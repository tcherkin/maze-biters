"""Restore exact iPhone artwork packs and checksum-pinned original audio sources."""
from pathlib import Path
import argparse
import gzip
import hashlib
import io
import json
import shutil
import struct
import re
import subprocess
from urllib.request import Request, urlopen

PACK_BASE = "../../../PC/StreamingAssets/WebPayload/"
REPOSITORY = "https://github.com/tcherkin/maze-biters"


def safe(root, relative):
    if not relative or "\\" in relative or Path(relative).is_absolute() or ".." in Path(relative).parts:
        raise ValueError("Unsafe relative path")
    path = (root / relative).resolve()
    if not path.is_relative_to(root.resolve()):
        raise ValueError("Path escapes destination")
    return path


def main():
    here = Path(__file__).resolve().parent
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("payload", type=Path, help="Published iPhone/StreamingAssets/WebPayload folder; shared PC packs must retain their repository-relative location")
    parser.add_argument("--repository", type=Path, help="Optional complete Git clone, used to restore original audio from its pinned commit without network access")
    args = parser.parse_args()
    payload = args.payload.resolve()
    manifest = json.loads((payload / "manifest.json").read_text(encoding="utf-8"))
    pack_base = manifest.get("packBase", "")
    if pack_base not in ("", PACK_BASE):
        raise ValueError("Unexpected shared pack base")
    pack_root = (payload / pack_base).resolve() if pack_base else payload
    expected = {x["path"]: x for x in manifest["requiredSources"]}
    sources = here / "SourceAssets"
    copies = (here / "WebPayload", here / "UnityProject/Assets/StreamingAssets/WebPayload")
    seen = set()
    for item in manifest["packs"]:
        path = safe(pack_root, item["file"])
        blob = path.read_bytes()
        if len(blob) != item["bytes"] or hashlib.sha256(blob).hexdigest() != item["sha256"]:
            raise ValueError("Pack integrity failure: " + item["file"])
        raw = gzip.decompress(blob)
        if len(raw) != item["rawBytes"]:
            raise ValueError("Pack length mismatch")
        reader = io.BytesIO(raw)
        while True:
            header = reader.read(4)
            if len(header) != 4:
                raise ValueError("Missing pack terminator")
            size, = struct.unpack("<i", header)
            if size == 0:
                if reader.read():
                    raise ValueError("Trailing bytes")
                break
            if not 0 < size <= 4096:
                raise ValueError("Invalid path size")
            key = reader.read(size).decode("utf-8")
            length, = struct.unpack("<i", reader.read(4))
            if length < 0 or length > 134217728:
                raise ValueError("Invalid file size")
            data = reader.read(length)
            evidence = expected.get(key)
            if key in seen or evidence is None or evidence["pack"] != item["file"] or len(data) != evidence["bytes"] or hashlib.sha256(data).hexdigest() != evidence["sha256"]:
                raise ValueError("Source integrity failure: " + key)
            target = safe(sources, key)
            target.parent.mkdir(parents=True, exist_ok=True)
            if target.exists() and target.read_bytes() != data:
                raise ValueError("Refusing to replace a changed source file: " + key)
            target.write_bytes(data)
            seen.add(key)
        for folder in copies:
            folder.mkdir(parents=True, exist_ok=True)
            target = safe(folder, item["file"])
            if target != path:
                shutil.copy2(path, target)
    if seen != expected.keys():
        raise ValueError("Incomplete source set")
    local_manifest = dict(manifest)
    local_manifest.pop("packBase", None)
    for folder in copies:
        target = folder / "manifest.json"
        if target.resolve() == (payload / "manifest.json").resolve():
            raise ValueError("Restoration must not replace a published manifest")
        target.write_text(json.dumps(local_manifest, indent=2) + "\n", encoding="utf-8")
    audio_manifest = json.loads((here / "audio-source-manifest.json").read_text(encoding="utf-8"))
    commit = audio_manifest["commit"]
    if audio_manifest.get("repository") != REPOSITORY or not re.fullmatch(r"[0-9a-f]{40}", commit):
        raise ValueError("Unexpected audio source repository")
    raw_base = "https://raw.githubusercontent.com/tcherkin/maze-biters/" + commit + "/"
    if audio_manifest.get("rawBase") != raw_base:
        raise ValueError("Unexpected audio source URL")
    restored_audio = 0
    for item in audio_manifest["files"]:
        repository_path, name = item["repositoryPath"], Path(item["path"]).name
        if not re.fullmatch(r"assets/audio/(?:music|sfx)/[a-z0-9-]+\.(?:mp3|wav)", repository_path) or item["path"] != "UnityProject/Assets/Resources/SessionAudio/" + name or Path(repository_path).name != name:
            raise ValueError("Invalid audio source path")
        if args.repository:
            data = subprocess.check_output(["git", "-C", str(args.repository.resolve()), "show", commit + ":" + repository_path])
        else:
            with urlopen(Request(raw_base + repository_path, headers={"User-Agent": "Maze-Biters-source-restoration"}), timeout=120) as response:
                data = response.read()
        if len(data) != item["bytes"] or hashlib.sha256(data).hexdigest() != item["sha256"]:
            raise ValueError("Audio integrity failure: " + name)
        target = safe(here, item["path"])
        target.parent.mkdir(parents=True, exist_ok=True)
        if target.exists() and target.read_bytes() != data:
            raise ValueError("Refusing to replace a changed audio source: " + name)
        target.write_bytes(data)
        restored_audio += 1
    print(json.dumps({"passed": True, "restoredFiles": len(seen), "packs": len(manifest["packs"]), "restoredAudio": restored_audio, "audioCommit": commit}))


if __name__ == "__main__":
    main()

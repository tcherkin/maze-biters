using System;
using System.IO;
using UnityEditor;
using UnityEditor.SceneManagement;
using UnityEditor.Build.Reporting;
using UnityEngine;
using MazeBiters.NativeStudy;
public static class StudyBuild {
 public static void Build(){
  SmoothLightBuild.Prepare();
  RunTests();
  Debug.Log("IPAD_FRAMING_TESTS "+IpadFramingValidation.Run());
  Debug.Log("IPAD_CAMERA_MOTION_TESTS "+IpadCameraMotionValidation.Run());
  Debug.Log("IPAD_SOLO_PACE_CHECKS "+IpadSoloPaceValidation.Run());
  Debug.Log("IPAD_BALANCE_CHECKS "+IpadCameraBalanceValidation.Run());
  IpadBuild.ValidateDevice();
  {var graphics=AssetDatabase.LoadAllAssetsAtPath("ProjectSettings/GraphicsSettings.asset")[0];var state=new SerializedObject(graphics);var list=state.FindProperty("m_AlwaysIncludedShaders");var shader=Shader.Find("MazeBiters/TunnelMaze");if(!shader)throw new Exception("Missing transparent tunnel shader");bool found=false;for(int i=0;i<list.arraySize;i++)found|=list.GetArrayElementAtIndex(i).objectReferenceValue==shader;if(!found){list.InsertArrayElementAtIndex(list.arraySize);list.GetArrayElementAtIndex(list.arraySize-1).objectReferenceValue=shader;state.ApplyModifiedPropertiesWithoutUndo();}}
  foreach(var name in new[]{"MazeBiters/LuminousFrameStars","MazeBiters/LuminousTunnelMaze","MazeBiters/FocusedCrystal","MazeBiters/ContourDusk","MazeBiters/GlideLanternLight","MazeBiters/FrameStars","MazeBiters/NeonField","MazeBiters/NeonProject","MazeBiters/NeonScreen","MazeBiters/NeonBlur"}){var neonSettings=AssetDatabase.LoadAllAssetsAtPath("ProjectSettings/GraphicsSettings.asset")[0];var state=new SerializedObject(neonSettings);var list=state.FindProperty("m_AlwaysIncludedShaders");var shader=Shader.Find(name);if(!shader)throw new Exception("Missing shader "+name);bool found=false;for(int i=0;i<list.arraySize;i++)if(list.GetArrayElementAtIndex(i).objectReferenceValue==shader)found=true;if(!found){list.InsertArrayElementAtIndex(list.arraySize);list.GetArrayElementAtIndex(list.arraySize-1).objectReferenceValue=shader;state.ApplyModifiedPropertiesWithoutUndo();}}
  {var graphics=AssetDatabase.LoadAllAssetsAtPath("ProjectSettings/GraphicsSettings.asset")[0];var state=new SerializedObject(graphics);var list=state.FindProperty("m_AlwaysIncludedShaders");var shader=Shader.Find("MazeBiters/NeonWallScreen");if(!shader)throw new Exception("Missing wall detail shader");bool found=false;for(int i=0;i<list.arraySize;i++)found|=list.GetArrayElementAtIndex(i).objectReferenceValue==shader;if(!found){list.InsertArrayElementAtIndex(list.arraySize);list.GetArrayElementAtIndex(list.arraySize-1).objectReferenceValue=shader;state.ApplyModifiedPropertiesWithoutUndo();}}
  PlayerSettings.companyName="Maze Biters";PlayerSettings.productName="Maze Biters iPad Preview";
  PlayerSettings.colorSpace=ColorSpace.Gamma;PlayerSettings.defaultScreenWidth=1440;PlayerSettings.defaultScreenHeight=1080;
  PlayerSettings.fullScreenMode=FullScreenMode.Windowed;PlayerSettings.runInBackground=true;PlayerSettings.resizableWindow=true;
  PlayerSettings.SetScriptingBackend(UnityEditor.Build.NamedBuildTarget.Standalone,ScriptingImplementation.Mono2x);
  PlayerSettings.SetUseDefaultGraphicsAPIs(BuildTarget.StandaloneWindows64,false);
  PlayerSettings.SetGraphicsAPIs(BuildTarget.StandaloneWindows64,new[]{UnityEngine.Rendering.GraphicsDeviceType.Direct3D11});
  // Explicit references keep shaders alive in release builds.
  var settings=AssetDatabase.LoadAllAssetsAtPath("ProjectSettings/GraphicsSettings.asset")[0];var so=new SerializedObject(settings);var shaders=so.FindProperty("m_AlwaysIncludedShaders");
  foreach(var name in new[]{"MazeBiters/CoopLeader","MazeBiters/MenuImage","MazeBiters/MenuShine","MazeBiters/HudGlyph","MazeBiters/SessionImage","MazeBiters/PickupImage","MazeBiters/PackedCharacter","MazeBiters/ExactImage","MazeBiters/EraseLight","MazeBiters/PremultipliedImage","MazeBiters/fantasyTurn","MazeBiters/dragonTurn","MazeBiters/SnakeSurface","MazeBiters/SnakeHead","MazeBiters/SnakeComposite","MazeBiters/IntakeCardinal","MazeBiters/fantasyMaskTurn","MazeBiters/IntakeComposite","MazeBiters/EraseIntake","MazeBiters/CreatureNeon","MazeBiters/CreatureEye","MazeBiters/dragonEyeTurn","MazeBiters/HunterEye","MazeBiters/ScorpionClip","MazeBiters/ScorpionRibbon"}){var shader=Shader.Find(name);if(!shader)throw new Exception("Missing shader "+name);bool found=false;for(int i=0;i<shaders.arraySize;i++)if(shaders.GetArrayElementAtIndex(i).objectReferenceValue==shader)found=true;if(!found){shaders.InsertArrayElementAtIndex(shaders.arraySize);shaders.GetArrayElementAtIndex(shaders.arraySize-1).objectReferenceValue=shader;}}so.ApplyModifiedPropertiesWithoutUndo();
  var scene=EditorSceneManager.NewScene(NewSceneSetup.EmptyScene,NewSceneMode.Single);EditorSceneManager.SaveScene(scene,"Assets/NativeStudy.unity");
  IpadBuild.Configure();
  var output=Path.GetFullPath(Path.Combine(Application.dataPath,"../../Builds/WindowsPreview/MazeBitersIPadPreview.exe"));Directory.CreateDirectory(Path.GetDirectoryName(output));
  var report=BuildPipeline.BuildPlayer(new BuildPlayerOptions{scenes=new[]{"Assets/NativeStudy.unity"},locationPathName=output,target=BuildTarget.StandaloneWindows64,options=BuildOptions.None});
  if(report.summary.result!=BuildResult.Succeeded)throw new Exception("Build failed: "+report.summary.result);
  // Tested Windows-only policy. BuildPipeline regenerates boot.config; keep
  // the lower-reservation allocator alongside fully overwritten glass textures.
  var boot=Path.Combine(Path.GetDirectoryName(output),"MazeBitersIPadPreview_Data/boot.config");
  File.AppendAllText(boot,"\nmemorysetup-main-allocator-mimalloc-enabled=0\n");
  Debug.Log("STUDY_BUILD_SUCCESS "+output+" bytes="+report.summary.totalSize);
 }
 public static void RunTests(){
  IpadPresentation.Suppress=true;try{
  Debug.Log("HUD_CONTACT_EASING_TESTS "+NativeHudContactValidation.Run());
  Debug.Log("STARTUP_PIXEL_CACHE_TESTS "+NativeStartupPixels.Validate());
  Debug.Log("GLASS_AURA_CLOCK_TESTS "+NativeLanternGlideValidation.Run());
  Debug.Log("AI_ONLY_ORIGINAL_DECISION_TESTS "+NativeAllyValidation.Run(false,false,true));
  Debug.Log("AI_ONLY_MODE_TESTS "+NativeAiOnlyValidation.Run());
  Debug.Log("TUNNEL_SKY_TESTS "+NativeTunnelSky.Validate());
  Debug.Log("DISPLAY_LAYOUT_TESTS "+NativeDisplayValidation.Run());
  Debug.Log("OVERVIEW_FRAMING_TESTS "+NativeOverviewFramingValidation.Run());
  Debug.Log("GAMEPAD_INPUT_TESTS "+NativeGamepadValidation.Run());
  Debug.Log("ALLY_ORIGINAL_DECISION_TESTS "+NativeAllyValidation.Run());
  Debug.Log("DUO_AI_ORIGINAL_DECISION_TESTS "+NativeAllyValidation.Run(false,true));
  Debug.Log("DUO_AI_ROSTER_TESTS "+NativeDuoAiValidation.Run());
  Debug.Log("DUO_AI_CAMERA_PARITY_TESTS "+NativeCoopValidation.Camera(true));
  Debug.Log("LEADER_AURA_MOTION_TESTS "+NativeLeaderAuraMotion.Validate());
  Debug.Log("LEADER_AURA_HEADING_TESTS "+NativeAuraHeading.Validate());
  Debug.Log("VERSUS_ORIGINAL_RULE_TESTS "+NativeVersusValidation.Run());
  Debug.Log("COOP_CAMERA_PARITY_TESTS "+NativeCoopValidation.Camera());
  Debug.Log("COOP_ORIGINAL_RULE_TESTS "+NativeCoopValidation.Run());
  Debug.Log("HIGH_SCORE_RULE_TESTS "+NativeRecordValidation.Numeric());
  Debug.Log("MENU_STATE_TESTS "+NativeMenuValidation.Numeric());
  Debug.Log("AUDIO_EVENT_AUDIT "+JsonUtility.ToJson(NativeAudioAudit.Events()));
  Debug.Log("HUD_CLOCK_PARITY_TESTS "+NativeHudValidation.Numeric());
  Debug.Log("HEAD_LIGHT_POSE_TESTS "+NativeHeadLightValidation.Run());
  Debug.Log("HUMAN_TURN_HISTORY_TESTS "+NativeHumanTurnValidation.Run());
  Debug.Log("CAMERA_ORIGINAL_PARITY_TESTS "+NativeCameraValidation.Run());
  Debug.Log("SNAKE_PACK_EXACT_PIXEL_TESTS "+NativeSnakePackValidation.Run());
  Debug.Log("MAZE_GENERATOR_PARITY_CASES "+MazeGeneratorValidation.Run());
  void Equal(double a,double b,string name){if(Math.Abs(a-b)>1e-9)throw new Exception(name+": "+a+" != "+b);}
  Equal(AnimationClock.Blink(0),0,"blink start");Equal(AnimationClock.Blink(70),1,"blink closed");Equal(AnimationClock.Blink(105),1,"blink hold");Equal(AnimationClock.Blink(220),0,"blink finish");
  Equal(AnimationClock.Mouth(0,95),.4,"walking closed");Equal(AnimationClock.Mouth(47.5,95),.26,"walking open");Equal(AnimationClock.Mouth(95,95),.4,"walking cycle");
  Equal(NativeLevelStudy.Directions[1].y,1,"down is positive grid Y");Equal(NativeLevelStudy.Directions[3].y,-1,"up is negative grid Y");
  AnimationValidation.ClockTests();Debug.Log("SCORPION_NUMERIC_TESTS "+ScorpionValidation.Run());
  Debug.Log("GAMEPLAY_LOGIC_TESTS "+JsonUtility.ToJson(GameplayValidation.Run()));
  Debug.Log("SESSION_LOGIC_TESTS "+JsonUtility.ToJson(SessionValidation.Run()));Debug.Log("LIFECYCLE_LOGIC_TESTS "+JsonUtility.ToJson(LifecycleValidation.Run()));Debug.Log("NEON_EYE_CLOCK_TESTS "+NeonValidation.EyeTests());
  Debug.Log("SNAKE_MOTION_TESTS "+AnimationValidation.SnakeTests());Debug.Log("SNAKE_RESOURCE_AND_RETIREMENT_TESTS "+SnakeResourceValidation.Run());
  Equal(AnimationClock.TurnAngle(2,0,45),1,"left-right via down");Equal(AnimationClock.TurnAngle(0,2,45),1,"right-left via down");
  for(int from=0;from<4;from++)for(int to=0;to<4;to++){var a=AnimationClock.TurnAngle(from,to,90);Equal((a%4+4)%4,to,"90ms endpoint");}
  var level=JsonUtility.FromJson<LevelData>(File.ReadAllText(Path.Combine(Application.streamingAssetsPath,"Reference/level.json")));
  if(level.geometry.Length!=25)throw new Exception("Level height");foreach(var row in level.geometry)if(row.Length!=36)throw new Exception("Level width");
  var manifest=JsonUtility.FromJson<ArtManifest>(File.ReadAllText(Path.Combine(Application.streamingAssetsPath,"Art/manifest.json")));
  int sets=0;foreach(var profile in manifest.profiles)foreach(var set in profile.sets){sets++;if(set.mouth.frames!=49)throw new Exception("Mouth frames");foreach(var p in set.blink)if(p.frames!=25)throw new Exception("Blink frames");}
  if(sets!=72)throw new Exception("Expected normal and three bright-player packs / both qualities / four headings");
  Debug.Log("STUDY_TESTS_PASS clocks, turn routing, level dimensions, 72 native art sets");
  }finally{IpadPresentation.Suppress=false;}
 }
}

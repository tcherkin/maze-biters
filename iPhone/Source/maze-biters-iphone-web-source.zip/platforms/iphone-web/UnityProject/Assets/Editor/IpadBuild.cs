using System;
using UnityEditor;
using UnityEngine;
using MazeBiters.NativeStudy;

public static class IpadBuild {
 public static void Configure(){
  PlayerSettings.companyName="Maze Biters";PlayerSettings.productName="Maze Biters iPad Preview";
  PlayerSettings.defaultScreenWidth=1280;PlayerSettings.defaultScreenHeight=960;
  PlayerSettings.defaultInterfaceOrientation=UIOrientation.AutoRotation;
  PlayerSettings.allowedAutorotateToPortrait=false;PlayerSettings.allowedAutorotateToPortraitUpsideDown=false;
  PlayerSettings.allowedAutorotateToLandscapeLeft=true;PlayerSettings.allowedAutorotateToLandscapeRight=true;
  PlayerSettings.iOS.targetDevice=iOSTargetDevice.iPadOnly;
  PlayerSettings.SetApplicationIdentifier(UnityEditor.Build.NamedBuildTarget.iOS,"com.mazebiters.ipad.prototype");
  PlayerSettings.SetScriptingBackend(UnityEditor.Build.NamedBuildTarget.iOS,ScriptingImplementation.IL2CPP);
  PlayerSettings.SetUseDefaultGraphicsAPIs(BuildTarget.iOS,false);
  PlayerSettings.SetGraphicsAPIs(BuildTarget.iOS,new[]{UnityEngine.Rendering.GraphicsDeviceType.Metal});
  EditorBuildSettings.scenes=new[]{new EditorBuildSettingsScene("Assets/NativeStudy.unity",true)};
  AssetDatabase.SaveAssets();
 }
 [MenuItem("Maze Biters/iPad/Build Windows preview")]
 public static void BuildPreview()=>StudyBuild.Build();
 [MenuItem("Maze Biters/iPad/Validate framing")]
 public static void Validate()=>Debug.Log("IPAD_FRAMING_TESTS "+IpadFramingValidation.Run());
 [MenuItem("Maze Biters/iPad/Open Device Simulator")]
 public static void OpenSimulator(){
  var type=Type.GetType("UnityEditor.DeviceSimulation.SimulatorWindow, UnityEditor.DeviceSimulatorModule");
  if(type==null)throw new Exception("Unity Device Simulator is unavailable in this Editor.");
  var window=EditorWindow.GetWindow(type);window.Show();
  // Unity 6.6 exposes the device selector on its internal SimulatorWindow.
  // Keep this editor convenience separate from all player/runtime code.
  var main=type.GetProperty("main")?.GetValue(window);
  var devices=main?.GetType().GetProperty("devices")?.GetValue(main) as Array;
  if(devices!=null)for(int i=0;i<devices.Length;i++)if(AssetDatabase.GetAssetPath((UnityEngine.Object)devices.GetValue(i))=="Assets/Devices/iPad-Pro-13-M5.device"){
   main.GetType().GetProperty("deviceIndex").SetValue(main,i);Debug.Log("IPAD_SIMULATOR_SELECTED native 2752x2064 landscape");break;
  }
  window.position=new Rect(40,80,1000,640);
  foreach(var other in Resources.FindObjectsOfTypeAll<EditorWindow>())if(other.GetType().Name=="GameView")other.Close();
  window.Focus();
  Debug.Log("iPad Simulator previews layout/touch, not M5 GPU performance. Press Play to test.");
 }
 public static void ValidateDevice(){
  var objects=AssetDatabase.LoadAllAssetsAtPath("Assets/Devices/iPad-Pro-13-M5.device");
  if(objects.Length==0)throw new Exception("Custom iPad device was not imported");
  foreach(var obj in objects)Debug.Log("IPAD_DEVICE_IMPORTED "+obj.GetType().FullName+" "+obj.name);
 }
}


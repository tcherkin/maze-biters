using System;
using System.IO;
using UnityEngine;
using MazeBiters.NativeStudy;

// Pure framing and pointer checks. Device rendering and performance are separate.
public static class IPhoneFramingAudit {
 [Serializable] sealed class Result { public bool passed; public int checks,sourceChecks; public string note; }
 public static void Validate(){
  var result=new Result{note="Native iPhone viewport, half-resolution HD, full-frame layout, whole-maze overview, edge balance, player visibility and touch projection. Camera, input and gameplay source preserved from the iPad Web edition."};
  void Check(bool ok,string name){result.checks++;if(!ok)throw new Exception("iPhone framing: "+name);}
  void Near(double a,double b,string name)=>Check(Math.Abs(a-b)<.002,name+": "+a+" / "+b);
  Check(IPhoneViewport.ReferencePixels==new Vector2Int(2868,1320),"iPhone 17 Pro Max native reference");
  Check(IPhoneViewport.Resolution(IPhoneViewport.ReferencePixels,"4k")==new Vector2Int(2868,1320),"native render target");
  Check(IPhoneViewport.Resolution(IPhoneViewport.ReferencePixels,"hd")==new Vector2Int(1434,660),"HD half-native render target");
  Check(IPhoneViewport.Resolution(new Vector2Int(2533,1171),"hd")==new Vector2Int(1267,586),"odd-pixel half-resolution rounding agrees with JavaScript");
  Check(IPhoneViewport.ConstrainNative(8604,3960)==new Vector2Int(2868,1320),"physical-sized CSS times DPR stays within physical landscape cap");
  Check(IPhoneViewport.ConstrainNative(3960,8604)==new Vector2Int(1320,2868),"portrait cap swaps the physical axes");
  Check(IPhoneViewport.ConstrainNative(3840,2160)==new Vector2Int(2347,1320),"different oversized aspect is preserved proportionally");
  Check(IPhoneViewport.Resolution(new Vector2Int(8604,3960),"hd")==new Vector2Int(1434,660),"HD halves the bounded native surface");
  Check(IPhoneViewport.ConstrainNative(double.NaN,1320)==IPhoneViewport.ReferencePixels,"invalid native metrics retain finite reference dimensions");
  foreach(var native in new[]{new Vector2Int(2868,1320),new Vector2Int(2532,1170),new Vector2Int(2778,1284),new Vector2Int(1334,750),new Vector2Int(1920,1080)}){
   var f=new NativeFrame((float)native.x/native.y,true);var safe=IpadPresentation.SafeRect(f);double close=IPhoneViewport.CloseZoom(f,native);
   Near(safe.xMin,0,"full-width left");Near(safe.yMin,0,"full-height top");Near(safe.width,f.Width,"full-width right");Near(safe.height,f.Height,"full-height bottom");
   Check(close>=1&&close<=2.6,"close zoom retains the established limit");
   var overview=IpadFraming.Calculate(f,288,200,1,close,safe);var board=f.ProjectBoard(overview.x,overview.y,overview.zoom);
   Near(board.y,32,"overview reserves original header");Near(board.yMax,f.Height,"overview reaches bottom");Near(board.x,f.Width-board.xMax,"overview side stars balanced");Check(board.x>=0,"overview shows entire width");
   var left=IpadFraming.Calculate(f,144,200,2,close,safe);var right=IpadFraming.Calculate(f,432,200,2,close,safe);
   var top=IpadFraming.Calculate(f,288,100,2,close,safe);var bottom=IpadFraming.Calculate(f,288,300,2,close,safe);
   Near(f.ProjectBoard(left.x,left.y,left.zoom).x,52,"left edge sky");Near(f.Width-f.ProjectBoard(right.x,right.y,right.zoom).xMax,52,"right edge sky");
   Near(f.ProjectBoard(top.x,top.y,top.zoom).y,52,"top edge sky");Near(f.Height-f.ProjectBoard(bottom.x,bottom.y,bottom.zoom).yMax,52,"bottom edge sky");
   foreach(var bounds in new[]{new Rect(24,24,0,0),new Rect(24,24,528,352),new Rect(80,40,300,220)}){
    var view=IpadFraming.KeepPlayers(f,top,bounds,safe);var projected=f.ProjectBoard(view.x,view.y,view.zoom);
    double minX=projected.x+(bounds.xMin-12)*view.zoom,maxX=projected.x+(bounds.xMax+12)*view.zoom,minY=projected.y+(bounds.yMin-12)*view.zoom,maxY=projected.y+(bounds.yMax+12)*view.zoom;
    Check(minX>=safe.xMin-.002&&maxX<=safe.xMax+.002&&minY>=Math.Max(safe.yMin,view.header)-.002&&maxY<=safe.yMax+.002,"all players fit with their complete silhouettes");
   }
   foreach(string quality in new[]{"hd","4k"}){
    var pixels=IPhoneViewport.Resolution(native,quality);Check(pixels==IPhoneViewport.Resolution(native,quality),"quality queries never halve the previous result");
    Check(Math.Abs((double)pixels.x/pixels.y-(double)native.x/native.y)<.003,"render aspect follows viewport");
    foreach(double sourceZoom in new[]{1.0,1.5,2.0}){
     var view=IpadFraming.Calculate(f,288,200,sourceZoom,close,safe);var projected=f.ProjectBoard(view.x,view.y,view.zoom);
     for(int row=0;row<25;row++)for(int col=0;col<36;col++){
      var p=new Vector2((float)(projected.x+(col+.5)*16*view.zoom),(float)(projected.y+(row+.5)*16*view.zoom));
      var physical=new Vector2(p.x/f.Width*pixels.x,pixels.y-p.y/f.Height*pixels.y);var logical=f.Logical(physical,new Rect(0,0,pixels.x,pixels.y),pixels.y);
      bool visible=p.x>=0&&p.x<f.Width&&p.y>=0&&p.y<f.Height;bool hit=f.PointerCell(logical,view.x,view.y,view.zoom,out var cell);
      Check(hit==visible&&(!hit||cell==new Vector2Int(col,row)),"touch coordinates match rendered maze");
     }
    }
   }
  }
  string source=Path.Combine(Application.dataPath,"Scripts"),original=Path.GetFullPath(Path.Combine(Application.dataPath,"../../../../platforms/ipad-web/UnityProject/Assets/Scripts"));
  if(Directory.Exists(original))foreach(string file in new[]{"NativeGameplayCamera.cs","IpadCameraMotion.cs","IpadInput.cs","NativeGameplayCameraIntegration.cs","NativeGameplayWorld.cs","NativeGamepadInput.cs"}){
   result.sourceChecks++;Check(File.ReadAllText(Path.Combine(original,file)).Replace("\r\n","\n")==File.ReadAllText(Path.Combine(source,file)).Replace("\r\n","\n"),"iPad source preserved: "+file);
  }
  result.passed=true;string dir=Path.GetFullPath(Path.Combine(Application.dataPath,"../../Results/iphone-framing"));Directory.CreateDirectory(dir);File.WriteAllText(Path.Combine(dir,"checks.json"),JsonUtility.ToJson(result,true));
  Debug.Log("IPHONE_FRAMING_CHECKS "+result.checks+" source="+result.sourceChecks);
 }
}

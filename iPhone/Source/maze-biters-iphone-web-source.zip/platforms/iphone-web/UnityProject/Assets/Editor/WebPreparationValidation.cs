using System;
using System.IO;
using System.Collections.Generic;
using UnityEngine;
using MazeBiters.NativeStudy;

public static class WebPreparationValidation {
 [Serializable] sealed class Report {public bool passed;public NativeMazeArtwork.WebPainterValidationResult[] cases;}
 public static void Run(){
  string destination=Path.GetFullPath(Path.Combine(Application.dataPath,"../../Results"));Directory.CreateDirectory(destination);
  var results=new List<NativeMazeArtwork.WebPainterValidationResult>();var lines=new List<string>();
  foreach(string quality in new[]{"hd","4k"})foreach(string theme in NativeMazeGenerator.Themes){
   var result=NativeMazeArtwork.ValidateWebPainterResult(quality,theme,theme=="green");results.Add(result);
   string json=JsonUtility.ToJson(result);lines.Add(json);Debug.Log("WEB_PAINTER_PARITY "+json);
   File.WriteAllLines(Path.Combine(destination,"cooperative-painter.txt"),lines);
   File.WriteAllText(Path.Combine(destination,"cooperative-painter.json"),JsonUtility.ToJson(new Report{passed=false,cases=results.ToArray()},true));
  }
  File.WriteAllText(Path.Combine(destination,"cooperative-painter.json"),JsonUtility.ToJson(new Report{passed=true,cases=results.ToArray()},true));
 }
}

using System;using System.IO;using UnityEditor;using UnityEngine;
[InitializeOnLoad] public static class WebSnakeSurfaceValidation {
 const string Pending="MazeBiters.SnakeSurfaces.Pending",Started="MazeBiters.SnakeSurfaces.Started";
 static WebSnakeSurfaceValidation(){EditorApplication.update+=Watch;}
 public static void Run(){var args=Environment.GetCommandLineArgs();int at=Array.IndexOf(args,"--report");if(Array.IndexOf(args,"--snake-surface-probe")<0||at<0||at+1==args.Length)throw new ArgumentException("Use --snake-surface-probe --report <fresh JSON path>");string report=Path.GetFullPath(args[at+1]);if(File.Exists(report))throw new IOException("Report already exists: "+report);SessionState.SetString(Pending,report);SessionState.SetString(Started,DateTime.UtcNow.ToString("O"));EditorApplication.EnterPlaymode();}
 static void Watch(){string report=SessionState.GetString(Pending,"");if(report.Length==0)return;if(File.Exists(report)){var result=JsonUtility.FromJson<MazeBiters.NativeStudy.NativeSnakeSurfaceValidation.Result>(File.ReadAllText(report));SessionState.EraseString(Pending);EditorApplication.Exit(result.passed?0:2);return;}if(DateTime.TryParse(SessionState.GetString(Started,""),out var started)&&(DateTime.UtcNow-started.ToUniversalTime()).TotalMinutes>8){SessionState.EraseString(Pending);Debug.LogError("Snake surface probe timed out");EditorApplication.Exit(3);}}
}

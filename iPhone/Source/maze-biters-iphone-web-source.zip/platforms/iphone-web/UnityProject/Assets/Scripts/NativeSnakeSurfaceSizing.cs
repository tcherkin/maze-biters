using System;
using UnityEngine;

namespace MazeBiters.NativeStudy {
 // Capacity follows one current silhouette, never the independent largest X/Y
 // extents from unrelated poses. Texel density and the resolve path stay fixed.
 public sealed class NativeSnakeSurfaceSizing {
  const double ShrinkDelay=.4;
  double oversizedSince=double.NaN;
  public static readonly bool Legacy=Array.IndexOf(Environment.GetCommandLineArgs(),"--legacy-snake-surface-shapes")>=0;
  static int Capacity(double required,int limit)=>Math.Min((int)Math.Ceiling(limit/32.0)*32,Math.Max(32,(int)Math.Ceiling(required*1.125/32)*32));
  public Vector2Int Choose(int currentWidth,int currentHeight,int visibleWidth,int visibleHeight,double reservedWidth,double reservedHeight,int limitWidth,int limitHeight,double now,out bool shrink){
   shrink=false;
   var desired=new Vector2Int(Capacity(Math.Max(visibleWidth,Math.Min(limitWidth,reservedWidth)),limitWidth),Capacity(Math.Max(visibleHeight,Math.Min(limitHeight,reservedHeight)),limitHeight));
   bool grow=currentWidth<visibleWidth||currentHeight<visibleHeight;
   if(grow){oversizedSince=double.NaN;return desired;}
   bool excessive=(long)currentWidth*currentHeight>4L*desired.x*desired.y;
   if(!excessive){oversizedSince=double.NaN;return new Vector2Int(currentWidth,currentHeight);}
   if(double.IsNaN(oversizedSince)||now<oversizedSince)oversizedSince=now;
   if(now-oversizedSince<ShrinkDelay)return new Vector2Int(currentWidth,currentHeight);
   oversizedSince=double.NaN;shrink=true;return desired;
  }
  public void Reset(){oversizedSince=double.NaN;}
 }
}

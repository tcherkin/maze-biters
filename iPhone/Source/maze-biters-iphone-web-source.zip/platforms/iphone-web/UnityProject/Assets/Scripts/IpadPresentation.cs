using System;
using UnityEngine;
using Screen = UnityEngine.Device.Screen;

namespace MazeBiters.NativeStudy {
 // Independent iPhone Web presentation. Rules, artwork, animation and the
 // proven touch/roster camera remain in the original game coordinate system.
 public static class IpadPresentation {
  static readonly string[] args=Environment.GetCommandLineArgs();
  public static bool Suppress;
  public static bool Enabled=>!Suppress&&(Application.isPlaying||!Application.isEditor)&&Array.IndexOf(args,"--pc-framing")<0;
  public static bool Probe=>Array.IndexOf(args,"--ipad-probe")>=0;
  public static bool DefaultMenu=>Application.isEditor||Array.IndexOf(args,"--report")<0&&Array.IndexOf(args,"--gameplay")<0;
  public static string DefaultQuality=>WebFiles.IsWeb?WebFiles.InitialQuality:(Enabled?"4k":"hd");
  // Desktop preview is a native-size render fitted into a resizable window.
  // Device Simulator and iPad use the actual (possibly windowed) device surface.
  public static Vector2Int NativePixels=>IPhoneViewport.NativePixels;
  public static float Aspect=>(float)NativePixels.x/NativePixels.y;
  public static Vector2Int Pixels(string quality)=>IPhoneViewport.Pixels(quality);
  public static double CloseZoom(NativeFrame f)=>IPhoneViewport.CloseZoom(f,NativePixels);
  // User requested full-screen dimensions without treating the notch as an inset.
  // Background, game and HUD all use the complete available viewport.
  public static Rect SafeRect(NativeFrame f)=>new Rect(0,0,f.Width,f.Height);
  static float Arg(string key){int i=Array.IndexOf(args,key);return i>=0&&i+1<args.Length&&float.TryParse(args[i+1],out float n)?Math.Max(0,n):0;}
 }

 public struct IpadView {public double x,y,zoom,header;}
 public static class IpadFraming {
  const double EdgeSky=52; // Equal screen-space breathing room on all four edges.
  public static double Smooth(double t){t=Math.Max(0,Math.Min(1,t));return t*t*(3-2*t);}
  public static IpadView Calculate(NativeFrame f,double x,double y,double sourceZoom,double closeZoom,Rect safe){
   double t=Smooth((sourceZoom-1)/.5),reserve=(32+safe.yMin)*(1-t);
   double fit=Math.Min(f.Width/576.0,(f.Height-32-safe.yMin)/400.0);
   double z=fit+(sourceZoom-1)*(closeZoom-fit);
   double dy=reserve/(2*z),cx=x,cy=y-dy;
   double spanX=Math.Min(64/sourceZoom,288-288/sourceZoom),spanY=Math.Min(64/sourceZoom,200-200/sourceZoom);
   if(spanX>0){double left=Smooth(1-(x-288/sourceZoom)/spanX),right=Smooth(1-(576-288/sourceZoom-x)/spanX);cx+=(f.Width/2-288*z/sourceZoom-EdgeSky*t)/z*(left-right);}
   if(spanY>0){double top=Smooth(1-(y-200/sourceZoom)/spanY),bottom=Smooth(1-(400-200/sourceZoom-y)/spanY);cy+=(f.Height/2-200*z/sourceZoom-reserve/2-EdgeSky*t)/z*(top-bottom);}
   return new IpadView{x=cx,y=cy,zoom=z,header=reserve};
  }
  // Only the camera is constrained. No entity position, tick, input, or animation changes.
  public static IpadView KeepPlayers(NativeFrame f,IpadView v,Rect bounds,Rect safe,double radius=12){
   double top=Math.Max(safe.yMin,v.header),bottom=safe.yMax,left=safe.xMin,right=safe.xMax;
   v.zoom=Math.Min(v.zoom,Math.Min((right-left)/(bounds.width+2*radius),(bottom-top)/(bounds.height+2*radius)));
   double minX=bounds.xMax+radius-(right-f.Width/2)/v.zoom,maxX=bounds.xMin-radius+(f.Width/2-left)/v.zoom;
   double minY=bounds.yMax+radius-(bottom-f.Height/2)/v.zoom,maxY=bounds.yMin-radius+(f.Height/2-top)/v.zoom;
   v.x=Math.Max(minX,Math.Min(maxX,v.x));v.y=Math.Max(minY,Math.Min(maxY,v.y));return v;
  }
 }
}

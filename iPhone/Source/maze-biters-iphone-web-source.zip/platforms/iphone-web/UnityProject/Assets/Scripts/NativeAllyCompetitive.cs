using System;using System.Collections.Generic;using System.Linq;using UnityEngine;
namespace MazeBiters.NativeStudy {
 public sealed partial class NativeAllyBrain {
  double OpponentDistance(Vector2Int from,NativePlayer other,double prediction){if(other==null)return Inf;int n=Field(other.Cell.x+other.Dir.x*prediction,other.Cell.y+other.Dir.y*prediction)[w.Index(from)];return n<0?Inf:n;}
  AllyDirective NewFlee(NativePlayer p,double t,List<(NativePlayer target,double distance)> threats,AllySkill skill,bool flip){
   var a=S(p);if(!Finite(a.escapeTemperamentUntil)||t>=a.escapeTemperamentUntil){a.escapeBite=w.Random()<skill.escapeBite;a.escapeSplit=w.Random()<skill.escapeSplit;a.escapeTemperamentUntil=t+Math.Max(450,skill.rethink*1.5);}
   var d=new AllyDirective{type="flee",target=threats[0].target,threats=threats.Select(x=>x.target).ToList(),skill=skill,urgent=true,bite=a.escapeBite,split=a.escapeSplit,flip=flip};
   a.directive=d;a.assessmentAt=t+Math.Max(180,skill.rethink);return d;
  }
  AllyDirective Directive(NativePlayer p,double t){
   var a=S(p);if(!w.Competitive||!p.IsAI||p.Dead||p.Lives<=0){a.directive=null;return null;}
   var skill=Skill;var others=Others(p).Where(o=>!o.Dead&&o.Lives>0).ToList();if(others.Count==0){a.directive=null;return null;}
   var threats=others.Where(o=>w.CanEatPlayer(o,p,t)).ToList();var prey=others.Where(o=>w.CanEatPlayer(p,o,t)).ToList();var prev=a.directive;
   bool flip=prev?.type=="hunt"&&threats.Contains(prev.target);
   var measured=threats.Select(o=>(target:o,distance:OpponentDistance(p.Cell,o,skill.prediction))).OrderBy(x=>x.distance).ToList();
   if(measured.Any(x=>x.distance<=skill.panic||flip&&x.target==prev.target&&x.distance<=skill.panic+1))return NewFlee(p,t,measured,skill,flip);
   double previousDistance=measured.Where(x=>x.target==prev?.target).Select(x=>x.distance).DefaultIfEmpty(Inf).First();
   bool valid=prev!=null&&prev.target!=null&&others.Contains(prev.target)&&(prev.type=="hunt"?prey.Contains(prev.target):prev.type=="flee"?threats.Contains(prev.target)&&previousDistance<=skill.panic+1:prev.type=="recover-score"&&threats.Contains(prev.target));
   if(valid&&t<a.assessmentAt)return prev;
   if(measured.Count>0){var d=new AllyDirective{type="recover-score",target=measured[0].target,threats=measured.Select(x=>x.target).ToList(),skill=skill};a.directive=d;a.assessmentAt=t+Math.Max(220,skill.rethink);a.escapeTarget=null;a.escapeUntil=0;return d;}
   var mp=prey.Select(o=>(target:o,distance:OpponentDistance(p.Cell,o,skill.prediction))).Where(x=>Finite(x.distance)).OrderBy(x=>x.target.Score).ThenBy(x=>x.distance).ToList();
   if(mp.Count>0&&mp[0].distance<=skill.notice&&w.Random()<skill.hunt){var chosen=mp[0];if(skill.error>0&&mp.Count>1&&w.Random()<skill.error)chosen=mp[Math.Min(mp.Count-1,1)];
    a.directive=new AllyDirective{type="hunt",target=chosen.target,threats=new List<NativePlayer>(),skill=skill};a.assessmentAt=t+skill.rethink;return a.directive;
   }a.directive=null;a.assessmentAt=t+skill.rethink;return null;
  }
  int Degree(Vector2Int c)=>dirs.Count(d=>w.Floor(c+d));
  Vector2Int? EscapeTarget(NativePlayer p,double t,AllyDirective directive){
   var a=S(p);var skill=directive?.skill??Skill;var threats=(directive?.threats??new List<NativePlayer>()).Where(o=>!o.Dead&&o.Lives>0&&w.CanEatPlayer(o,p,t)).ToList();if(threats.Count==0)return null;
   if(a.escapeTarget.HasValue&&t<a.escapeUntil&&w.Floor(a.escapeTarget.Value))return a.escapeTarget;
   var from=Field(p.Cell);var fields=threats.Select(o=>Field(o.Cell.x+o.Dir.x*skill.prediction,o.Cell.y+o.Dir.y*skill.prediction)).ToArray();
   var candidates=new List<(Vector2Int c,int travel,int degree,double score)>();for(int y=0;y<w.Height;y++)for(int x=0;x<w.Width;x++){var c=new Vector2Int(x,y);if(!w.Floor(c))continue;int k=w.Index(c),travel=from[k];if(travel<0||travel>skill.horizon)continue;int nearest=fields.Min(f=>f[k]<0?999:f[k]),degree=Degree(c);double score=nearest*1000-travel*7+degree*35-(degree<=1&&travel>0?2600:0);candidates.Add((c,travel,degree,score));}
   if(candidates.Count==0)return Nearest(p.Cell.x,p.Cell.y);candidates=candidates.OrderByDescending(c=>c.score).ThenBy(c=>c.travel).ToList();var chosen=candidates[0];
   if(skill.error>0&&candidates.Count>1&&w.Random()<skill.error){var top=candidates.Where(c=>c.score>=candidates[0].score-1800&&c.degree>1).Take(4).ToList();int n=(int)(w.Random()*top.Count);if(top.Count>0)chosen=top[n];}
   a.escapeTarget=chosen.c;a.escapeUntil=t+Math.Max(420,skill.rethink*1.15);return a.escapeTarget;
  }
  double EscapeDistance(Vector2Int c,AllyDirective d,NativePlayer p,double t){var skill=d?.skill??Skill;return (d?.threats??new List<NativePlayer>()).Where(o=>!o.Dead&&o.Lives>0&&w.CanEatPlayer(o,p,t)).Select(o=>OpponentDistance(c,o,skill.prediction)).DefaultIfEmpty(Inf).Min();}
  AllyObjective EscapeSnake(NativePlayer p,double t,AllyDirective directive){
   var skill=directive?.skill??Skill;if(directive?.bite!=true||w.Snakes.Count==0)return null;var escape=EscapeTarget(p,t,directive);if(!escape.HasValue)return null;
   double direct=Distance(p.Cell,escape.Value),current=EscapeDistance(p.Cell,directive,p,t);var list=new List<AllyObjective>();
   void Consider(NativeGameplaySnake s,int i,string kind){
    if(s.Body.Count==0||kind=="split"&&!directive.split||kind=="split"&&directive.urgent&&w.AiDifficulty<3)return;
    var target=s.Body[i];double coarse=Distance(p.Cell,target),on=Distance(target,escape.Value);if(!Finite(coarse)||!Finite(on)||coarse>skill.range||Math.Max(0,coarse+on-direct)>skill.detour+2)return;
    var o=new AllyObjective{type=kind=="split"?"escape-route-split":"escape-route-tail",target=target,snake=s,kind=kind,bodyIndex=i};var f=ObjectiveField(o);int route=f[w.Index(p.Cell)];if(route<0||route>skill.range)return;
    double onward=Distance(target,escape.Value);if(!Finite(onward)||!Finite(direct))return;double detour=Math.Max(0,route+onward-direct);bool committed=s==S(p).locked&&S(p).bitten;if(detour>skill.detour+(committed?2:0))return;
    double threat=EscapeDistance(target,directive,p,t);if(Finite(current)&&threat+skill.slack<current)return;
    bool safe=Legal(p,t).Any(d=>f[w.Index(p.Cell+d)]>=0&&f[w.Index(p.Cell+d)]<route&&Collision(p,d,p.Cell+d,t,o)<100000&&Danger(p,d,p.Cell+d,t)<105);if(route>0&&!safe)return;
    o.score=detour*24+route-threat*.35+(kind=="split"?(w.AiDifficulty>=3?-2:3):0)-(committed?40:0);list.Add(o);
   }
   foreach(var s in w.Snakes){if(s.Body.Count>1)Consider(s,s.Body.Count-1,"tail");if(s.Body.Count>=3)foreach(int i in Splits(s).Take(w.AiDifficulty>=3?2:1))Consider(s,i,"split");}return list.OrderBy(o=>o.score).FirstOrDefault();
  }
  bool FollowEscape(NativePlayer p,double t,List<Vector2Int> options,AllyDirective directive){
   var skill=directive?.skill??Skill;var threats=(directive?.threats??Others(p).ToList()).Where(o=>!o.Dead&&o.Lives>0&&w.CanEatPlayer(o,p,t)).ToList();if(threats.Count==0)return false;
   var escape=EscapeTarget(p,t,directive);var f=escape.HasValue?Field(escape.Value):null;var measured=new List<Step>();
   foreach(var d in options){var c=p.Cell+d;var s=new Step{d=d,c=c,collision=Collision(p,d,c,t),danger=Danger(p,d,c,t),threat=threats.Min(o=>OpponentDistance(c,o,skill.prediction)),cul=CulDeSac(p,c,null),reverse=d==-p.Dir,distance=f==null?Inf:f[w.Index(c)]};
    s.score=(s.collision>=100000?1000000000.0:0)+(s.danger>=105?800000000:0)+(!Finite(s.distance)||s.distance<0?400000000:0)+(s.cul?180000:0)+s.danger*180+s.collision+s.distance*420+(s.reverse?900:0)-Math.Min(200,s.threat)*70;measured.Add(s);}
   measured=measured.OrderBy(s=>s.score).ToList();if(measured.Count==0)return false;var choice=measured[0];var alternatives=measured.Where(s=>s.collision<100000&&s.danger<105).ToList();
   if(skill.error>0&&alternatives.Count>1&&w.Random()<skill.error){int upper=Math.Min(alternatives.Count-1,skill.error>.3?2:1);choice=alternatives[1+(int)(w.Random()*upper)];}
   Choose(p,choice.d,t);Thought(p,"central-escape-opponent",directive.target.Cell,choice.danger,choice.score);return true;
  }
  bool Roam(NativePlayer p,double t,List<Vector2Int> options){
   if(!w.Competitive||options.Count==0)return false;var a=S(p);if(a.roamObserved!=p.Cell){a.roamVisits.TryGetValue(p.Cell,out var v);a.roamVisits[p.Cell]=(v.count+1,t);a.roamObserved=p.Cell;}
   foreach(var c in a.roamVisits.Keys.ToArray())if(t-a.roamVisits[c].time>45000)a.roamVisits.Remove(c);
   var measured=options.Select(d=>{var c=p.Cell+d;a.roamVisits.TryGetValue(c,out var v);return new Step{d=d,c=c,collision=Collision(p,d,c,t),danger=Danger(p,d,c,t),reverse=d==-p.Dir,forward=d==p.Dir,exits=dirs.Count(n=>c+n==p.Cell||w.Floor(c+n)&&!w.SolidEgg(c+n)&&SafeRoute(p,c+n,t)),visits=v.count,tie=((c.x*17+c.y*31+p.Id*13+(d.x+1)*7+(d.y+1)*11)%19)/19.0};}).ToList();
   var safe=measured.Where(s=>s.collision<100000&&s.danger<105).ToList();var nonReverse=safe.Where(s=>!s.reverse).ToList();var candidates=nonReverse.Count>0?nonReverse:safe.Count>0?safe:measured;
   var choice=candidates.OrderBy(s=>(s.collision>=100000?1000000000:0)+(s.danger>=105?900000000:0)+(s.exits<=1?180000:0)+s.danger*300+s.collision+s.visits*900-(s.forward?18:0)+s.tie).First();
   Choose(p,choice.d,t);Thought(p,"coherent-vs-roam",choice.c,choice.danger);return true;
  }
 }
}


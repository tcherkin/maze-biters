using Screen = UnityEngine.Device.Screen;
using System;
using System.IO;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Profiling;
using Process=System.Diagnostics.Process;
namespace MazeBiters.NativeStudy {
 // ANIMATION MIGRATION SLICE, not the complete game. Enemy simulation,
 // live contacts, remaining effects and lighting remain parity gates.
 public sealed class NativeLevelStudy:MonoBehaviour {
  // Browser/game grid has positive Y DOWN, unlike Unity's world coordinates.
  public static readonly Vector2Int[] Directions={new Vector2Int(1,0),new Vector2Int(0,1),new Vector2Int(-1,0),new Vector2Int(0,-1)};
  public static readonly string[] DirectionNames={"right","down","left","up"};
  LevelData level;PackedArt art;Camera sceneCamera;RenderTexture target;Mesh quad;Texture2D mazeTexture;Material mazeMaterial;NativeDusk dusk;
  NativeTurnBank turns;NativeTurnActor playerTurn;NativeTurnClock turnClock=new NativeTurnClock();NativeSnakeStudy snakeStudy;NativeTurnGallery gallery;bool animationValidate,snakeValidate;bool slowMotion;
  NativeNeon neon;bool neonValidate,captureNeon,legacyWalls;int captureIndex;MeshRenderer playerRenderer;MaterialPropertyBlock properties=new MaterialPropertyBlock();readonly Material[,] playerMaterials=new Material[3,4];
  Vector2Int cell,from,desired;int direction=1,palette;double clock,started=-1e6,lastMove,biteAt=-1e6,biteInitial;
  bool moving,startedPlaying,paused,showHelp=true;string quality="hd",reportFile;BlinkClock blink=new BlinkClock(0xB17E2026,900);
  string[] palettes={"p1","p2","ai","h1","h3","h4"};bool smoke,validate;int smokeFrames;double cpuBegin;long peakWorking;bool finishing;
  readonly List<double> frameTimes=new List<double>(1200);double lastFrame;GUIStyle label;
  bool comparison,exportComparison,captureComparison,uncapped,waitForFocus;BenchTrace bench;int benchIndex;double benchStart,benchCpu,benchLast;bool benchFocused=true;readonly List<double> benchFrames=new List<double>(),benchSubmit=new List<double>();NativeTurnActor[] benchActors;
  [RuntimeInitializeOnLoadMethod(RuntimeInitializeLoadType.AfterSceneLoad)]static void Boot(){
#if UNITY_WEBGL && !UNITY_EDITOR
   new GameObject("Web loading").AddComponent<WebBootstrap>();return;
#endif
var args=Environment.GetCommandLineArgs();if(Array.IndexOf(args,"--snake-surface-probe")>=0)new GameObject("Snake surface capacity validation").AddComponent<NativeSnakeSurfaceValidation>();else if(Array.IndexOf(args,"--record-residency-probe")>=0)new GameObject("Record artwork residency").AddComponent<NativeRecordResidencyValidation>();else if(Array.IndexOf(args,"--glass-artwork-probe")>=0)new GameObject("Native glass artwork parity").AddComponent<NativeGlassArtworkValidation>();else if(Array.IndexOf(args,"--controller-probe")>=0)new GameObject("Controller validation").AddComponent<NativeGamepadValidation>();else if(Array.IndexOf(args,"--leader-aura")>=0||Array.IndexOf(args,"--leader-aura-motion")>=0||Array.IndexOf(args,"--leader-aura-turn")>=0)new GameObject("Leader aura art validation").AddComponent<NativeLeaderAuraStudy>();else if(Array.IndexOf(args,"--validate-records")>=0)new GameObject("Records parity").AddComponent<NativeRecordValidation>();else if(Array.IndexOf(args,"--records-smoke")>=0)new GameObject("Records lifecycle").AddComponent<NativeMenu>();else if(Array.IndexOf(args,"--validate-menu")>=0)new GameObject("Original menu parity").AddComponent<NativeMenuValidation>();else if(Array.IndexOf(args,"--menu")>=0||Array.IndexOf(args,"--menu-smoke")>=0)new GameObject("Original title menu").AddComponent<NativeMenu>();else if(Array.IndexOf(args,"--validate-hud")>=0)new GameObject("Original HUD parity").AddComponent<NativeHudValidation>();else if(Array.IndexOf(args,"--validate-maze-preparation")>=0)new GameObject("Maze preparation parity").AddComponent<MazePreparationValidation>();else if(Array.IndexOf(args,"--validate-generation")>=0)new GameObject("Generated maze parity").AddComponent<MazeArtworkValidation>();else if(Array.IndexOf(args,"--validate-session")>=0)new GameObject("Session parity").AddComponent<SessionVisualValidation>();else if(Array.IndexOf(args,"--validate-lifecycle")>=0)new GameObject("Lifecycle parity").AddComponent<LifecycleVisualValidation>();else if(Array.IndexOf(args,"--validate-pickups")>=0)new GameObject("Pickup parity").AddComponent<PickupValidation>();else if(Array.IndexOf(args,"--validate-hunter-neon")>=0)new GameObject("Hunter neon parity").AddComponent<HunterNeonValidation>();else if(Array.IndexOf(args,"--validate-intake-scorpion")>=0)new GameObject("Intake and scorpion parity").AddComponent<IntakeScorpionValidation>();else if(Array.IndexOf(args,"--lifecycle-smoke")>=0||Array.IndexOf(args,"--pickup-smoke")>=0||Array.IndexOf(args,"--gameplay-intake")>=0||Array.IndexOf(args,"--gameplay")>=0||Array.IndexOf(args,"--gameplay-smoke")>=0)new GameObject("Native gameplay study").AddComponent<NativeGameplayStudy>();else if(IpadPresentation.DefaultMenu||args.Length==1)new GameObject("Original title menu").AddComponent<NativeMenu>();else new GameObject("Native level study").AddComponent<NativeLevelStudy>();}
  void Start(){
   var args=Environment.GetCommandLineArgs();for(int i=0;i<args.Length;i++){
    if(args[i]=="--quality"&&i+1<args.Length)quality=args[++i].ToLowerInvariant();
    if(args[i]=="--smoke")smoke=true;
    if(args[i]=="--validate")validate=true;
    if(args[i]=="--validate-animation")animationValidate=true;
    if(args[i]=="--validate-snakes")snakeValidate=true;
    if(args[i]=="--validate-neon")neonValidate=true;
    if(args[i]=="--capture-neon")captureNeon=true;
    if(args[i]=="--legacy-wall-receiver")legacyWalls=true;
    if(args[i]=="--comparison")comparison=true;
    if(args[i]=="--baseline-renderer")RendererTuning.Optimized=false;
    if(args[i]=="--profile-renderer")RenderProfile.Enabled=true;
    if(args[i]=="--uncapped")uncapped=true;
    if(args[i]=="--wait-for-focus")waitForFocus=true;
    if(args[i]=="--export-comparison")exportComparison=true;
    if(args[i]=="--capture-comparison")captureComparison=true;
    if(args[i]=="--report"&&i+1<args.Length)reportFile=args[++i];
   }
   if(quality!="hd"&&quality!="4k")throw new ArgumentException("Quality must be HD or 4K");
   if(!smoke&&!validate)Screen.SetResolution(1440,1080,FullScreenMode.Windowed);
   Application.runInBackground=true;QualitySettings.vSyncCount=0;Application.targetFrameRate=uncapped?-1:120;
   // The approved WebGL textures use LINEAR only. Unity's quality preset
   // must not silently force anisotropic filtering onto a distorted turn UV.
   QualitySettings.anisotropicFiltering=AnisotropicFiltering.Disable;
   level=JsonUtility.FromJson<LevelData>(File.ReadAllText(Path.Combine(WebFiles.Root,"Reference/level.json")));
   if(level.columns!=36||level.rows!=25||level.tile!=16)throw new InvalidDataException("Wrong level fixture");
   quad=new Mesh {name="Shared quad"};quad.vertices=new[]{new Vector3(0,0),new Vector3(1,0),new Vector3(1,-1),new Vector3(0,-1)};
   quad.uv=new[]{new Vector2(0,1),new Vector2(1,1),new Vector2(1,0),new Vector2(0,0)};quad.triangles=new[]{0,1,2,0,2,3};quad.RecalculateBounds();
   sceneCamera=new GameObject("Native orthographic camera").AddComponent<Camera>();sceneCamera.enabled=false;sceneCamera.orthographic=true;sceneCamera.orthographicSize=216;
   sceneCamera.transform.position=new Vector3(288,-184,-10);sceneCamera.clearFlags=CameraClearFlags.SolidColor;sceneCamera.backgroundColor=Color.black;sceneCamera.allowHDR=false;sceneCamera.allowMSAA=true;
   sceneCamera.cullingMask&=~(1<<28);
   mazeTexture=new Texture2D(2,2,TextureFormat.RGBA32,false,false){filterMode=FilterMode.Bilinear,wrapMode=TextureWrapMode.Clamp};
   if(!mazeTexture.LoadImage(File.ReadAllBytes(Path.Combine(WebFiles.Root,"Reference/maze.png")),true))throw new IOException("Maze fixture decode failed");
   mazeMaterial=new Material(Shader.Find("MazeBiters/ExactImage")){mainTexture=mazeTexture};
   var maze=MakeQuad("Exact original level cache",mazeMaterial);maze.transform.localScale=new Vector3(576,400,1);
   playerRenderer=MakeQuad("Native player",null);playerRenderer.sortingOrder=10;playerRenderer.transform.localScale=new Vector3(16,16,1);
   SetQuality(quality);ResetPlayer();lastFrame=Time.realtimeSinceStartupAsDouble;cpuBegin=Process.GetCurrentProcess().TotalProcessorTime.TotalMilliseconds;
   dusk=new NativeDusk(quad,sceneCamera);
   if(!animationValidate&&!validate&&!snakeValidate&&!neonValidate){snakeStudy=new NativeSnakeStudy(sceneCamera,level);neon=new NativeNeon(level.geometry,quad,dusk,legacyWalls,snakeStudy.Snakes);}
   if(neonValidate){var passed=NeonValidation.Run(quality,level.geometry,reportFile);finishing=true;Application.Quit(passed?0:2);}
   if(snakeValidate){var passed=AnimationValidation.Snakes(quality,reportFile);finishing=true;Application.Quit(passed?0:2);}
   if(animationValidate){var passed=AnimationValidation.Turns(quality,art,quad,reportFile);finishing=true;Application.Quit(passed?0:2);}
   if(validate){var output=reportFile??Path.Combine(Application.persistentDataPath,"pose-"+quality+".json");Directory.CreateDirectory(Path.GetDirectoryName(Path.GetFullPath(output)));var passed=PoseValidation.Run(quality,quad,output);var light=dusk.Validate();File.WriteAllText(Path.ChangeExtension(output,"lighting.json"),light);passed&=JsonUtility.FromJson<LightResult>(light).passed;finishing=true;Application.Quit(passed?0:2);}
   Debug.Log("Native study ready; parity gate OPEN. No browser or JavaScript runtime embedded.");
   if(exportComparison){SceneBenchmark.Export(snakeStudy,reportFile);finishing=true;Application.Quit();}
   if(comparison||captureComparison){bench=JsonUtility.FromJson<BenchTrace>(File.ReadAllText(Path.Combine(WebFiles.Root,"Reference/benchmark-trace.json")));benchActors=new NativeTurnActor[6];for(int i=0;i<6;i++)benchActors[i]=new NativeTurnActor(turns,i<3?"fantasy":"dragon",palettes[i]);showHelp=false;}
  }
  MeshRenderer MakeQuad(string name,Material material){var go=new GameObject(name);go.AddComponent<MeshFilter>().sharedMesh=quad;var r=go.AddComponent<MeshRenderer>();r.sharedMaterial=material;return r;}
  void ResetPlayer(){cell=from=new Vector2Int(level.players[0].x,level.players[0].y);desired=Directions[1];direction=1;moving=startedPlaying=false;clock=lastMove=0;started=biteAt=-1e6;blink=new BlinkClock(0xB17E2026,900);turnClock.Reset();}
  public bool Floor(Vector2Int p)=>p.x>=0&&p.y>=0&&p.x<level.columns&&p.y<level.rows&&level.geometry[p.y][p.x]!='#';
  void SetQuality(string value){
   quality=value;bool showGallery=gallery?.Visible??false;gallery?.Dispose();playerTurn?.Dispose();turns?.Dispose();art?.Dispose();art=new PackedArt(quality);turns=new NativeTurnBank(quality,art,quad);playerTurn=new NativeTurnActor(turns,palette<3?"fantasy":"dragon",palettes[palette]);gallery=new NativeTurnGallery(turns,quad){Visible=showGallery};
   for(int p=0;p<3;p++)for(int d=0;d<4;d++)playerMaterials[p,d]=art.materials["fantasy-biters:"+palettes[p]+":"+DirectionNames[d]];
   if(target){sceneCamera.targetTexture=null;target.Release();Destroy(target);}
   int height=quality=="4k"?2160:1080;target=new RenderTexture(height*4/3,height,0,RenderTextureFormat.ARGB32,RenderTextureReadWrite.Default){name="Native "+quality.ToUpperInvariant()+" backing",antiAliasing=1,filterMode=FilterMode.Bilinear};
   target.Create();sceneCamera.targetTexture=target;sceneCamera.aspect=4f/3;
   // Keep borrowed emission geometry and the eye-glint clock alive on F2.
   // Only the lit snakes' pixel-density-dependent scratch targets change.
   if(snakeStudy!=null){if(RendererTuning.Optimized)snakeStudy.ResetSurfaces();else {int length=snakeStudy.Count;snakeStudy.Dispose();snakeStudy=new NativeSnakeStudy(sceneCamera,level);while(snakeStudy.Count!=length)snakeStudy.CycleLength();}}
  }
  void Update(){
   if(level==null||finishing)return;
   if(comparison||captureComparison){RunComparison();return;}
   if(Input.GetKeyDown(KeyCode.Escape))Application.Quit();
   if(Input.GetKeyDown(KeyCode.F1))showHelp=!showHelp;
   if(Input.GetKeyDown(KeyCode.F2))SetQuality(quality=="hd"?"4k":"hd");
   if(Input.GetKeyDown(KeyCode.F3)){palette=(palette+1)%6;playerTurn.Dispose();playerTurn=new NativeTurnActor(turns,palette<3?"fantasy":"dragon",palettes[palette]);}
   if(Input.GetKeyDown(KeyCode.F4))slowMotion=!slowMotion;
   if(Input.GetKeyDown(KeyCode.F5))snakeStudy?.CycleLength();
   if(Input.GetKeyDown(KeyCode.F6))gallery.Visible=!gallery.Visible;
   if(Input.GetKeyDown(KeyCode.F7)&&neon!=null)neon.Enabled=!neon.Enabled;
   if(Input.GetKeyDown(KeyCode.P))paused=!paused;
   if(Input.GetKeyDown(KeyCode.R))ResetPlayer();
   // Original cardinal keys, buffered until a legal cell transition.
   if(Input.GetKeyDown(KeyCode.RightArrow)||Input.GetKeyDown(KeyCode.D))Request(0);
   if(Input.GetKeyDown(KeyCode.DownArrow)||Input.GetKeyDown(KeyCode.S))Request(1);
   if(Input.GetKeyDown(KeyCode.LeftArrow)||Input.GetKeyDown(KeyCode.A))Request(2);
   if(Input.GetKeyDown(KeyCode.UpArrow)||Input.GetKeyDown(KeyCode.W))Request(3);
   if(!paused)clock+=Math.Min(250,Time.unscaledDeltaTime*1000)*(slowMotion?.15:1);
   if(captureNeon){clock=new[]{0.0,1200,4000}[captureIndex];direction=captureIndex;cell=from=new Vector2Int(5,1);moving=startedPlaying=false;}
   if(smoke){smokeFrames++;if(smokeFrames%90==1){desired=Directions[(smokeFrames/90)%4];startedPlaying=true;}if(smokeFrames%150==1)palette=(palette+1)%3;}
   if(startedPlaying&&clock-lastMove>level.playerStepMs){
    from=cell;if(Floor(cell+desired)){int next=Array.IndexOf(Directions,desired);if(next!=direction)turnClock.Request(direction,next,clock);direction=next;cell+=desired;}
    else if(Floor(cell+Directions[direction]))cell+=Directions[direction];
    moving=cell!=from;started=clock;lastMove=clock;
   }
   double phase=AnimationClock.Clamp((clock-started)/level.playerStepMs);
   var pos=Vector2.Lerp(from,cell,(float)phase);playerRenderer.transform.position=new Vector3(pos.x*16,-pos.y*16,-1);
   double walking=AnimationClock.Mouth(clock-started,level.playerStepMs,moving?1:0);
   // Diagnostic trigger only, explicitly not a substitute for native collision events.
   if(Input.GetKeyDown(KeyCode.B)){biteAt=clock;biteInitial=walking;}
   double mouth=AnimationClock.Bite(clock,biteAt,biteAt+140,biteInitial,walking);
   playerTurn.Palette=palettes[palette];turns.Render(playerTurn,turnClock.Sample(clock,direction),AnimationClock.Frame(mouth,48),AnimationClock.Frame(blink.Sample(clock),24));playerRenderer.sharedMaterial=playerTurn.Display;playerRenderer.SetPropertyBlock(null);
   dusk.Render(pos,Directions[direction],Time.unscaledDeltaTime*1000,paused,captureNeon);
   snakeStudy?.Update(clock);
   if(neon!=null&&snakeStudy!=null)neon.Render(snakeStudy.Snakes,snakeStudy.Poses,playerTurn.Display,playerRenderer.transform.localToWorldMatrix,clock,!captureNeon);
   gallery.Update(clock);
   // Render explicitly after all offscreen compositors. This also keeps
   // hidden-window smoke captures real instead of accepting a cleared frame.
   sceneCamera.Render();
   if(captureNeon){NeonSceneCapture.Save(quality,reportFile,captureIndex,clock,target,snakeStudy,pos,direction,AnimationClock.Frame(mouth,48),AnimationClock.Frame(blink.Sample(clock),24),dusk.Angle);if(++captureIndex>=3){finishing=true;Application.Quit();}return;}
   double real=Time.realtimeSinceStartupAsDouble;
   if(smokeFrames>120&&smoke)frameTimes.Add((real-lastFrame)*1000);lastFrame=real;
   if(smoke&&smokeFrames%60==0&&NativeMemory.TryRead(out var ws,out var peak,out _))peakWorking=Math.Max(peakWorking,peak);
   if(smoke&&smokeFrames>=840){finishing=true;StartCoroutine(FinishSmoke());}
  }
  void Request(int d){desired=Directions[d];startedPlaying=true;}
  void RunComparison(){
   if(waitForFocus&&benchIndex==0&&!Application.isFocused)return;
   double begin=Time.realtimeSinceStartupAsDouble;int count=bench.frames.Length,index=benchIndex%count;var f=bench.frames[index];
   if(benchIndex==count){benchStart=benchLast=begin;benchCpu=Process.GetCurrentProcess().TotalProcessorTime.TotalMilliseconds;}
   if(benchIndex>count)benchFrames.Add((begin-benchLast)*1000);benchLast=begin;
   RenderProfile.Begin(benchIndex>=count);long stamp=RenderProfile.Stamp();
   var actor=benchActors[f.palette];turns.Render(actor,f.turn,f.mouth,f.blink);playerRenderer.sharedMaterial=actor.Display;playerRenderer.transform.position=new Vector3(f.player.x*16,-f.player.y*16,-1);playerRenderer.SetPropertyBlock(null);RenderProfile.Add("Character",stamp);
   stamp=RenderProfile.Stamp();dusk.Render(f.player,new Vector2((float)Math.Cos(f.lightAngle),(float)Math.Sin(f.lightAngle)),bench.stepMs,false,true);RenderProfile.Add("Dusk",stamp);
   stamp=RenderProfile.Stamp();snakeStudy.Apply(f);RenderProfile.Add("Snake geometry",stamp);
   neon.Render(snakeStudy.Snakes,snakeStudy.Poses,actor.Display,playerRenderer.transform.localToWorldMatrix,f.time,true);
   stamp=RenderProfile.Stamp();sceneCamera.Render();RenderProfile.Camera();RenderProfile.Add("Scene submission",stamp);RenderProfile.End();
   if(benchIndex>=count){benchSubmit.Add((Time.realtimeSinceStartupAsDouble-begin)*1000);benchFocused&=Application.isFocused;}
   if(captureComparison&&Array.IndexOf(new[]{108,244,492,732,972,1212},index)>=0){Directory.CreateDirectory(reportFile);var prev=RenderTexture.active;RenderTexture.active=target;var tex=new Texture2D(target.width,target.height,TextureFormat.RGBA32,false);tex.ReadPixels(new Rect(0,0,target.width,target.height),0,0);tex.Apply();File.WriteAllBytes(Path.Combine(reportFile,"unity-"+quality+"-"+index+".png"),tex.EncodeToPNG());Destroy(tex);RenderTexture.active=prev;}
   benchIndex++;
   if(captureComparison&&benchIndex>=count){finishing=true;Application.Quit();}
   if(comparison&&benchIndex>=count*2){
    NativeMemory.TryRead(out var ws,out var peak,out var committed);var result=new BenchResult{quality=quality,device=SystemInfo.graphicsDeviceName,frames=count,width=target.width,height=target.height,elapsedMs=(Time.realtimeSinceStartupAsDouble-benchStart)*1000,cpuProcessMs=Process.GetCurrentProcess().TotalProcessorTime.TotalMilliseconds-benchCpu,workingSetBytes=ws,privateCommittedBytes=committed,peakWorkingSetBytes=peak,managedBytes=GC.GetTotalMemory(false),textureBytes=art.TextureBytes+turns.TextureBytes+snakeStudy.TextureBytes+neon.TextureBytes+((long)mazeTexture.width*mazeTexture.height+256*256+512*384)*4,targetBytes=((long)target.width*target.height+576*400+13*3*turns.Size*turns.Size)*4+snakeStudy.SurfaceBytes+neon.TargetBytes,focused=benchFocused,frameMs=benchFrames.ToArray(),submitMs=benchSubmit.ToArray(),note="Matched renderer workload, shared numeric poses. 1440-frame full warmup + 1440 measured frames, 120 FPS target. Submit time excludes asynchronous GPU completion; process CPU includes Unity threads. Texture ledger is not VRAM."};
    result.rendererMode=RendererTuning.Optimized?"optimized":"baseline";result.profile=RenderProfile.Enabled?RenderProfile.Result():null;if(uncapped)result.note=result.note.Replace("120 FPS target","uncapped target");
    Directory.CreateDirectory(Path.GetDirectoryName(Path.GetFullPath(reportFile)));File.WriteAllText(reportFile,JsonUtility.ToJson(result));finishing=true;Application.Quit();
   }
  }
  IEnumerator FinishSmoke(){
   yield return new WaitForEndOfFrame();
   var output=reportFile??Path.Combine(Application.persistentDataPath,"smoke-"+quality+".json");Directory.CreateDirectory(Path.GetDirectoryName(Path.GetFullPath(output)));
   bool memoryAvailable=NativeMemory.TryRead(out var working,out var peakBytes,out var committed);
   var report=new SmokeReport {quality=quality,width=target.width,height=target.height,frames=smokeFrames,parityComplete=false,memoryAvailable=memoryAvailable,
    cpuProcessMs=Process.GetCurrentProcess().TotalProcessorTime.TotalMilliseconds-cpuBegin,workingSetBytes=working,peakWorkingSetBytes=memoryAvailable?Math.Max(peakWorking,peakBytes):-1,privateCommittedBytes=committed,
    unityAllocatedBytes=Profiler.GetTotalAllocatedMemoryLong(),managedBytes=GC.GetTotalMemory(false),textureRgbaBytes=art.TextureBytes+turns.TextureBytes+(snakeStudy?.TextureBytes??0)+(neon?.TextureBytes??0)+((long)mazeTexture.width*mazeTexture.height+256*256+512*384)*4,
    targetRgbaBytes=((long)target.width*target.height+576*400+7*3*turns.Size*turns.Size)*4+(snakeStudy?.SurfaceBytes??0)+(neon?.TargetBytes??0),depthStencilEstimateBytes=0,turnMeshBytes=turns.MeshBytes,frameMs=frameTimes.ToArray(),device=SystemInfo.graphicsDeviceName,api=SystemInfo.graphicsDeviceType.ToString(),
    note="FUNCTIONAL SMOKE ONLY. Turns, five snakes, original neon materials, world light fields and DUSK. Missing full simulation and interactions. Do NOT compare timings with complete browser. Resource capacity ledger, not driver VRAM."};
   var previous=RenderTexture.active;RenderTexture.active=target;var image=new Texture2D(target.width,target.height,TextureFormat.RGBA32,false);
   image.ReadPixels(new Rect(0,0,target.width,target.height),0,0);image.Apply();var pixels=image.GetPixels32();int lit=0;foreach(var pixel in pixels)if(pixel.r+pixel.g+pixel.b>15)lit++;report.nonBlankFrame=lit>pixels.Length/100;File.WriteAllBytes(Path.ChangeExtension(output,".png"),image.EncodeToPNG());File.WriteAllText(output,JsonUtility.ToJson(report,true));Destroy(image);RenderTexture.active=previous;
   Debug.Log("Smoke report: "+output);Application.Quit(report.nonBlankFrame?0:2);
  }
  void OnGUI(){
   if(!target)return;
   var h=Math.Min(Screen.height,Screen.width*.75f);var w=h*4/3;var rect=new Rect((Screen.width-w)/2,(Screen.height-h)/2,w,h);
   GUI.DrawTexture(rect,target,ScaleMode.StretchToFill,false);
   if(comparison||captureComparison)return;
   if(label==null)label=new GUIStyle(GUI.skin.label){normal={textColor=new Color(.75f,.92f,1)}};
   float ui=Math.Max(1,Screen.height/900f);label.fontSize=Mathf.RoundToInt(16*ui);
   GUI.Label(new Rect(rect.x+10*ui,rect.y+5*ui,w-20*ui,24*ui),"UNITY • LIGHTING STUDY • "+quality.ToUpperInvariant()+" • "+palettes[palette]+" • "+(slowMotion?"SLOW MOTION":"90 ms turns"),label);
   if(gallery?.Visible??false)GUI.Label(new Rect(rect.x+10*ui,rect.y+29*ui,w-20*ui,24*ui),"ALL 6 • "+gallery.Caption+" • F4 slow / F6 return",label);
   if(showHelp){GUI.Box(new Rect(10*ui,Screen.height-96*ui,Math.Min(850*ui,Screen.width-20*ui),86*ui),"");GUI.Label(new Rect(20*ui,Screen.height-92*ui,830*ui,80*ui),"Arrows/WASD: move   F2: HD/4K   F3: six characters   F4: slow   F5: snake length\nF6: ALL TURNS   F7: light layers on/off   B: bite   P: pause   R: reset\nOriginal 70% inner / 50% body spill / 40% wall reflections; no fog or overhead lights.\nStudy routes only; complete AI, contacts and consumption still pending.",label);}
  }
  void OnDestroy(){RenderTexture.active=null;if(sceneCamera)sceneCamera.targetTexture=null;if(benchActors!=null)foreach(var a in benchActors)a?.Dispose();neon?.Dispose();snakeStudy?.Dispose();dusk?.Dispose();gallery?.Dispose();playerTurn?.Dispose();turns?.Dispose();art?.Dispose();if(target){target.Release();Destroy(target);}if(mazeTexture)Destroy(mazeTexture);if(mazeMaterial)Destroy(mazeMaterial);if(quad)Destroy(quad);}
 }
 [Serializable]public class SmokeReport {public string quality,device,api,note;public int width,height,frames;public bool parityComplete,memoryAvailable,nonBlankFrame;public double cpuProcessMs;public long workingSetBytes,peakWorkingSetBytes,privateCommittedBytes,unityAllocatedBytes,managedBytes,textureRgbaBytes,targetRgbaBytes,depthStencilEstimateBytes,turnMeshBytes;public double[] frameMs;}
}

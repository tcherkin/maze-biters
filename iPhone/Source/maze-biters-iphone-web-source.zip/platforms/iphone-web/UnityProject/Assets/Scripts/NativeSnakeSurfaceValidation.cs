using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using UnityEngine;
using UnityEngine.Rendering;

namespace MazeBiters.NativeStudy {
 public sealed class NativeSnakeSurfaceValidation:MonoBehaviour {
  [Serializable] public sealed class Case {public string quality,treatment;public bool tailOnly,passed,strictTwoBytePassed;public int frames,imageChecks,maxChannelError,pixelsBeyondTwo,legacyAllocations,boundedAllocations,shrinks,delayedShrinkChecks,worstFrame,worstX,worstY;public long comparedPixels,legacyPeakBytes,boundedPeakBytes,legacyFinalBytes,boundedFinalBytes;public double meanChannelError,fractionPixelsBeyondTwo;}
  [Serializable] public sealed class Result {public bool passed;public string error,device,api,note;public int policyChecks;public Case[] cases;}
  Result result;readonly List<Case> results=new List<Case>();string folder,report;
  IEnumerator Start(){
   var args=Environment.GetCommandLineArgs();int at=Array.IndexOf(args,"--report");report=at>=0?Path.GetFullPath(args[at+1]):Path.Combine(Application.persistentDataPath,"snake-surfaces.json");folder=Path.GetDirectoryName(report);Directory.CreateDirectory(folder);
   Application.runInBackground=true;Application.targetFrameRate=120;QualitySettings.vSyncCount=0;
   result=new Result{device=SystemInfo.graphicsDeviceName,api=SystemInfo.graphicsDeviceType.ToString(),note="Actual GPU A/B with identical original poses, shaders, native texel density and4xMSAA. Continuous long-snake grid turns, changing mouth phase, bent intake tail, solo head, lit and glow. Capacity changes can alter float UV raster rounding: explicit gate max8/255, at most1 pixel per million beyond2/255, mean<=.001/255; strict2-byte result is separate. Capacity bytes are the nominal MSAA+resolve ledger, not process RAM. No FPS claim; allocation counts are reported."};
   using(var run=Run()){while(true){bool more=false;try{more=run.MoveNext();}catch(Exception e){result.error=e.ToString();Debug.LogException(e);break;}if(!more){result.passed=true;break;}yield return run.Current;}}
   result.cases=results.ToArray();File.WriteAllText(report,JsonUtility.ToJson(result,true));Debug.Log("SNAKE_SURFACE_VALIDATION "+JsonUtility.ToJson(result));
#if !UNITY_EDITOR
   Application.Quit(result.passed?0:2);
#endif
  }
  void Check(bool condition,string label){result.policyChecks++;if(!condition)throw new InvalidOperationException(label);}
  IEnumerator<object> Run(){
   var policy=new NativeSnakeSurfaceSizing();bool shrunk;var first=policy.Choose(0,0,1500,60,1500,60,2868,1320,0,out shrunk);var turned=policy.Choose(first.x,first.y,60,1300,60,1300,2868,1320,.1,out shrunk);
   Check(turned.x<first.x/4&&turned.y>=1300,"Growth replaces both historical dimensions");
   var stay=policy.Choose(1504,1312,60,1300,60,1300,2868,1320,1,out shrunk);Check(!shrunk&&stay.x==1504,"Oversized surface is not shrunk immediately");
   stay=policy.Choose(1504,1312,60,1300,60,1300,2868,1320,1.2,out shrunk);Check(!shrunk,"Short-lived bounds do not cause shrink churn");
   stay=policy.Choose(1504,1312,60,1300,60,1300,2868,1320,1.5,out shrunk);Check(shrunk&&stay.x<200,"Stable excess capacity is retired");
   foreach(string q in new[]{"hd","4k"})foreach(string treatment in new[]{"lit","emission","original","tail"})foreach(var step in RenderCase(q,treatment))yield return step;
   Check(results.All(c=>c.passed),"Every GPU image and capacity case passed");
  }
  static List<Vector2Int> Route(){var path=new List<Vector2Int>();for(int x=6;x<=18;x++)path.Add(new Vector2Int(x,8));for(int y=9;y<=20;y++)path.Add(new Vector2Int(18,y));for(int x=17;x>=6;x--)path.Add(new Vector2Int(x,20));for(int y=19;y>=8;y--)path.Add(new Vector2Int(6,y));return path;}
  IEnumerable<object> RenderCase(string quality,string label){
   bool tail=label=="tail",emission=label=="emission";string treatment=label=="original"?null:emission?"emission":"lit";
   int width=emission?1152:quality=="4k"?2868:1434,height=emission?800:quality=="4k"?1320:660;float density=emission?2:height/432f*2.6f;
   var c=new Case{quality=quality,treatment=label,tailOnly=tail};results.Add(c);
   var before=new NativeSnake("Green",treatment,null,tail,true);var after=new NativeSnake("Green",treatment,null,tail,false);before.ReservedDensity=after.ReservedDensity=density;
   var gameObject=new GameObject("Snake capacity GPU probe");var camera=gameObject.AddComponent<Camera>();camera.enabled=false;camera.cullingMask=0;camera.orthographic=true;camera.aspect=(float)width/height;camera.orthographicSize=height/(2*density);camera.clearFlags=CameraClearFlags.SolidColor;camera.backgroundColor=new Color(8/255f,16/255f,25/255f,1);camera.allowHDR=false;camera.allowMSAA=true;
   var a=new RenderTexture(width,height,0,RenderTextureFormat.ARGB32){antiAliasing=1};var b=new RenderTexture(a.descriptor);a.Create();b.Create();
   var commands=new CommandBuffer{name="Snake surface shape A/B"};camera.AddCommandBuffer(CameraEvent.BeforeForwardAlpha,commands);Texture2D readA=null,readB=null;long sum=0;
   try{
    var path=Route();var model=new NativeGameplaySnake{Body=path.Take(13).Reverse().ToList(),Dir=Vector2Int.right};var motion=new NativeLiveSnake(model,0);SnakePose pose=null;
    for(int move=0;move<=36;move++){
     if(move>0){var old=model.Body.ToArray();model.Body=path.Skip(move).Take(13).Reverse().ToList();model.Dir=model.Body[0]-model.Body[1];motion.Record(model,old,move*218,218);}
     for(int part=0;part<4;part++){
      pose=motion.Evaluate(move*218+part*218/4.0);if(tail){pose.bendSpan=SnakeMotion.Tail;pose.bendDy=2.8*Math.Sin(move*.19);}
      Render(pose);if(part==3&&move%3==0)Compare(move,move==0||move==6||move==12);
      yield return null;
     }
    }
    // Keep the final narrow vertical pose long enough for time-based shrink.
    pose=motion.Evaluate(37*218);double until=Time.realtimeSinceStartupAsDouble+.6;
    while(Time.realtimeSinceStartupAsDouble<until){Render(pose);yield return null;}
    Compare(99,true);c.legacyFinalBytes=before.SurfaceBytes;c.boundedFinalBytes=after.SurfaceBytes;
    if(!tail){
     // A broad corner followed by a shorter stationary vertical body exercises
     // delayed shrink without a growth event replacing the wide surface first.
     model.Body=path.Skip(6).Take(13).Reverse().ToList();model.Dir=model.Body[0]-model.Body[1];Render(new NativeLiveSnake(model,0).Evaluate(1));
     model.Body=Enumerable.Range(9,7).Select(y=>new Vector2Int(12,y)).Reverse().ToList();model.Dir=Vector2Int.up;pose=new NativeLiveSnake(model,0).Evaluate(1);
     int oldShrinks=after.BodySurfaceShrinks;until=Time.realtimeSinceStartupAsDouble+.6;
     while(Time.realtimeSinceStartupAsDouble<until){Render(pose);yield return null;}
     Compare(101,false);c.delayedShrinkChecks=after.BodySurfaceShrinks>oldShrinks?1:0;
    }
    // A solo head has no body surface, but must retain its original head path.
    if(!tail){pose.solo=true;pose.soloAmount=1;pose.length=SnakeMotion.Head;Render(pose);Compare(100,false);}
    c.legacyAllocations=before.BodySurfaceAllocations;c.boundedAllocations=after.BodySurfaceAllocations;c.shrinks=after.BodySurfaceShrinks;
    c.meanChannelError=c.comparedPixels==0?0:(double)sum/(c.comparedPixels*4);c.fractionPixelsBeyondTwo=c.comparedPixels==0?0:(double)c.pixelsBeyondTwo/c.comparedPixels;c.strictTwoBytePassed=c.maxChannelError<=2;
    c.passed=c.maxChannelError<=8&&c.fractionPixelsBeyondTwo<=1e-6&&c.meanChannelError<=.001&&(tail||c.boundedFinalBytes<c.legacyFinalBytes*.35&&c.delayedShrinkChecks==1)&&c.boundedAllocations<=36;
    if(!c.passed)throw new InvalidOperationException("Snake surface case failed "+quality+"/"+label+": "+JsonUtility.ToJson(c));
    void Render(SnakePose p){
     float x=(float)model.Body.Average(cell=>(cell.x+.5)*16),y=(float)-model.Body.Average(cell=>(cell.y+.5)*16);camera.transform.position=new Vector3(x,y,-10);
     before.Prepare(p,tail);after.Prepare(p,tail);
     camera.targetTexture=a;commands.Clear();before.Submit(commands,1,camera);camera.Render();camera.targetTexture=b;commands.Clear();after.Submit(commands,1,camera);camera.Render();
     c.frames++;c.legacyPeakBytes=Math.Max(c.legacyPeakBytes,before.SurfaceBytes);c.boundedPeakBytes=Math.Max(c.boundedPeakBytes,after.SurfaceBytes);
    }
    void Compare(int step,bool save){
     if(!readA){readA=new Texture2D(width,height,TextureFormat.RGBA32,false,false);readB=new Texture2D(width,height,TextureFormat.RGBA32,false,false);}var active=RenderTexture.active;
     try{RenderTexture.active=a;readA.ReadPixels(new Rect(0,0,width,height),0,0);readA.Apply();RenderTexture.active=b;readB.ReadPixels(new Rect(0,0,width,height),0,0);readB.Apply();}finally{RenderTexture.active=active;}
     int priorWorst=c.maxChannelError;var pa=readA.GetRawTextureData<Color32>();var pb=readB.GetRawTextureData<Color32>();for(int i=0;i<pa.Length;i++){int r=Math.Abs(pa[i].r-pb[i].r),g=Math.Abs(pa[i].g-pb[i].g),blue=Math.Abs(pa[i].b-pb[i].b),alpha=Math.Abs(pa[i].a-pb[i].a),error=Math.Max(Math.Max(r,g),Math.Max(blue,alpha));sum+=r+g+blue+alpha;if(error>c.maxChannelError){c.maxChannelError=error;c.worstFrame=step;c.worstX=i%width;c.worstY=height-1-i/width;}if(error>2)c.pixelsBeyondTwo++;}
     if(c.maxChannelError>Math.Max(2,priorWorst)){File.WriteAllBytes(Path.Combine(folder,quality+"-"+label+"-worst-before.png"),readA.EncodeToPNG());File.WriteAllBytes(Path.Combine(folder,quality+"-"+label+"-worst-after.png"),readB.EncodeToPNG());}
     c.imageChecks++;c.comparedPixels+=pa.Length;if(save&&label=="lit"){File.WriteAllBytes(Path.Combine(folder,quality+"-"+step+"-before.png"),readA.EncodeToPNG());File.WriteAllBytes(Path.Combine(folder,quality+"-"+step+"-after.png"),readB.EncodeToPNG());}
    }
   }finally{camera.targetTexture=null;camera.RemoveCommandBuffer(CameraEvent.BeforeForwardAlpha,commands);commands.Dispose();before.Dispose();after.Dispose();a.Release();b.Release();foreach(var o in new UnityEngine.Object[]{a,b,readA,readB,gameObject})if(o)Destroy(o);}
   yield return null;
  }
 }
}

using System.Runtime.InteropServices;
using UnityEngine;

namespace MazeBiters.NativeStudy {
 // Browser suspension is separate from the player's explicit pause switch.
 // The JS clock records visibility events even when the Unity loop is stopped.
 [DefaultExecutionOrder(-11000)]
 public sealed class WebLifecycle:MonoBehaviour {
  static bool ownsAudioPause,savedAudioPause;
  public static bool Suspended {
   get {
#if UNITY_WEBGL && !UNITY_EDITOR
    return (MBWLifecycleState()&1)!=0;
#else
    return false;
#endif
   }
  }
  internal static int Generation {
   get {
#if UNITY_WEBGL && !UNITY_EDITOR
    return MBWLifecycleState()>>1;
#else
    return 0;
#endif
   }
  }
  public static double Realtime {
   get {
#if UNITY_WEBGL && !UNITY_EDITOR
    return MBWLifecycleSeconds();
#else
    return Time.realtimeSinceStartupAsDouble;
#endif
   }
  }
  [RuntimeInitializeOnLoadMethod(RuntimeInitializeLoadType.BeforeSceneLoad)]
  static void Install(){
#if UNITY_WEBGL && !UNITY_EDITOR
   var owner=new GameObject("Web page lifecycle");DontDestroyOnLoad(owner);owner.AddComponent<WebLifecycle>();
   ApplyAudioState();
#endif
  }
  static void ApplyAudioState(){
   if(Suspended){if(!ownsAudioPause){savedAudioPause=AudioListener.pause;ownsAudioPause=true;}AudioListener.pause=true;}
   else if(ownsAudioPause){AudioListener.pause=savedAudioPause;ownsAudioPause=false;}
  }
  void Update()=>ApplyAudioState();
  void OnApplicationFocus(bool focused)=>ApplyAudioState();
  void OnApplicationPause(bool paused)=>ApplyAudioState();
#if UNITY_WEBGL && !UNITY_EDITOR
  [DllImport("__Internal")] static extern int MBWLifecycleState();
  [DllImport("__Internal")] static extern double MBWLifecycleSeconds();
#endif
 }
 public sealed partial class NativeGameplayStudy {
  int webLifecycleGeneration;
  bool webLifecycleHeld;
  bool HoldWebLifecycle(){
#if UNITY_WEBGL && !UNITY_EDITOR
   bool hidden=WebLifecycle.Suspended;int generation=WebLifecycle.Generation;
   bool resumed=!hidden&&(webLifecycleHeld||generation!=webLifecycleGeneration);
   if(hidden||resumed){
    // A browser can omit every Update between blur and focus. The generation
    // still invalidates that first frame's elapsed time and captured fingers.
    world?.ClearAllKeys();ReleaseIpadTouch();discardPreparationDelta=true;
   }
   webLifecycleGeneration=generation;webLifecycleHeld=hidden;
   return hidden||resumed;
#else
   return false;
#endif
  }
 }
}

using System;
using UnityEngine;
using UnityEngine.Profiling;
namespace MazeBiters.NativeStudy {
 // Opt-in resource accounting, not a claim about Safari's total process RAM.
 // Regular play does not enumerate textures or sample the managed heap.
 [Serializable] sealed class WebMemorySample {
  public long menuTextureBytes,menuTargetBytes,gameSnakeSurfaceBytes,neonTargetBytes;
  public long snakeTextureBytes,turnTextureBytes,mazeTextureBytes,allocatedBytes,reservedBytes;
 }
 public sealed partial class NativeMenu {
  string WebMemoryState(){
   if(!Application.absoluteURL.Contains("diagnostic=1"))return "";
   var sample=new WebMemorySample{menuTextureBytes=renderer?.TextureBytes??0,
    menuTargetBytes=renderer?.Target?(long)renderer.Target.width*renderer.Target.height*4:0,
    snakeTextureBytes=NativeSnakeTextures.ResidentBytes,
    allocatedBytes=Profiler.GetTotalAllocatedMemoryLong(),reservedBytes=Profiler.GetTotalReservedMemoryLong()};
   if(gameplay)gameplay.AddWebMemory(sample);
   return ",\"memory\":"+JsonUtility.ToJson(sample);
  }
 }
 public sealed partial class NativeGameplayStudy {
  internal void AddWebMemory(WebMemorySample sample){
   foreach(var s in snakes.Values)sample.gameSnakeSurfaceBytes+=s.art.SurfaceBytes;
   foreach(var s in ghosts)sample.gameSnakeSurfaceBytes+=s.art.SurfaceBytes;
   sample.neonTargetBytes=neon?.TargetBytes??0;
   sample.turnTextureBytes=bank?.TextureBytes??0;
   sample.mazeTextureBytes=maze?(long)maze.width*maze.height*4:0;
  }
 }
}

using System;using System.IO;using System.Linq;using System.Collections.Generic;using UnityEngine;
namespace MazeBiters.NativeStudy {
 [Serializable]class LifecycleOracle {public PowerTest[] powers;public PressureTest[] pressures;public SpawnTest[] spawns;public EggTest[] eggTests;public HatchExpected[] hatchOrder;public DropTest[] drops;public CollectTest[] collects;public HeadTest[] heads;}
 [Serializable]class PowerTest {public PowerExpected[] samples;}
 [Serializable]class PowerExpected {public double time,strength,delay,until,rampAt,rampFrom,rampDuration,warning;public bool refresh,bright;}
 [Serializable]class PressureTest {public int level,mass,draws;public double difficulty,age,time,depletion,spawn,egg,repeat;}
 [Serializable]class SpawnTest {public int seed,draws;public bool crowded,exists;public Vector2Int head,tail,dir;public double fruit,egg,retry;}
 [Serializable]class EggTest {public string cover;public EggExpected[] samples;}
 [Serializable]class EggExpected {public double time,born;public int stage,eggs,draws;public bool solid;public HatchExpected[] hunters;}
 [Serializable]class HatchExpected {public Vector2Int cell,dir;public int palette;public double anger;public bool mother;}
 [Serializable]class DropTest {public bool snap,both,kill;public DropExpected[] samples;}
 [Serializable]class DropExpected {public double time,fruit,egg,retry;public int pending,draws;public FruitExpected[] fruits;public EggDropExpected[] eggs;}
 [Serializable]class FruitExpected {public Vector2Int cell;public int kind;public double born;}
 [Serializable]class EggDropExpected {public Vector2Int cell;public double born;}
 [Serializable]class CollectTest {public int kind,score,fruits;public double until,biteAt,biteDuration;}
 [Serializable]class HeadTest {public int count,score,draws;public SnakeExpected[] snakes;}
 [Serializable]class SnakeExpected {public Vector2Int[] body;public Vector2Int dir;public double anger,peak,floor,threat,turn;}
 [Serializable]public class LifecycleLogicReport {public bool passed;public int assertions,powerSamples,pressureCases,spawnCases,eggSamples,dropSamples,headCases;public string note;}
 public static class LifecycleValidation {
  sealed class Tape {uint state;public int Draws;public Tape(int seed=7){state=(uint)seed;}public double Next(){Draws++;unchecked{state+=0x6D2B79F5;uint v=(state^(state>>15))*(1|state);v^=v+(v^(v>>7))*(61|v);return (v^(v>>14))/4294967296.0;}}}
  public static LifecycleLogicReport Run(){
   var root=Path.Combine(WebFiles.Root,"Reference");
   var oracle=JsonUtility.FromJson<LifecycleOracle>(File.ReadAllText(Path.Combine(root,"lifecycle-oracle.json")));
   var grid=JsonUtility.FromJson<LevelData>(File.ReadAllText(Path.Combine(root,"level.json"))).geometry;
   var result=new LifecycleLogicReport{passed=true,note="Frozen original JS functions, identical seeded RNG, numeric power/drop/egg/head state parity. Single-human slice; not complete-game parity."};
   void Check(bool ok,string message){result.assertions++;if(!ok)throw new Exception("LIFECYCLE PARITY: "+message);}
   void Near(double a,double b,string name){Check(!double.IsNaN(a)&&Math.Abs(a-b)<1e-7,name+": "+a.ToString("R")+" != "+b.ToString("R"));}
   NativeGameplayWorld World(Tape rng){var w=new NativeGameplayWorld(grid,rng.Next){Assist=false};w.Player.Cell=w.Player.From=new Vector2Int(2,1);return w;}
   double Retry(NativeGameplayWorld w)=>double.IsPositiveInfinity(w.ScorpionSpawnAt)?0:w.ScorpionSpawnAt;
   void Hunters(NativeHunter[] actual,HatchExpected[] expected,string id){Check(actual.Length==expected.Length,id+" hunter count");for(int i=0;i<actual.Length;i++){var h=actual[i];var e=expected[i];Check(h.Cell==e.cell&&h.Dir==e.dir&&h.Palette==e.palette&&h.MotherAlive==e.mother,id+" hatch identity "+i);Near(h.Anger,e.anger,id+" hatch anger");}}
   foreach(var test in oracle.powers){var w=World(new Tape());w.ActivatePower();foreach(var e in test.samples){w.Time=e.time;if(e.refresh)w.ActivatePower();w.UpdatePower();string id="power "+e.time;Near(w.PowerStrength,e.strength,id+" strength");Near(w.PlayerDelay,e.delay,id+" delay");Near(w.Player.PowerUntil,e.until,id+" until");Near(w.Player.RampAt,e.rampAt,id+" ramp");Near(w.Player.RampFrom,e.rampFrom,id+" from");Near(w.Player.RampDuration,e.rampDuration,id+" duration");Near(w.Player.WarningAt,e.warning,id+" warning");Check(w.Player.PowerBright==e.bright,id+" bright");result.powerSamples++;}}
   foreach(var e in oracle.pressures){var rng=new Tape();var w=World(rng);w.Level=e.level;w.Difficulty=e.difficulty;w.Time=1000+e.age;w.StartingSnakeMass=35;if(e.mass>0)w.Snakes.Add(new NativeGameplaySnake{Body=Enumerable.Repeat(new Vector2Int(5,1),e.mass).ToList()});Near(w.TimePressure,e.time,"time pressure");Near(w.DepletionPressure,e.depletion,"mass pressure");Near(w.PressureDelay(15000,30000),e.spawn,"spawn delay");Near(w.PressureDelay(30000,60000),e.egg,"first egg delay");Near(w.PressureDelay(30000,50000)*2,e.repeat,"repeat egg delay");Check(rng.Draws==e.draws,"pressure RNG");result.pressureCases++;}
   foreach(var e in oracle.spawns){var rng=new Tape(e.seed);var w=World(rng);w.StartingSnakeMass=35;w.Snakes.Add(new NativeGameplaySnake{Body=Enumerable.Repeat(new Vector2Int(5,1),35).ToList()});if(e.crowded)for(int y=0;y<w.Height;y++)for(int x=0;x<w.Width;x++)if(w.Floor(new Vector2Int(x,y)))w.Fruits.Add(new NativeFruit{Cell=new Vector2Int(x,y)});w.SpawnScorpion();Check((w.Scorpion!=null)==e.exists,"spawn exists");if(e.exists){var s=w.Scorpion;Check(s.Cell==e.head&&s.Tail==e.tail&&s.Dir==e.dir,"spawn placement");Near(s.NextFruit,e.fruit,"spawn fruit");Near(s.NextEgg,e.egg,"spawn egg");}Near(Retry(w),e.retry,"spawn retry");Check(rng.Draws==e.draws,"spawn RNG");result.spawnCases++;}
   foreach(var test in oracle.eggTests){var rng=new Tape();var w=World(rng);var cell=new Vector2Int(5,1);w.Eggs.Add(new NativeEgg{Cell=cell,Born=0});
    if(test.cover=="player"||test.cover=="dead-player"){w.Player.Cell=cell;w.Player.Dead=test.cover=="dead-player";}
    if(test.cover=="snake")w.Snakes.Add(new NativeGameplaySnake{Body=new List<Vector2Int>{cell}});
    if(test.cover=="scorpion")w.PlaceScorpion(cell,Vector2Int.right);
    if(test.cover=="hunter")w.Hunters.Add(new NativeHunter{Id=99,Cell=cell});
    if(test.cover=="fruit")w.Fruits.Add(new NativeFruit{Cell=cell});
    foreach(var e in test.samples){w.Time=e.time;if(e.time==12001){w.Player.Cell=new Vector2Int(2,1);w.Player.Dead=false;w.Snakes.Clear();w.Scorpion=null;w.Hunters.RemoveAll(h=>h.Id==99);w.Fruits.Clear();}string id="egg "+test.cover+" t="+e.time;Check(w.SolidEgg(cell)==e.solid,id+" obstacle");w.UpdateEggs();Check(w.Eggs.Count==e.eggs,id+" eggs");Near(w.Eggs.Count>0?w.Eggs[0].Born:0,e.born,id+" birth");Check((w.Eggs.Count>0?w.Eggs[0].CrackStage:0)==e.stage,id+" stage");Hunters(w.Hunters.Where(h=>h.Id>=1000).ToArray(),e.hunters,id);Check(rng.Draws==e.draws,id+" RNG");result.eggSamples++;}
   }
   {var w=World(new Tape());for(int x=3;x<=9;x++)w.Eggs.Add(new NativeEgg{Cell=new Vector2Int(x,1)});w.Time=13000;w.UpdateEggs();Hunters(w.Hunters.ToArray(),oracle.hatchOrder,"palette cycle");}
   foreach(var test in oracle.drops){var rng=new Tape();var w=World(rng);w.LifecycleEnabled=true;var s=w.PlaceScorpion(new Vector2Int(test.snap?9:5,1),Vector2Int.right);s.LastMove=0;s.NextFruit=1000;s.NextEgg=test.both?1000:1e9;w.MoveScorpion();
    foreach(var e in test.samples){w.Time=e.time;if(test.kill&&e.time==1050)w.EatScorpion();w.ReleaseDrops();string id="drops "+test.snap+"/"+test.both+"/"+test.kill+" "+e.time;Check(w.Fruits.Count==e.fruits.Length&&w.Eggs.Count==e.eggs.Length&&w.PendingDrops.Count==e.pending,id+" counts");for(int i=0;i<e.fruits.Length;i++){var f=w.Fruits[i];Check(f.Cell==e.fruits[i].cell&&f.Kind==e.fruits[i].kind,id+" fruit");Near(f.Born,e.fruits[i].born,id+" fruit age");}for(int i=0;i<e.eggs.Length;i++){Check(w.Eggs[i].Cell==e.eggs[i].cell,id+" egg cell");Near(w.Eggs[i].Born,e.eggs[i].born,id+" egg age");}Near(w.Scorpion?.NextFruit??0,e.fruit,id+" next fruit");Near(w.Scorpion?.NextEgg??0,e.egg,id+" next egg");Near(Retry(w),e.retry,id+" respawn");Check(rng.Draws==e.draws,id+" RNG "+rng.Draws+" != "+e.draws);result.dropSamples++;}
   }
   foreach(var e in oracle.collects){var w=World(new Tape());w.Fruits.Add(new NativeFruit{Cell=w.Player.Cell,Kind=e.kind});w.CollectFruit();Check(w.Player.Score==e.score&&w.Fruits.Count==e.fruits,"collect score/remove");Near(w.Player.PowerUntil,e.until,"collect power");Near(w.Player.BiteAt,e.biteAt,"collect lead");Near(w.Player.BiteEnd-w.Player.BiteAt,e.biteDuration,"collect duration");}
   foreach(var test in oracle.heads){var rng=new Tape();var w=World(rng);var s=new NativeGameplaySnake{Body=Enumerable.Range(0,test.count).Select(i=>new Vector2Int(9-i,1)).ToList(),Dir=Vector2Int.right,Temperament=.7,Anger=1,AngerPeak=1,AngerFloor=.5,Threat=3};w.Snakes.Add(s);w.PowerEatHead(s);Check(w.Player.Score==test.score&&w.Snakes.Count==test.snakes.Length,"power head count/score");for(int i=0;i<w.Snakes.Count;i++){var a=w.Snakes[i];var e=test.snakes[i];Check(a.Body.SequenceEqual(e.body)&&a.Dir==e.dir,"power head body");Near(a.Anger,e.anger,"head anger");Near(a.AngerPeak,e.peak,"head peak");Near(a.AngerFloor,e.floor,"head floor");Near(a.Threat,e.threat,"head threat");Near(a.TurnBias,e.turn,"head turn");}Check(rng.Draws==test.draws,"head RNG");result.headCases++;}
   // Integration invariants beyond isolated original-function samples.
   {var w=World(new Tape());w.Fruits.Add(new NativeFruit{Cell=new Vector2Int(3,1)});w.Hunters.Add(new NativeHunter{Cell=new Vector2Int(3,1)});w.Press("test",Vector2Int.right);w.AdvancePlayer();Check(w.Power&&!w.Player.Dead&&w.Player.Score==250&&w.Hunters.Count==0,"fruit powers player before hunter contact in same step");Near(w.Player.MoveDuration,95,"collection does not retime current move");w.Time+=500;Check(w.PlayerDelay<95,"next move accelerates");}
   {var w=World(new Tape());w.ActivatePower();var s=new NativeGameplaySnake{Body=new List<Vector2Int>{new Vector2Int(3,1),new Vector2Int(4,1)},Dir=Vector2Int.left};w.Snakes.Add(s);Check(!w.CanEnter(w.Player.Cell,s),"powered player blocks snake entry");w.Press("test",Vector2Int.right);w.AdvancePlayer();Check(!w.Player.Dead&&w.Player.Score==125&&w.Player.Ricochet==null&&w.Snakes[0].Body.Count==1,"powered frontal head intake");}
   {var w=World(new Tape());var cell=new Vector2Int(5,1);w.Eggs.Add(new NativeEgg{Cell=cell});w.Time=9999;w.RefreshEggTopology();int before=w.ObstacleRevision;w.Time=10000;w.RefreshEggTopology();Check(w.ObstacleRevision>before&&w.SolidEgg(cell),"egg becomes route obstacle");before=w.ObstacleRevision;w.Time=13000;w.UpdateEggs();Check(w.ObstacleRevision>before&&!w.SolidEgg(cell),"hatched egg removes route obstacle");}
   return result;
  }
 }
}

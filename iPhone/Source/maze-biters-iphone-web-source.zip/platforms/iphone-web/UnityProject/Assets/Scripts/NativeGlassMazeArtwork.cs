using System;
using System.Diagnostics;
using System.IO;
using System.IO.Compression;
using System.Threading.Tasks;
using Unity.Collections;
using UnityEngine;

namespace MazeBiters.NativeStudy {
 // Loading-worker port of the approved smoked-floor/luminous-material formulas.
 // Topology, world units and gameplay RNG are still owned by the original generator.
 public sealed partial class NativeMazeArtwork {
  public bool IsGlass {get;private set;}
  public int Width=>IsGlass?glassWidth:W;
  public int Height=>IsGlass?glassHeight:H;
  public string GlassQuality {get;private set;}
  public string Theme {get;private set;}
  public Texture2D Emission {get;private set;}
  int glassWidth,glassHeight,glassSize,glassPublishStage,glassPublishOffset;
  double glassPublishMs;
  NativeArray<Color32> glassEmissionPixels;
  Texture2D glassPublishingMaze,glassPublishingEmission;
  // Independent rows/columns only. Each scanline's floating-point accumulation
  // keeps its approved order; no reduction, random state or GPU API is parallel.
  // Reserve at least half the logical CPUs for the live scene/loading screen.
#if UNITY_WEBGL && !UNITY_EDITOR
  public static readonly int GlassPainterWorkers=1;
#else
  public static readonly int GlassPainterWorkers=Array.IndexOf(Environment.GetCommandLineArgs(),"--serial-glass-painter")>=0?1:Math.Min(4,Math.Max(1,Environment.ProcessorCount/2));
#endif
  static readonly ParallelOptions GlassParallelOptions=new ParallelOptions{MaxDegreeOfParallelism=GlassPainterWorkers};
  System.Threading.CancellationToken glassCancellation;
  void GlassRows(int count,Action<int> row){
   glassCancellation.ThrowIfCancellationRequested();
   if(GlassPainterWorkers==1){for(int i=0;i<count;i++){glassCancellation.ThrowIfCancellationRequested();row(i);}}
   else if(glassCancellation.CanBeCanceled)Parallel.For(0,count,new ParallelOptions{MaxDegreeOfParallelism=GlassPainterWorkers,CancellationToken=glassCancellation},row);
   else Parallel.For(0,count,GlassParallelOptions,row);
  }

  static byte[] GlassRead(string file,int count) {
   var result=new byte[count];int offset=0;
   using(var input=File.OpenRead(file))using(var gzip=new GZipStream(input,CompressionMode.Decompress)) {
    while(offset<count){int n=gzip.Read(result,offset,count-offset);if(n==0)throw new EndOfStreamException(file);offset+=n;}
    if(gzip.ReadByte()!=-1)throw new InvalidDataException("Oversized glass brush "+file);
   }
   return result;
  }
  static float[] GlassFloats(string file,int count) {var bytes=GlassRead(file,checked(count*4));var result=new float[count];Buffer.BlockCopy(bytes,0,result,0,bytes.Length);return result;}
  static double[] GlassCoefficients(string file) {var bytes=File.ReadAllBytes(file);if(bytes.Length!=15*8)throw new InvalidDataException("Invalid glass coefficients");var result=new double[15];Buffer.BlockCopy(bytes,0,result,0,bytes.Length);return result;}
  static double GlassClamp(double value,double lo=0,double hi=1)=>Math.Max(lo,Math.Min(hi,value));
  static double GlassSmooth(double a,double b,double value){double t=GlassClamp((value-a)/(b-a));return t*t*(3-2*t);}
  static int GlassRound(double value)=>(int)Math.Floor(value+.5);

  void BuildGlass(SessionLevel level,string quality,bool deferUpload,PreparationProfile profile,bool packGlassCache) {
#if UNITY_WEBGL && !UNITY_EDITOR
   if(WebWorkQueue.Capturing){glassCancellation=NativeMazeWorker.CurrentToken;WebWorkQueue.Defer(BuildGlassWeb(level,quality,deferUpload,profile,packGlassCache));return;}
#endif
   glassCancellation=NativeMazeWorker.CurrentToken;glassCancellation.ThrowIfCancellationRequested();
   if(quality!="hd"&&quality!="4k")throw new ArgumentOutOfRangeException(nameof(quality));
   if(level.geometry==null||level.geometry.Length!=25)throw new InvalidDataException("Glass maze requires original25-row topology");
   foreach(var row in level.geometry)if(row==null||row.Length!=36)throw new InvalidDataException("Glass maze requires original36-column topology");
   IsGlass=true;GlassQuality=quality;glassSize=quality=="4k"?160:80;glassWidth=36*glassSize;glassHeight=25*glassSize;
   string root=Path.Combine(Path.GetDirectoryName(brushRoot),"glass-brushes");
   if(Array.IndexOf(NativeMazeGenerator.Themes,level.theme)<0)throw new InvalidDataException("Unknown glass palette "+level.theme);
   string prefix=Path.Combine(root,level.theme,quality);int atlasPixels=16*glassSize*glassSize,count=glassWidth*glassHeight;
   var timer=Stopwatch.StartNew();int collections=GC.CollectionCount(0);
   NativeArray<float> broad=default,edge=default,scratch=default;
   try {
    // Only small immutable brushes are managed; full native fields use explicitly
    // owned buffers and are released before this worker returns to the loading gate.
    var wall=GlassRead(Path.Combine(prefix,"wall.rgba.gz"),atlasPixels*4);
    var wallEmission=GlassFloats(Path.Combine(prefix,"emission.f32.gz"),atlasPixels*3);
    var detail=GlassRead(Path.Combine(prefix,"receiver.r8.gz"),atlasPixels);
    var low=GlassRead(Path.Combine(prefix,"receiver-low.r8.gz"),256*16);
    var seed=GlassFloats(Path.Combine(root,"common",quality,"glint-seed.f32.gz"),atlasPixels);
    var coefficients=GlassCoefficients(Path.Combine(prefix,"floor-coefficients.f64"));
    profile.backdropMs=timer.Elapsed.TotalMilliseconds;timer.Restart();Topology();
    profile.topologyMs=timer.Elapsed.TotalMilliseconds;timer.Restart();
    glassCancellation.ThrowIfCancellationRequested();broad=new NativeArray<float>(count,Allocator.Persistent,NativeArrayOptions.ClearMemory);
    if(BoundedGlassPreparation){FillGlassAlpha(broad,wall);GlassBlurBounded(broad,glassSize*.42);}
    glassCancellation.ThrowIfCancellationRequested();edge=new NativeArray<float>(count,Allocator.Persistent,NativeArrayOptions.ClearMemory);
    if(BoundedGlassPreparation){FillGlassAlpha(edge,wall);GlassBlurBounded(edge,glassSize*.09);}
    else{
     scratch=new NativeArray<float>(count,Allocator.Persistent,NativeArrayOptions.UninitializedMemory);
     FillGlassAlpha(broad,wall);GlassBlur(broad,scratch,glassSize*.42);
     FillGlassAlpha(edge,wall);GlassBlur(edge,scratch,glassSize*.09);
    }
    NativeGlassPeakTrace.Mark("optical-fields");
    profile.floorsMs=timer.Elapsed.TotalMilliseconds;timer.Restart();
    var compositionEdge=edge;NativeArray<float> glints=default;
    if(BoundedGlassPreparation){glassEmissionPixels=edge.Reinterpret<Color32>(4);edge=default;}
    else{
    // Reuse the blur scratch for horizontal caustic seeds. Reinterpret the future
    // emission pixels as one float/texel until final composition, avoiding a fourth
    // full optical field. Every float is consumed before its own pixel is written.
    GlassSoftenSeed(scratch,seed);
    var glintSource=scratch;
    if(CompactGlassCache){glassEmissionPixels=scratch.Reinterpret<Color32>(4);scratch=default;}
    else glassEmissionPixels=new NativeArray<Color32>(count,Allocator.Persistent,NativeArrayOptions.UninitializedMemory);
    glints=glassEmissionPixels.Reinterpret<float>(4);
    int[] dx=new int[9],dy=new int[9];double[] weight=new double[9];
    for(int k=0;k<9;k++){int step=k+1;dx[k]=GlassRound(step*glassSize*.004);dy[k]=GlassRound(step*glassSize*.055);weight[k]=Math.Exp(-step*.27);}
    Action<int> glintRow=y=>{for(int x=0;x<glassWidth;x++){
     double value=0;for(int k=0;k<9;k++)if(y>=dy[k])value+=glintSource[(y-dy[k])*glassWidth+Math.Max(0,x-dx[k])]*weight[k];
     glints[y*glassWidth+x]=(float)(value*.28);
    }};
    if(CompactGlassCache){
     // Every source row is at least dy[0] rows above its destination. Work from
     // bottom to top in bands no taller than that distance: rows within a band
     // can run in parallel, and never read a row that has already been replaced.
     // Each pixel retains the original nine-term floating-point summation order.
     for(int end=glassHeight;end>0;){int start=Math.Max(0,end-dy[0]),stop=end;GlassRows(stop-start,i=>glintRow(start+i));end=start;}
    }else GlassRows(glassHeight,glintRow);
    if(scratch.IsCreated)scratch.Dispose();scratch=default;
    }
    profile.territoryMs=timer.Elapsed.TotalMilliseconds;timer.Restart();
    var compositionBroad=broad;
    // Once a pixel's optical samples are read, its broad-field slot becomes the
    // final maze pixel. Ownership transfers here; no alias is disposed twice.
    if(CompactGlassCache){pixels=broad.Reinterpret<Color32>(4);broad=default;}
    else pixels=new NativeArray<Color32>(count,Allocator.Persistent,NativeArrayOptions.UninitializedMemory);
    Relief=new byte[count];pendingLow=new Color32[576*400];
    ComposeGlass(compositionBroad,compositionEdge,glints,wall,wallEmission,detail,coefficients,BoundedGlassPreparation?seed:null);
    NativeGlassPeakTrace.Mark("composed");
    for(int gy=0;gy<25;gy++)for(int gx=0;gx<36;gx++){
     int tile=masks[gx,gy];if(tile<0)continue;
     for(int y=0;y<16;y++)for(int x=0;x<16;x++){byte value=low[y*256+tile*16+x];pendingLow[(gy*16+y)*576+gx*16+x]=new Color32(value,value,value,value);}
    }
    // Relief already uses bottom-up rows. In-place composition must consume its
    // fields top-down, so flip completed emission and (in compact mode) maze once.
    using(var row=new NativeArray<Color32>(glassWidth,Allocator.Persistent,NativeArrayOptions.UninitializedMemory)){
     for(int y=0;y<glassHeight/2;y++){int a=y*glassWidth,b=(glassHeight-1-y)*glassWidth;NativeArray<Color32>.Copy(glassEmissionPixels,a,row,0,glassWidth);NativeArray<Color32>.Copy(glassEmissionPixels,b,glassEmissionPixels,a,glassWidth);NativeArray<Color32>.Copy(row,0,glassEmissionPixels,b,glassWidth);
      if(CompactGlassCache){NativeArray<Color32>.Copy(pixels,a,row,0,glassWidth);NativeArray<Color32>.Copy(pixels,b,pixels,a,glassWidth);NativeArray<Color32>.Copy(row,0,pixels,b,glassWidth);}
     }
    }
    flipped=true;profile.wallsMs=timer.Elapsed.TotalMilliseconds;
    profile.totalMs=profile.backdropMs+profile.topologyMs+profile.floorsMs+profile.territoryMs+profile.wallsMs;
    profile.collections=GC.CollectionCount(0)-collections;Profile=profile;
   } catch {DisposeStaging();throw;} finally {if(broad.IsCreated)broad.Dispose();if(edge.IsCreated)edge.Dispose();if(scratch.IsCreated)scratch.Dispose();}
   if(CompactGlassCache&&deferUpload&&packGlassCache){var packing=Stopwatch.StartNew();try{PackGlassStaging();}catch{DisposeStaging();throw;}GlassPackingMs=packing.Elapsed.TotalMilliseconds;Profile.totalMs+=GlassPackingMs;}
   NativeGlassPeakTrace.Mark("worker-ready");
   if(!deferUpload){try{Publish();}catch{Discard();throw;}}
  }
  void FillGlassAlpha(NativeArray<float> destination,byte[] wall) {
   GlassRows(25,gy=>{for(int gx=0;gx<36;gx++){
    int tile=masks[gx,gy];if(tile<0)continue;
    for(int y=0;y<glassSize;y++)for(int x=0;x<glassSize;x++)destination[(gy*glassSize+y)*glassWidth+gx*glassSize+x]=(float)(wall[(y*16*glassSize+tile*glassSize+x)*4+3]/255.0);
   }});
  }
  void GlassBlur(NativeArray<float> source,NativeArray<float> temp,double sigma) {
   double ideal=Math.Sqrt(4*sigma*sigma+1);int low=(int)Math.Floor(ideal);if((low&1)==0)low--;
   int high=low+2,n=GlassRound((12*sigma*sigma-3*low*low-12*low-9)/(-4.0*low-4));
   for(int k=0;k<3;k++){int radius=((k<n?low:high)-1)/2;GlassBox(source,temp,radius,true);GlassBox(temp,source,radius,false);}
  }
  void GlassBox(NativeArray<float> source,NativeArray<float> destination,int radius,bool horizontal) {
   int outer=horizontal?glassHeight:glassWidth,inner=horizontal?glassWidth:glassHeight,stride=horizontal?1:glassWidth;double divisor=2*radius+1;
   GlassRows(outer,q=>{
    int origin=horizontal?q*glassWidth:q;double sum=0;
    for(int k=-radius;k<=radius;k++)sum+=source[origin+Math.Max(0,Math.Min(inner-1,k))*stride];
    for(int p=0;p<inner;p++){
     destination[origin+p*stride]=(float)(sum/divisor);
     sum+=(double)source[origin+Math.Max(0,Math.Min(inner-1,p+radius+1))*stride]-source[origin+Math.Max(0,Math.Min(inner-1,p-radius))*stride];
    }
   });
  }
  float GlassSeed(float[] seed,int x,int y) {int tile=masks[x/glassSize,y/glassSize];return tile<0?0:seed[(y%glassSize)*16*glassSize+tile*glassSize+x%glassSize];}
  void GlassSoftenSeed(NativeArray<float> destination,float[] seed) {
   int radius=Math.Max(1,GlassRound(glassSize*.024));double divisor=radius*2+1;
   GlassRows(glassHeight,y=>{
    double sum=0;for(int k=-radius;k<=radius;k++)sum+=GlassSeed(seed,Math.Max(0,Math.Min(glassWidth-1,k)),y);
    for(int x=0;x<glassWidth;x++){
     destination[y*glassWidth+x]=(float)(sum/divisor);
     sum+=(double)GlassSeed(seed,Math.Min(glassWidth-1,x+radius+1),y)-GlassSeed(seed,Math.Max(0,x-radius),y);
    }
   });
  }
  Action<int,float[]> GlassComposer(NativeArray<float> broad,NativeArray<float> edge,NativeArray<float> glints,byte[] wall,float[] emission,byte[] detail,double[] c) {
   var compose=GlassChunkComposer(broad,edge,glints,wall,emission,detail,c,pixels,glassEmissionPixels,false);
   return (y,streamedGlints)=>compose(y,streamedGlints,0,0);
  }
   // The Web painter supplies losslessly decoded optical bands and two output
  // chunks. Native callers still use the same full fields and original order.
  // Only indexing differs: every optical value and arithmetic operation below
  // is shared, including float samples, rounding and the nine-term glint sum.
  Action<int,float[],int,int> GlassChunkComposer(NativeArray<float> broad,NativeArray<float> edge,NativeArray<float> glints,byte[] wall,float[] emission,byte[] detail,double[] c,NativeArray<Color32> mazeOutput,NativeArray<Color32> emissionOutput,bool bottomUpOutput) {
   double radius=.92*glassSize,aa=1.2*glassSize/80;
   // Coordinates/formulas remain in native texels, exactly as the approved study.
   Action<int,float[],int,int> composeRow=(y,streamedGlints,fieldOffset,outputOffset)=>{for(int x=0;x<glassWidth;x++){
    int j=y*glassWidth+x,destination=(glassHeight-1-y)*glassWidth+x,tile=masks[x/glassSize,y/glassSize];
    int s=tile<0?-1:(y%glassSize)*16*glassSize+tile*glassSize+x%glassSize;
    double alpha=s<0?0:wall[s*4+3]/255.0;
    double qx=Math.Max(0,Math.Max(radius-x-.5,x+.5-(glassWidth-radius))),qy=Math.Max(0,Math.Max(radius-y-.5,y+.5-(glassHeight-radius)));
    double coverage=1-GlassSmooth(-aa,aa,Math.Sqrt(qx*qx+qy*qy)-radius);
    // Keep these as float (not double) to preserve the original arithmetic.
    float broadSample=broad[j-fieldOffset],edgeSample=edge[j-fieldOffset],glintSample=streamedGlints!=null?streamedGlints[x]:glints[j];
    double spill=1-Math.Exp(-3*broadSample),shine=1-Math.Exp(-2*edgeSample);
    byte fr=Byte(c[0]+c[3]*spill+c[6]*shine),fg=Byte(c[1]+c[4]*spill+c[7]*shine),fb=Byte(c[2]+c[5]*spill+c[8]*shine),fa=Byte(153*coverage);
    double floorAlpha=fa/255.0,combined=alpha+floorAlpha*(1-alpha);
    int output=bottomUpOutput?destination-outputOffset:CompactGlassCache?j:destination;
    if(alpha>0)mazeOutput[output]=new Color32(Byte((wall[s*4]*alpha+fr*floorAlpha*(1-alpha))/combined),Byte((wall[s*4+1]*alpha+fg*floorAlpha*(1-alpha))/combined),Byte((wall[s*4+2]*alpha+fb*floorAlpha*(1-alpha))/combined),Byte(combined*255));
    else mazeOutput[output]=new Color32(fr,fg,fb,fa);
    Relief[destination]=s<0?(byte)0:detail[s];
    double spread=1-Math.Exp(-3.35*broadSample),rim=1-Math.Exp(-2.45*edgeSample);
    double sheen=.96+.04*Math.Cos(x/(double)glassSize*.21+y/(double)glassSize*.37);
    double lightBase=(.040+.315*spread)*sheen,reflection=.10*rim+.25*glintSample;
    double perimeter=GlassSmooth(glassSize*.015,glassSize*.35,Math.Min(Math.Min(x+.5,y+.5),Math.Min(glassWidth-x-.5,glassHeight-y-.5)));
    double mr=s<0?0:emission[s*3],mg=s<0?0:emission[s*3+1],mb=s<0?0:emission[s*3+2];
    emissionOutput[bottomUpOutput?output:j]=new Color32(Byte(((c[9]*lightBase+c[12]*reflection)*perimeter*(1-alpha)+mr*alpha)*255),Byte(((c[10]*lightBase+c[13]*reflection)*perimeter*(1-alpha)+mg*alpha)*255),Byte(((c[11]*lightBase+c[14]*reflection)*perimeter*(1-alpha)+mb*alpha)*255),Byte(coverage*255));
   }};
   return composeRow;
  }
  void ComposeGlass(NativeArray<float> broad,NativeArray<float> edge,NativeArray<float> glints,byte[] wall,float[] emission,byte[] detail,double[] c,float[] streamedSeed=null) {
   var composeRow=GlassComposer(broad,edge,glints,wall,emission,detail,c);
   if(streamedSeed!=null)GlassStreamGlints(streamedSeed,composeRow);else GlassRows(glassHeight,y=>composeRow(y,null));
  }
  // Both unpublished textures are completely overwritten by CopyGlassRows before
  // Apply and before either is exposed to a renderer. Avoid the redundant blank
  // allocation/upload; keep the old initialization in the before/after control.
  Texture2D GlassTexture(string name)=>new Texture2D(glassWidth,glassHeight,TextureFormat.RGBA32,false,false,NativeMazeWorker.Enabled){name=name,filterMode=FilterMode.Bilinear,wrapMode=TextureWrapMode.Clamp};
  bool PublishGlassStep() {
   if(Maze)return true;
   if(!HasPackedGlass&&((glassPublishStage<=1&&!pixels.IsCreated)||(glassPublishStage<=4&&!glassEmissionPixels.IsCreated)))throw new InvalidOperationException("Glass staging pixels unavailable");
   long stamp=NativeStallTrace.Stamp();var watch=Stopwatch.StartNew();
   try {
    switch(glassPublishStage) {
     case 0:glassPublishingMaze=GlassTexture("Generated approved glass maze");glassPublishStage++;NativeStallTrace.Add("prep-glass-maze-create",stamp);return false;
     case 1:CopyGlassRows(pixels,glassPublishingMaze);NativeStallTrace.Add("prep-glass-maze-copy",stamp);return false;
     case 2:glassPublishingMaze.Apply(false,true);if(BoundedGlassPreparation&&pixels.IsCreated){pixels.Dispose();pixels=default;}glassPublishStage++;NativeGlassPeakTrace.Mark("maze-uploaded");NativeStallTrace.Add("prep-glass-maze-apply",stamp);return false;
     case 3:glassPublishingEmission=GlassTexture("Generated approved crystal emission");glassPublishStage++;NativeStallTrace.Add("prep-glass-emission-create",stamp);return false;
     case 4:CopyGlassRows(glassEmissionPixels,glassPublishingEmission);NativeStallTrace.Add("prep-glass-emission-copy",stamp);return false;
     case 5:glassPublishingEmission.Apply(false,true);if(BoundedGlassPreparation&&glassEmissionPixels.IsCreated){glassEmissionPixels.Dispose();glassEmissionPixels=default;}glassPublishStage++;NativeGlassPeakTrace.Mark("emission-uploaded");NativeStallTrace.Add("prep-glass-emission-apply",stamp);return false;
     case 6:LowReceiver=Texture(pendingLow,576,400,"Generated glass low wall relief");pendingLow=null;glassPublishStage++;NativeStallTrace.Add("prep-glass-receiver",stamp);return false;
     default:
      if(pixels.IsCreated)pixels.Dispose();DisposeGlassStaging();Maze=glassPublishingMaze;Emission=glassPublishingEmission;glassPublishingMaze=glassPublishingEmission=null;
      NativeStallTrace.Add("prep-glass-release",stamp);return true;
    }
   } finally {glassPublishMs+=watch.Elapsed.TotalMilliseconds;if(Maze){Profile.uploadMs+=glassPublishMs;Profile.totalMs+=glassPublishMs;LastProfile=Profile;}}
  }
  void CopyGlassRows(NativeArray<Color32> source,Texture2D target) {
   if(HasPackedGlass){CopyPackedGlassRows(target);return;}
   // Same maximum1.41MiB publication chunk as the original native80 painter.
   int count=Math.Min(W*128,source.Length-glassPublishOffset);
   NativeArray<Color32>.Copy(source,glassPublishOffset,target.GetRawTextureData<Color32>(),glassPublishOffset,count);
   glassPublishOffset+=count;if(glassPublishOffset==source.Length){glassPublishOffset=0;glassPublishStage++;}
  }
  void DisposeGlassStaging(){if(glassEmissionPixels.IsCreated)glassEmissionPixels.Dispose();DisposeStartupPixels();packedGlassMaze=packedGlassEmission=null;glassUnpackBuffer=null;glassRunUnpack=null;}
  void DiscardGlass(){if(glassPublishingMaze)UnityEngine.Object.Destroy(glassPublishingMaze);if(glassPublishingEmission)UnityEngine.Object.Destroy(glassPublishingEmission);if(Emission)UnityEngine.Object.Destroy(Emission);glassPublishingMaze=glassPublishingEmission=null;Emission=null;}
 }
}

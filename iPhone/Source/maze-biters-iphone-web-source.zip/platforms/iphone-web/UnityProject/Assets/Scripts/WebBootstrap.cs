using System;
using System.IO;
using System.IO.Compression;
using System.Collections;
using System.Collections.Generic;
using System.Runtime.InteropServices;
using UnityEngine;
using UnityEngine.Networking;

namespace MazeBiters.NativeStudy {
 public static class WebFiles {
#if UNITY_WEBGL && !UNITY_EDITOR
  public const bool IsWeb=true;
  public static string Root=>"/maze-biters-iphone-assets";
  public static bool Ready;
#else
  public const bool IsWeb=false;
  public static string Root=>Path.GetFullPath(Path.Combine(Application.dataPath,"../../SourceAssets"));
  public static bool Ready=true;
#endif
  public static string InitialQuality=>Application.absoluteURL.Contains("quality=hd")?"hd":"4k";
 }
 public sealed class WebBootstrap:MonoBehaviour {
  [Serializable] public sealed class Pack {public string file,stage,sha256;public long bytes,rawBytes;public int fileCount;}
  [Serializable] public sealed class Manifest {public int version;public string packBase;public Pack[] packs;}
  [DllImport("__Internal")] static extern void MBWebStatus(string message,float progress,int phase);
  [DllImport("__Internal")] static extern void MBWebState(string json);
  [DllImport("__Internal")] static extern void MBWebSync();
  [DllImport("__Internal")] static extern int MBWebPaused();
  string error;bool loading,menuCreated;int completed,retries;Manifest manifest;double lastState;
  string RequestUrl(string root,string file)=>root+file+(retries>0?"?retry="+retries:"");
  public static string ResolvePackRoot(string root,string packBase){
   if(string.IsNullOrEmpty(packBase))return root;
   if(packBase!="../../../PC/StreamingAssets/WebPayload/")throw new InvalidDataException("Unsupported shared asset location");
   return new Uri(new Uri(root,UriKind.Absolute),packBase).AbsoluteUri;
  }
  public static void Status(string message,float progress=0,int phase=0){
#if UNITY_WEBGL && !UNITY_EDITOR
   MBWebStatus(message,progress,phase);
#endif
  }
  void Start(){DontDestroyOnLoad(gameObject);Application.targetFrameRate=60;StartCoroutine(Guard());}
  IEnumerator Guard(){
   loading=true;error=null;var steps=Load();
   try {while(true){bool more=false;try{more=steps.MoveNext();}catch(Exception e){error=e.Message;Debug.LogException(e);}if(error!=null||!more)break;yield return steps.Current;}}
   finally{(steps as IDisposable)?.Dispose();loading=false;}
   if(error!=null)Status("Зареждането беше прекъснато. Проверете връзката и опитайте отново.",0,-1);
  }
  IEnumerator Load(){
   var baseUrl=Application.streamingAssetsPath+"/WebPayload/";
   string manifestFile=WebFiles.IsWeb?"manifest-"+Application.buildGUID+".json":"manifest.json";
   if(manifest==null){using(var r=UnityWebRequest.Get(RequestUrl(baseUrl,manifestFile))){r.timeout=90;yield return r.SendWebRequest();if(r.result!=UnityWebRequest.Result.Success)throw new IOException(r.error);var candidate=JsonUtility.FromJson<Manifest>(r.downloadHandler.text);WebPayload.Validate(candidate);manifest=candidate;}}
   string packRoot=ResolvePackRoot(baseUrl,manifest.packBase);
   while(completed<manifest.packs.Length){
    if(!menuCreated&&manifest.packs[completed].stage!="menu"){
     foreach(var step in NativeMenuBoot.PrepareWeb())yield return null;
     new GameObject("Original title menu").AddComponent<NativeMenu>();menuCreated=true;yield return null;
    }
    var pack=manifest.packs[completed];int phase=pack.stage=="menu"?0:1;
    Status(phase==0?"Подготвяне на менюто…":"Зареждане на нивата и анимациите…",completed/(float)manifest.packs.Length,phase);
    byte[] data;
    using(var request=UnityWebRequest.Get(RequestUrl(packRoot,pack.file))){
     request.timeout=180;var operation=request.SendWebRequest();
     while(!operation.isDone){Status(phase==0?"Подготвяне на менюто…":"Зареждане на нивата и анимациите…",(completed+request.downloadProgress)/(float)manifest.packs.Length,phase);yield return null;}
     if(request.result!=UnityWebRequest.Result.Success)throw new IOException(pack.file+": "+request.error);
     data=request.downloadHandler.data;
    }
    foreach(var step in WebPayload.Verify(pack,data))yield return null;
    foreach(var step in WebPayload.Unpack(pack,data,WebFiles.Root))yield return null;
    data=null;completed++;
    if(!menuCreated&&pack.stage=="menu"&&(completed==manifest.packs.Length||manifest.packs[completed].stage!="menu")){
     foreach(var step in NativeMenuBoot.PrepareWeb())yield return null;
     new GameObject("Original title menu").AddComponent<NativeMenu>();menuCreated=true;yield return null;Status("Зареждане на нивата и анимациите…",completed/(float)manifest.packs.Length,1);
    }
   }
   NativeTurnBank.QueueCageSources();WebFiles.Ready=true;Status("",1,2);Debug.Log("WEB_ASSETS_READY");
  }
  public void Retry(){if(!loading){retries++;StartCoroutine(Guard());}}
  public void Pause(){var menu=FindAnyObjectByType<NativeMenu>();if(menu)menu.WebPause();}
  public void Menu(){var menu=FindAnyObjectByType<NativeMenu>();if(menu)menu.WebReturn();}
  void Update(){
   if(Time.realtimeSinceStartupAsDouble-lastState<.5)return;lastState=Time.realtimeSinceStartupAsDouble;
   var menu=FindAnyObjectByType<NativeMenu>();
#if UNITY_WEBGL && !UNITY_EDITOR
   MBWebState(menu?menu.WebState():"{\"stage\":\"loading\"}");
#endif
  }
  public static void Sync(){
#if UNITY_WEBGL && !UNITY_EDITOR
   MBWebSync();
#endif
  }
 }
 public static partial class WebStateUtil {public static string Quote(string value)=>"\""+(value??"").Replace("\\","\\\\").Replace("\"","\\\"").Replace("\n"," ").Replace("\r"," ")+"\"";}
 public sealed partial class NativeMenu {
  public void WebPause(){if(gameplay)gameplay.WebPause();}
  public void WebReturn(){if(gameplay)ReturnToMenu();else if(records!=null)CloseRecords();else if(State.Pending)State.CancelStart();}
  public string WebState()=>"{\"stage\":"+WebStateUtil.Quote(gameplay?"game":"menu")+",\"quality\":"+WebStateUtil.Quote(State.Quality)+",\"pending\":"+(State.Pending?"true":"false")+",\"ready\":"+(PreparedForSelection?"true":"false")+",\"mode\":"+State.SelectedMode+",\"error\":"+WebStateUtil.Quote(preparationError)+(gameplay?",\"game\":"+gameplay.WebState():"")+"}";
 }
 public sealed partial class NativeGameplayStudy {
  public void WebPause(){paused=!paused;}
  public string WebState()=>"{\"level\":"+(world?.Level??0)+",\"players\":"+(world==null?0:world.PlayerCount)+",\"time\":"+time.ToString(System.Globalization.CultureInfo.InvariantCulture)+",\"paused\":"+(paused?"true":"false")+",\"pageHidden\":"+(WebLifecycle.Suspended?"true":"false")+",\"renderWidth\":"+(target?target.width:0)+",\"renderHeight\":"+(target?target.height:0)+"}";
 }
}

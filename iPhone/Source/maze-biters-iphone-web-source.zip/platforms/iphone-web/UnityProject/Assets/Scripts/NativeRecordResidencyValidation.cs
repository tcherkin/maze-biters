using System;using System.IO;using System.Collections;using System.Collections.Generic;using System.Security.Cryptography;using UnityEngine;
namespace MazeBiters.NativeStudy {
 // Runs with an actual graphics device. These checks exercise texture ownership,
 // interrupted preparation and exact record/menu pixels; they are not an FPS test.
 public sealed class NativeRecordResidencyValidation:MonoBehaviour {
  [Serializable] public sealed class Result {public bool passed;public string quality,error,note;public int checks,preparedFrames,cancelledFrames;public long menuBytes,recordScreenBytes,releasedBytes;public string[] imageHashes;}
  Result result;NativeMenuRenderer renderer;string report;
  IEnumerator Start(){
   string q="hd";var args=Environment.GetCommandLineArgs();for(int i=0;i<args.Length;i++){if(args[i]=="--quality")q=args[++i];if(args[i]=="--report")report=args[++i];}
   result=new Result{quality=q,note="Real Unity GPU rendering: lazy menu, partial cancellation, full records, synchronous diagnostic parity, release/reopen, and unchanged leader menu pixels. Texture bytes count owned RGBA artwork only, not total RAM or GPU residency."};
   Application.runInBackground=true;QualitySettings.anisotropicFiltering=AnisotropicFiltering.Disable;
   using(var work=Run(q)){while(true){bool more=false;try{more=work.MoveNext();}catch(Exception e){result.error=e.ToString();Debug.LogException(e);break;}if(!more){result.passed=true;break;}yield return work.Current;}}
   renderer?.Dispose();renderer=null;yield return null;
   if(string.IsNullOrEmpty(report))report=Path.Combine(Application.persistentDataPath,"record-residency-"+q+".json");
   Directory.CreateDirectory(Path.GetDirectoryName(Path.GetFullPath(report)));File.WriteAllText(report,JsonUtility.ToJson(result,true));Debug.Log("RECORD_RESIDENCY "+JsonUtility.ToJson(result));
#if !UNITY_EDITOR
   Application.Quit(result.passed?0:2);
#endif
  }
  void Check(bool condition,string message){result.checks++;if(!condition)throw new InvalidOperationException(message);}
  IEnumerator<object> Run(string q){
   renderer=new NativeMenuRenderer(q,deferred:true);foreach(var step in renderer.LoadSteps())yield return null;
   Check(renderer.Ready&&!renderer.RecordsReady,"Ordinary menu must not retain full record artwork");
   var leader=new NativeRecord{id="leader",name="FANTASY",score=54320,level=4,mode=1};renderer.SetLeader(leader);
   result.menuBytes=renderer.TextureBytes;string menuBefore=MenuHash(q);
   using(var partial=renderer.PrepareRecordsSteps().GetEnumerator()){
    while(renderer.TextureBytes==result.menuBytes){Check(partial.MoveNext(),"Partial preparation must upload a record texture");result.cancelledFrames++;yield return null;}
   }
   Check(!renderer.RecordsReady,"Interrupted records are not ready");renderer.ReleaseRecordScreen();yield return null;
   Check(renderer.TextureBytes==result.menuBytes,"Cancellation releases every partially uploaded screen texture");
   Check(MenuHash(q)==menuBefore,"Cancellation leaves exact menu pixels");
   foreach(var step in renderer.PrepareRecordsSteps()){result.preparedFrames++;yield return null;}
   Check(renderer.RecordsReady,"Requested record screen completes");result.recordScreenBytes=renderer.TextureBytes-result.menuBytes;
   Check(result.recordScreenBytes==(q=="4k"?80852784L:20624912L),"Screen-only artwork byte count matches the unchanged source PNGs");
   var spec=renderer.RecordSpec;var first=CaptureCases(spec);result.imageHashes=first;
   renderer.ReleaseRecordScreen();yield return null;Check(!renderer.RecordsReady&&renderer.TextureBytes==result.menuBytes,"Leaving records releases their screen-only artwork");
   Check(MenuHash(q)==menuBefore,"Leader menu remains pixel-identical after full records");
   // The legacy direct diagnostic loader provides an independent loading path;
   // rendering/texture bytes must match the cooperative path exactly.
   var direct=renderer.RecordSpec;Check(renderer.RecordsReady,"Direct diagnostic loading is still supported");Compare(first,CaptureCases(direct),"direct diagnostic pixels");
   renderer.ReleaseRecordScreen();yield return null;
   foreach(var step in renderer.PrepareRecordsSteps())yield return null;
   Compare(first,CaptureCases(spec),"reopened cooperative pixels");
   renderer.ReleaseRecordScreen();yield return null;renderer.ReleaseRecordScreen();
   result.releasedBytes=renderer.TextureBytes;Check(result.releasedBytes==result.menuBytes,"Repeated release is idempotent");
   Check(MenuHash(q)==menuBefore,"Final menu artwork and effects are unchanged");
  }
  string MenuHash(string q){var menu=new NativeMenuState{Quality=q,Focus=6};menu.SetFocus(6,8100);menu.FocusAlpha=menu.FocusStart=0;menu.Changed=menu.Observed=8100;renderer.Render(menu,8100);return Hash(renderer.Target);}
  string[] CaptureCases(RecordManifest spec){var hashes=new List<string>();foreach(var c in spec.cases){
   if(c.screen=="menu")continue;
   var state=new NativeRecordState{Entry=c.screen=="entry",Candidate=c.candidate,Draft=c.draft??"",Row=c.row,Column=c.col,Page=c.page,Action=c.action,Status=c.status??"",Highlight=c.highlight??""};
   if(c.warm>0)renderer.RenderRecords(state,c.scores,c.warm);renderer.RenderRecords(state,c.scores,c.time);hashes.Add(c.name+":"+Hash(renderer.Target));
  }Check(hashes.Count>0,"Record fixtures include actual rendered screens");return hashes.ToArray();}
  void Compare(string[] expected,string[] actual,string label){Check(expected.Length==actual.Length,label+" count");for(int i=0;i<expected.Length;i++)Check(expected[i]==actual[i],label+" "+i);}
  static string Hash(RenderTexture target){var old=RenderTexture.active;var read=new Texture2D(target.width,target.height,TextureFormat.RGBA32,false,false);try{
   RenderTexture.active=target;read.ReadPixels(new Rect(0,0,target.width,target.height),0,0);read.Apply();
   using(var sha=SHA256.Create())return BitConverter.ToString(sha.ComputeHash(read.GetRawTextureData())).Replace("-","").ToLowerInvariant();
  }finally{RenderTexture.active=old;UnityEngine.Object.Destroy(read);}}
 }
}

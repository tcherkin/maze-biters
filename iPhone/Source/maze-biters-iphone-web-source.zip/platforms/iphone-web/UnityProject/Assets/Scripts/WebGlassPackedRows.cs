using System;
using System.Collections.Generic;
using System.IO;
using System.IO.Compression;
using Unity.Collections;
using UnityEngine;
using CompressionLevel=System.IO.Compression.CompressionLevel;

namespace MazeBiters.NativeStudy {
 public sealed partial class NativeMazeArtwork {
  // These counters describe owned CPU working buffers, not process RAM or GPU
  // memory. Immutable source brushes and engine/allocator overhead are excluded.
  public long WebPainterPeakWorkingBytes {get;private set;}
  public string WebPainterPeakStage {get;private set;}
  string webPainterStage;
  long webPainterFullFieldBytes,webPainterChunkBytes,webPainterAuxiliaryBytes;
  Action observeWebWorking;
  public int WebPainterPeakFullFields {get;private set;}
  void ObserveWebPainter(WebOpticalBlock[] broad,WebOpticalBlock[] edge,WebGlassCodec codec,WebOpticalCodec optical){
   long bytes=webPainterFullFieldBytes+webPainterChunkBytes+webPainterAuxiliaryBytes+GlassStagingBytes+(codec?.ScratchBytes??0)+(optical?.ScratchBytes??0);
   if(broad!=null)foreach(var block in broad)if(block.data.IsCreated)bytes+=block.data.Length;
   if(edge!=null)foreach(var block in edge)if(block.data.IsCreated)bytes+=block.data.Length;
   if(bytes>WebPainterPeakWorkingBytes){WebPainterPeakWorkingBytes=bytes;WebPainterPeakStage=webPainterStage;}
   WebPainterPeakFullFields=Math.Max(WebPainterPeakFullFields,(int)(webPainterFullFieldBytes/(4L*glassWidth*glassHeight)));
  }
  struct WebOpticalBlock {public NativeArray<byte> data;public bool raw;}
  static void DisposeWebOpticalBlocks(WebOpticalBlock[] blocks){if(blocks!=null)for(int i=0;i<blocks.Length;i++){if(blocks[i].data.IsCreated)blocks[i].data.Dispose();blocks[i]=default;}}
  // Optical floats vary smoothly in their low bits, so byte compression saves
  // much more space than exact four-word matching. Never quantize or round:
  // IEEE bytes are restored before the shared pixel formula reads each float.
  sealed class WebOpticalCodec:IDisposable {
   byte[] input;MemoryStream stream;
   public long ScratchBytes=>(input?.LongLength??0)+(stream?.Capacity??0);
   public WebOpticalCodec(int chunkPixels){int bytes=checked(chunkPixels*4);input=new byte[bytes];stream=new MemoryStream(bytes+1024);}
   public IEnumerable<object> Pack(NativeArray<float> field,int offset,int count,Action<WebOpticalBlock> receive){
    int bytes=checked(count*4);NativeArray<byte>.Copy(field.Reinterpret<byte>(4),offset*4,input,0,bytes);stream.SetLength(0);stream.Position=0;
    using(var gzip=new GZipStream(stream,CompressionLevel.Fastest,true)){
     for(int at=0;at<bytes;at+=8192){gzip.Write(input,at,Math.Min(8192,bytes-at));yield return null;}
    }
    int packed=checked((int)stream.Length);bool raw=packed>=bytes;int used=raw?bytes:packed;
    var block=new WebOpticalBlock{data=new NativeArray<byte>(used,Allocator.Persistent,NativeArrayOptions.UninitializedMemory),raw=raw};
    try{NativeArray<byte>.Copy(raw?input:stream.GetBuffer(),0,block.data,0,used);receive(block);}
    catch{if(block.data.IsCreated)block.data.Dispose();throw;}
    yield return null;
   }
   public IEnumerable<object> Unpack(WebOpticalBlock block,NativeArray<float> band,int count){
    int bytes=checked(count*4);if(!block.data.IsCreated||bytes>input.Length)throw new InvalidDataException("Missing optical band");
    if(block.raw){if(block.data.Length!=bytes)throw new InvalidDataException("Raw optical band length");NativeArray<byte>.Copy(block.data,0,band.Reinterpret<byte>(4),0,bytes);yield return null;yield break;}
    stream.SetLength(block.data.Length);stream.Position=0;NativeArray<byte>.Copy(block.data,0,stream.GetBuffer(),0,block.data.Length);
    using(var gzip=new GZipStream(stream,CompressionMode.Decompress,true)){
     int offset=0;while(offset<bytes){int n=gzip.Read(input,offset,Math.Min(8192,bytes-offset));if(n==0)throw new EndOfStreamException("Optical band");offset+=n;yield return null;}
     if(gzip.ReadByte()!=-1)throw new InvalidDataException("Oversized optical band");
    }
    NativeArray<byte>.Copy(input,0,band.Reinterpret<byte>(4),0,bytes);yield return null;
   }
   public void Dispose(){stream?.Dispose();stream=null;input=null;}
  }
  // The existing exact uint-word codec, cooperatively sliced. Float fields are
  // compressed as IEEE bits, without quantization or a different blur pass.
  sealed class WebGlassCodec {
   public readonly uint[] input=new uint[GlassChunkPixels],work=new uint[GlassChunkPixels+1];
   readonly int[] table=new int[65536];
   public long ScratchBytes=>4L*(input.Length+work.Length+table.Length);
   int used;bool raw;
   IEnumerable<object> Encode(int count){
    Array.Clear(table,0,table.Length);used=0;int literal=0,p=0,nextYield=8192;
    void Literals(int end){int n=end-literal;if(n==0)return;work[used++]=(uint)n;Array.Copy(input,literal,work,used,n);used+=n;}
    while(p+3<count){
     if(p>=nextYield){nextYield=p+8192;yield return null;}
     uint hash=unchecked(input[p]*2654435761u^input[p+1]*2246822519u^input[p+2]*3266489917u);int slot=(int)(hash>>16),prior=table[slot]-1;table[slot]=p+1;
     if(prior<0||input[prior]!=input[p]||input[prior+1]!=input[p+1]||input[prior+2]!=input[p+2]||input[prior+3]!=input[p+3]){p++;continue;}
     int end=p+4;
     while(end<count&&input[prior+end-p]==input[end]){end++;if(end>=nextYield){nextYield=end+8192;yield return null;}}
     Literals(p);work[used++]=unchecked((uint)-(end-p));work[used++]=(uint)(p-prior);literal=p=end;
    }
    Literals(count);raw=used>=count;if(raw)used=count;
   }
   public IEnumerable<object> Pack(NativeArray<uint> source,int offset,int count,Action<StartupPixelBlock> receive){
    NativeArray<uint>.Copy(source,offset,input,0,count);
    foreach(var step in Encode(count))yield return step;
    var block=new StartupPixelBlock{data=new NativeArray<uint>(used,Allocator.Persistent,NativeArrayOptions.UninitializedMemory),raw=raw};
    try{NativeArray<uint>.Copy(raw?input:work,0,block.data,0,used);receive(block);}
    catch{if(block.data.IsCreated)block.data.Dispose();throw;}
    yield return null;
   }
  }
  IEnumerable<object> PackWebBroad(NativeArray<float> source,WebOpticalBlock[] blocks,int chunkPixels,WebOpticalCodec codec){
   for(int i=0;i<blocks.Length;i++){
    int slot=i,offset=i*chunkPixels,count=Math.Min(chunkPixels,source.Length-offset);
    foreach(var step in codec.Pack(source,offset,count,block=>blocks[slot]=block))yield return step;
    observeWebWorking?.Invoke();
   }
  }
  IEnumerable<object> ComposeWebPacked(WebOpticalBlock[] broad,WebOpticalBlock[] edge,int broadChunkPixels,float[] seed,byte[] wall,float[] wallEmission,byte[] detail,double[] coefficients,WebGlassCodec codec,WebOpticalCodec optical){
   int total=glassWidth*glassHeight,count=(total+GlassChunkPixels-1)/GlassChunkPixels;
   runGlassMaze=new StartupPixelBlock[count];runGlassEmission=new StartupPixelBlock[count];
   NativeArray<float> broadBand=default,edgeBand=default;NativeArray<Color32> mazeBand=default,emissionBand=default;
   try{
    broadBand=new NativeArray<float>(broadChunkPixels,Allocator.Persistent,NativeArrayOptions.UninitializedMemory);
    edgeBand=new NativeArray<float>(broadChunkPixels,Allocator.Persistent,NativeArrayOptions.UninitializedMemory);
    mazeBand=new NativeArray<Color32>(GlassChunkPixels,Allocator.Persistent,NativeArrayOptions.UninitializedMemory);
    emissionBand=new NativeArray<Color32>(GlassChunkPixels,Allocator.Persistent,NativeArrayOptions.UninitializedMemory);
    webPainterChunkBytes=4L*(broadBand.Length+edgeBand.Length+mazeBand.Length+emissionBand.Length);observeWebWorking?.Invoke();
    var compose=GlassChunkComposer(broadBand,edgeBand,default,wall,wallEmission,detail,coefficients,mazeBand,emissionBand,true);
    int loadedBroad=-1,pendingOutput=-1;
    Action<int,float[]> row=(y,glints)=>{
     int inputIndex=y*glassWidth/broadChunkPixels,broadOffset=inputIndex*broadChunkPixels;
     if(inputIndex!=loadedBroad)throw new InvalidOperationException("Optical band was not prepared");
     int destination=(glassHeight-1-y)*glassWidth,outputIndex=destination/GlassChunkPixels;
     compose(y,glints,broadOffset,outputIndex*GlassChunkPixels);
     if(destination%GlassChunkPixels==0)pendingOutput=outputIndex;
    };
    // Rows are consumed top-down for the original glint history, but written
    // bottom-up within their final publication chunk. No whole-image flip or
    // second pair of full RGBA arrays is ever needed.
    using(var rows=WebComposeGlass(seed,row).GetEnumerator())for(int y=0;y<glassHeight;y++){
     int inputIndex=y*glassWidth/broadChunkPixels;
     if(inputIndex!=loadedBroad){
      int bandWords=Math.Min(broadChunkPixels,total-inputIndex*broadChunkPixels);
      foreach(var step in optical.Unpack(broad[inputIndex],broadBand,bandWords))yield return step;
      broad[inputIndex].data.Dispose();broad[inputIndex]=default;
      foreach(var step in optical.Unpack(edge[inputIndex],edgeBand,bandWords))yield return step;
      edge[inputIndex].data.Dispose();edge[inputIndex]=default;loadedBroad=inputIndex;
     }
     if(!rows.MoveNext())throw new InvalidOperationException("Missing glass composition row");yield return rows.Current;
     if(pendingOutput<0)continue;
     int slot=pendingOutput,words=Math.Min(GlassChunkPixels,total-slot*GlassChunkPixels);pendingOutput=-1;
     foreach(var packed in codec.Pack(mazeBand.Reinterpret<uint>(4),0,words,block=>runGlassMaze[slot]=block))yield return packed;
     observeWebWorking?.Invoke();
     foreach(var packed in codec.Pack(emissionBand.Reinterpret<uint>(4),0,words,block=>runGlassEmission[slot]=block))yield return packed;
     observeWebWorking?.Invoke();yield return "web output packed";
    }
   }finally{
    if(broadBand.IsCreated)broadBand.Dispose();if(edgeBand.IsCreated)edgeBand.Dispose();if(mazeBand.IsCreated)mazeBand.Dispose();if(emissionBand.IsCreated)emissionBand.Dispose();webPainterChunkBytes=0;
   }
  }
 }
}

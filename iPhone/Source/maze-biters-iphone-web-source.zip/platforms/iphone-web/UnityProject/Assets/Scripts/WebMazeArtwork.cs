using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using Unity.Collections;
using UnityEngine;

namespace MazeBiters.NativeStudy {
 public sealed partial class NativeMazeArtwork {
  NativeMazeArtwork(SessionLevel level,string sourceRoot){StarSky=true;fast=true;brushRoot=sourceRoot;grid=level.geometry;Theme=level.theme;hue=NativeMazeGenerator.Hues[Array.IndexOf(NativeMazeGenerator.Themes,level.theme)];}
  // Editor-only entrypoint compares CPU RGBA bytes before upload, independently
  // of WebGL shader validation and without changing source assets or gameplay.
  [Serializable] public sealed class WebPainterValidationResult {
   public bool passed;public string quality,theme,sha256;public int slices,cancellationChecks,maximumWholeOpticalFields;
   public long previousWebWorkingBytes,peakWorkingBytes,readyPackedBytes;
   public string accounting="Explicit owned CPU working buffers: optical fields, compressed blocks, codec and row buffers, relief and low receiver. Excludes immutable brushes, unreachable managed allocations awaiting GC, allocator/compression-library internal overhead, GPU memory and total process RAM. Previous Web peak is the exact size sum of its two raw fields plus relief, low receiver and glint ring.";
  }
  public static string ValidateWebPainter(string quality)=>JsonUtility.ToJson(ValidateWebPainterResult(quality,"green",true));
  public static WebPainterValidationResult ValidateWebPainterResult(string quality,string theme,bool checkCancellation){
   string root=Path.Combine(WebFiles.Root,"Reference/maze-brushes");
   var level=new NativeMazeGenerator(34,NativeMazeGenerator.Difficulties[2]).Generate(1);
   level.theme=theme;
   var before=new NativeMazeArtwork(level,1,true,true,root,glassQuality:quality,packGlassCache:false);
   string expected;try{expected=before.WebPixelHash();}finally{before.DisposeStaging();}
   var after=new NativeMazeArtwork(level,root);int slices=0;
   var result=new WebPainterValidationResult{quality=quality,theme=theme,sha256=expected};
   try{
    foreach(var step in after.BuildGlassWeb(level,quality,true,new PreparationProfile{optimized=true},false))slices++;
    if(slices<1000)throw new Exception("Web painter did not yield scanlines");string actual=after.WebPixelHash();if(actual!=expected)throw new Exception("Cooperative painter pixels differ: "+quality+"/"+theme+" "+expected+" != "+actual);
    if(after.WebPainterPeakFullFields!=1||after.pixels.IsCreated||after.glassEmissionPixels.IsCreated)throw new Exception("Web painter retained whole output fields");
    int rows=GlassRound(9*after.glassSize*.055)+1;
    result.previousWebWorkingBytes=9L*after.glassWidth*after.glassHeight+576L*400*4+4L*(rows+1)*after.glassWidth+144;
    result.peakWorkingBytes=after.WebPainterPeakWorkingBytes;result.readyPackedBytes=after.GlassStagingBytes;result.maximumWholeOpticalFields=after.WebPainterPeakFullFields;result.slices=slices;
    if(result.peakWorkingBytes>=result.previousWebWorkingBytes)throw new Exception("Web painter did not lower peak working buffers: "+quality+"/"+theme+" previous="+result.previousWebWorkingBytes+" current="+result.peakWorkingBytes+" packed="+result.readyPackedBytes+" phase="+after.WebPainterPeakStage);
   }
   finally{after.DisposeStaging();}
   if(checkCancellation)foreach(string stage in new[]{"early","web broad packed","web output packed"}){
    var cancelled=new NativeMazeArtwork(level,root);bool reached=false;int visited=0;
    using(var work=cancelled.BuildGlassWeb(level,quality,true,new PreparationProfile{optimized=true},false).GetEnumerator()){
     while(work.MoveNext()){visited++;if(stage=="early"?visited==20:work.Current as string==stage){reached=true;break;}}
    }
    if(!reached)throw new Exception("Painter completed before cancellation stage "+stage);
    if(cancelled.GlassStagingBytes!=0||cancelled.webPainterFullFieldBytes!=0||cancelled.webPainterChunkBytes!=0||cancelled.webPainterAuxiliaryBytes!=0)throw new Exception("Cancelled Web paint retained staging at "+stage);
    result.cancellationChecks++;
   }
   result.passed=true;return result;
  }
  string WebPixelHash(){
   using(var hash=System.Security.Cryptography.SHA256.Create()){
    var chunk=new byte[65536];
    if(runGlassMaze!=null){
     var words=new uint[GlassChunkPixels];var bytes=new byte[GlassChunkBytes];int total=glassWidth*glassHeight;
     foreach(var blocks in new[]{runGlassMaze,runGlassEmission})for(int index=0,offset=0;offset<total;index++,offset+=GlassChunkPixels){int count=Math.Min(GlassChunkPixels,total-offset);NativeStartupPixels.UnpackNative(blocks[index].data,blocks[index].raw,words,count);Buffer.BlockCopy(words,0,bytes,0,count*4);hash.TransformBlock(bytes,0,count*4,null,0);}
    }else foreach(var array in new[]{pixels,glassEmissionPixels}){var data=array.Reinterpret<byte>(4);for(int offset=0;offset<data.Length;offset+=chunk.Length){int count=Math.Min(chunk.Length,data.Length-offset);NativeArray<byte>.Copy(data,offset,chunk,0,count);hash.TransformBlock(chunk,0,count,null,0);}}
    hash.TransformBlock(Relief,0,Relief.Length,null,0);
    for(int i=0;i<pendingLow.Length;i++){var p=pendingLow[i];chunk[0]=p.r;chunk[1]=p.g;chunk[2]=p.b;chunk[3]=p.a;hash.TransformBlock(chunk,0,4,null,0);}
    hash.TransformFinalBlock(Array.Empty<byte>(),0,0);return BitConverter.ToString(hash.Hash).Replace("-","");
   }
  }
  // Same native-texel painter, sum order and float casts as the approved glass.
  // The Web variant yields between complete scanlines instead of using threads.
  IEnumerable<object> BuildGlassWeb(SessionLevel level,string quality,bool deferUpload,PreparationProfile profile,bool packGlassCache){
   if(quality!="hd"&&quality!="4k")throw new ArgumentOutOfRangeException(nameof(quality));
   if(level.geometry==null||level.geometry.Length!=25)throw new InvalidDataException("Glass maze requires25rows");
   foreach(var row in level.geometry)if(row==null||row.Length!=36)throw new InvalidDataException("Glass maze requires36columns");
   IsGlass=true;GlassQuality=quality;glassSize=quality=="4k"?160:80;glassWidth=36*glassSize;glassHeight=25*glassSize;
   if(!CompactGlassCache||!BoundedGlassPreparation)throw new NotSupportedException("Web preparation requires the approved bounded glass painter");
   string root=Path.Combine(Path.GetDirectoryName(brushRoot),"glass-brushes"),prefix=Path.Combine(root,level.theme,quality);
   int atlasPixels=16*glassSize*glassSize,count=glassWidth*glassHeight,collections=GC.CollectionCount(0);
   var timer=Stopwatch.StartNew();NativeArray<float> broad=default,edge=default;bool complete=false;
   // Keep only one whole optical field. The broad field is stored as exact
   // IEEE float words before edge allocation, then decoded eight rows at a time.
   int broadChunkPixels=glassWidth*8;
   var broadBlocks=new WebOpticalBlock[(count+broadChunkPixels-1)/broadChunkPixels];
   var edgeBlocks=new WebOpticalBlock[broadBlocks.Length];
   WebGlassCodec codec=null;var optical=new WebOpticalCodec(broadChunkPixels);
   observeWebWorking=()=>ObserveWebPainter(broadBlocks,edgeBlocks,codec,optical);
   try{
    var wall=GlassRead(Path.Combine(prefix,"wall.rgba.gz"),atlasPixels*4);yield return null;
    var wallEmission=GlassFloats(Path.Combine(prefix,"emission.f32.gz"),atlasPixels*3);yield return null;
    var detail=GlassRead(Path.Combine(prefix,"receiver.r8.gz"),atlasPixels);yield return null;
    var low=GlassRead(Path.Combine(prefix,"receiver-low.r8.gz"),256*16);yield return null;
    var seed=GlassFloats(Path.Combine(root,"common",quality,"glint-seed.f32.gz"),atlasPixels);yield return null;
    var coefficients=GlassCoefficients(Path.Combine(prefix,"floor-coefficients.f64"));
    profile.backdropMs=timer.Elapsed.TotalMilliseconds;timer.Restart();Topology();profile.topologyMs=timer.Elapsed.TotalMilliseconds;timer.Restart();yield return null;
    webPainterStage="broad blur";broad=new NativeArray<float>(count,Allocator.Persistent,NativeArrayOptions.UninitializedMemory);webPainterFullFieldBytes=4L*count;observeWebWorking?.Invoke();yield return null;
    foreach(var step in WebFillGlass(broad,wall))yield return step;
    foreach(var step in WebBlurGlass(broad,glassSize*.42))yield return step;
    webPainterStage="broad packing";foreach(var step in PackWebBroad(broad,broadBlocks,broadChunkPixels,optical))yield return step;
    broad.Dispose();broad=default;webPainterFullFieldBytes=0;NativeGlassPeakTrace.Mark("web-broad-packed");yield return "web broad packed";
    webPainterStage="edge blur";edge=new NativeArray<float>(count,Allocator.Persistent,NativeArrayOptions.UninitializedMemory);webPainterFullFieldBytes=4L*count;observeWebWorking?.Invoke();yield return null;
    foreach(var step in WebFillGlass(edge,wall))yield return step;
    foreach(var step in WebBlurGlass(edge,glassSize*.09))yield return step;
    webPainterStage="edge packing";foreach(var step in PackWebBroad(edge,edgeBlocks,broadChunkPixels,optical))yield return step;
    edge.Dispose();edge=default;webPainterFullFieldBytes=0;yield return "web edge packed";
    profile.floorsMs=timer.Elapsed.TotalMilliseconds;timer.Restart();
    codec=new WebGlassCodec();webPainterStage="composition";Relief=new byte[count];pendingLow=new Color32[576*400];observeWebWorking?.Invoke();yield return "web edge ready";
    foreach(var step in ComposeWebPacked(broadBlocks,edgeBlocks,broadChunkPixels,seed,wall,wallEmission,detail,coefficients,codec,optical))yield return step;
    NativeGlassPeakTrace.Mark("web-packed-composition");
    for(int gy=0;gy<25;gy++){for(int gx=0;gx<36;gx++){
     int tile=masks[gx,gy];if(tile<0)continue;
     for(int y=0;y<16;y++)for(int x=0;x<16;x++){byte value=low[y*256+tile*16+x];pendingLow[(gy*16+y)*576+gx*16+x]=new Color32(value,value,value,value);}
    }yield return null;}
    // Final pixels are already packed in upload order even when callers did
    // not request a boot cache. Retaining raw fields here would restore the
    // mobile peak; PackGlassWeb safely treats this ready cache as complete.
    flipped=true;profile.wallsMs=timer.Elapsed.TotalMilliseconds;
    profile.totalMs=profile.backdropMs+profile.topologyMs+profile.floorsMs+profile.wallsMs;profile.collections=GC.CollectionCount(0)-collections;Profile=profile;
    if(!deferUpload)while(!PublishGlassStep())yield return null;
    complete=true;
   }finally{if(broad.IsCreated)broad.Dispose();if(edge.IsCreated)edge.Dispose();DisposeWebOpticalBlocks(broadBlocks);DisposeWebOpticalBlocks(edgeBlocks);optical.Dispose();webPainterFullFieldBytes=0;observeWebWorking=null;if(!complete)DisposeStaging();}
  }
  IEnumerable<object> WebFillGlass(NativeArray<float> field,byte[] wall){
   for(int y=0;y<glassHeight;y++){
    int gy=y/glassSize,localY=y%glassSize;
    for(int gx=0;gx<36;gx++){int tile=masks[gx,gy],at=y*glassWidth+gx*glassSize,src=(localY*16*glassSize+tile*glassSize)*4;
     for(int x=0;x<glassSize;x++)field[at+x]=tile<0?0:(float)(wall[src+x*4+3]/255.0);
    }yield return null;
   }
  }
  IEnumerable<object> WebBlurGlass(NativeArray<float> field,double sigma){
   double ideal=Math.Sqrt(4*sigma*sigma+1);int low=(int)Math.Floor(ideal);if((low&1)==0)low--;
   int high=low+2,n=GlassRound((12*sigma*sigma-3*low*low-12*low-9)/(-4.0*low-4));
   for(int k=0;k<3;k++){int radius=((k<n?low:high)-1)/2;
    foreach(var step in WebBoxGlass(field,radius,true))yield return step;
    foreach(var step in WebBoxGlass(field,radius,false))yield return step;
   }
  }
  IEnumerable<object> WebBoxGlass(NativeArray<float> field,int radius,bool horizontal){
   int outer=horizontal?glassHeight:glassWidth,inner=horizontal?glassWidth:glassHeight,stride=horizontal?1:glassWidth;double divisor=2*radius+1;
   var line=new float[inner];
   webPainterAuxiliaryBytes+=4L*inner;observeWebWorking?.Invoke();try{
   for(int q=0;q<outer;q++){
    int origin=horizontal?q*glassWidth:q;
    if(horizontal)NativeArray<float>.Copy(field,origin,line,0,inner);else for(int p=0;p<inner;p++)line[p]=field[origin+p*stride];
    double sum=0;for(int k=-radius;k<=radius;k++)sum+=line[Math.Max(0,Math.Min(inner-1,k))];
    for(int p=0;p<inner;p++){field[origin+p*stride]=(float)(sum/divisor);sum+=(double)line[Math.Max(0,Math.Min(inner-1,p+radius+1))]-line[Math.Max(0,Math.Min(inner-1,p-radius))];}
    yield return null;
   }
   }finally{webPainterAuxiliaryBytes-=4L*inner;}
  }
  IEnumerable<object> WebComposeGlass(float[] seed,Action<int,float[]> compose){
   int[] dx=new int[9],dy=new int[9];double[] weight=new double[9];
   for(int k=0;k<9;k++){int step=k+1;dx[k]=GlassRound(step*glassSize*.004);dy[k]=GlassRound(step*glassSize*.055);weight[k]=Math.Exp(-step*.27);}
   int rows=dy[8]+1;var glint=new float[glassWidth];
   using(var ring=new NativeArray<float>(rows*glassWidth,Allocator.Persistent,NativeArrayOptions.UninitializedMemory)){
    long bytes=4L*(ring.Length+glint.Length+dx.Length+dy.Length)+8L*weight.Length;
    webPainterAuxiliaryBytes+=bytes;observeWebWorking?.Invoke();try{
    for(int y=0;y<glassHeight;y++){
     GlassSeedRow(ring,(y%rows)*glassWidth,seed,y);
     for(int x=0;x<glassWidth;x++){double value=0;for(int k=0;k<9;k++)if(y>=dy[k])value+=ring[((y-dy[k])%rows)*glassWidth+Math.Max(0,x-dx[k])]*weight[k];glint[x]=(float)(value*.28);}
     compose(y,glint);yield return null;
    }
    }finally{webPainterAuxiliaryBytes-=bytes;}
   }
  }
  IEnumerable<object> PackGlassWeb(){
   if(!IsGlass||!pixels.IsCreated||HasPackedGlass)yield break;
   var timer=Stopwatch.StartNew();bool complete=false;
   try{
    foreach(var step in PackWebPixels(pixels,true))yield return step;pixels.Dispose();pixels=default;
    foreach(var step in PackWebPixels(glassEmissionPixels,false))yield return step;glassEmissionPixels.Dispose();glassEmissionPixels=default;
    complete=true;
   }finally{if(!complete)DisposeStaging();}
   GlassPackingMs=timer.Elapsed.TotalMilliseconds;Profile.totalMs+=GlassPackingMs;
  }
  IEnumerable<object> PackWebPixels(NativeArray<Color32> source,bool maze){
   var words=source.Reinterpret<uint>(4);var blocks=new StartupPixelBlock[(words.Length+GlassChunkPixels-1)/GlassChunkPixels];
   if(maze)runGlassMaze=blocks;else runGlassEmission=blocks;
   var input=new uint[GlassChunkPixels];var work=new uint[GlassChunkPixels+1];var table=new int[65536];
   for(int i=0;i<blocks.Length;i++){
    int offset=i*GlassChunkPixels,count=Math.Min(GlassChunkPixels,words.Length-offset);NativeArray<uint>.Copy(words,offset,input,0,count);
    int used=NativeStartupPixels.Encode(input,count,work,table,out bool raw);
    blocks[i]=new StartupPixelBlock{data=new NativeArray<uint>(used,Allocator.Persistent,NativeArrayOptions.UninitializedMemory),raw=raw};
    NativeArray<uint>.Copy(raw?input:work,0,blocks[i].data,0,used);yield return null;
   }
  }
 }
}

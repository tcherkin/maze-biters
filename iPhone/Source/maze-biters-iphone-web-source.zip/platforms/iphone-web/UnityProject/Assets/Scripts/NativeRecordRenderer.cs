using System;using System.IO;using System.Collections.Generic;using UnityEngine;
namespace MazeBiters.NativeStudy {
 [Serializable] public sealed class RecordManifest {public string quality,chars;public MenuLayer[] entries;public RecordCase[] cases;}
 [Serializable] public sealed class RecordCase {public string name,image,screen,draft,status,highlight;public double time,warm;public int row,col,page,action=1;public NativeRecord[] scores;public NativeRecord candidate;}
 public sealed partial class NativeMenuRenderer {
  RecordManifest recordSpec;bool recordMenu,recordLoaded,recordPreparing;float recordLeft,recordRight;RecordText menuRecord,recordBody,recordHeading;string textKey;NativeRecord[] textScores;
  public bool RecordsReady=>!disposed&&recordLoaded;
  static bool MenuRecordLayer(string id)=>id=="menu-chrome"||id.StartsWith("font-",StringComparison.Ordinal);
  // Only the leader caption's chrome and fonts belong to the ordinary menu.
  // Full record screens are prepared only while the player requests them.
  IEnumerable<object> PrepareMenuRecordSteps(){
   EnsureRecordManifest();yield return "menu leader manifest";
   foreach(var e in recordSpec.entries)if(MenuRecordLayer(e.id))foreach(var step in LoadLayerSteps(recordsDirectory,e,true,true))yield return step;
  }
  // The ordinary menu continues animating between reads and texture uploads.
  public IEnumerable<object> PrepareRecordsSteps(){
   ThrowIfDisposed();while(recordPreparing){yield return "record art preparation";ThrowIfDisposed();}if(recordLoaded)yield break;
   recordPreparing=true;
   try{
    EnsureRecordManifest();yield return "record manifest";
    foreach(var e in recordSpec.entries)foreach(var step in LoadLayerSteps(recordsDirectory,e,true,true))yield return step;
    ThrowIfDisposed();recordLoaded=true;
   }finally{recordPreparing=false;}
  }
  public void ReleaseRecordScreen(){
   if(disposed)return;
   if(recordPreparing)throw new InvalidOperationException("Cancel record preparation before releasing its textures");
   // A cancelled source read can complete after this screen closes. Detach its
   // byte array from the retained menu without waiting or publishing a texture.
   var pending=pendingSource;pendingSource=null;
   if(pending!=null)WebWorkQueue.Continue(pending,t=>{if(t.IsFaulted){var ignored=t.Exception;}});
   // Clear commands before retiring meshes/textures that the last records frame
   // referenced. The existing target still contains that completed frame.
   draw?.Clear();recordBody?.Dispose();recordHeading?.Dispose();navText?.Dispose();
   recordBody=recordHeading=navText=null;textKey=null;textScores=null;recordLoaded=false;
   if(recordSpec==null)return;
   foreach(var e in recordSpec.entries){
    if(MenuRecordLayer(e.id)||!textures.TryGetValue(e.id,out var texture))continue;
    textures.Remove(e.id);layers.Remove(e.id);TextureBytes-=(long)texture.width*texture.height*4;
    UnityEngine.Object.Destroy(texture);
   }
  }
  void EnsureRecordManifest(){ThrowIfDisposed();if(recordSpec==null)recordSpec=JsonUtility.FromJson<RecordManifest>(File.ReadAllText(Path.Combine(recordsDirectory,Manifest.quality+".json")));}
  public RecordManifest RecordSpec{get{LoadRecords();return recordSpec;}}
  void LoadRecords(bool all=true){
   string dir=recordsDirectory;EnsureRecordManifest();
   if(all&&recordLoaded)return;
   foreach(var e in recordSpec.entries){if(textures.ContainsKey(e.id)||!all&&!MenuRecordLayer(e.id))continue;var tex=new Texture2D(2,2,TextureFormat.RGBA32,false){name="Original records "+e.id,filterMode=e.id.StartsWith("font-")?FilterMode.Point:FilterMode.Bilinear,wrapMode=TextureWrapMode.Clamp};try{if(!tex.LoadImage(File.ReadAllBytes(Path.Combine(dir,e.file)),!e.id.StartsWith("font-")))throw new IOException(e.file);textures.Add(e.id,tex);layers.Add(e.id,e);TextureBytes+=(long)tex.width*tex.height*4;}catch{UnityEngine.Object.Destroy(tex);throw;}}
   if(all)recordLoaded=true;
  }
  // Text is batched into two retained meshes; only changes to content rebuild it.
  sealed class RecordText:IDisposable {
   readonly Mesh[] meshes={new Mesh(),new Mesh()};readonly List<Vector3>[] vertices={new List<Vector3>(),new List<Vector3>()};readonly List<Vector2>[] uv={new List<Vector2>(),new List<Vector2>()};readonly List<int>[] triangles={new List<int>(),new List<int>()};readonly string chars;
   public RecordText(string chars){this.chars=chars;}
   public void Add(string text,float x,float y,float scale=1,bool red=false,int align=0){text=text??"";if(align==1)x-=text.Length*8*scale;else if(align==2)x-=text.Length*16*scale;int color=red?1:0;float size=16*scale;foreach(char ch in text){if(ch!=' '){int i=chars.IndexOf(ch);if(i<0)i=chars.IndexOf('?');float u=(i%8)/8f,v=1-(i/8+1)/6f;int n=vertices[color].Count;vertices[color].AddRange(new[]{new Vector3(x,-y),new Vector3(x+size,-y),new Vector3(x+size,-y-size),new Vector3(x,-y-size)});uv[color].AddRange(new[]{new Vector2(u,v+1f/6),new Vector2(u+1f/8,v+1f/6),new Vector2(u+1f/8,v),new Vector2(u,v)});triangles[color].AddRange(new[]{n,n+1,n+2,n,n+2,n+3});}x+=size;}}
   public void Seal(){for(int i=0;i<2;i++){meshes[i].SetVertices(vertices[i]);meshes[i].SetUVs(0,uv[i]);meshes[i].SetTriangles(triangles[i],0);meshes[i].RecalculateBounds();vertices[i].Clear();uv[i].Clear();triangles[i].Clear();}}
   public void Draw(NativeMenuRenderer r,float alpha){for(int i=0;i<2;i++){r.properties.Clear();r.properties.SetTexture("_MainTex",r.textures[i==0?"font-blue":"font-red"]);r.properties.SetFloat("_Opacity",alpha);r.properties.SetVector("_UVRect",new Vector4(0,0,1,1));r.draw.DrawMesh(meshes[i],Matrix4x4.identity,r.image,0,0,r.properties);}}
   public void Dispose(){foreach(var mesh in meshes)UnityEngine.Object.Destroy(mesh);}
  }
  public void SetLeader(NativeRecord leader){LoadRecords(false);recordMenu=true;menuRecord?.Dispose();menuRecord=new RecordText(recordSpec.chars);string blue="HIGH SCORE - "+(leader?.score??0).ToString().PadLeft(5,'0')+" ",red=leader?.name??"NOBODY";float scale=Math.Min(2,1024f/((blue.Length+red.Length)*16));recordLeft=(1024-(blue.Length+red.Length)*16*scale)/2;recordRight=1024-recordLeft;menuRecord.Add(blue,256+recordLeft*.5f,36,scale*.5f);menuRecord.Add(red,256+(recordLeft+blue.Length*16*scale)*.5f,36,scale*.5f,true);menuRecord.Seal();
   // Rebuilt only when the leader changes, at the same 1152 x 32 logical size
   // as the original glyph-clipped sweep. No per-frame CPU raster work.
   var pixels=new Color32[1152*32];string text=blue+red;float x=recordLeft;var atlas=new[]{textures["font-blue"].GetPixels32(),textures["font-red"].GetPixels32()};for(int k=0;k<text.Length;k++){int index=recordSpec.chars.IndexOf(text[k]);float size=16*scale;if(index>=0&&text[k]!=' '){for(int py=0;py<32;py++)for(int px=Math.Max(0,(int)Math.Ceiling(x-.5f));px<Math.Min(1152,Math.Ceiling(x+size-.5f));px++){if(py+.5>=size)continue;int sx=Math.Min(159,(int)((px+.5-x)/size*160)),sy=Math.Min(159,(int)((py+.5)/size*160));int offset=(959-(index/8*160+sy))*1280+index%8*160+Math.Max(0,sx);pixels[(31-py)*1152+px]=new Color32(255,255,255,atlas[k<blue.Length?0:1][offset].a);}}x+=size;}
   if(textures.TryGetValue("mask-record",out var old)){TextureBytes-=old.width*old.height*4;UnityEngine.Object.Destroy(old);}var mask=new Texture2D(1152,32,TextureFormat.RGBA32,false){filterMode=FilterMode.Bilinear};mask.SetPixels32(pixels);mask.Apply(false,true);textures["mask-record"]=mask;TextureBytes+=1152*32*4;leaderKey=(leader?.score??0)+"|"+(leader?.name??"NOBODY");
  }
  void ClippedGlow(Rect a,Rect clip,double alpha){if(alpha<=.001)return;Rect r=Rect.MinMaxRect(Math.Max(a.x,clip.x),Math.Max(a.y,clip.y),Math.Min(a.xMax,clip.xMax),Math.Min(a.yMax,clip.yMax));if(r.width<=0||r.height<=0)return;properties.Clear();properties.SetTexture("_MainTex",textures["emerald"]);properties.SetFloat("_Opacity",(float)alpha);properties.SetVector("_UVRect",new Vector4((r.x-a.x)/a.width,(a.yMax-r.yMax)/a.height,r.width/a.width,r.height/a.height));draw.DrawMesh(quad,Matrix4x4.TRS(new Vector3(r.x,-r.y),Quaternion.identity,new Vector3(r.width,r.height,1)),image,0,1,properties);}
  void RecordFocusGlow(RecordFocus f,Func<int,Rect> area,Rect clip){foreach(int i in new[]{f.Old,f.Current}){if(i<0)continue;var a=area(i);ClippedGlow(new Rect(a.x-18,a.y-14,a.width+36,a.height+28),clip,(i==f.Current?f.Alpha:f.OldAlpha)*.27);}}
  string ButtonId(int group,int index)=>group==0?"slot:"+index:group==1?"key:"+index:group==2?"entry-action:"+index:"board-board:"+index;
  void Button(int group,int index,bool selected,float alpha=1)=>Layer("button-"+ButtonId(group,index)+"-"+(selected?1:0),alpha);
  public void RenderRecords(NativeRecordState s,NativeRecord[] scores,double t){if(!RecordsReady)throw new InvalidOperationException("Record artwork must finish cooperative preparation before drawing");EnsureDisplay();draw.Clear();Layer(s.Entry?"bg-entry":"bg-leaderboard");int pages=Math.Max(1,(scores.Length+9)/10);s.Page=Math.Max(0,Math.Min(pages-1,s.Page));int start=s.Page*10,count=Math.Min(10,scores.Length-start);
   if(!s.Entry&&count>0){Layer("row-rule");for(int i=0;i<count;i++)Layer("row-"+i);}
   float dx=(float)Math.Sin(t*Math.PI*2/14000)*22,dy=(float)Math.Sin(t*Math.PI*2/18000)*10;Glow("emerald",16+dx,dy,620,210,.046*(1+.12*Math.Sin(t*Math.PI*2/16000+Math.PI/6)));Glow("violet",560-dx,13-dy,420,225,.027*(1+.10*Math.Sin(t*Math.PI*2/18000+Math.PI*1.3)));
   string key=s.Entry+"|"+s.Revision+"|"+s.Draft+"|"+s.Row+"|"+s.Column+"|"+s.Page+"|"+s.Action+"|"+s.Status+"|"+s.Highlight+"|"+(s.Candidate?.score??0)+"|"+(s.Candidate?.level??1);
   if(key!=textKey||!ReferenceEquals(scores,textScores)){textKey=key;textScores=scores;BuildRecordText(s,scores,start,count,pages);}
   recordHeading.Draw(this,(float)(.35+.65*Math.Max(0,Math.Min(1,(t-s.Entered)/360))));
   double cycle=Math.PI*2*310,phase=t-s.Entered-cycle*2;if(phase>=0&&(phase%=cycle*4)<cycle*2.5){float w=(s.Entry?14:11)*32;double progress=phase/(cycle*2.5),way=progress<=.5?progress*2:(1-progress)*2;lefts[0]=(float)((1024-w)/2-176+(w+176-176*.22)*way);Shine(s.Entry?"mask-entry":"mask-board",0,58,1152,32,0,1,.92f,.55f);}
   if(s.Entry){int cursor=s.Draft.Length<10?s.Draft.Length:-1,focus=s.Row==5?40+s.Column:s.Row*8+s.Column;s.Cursor.Set(cursor,t);s.Focus.Set(focus,t);
    for(int i=0;i<10;i++)Button(0,i,cursor==i);RecordFocusGlow(s.Cursor,i=>NativeRecordState.Area(0,i),new Rect(226,208,572,68));
    double age=t-s.ImprintAt;if(s.Imprint>=0&&age>=0&&age<420){var a=NativeRecordState.Area(0,s.Imprint);double rise=Math.Min(1,age/55),decay=Math.Max(0,1-Math.Max(0,age-55)/365);Glow("emerald",a.x-5,a.y-5,a.width+10,a.height+10,.24*rise*decay*decay);}
    for(int i=0;i<40;i++)Button(1,i,focus==i,.94f);for(int i=0;i<3;i++)Button(2,i,focus==40+i);RecordFocusGlow(s.Focus,i=>NativeRecordState.Area(i<40?1:2,i<40?i:i-40),new Rect(168,294,688,342));
   }else{if(count==0)Layer("empty-head");for(int i=0;i<count;i++){bool hi=scores[start+i].id==s.Highlight;if(hi||start+i==0)Glow(hi?"emerald":"gold",54,187+i*39,916,58,hi?.085*(.94+.06*Math.Sin(t/1850)):.105);}
    for(int i=0;i<3;i++)Button(3,i,s.Action==i,i==1||pages>1?1:.3f);s.Focus.Set(s.Action==1||pages>1?s.Action:-1,t);RecordFocusGlow(s.Focus,i=>NativeRecordState.Area(3,i),new Rect(164,638,696,78));}
   recordBody.Draw(this,1);navText?.Draw(this,navAlpha);DrawSurround();camera.Render();
  }
  void BuildRecordText(NativeRecordState s,NativeRecord[] scores,int start,int count,int pages){recordBody?.Dispose();recordHeading?.Dispose();recordBody=new RecordText(recordSpec.chars);recordHeading=new RecordText(recordSpec.chars);var b=recordBody;recordHeading.Add(s.Entry?"NEW HIGH SCORE":"HIGH SCORES",512,58,2,false,1);b.Add(s.Entry?"WELCOME TO THE TOP 25":"TOP 25 - THIS DEVICE",512,104,1,true,1);
   if(s.Entry){string blue="SCORE "+(s.Candidate?.score??0).ToString().PadLeft(5,'0')+"   ",red="LEVEL "+(s.Candidate?.level??1);float x=512-(blue.Length+red.Length)*10;b.Add(blue,x,158,1.25f);b.Add(red,x+blue.Length*20,158,1.25f,true);b.Add("ENTER YOUR NAME",512,188,.8f,false,1);for(int i=0;i<s.Draft.Length;i++)b.Add(s.Draft[i].ToString(),260+i*56,226,2,true,1);b.Add("UP TO 10 CHARACTERS - NO SPACES",512,283,.65f,false,1);
    for(int i=0;i<40;i++){var a=NativeRecordState.Area(1,i);b.Add(NativeRecordState.Keys[i].ToString(),a.center.x,a.y+8,1.25f,s.Row*8+s.Column==i&&s.Row<5,1);}for(int i=0;i<3;i++){var a=NativeRecordState.Area(2,i);b.Add(new[]{"DELETE","SAVE","SKIP"}[i],a.center.x,a.y+15,1.25f,i==1,1);}b.Add("TYPE OR ARROWS THEN SPACE - D-PAD AND A",512,650,.8f,false,1);b.Add("EMPTY NAMES ARE NEVER SAVED",512,678,.75f,true,1);b.Add(s.Status.Length>0?s.Status:"ESC - SKIP WITHOUT SAVING",512,s.Status.Length>0?706:724,s.Status.Length>0?.75f:.65f,s.Status.Length>0,1);
   }else{if(count>0){b.Add("RANK",92,160,.85f);b.Add("NAME",184,160,.85f);b.Add("MODE",408,160,.85f);b.Add("LEVEL",690,160,.85f,false,1);b.Add("SCORE",930,160,.85f,false,2);}else{b.Add("NO SCORES YET",512,346,1.35f,true,1);b.Add("PLAY A GAME AND CLAIM THE FIRST PLACE",512,398,.75f,false,1);}
    for(int i=0;i<count;i++){var r=scores[start+i];bool red=start+i<3||r.id==s.Highlight;float y=206+i*39;b.Add((start+i+1).ToString("D2"),92,y,1,red);b.Add(r.name,184,y,1,red);b.Add(new[]{"SOLO","DUO VS","SOLO AI","DUO AI","CO-OP"}[Math.Max(0,Math.Min(4,r.mode-1))],408,y,.85f);b.Add(r.level.ToString("D3"),690,y,1,false,1);b.Add(r.score.ToString("D6"),930,y,1,red,2);}b.Add("PAGE "+(s.Page+1)+" OF "+pages,512,614,.8f,false,1);
    // Disabled navigation is a separate dimmed batch, drawn below.
    b.Add("BACK",512,665,1.25f,true,1);b.Add(s.Status.Length>0?s.Status:"ARROWS - SPACE   D-PAD - A   ESC - BACK",512,s.Status.Length>0?714:724,s.Status.Length>0?.65f:.7f,s.Status.Length>0,1);
   }recordBody.Seal();recordHeading.Seal();navText?.Dispose();navText=null;if(!s.Entry){navText=new RecordText(recordSpec.chars);navText.Add("PREV",276,665,1.25f,false,1);navText.Add("NEXT",748,665,1.25f,false,1);navText.Seal();navAlpha=pages>1?1:.3f;}
  }
  RecordText navText;float navAlpha;
  void DisposeRecords(){menuRecord?.Dispose();recordBody?.Dispose();recordHeading?.Dispose();navText?.Dispose();}
 }
}

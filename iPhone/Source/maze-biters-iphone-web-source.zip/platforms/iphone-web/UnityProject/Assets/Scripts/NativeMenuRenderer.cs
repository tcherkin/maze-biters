using System;using System.IO;using System.Collections.Generic;using System.Threading.Tasks;using UnityEngine;using UnityEngine.Rendering;
namespace MazeBiters.NativeStudy {
 // Retained GPU layers. No browser, JavaScript, per-frame rasterization or readback.
 public sealed partial class NativeMenuRenderer:IDisposable {
  public readonly MenuManifest Manifest;public RenderTexture Target{get;private set;}public long TextureBytes{get;private set;}public bool Ready{get;private set;}
  readonly Dictionary<string,Texture2D> textures=new Dictionary<string,Texture2D>();readonly Dictionary<string,MenuLayer> layers=new Dictionary<string,MenuLayer>();
  Material image,shine;Mesh quad;Camera camera;CommandBuffer draw;readonly MaterialPropertyBlock properties=new MaterialPropertyBlock();
  readonly RenderTexture[] effects=new RenderTexture[3];readonly float[] lefts=new float[32];readonly MenuArea[] areas=new MenuArea[12];
  readonly string menuDirectory,recordsDirectory;readonly bool deferred;bool loading;Task<byte[]> pendingSource;string leaderKey;
  // A quality change builds one temporary candidate while the ready menu keeps
  // drawing. Source reads never touch Unity; upload and publication stay here.
  public NativeMenuRenderer(string quality,bool deferred=false){
   this.deferred=deferred;menuDirectory=Path.Combine(WebFiles.Root,"Reference/menu");recordsDirectory=Path.Combine(WebFiles.Root,"Reference/records");Manifest=JsonUtility.FromJson<MenuManifest>(File.ReadAllText(Path.Combine(menuDirectory,quality+".json")));
   foreach(var a in Manifest.areas)areas[Array.IndexOf(NativeMenuState.Keys,a.id)]=a;
   if(!deferred)try{foreach(var step in LoadSteps()){} }catch{Dispose();throw;}
  }
  public IEnumerable<object> LoadSteps(){
   if(disposed)throw new ObjectDisposedException(nameof(NativeMenuRenderer));if(Ready)yield break;if(loading)throw new InvalidOperationException("Menu preparation is already running");loading=true;
   try{
   foreach(var e in Manifest.entries)foreach(var step in LoadLayerSteps(menuDirectory,e,false))yield return step;
   // Preserve the live leader caption, but do not allocate the separate record
   // screens until they are opened. This also applies to quality candidates.
   foreach(var step in PrepareMenuRecordSteps())yield return step;
   ThrowIfDisposed();
   quad=new Mesh();quad.vertices=new[]{new Vector3(0,0),new Vector3(1,0),new Vector3(1,-1),new Vector3(0,-1)};quad.uv=new[]{new Vector2(0,1),new Vector2(1,1),new Vector2(1,0),new Vector2(0,0)};quad.triangles=new[]{0,1,2,0,2,3};quad.RecalculateBounds();
   image=new Material(Shader.Find("MazeBiters/MenuImage"));shine=new Material(Shader.Find("MazeBiters/MenuShine"));shine.SetTexture("_Beam",textures["beam"]);
   yield return "menu materials";ThrowIfDisposed();
   camera=new GameObject("Original menu GPU compositor").AddComponent<Camera>();camera.enabled=false;camera.cullingMask=0;camera.orthographic=true;camera.orthographicSize=384;camera.aspect=4f/3;camera.transform.position=new Vector3(512,-384,-10);camera.clearFlags=CameraClearFlags.SolidColor;camera.backgroundColor=Color.black;camera.allowHDR=camera.allowMSAA=false;
   var size=NativeDisplay.Stable?NativeDisplay.Frame.Pixels(Manifest.quality):new Vector2Int(Manifest.width,Manifest.height);
   Target=new RenderTexture(size.x,size.y,0,RenderTextureFormat.ARGB32){name="Menu "+Manifest.quality,filterMode=FilterMode.Bilinear};Target.Create();camera.targetTexture=Target;camera.aspect=(float)size.x/size.y;camera.orthographicSize=MenuFrame.Height*768/432/2;
   draw=new CommandBuffer{name="Original title menu layers"};camera.AddCommandBuffer(CameraEvent.BeforeForwardAlpha,draw);
   yield return "menu target";
   for(int i=0;i<3;i++){ThrowIfDisposed();effects[i]=new RenderTexture(i==0?1152:376,i==0?32:48,0,RenderTextureFormat.ARGB32){filterMode=FilterMode.Bilinear,wrapMode=TextureWrapMode.Clamp};effects[i].Create();yield return "menu shine target";}
   ThrowIfDisposed();Ready=true;
   }finally{loading=false;}
  }
  IEnumerable<object> LoadLayerSteps(string directory,MenuLayer e,bool record,bool background=false){
   if(textures.ContainsKey(e.id))yield break;ThrowIfDisposed();byte[] bytes;
   if(deferred||background){string path=Path.Combine(directory,e.file);var read=WebWorkQueue.Run(()=>File.ReadAllBytes(path));pendingSource=read;while(!read.IsCompleted){ThrowIfDisposed();yield return "menu source read";}ThrowIfDisposed();bytes=read.GetAwaiter().GetResult();pendingSource=null;}
   else bytes=File.ReadAllBytes(Path.Combine(directory,e.file));
   // A legacy synchronous diagnostic may have requested the same record layer
   // while its managed read was pending. Keep exactly one owner of the texture.
   if(textures.ContainsKey(e.id))yield break;
   bool font=record&&e.id.StartsWith("font-");var tex=new Texture2D(2,2,TextureFormat.RGBA32,false,false){name=(record?"Original records ":"Original menu ")+e.id,filterMode=font?FilterMode.Point:FilterMode.Bilinear,wrapMode=TextureWrapMode.Clamp};
   try{if(!tex.LoadImage(bytes,!font))throw new IOException(e.file);textures.Add(e.id,tex);layers.Add(e.id,e);TextureBytes+=(long)tex.width*tex.height*4;}catch{UnityEngine.Object.Destroy(tex);throw;}
   bytes=null;yield return "menu texture "+e.id;
  }
  void ThrowIfDisposed(){if(disposed)throw new ObjectDisposedException(nameof(NativeMenuRenderer));}
  public void SetLeaderIfChanged(NativeRecord leader){
   ThrowIfDisposed();string key=(leader?.score??0)+"|"+(leader?.name??"NOBODY");if(recordMenu&&leaderKey==key)return;SetLeader(leader);leaderKey=key;
  }
  void Stamp(string id,Rect rect,float alpha=1,int pass=0){if(alpha<=0)return;properties.Clear();properties.SetTexture("_MainTex",textures[id]);properties.SetFloat("_Opacity",alpha);properties.SetVector("_UVRect",new Vector4(0,0,1,1));draw.DrawMesh(quad,Matrix4x4.TRS(new Vector3(rect.x,-rect.y,0),Quaternion.identity,new Vector3(rect.width,rect.height,1)),image,0,pass,properties);}
  void Layer(string id,float alpha=1){var e=layers[id];Stamp(id,new Rect(e.x,e.y,e.w,e.h),alpha);}
  void Glow(string id,float x,float y,float w,float h,double alpha)=>Stamp(id,new Rect(x,y,w,h),(float)alpha,1);
  void Focus(int index,double alpha){if(index<0||alpha<=.001)return;string key=NativeMenuState.Keys[index];Layer("focus-"+key,(float)alpha);}
  void FocusGlow(int index,double alpha){if(index<0||alpha<=.001)return;var a=areas[index];Glow("emerald",a.x-18,a.y-14,a.w+36,a.h+28,alpha*.27);}
  void Shine(string mask,float x,float y,float w,float h,int slot,int count,float opacity,float shadow){
   if(count==0)return;var target=effects[slot];var tex=textures[mask];
   // Logical mask dimensions are intentionally the same as the browser buffers.
   if(target.width!=tex.width||target.height!=tex.height){target.Release();target.width=tex.width;target.height=tex.height;target.Create();}
   shine.SetFloat("_MaskWidth",tex.width);shine.SetInt("_Count",count);shine.SetFloatArray("_Lefts",lefts);var previous=RenderTexture.active;Graphics.Blit(tex,target,shine,0);RenderTexture.active=previous;
   float pad=8/Manifest.scale,px=w/tex.width,py=h/tex.height;
   properties.Clear();properties.SetTexture("_MainTex",target);properties.SetFloat("_Opacity",opacity);properties.SetFloat("_ShadowAlpha",shadow);
   properties.SetVector("_Mapping",new Vector4(1+2*pad/w,1+2*pad/h,-pad/w,-pad/h));properties.SetVector("_Pixel",new Vector4(1/(w*Manifest.scale),1/(h*Manifest.scale),0,0));
   draw.DrawMesh(quad,Matrix4x4.TRS(new Vector3(x-pad,-y+pad,0),Quaternion.identity,new Vector3(w+2*pad,h+2*pad,1)),shine,0,1,properties);
  }
  public void Render(NativeMenuState s,double t){
   if(!Ready)throw new InvalidOperationException("Menu renderer is not ready");
   s.Advance(t);EnsureDisplay();draw.Clear();Layer("background");
   float dx=(float)Math.Sin(t*Math.PI*2/14000)*22,dy=(float)Math.Sin(t*Math.PI*2/18000)*10;
   Glow("emerald",-94+dx,409+dy,570,330,.095*(1+.12*Math.Sin(t*Math.PI*2/16000+Math.PI/6)));
   Glow("violet",609-dx,423-dy,510,310,.06*(1+.10*Math.Sin(t*Math.PI*2/18000+Math.PI*1.3)));Glow("emerald",170,68,684,112,.035);
   // Original per-button iteration order is stable even when focus reverses.
   for(int i=0;i<12;i++)Focus(i,i==s.Focus?s.FocusAlpha:i==s.OldFocus?s.OldAlpha:0);
   FocusGlow(s.OldFocus,s.OldAlpha);FocusGlow(s.Focus,s.FocusAlpha);Layer(recordMenu?"menu-chrome":"chrome");if(recordMenu)menuRecord.Draw(this,1);
   for(int i=0;i<6;i++)Layer("label-"+NativeMenuState.Modes[i],(float)s.Alpha(NativeMenuState.Keys[i],t));
   Layer(t<s.ComingUntil?"coming":"hint-"+s.LastMode);
   Layer("difficulty-"+s.Difficulty,(float)s.Alpha("difficulty",t));Layer("speed-"+s.Speed,(float)s.Alpha("speed",t));Layer("quality-"+(s.Quality=="4k"?1:0));Layer("music-"+s.Music,(float)s.Alpha("music",t));string score="score-"+s.Difficulty+"-"+s.Speed;Layer(score);
   double cycle=Math.PI*2*310,phase=t-cycle*4;
   if(phase>=0&&(phase%=cycle*8)<cycle*2.5){double progress=phase/(cycle*2.5),way=progress<=.5?progress*2:(1-progress)*2;double start=(recordMenu?recordLeft:Manifest.highLeft)-88,end=(recordMenu?recordRight:Manifest.highRight)+88-176*.22;lefts[0]=(float)(start+(end-start)*way-88);Shine(recordMenu?"mask-record":"mask-high",256,36,576,16,0,1,.92f,.55f);}
   double age=t-s.ActiveAt;int mode=Array.IndexOf(NativeMenuState.Keys,s.Active);
   if(mode>=0&&mode<6&&age>=0&&age<620){var a=areas[mode];lefts[0]=(float)(-176+(a.w-48+176)*NativeMenuState.Smooth(age/620));Shine("mask-"+s.Active,a.x+24,a.y+13,a.w-48,48,1,1,.96f,.5f);}
   if(s.Shots.Count>0){var e=layers[score];for(int i=0;i<s.Shots.Count;i++)lefts[i]=(float)(-176+(e.w+176)*NativeMenuState.Smooth((t-s.Shots[i])/620));Shine("mask-"+score,e.x,597,e.w,48,2,s.Shots.Count,.96f,.5f);}
   DrawSurround();camera.Render();
  }
  public int Hit(Vector2 logical){for(int i=0;i<areas.Length;i++){var a=areas[i];if(new Rect(a.x,a.y,a.w,a.h).Contains(logical))return i;}return -1;}
  bool disposed;
  public void Dispose(){
   if(disposed)return;disposed=true;Ready=false;DisposeRecords();UnityEngine.Object.Destroy(frameStars);
   // A cancelled candidate has at most one managed read in flight. It may
   // finish independently, but can never publish a Unity texture after dispose.
   if(pendingSource!=null){WebWorkQueue.Continue(pendingSource,t=>{if(t.IsFaulted){var ignored=t.Exception;}});pendingSource=null;}
   if(camera){if(draw!=null)camera.RemoveCommandBuffer(CameraEvent.BeforeForwardAlpha,draw);camera.targetTexture=null;}draw?.Dispose();draw=null;
   foreach(var t in textures.Values)UnityEngine.Object.Destroy(t);textures.Clear();layers.Clear();TextureBytes=0;
   foreach(var t in effects){if(!t)continue;if(RenderTexture.active==t)RenderTexture.active=null;t.Release();UnityEngine.Object.Destroy(t);}
   if(Target){if(RenderTexture.active==Target)RenderTexture.active=null;Target.Release();UnityEngine.Object.Destroy(Target);Target=null;}
   UnityEngine.Object.Destroy(image);UnityEngine.Object.Destroy(shine);UnityEngine.Object.Destroy(quad);if(camera)UnityEngine.Object.Destroy(camera.gameObject);
  }
 }
}

using System;
using System.Runtime.InteropServices;
using UnityEngine;

namespace MazeBiters.NativeStudy {
 // CSS viewport × device-pixel ratio is independent of the current Unity
 // render buffer. Reading Screen.width here would halve repeatedly in HD.
 public static class IPhoneViewport {
  public static readonly Vector2Int ReferencePixels=new Vector2Int(2868,1320);
  static Vector2Int pixels=ReferencePixels;
  static int sampledFrame=-1;
  static double revision=double.NaN;
  static bool stable=true,portrait;
#if UNITY_WEBGL && !UNITY_EDITOR
  [DllImport("__Internal")] static extern double MBIphoneViewport(int field);
#endif
  static void Refresh(){
#if UNITY_WEBGL && !UNITY_EDITOR
   if(sampledFrame==Time.frameCount)return;sampledFrame=Time.frameCount;
   stable=MBIphoneViewport(7)>.5;portrait=MBIphoneViewport(8)>.5;
   double next=MBIphoneViewport(6);if(next==revision)return;
   // Portrait is covered and suspended by the page. Retain the last landscape
   // resources rather than allocating an intermediate portrait render target.
   if(portrait)return;
   double width=MBIphoneViewport(0),height=MBIphoneViewport(1);
   if(!double.IsFinite(width)||!double.IsFinite(height)||width<1||height<1||width<height)return;
   revision=next;
   pixels=ConstrainNative(width,height);
#endif
  }
  public static Vector2Int NativePixels{get{Refresh();return pixels;}}
  // The page owns hysteresis and the 180 ms layout debounce. A second delay
  // here would resume gameplay before its render target accepted the new size.
  public static bool Stable{get{Refresh();return stable&&!portrait;}}
  public static Vector2Int ConstrainNative(double width,double height){
   if(!double.IsFinite(width)||!double.IsFinite(height)||width<1||height<1)return ReferencePixels;
   bool portrait=height>width;int maxW=portrait?1320:2868,maxH=portrait?2868:1320;
   double scale=Math.Min(1,Math.Min(maxW/width,maxH/height));
   return new Vector2Int(Math.Max(1,Math.Min(maxW,(int)Math.Floor(width*scale+.5))),Math.Max(1,Math.Min(maxH,(int)Math.Floor(height*scale+.5))));
  }
  public static Vector2Int Resolution(Vector2Int native,string quality){
   var bounded=ConstrainNative(Math.Max(1,native.x),Math.Max(1,native.y));int w=bounded.x,h=bounded.y;
   return quality=="4k"?new Vector2Int(w,h):new Vector2Int((w+1)/2,(h+1)/2);
  }
  public static Vector2Int Pixels(string quality){
   Refresh();
   return Resolution(pixels,quality);
  }
  public static double CloseZoom(NativeFrame frame,Vector2Int native)=>Math.Max(1,Math.Min(2.6,160.0*frame.Height/(16*Math.Max(1,native.y))));
 }
}

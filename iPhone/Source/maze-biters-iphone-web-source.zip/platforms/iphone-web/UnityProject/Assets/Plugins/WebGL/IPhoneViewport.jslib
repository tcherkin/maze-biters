mergeInto(LibraryManager.library, {
 MBIphoneViewport: function(field) {
  var v=window.mazePhoneViewport;
  if(!v)return field===0?2868:field===1?1320:field===7?1:0;
  switch(field){case 0:return v.nativeWidth;case 1:return v.nativeHeight;case 2:return v.left;case 3:return v.right;case 4:return v.top;case 5:return v.bottom;case 6:return v.revision;case 7:return v.stable;case 8:return v.portrait;default:return 0;}
 },
 MBIphoneQuality: function(nativeQuality) {if(window.mazePhoneSetQuality)window.mazePhoneSetQuality(nativeQuality);}
});

MAZE BITERS — IPHONE WEB

Independent landscape Unity WebGL2 release at:
https://tcherkin.github.io/maze-biters/iPhone/

The game and starfield occupy Kiosker's available viewport without stretching.
For iPhone 17 Pro Max the 4K-labelled high-detail setting uses native 2868x1320;
HD uses 1434x660. Existing menu artwork/proportions are retained.

Tap Start once for audio. Menu-first loading and pending-start blinking remain.
Scores/preferences are isolated from iPad and PC. All six modes are retained.
No physical iPhone/Kiosker hardware performance claim is made by desktop checks.

Rebuild using Unity 6000.6.3f1 with Web Build Support; see DEPLOYMENT.md.
Runtime artwork packs are immutable shared PC resources protected by release
fingerprints and external dependency pins. Music/SFX source files in the compact
source archive are reconstructed from fixed commit 421d8d09ddfb8d84cd188df796e43b8ef454a1ba.
The played audio is compiled into this edition's runtime.

Native PC, native iPad, PC Web, iPad Web and the original game are independent.

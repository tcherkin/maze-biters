# Rebuilding and publishing the iPhone web edition

This isolated project lives at `platforms/iphone-web`. Use Unity 6000.6.3f1 and
Web Build Support. Its product is a landscape full-viewport iPhone edition;
existing PC/iPad/browser projects are not its build output.

## Restore a downloaded source archive

1. Extract `Source/maze-biters-iphone-web-source.zip` at a workspace root.
2. Clone the published `tcherkin/maze-biters` repository, retaining its `iPhone/`,
   `PC/` and `assets/audio` directories and Git history.
3. Run from the extracted workspace:

```text
python platforms/iphone-web/restore-source-assets.py <repository>/iPhone/StreamingAssets/WebPayload --repository <repository>
```

The tool validates both compressed packs and all individual files, recreates
`SourceAssets`, and materializes an independent local payload in `WebPayload`
and `UnityProject/Assets/StreamingAssets/WebPayload`. It removes the external
`packBase` from those reconstructed local manifests, so development builds use
local packs. Published manifests and shared PC files are never overwritten.

`audio-source-manifest.json` pins original audio to commit
`421d8d09ddfb8d84cd188df796e43b8ef454a1ba`. Every restored audio file is checked
against its byte count and SHA256; existing changed files are not overwritten.
When `--repository` is omitted, only these pinned original audio files are
fetched from `raw.githubusercontent.com`, never mutable `main` URLs. Their `.meta`
files and the complete independent Unity code/settings are already in the ZIP.

Full legacy desktop validation commands may need separate development fixtures;
they are not required for building the interactive web release.

## Build locally

For changed art/sound, regenerate the source payload with:

```text
python platforms/iphone-web/export-web-sfx.py
python platforms/iphone-web/pack-web-assets.py
```

Copy the canonical manifest and its hash-named packs into the Unity project's
`Assets/StreamingAssets/WebPayload`. Keep uncompressed `SourceAssets` outside
`UnityProject/Assets`. Build with the installed Unity executable:

```text
-batchmode -quit -projectPath platforms/iphone-web/UnityProject -buildTarget WebGL -executeMethod WebBuild.Build -logFile web-build.log
```

Output: `platforms/iphone-web/Builds/iPhone`. The build has its own WebGL runtime,
loader and build GUID. Gzip decompression fallback works on GitHub Pages without
custom server headers. Serve through HTTP, not `file://`.

For iPhone 17 Pro Max high-detail (`4K` in the original menu) means native 2868×1320,
HD 1434×660. It does not impose desktop 3840×2160. Validate viewport resizing,
landscape, touch input, menu selection while loading, audio after gesture,
background/foreground, restart, all modes, and performance on the actual phone.
The browser preview is not a hardware performance benchmark.

## Prepare an additive release

Use an independent checkout at `platforms/iphone-web/Publish`, origin
`https://github.com/tcherkin/maze-biters.git`, clean outside `iPhone/`, with HEAD
equal to the fetched `origin/main`.

```text
python platforms/iphone-web/prepare-publication.py
python platforms/iphone-web/Results/audit/audit-publication.py --reconstruct
```

The publisher changes only `Publish/iPhone/`. It selects the four Unity resources
actually referenced by the generated HTML, adds a source ZIP and creates exact
release hashes. Canonical and GUID manifests are identical and have the single
allowed `packBase` value `../../../PC/StreamingAssets/WebPayload/`.

Only packs whose filenames, SHA256 hashes and byte counts exactly match existing
PC resources may be shared. The current release shares 41 unchanged packs. A pack
change requires a reviewed new immutable resource delivery plan; never replace a
published hash URL with different bytes. Local build packs remain untouched.

`release.json.externalDependencies` pins every shared resource. The local PC
publisher's `external_runtime_records` and `retain_external_dependencies` guards
retain these assets even after multiple later PC releases. A reference copy is
included as `pc-publication-pin-reference.py`; it is a PC publisher reference,
not an iPhone entry point. Carry those guards into any independently reconstructed
PC publishing tool before its next cleanup. Do not delete or rename resources
referenced by any edition's external dependencies.

The compact source archive excludes duplicated audio binaries, and its source
manifest covers all included code/meta/settings plus audio reconstruction metadata.
Current game audio is compiled into iPhone's own runtime, not dependent on those
source restoration URLs during play.

The complete site must remain below 990,000,000 bytes, and each file below 100 MiB.
Do not remove existing PC/iPad assets to make room. Previous iPhone runtime files
are retained for one generation for cached pages; this may require a different
hosting plan once updates no longer fit the overall budget.

After review, stage only `iPhone/`, then verify:

```text
python platforms/iphone-web/Results/audit/audit-publication.py --staged
```

Fetch main before publishing, preserving concurrent changes. Existing Pages
publishes from main at repository root. No Pages configuration change is needed.
After deployment, run `audit-publication.py --public`, check the public URL in a
browser, and confirm all pre-existing root/PC/iPad files remain byte-identical.

`Results/audit/test-publication-retention.py` uses tiny isolated fixtures and
also checks shared PC pack retention and tamper rejection. It never publishes.

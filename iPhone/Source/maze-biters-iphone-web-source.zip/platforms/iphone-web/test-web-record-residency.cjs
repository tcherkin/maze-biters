const fs = require('node:fs');
const path = require('node:path');
const assert = require('node:assert/strict');
const root = __dirname;
const scripts = path.join(root, 'UnityProject/Assets/Scripts');
const read = name => fs.readFileSync(path.join(scripts, name + '.cs'), 'utf8');
let checks = 0;
const check = (value, message) => {checks++; assert(value, message);};
const loading = read('NativeMenuArtworkLoading');
const menuReady = loading.match(/bool MenuArtworkReady=>([^;]+);/)[1];
check(!/RecordsReady|RecordTrackReady/.test(menuReady), 'Game readiness must not depend on unopened records or their music');
check(loading.includes('if(records!=null&&renderer.Manifest.quality==State.Quality&&!RecordArtworkReady'), 'Record artwork starts only for a requested record screen');
check(loading.includes('records==requested&&requested.Entry&&!gameplay'), 'High score music prepares only for a still-current name-entry request');
const renderer = read('NativeMenuRenderer');
const startup = renderer.slice(renderer.indexOf('public IEnumerable<object> LoadSteps()'),renderer.indexOf('IEnumerable<object> LoadLayerSteps'));
check(!startup.includes('PrepareRecordsSteps'), 'Ordinary menu startup must not prepare full records');
check(startup.includes('PrepareMenuRecordSteps'), 'Original live leader caption remains available');
const records = read('NativeMenuRecords');
const openEntry = records.slice(records.indexOf('void OpenEntry('),records.indexOf('void BeginRecordPresentation('));
check(!openEntry.includes('Audio.SetMenuTrack'), 'Entering records must not invoke blocking music load before readiness');
check(records.includes('if(!RecordArtworkReady)throw new InvalidOperationException'), 'Original entry music starts only after asynchronous readiness');
check(records.includes('records=null;ReleaseRecordArtwork();'), 'Leaving records releases their screen-specific textures');
check(read('NativeMenu').includes('ReleaseRecordArtwork();'), 'Starting gameplay releases record-only artwork');
const recordRenderer = read('NativeRecordRenderer');
check(recordRenderer.includes('if(!RecordsReady)throw new InvalidOperationException'), 'Drawing must never implicitly load the screen');
check(recordRenderer.includes('if(recordPreparing)throw new InvalidOperationException'), 'Unsafe release during preparation is rejected');
const release = recordRenderer.slice(recordRenderer.indexOf('public void ReleaseRecordScreen()'), recordRenderer.indexOf('void EnsureRecordManifest()'));
check(release.includes('var pending=pendingSource;pendingSource=null;'), 'Closing records detaches the canceled source read from the retained menu');
check(release.includes('WebWorkQueue.Continue(pending,t=>{if(t.IsFaulted){var ignored=t.Exception;}})'), 'Detached reads still observe errors without publishing a texture');
check(!/GetAwaiter|\.Wait\(|\.Result/.test(release), 'Closing records never waits synchronously for an in-flight read');
check(loading.includes('pending?.Dispose();'), 'Cancellation disposes the owned iterator so re-opening can proceed');
check(!loading.slice(loading.indexOf('IEnumerator LoadRecordArtwork'),loading.indexOf('IEnumerator LoadMenuArtwork')).includes('FailMenuPreparation'), 'Record load failure must not poison game startup');
const partitions = [];
for (const quality of ['hd','4k']) {
  const directory = path.join(root,'SourceAssets/Reference/records');
  const manifest = JSON.parse(fs.readFileSync(path.join(directory,quality+'.json'),'utf8'));
  let sharedBytes=0, screenBytes=0, sharedCount=0, screenCount=0;
  const names = new Set();
  for (const e of manifest.entries) {
    check(!names.has(e.id), quality+' unique record layer '+e.id); names.add(e.id);
    const png = fs.readFileSync(path.join(directory,e.file));
    check(png.subarray(0,8).equals(Buffer.from([137,80,78,71,13,10,26,10])), quality+' PNG '+e.id);
    const bytes=png.readUInt32BE(16)*png.readUInt32BE(20)*4;
    if(e.id==='menu-chrome'||e.id.startsWith('font-')){sharedBytes+=bytes; sharedCount++;}
    else{screenBytes+=bytes; screenCount++;}
  }
  check(sharedCount===3, quality+' retains chrome and two original font atlases');
  check(screenBytes===(quality==='4k'?80852784:20624912), quality+' exact unchanged-source residency reduction');
  partitions.push({quality,sharedCount,screenCount,sharedBytes,screenBytes});
}
console.log(JSON.stringify({passed:true,checks,partitions,note:'Policy and unchanged PNG dimensions. Run WebRecordResidencyValidation for actual Unity pixel/lifecycle validation.'},null,2));

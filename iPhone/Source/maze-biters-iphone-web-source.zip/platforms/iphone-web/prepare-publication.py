"""Stage an already-tested web build under iPhone/; never commit or push it."""
from pathlib import Path
import argparse
import hashlib
import json
import re
import shutil
import subprocess
import zipfile

HERE = Path(__file__).resolve().parent
CHECKOUT = HERE / "Publish"
BUILD = HERE / "Builds/iPhone"
MAX_FILE = 100 * 1024 * 1024
PAYLOAD_ROOT = "StreamingAssets/WebPayload/"
SHARED_ROOT = "PC/" + PAYLOAD_ROOT
PACK_BASE = "../../../PC/StreamingAssets/WebPayload/"
SOURCE_COMMIT = "421d8d09ddfb8d84cd188df796e43b8ef454a1ba"
RAW_BASE = "https://raw.githubusercontent.com/tcherkin/maze-biters/"


def digest(path):
    with path.open("rb") as stream:
        return hashlib.file_digest(stream, "sha256").hexdigest()


def safe(root, relative):
    relative = relative.as_posix() if isinstance(relative, Path) else relative
    if not relative or "\\" in relative or Path(relative).is_absolute() or ".." in Path(relative).parts:
        raise ValueError("Unsafe relative path")
    path = (root / relative).resolve()
    if not path.is_relative_to(root.resolve()):
        raise ValueError("Path escapes intended directory")
    return path


def git(*args):
    return subprocess.check_output(["git", "-C", str(CHECKOUT), *args], text=True).rstrip("\r\n")


def git_blob(commit, path):
    return subprocess.check_output(["git", "-C", str(CHECKOUT), "show", commit + ":" + path])


def hidden_data_path(relative):
    if not re.fullmatch(r"Build/[0-9a-f]{32}\.data\.unityweb", relative):
        raise ValueError("Only the immutable Unity data file can use raw Git hosting")
    return ".runtime/" + Path(relative).name


def require_hidden_runtime_exclusion():
    # This repository uses default branch-based Jekyll Pages. A future change
    # to that contract must be reviewed rather than silently exceeding its cap.
    if (CHECKOUT / ".nojekyll").exists() or (CHECKOUT / "_config.yml").exists():
        raise ValueError("Raw data staging requires the unchanged default Jekyll exclusion policy")


def external_data_record(commit, relative, file):
    require_hidden_runtime_exclusion()
    if not re.fullmatch(r"[0-9a-f]{40}", commit):
        raise ValueError("Unity data must be pinned to a complete immutable Git commit")
    if git("rev-parse", commit + "^{commit}") != commit:
        raise ValueError("Unity data commit does not resolve exactly")
    git("merge-base", "--is-ancestor", commit, "HEAD")
    repository_path = "iPhone/" + hidden_data_path(relative)
    blob = git_blob(commit, repository_path)
    fingerprint = {"bytes": file.stat().st_size, "sha256": digest(file)}
    if len(blob) != fingerprint["bytes"] or hashlib.sha256(blob).hexdigest() != fingerprint["sha256"]:
        raise ValueError("Pinned data differs from the tested build")
    return {"kind": "unity-data", "path": relative, "repositoryPath": repository_path, "commit": commit, "url": RAW_BASE + commit + "/" + repository_path, **fingerprint}


def external_build_compatibility(baseline, current, build_guid):
    previous = baseline.get("compatibilityExternalBuildFiles", []) if baseline.get("buildGuid") == build_guid else baseline.get("currentExternalBuildFiles", [])
    urls = {item["url"] for item in current}
    return [item for item in previous if item["url"] not in urls]


def bind_external_data(index, entry):
    cache = "cacheControl:url=>'must-revalidate'"
    if index.count(entry["path"]) != 1 or index.count(cache) != 1:
        raise ValueError("Unexpected data/cache binding in the tested HTML")
    # Raw Git does not expose validators to browser JavaScript. Unity's own
    # immutable cache mode avoids an unnecessary full GET on every later start.
    # Only this exact commit-pinned URL qualifies; every other URL revalidates.
    binding = "cacheControl:url=>url===" + json.dumps(entry["url"]) + "?'immutable':'must-revalidate'"
    return index.replace(entry["path"], entry["url"]).replace(cache, binding)


def immutable_runtime_path(name):
    return name.startswith("Build/") or bool(re.fullmatch(re.escape(PAYLOAD_ROOT) + r"manifest-[0-9a-fA-F]{32}\.json", name)) or name.startswith(PAYLOAD_ROOT) and name.endswith(".mbpack.gz")


def preflight_runtime(destination, baseline, candidates):
    """Reject immutable collisions before touching any published file."""
    for entry in baseline.get("files", []):
        if not immutable_runtime_path(entry["path"]):
            continue
        file = safe(destination, entry["path"])
        if not file.is_file() or file.stat().st_size != entry["bytes"] or digest(file) != entry["sha256"]:
            raise ValueError("An existing immutable runtime was modified before publication: " + entry["path"])
    for name, evidence in candidates.items():
        if not immutable_runtime_path(name):
            continue
        file = safe(destination, name)
        if file.exists() and (not file.is_file() or file.stat().st_size != evidence["bytes"] or digest(file) != evidence["sha256"]):
            raise ValueError("Publication would overwrite an immutable runtime URL: " + name)


def committed_release():
    result = subprocess.run(["git", "-C", str(CHECKOUT), "show", "HEAD:iPhone/release.json"], capture_output=True)
    if result.returncode:
        return {}
    return json.loads(result.stdout)


def compatibility_records(baseline, current, build_guid=None):
    """Retain the previous release's own runtime, never its inherited runtime."""
    guid = baseline.get("buildGuid")
    previous_manifest = PAYLOAD_ROOT + ("manifest-" + guid + ".json" if guid else "manifest.json")
    latest = {entry["path"]: entry for entry in current}
    retained = []
    same_build = bool(build_guid and guid == build_guid)
    entries = baseline.get("compatibilityFiles", []) if same_build else baseline.get("currentFiles", baseline.get("files", []))
    for entry in entries:
        name = entry["path"]
        runtime = same_build or name.startswith("Build/") or name == previous_manifest or name.startswith(PAYLOAD_ROOT) and name.endswith(".mbpack.gz")
        if not runtime:
            continue
        if name in latest:
            if latest[name]["sha256"] != entry["sha256"] or latest[name]["bytes"] != entry["bytes"]:
                raise ValueError("Current build would overwrite an immutable previous runtime resource: " + name)
        else:
            retained.append(entry)
    return retained


def source_archive(destination):
    files = []
    audio_sources = []
    project = HERE / "UnityProject"
    for directory in ("Assets", "Packages", "ProjectSettings"):
        for file in (project / directory).rglob("*"):
            if not file.is_file():
                continue
            relative = file.relative_to(project).as_posix()
            # Content is already published in the hash packs, not duplicated in
            # this archive. Keep StreamingAssets.meta for its stable folder GUID.
            if relative.startswith("Assets/StreamingAssets/"):
                continue
            if relative.startswith("Assets/Resources/SessionAudio/") and file.suffix.lower() in (".mp3", ".wav"):
                kind = "music" if file.suffix.lower() == ".mp3" else "sfx"
                repository_path = "assets/audio/" + kind + "/" + file.name
                committed = subprocess.check_output(["git", "-C", str(CHECKOUT), "show", SOURCE_COMMIT + ":" + repository_path])
                if committed != file.read_bytes():
                    raise ValueError("Audio differs from pinned reconstruction source: " + relative)
                audio_sources.append({"path": "UnityProject/" + relative, "repositoryPath": repository_path, "bytes": len(committed), "sha256": hashlib.sha256(committed).hexdigest()})
                continue
            files.append((file, "UnityProject/" + relative))
    helpers = ("restore-source-assets.py", "pc-publication-pin-reference.py", "pack-web-assets.py", "prepare-publication.py", "export-web-sfx.py", "DEPLOYMENT.md", "README-WEB.md", "README.txt", "Results/audit/test-publication-retention.py", "Results/audit/web-shell-contract.cjs", "Results/audit/iphone-shell-contract.cjs", "Results/audit/audit-publication.py", "Results/audit/pre-publication-baseline.json")
    helpers += tuple(path.name for path in HERE.glob("test-web-*.cjs"))
    for name in helpers:
        file = HERE / name
        if not file.is_file():
            raise FileNotFoundError(name)
        files.append((file, name))
    archive_root = "platforms/iphone-web/"
    source_manifest = []
    private_path = re.compile(r"(?:[A-Za-z]:[\\/](?:Users|Program Files)|\x2fUsers\x2f|\x2fhome\x2f[^ /]+\x2f)", re.IGNORECASE)
    text_extensions = {".cs", ".shader", ".json", ".asset", ".unity", ".py", ".md", ".js", ".jslib", ".cjs", ".html", ".meta", ".txt"}
    with zipfile.ZipFile(destination, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
        for file, relative in sorted(files, key=lambda item: item[1]):
            safe(project if relative.startswith("UnityProject/") else HERE, file.relative_to(project if relative.startswith("UnityProject/") else HERE))
            data = file.read_bytes()
            if file.suffix.lower() in text_extensions:
                text = data.decode("utf-8-sig")
                if private_path.search(text):
                    raise ValueError("Local machine path in public source: " + relative)
            info = zipfile.ZipInfo(archive_root + relative, date_time=(1980, 1, 1, 0, 0, 0))
            info.compress_type = zipfile.ZIP_DEFLATED
            info.external_attr = 0o100644 << 16
            archive.writestr(info, data)
            source_manifest.append({"path": relative, "bytes": len(data), "sha256": hashlib.sha256(data).hexdigest()})
        audio_manifest = {"version": 1, "repository": "https://github.com/tcherkin/maze-biters", "commit": SOURCE_COMMIT, "rawBase": "https://raw.githubusercontent.com/tcherkin/maze-biters/" + SOURCE_COMMIT + "/", "files": audio_sources}
        audio_data = (json.dumps(audio_manifest, indent=2) + "\n").encode()
        info = zipfile.ZipInfo(archive_root + "audio-source-manifest.json", date_time=(1980, 1, 1, 0, 0, 0))
        info.compress_type = zipfile.ZIP_DEFLATED
        archive.writestr(info, audio_data)
        source_manifest.append({"path": "audio-source-manifest.json", "bytes": len(audio_data), "sha256": hashlib.sha256(audio_data).hexdigest()})
        info = zipfile.ZipInfo(archive_root + "source-manifest.json", date_time=(1980, 1, 1, 0, 0, 0))
        info.compress_type = zipfile.ZIP_DEFLATED
        archive.writestr(info, json.dumps({"version": 1, "files": source_manifest}, indent=2) + "\n")
    with zipfile.ZipFile(destination) as archive:
        if archive.testzip() is not None:
            raise ValueError("Source ZIP verification failed")
    return len(source_manifest)


def shared_dependencies(payload):
    dependencies = []
    for item in payload["packs"]:
        name = item["file"]
        if not re.fullmatch(r"(?:menu|runtime)-[0-9a-f]{20}\.mbpack\.gz", name):
            raise ValueError("Invalid immutable pack name")
        path = SHARED_ROOT + name
        file = safe(CHECKOUT, path)
        if not file.is_file() or file.stat().st_size != item["bytes"] or digest(file) != item["sha256"]:
            raise ValueError("Shared PC pack is missing or differs; no existing resource may be replaced: " + path)
        dependencies.append({"kind": "runtime", "path": path, "bytes": item["bytes"], "sha256": item["sha256"]})
    return dependencies


def compatibility_dependencies(baseline, current, build_guid):
    """Cached previous HTML still needs the packs referenced by its own manifest."""
    same_build = baseline.get("buildGuid") == build_guid
    previous = baseline.get("compatibilityDependencies", []) if same_build else baseline.get("currentExternalDependencies", baseline.get("externalDependencies", []))
    latest = {item["path"]: item for item in current}
    retained = []
    for item in previous:
        path = item.get("path", "")
        if item.get("kind") != "runtime" or not re.fullmatch(r"PC/StreamingAssets/WebPayload/(?:menu|runtime)-[0-9a-f]{20}\.mbpack\.gz", path):
            raise ValueError("Invalid previous external dependency")
        file = safe(CHECKOUT, path)
        if not file.is_file() or file.stat().st_size != item["bytes"] or digest(file) != item["sha256"]:
            raise ValueError("Previous shared runtime missing or modified: " + path)
        if path in latest:
            if latest[path] != item:
                raise ValueError("Shared runtime fingerprint collision: " + path)
        else:
            retained.append(item)
    return retained


def main(data_commit=None, prepare_data_only=False):
    if HERE.name != "iphone-web" or HERE.parent.name != "platforms":
        raise ValueError("Unexpected working project")
    if git("remote", "get-url", "origin") != "https://github.com/tcherkin/maze-biters.git":
        raise ValueError("Deployment checkout has an unexpected origin")
    if git("rev-parse", "HEAD") != git("rev-parse", "origin/main"):
        raise ValueError("Deployment HEAD must equal the fetched origin/main before staging")
    for line in git("status", "--porcelain", "--untracked-files=all").splitlines():
        if line and not line[3:].replace("\\", "/").startswith("iPhone/"):
            raise ValueError("Deployment contains changes outside iPhone/: " + line)
    if not (BUILD / "index.html").is_file():
        raise ValueError("Build output is incomplete: index.html missing")
    info = json.loads((BUILD / "build-info.json").read_text(encoding="utf-8-sig"))
    guid = info["buildGuid"]
    if not re.fullmatch(r"[0-9a-fA-F]{32}", guid) or info["assetManifest"] != "manifest-" + guid + ".json":
        raise ValueError("Invalid build/asset manifest identity")
    index = (BUILD / "index.html").read_text(encoding="utf-8-sig")
    build_paths = set(re.findall(r"Build/[^\s'\"<>?]+", index))
    if len(build_paths) != 4 or not any(".wasm" in name for name in build_paths):
        raise ValueError("Current HTML must reference the four Unity build resources")
    if any(not safe(BUILD, name).is_file() for name in build_paths):
        raise ValueError("An HTML-referenced Unity resource is missing")
    data_relative = next(name for name in build_paths if name.endswith(".data.unityweb"))
    data_file = safe(BUILD, data_relative)
    if prepare_data_only:
        if data_commit:
            raise ValueError("Prepare the hidden data commit before selecting its commit")
        require_hidden_runtime_exclusion()
        target = safe(CHECKOUT, "iPhone/" + hidden_data_path(data_relative))
        target.parent.mkdir(parents=True, exist_ok=True)
        if target.exists() and digest(target) != digest(data_file):
            raise ValueError("Refusing to replace an immutable hidden runtime")
        if data_file.stat().st_size >= MAX_FILE:
            raise ValueError("Unity data exceeds the safe Git file limit")
        shutil.copy2(data_file, target)
        print(json.dumps({"preparedDataOnly": True, "path": target.relative_to(CHECKOUT).as_posix(), "bytes": target.stat().st_size, "sha256": digest(target), "entryPagesChanged": False, "committed": False, "pushed": False}, indent=2))
        return
    external_build = [external_data_record(data_commit, data_relative, data_file)] if data_commit else []
    destination = safe(CHECKOUT, "iPhone")
    destination.mkdir(parents=True, exist_ok=True)
    previous = destination / "release.json"
    managed = []
    if previous.is_file():
        managed = json.loads(previous.read_text(encoding="utf-8"))["files"]
    baseline = committed_release()
    expected = set()
    payload = json.loads((BUILD / PAYLOAD_ROOT / "manifest.json").read_text(encoding="utf-8"))
    canonical = BUILD / PAYLOAD_ROOT / "manifest.json"
    versioned = BUILD / PAYLOAD_ROOT / info["assetManifest"]
    if versioned.read_bytes() != canonical.read_bytes():
        raise ValueError("Versioned manifest differs from canonical restore manifest")
    if payload.get("packBase", "") not in ("", PACK_BASE):
        raise ValueError("Unexpected source asset base")
    dependencies = shared_dependencies(payload)
    published_payload = dict(payload, packBase=PACK_BASE)
    published_manifest = (json.dumps(published_payload, indent=2) + "\n").encode()
    candidates = {name: {"bytes": safe(BUILD, name).stat().st_size, "sha256": digest(safe(BUILD, name))} for name in build_paths if not external_build or name != data_relative}
    candidates[PAYLOAD_ROOT + info["assetManifest"]] = {"bytes": len(published_manifest), "sha256": hashlib.sha256(published_manifest).hexdigest()}
    preflight_runtime(destination, baseline, candidates)
    # Preserve byte-for-byte checksums even when the parent repository enables
    # text normalization. This policy applies only inside the published iPhone/.
    (destination / ".gitattributes").write_bytes(b"# Release checksums require the exact generated bytes.\n* -text !eol\n")
    expected.add(".gitattributes")
    allowed_payload = {PAYLOAD_ROOT + "manifest.json", PAYLOAD_ROOT + info["assetManifest"]}
    for file in sorted(BUILD.rglob("*")):
        if not file.is_file() or file.suffix == ".meta":
            continue
        relative = file.relative_to(BUILD).as_posix()
        if relative.startswith("Build/") and relative not in build_paths:
            continue
        if external_build and relative == data_relative:
            continue
        if relative.startswith("StreamingAssets/") and relative not in allowed_payload:
            continue
        if file.stat().st_size >= MAX_FILE:
            raise ValueError("Build file exceeds safe Git limit: " + relative)
        target = safe(destination, relative)
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(file, target)
        expected.add(relative)
    if external_build:
        entry = external_build[0]
        published_index = bind_external_data(index, entry)
        (destination / "index.html").write_text(published_index, encoding="utf-8")
    for name in ("manifest.json", info["assetManifest"]):
        safe(destination / PAYLOAD_ROOT, name).write_bytes(published_manifest)
    shutil.copy2(HERE / "README-WEB.md", destination / "README.md")
    expected.add("README.md")
    archive = safe(destination, "Source/maze-biters-iphone-web-source.zip")
    archive.parent.mkdir(parents=True, exist_ok=True)
    count = source_archive(archive)
    if archive.stat().st_size >= MAX_FILE:
        raise ValueError("Source archive exceeds safe Git limit")
    expected.add("Source/maze-biters-iphone-web-source.zip")
    current = [{"path": name, "bytes": (destination / name).stat().st_size, "sha256": digest(destination / name)} for name in sorted(expected) if name != ".gitattributes"]
    compatibility = compatibility_records(baseline, current, guid)
    compatibility_pins = compatibility_dependencies(baseline, dependencies, guid)
    compatibility_build = external_build_compatibility(baseline, external_build, guid)
    for entry in compatibility:
        file = safe(destination, entry["path"])
        if not file.is_file() or file.stat().st_size != entry["bytes"] or digest(file) != entry["sha256"]:
            raise ValueError("Previous runtime resource is missing or was modified: " + entry["path"])
        expected.add(entry["path"])
    # Remove only files owned by our previous release manifest, and only when
    # still byte-identical to that manifest. Never recursively delete a folder.
    for old in managed:
        if old["path"] in expected:
            continue
        file = safe(destination, old["path"])
        if file.is_file():
            if digest(file) != old["sha256"]:
                raise ValueError("Refusing to remove modified previous artifact: " + old["path"])
            file.unlink()
    evidence = sorted(current + compatibility, key=lambda entry: entry["path"])
    root_bytes = 0
    for line in git("ls-tree", "-rl", "HEAD").splitlines():
        metadata, name = line.split("\t", 1)
        if not name.startswith("iPhone/"):
            root_bytes += int(metadata.split()[-1])
    total_bytes = sum(entry["bytes"] for entry in evidence)
    if root_bytes + total_bytes >= 990000000:
        raise ValueError("Published site would exceed the safe GitHub Pages size budget")
    if any(entry["bytes"] >= MAX_FILE for entry in evidence):
        raise ValueError("A retained artifact exceeds the safe Git file limit")
    # GitHub Pages deliberately omits dotfiles. Keep repository metadata out of
    # the served-artifact manifest rather than advertising an expected HTTP 404.
    repository_only = [".gitattributes"] + sorted(file.relative_to(destination).as_posix() for file in (destination / ".runtime").glob("*.data.unityweb"))
    report = {"version": 4, "product": "Maze Biters iPhone Web", "engine": "Unity 6000.6.3f1", "baseCommit": git("rev-parse", "HEAD"), "buildGuid": guid, "assetManifest": PAYLOAD_ROOT + info["assetManifest"], "sourceFiles": count, "sourceAudioCommit": SOURCE_COMMIT, "runtimeFiles": payload["verifiedFiles"], "repositoryOnlyFiles": repository_only, "currentFiles": current, "compatibilityFiles": compatibility, "currentExternalDependencies": dependencies, "compatibilityDependencies": compatibility_pins, "externalDependencies": dependencies + compatibility_pins, "currentExternalBuildFiles": external_build, "compatibilityExternalBuildFiles": compatibility_build, "externalBuildFiles": external_build + compatibility_build, "files": evidence, "totalBytes": total_bytes, "siteBytes": root_bytes + total_bytes}
    (destination / "release.json").write_text(json.dumps(report, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({"prepared": True, "directory": "Publish/iPhone", "files": len(evidence) + 2, "sourceFiles": count, "sharedPacks": len(dependencies), "totalMiB": round(report["totalBytes"] / 1048576, 3), "sourceZipMiB": round(archive.stat().st_size / 1048576, 3), "baseCommit": report["baseCommit"], "committed": False, "pushed": False}, indent=2))


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--prepare-data-only", action="store_true", help="Copy only the new Unity data to iPhone/.runtime for an additive preliminary commit; does not change any entry page")
    parser.add_argument("--data-commit", help="Use exact tested Unity data from this already-published immutable Git commit instead of duplicating it in Pages")
    options = parser.parse_args()
    main(options.data_commit, options.prepare_data_only)

"""Read-only local/public iPhone release verification; evidence stays outside Publish."""
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor
from urllib.request import Request, urlopen
from urllib.parse import urlsplit
import argparse
import hashlib
import json
import re
import subprocess
import tempfile
import zipfile

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]
CHECKOUT = ROOT / "Publish"
DESTINATION = CHECKOUT / "iPhone"
BASE = "https://tcherkin.github.io/maze-biters/"
HEADERS = ("Content-Type", "Content-Encoding", "Content-Length", "Cache-Control", "ETag")


def sha(data):
    return hashlib.sha256(data).hexdigest()


def git(*args):
    return subprocess.check_output(["git", "-C", str(CHECKOUT), *args])


def safe(root, relative):
    path = (root / relative).resolve()
    if not relative or Path(relative).is_absolute() or not path.is_relative_to(root.resolve()):
        raise ValueError("Unsafe release path")
    return path


def remote(name, expected):
    request = Request(BASE + name, headers={"User-Agent": "Maze-Biters-iPhone-release-integrity"})
    with urlopen(request, timeout=120) as response:
        digest = hashlib.sha256()
        size = 0
        while blob := response.read(1048576):
            digest.update(blob)
            size += len(blob)
        result = {"path": name, "status": response.status, "bytes": size, "sha256": digest.hexdigest(), "headers": {k: response.headers.get(k) for k in HEADERS if response.headers.get(k)}}
    result["passed"] = result["status"] == 200 and size == expected["bytes"] and result["sha256"] == expected["sha256"]
    return result


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--public", action="store_true", help="Also verify public HTTP bytes after Pages deployment")
    parser.add_argument("--staged", action="store_true", help="Verify staged Git bytes match release checksums")
    parser.add_argument("--reconstruct", action="store_true", help="Reconstruct runtime files into an isolated test directory")
    args = parser.parse_args()
    baseline = json.loads((HERE / "pre-publication-baseline.json").read_text())
    release = json.loads((DESTINATION / "release.json").read_text())
    expected_tree = {e["path"]: (e["gitBlob"], e["bytes"]) for e in baseline["outsideIPhone"]}
    actual_tree = {}
    for line in git("ls-tree", "-rl", "HEAD").decode().splitlines():
        meta, name = line.split("\t", 1)
        mode, kind, oid, size = meta.split()
        if not name.startswith("iPhone/"):
            actual_tree[name] = (oid, int(size))
    assert actual_tree == expected_tree, "A protected committed file changed"
    changed = git("diff", "--name-only", baseline["commit"]).decode().splitlines()
    assert all(name.startswith("iPhone/") for name in changed), "A protected working file changed"
    assert git("rev-parse", "HEAD:iPad").decode().strip() == baseline["ipadTree"]
    assert git("rev-parse", "HEAD:PC").decode().strip() == baseline["pcTree"]
    artifacts = []
    for entry in release["files"]:
        blob = safe(DESTINATION, entry["path"]).read_bytes()
        assert len(blob) == entry["bytes"] and sha(blob) == entry["sha256"], entry["path"]
        if args.staged:
            staged = git("show", ":iPhone/" + entry["path"])
            assert staged == blob, "Staged bytes differ: " + entry["path"]
        artifacts.append({"path": entry["path"], "bytes": len(blob), "passed": True})
    assert all(x["bytes"] < 100 * 1024 * 1024 for x in release["files"])
    site_bytes = sum(size for _, size in actual_tree.values()) + sum(e["bytes"] for e in release["files"])
    assert site_bytes < 990000000
    assert all(e["path"] != ".gitattributes" for e in release["files"])
    if args.staged:
        for name in ("release.json", ".gitattributes"):
            assert git("show", ":iPhone/" + name) == (DESTINATION / name).read_bytes(), "Staged metadata differs: " + name
    info = json.loads((DESTINATION / "build-info.json").read_text(encoding="utf-8-sig"))
    assert info["buildGuid"] == release["buildGuid"]
    payload = DESTINATION / "StreamingAssets/WebPayload"
    assert (payload / info["assetManifest"]).read_bytes() == (payload / "manifest.json").read_bytes()
    dependencies = release["externalDependencies"]
    assert len(release["currentExternalDependencies"]) == len(json.loads((payload / "manifest.json").read_text())["packs"])
    for entry in dependencies:
        assert entry["kind"] == "runtime" and entry["path"].startswith("PC/StreamingAssets/WebPayload/")
        blob = safe(CHECKOUT, entry["path"]).read_bytes()
        assert len(blob) == entry["bytes"] and sha(blob) == entry["sha256"], entry["path"]
    assert json.loads((payload / "manifest.json").read_text())["packBase"] == "../../../PC/StreamingAssets/WebPayload/"
    assert not list(payload.glob("*.mbpack.gz")), "Shared payload must not be duplicated"
    archive_path = DESTINATION / "Source/maze-biters-iphone-web-source.zip"
    source_root = "platforms/iphone-web/"
    reconstruction = None
    with zipfile.ZipFile(archive_path) as archive:
        assert archive.testzip() is None
        source_manifest = json.loads(archive.read(source_root + "source-manifest.json"))["files"]
        for entry in source_manifest:
            blob = archive.read(source_root + entry["path"])
            assert len(blob) == entry["bytes"] and sha(blob) == entry["sha256"], entry["path"]
        assert len(source_manifest) == release["sourceFiles"]
        audio_manifest = json.loads(archive.read(source_root + "audio-source-manifest.json"))
        assert audio_manifest["commit"] == release["sourceAudioCommit"]
        for entry in audio_manifest["files"]:
            blob = git("show", audio_manifest["commit"] + ":" + entry["repositoryPath"])
            assert len(blob) == entry["bytes"] and sha(blob) == entry["sha256"], entry["path"]
            assert source_root + entry["path"] not in archive.namelist(), "Audio source duplicated in ZIP"
        assert len(audio_manifest["files"]) == 44
        if args.reconstruct:
            temporary = Path(tempfile.mkdtemp(prefix="source-restoration-", dir=HERE))
            for name in archive.namelist():
                safe(temporary, name)
            archive.extractall(temporary)
            output = subprocess.check_output(["python", str(temporary / source_root / "restore-source-assets.py"), str(payload.resolve()), "--repository", str(CHECKOUT.resolve())], text=True)
            reconstruction = json.loads(output)
            assert reconstruction["passed"] and reconstruction["restoredFiles"] == release["runtimeFiles"]
    result = {"passed": True, "buildGuid": release["buildGuid"], "baseCommit": baseline["commit"], "commit": git("rev-parse", "HEAD").decode().strip(), "rootPcAndIpadUnchanged": True, "sharedPackPins": len(dependencies), "externalAudioSources": len(audio_manifest["files"]), "protectedFiles": len(actual_tree), "artifactCount": len(artifacts), "sourceFiles": len(source_manifest), "sourceZipCRC": True, "runtimeFiles": release["runtimeFiles"], "siteBytes": site_bytes, "stagedBytesVerified": args.staged, "reconstruction": reconstruction}
    if args.public:
        requests = [("iPhone/" + e["path"], e) for e in release["files"]]
        requests += [(e["path"], e) for e in dependencies]
        local_release = (DESTINATION / "release.json").read_bytes()
        requests.append(("iPhone/release.json", {"bytes": len(local_release), "sha256": sha(local_release)}))
        # Protect the original landing page plus all its direct JS/CSS resources,
        # and the iPad landing/release/build identity; the complete tree is above.
        original_index = git("show", baseline["commit"] + ":index.html")
        protected = ["index.html", "iPad/index.html", "iPad/release.json", "iPad/build-info.json", "PC/index.html", "PC/release.json", "PC/build-info.json"]
        protected += re.findall(r'(?:src|href)="([^"\s]+\.(?:js|css)(?:\?[^"\s]*)?)"', original_index.decode())
        for name in protected:
            blob = git("show", baseline["commit"] + ":" + urlsplit(name).path)
            requests.append((name, {"bytes": len(blob), "sha256": sha(blob)}))
        with ThreadPoolExecutor(max_workers=4) as pool:
            public = list(pool.map(lambda item: remote(*item), requests))
        result["public"] = public
        result["passed"] = all(e["passed"] for e in public)
    report = HERE / ("public-publication-integrity.json" if args.public else "local-publication-integrity.json")
    report.write_text(json.dumps(result, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({k: v for k, v in result.items() if k != "public"}, indent=2))
    if not result["passed"]:
        raise SystemExit(2)


if __name__ == "__main__":
    main()

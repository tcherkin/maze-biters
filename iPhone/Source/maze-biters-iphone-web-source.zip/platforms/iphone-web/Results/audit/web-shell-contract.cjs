// The iPhone shell intentionally uses native viewport pixels instead of the
// copied PC shell's fixed 16:9 buffers. Keep the familiar audit entry point.
require('./iphone-shell-contract.cjs');

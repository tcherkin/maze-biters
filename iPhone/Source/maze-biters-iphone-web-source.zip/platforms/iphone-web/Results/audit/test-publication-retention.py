"""Exercise iPhone-only publication with tiny isolated fixtures, never the real checkout."""
from pathlib import Path
import contextlib
import hashlib
import importlib.util
import io
import json
import subprocess
import tempfile
import zipfile

ROOT = Path(__file__).resolve().parents[2]
spec = importlib.util.spec_from_file_location("publication", ROOT / "prepare-publication.py")
p = importlib.util.module_from_spec(spec)
spec.loader.exec_module(p)
fixture = Path(tempfile.mkdtemp(prefix="pc-publication-fixture-", dir=Path(__file__).resolve().parent)) / "platforms/iphone-web"
fixture.mkdir(parents=True)
p.HERE, p.CHECKOUT, p.BUILD = fixture, fixture / "Publish", fixture / "Builds/iPhone"
destination = p.CHECKOUT / "iPhone"
destination.mkdir(parents=True)
baseline, checks = {}, []
git_state = {"status": "", "origin": "https://github.com/tcherkin/maze-biters.git", "remoteHead": "a" * 40, "existingBytes": 900563761}


def check(name, condition):
    assert condition, name
    checks.append(name)


def fake_git(*args):
    if args[:2] == ("remote", "get-url"):
        return git_state["origin"]
    if args[0] == "rev-parse":
        return git_state["remoteHead"] if args[1] == "origin/main" else "a" * 40
    if args[0] == "status":
        return git_state["status"]
    if args[:2] == ("merge-base", "--is-ancestor"):
        return ""
    if args[0] == "ls-tree":
        return "100644 blob " + "b" * 40 + " " + str(git_state["existingBytes"]) + "\tiPad/unchanged.bin"
    raise AssertionError(args)


def fake_archive(path):
    with zipfile.ZipFile(path, "w") as archive:
        archive.writestr(zipfile.ZipInfo("test.txt", date_time=(1980,1,1,0,0,0)), "isolated iPhone publisher fixture")
    return 1


def evidence(path, content):
    return {"path": path, "bytes": len(content), "sha256": hashlib.sha256(content).hexdigest()}


def put(root, name, content):
    path = root / name
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_bytes(content)
    return evidence(name, content)


def payload(letter):
    blob = ("pack-" + letter).encode()
    entry = evidence("runtime-" + hashlib.sha256(blob).hexdigest()[:20] + ".mbpack.gz", blob)
    entry["file"] = entry.pop("path")
    manifest = {"verifiedFiles": 1, "packs": [entry]}
    return manifest, json.dumps(manifest).encode(), entry["file"], blob


def build(letter, resources):
    manifest, data, name, blob = resources
    paths = ["Build/" + letter * 32 + suffix for suffix in (".data.unityweb", ".framework.js.unityweb", ".loader.js", ".wasm.unityweb")]
    for path in paths:
        put(p.BUILD, path, (path + " fixture").encode())
    put(p.BUILD, "Build/unreferenced.unityweb", b"stale build artifact")
    put(p.BUILD, "index.html", ("<script>" + ";".join("'" + path + "'" for path in paths) + ";cacheControl:url=>'must-revalidate'</script>").encode())
    put(p.BUILD, "build-info.json", json.dumps({"buildGuid": letter * 32, "assetManifest": "manifest-" + letter * 32 + ".json"}).encode())
    put(p.BUILD, p.PAYLOAD_ROOT + "manifest.json", data)
    put(p.BUILD, p.PAYLOAD_ROOT + "manifest-" + letter * 32 + ".json", data)
    put(p.BUILD, p.PAYLOAD_ROOT + name, blob)
    put(p.CHECKOUT, p.SHARED_ROOT + name, blob)
    return paths


def run(**options):
    with contextlib.redirect_stdout(io.StringIO()):
        p.main(**options)
    report = json.loads((destination / "release.json").read_text())
    for entry in report["files"]:
        blob = (destination / entry["path"]).read_bytes()
        check("artifact checksum " + entry["path"], len(blob) == entry["bytes"] and hashlib.sha256(blob).hexdigest() == entry["sha256"])
    for name, original in protected.items():
        check("preserved existing edition " + name, (p.CHECKOUT / name).read_bytes() == original)
    return report


def rejected(name, action):
    try:
        action()
    except ValueError:
        check(name, True)
    else:
        raise AssertionError(name + " did not reject")


p.git, p.committed_release, p.source_archive = fake_git, lambda: baseline, fake_archive
(fixture / "README-WEB.md").write_text("Fixture PC README")
protected = {"index.html": b"original browser root", "iPad/release.json": b'{"files":[{"path":"Build/legacy.wasm"}]}', "iPad/Build/legacy.wasm": b"iPad resources remain byte-identical", "PC/index.html": b"Existing PC game stays intact"}
for name, blob in protected.items():
    put(p.CHECKOUT, name, blob)

a_resources = payload("a")
a_paths = build("a", a_resources)
a = run()
check("fresh iPhone release inherits no iPad compatibility", not a["compatibilityFiles"])
check("no duplicate shared pack", not (destination / p.PAYLOAD_ROOT / a_resources[2]).exists())
check("pack base points to immutable shared store", json.loads((destination / p.PAYLOAD_ROOT / "manifest.json").read_text())["packBase"] == p.PACK_BASE)
check("shared runtime pin recorded", a["externalDependencies"] == [{"kind":"runtime", "path":p.SHARED_ROOT + a_resources[2], "bytes":len(a_resources[3]), "sha256":hashlib.sha256(a_resources[3]).hexdigest()}])
check("existing iPad bytes included in full-site budget", a["siteBytes"] == a["totalBytes"] + git_state["existingBytes"])
check("iPhone source archive name", (destination / "Source/maze-biters-iphone-web-source.zip").is_file())
check("current files selected from HTML", all(any(e["path"] == path for e in a["currentFiles"]) for path in a_paths))
check("stale output excluded", not (destination / "Build/unreferenced.unityweb").exists())
check("dotfile excluded from served manifest", all(e["path"] != ".gitattributes" for e in a["files"]) and (destination / ".gitattributes").exists())
check("repeated precommit preparation stable", a == run())

baseline.update(a)
b_resources = payload("b")
b_paths = build("b", b_resources)
b = run()
check("cached previous iPhone manifest retains old shared pack", len(b["externalDependencies"]) == 2 and b["compatibilityDependencies"] == a["currentExternalDependencies"])
check("only preceding iPhone generation retained", set(e["path"] for e in b["compatibilityFiles"]) == set(a_paths + [p.PAYLOAD_ROOT + "manifest-" + "a" * 32 + ".json"]))
check("canonical reconstruction manifest stays current", (destination / p.PAYLOAD_ROOT / "manifest.json").read_bytes() == (json.dumps(dict(b_resources[0], packBase=p.PACK_BASE), indent=2) + "\n").encode())
baseline.clear(); baseline.update(b)
check("same build after commit preserves compatibility", run()["compatibilityFiles"] == b["compatibilityFiles"])
build("c", payload("c"))
c = run()
check("shared compatibility pins remain one generation", len(c["externalDependencies"]) == 2 and c["compatibilityDependencies"] == b["currentExternalDependencies"])
check("retention remains bounded", len(c["compatibilityFiles"]) == 5)
check("older versioned manifest removed", not (destination / p.PAYLOAD_ROOT / ("manifest-" + "a" * 32 + ".json")).exists())
check("older build removed", not any((destination / name).exists() for name in a_paths))
check("older pack removed", not (destination / p.PAYLOAD_ROOT / a_resources[2]).exists())
rejected("mutable previous resource collision rejected", lambda: p.compatibility_records({"files": [evidence("Build/same.loader.js", b"old")]}, [evidence("Build/same.loader.js", b"new")], "e" * 32))
rejected("path traversal rejected", lambda: p.safe(destination, "../iPad/index.html"))
git_state["status"] = " M iPad/index.html"
rejected("iPad checkout mutation rejected", p.main)
git_state["status"] = " M index.html"
rejected("root checkout mutation rejected", p.main)
git_state["status"] = ""
git_state["origin"] = "https://github.com/other/repo.git"
rejected("wrong origin rejected", p.main)
git_state["origin"] = "https://github.com/tcherkin/maze-biters.git"
git_state["remoteHead"] = "d" * 40
rejected("unreconciled branch rejected", p.main)
git_state["remoteHead"] = "a" * 40
git_state["existingBytes"] = 990000000
rejected("full-site budget includes existing editions", p.main)

# Retaining PC packs pinned by iPhone must survive unrelated later PC generations.
pc_spec = importlib.util.spec_from_file_location("pc_publication", ROOT / "pc-publication-pin-reference.py")
pc = importlib.util.module_from_spec(pc_spec); pc_spec.loader.exec_module(pc)
pinned = evidence(p.PAYLOAD_ROOT + a_resources[2], a_resources[3])
pins_release = {"externalDependencies": [{"kind":"runtime", **dict(pinned, path="PC/" + pinned["path"])}]}
(destination / "release.json").write_text(json.dumps(pins_release))
check("PC owner finds iPhone runtime pins", pc.external_runtime_records(p.CHECKOUT) == [pinned])
check("older PC pack survives multiple generations", pc.retain_external_dependencies([evidence("Build/new.wasm", b"new")], [], [pinned]) == [pinned])
check("already retained PC pin deduplicated", pc.retain_external_dependencies([], [pinned], [pinned]) == [])
rejected("conflicting PC pin rejected", lambda: pc.retain_external_dependencies([dict(pinned, sha256="0" * 64)], [], [pinned]))
pin_file = p.CHECKOUT / "PC" / pinned["path"]
pin_file.write_bytes(b"damaged")
rejected("damaged shared PC pin rejected", lambda: pc.external_runtime_records(p.CHECKOUT))
pin_file.write_bytes(a_resources[3])
pins_release["externalDependencies"][0]["path"] = "PC/../iPad/secret.mbpack.gz"
(destination / "release.json").write_text(json.dumps(pins_release))
rejected("external pin traversal rejected", lambda: pc.external_runtime_records(p.CHECKOUT))

# Optional lossless data hosting avoids a second 47 MB Pages copy, while old
# cached HTML keeps its complete preceding local runtime. This never changes
# the local/tested build or a protected edition.
git_state["existingBytes"] = 900563761
baseline.clear(); baseline.update(c)
(destination / "release.json").write_text(json.dumps(c))
d_paths = build("d", payload("d"))
index_before = (destination / "index.html").read_bytes()
release_before = (destination / "release.json").read_bytes()
with contextlib.redirect_stdout(io.StringIO()):
    p.main(prepare_data_only=True)
check("data-only phase leaves published entry intact", (destination / "index.html").read_bytes() == index_before)
check("data-only phase leaves release metadata intact", (destination / "release.json").read_bytes() == release_before)
data_path = next(name for name in d_paths if name.endswith(".data.unityweb"))
hidden = "iPhone/" + p.hidden_data_path(data_path)
check("data-only phase copies exact tested data", (p.CHECKOUT / hidden).read_bytes() == (p.BUILD / data_path).read_bytes())
p.git_blob = lambda commit, name: (p.CHECKOUT / name).read_bytes()
d = run(data_commit="a" * 40)
external = d["currentExternalBuildFiles"][0]
check("raw data URL pins complete immutable commit", external["url"] == p.RAW_BASE + "a" * 40 + "/" + hidden)
check("new HTML references pinned raw data", external["url"] in (destination / "index.html").read_text())
cache_function = (destination / "index.html").read_text().split("cacheControl:")[1].split("</script>")[0]
test_urls = [external["url"], external["url"] + "?changed", "https://raw.githubusercontent.com/tcherkin/maze-biters/main/" + hidden, "Build/" + "d" * 32 + ".wasm.unityweb", "StreamingAssets/WebPayload/manifest.json"]
decisions = json.loads(subprocess.check_output(["node", "-e", "const f=Function('return ('+process.argv[1]+')')();console.log(JSON.stringify(JSON.parse(process.argv[2]).map(f)))", cache_function, json.dumps(test_urls)], text=True))
check("only exact immutable data URL skips revalidation", decisions == ["immutable", "must-revalidate", "must-revalidate", "must-revalidate", "must-revalidate"])
rejected("unexpected cache policy is never overwritten", lambda: p.bind_external_data((p.BUILD / "index.html").read_text().replace("cacheControl", "otherCache"), external))
check("local tested HTML remains unchanged", external["url"] not in (p.BUILD / "index.html").read_text())
check("new data not duplicated as a served artifact", not any(e["path"] == data_path for e in d["files"]))
check("hidden raw data excluded from Pages budget", p.hidden_data_path(data_path) in d["repositoryOnlyFiles"] and all(".runtime/" not in e["path"] for e in d["files"]))
check("cached preceding HTML retains its full local data", any(e["path"].endswith(".data.unityweb") for e in d["compatibilityFiles"]))
baseline.clear(); baseline.update(d)
check("same external build keeps preceding compatibility", run(data_commit="a" * 40)["compatibilityFiles"] == d["compatibilityFiles"])
build("e", payload("e"))
with contextlib.redirect_stdout(io.StringIO()):
    p.main(prepare_data_only=True)
e = run(data_commit="a" * 40)
check("previous raw data remains an explicit compatibility dependency", e["compatibilityExternalBuildFiles"] == d["currentExternalBuildFiles"])
rejected("raw mutable branch reference rejected", lambda: p.external_data_record("main", data_path, p.BUILD / data_path))
rejected("raw data path traversal rejected", lambda: p.hidden_data_path("Build/../secret.data.unityweb"))
(p.CHECKOUT / ".nojekyll").write_text("")
rejected("changed Pages exclusion policy rejected", p.require_hidden_runtime_exclusion)
(p.CHECKOUT / ".nojekyll").unlink()
(p.CHECKOUT / hidden).write_bytes(b"wrong immutable data")
rejected("raw commit bytes must equal tested build", lambda: p.external_data_record("a" * 40, data_path, p.BUILD / data_path))

result = {"passed": True, "checks": len(checks), "names": checks, "note": "Tiny isolated filesystem fixtures only. No actual deployment, source build, staging, commit or push."}
(Path(__file__).resolve().parent / "publication-retention.json").write_text(json.dumps(result, indent=2) + "\n")
print(json.dumps({"passed": True, "checks": len(checks)}))

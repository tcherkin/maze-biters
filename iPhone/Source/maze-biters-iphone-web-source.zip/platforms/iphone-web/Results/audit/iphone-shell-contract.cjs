const fs=require('node:fs'),vm=require('node:vm'),path=require('node:path'),assert=require('node:assert/strict');
const root=path.resolve(__dirname,'../..');
const source=process.argv[2]?path.resolve(process.argv[2]):path.join(root,'UnityProject/Assets/WebGLTemplates/MazeBiters/index.html');
const html=fs.readFileSync(source,'utf8');
const script=[...html.matchAll(/<script>([\s\S]*?)<\/script>/g)].map(m=>m[1]).join('\n');
function host(options={}){
 const elements=new Map(),calls=[],listeners=new Map(),timers=new Map();let nextTimer=0;
 function listen(group,name,fn,capture){const key=group+':'+name;if(!listeners.has(key))listeners.set(key,[]);listeners.get(key).push({fn,capture});}
 function element(id){if(!elements.has(id))elements.set(id,{style:{},textContent:'',value:0,width:0,height:0,focus(){calls.push(['focus',id]);},addEventListener(name,fn,capture){listen(id,name,fn,capture);}});return elements.get(id);}
 const viewport={width:options.width||956,height:options.height||440,offsetLeft:0,offsetTop:0,addEventListener(name,fn){listen('viewport',name,fn);}};
 const context={console,URLSearchParams,innerWidth:options.width||956,innerHeight:options.height||440,devicePixelRatio:options.dpr||3,
  navigator:{userAgent:options.desktop?'Mozilla Windows Chrome':'Mozilla iPhone Mobile Safari',maxTouchPoints:options.desktop?0:5},
  visualViewport:options.noVisualViewport?null:viewport,
  location:{search:options.query||'',reload(){calls.push(['reload']);}},
  Event:function(type){this.type=type;},
  addEventListener(name,fn,capture){listen('window',name,fn,capture);},
  dispatchEvent(event){for(const x of listeners.get('window:'+event.type)||[])x.fn(event);},
  setTimeout(fn,ms){timers.set(++nextTimer,{fn,ms});return nextTimer;},clearTimeout(id){timers.delete(id);},
  document:{querySelector:element,addEventListener(name,fn,capture){listen('document',name,fn,capture);},documentElement:{},fullscreenElement:null},
  fakeUnity:{SendMessage(...args){calls.push(['send',...args]);}}
 };
 context.window=context;vm.createContext(context);vm.runInContext(script,context,{filename:source});
 return {context,elements,calls,listeners,timers,viewport,run:s=>vm.runInContext(s,context),canvas:()=>element('#canvas'),metrics:()=>context.mazePhoneViewport,
  resize(w,h,dpr){context.innerWidth=viewport.width=w;context.innerHeight=viewport.height=h;if(dpr!==undefined)context.devicePixelRatio=dpr;this.run('fit()');},
  settle(){const pending=[...timers.values()];timers.clear();for(const t of pending)t.fn();},
  event(group,type,overrides={}){const event={type,code:'Enter',key:'Enter',altKey:false,repeat:false,target:{closest:()=>false},stopped:false,prevented:false,stopImmediatePropagation(){this.stopped=true;},preventDefault(){this.prevented=true;},...overrides};for(const x of listeners.get(group+':'+type)||[]){x.fn(event);if(event.stopped)break;}return event;}
 };
}
const checks=[];
function test(name,fn,options){try{const h=host(options);fn(h);checks.push({name,pass:true});}catch(e){checks.push({name,pass:false,error:e.stack});}}
function dimensions(h,w,ht){assert.equal(h.canvas().width,w);assert.equal(h.canvas().height,ht);}
test('iPhone 17 Pro Max uses all 2868×1320 pixels before Unity startup',h=>{dimensions(h,2868,1320);assert.equal(h.canvas().style.width,'956px');assert.equal(h.canvas().style.height,'440px');assert.equal(h.canvas().style.left,'0px');assert.equal(h.canvas().style.top,'0px');assert.equal(h.context.document.querySelector('#preview-tools').style.display,undefined);});
test('Native and HD share the same surface and exact aspect',h=>{h.context.mazePhoneSetQuality('hd');dimensions(h,1434,660);assert.equal(h.metrics().nativeWidth,2868);assert.equal(h.metrics().nativeHeight,1320);h.context.mazePhoneSetQuality(1);dimensions(h,2868,1320);});
test('Explicit HD URL has correct initial half-resolution buffer',h=>dimensions(h,1434,660),{query:'?quality=hd'});
test('Actual active state selects buffer quality without overwriting metrics',h=>{h.run('mazeWebState(\'{"quality":"hd"}\')');dimensions(h,1434,660);h.run('mazeWebState(\'{"quality":"4k"}\')');dimensions(h,2868,1320);assert.equal(h.metrics().cssWidth,956);});
test('iPhone SE uses its actual pixels instead of Max fixed resolution',h=>dimensions(h,1334,750),{width:667,height:375,dpr:2});
test('Another iPhone uses its actual viewport instead of a fixed 16:9 rectangle',h=>dimensions(h,2532,1170),{width:844,height:390,dpr:3});
test('The full surface deliberately ignores physical cutout padding',h=>{assert(!html.includes('safe-area-inset'));assert(html.includes('viewport-fit=cover'));for(const key of ['left','right','top','bottom'])assert.equal(h.metrics()[key],0);});
test('A 180-degree landscape rotation retains the surface and drawing buffer',h=>{const revision=h.metrics().revision;h.resize(956,440);dimensions(h,2868,1320);assert.equal(h.metrics().revision,revision);assert.equal(h.timers.size,0);assert.equal(h.context.mazePhoneHold,false);});
test('Portrait hides stretched content and freezes landscape resources',h=>{h.resize(440,956);dimensions(h,2868,1320);assert.equal(h.metrics().nativeWidth,2868);assert.equal(h.metrics().portrait,1);assert.equal(h.metrics().stable,0);assert.equal(h.context.mazePhoneHold,true);assert.equal(h.elements.get('#rotate').style.display,'flex');});
test('Returning to landscape waits for stable layout without reallocating portrait resources',h=>{h.resize(440,956);h.resize(956,440);assert.equal(h.context.mazePhoneHold,true);assert.equal(h.timers.size,1);dimensions(h,2868,1320);h.settle();assert.equal(h.context.mazePhoneHold,false);assert.equal(h.metrics().portrait,0);assert.equal(h.metrics().stable,1);assert.equal(h.elements.get('#rotate').style.display,'none');dimensions(h,2868,1320);});
test('Successive Safari viewport changes publish only the final settled dimensions',h=>{h.resize(900,420);h.resize(930,430);h.resize(950,440);assert.equal(h.timers.size,1);assert.equal(h.metrics().nativeWidth,2868);h.settle();dimensions(h,2850,1320);assert.equal(h.metrics().nativeWidth,2850);assert.equal(h.context.mazePhoneHold,false);});
test('DPR changes are measured independently of current HD backing size',h=>{h.context.mazePhoneSetQuality(0);h.resize(956,440,2);h.settle();dimensions(h,956,440);assert.equal(h.metrics().nativeWidth,1912);assert.equal(h.metrics().nativeHeight,880);h.context.mazePhoneSetQuality(1);dimensions(h,1912,880);});
test('Odd native pixel counts use matching nearest-integer half-size rounding',h=>{dimensions(h,1335,751);h.context.mazePhoneSetQuality(0);dimensions(h,668,376);},{width:667.5,height:375.5,dpr:2});
test('Without VisualViewport the normal inner viewport still fills the phone',h=>dimensions(h,2868,1320),{noVisualViewport:true});
test('Invalid VisualViewport data falls back to finite inner dimensions',h=>{h.viewport.width=0;h.viewport.height=NaN;h.context.devicePixelRatio=NaN;h.run('fit(true)');dimensions(h,956,440);});
test('Desktop defaults to a visible correctly scaled iPhone 17 Pro Max preview',h=>{dimensions(h,2868,1320);assert.equal(parseFloat(h.canvas().style.width),1920);assert(Math.abs(parseFloat(h.canvas().style.height)-1920*440/956)<1e-6);assert.equal(h.elements.get('#preview-tools').style.display,'flex');assert(h.elements.get('#preview-label').textContent.includes('17 Pro Max'));},{desktop:true,width:1920,height:1080,dpr:1});
test('Visible preview rotation exercises portrait hold and landscape restore',h=>{h.elements.get('#preview-rotate').onclick();assert.equal(h.context.mazePhoneHold,true);dimensions(h,2868,1320);h.elements.get('#preview-rotate').onclick();h.settle();assert.equal(h.context.mazePhoneHold,false);dimensions(h,2868,1320);},{desktop:true,width:1920,height:1080,dpr:1});
test('Explicit desktop preview fixture supports other phone proportions',h=>dimensions(h,1334,750),{desktop:true,width:1920,height:1080,dpr:1,query:'?preview=se'});
test('Desktop preview can be disabled to test an actual full browser surface',h=>dimensions(h,1920,1080),{desktop:true,width:1920,height:1080,dpr:1,query:'?preview=off'});
test('Initial boot failure reloads the entire runtime',h=>{h.run("failed('initial boot failure')");h.elements.get('#retry').onclick();assert(h.calls.some(c=>c[0]==='reload'));});
test('Recoverable asset error retries the same bootstrap',h=>{h.run("unity=fakeUnity; mazeWebStatus('asset interrupted',0,-1)");h.elements.get('#retry').onclick();assert(h.calls.some(c=>c[0]==='send'&&c[2]==='Retry'));assert.equal(h.elements.get('#retry').style.display,'none');});
test('Fatal runtime errors remain visible despite pending asset callbacks',h=>{h.run("unity=fakeUnity; failed('WASM aborted'); mazeWebStatus('background assets',.6,1)");assert.equal(h.elements.get('#loading').style.display,'flex');h.elements.get('#retry').onclick();assert(h.calls.some(c=>c[0]==='reload'));});
test('Page toolbar receives clicks without leaking pointer gestures into Unity',h=>{for(const type of ['pointerdown','pointermove','pointerup','touchstart','touchmove','touchend','touchcancel','mousedown','mouseup']){const e=h.event('window',type,{target:{closest:()=>true}});assert(e.stopped,type);assert(!e.prevented,type+' keeps default click activation');}h.run('unity=fakeUnity');h.elements.get('#pause').onclick();assert(h.calls.some(c=>c[0]==='send'&&c[2]==='Pause'));});
test('Gameplay canvas gestures are not intercepted by the page toolbar',h=>{for(const type of ['pointerdown','pointermove','pointerup','touchstart','touchmove','touchend'])assert(!h.event('window',type).stopped,type);});
test('DOM toolbar keyboard activation and matching release stay out of Unity',h=>{const down=h.event('window','keydown',{target:{closest:()=>true}}),up=h.event('window','keyup');assert(down.stopped&&up.stopped);assert(!down.prevented&&!up.prevented);assert(!h.event('window','keydown',{key:'ArrowUp',code:'ArrowUp'}).stopped);});
test('Alt+Enter toggles fullscreen only once per press',h=>{let entered=0,exited=0;const d=h.context.document;d.documentElement.requestFullscreen=()=>{entered++;d.fullscreenElement=d.documentElement;return {catch(){}};};d.exitFullscreen=()=>{exited++;d.fullscreenElement=null;return {catch(){}};};const down=h.event('window','keydown',{altKey:true});h.event('window','keydown',{altKey:true,repeat:true});h.event('window','keydown',{altKey:true});const up=h.event('window','keyup');h.event('window','keydown',{altKey:true});assert.equal(entered,1);assert.equal(exited,1);assert(down.stopped&&down.prevented&&up.stopped&&up.prevented);});
test('Fullscreen button tolerates missing iOS fullscreen API',h=>{h.elements.get('#full').onclick();assert(h.calls.some(c=>c[0]==='focus'));});
test('Actual numeric jslib exposes all agreed fields without allocating JSON',h=>{const library={};h.context.LibraryManager={library};h.context.mergeInto=(target,entries)=>Object.assign(target,entries);vm.runInContext(fs.readFileSync(path.join(root,'UnityProject/Assets/Plugins/WebGL/IPhoneViewport.jslib'),'utf8'),h.context);assert.deepEqual([0,1,2,3,4,5,6,7,8].map(n=>library.MBIphoneViewport(n)),[2868,1320,0,0,0,0,h.metrics().revision,1,0]);library.MBIphoneQuality(0);dimensions(h,1434,660);h.resize(440,956);assert.equal(library.MBIphoneViewport(7),0);assert.equal(library.MBIphoneViewport(8),1);assert.equal(library.MBIphoneViewport(0),2868);});
const report={source,kind:'Actual inline shell and jslib executed in Node VM with deterministic browser events; does not certify physical Safari/Kiosker rendering or touch hardware',passed:checks.filter(c=>c.pass).length,total:checks.length,checks};
fs.writeFileSync(path.join(__dirname,'iphone-shell-contract.json'),JSON.stringify(report,null,2)+'\n');console.log(JSON.stringify(report,null,2));if(report.passed!==report.total)process.exitCode=1;

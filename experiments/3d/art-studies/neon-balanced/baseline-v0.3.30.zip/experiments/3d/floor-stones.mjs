import * as THREE from './vendor/three.module.min.js';

const TOP=-.005,EDGE=-.013,JOINT=-.018;
const hash=(x,y=0)=>{let n=Math.imul(x+173,374761393)^Math.imul(y+37,668265263);n=Math.imul(n^(n>>>13),1274126177);return (n^(n>>>16))>>>0;};
const smooth=t=>t*t*(3-2*t);
function noise(x,z){
  const i=Math.floor(x),j=Math.floor(z),u=smooth(x-i),v=smooth(z-j);
  const a=(hash(i,j)%65536)/65535,b=(hash(i+1,j)%65536)/65535;
  const c=(hash(i,j+1)%65536)/65535,d=(hash(i+1,j+1)%65536)/65535;
  return (a+(b-a)*u)*(1-v)+(c+(d-c)*u)*v;
}

// Mixed rectangles span neighbouring courses, breaking continuous brick rows.
// The lattice fits the exact extent, so borders never produce thin slivers.
function slabsFor(bounds){
  const columns=Math.ceil((bounds.maxX-bounds.minX)/1.02),rows=Math.ceil((bounds.maxZ-bounds.minZ)/1.02);
  const dx=(bounds.maxX-bounds.minX)/columns,dz=(bounds.maxZ-bounds.minZ)/rows;
  const occupied=new Uint8Array(columns*rows),slabs=[];
  const sizes=[[2,2],[3,2],[2,3],[3,3],[2,2],[3,2],[2,3],[2,1],[1,2],[1,1]];
  for(let z=0;z<rows;z++)for(let x=0;x<columns;x++){
    if(occupied[z*columns+x])continue;
    const seed=hash(x+53,z+19),offset=seed%7;
    const choices=[...sizes.slice(0,7).map((_,i)=>sizes[(i+offset)%7]),...sizes.slice(7)];
    const [w,h]=choices.find(([w,h])=>{
      if(x+w>columns||z+h>rows)return false;
      for(let j=z;j<z+h;j++)for(let i=x;i<x+w;i++)if(occupied[j*columns+i])return false;
      return true;
    });
    for(let j=z;j<z+h;j++)for(let i=x;i<x+w;i++)occupied[j*columns+i]=1;
    slabs.push({minX:bounds.minX+x*dx,maxX:bounds.minX+(x+w)*dx,
      minZ:bounds.minZ+z*dz,maxZ:bounds.minZ+(z+h)*dz,seed,cells:[w,h]});
  }
  return slabs;
}

function texturesFor(bounds,slabs){
  const size=512,canvas=()=>{const c=document.createElement('canvas');c.width=c.height=size;return c;};
  const colorCanvas=canvas(),surfaceCanvas=canvas(),colorContext=colorCanvas.getContext('2d'),surfaceContext=surfaceCanvas.getContext('2d');
  const colors=colorContext.createImageData(size,size),surface=surfaceContext.createImageData(size,size);
  const width=bounds.maxX-bounds.minX,depth=bounds.maxZ-bounds.minZ;
  for(let y=0;y<size;y++)for(let x=0;x<size;x++){
    const wx=bounds.minX+x/(size-1)*width,wz=bounds.maxZ-y/(size-1)*depth,i=(y*size+x)*4;
    const broad=noise(wx*.62,wz*.62),grain=noise(wx*2.4+37,wz*2.4-19);
    const tone=220+(broad-.5)*14+(grain-.5)*5;
    colors.data[i]=tone-1;colors.data[i+1]=tone;colors.data[i+2]=tone+2;colors.data[i+3]=255;
    // Red carries gentle bump; green carries roughness. It has no color-space
    // conversion, unlike the diffuse texture, so stone cannot become glossy.
    surface.data[i]=124+(broad-.5)*32+(grain-.5)*12;
    surface.data[i+1]=232+(broad-.5)*12;surface.data[i+2]=0;surface.data[i+3]=255;
  }
  // Rare short, broken wear lines are baked only into their own slab's area.
  // One non-repeating world atlas avoids a recognisable crack on every stone.
  for(const slab of slabs){
    if(slab.seed%19!==0||Math.min(...slab.cells)<2)continue;
    const sx=(slab.minX+slab.maxX)/2,sz=(slab.minZ+slab.maxZ)/2;
    const angle=(slab.seed%628)/100,length=.32+(slab.seed%23)/100;
    let previous={x:sx-Math.cos(angle)*length/2,z:sz-Math.sin(angle)*length/2};
    for(let segment=1;segment<=3;segment++){
      const along=(segment/3-.5)*length,bend=(hash(segment,slab.seed)%100/100-.5)*.08;
      const next={x:sx+Math.cos(angle)*along-Math.sin(angle)*bend,z:sz+Math.sin(angle)*along+Math.cos(angle)*bend};
      const pad=.085,toX=v=>(v-bounds.minX)/width*(size-1),toY=v=>(bounds.maxZ-v)/depth*(size-1);
      const x0=Math.max(0,Math.floor(toX(Math.min(previous.x,next.x)-pad))),x1=Math.min(size-1,Math.ceil(toX(Math.max(previous.x,next.x)+pad)));
      const y0=Math.max(0,Math.floor(toY(Math.max(previous.z,next.z)+pad))),y1=Math.min(size-1,Math.ceil(toY(Math.min(previous.z,next.z)-pad)));
      const vx=next.x-previous.x,vz=next.z-previous.z,len=vx*vx+vz*vz;
      for(let y=y0;y<=y1;y++)for(let x=x0;x<=x1;x++){
        const wx=bounds.minX+x/(size-1)*width,wz=bounds.maxZ-y/(size-1)*depth;
        const t=Math.max(0,Math.min(1,((wx-previous.x)*vx+(wz-previous.z)*vz)/len));
        const d2=(wx-previous.x-t*vx)**2+(wz-previous.z-t*vz)**2;
        const wear=Math.exp(-d2/.0012)*.42,i=(y*size+x)*4;
        for(let channel=0;channel<3;channel++)colors.data[i+channel]-=wear*27;
        surface.data[i]-=wear*20;surface.data[i+1]+=wear*7;
      }
      previous=next;
    }
  }
  colorContext.putImageData(colors,0,0);surfaceContext.putImageData(surface,0,0);
  const map=new THREE.CanvasTexture(colorCanvas),detail=new THREE.CanvasTexture(surfaceCanvas);
  map.colorSpace=THREE.SRGBColorSpace;
  for(const texture of [map,detail]){
    texture.flipY=false;
    texture.wrapS=texture.wrapT=THREE.ClampToEdgeWrapping;
    texture.minFilter=THREE.LinearMipmapLinearFilter;texture.magFilter=THREE.LinearFilter;texture.anisotropy=4;
  }
  return {map,detail};
}

export function addStoneFloor(group,layout){
  const bounds={minX:-layout.width/2-.15,maxX:layout.width/2+.15,minZ:-layout.height/2-.15,maxZ:layout.height/2+.15,minY:JOINT,maxY:TOP};
  const slabs=slabsFor(bounds),data={position:[],normal:[],uv:[],color:[]};
  const point=(x,y,z)=>new THREE.Vector3(x,y,z),base=new THREE.Color(0x222532);
  const emit=(vertices,color)=>{
    const [a,b,c]=vertices,n=new THREE.Vector3().subVectors(b,a).cross(new THREE.Vector3().subVectors(c,a)).normalize();
    for(const p of vertices){data.position.push(p.x,p.y,p.z);data.normal.push(n.x,n.y,n.z);
      data.uv.push((p.x-bounds.minX)/(bounds.maxX-bounds.minX),(bounds.maxZ-p.z)/(bounds.maxZ-bounds.minZ));
      data.color.push(color.r,color.g,color.b);}
  };
  const quad=(a,b,c,d,color)=>{emit([a,b,c],color);emit([a,c,d],color);};
  // A continuous recessed mortar surface closes cut corners and every joint.
  quad(point(bounds.minX,JOINT,bounds.minZ),point(bounds.minX,JOINT,bounds.maxZ),
    point(bounds.maxX,JOINT,bounds.maxZ),point(bounds.maxX,JOINT,bounds.minZ),base.clone().multiplyScalar(.64));
  for(const slab of slabs){
    const joint=.008+(slab.seed%4)*.001,bevel=.019+(slab.seed%5)*.001;
    const cut=.024+(slab.seed%7)*.004;
    const ring=(inset,y)=>{
      const x0=slab.minX+inset,x1=slab.maxX-inset,z0=slab.minZ+inset,z1=slab.maxZ-inset;
      return [point(x0+cut,y,z0),point(x0,y,z0+cut),point(x0,y,z1-cut),point(x0+cut,y,z1),
        point(x1-cut,y,z1),point(x1,y,z1-cut),point(x1,y,z0+cut),point(x1-cut,y,z0)];
    };
    const lower=ring(joint,EDGE),upper=ring(joint+bevel,TOP);
    // A single restrained nick affects a few corners, never the walking plane.
    if(slab.seed%17===0){upper[2].x+=.012;upper[2].z-=.02;}
    const center=point((slab.minX+slab.maxX)/2,TOP,(slab.minZ+slab.maxZ)/2);
    const variation=(noise(center.x*.19,center.z*.19)-.5)*.12+(slab.seed%11-5)*.004;
    const color=base.clone().multiplyScalar(1+variation),edgeColor=color.clone().multiplyScalar(.92);
    for(let i=0;i<8;i++){
      const j=(i+1)%8;
      emit([upper[i],upper[j],center],color);
      quad(lower[i],lower[j],upper[j],upper[i],edgeColor);
    }
  }
  const geometry=new THREE.BufferGeometry();
  for(const [key,size] of [['position',3],['normal',3],['uv',2],['color',3]])geometry.setAttribute(key,new THREE.Float32BufferAttribute(data[key],size));
  geometry.computeBoundingBox();geometry.computeBoundingSphere();
  const {map,detail}=texturesFor(bounds,slabs);
  const material=new THREE.MeshStandardMaterial({vertexColors:true,map,bumpMap:detail,bumpScale:.038,
    roughnessMap:detail,roughness:.94,metalness:.025,envMapIntensity:.24});
  const mesh=new THREE.Mesh(geometry,material);mesh.name='stone-floor-slabs';mesh.receiveShadow=true;group.add(mesh);
  group.userData.floorStyle='flagstone-v1';group.userData.floorBounds=bounds;group.userData.floorSlabs=slabs;
  group.userData.pavingCount=slabs.length;
  return {geometries:[geometry],textures:[map,detail]};
}

Shader "Hidden/MazeBiters/OrbitTouch" {
 Properties {
  _MainTex("Unused UI texture",2D)="white"{}
  _Thumb("Thumb offset and radius",Vector)=(0,0,23.92,0)
  _Light("Direction, strength, fade, opacity",Vector)=(0,0,0,.64)
 }
 SubShader {
  Tags {"Queue"="Overlay" "RenderType"="Transparent" "IgnoreProjector"="True"}
  Cull Off ZWrite Off ZTest Always Blend One OneMinusSrcAlpha
  Pass {
   CGPROGRAM
   #pragma vertex vert
   #pragma fragment frag
   #pragma target 3.0
   #include "UnityCG.cginc"
   float4 _Thumb,_Light;
   struct V {float4 p:POSITION;float2 uv:TEXCOORD0;};
   struct F {float4 p:SV_POSITION;float2 uv:TEXCOORD0;};
   F vert(V v){F f;f.p=UnityObjectToClipPos(v.p);f.uv=v.uv;return f;}
   float sq(float x){return x*x;}
   float4 over(float4 dst,float3 color,float alpha){alpha=saturate(alpha);return float4(color*alpha+dst.rgb*(1-alpha),alpha+dst.a*(1-alpha));}
   float stroke(float distance,float width,float aa){return 1-smoothstep(width*.5-aa,width*.5+aa,abs(distance));}
   float4 edge(float angle){
    float t=frac(angle/6.283185307+1);
    float4 a=float4(155,181,220,35.7),b=float4(190,228,247,25.5);
    if(t<.14)return lerp(a,b,t/.14)/255;
    a=b;b=float4(216,229,252,61.2);if(t<.3)return lerp(a,b,(t-.14)/.16)/255;
    a=b;b=float4(140,166,205,30.6);if(t<.48)return lerp(a,b,(t-.3)/.18)/255;
    a=b;b=float4(232,235,255,71.4);if(t<.65)return lerp(a,b,(t-.48)/.17)/255;
    a=b;b=float4(253,253,255,145.35);if(t<.77)return lerp(a,b,(t-.65)/.12)/255;
    a=b;b=float4(194,211,241,79.05);if(t<.87)return lerp(a,b,(t-.77)/.10)/255;
    return lerp(b,float4(155,181,220,35.7),(t-.87)/.13)/255;
   }
   float4 lip(float angle){
    float t=frac(angle/6.283185307+1);
    float4 a=float4(184,206,241,112.2),b=float4(179,226,250,102);
    if(t<.2)return lerp(a,b,t/.2)/255;
    a=b;b=float4(218,221,255,117.3);if(t<.45)return lerp(a,b,(t-.2)/.25)/255;
    a=b;b=float4(240,247,255,234.6);if(t<.68)return lerp(a,b,(t-.45)/.23)/255;
    a=b;b=float4(255,254,255,255);if(t<.8)return lerp(a,b,(t-.68)/.12)/255;
    return lerp(b,float4(184,206,241,112.2),(t-.8)/.2)/255;
   }
   float4 lens(float t){
    float4 a=float4(253,252,255,53.55),b=float4(188,214,241,10.2);
    if(t<.38)return lerp(a,b,saturate(t/.38))/255;
    a=b;b=float4(164,191,235,16.575);if(t<.72)return lerp(a,b,(t-.38)/.34)/255;
    return lerp(b,float4(214,229,255,68.85),saturate((t-.72)/.28))/255;
   }
   float4 frag(F f):SV_Target {
    const float radius=60,extent=78;
    float2 p=(float2(f.uv.x,1-f.uv.y)-.5)*(2*extent);
    float distance=length(p),rim=distance-radius,angle=atan2(p.y,p.x);
    float aa=max(.17,fwidth(distance)*.65),opacity=_Light.w;
    float fade=saturate(_Light.z);fade=fade*fade*(3-2*fade);
    float4 result=0,baseEdge=edge(angle);
    float staticOpacity=baseEdge.a*(opacity/.64)*.72;
    result=over(result,baseEdge.rgb,staticOpacity*stroke(rim,3.6,aa));
    result=over(result,baseEdge.rgb,staticOpacity*stroke(rim-2.8,.55,aa));
    result=over(result,baseEdge.rgb,staticOpacity*stroke(rim+2.7,.55,aa));
    // One angular peak for every cardinal/diagonal. Wrap safely through zero.
    float delta=atan2(sin(angle-_Light.x),cos(angle-_Light.x));
    float light=saturate(_Light.y)*exp(-.5*sq(delta/.38));
    float shine=.5+.5*cos(angle+3.141592654*.65);
    float3 pearl=float3(242+13*shine,244+11*shine,255)/255;
    float halo=exp(-.5*sq(rim/4.5));
    result=over(result,float3(196,221,255)/255,opacity*light*.17*halo);
    result=over(result,float3(177,208,255)/255,opacity*light*.30*stroke(rim,7,aa));
    result=over(result,pearl,opacity*light*.91*stroke(rim,1.9,aa));
    result=over(result,float3(188,218,255)/255,opacity*light*.38*stroke(rim+2.3,.8,aa));
    result=over(result,pearl,opacity*light*.91*stroke(rim-1.8,.65,aa));
    result=over(result,float3(227,238,255)/255,.19*(1-smoothstep(1.6-aa,1.6+aa,distance)));

    float2 q=p-_Thumb.xy;
    float k=_Thumb.z,thumbDistance=length(q),thumbAngle=atan2(q.y,q.x);
    float thumbAa=max(.17,fwidth(thumbDistance)*.65),inside=1-smoothstep(k-thumbAa,k+thumbAa,thumbDistance);
    // The ray/circle intersection reproduces the offset radial glass gradient.
    float2 origin=float2(-.38,-.48)*k,ray=q-origin;
    float A=dot(ray,ray),B=dot(origin,ray),C=dot(origin,origin)-k*k;
    float gradient=A/max(.0001,-B+sqrt(max(0,B*B-A*C)));
    float4 glass=lens(gradient);
    result=over(result,glass.rgb,glass.a*opacity*inside);
    float4 bevel=lip(thumbAngle);
    float thumbHalo=exp(-.5*sq((thumbDistance-k)/2.5));
    result=over(result,float3(196,221,255)/255,bevel.a*opacity*.22*thumbHalo);
    result=over(result,bevel.rgb,bevel.a*opacity*stroke(thumbDistance-k,1.6,thumbAa));
    result=over(result,bevel.rgb,bevel.a*opacity*stroke(thumbDistance-k+2,.45,thumbAa));
    // Small elongated upper reflection, not an opaque thumb fill.
    float2 s=q-float2(-.22,-.42)*k;
    s=float2(.9393727*s.x-.3428978*s.y,.3428978*s.x+.9393727*s.y);
    float ellipse=length(s/float2(k*.42,k*.11));
    float specular=(1-smoothstep(.83,1.17,ellipse))*saturate(1-abs(q.x/k));
    result=over(result,float3(247,250,255)/255,opacity*.43*specular);
    return result*fade;
   }
   ENDCG
  }
 }
}

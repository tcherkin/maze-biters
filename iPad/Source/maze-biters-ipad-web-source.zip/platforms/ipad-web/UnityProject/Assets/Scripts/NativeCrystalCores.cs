using System;
using UnityEngine;
namespace MazeBiters.NativeStudy {
 [Serializable] public sealed class CrystalCoreComparison {
  public bool passed;public int changedMazePixels,changedEmissionPixels,changedReliefPixels,outsideChanges,wallChanges,floorChanges,lowReceiverOutsideChanges;
  public int separatedGapPixels,nonEmissiveGapPixels,gapReceiverPixels,opaqueCorePixels;
  public int coreSurfacePixels,translucentCorePixels,clearBodyPixels;
  public int testedCorePerimeterPixels,outsideCleanPerimeterPixels,extraPerimeterGlassPixels;
  public int opaqueWallChanges,partialWallChanges,partialWallOutsideChanges,partialWallCompositeErrors,backedCurveWallPixels;
 }
 [Serializable] public sealed class CrystalOuterMaterialAudit {
  public string theme,quality;
  public int sourceTile=10,sourceSamples,brightChannelSamples,topMin,topMax,bottomMin,bottomMax;
  public double maxEmissionSource,maxEmissionSurface;
 }
 [Serializable] public sealed class CrystalRoundedTileAudit {
  public bool evaluated;public int affectedCorePixels,roundedRecessPixels;
  public double gapHalfInTiles=.0085,gapFeatherInTiles=.0035,cornerRadiusInTiles=.035,maxNormalError;
  public int authoredCurvePixels,curveRevealedPixels,curveJunctionPixels;public double maxCurveNormalError;
 }
 [Serializable] public sealed class CrystalSeamLayout {
  public int periodX,periodY,originX,originY;
  public double phaseX,phaseY,wallHorizontalJoin,wallVerticalJoin1,wallVerticalJoin2;
 }
 public sealed partial class NativeMazeArtwork {
  // Production iPad presentation. The opt-out is reserved for explicit
  // diagnostic controls; every ordinary menu/cache/gameplay path gets cores.
  public static readonly bool CrystalCoresEnabled=Array.IndexOf(Environment.GetCommandLineArgs(),"--no-crystal-cores")<0;
  readonly bool crystalCores;
  Color32[] crystalMaterial,crystalLight;
  public CrystalOuterMaterialAudit OuterCrystalMaterial{get;private set;}
  public CrystalSeamLayout CoreSeams{get;private set;}
  public CrystalRoundedTileAudit RoundedTiles{get;private set;}
  int[] roundedPixelRows,roundedRecessRows;double[] roundedNormalRows;
  int[] authoredCurveRows,curveRevealRows,curveJunctionRows;double[] curveNormalRows;
  byte[] crystalProbeWall;
  int[] backedCurveWallRows,partialCompositeErrorRows;
  int backedCurveWallPixels,partialWallCompositeErrors;
  internal bool IsCrystalSample(double logicalX,double logicalY){
   if(!crystalCores||!IsGlass)return false;
   int x=(int)Math.Floor(logicalX*glassSize/16),y=(int)Math.Floor(logicalY*glassSize/16);
   if(x<0||y<0||x>=glassWidth||y>=glassHeight||!CrystalInterior(x,y,out _,out _))return false;
   int tile=masks[x/glassSize,y/glassSize];if(tile<0)return true;
   if(crystalProbeWall==null)crystalProbeWall=GlassRead(System.IO.Path.Combine(System.IO.Path.GetDirectoryName(brushRoot),"glass-brushes",Theme,GlassQuality,"wall.rgba.gz"),16*glassSize*glassSize*4);
   return crystalProbeWall[((y%glassSize)*16*glassSize+tile*glassSize+x%glassSize)*4+3]==0;
  }
  // Between four solid cell centres only. This never infers solidity from
  // darkness, rendered wall masks or a visually enclosed walkable corridor.
  bool CrystalInterior(int x,int y,out double u,out double v){
   double px=(x+.5)/glassSize-.5,py=(y+.5)/glassSize-.5;
   int bx=(int)Math.Floor(px),by=(int)Math.Floor(py);u=px-bx;v=py-by;
   if(!Block(bx,by))return false;
   const double inset=.155,round=.20;
   bool l=!Block(bx-1,by),r=!Block(bx+1,by),t=!Block(bx,by-1),b=!Block(bx,by+1);
   if(l&&u<inset||r&&u>1-inset||t&&v<inset||b&&v>1-inset)return false;
   bool Corner(double a,double z){double c=inset+round;return a>=c||z>=c||(a-c)*(a-c)+(z-c)*(z-c)<=round*round;}
   if(l&&t&&!Corner(u,v)||r&&t&&!Corner(1-u,v)||l&&b&&!Corner(u,1-v)||r&&b&&!Corner(1-u,1-v))return false;
   // Re-entrant corners retain a rounded socket for the authored glass bend.
   double rr=inset*inset;
   if(!l&&!t&&!Block(bx-1,by-1)&&u*u+v*v<rr)return false;
   if(!r&&!t&&!Block(bx+1,by-1)&&(1-u)*(1-u)+v*v<rr)return false;
   if(!l&&!b&&!Block(bx-1,by+1)&&u*u+(1-v)*(1-v)<rr)return false;
   if(!r&&!b&&!Block(bx+1,by+1)&&(1-u)*(1-u)+(1-v)*(1-v)<rr)return false;
   return true;
  }
  bool CrystalPixel(int x,int y,ref Color32 maze,ref Color32 light,bool curvedOnly=false){
   if(!crystalCores||!CrystalInterior(x,y,out _,out _))return false;
   var facet=CrystalFacetAt(x,y);
   if(curvedOnly&&!facet.authoredCurve)return false;
   if(facet.outsidePanelDomain){maze=new Color32(0,0,0,64);light=new Color32(0,0,0,0);return true;}
   GemCorePixel(x,y,facet,ref maze,ref light);
   if(curveJunctionRows!=null&&facet.curveJunction)curveJunctionRows[y]++;
   if(authoredCurveRows!=null&&facet.authoredCurve){
    authoredCurveRows[y]++;
    if(facet.perimeterClearance>facet.circularPerimeterClearance+.01&&maze.a>64)curveRevealRows[y]++;
    curveNormalRows[y]=Math.Max(curveNormalRows[y],Math.Abs(Math.Sqrt(facet.nx*facet.nx+facet.ny*facet.ny)-1));
   }
   // Explicit native-probe evidence only. Each painter row has one writer;
   // interactive level preparation allocates none of these counters.
   if(roundedPixelRows!=null&&facet.roundedCorner&&facet.straightDistance-facet.distance>.01){
    roundedPixelRows[y]++;
    // Count the geometric cutout independently of the face's optical alpha.
    // The old fully opaque material's coverage is the geometry-only witness.
    if(facet.straightDistance>=.012*glassSize&&Byte(64+191*GlassSmooth(.0085*glassSize,.012*glassSize,Math.Max(0,facet.distance)))<255)roundedRecessRows[y]++;
    roundedNormalRows[y]=Math.Max(roundedNormalRows[y],Math.Abs(Math.Sqrt(facet.nx*facet.nx+facet.ny*facet.ny)-1));
   }
   return true;
  }
  // The authored wall remains the front layer. Its translucent antialiasing
  // must reveal the adjacent crystal backing, rather than the old dark floor.
  void CrystalCurveWallPixel(int x,int y,double alpha,byte[] wall,int s,double mr,double mg,double mb,
   Color32 backing,Color32 backingLight,ref Color32 maze,ref Color32 light){
   if(!CrystalPixel(x,y,ref backing,ref backingLight,true))return;
   double ba=backing.a/255.0,a=alpha+ba*(1-alpha);
   double r=(wall[s*4]*alpha+backing.r*ba*(1-alpha))/a;
   double g=(wall[s*4+1]*alpha+backing.g*ba*(1-alpha))/a;
   double b=(wall[s*4+2]*alpha+backing.b*ba*(1-alpha))/a;
   maze=new Color32(Byte(r),Byte(g),Byte(b),Byte(a*255));
   light=new Color32(Byte(mr*alpha*255+backingLight.r*(1-alpha)),Byte(mg*alpha*255+backingLight.g*(1-alpha)),Byte(mb*alpha*255+backingLight.b*(1-alpha)),Byte(alpha*255+backingLight.a*(1-alpha)));
   if(backedCurveWallRows!=null){
    backedCurveWallRows[y]++;
    // Independent source-over invariant in premultiplied space. Quantization
    // permits one stored RGB/alpha texel; no dark floor may enter this mixture.
    double actualA=maze.a/255.0,tolerance=1.6;
    bool valid=Math.Abs(maze.r*actualA-(wall[s*4]*alpha+backing.r*ba*(1-alpha)))<=tolerance
     &&Math.Abs(maze.g*actualA-(wall[s*4+1]*alpha+backing.g*ba*(1-alpha)))<=tolerance
     &&Math.Abs(maze.b*actualA-(wall[s*4+2]*alpha+backing.b*ba*(1-alpha)))<=tolerance;
    if(!valid)partialCompositeErrorRows[y]++;
   }
  }
  void FinishCrystalTileProbe(){
   if(roundedPixelRows==null)return;
   for(int y=0;y<roundedPixelRows.Length;y++){RoundedTiles.affectedCorePixels+=roundedPixelRows[y];RoundedTiles.roundedRecessPixels+=roundedRecessRows[y];RoundedTiles.maxNormalError=Math.Max(RoundedTiles.maxNormalError,roundedNormalRows[y]);RoundedTiles.authoredCurvePixels+=authoredCurveRows[y];RoundedTiles.curveRevealedPixels+=curveRevealRows[y];RoundedTiles.curveJunctionPixels+=curveJunctionRows[y];RoundedTiles.maxCurveNormalError=Math.Max(RoundedTiles.maxCurveNormalError,curveNormalRows[y]);backedCurveWallPixels+=backedCurveWallRows[y];partialWallCompositeErrors+=partialCompositeErrorRows[y];}
   RoundedTiles.evaluated=true;roundedPixelRows=roundedRecessRows=authoredCurveRows=curveRevealRows=curveJunctionRows=null;roundedNormalRows=curveNormalRows=null;
   backedCurveWallRows=partialCompositeErrorRows=null;
  }
  struct CrystalOuterSample {public double r,g,b,er,eg,eb;}
  static CrystalOuterSample CrystalMix(CrystalOuterSample a,CrystalOuterSample b,double t)=>new CrystalOuterSample{r=a.r+(b.r-a.r)*t,g=a.g+(b.g-a.g)*t,b=a.b+(b.b-a.b)*t,er=a.er+(b.er-a.er)*t,eg=a.eg+(b.eg-a.eg)*t,eb=a.eb+(b.eb-a.eb)*t};
  // RGB and intrinsic emission use exactly the same four atlas texels/weights.
  // Each bilinear footprint is clamped INSIDE its outer-glass band. The much
  // brighter central light channel and its reflective lip are never sampled.
  CrystalOuterSample SampleCrystalOuter(byte[] wall,float[] emission,double sourceX,double sourceY,bool lower){
   int scale=glassSize/80,minY=lower?52*scale:20*scale,maxY=lower?58*scale:30*scale;
   double sx=Math.Max(6*scale,Math.Min(34*scale,sourceX)),sy=Math.Max(minY,Math.Min(maxY,sourceY));
   int x0=(int)Math.Floor(sx),x1=Math.Min(34*scale,x0+1),y0=(int)Math.Floor(sy),y1=Math.Min(maxY,y0+1);
   double fx=sx-x0,fy=sy-y0;var sample=new CrystalOuterSample();
   for(int tap=0;tap<4;tap++){
    int x=(tap&1)==0?x0:x1,y=(tap&2)==0?y0:y1;
    double weight=((tap&1)==0?1-fx:fx)*((tap&2)==0?1-fy:fy);
    int at=y*(16*glassSize)+10*glassSize+x;
    sample.r+=wall[at*4]*weight;sample.g+=wall[at*4+1]*weight;sample.b+=wall[at*4+2]*weight;
    double er=emission[at*3],eg=emission[at*3+1],eb=emission[at*3+2];
    sample.er+=er*weight;sample.eg+=eg*weight;sample.eb+=eb*weight;
    OuterCrystalMaterial.sourceSamples++;
    if(y>=34*scale&&y<52*scale)OuterCrystalMaterial.brightChannelSamples++;
    OuterCrystalMaterial.maxEmissionSource=Math.Max(OuterCrystalMaterial.maxEmissionSource,Math.Max(er,Math.Max(eg,eb)));
   }
   return sample;
  }
  void PrepareCrystalMaterial(byte[] wall,float[] emission){
   if(!crystalCores)return;
   PrepareCrystalStructure(wall);
   if(Array.IndexOf(Environment.GetCommandLineArgs(),"--crystal-core-complex")>=0)CoreStress=InspectPreparedCrystalGeometry(wall);
   PrepareGemCoreMaterial(wall,emission);
   if(Array.IndexOf(Environment.GetCommandLineArgs(),"--crystal-core-probe")>=0||Array.IndexOf(Environment.GetCommandLineArgs(),"--ipad-crystal-probe")>=0){RoundedTiles=new CrystalRoundedTileAudit();roundedPixelRows=new int[glassHeight];roundedRecessRows=new int[glassHeight];roundedNormalRows=new double[glassHeight];authoredCurveRows=new int[glassHeight];curveRevealRows=new int[glassHeight];curveJunctionRows=new int[glassHeight];curveNormalRows=new double[glassHeight];backedCurveWallRows=new int[glassHeight];partialCompositeErrorRows=new int[glassHeight];}
  }
  internal CrystalCoreComparison CompareCrystalControl(NativeMazeArtwork control){
   if(!IsGlass||!control.IsGlass||Width!=control.Width||Height!=control.Height||!pixels.IsCreated||!control.pixels.IsCreated)throw new InvalidOperationException("Core comparison requires matching unpacked glass staging");
   var result=new CrystalCoreComparison{backedCurveWallPixels=backedCurveWallPixels,partialWallCompositeErrors=partialWallCompositeErrors};
   string prefix=System.IO.Path.Combine(System.IO.Path.GetDirectoryName(brushRoot),"glass-brushes",Theme,GlassQuality);
   byte[] wall=GlassRead(System.IO.Path.Combine(prefix,"wall.rgba.gz"),16*glassSize*glassSize*4);
   bool Same(Color32 a,Color32 b)=>a.r==b.r&&a.g==b.g&&a.b==b.b&&a.a==b.a;
   for(int y=0;y<glassHeight;y++)for(int x=0;x<glassWidth;x++){
    int at=(glassHeight-1-y)*glassWidth+x;bool mazeChanged=!Same(pixels[at],control.pixels[at]),emissionChanged=!Same(glassEmissionPixels[at],control.glassEmissionPixels[at]),reliefChanged=Relief[at]!=control.Relief[at];
    if(mazeChanged)result.changedMazePixels++;if(emissionChanged)result.changedEmissionPixels++;if(reliefChanged)result.changedReliefPixels++;
    bool eligible=CrystalInterior(x,y,out _,out _);
    if(!mazeChanged&&!emissionChanged&&!reliefChanged&&!eligible)continue;
    int gx=x/glassSize,gy=y/glassSize,tile=masks[gx,gy];
    int sourceAlpha=tile>=0?wall[((y%glassSize)*16*glassSize+tile*glassSize+x%glassSize)*4+3]:0;
    bool authoredWall=sourceAlpha>0;
    if(!authoredWall&&eligible){
     var p=pixels[at];var e=glassEmissionPixels[at];
     if(p.a==255)result.opaqueCorePixels++;
     if(p.a>64&&(p.r>0||p.g>0||p.b>0)){
      result.coreSurfacePixels++;
      if(p.a>153&&p.a<255)result.translucentCorePixels++;
      if(p.a==Byte(CoreGlassBodyOpacity*255))result.clearBodyPixels++;
     }
     if(p.r==0&&p.g==0&&p.b==0&&p.a==64){
      result.separatedGapPixels++;
      if(e.r==0&&e.g==0&&e.b==0&&e.a==0)result.nonEmissiveGapPixels++;
      if(Relief[at]!=0)result.gapReceiverPixels++;
     }
     double perimeterClearance=IndependentCoreClearance(x,y,wall);
     if(perimeterClearance<.10)result.testedCorePerimeterPixels++;
     if(perimeterClearance<-1e-9){
      result.outsideCleanPerimeterPixels++;
      if(p.r!=0||p.g!=0||p.b!=0||p.a!=64||e.r!=0||e.g!=0||e.b!=0||e.a!=0)result.extraPerimeterGlassPixels++;
     }
    }
    if(!mazeChanged&&!emissionChanged&&!reliefChanged)continue;
    if(!eligible)result.outsideChanges++;
    if(!Wall(gx,gy))result.floorChanges++;
    if(authoredWall){
     result.wallChanges++;
     if(sourceAlpha==255)result.opaqueWallChanges++;
     else {result.partialWallChanges++;if(!eligible||tile!=3&&tile!=6&&tile!=9&&tile!=12)result.partialWallOutsideChanges++;}
    }
   }
   for(int i=0;i<pendingLow.Length;i++)if(!Same(pendingLow[i],control.pendingLow[i]))result.lowReceiverOutsideChanges++;
   result.passed=result.changedMazePixels>0&&result.changedEmissionPixels>0&&result.changedReliefPixels==0&&result.outsideChanges==0&&result.opaqueWallChanges==0&&result.partialWallOutsideChanges==0&&result.partialWallCompositeErrors==0&&result.wallChanges==result.partialWallChanges&&result.partialWallChanges<=result.backedCurveWallPixels&&result.floorChanges==0&&result.lowReceiverOutsideChanges==0&&result.testedCorePerimeterPixels>0&&result.extraPerimeterGlassPixels==0;
   return result;
  }
  // Independent probe predicate, derived from the exposed solid-cell boundary,
  // rather than reusing the painter's segment bins or its nearest seam.
  double IndependentCoreClearance(int x,int y,byte[] wall){
   double px=(x+.5)/glassSize-.5,py=(y+.5)/glassSize-.5,best=4;
   double nearestX=0,nearestY=0;bool projected=true;
   int bx=(int)Math.Floor(px),by=(int)Math.Floor(py);
   void Edge(double ax,double ay,double cx,double cy){double dx=cx-ax,dy=cy-ay,raw=((px-ax)*dx+(py-ay)*dy)/(dx*dx+dy*dy),t=Math.Max(0,Math.Min(1,raw));double qx=ax+t*dx,qy=ay+t*dy,ox=px-qx,oy=py-qy,d=ox*ox+oy*oy;if(d<best){best=d;nearestX=qx;nearestY=qy;projected=raw>=0&&raw<=1;}}
   for(int iy=by-1;iy<=by+1;iy++)for(int ix=bx-1;ix<=bx+1;ix++)if(Block(ix,iy)){
    if(!Block(ix,iy-1))Edge(ix,iy,ix+1,iy);
    if(!Block(ix,iy+1))Edge(ix,iy+1,ix+1,iy+1);
    if(!Block(ix-1,iy))Edge(ix,iy,ix,iy+1);
    if(!Block(ix+1,iy))Edge(ix+1,iy,ix+1,iy+1);
   }
   double distance=Math.Sqrt(best);
   int gx=x/glassSize,gy=y/glassSize,mask=masks[gx,gy];
   int sx=mask==12||mask==9?1:-1,sy=mask==3||mask==9?1:-1;
   int neighbours=(Block(gx-1,gy-1)?1:0)+(Block(gx,gy-1)?1:0)+(Block(gx-1,gy)?1:0)+(Block(gx,gy)?1:0);
   if(neighbours==3&&(mask==12||mask==6||mask==3||mask==9)){
    // Independent one-ray construction: visible glass at45degrees determines
    // an offset circle tangent to both unchanged straight wall insets. This
    // deliberately does not use the painter's fit, coefficients, bins or normals.
    double last=.10*glassSize,unit=1/Math.Sqrt(2);
    for(double r=.10*glassSize;r<=.42*glassSize;r+=.125)if(ProbeCornerAlpha(wall,mask,glassSize*.5+sx*unit*r,glassSize*.5+sy*unit*r)>=64)last=r;
    double visible=last+.0625,straight=.28*glassSize;
    double d=straight-Math.Sqrt(2)*visible+Math.Sqrt(Math.Max(0,visible*visible-2*Math.Sqrt(2)*straight*visible+2*straight*straight));
    double a=sx*(px-gx)*glassSize,b=sy*(py-gy)*glassSize;
    if(d>0&&d<.3*glassSize&&a>=-d&&b>=-d)
     return (Math.Sqrt((a+d)*(a+d)+(b+d)*(b+d))-(straight+d)+1.0)/glassSize;
   }
   return distance-.28;
  }
  double ProbeCornerAlpha(byte[] wall,int mask,double x,double y){
   double px=Math.Max(0,Math.Min(glassSize-1,x-.5)),py=Math.Max(0,Math.Min(glassSize-1,y-.5));int ix=(int)px,iy=(int)py,jx=Math.Min(glassSize-1,ix+1),jy=Math.Min(glassSize-1,iy+1);double fx=px-ix,fy=py-iy;
   double a=wall[(iy*16*glassSize+mask*glassSize+ix)*4+3]*(1-fx)+wall[(iy*16*glassSize+mask*glassSize+jx)*4+3]*fx;
   double b=wall[(jy*16*glassSize+mask*glassSize+ix)*4+3]*(1-fx)+wall[(jy*16*glassSize+mask*glassSize+jx)*4+3]*fx;return a*(1-fy)+b*fy;
  }
 }
}

using UnityEngine;

namespace MazeBiters.NativeStudy {
 public sealed class IpadSwipePad {
  public int FingerId=-1;
  public Vector2 Origin;
  public Vector2Int Direction;
  public bool Held=>FingerId>=0;
  internal bool Seen,KeysOwned;
  internal NativePlayer Owner;
 }

 // Invisible per-finger steering. Ownership is chosen only on touch-down;
 // the original trailing swipe anchor follows each finger independently.
 public sealed class IpadSwipeInput {
  public readonly IpadSwipePad[] Pads={new IpadSwipePad(),new IpadSwipePad()};
  NativeGameplayWorld world;
  int width,height;
  float threshold;
  bool active;
  public bool Duo {get;private set;}
  NativePlayer Human(int slot)=>world!=null&&slot<world.PlayerCount&&!world.GetPlayer(slot).IsAI?world.GetPlayer(slot):null;
  bool Eligible(int slot){var p=Human(slot);return active&&p!=null&&!p.Dead&&p.Lives>0&&!p.Eliminated;}

  public void BeginFrame(NativeGameplayWorld next,int displayWidth,int displayHeight,bool enabled){
   if(!ReferenceEquals(world,next)){CancelAll();world=next;}
   if(width!=displayWidth||height!=displayHeight){CancelAll();width=displayWidth;height=displayHeight;}
   active=enabled&&world!=null&&!world.GameOver&&!world.Transition;
   Duo=Human(1)!=null;threshold=Mathf.Max(10,height*.012f);
   for(int slot=0;slot<2;slot++){
    var pad=Pads[slot];pad.Seen=false;
    if(!Eligible(slot)||(pad.Held&&!ReferenceEquals(pad.Owner,Human(slot))))CancelSlot(slot);
   }
  }

  public void Touch(int fingerId,Vector2 position,TouchPhase phase){
   int slot=-1;for(int i=0;i<2;i++)if(Pads[i].FingerId==fingerId){slot=i;break;}
   if(phase==TouchPhase.Began){
    if(slot>=0)CancelSlot(slot);
    slot=Duo&&position.x>=width*.5f?1:0;
    if(!Eligible(slot)||Pads[slot].Held)return;
    var pad=Pads[slot];pad.FingerId=fingerId;pad.Origin=position;pad.Direction=Vector2Int.zero;pad.Owner=Human(slot);pad.Seen=true;
    return;
   }
   if(slot<0)return;
   if(phase==TouchPhase.Ended||phase==TouchPhase.Canceled){CancelSlot(slot);return;}
   var p=Pads[slot];p.Seen=true;
   if(!Eligible(slot)||!ReferenceEquals(p.Owner,Human(slot))){CancelSlot(slot);return;}
   var delta=position-p.Origin;float length=delta.magnitude;
   if(length<threshold)return;
   var direction=IpadSwipeDirections.Choose(delta,p.Direction);
   if(direction!=p.Direction){IpadSwipeDirections.Sync(world,p.Owner,direction);p.Direction=direction;p.KeysOwned=true;}
   if(length>threshold*3)p.Origin=position-delta/length*(threshold*3);
  }

  public void EndFrame(){for(int slot=0;slot<2;slot++)if(Pads[slot].Held&&!Pads[slot].Seen)CancelSlot(slot);}
  public void CancelAll(){for(int slot=0;slot<2;slot++)CancelSlot(slot);}
  void CancelSlot(int slot){
   var p=Pads[slot];
   // A hidden prepared scene may share the world; never release keys it did not own.
   if(p.KeysOwned)IpadSwipeDirections.Release(world,p.Owner);
   p.FingerId=-1;p.Origin=Vector2.zero;p.Direction=Vector2Int.zero;p.Seen=p.KeysOwned=false;p.Owner=null;
  }
 }
}

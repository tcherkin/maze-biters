using System;
using System.IO;
using System.Collections.Generic;
using System.Threading.Tasks;
using UnityEngine;
using UnityEngine.Rendering;
namespace MazeBiters.NativeStudy {
 [Serializable]class CageFile {public Cage[] entries;}
 [Serializable]class Cage {public int back,mirror,frame;public float[] vertices;}
 public sealed partial class NativeTurnBank:IDisposable {
  public readonly int Size;public readonly string Quality;
  readonly PackedArt art;readonly Mesh quad;readonly Camera camera;readonly GameObject renderObject;readonly MeshRenderer renderer;readonly MeshFilter filter;
  readonly MaterialPropertyBlock block=new MaterialPropertyBlock();readonly Dictionary<string,Mesh> meshes=new Dictionary<string,Mesh>();
  readonly CommandBuffer direct=new CommandBuffer{name="Exact character compositor"};
  readonly Dictionary<string,Texture2DArray> shapes=new Dictionary<string,Texture2DArray>();readonly Dictionary<string,Texture2D> caps=new Dictionary<string,Texture2D>();
  readonly Dictionary<int,Texture2DArray> apertures=new Dictionary<int,Texture2DArray>();
  Material intakeCardinal,intakeTurn;
  Material hunterEyeCardinal,hunterEyeTurn;readonly Dictionary<string,Texture2DArray> hunterEyes=new Dictionary<string,Texture2DArray>();
  static Task<CageFile[]> earlyCages;Task<CageFile[]> cageSources;
  static CageFile[] ReadCages(string root)=>new[]{JsonUtility.FromJson<CageFile>(File.ReadAllText(Path.Combine(root,"fantasy-cages.json"))),JsonUtility.FromJson<CageFile>(File.ReadAllText(Path.Combine(root,"dragon-cages.json")))};
  internal static void QueueCageSources(){string root=Path.Combine(WebFiles.Root,"Animation");earlyCages=WebWorkQueue.Run(()=>ReadCages(root));}
  public long TextureBytes{get;private set;}public long MeshBytes{get;private set;}
  public NativeTurnBank(string quality,PackedArt art,Mesh quad,bool deferred=false){
   Quality=quality;Size=quality=="4k"?160:80;this.art=art;this.quad=quad;
   var go=new GameObject("Shared native turn compositor");camera=go.AddComponent<Camera>();camera.enabled=false;camera.orthographic=true;camera.orthographicSize=.5f;camera.aspect=1;
   camera.transform.position=new Vector3(.5f,-.5f,-10);camera.clearFlags=CameraClearFlags.SolidColor;camera.backgroundColor=Color.clear;camera.cullingMask=1<<28;camera.allowHDR=camera.allowMSAA=false;
   renderObject=new GameObject("Shared turn cage");renderObject.layer=28;filter=renderObject.AddComponent<MeshFilter>();renderer=renderObject.AddComponent<MeshRenderer>();renderer.enabled=false;
   if(deferred){cageSources=earlyCages;earlyCages=null;if(cageSources==null){string root=Path.Combine(WebFiles.Root,"Animation");cageSources=WebWorkQueue.Run(()=>ReadCages(root));}}
   if(!deferred)foreach(var step in PrepareCagesSteps()){}
  }
  public IEnumerable<object> PrepareCagesSteps(){
   CageFile[] sources=null;if(cageSources!=null){while(!cageSources.IsCompleted)yield return "wait";sources=cageSources.GetAwaiter().GetResult();cageSources=null;}int familyIndex=0;
   foreach(var family in new[]{"fantasy","dragon"}){
    var cages=sources!=null?sources[familyIndex++]:JsonUtility.FromJson<CageFile>(File.ReadAllText(Path.Combine(WebFiles.Root,"Animation/"+family+"-cages.json")));
    if(NativeBalancedLaunch.Distributed)yield return "turn cage source";
    foreach(var c in cages.entries){int count=c.vertices.Length/6;var points=new Vector3[count];var side=new Vector2[count];var end=new Vector2[count];var control=new Vector2[count];var ids=new int[count];
     for(int i=0;i<count;i++){int k=i*6;side[i]=new Vector2(c.vertices[k],c.vertices[k+1]);end[i]=new Vector2(c.vertices[k+2],c.vertices[k+3]);control[i]=new Vector2(c.vertices[k+4],c.vertices[k+5]);points[i]=new Vector3(side[i].x,-side[i].y,0);ids[i]=i;}
     var m=new Mesh{name=family+":"+c.back+":"+c.mirror+":"+c.frame};m.vertices=points;m.uv=side;m.uv2=end;m.uv3=control;m.triangles=ids;m.bounds=new Bounds(new Vector3(.5f,-.5f,0),new Vector3(4,4,2));m.UploadMeshData(true);meshes.Add(m.name,m);MeshBytes+=count*40;
     if(NativeBalancedLaunch.Distributed)yield return "turn cage mesh";
    }
   }
  }
  string Key(string family,string palette,int d)=>family+":"+palette+":"+NativeLevelStudy.DirectionNames[d];
  string Prefix(string key)=>Path.Combine(WebFiles.Root,"Reference/anim-"+Quality+"-"+key.Replace(':','-'));
  Texture2DArray Shape(string key){
   if(shapes.TryGetValue(key,out var found))return found;long trace=NativeStallTrace.Stamp();var bytes=File.ReadAllBytes(Prefix(key)+"-shape.bin");if(bytes.Length!=Size*Size*49)throw new InvalidDataException("Shape length "+key);
   var array=new Texture2DArray(Size,Size,49,TextureFormat.R8,false,true){filterMode=FilterMode.Bilinear,wrapMode=TextureWrapMode.Clamp,name=key+" silhouette"};
   for(int f=0;f<49;f++)array.SetPixelData(bytes,0,f,Size*Size*f);array.Apply(false,true);shapes.Add(key,array);TextureBytes+=bytes.Length;if(NativeStallTrace.Enabled)NativeStallTrace.Add("load-shape:"+key,trace);return array;
  }
  Texture2D Cap(string key,int frame){
   if(!key.EndsWith(":up"))frame=0;var cacheKey=key+":"+frame;if(caps.TryGetValue(cacheKey,out var found))return found;
   long trace=NativeStallTrace.Stamp();var path=Prefix(key)+"-cap.bin";var bytes=new byte[Size*Size*4];using(var file=File.OpenRead(path)){file.Position=(long)frame*bytes.Length;int n=0;while(n<bytes.Length){int got=file.Read(bytes,n,bytes.Length-n);if(got==0)throw new EndOfStreamException(path);n+=got;}}
   var flipped=new byte[bytes.Length];for(int y=0;y<Size;y++)Buffer.BlockCopy(bytes,y*Size*4,flipped,(Size-1-y)*Size*4,Size*4);
   var texture=new Texture2D(Size,Size,TextureFormat.RGBA32,false,false){filterMode=FilterMode.Bilinear,wrapMode=TextureWrapMode.Clamp,name=cacheKey+" clean cap"};texture.LoadRawTextureData(flipped);texture.Apply(false,true);caps.Add(cacheKey,texture);TextureBytes+=bytes.Length;
   // Cap residency is bounded; no per-frame growth over an extended session.
   if(caps.Count>capCapacity){string oldest=null;foreach(var k in caps.Keys){oldest=k;break;}var old=caps[oldest];caps.Remove(oldest);TextureBytes-=(long)Size*Size*4;UnityEngine.Object.Destroy(old);}if(NativeStallTrace.Enabled)NativeStallTrace.Add("load-cap:"+cacheKey,trace);return texture;
  }
  public Material Cardinal(string family,string palette,int dir)=>art.materials[(family=="fantasy"?"fantasy-biters":"dragon-kin")+":"+palette+":"+NativeLevelStudy.DirectionNames[dir]];
  Texture2DArray Aperture(int d){if(apertures.TryGetValue(d,out var a))return a;var bytes=File.ReadAllBytes(Path.Combine(WebFiles.Root,"Reference/intake-"+Quality+"-"+NativeLevelStudy.DirectionNames[d]+".bin"));a=new Texture2DArray(Size,Size,49,TextureFormat.R8,false,true){filterMode=FilterMode.Bilinear,wrapMode=TextureWrapMode.Clamp};for(int f=0;f<49;f++)a.SetPixelData(bytes,0,f,Size*Size*f);a.Apply(false,true);apertures.Add(d,a);TextureBytes+=bytes.Length;return a;}
  // Exactly the production ownership/UV shader, with anatomy masks in place of paint.
  // Called after Render: source poses and closure-specific cage are already resident.
  public void RenderIntake(NativeTurnActor actor,TurnPose pose,int mouth,RenderTexture output){
   if(intakeCardinal==null){intakeCardinal=new Material(Shader.Find("MazeBiters/IntakeCardinal"));intakeTurn=new Material(Shader.Find("MazeBiters/fantasyMaskTurn"));}
   if(pose.from==pose.to||pose.mix<1e-9||pose.mix>1-1e-9){int d=pose.mix>1-1e-9?pose.to:pose.from;intakeCardinal.SetTexture("_Mask",Aperture(d));intakeCardinal.SetFloat("_Frame",mouth);Draw(output,quad,intakeCardinal);return;}
   int side=pose.from%2==0?pose.from:pose.to,end=pose.from%2==1?pose.from:pose.to;bool back=end==3,mirror=side==2;
   intakeTurn.CopyPropertiesFromMaterial(actor.Turn);intakeTurn.SetTexture("uSideMask",Aperture(side));intakeTurn.SetTexture("uEndMask",Aperture(end));
   Draw(output,meshes["fantasy:"+(back?1:0)+":"+(mirror?1:0)+":"+mouth],intakeTurn);
  }
  void Draw(RenderTexture target,Mesh mesh,Material material,Vector4? frames=null){
   if(RendererTuning.Optimized){block.Clear();if(frames.HasValue)block.SetVector("_Frames",frames.Value);direct.Clear();direct.SetRenderTarget(target);direct.ClearRenderTarget(false,true,Color.clear);direct.SetViewProjectionMatrices(camera.worldToCameraMatrix,camera.projectionMatrix);direct.DrawMesh(mesh,Matrix4x4.identity,material,0,0,block);Graphics.ExecuteCommandBuffer(direct);return;}
   filter.sharedMesh=mesh;renderer.sharedMaterial=material;block.Clear();if(frames.HasValue)block.SetVector("_Frames",frames.Value);renderer.SetPropertyBlock(block);renderer.enabled=true;camera.targetTexture=target;camera.Render();RenderProfile.Camera();renderer.enabled=false;camera.targetTexture=null;
  }
  Texture2DArray HunterEyes(string palette,int direction){
   string key=palette+"-"+NativeLevelStudy.DirectionNames[direction];if(hunterEyes.TryGetValue(key,out var found))return found;
   long trace=NativeStallTrace.Stamp();var bytes=File.ReadAllBytes(Path.Combine(WebFiles.Root,"Reference/hunter-eye-"+Quality+"-"+key+".bin"));
   if(bytes.Length!=Size*Size*25)throw new InvalidDataException("Hunter iris bank "+key);
   var array=new Texture2DArray(Size,Size,25,TextureFormat.R8,false,true){filterMode=FilterMode.Bilinear,wrapMode=TextureWrapMode.Clamp};
   for(int f=0;f<25;f++)array.SetPixelData(bytes,0,f,Size*Size*f);array.Apply(false,true);hunterEyes.Add(key,array);TextureBytes+=bytes.Length;if(NativeStallTrace.Enabled)NativeStallTrace.Add("load-eyes:"+key,trace);return array;
  }
  // Render immediately after the normal pose. Reuse its exact closure cage,
  // art alpha and ownership; only paint payload changes to authored iris masks.
  public void RenderHunterEyes(NativeTurnActor actor,TurnPose pose,int mouth,int blink,RenderTexture output){
   if(actor.Family!="dragon")throw new ArgumentException("Only Dragon eye anatomy");
   if(hunterEyeCardinal==null){hunterEyeCardinal=new Material(Shader.Find("MazeBiters/IntakeCardinal"));hunterEyeTurn=new Material(Shader.Find("MazeBiters/dragonEyeTurn"));}
   if(pose.from==pose.to||pose.mix<1e-9||pose.mix>1-1e-9){int d=pose.mix>1-1e-9?pose.to:pose.from;hunterEyeCardinal.SetTexture("_Mask",HunterEyes(actor.Palette,d));hunterEyeCardinal.SetFloat("_Frame",blink);Draw(output,quad,hunterEyeCardinal);return;}
   int side=pose.from%2==0?pose.from:pose.to,end=pose.from%2==1?pose.from:pose.to;
   hunterEyeTurn.CopyPropertiesFromMaterial(actor.Turn);hunterEyeTurn.SetFloat("uEyeFrame",blink);hunterEyeTurn.SetTexture("uSideMask",HunterEyes(actor.Palette,side));hunterEyeTurn.SetTexture("uEndMask",HunterEyes(actor.Palette,end));
   Draw(output,meshes["dragon:"+(end==3?1:0)+":"+(side==2?1:0)+":"+mouth],hunterEyeTurn);
  }
  public void Render(NativeTurnActor actor,TurnPose pose,int mouth,int blink){NativePoseCache.PoseCalls++;var key=new NativePoseKey(actor,pose,mouth,blink);if(NativePoseCache.Enabled&&actor.CachedBank==this&&actor.CachedPose.Same(key)&&actor.Output.IsCreated()){NativePoseCache.PoseHits++;return;}actor.CachedBank=this;actor.CachedPose=key;actor.OutputRevision++;var palette=actor.ArtPalette;
   if(pose.from==pose.to||pose.mix<1e-9||pose.mix>1-1e-9){int d=pose.mix>1-1e-9?pose.to:pose.from;var mat=Cardinal(actor.Family,palette,d);var f=mat.GetVector("_Frames");f.x=mouth;f.y=blink;Draw(actor.Output,quad,mat,f);return;}
   int side=pose.from%2==0?pose.from:pose.to,end=pose.from%2==1?pose.from:pose.to;bool back=end==3,mirror=side==2;float t=(float)(pose.from==side?pose.mix:1-pose.mix);
   var sideKey=Key(actor.Family,palette,side);var endKey=Key(actor.Family,palette,end);
   string cache=sideKey+":"+endKey+":"+mouth+":"+blink;
   if(cache!=actor.SourceKey){foreach(var d in new[]{side,end}){var mat=Cardinal(actor.Family,palette,d);var f=mat.GetVector("_Frames");f.x=mouth;f.y=blink;Draw(d==side?actor.Side:actor.End,quad,mat,f);}actor.SourceKey=cache;}
   var shader=actor.Turn;shader.SetTexture("uSide",actor.Side);shader.SetTexture("uEnd",actor.End);shader.SetTexture("uSideShape",Shape(sideKey));shader.SetTexture("uEndShape",Shape(endKey));
   shader.SetFloat("uShapeFrame",mouth);shader.SetFloat("uTurn",t);shader.SetFloat("uMirror",mirror?1:0);shader.SetFloat("uBack",back?1:0);shader.SetFloat("uClosure",mouth/48f);shader.SetFloat("uNativeSize",Size);
   if(actor.Family=="dragon"&&back){shader.SetTexture("uSideCap",Cap(sideKey,0));shader.SetTexture("uEndCap",Cap(endKey,mouth));}
   Draw(actor.Output,meshes[actor.Family+":"+(back?1:0)+":"+(mirror?1:0)+":"+mouth],shader);
  }
  public void Dispose(){direct.Dispose();foreach(var m in meshes.Values)UnityEngine.Object.Destroy(m);foreach(var t in shapes.Values)UnityEngine.Object.Destroy(t);foreach(var t in caps.Values)UnityEngine.Object.Destroy(t);foreach(var t in apertures.Values)UnityEngine.Object.Destroy(t);foreach(var t in hunterEyes.Values)UnityEngine.Object.Destroy(t);UnityEngine.Object.Destroy(hunterEyeCardinal);UnityEngine.Object.Destroy(hunterEyeTurn);UnityEngine.Object.Destroy(intakeCardinal);UnityEngine.Object.Destroy(intakeTurn);if(camera)UnityEngine.Object.Destroy(camera.gameObject);UnityEngine.Object.Destroy(renderObject);}
 }
 public sealed class NativeTurnActor:IDisposable {
  internal NativeTurnBank CachedBank;internal NativePoseKey CachedPose;public long OutputRevision;public bool Bright;public string ArtPalette=>Palette+(Bright?"-bright":"");public string Family,Palette,SourceKey;public readonly Material Turn,Display;public readonly RenderTexture Side,End,Output;
  public NativeTurnActor(NativeTurnBank bank,string family,string palette){Family=family;Palette=palette;Turn=new Material(Shader.Find("MazeBiters/"+family+"Turn"));
   RenderTexture Make(){var rt=new RenderTexture(bank.Size,bank.Size,0,RenderTextureFormat.ARGB32,RenderTextureReadWrite.Default){antiAliasing=1,filterMode=FilterMode.Bilinear,wrapMode=TextureWrapMode.Clamp};rt.Create();return rt;}
   Side=Make();End=Make();Output=Make();Display=new Material(Shader.Find("MazeBiters/PremultipliedImage")){mainTexture=Output};
  }
  public void Dispose(){foreach(var rt in new[]{Side,End,Output})if(rt){if(RenderTexture.active==rt)RenderTexture.active=null;rt.Release();UnityEngine.Object.Destroy(rt);}UnityEngine.Object.Destroy(Turn);UnityEngine.Object.Destroy(Display);}
 }
}

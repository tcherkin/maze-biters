using System;using UnityEngine;
namespace MazeBiters.NativeStudy {
 public sealed partial class NativeAllyBrain {
  // Original autonomousCharacterTurnVector / MazeBrain.previewTurn. A visual
  // anticipation only: it neither chooses travel directions nor consumes RNG.
  public Vector2Int VisualVector(NativePlayer p){
   var s=S(p);bool hasTarget=!string.IsNullOrEmpty(s.thought);
   if(ReferenceEquals(s.previewGrid,w.Grid)&&s.previewCell==p.Cell&&s.previewDir==p.Dir&&s.previewNext==p.Next&&s.previewHasTarget==hasTarget&&s.previewTarget==s.thoughtTarget&&s.previewRevision==w.ObstacleRevision)return s.previewVector;
   s.previewGrid=w.Grid;s.previewCell=p.Cell;s.previewDir=p.Dir;s.previewNext=p.Next;s.previewTarget=s.thoughtTarget;s.previewHasTarget=hasTarget;s.previewRevision=w.ObstacleRevision;
   return s.previewVector=p.Next!=p.Dir?p.Next:Preview(p,hasTarget?(Vector2Int?)s.thoughtTarget:null);
  }
  Vector2Int Preview(NativePlayer p,Vector2Int? target){
   Vector2Int? goal=target.HasValue?(Vector2Int?)w.Brain.Nearest(target.Value):null;if(goal==p.Cell)return Vector2Int.zero;
   var field=goal.HasValue?w.Brain.Field(goal.Value):null;var cell=p.Cell;var facing=p.Dir;int ignored=0;
   for(int step=0;step<=3;step++){
    int available=0,count=0,nonReverse=0,only=-1,onlyNonReverse=-1,forward=-1,best=-1,bestDistance=int.MaxValue;
    for(int i=0;i<dirs.Length;i++){var d=dirs[i];var n=cell+d;if(!w.Floor(n)||w.SolidEgg(n)||!SafeRoute(p,n))continue;
     available|=1<<i;count++;only=i;if(d!=-facing){nonReverse++;onlyNonReverse=i;}if(d==facing)forward=i;
     if(field!=null){int distance=field[w.Index(n)];if(distance>=0&&(distance<bestDistance||distance==bestDistance&&d==facing)){best=i;bestDistance=distance;}}
    }
    if(count==0)return Vector2Int.zero;
    if(field==null)best=forward>=0?forward:nonReverse==1?onlyNonReverse:count==1?only:-1;
    if(best<0)return Vector2Int.zero;var chosen=dirs[best];
    if(chosen!=facing)return (ignored&(1<<best))!=0?Vector2Int.zero:chosen;
    for(int i=0;i<dirs.Length;i++)if((available&(1<<i))!=0&&dirs[i]!=chosen&&dirs[i]!=-facing)ignored|=1<<i;
    cell+=chosen;facing=chosen;
   }
   return Vector2Int.zero;
  }
 }
}


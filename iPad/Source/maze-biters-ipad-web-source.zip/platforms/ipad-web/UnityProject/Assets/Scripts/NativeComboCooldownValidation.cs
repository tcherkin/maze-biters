#if UNITY_EDITOR
using System;
using UnityEngine;
namespace MazeBiters.NativeStudy {
 public static partial class NativeComboValidation {
  static void CooldownRules(NativeComboReport r){
   foreach(int mode in new[]{0,1,3,4})foreach(int tier in new[]{0,2,4}){
    var f=Active(r,mode,0,tier);var w=f.world;var p=w.Player;var d=Vector2Int.right;
    w.Snakes.RemoveAll(s=>s.Id!=10);Step(r,w);double expiry=p.Combo.CooldownUntil,upgrade=p.Combo.LastUpgradeAt;int sounds=f.StartSounds;
    Clock(w,expiry-100);var third=Add(w,p.Cell+d,d,1);int score=p.Score;Step(r,w);
    Check(r,w.ComboActive&&!p.Combo.CoolingDown&&p.Combo.ScoreMultiplier==2&&p.Score-score==250&&p.Combo.LastUpgradeAt==upgrade&&f.StartSounds==sounds,"A new snake after a short gap retains x2, with no upgrade cue: mode="+mode+", tier="+tier);
    Add(w,p.Cell+d,d,1);score=p.Score;Step(r,w);
    Check(r,p.Combo.ScoreMultiplier==4&&p.Score-score==500&&f.StartSounds==sounds+1,"Only the next uninterrupted distinct snake upgrades to x4");
    Step(r,w);Check(r,Near(p.Combo.CooldownUntil,w.Time+1000),"A resumed meal gets a fresh full grace window when it ends");
    Clock(w,w.Time+300);var fragment=Add(w,p.Cell+d,d,1);fragment.ComboLineageId=third.Id;Step(r,w);
    Check(r,p.Combo.ScoreMultiplier==4&&f.StartSounds==sounds+1,"Returning to an already counted lineage never farms the multiplier");
    Add(w,p.Cell+d,d,1);Step(r,w);Check(r,p.Combo.ScoreMultiplier==8&&f.StartSounds==sounds+2,"An uninterrupted new lineage after the resumed meal can upgrade again");
   }
   foreach(double offset in new[]{-.001,0.0,.001,500.0}){
    var f=Active(r);var w=f.world;var p=w.Player;w.Snakes.RemoveAll(s=>s.Id!=10);Step(r,w);double until=p.Combo.CooldownUntil;
    Add(w,p.Cell+Vector2Int.right,Vector2Int.right,1);w.Time=until+offset;int before=p.Score;w.AdvancePlayer();
    Check(r,offset<0?w.ComboActive&&p.Combo.ScoreMultiplier==2&&p.Score-before==250:!w.ComboActive&&p.Combo.SnakeCount==1&&p.Score-before==125,"Exact grace boundary cannot revive an expired score multiplier: offset="+offset);
   }
   {
    var f=Active(r);var w=f.world;var p=w.Player;w.Snakes.RemoveAll(s=>s.Id!=10);Clock(w,w.Time+1000);Step(r,w);int sounds=f.StartSounds;
    for(int n=0;n<2;n++){
     Clock(w,w.Time+650);w.PlaceScorpion(p.Cell+Vector2Int.right*2,Vector2Int.right);int score=p.Score;Step(r,w);
     Check(r,w.Scorpion==null&&w.ComboActive&&p.Combo.ScoreMultiplier==2&&p.Score-score==150&&Near(p.Combo.CooldownUntil,w.Time+1000)&&f.StartSounds==sounds,"Scorpion contact refreshes one second, never score tier, points or upgrade sound: "+n);
    }
    Add(w,p.Cell+Vector2Int.right,Vector2Int.right,1);Step(r,w);Check(r,p.Combo.ScoreMultiplier==2&&f.StartSounds==sounds,"Scorpion interrupts snake-only score adjacency");
    Add(w,p.Cell+Vector2Int.right,Vector2Int.right,1);Step(r,w);Check(r,p.Combo.ScoreMultiplier==4&&f.StartSounds==sounds+1,"Snake adjacency can resume after a scorpion without losing the held multiplier");
   }
   foreach(bool firstSnake in new[]{false,true}){
    var f=World();var w=f.world;var p=w.Player;if(firstSnake){Add(w,p.Cell+Vector2Int.right,Vector2Int.right,1);Step(r,w);}
    w.PlaceScorpion(p.Cell+Vector2Int.right*2,Vector2Int.right);Step(r,w);Add(w,p.Cell+Vector2Int.right,Vector2Int.right,1);Step(r,w);
    Check(r,!w.ComboActive&&p.Combo.SnakeCount==1&&f.StartSounds==0,"Scorpion cannot start an inactive snake combo, firstSnake="+firstSnake);
   }
   {
    var f=Active(r);var w=f.world;var p=w.Player;w.Snakes.RemoveAll(s=>s.Id!=10);Step(r,w);double deadline=p.Combo.CooldownUntil;
    Clock(w,w.Time+200);w.Fruits.Add(new NativeFruit{Cell=p.Cell+Vector2Int.right,Kind=0});int score=p.Score;Step(r,w);double powerUntil=p.PowerUntil;double previousDeadline=deadline;deadline=p.Combo.CooldownUntil;
    Check(r,w.ComboActive&&w.Power&&p.Score-score==50&&Near(deadline,w.Time+1000)&&deadline>previousDeadline&&Near(powerUntil,w.Time+7000),"Fruit starts independent Power with normal points and refreshes one full second of combo grace");
    double t=w.Time;w.RealTime+=10000;w.UpdateCombos();Check(r,w.Time==t&&w.ComboActive&&p.PowerUntil==powerUntil&&p.Combo.CooldownUntil==deadline,"Paused simulation spends neither grace nor fruit time");
    Clock(w,deadline);Check(r,!w.ComboActive&&w.Power&&p.PowerUntil==powerUntil&&Near(w.MovementSpeedMultiplier,(1+w.PowerStrength)*(1+w.ComboStrength)),"Fruit and combo remain independent across grace expiry");
   }
   foreach(double speed in NativeMenuState.Speeds){
    var f=Active(r);var w=f.world;var p=w.Player;w.ScoreSpeed=speed;w.ActivatePower();Clock(w,w.Time+1200);w.PauseComboFeeding();double start=w.Time;
    Check(r,Near(w.MovementSpeedMultiplier,4)&&Near((p.Combo.CooldownUntil-start)/speed,1000/speed),"Grace scales once with selected game speed, never with the x4 movement boost: "+speed);
    Clock(w,start+999);Check(r,w.ComboActive&&Near(w.MovementSpeedMultiplier,4),"Both speed multipliers hold throughout grace: "+speed);
    Clock(w,start+1000);Check(r,!w.ComboActive&&Near(w.MovementSpeedMultiplier,4),"No speed discontinuity at grace expiry: "+speed);
    Clock(w,start+2500);Check(r,Near(w.ComboStrength,0)&&w.Power&&Near(w.MovementSpeedMultiplier,2),"Existing 1500ms combo deceleration finishes independently: "+speed);
   }
   {
    var f=Active(r);var w=f.world;w.Snakes.RemoveAll(s=>s.Id!=10);w.Player.Waiting=true;w.AdvancePlayer();double expiry=w.Player.Combo.CooldownUntil;
    w.Tick(expiry);Check(r,!w.Player.Combo.Active&&w.Player.Combo.SnakeCount==0,"The regular world tick expires a stationary player's combo without input");
   }
   {
    var f=Active(r,4);var w=f.world;for(int slot=1;slot<3;slot++)using(w.ForPlayer(w.GetPlayer(slot))){AddChain(w,w.Player.Cell,Vector2Int.right);for(int n=0;n<5;n++)Step(r,w);}
    double begin=w.Time;using(w.ForPlayer(w.GetPlayer(0)))w.PauseComboFeeding();Clock(w,begin+500);using(w.ForPlayer(w.GetPlayer(1)))w.PauseComboFeeding();Clock(w,begin+1000);
    Check(r,!w.GetPlayer(0).Combo.Active&&w.GetPlayer(1).Combo.Active&&w.GetPlayer(2).Combo.Active,"Three participants keep independent combo expiry clocks");
    Clock(w,begin+1500);Check(r,!w.GetPlayer(1).Combo.Active&&w.GetPlayer(2).Combo.Active,"Expiring the second player's grace leaves the third player's feeding untouched");
   }
  }
 }
}
#endif

using System;using System.IO;using UnityEngine;
namespace MazeBiters.NativeStudy {
 public sealed class MazeArtworkValidation:MonoBehaviour {
  [Serializable] sealed class Case{public long seed;public int d,n;}
  [Serializable] sealed class Cases{public Case[] cases;}
  void Start(){try{var args=Environment.GetCommandLineArgs();int at=Array.IndexOf(args,"--report");string folder=at<0?Application.persistentDataPath:args[at+1];Directory.CreateDirectory(folder);var cases=JsonUtility.FromJson<Cases>(File.ReadAllText(Path.Combine(WebFiles.Root,"Reference/generator-visual-cases.json"))).cases;for(int i=0;i<cases.Length;i++){var e=cases[i];var g=new NativeMazeGenerator((uint)e.seed,NativeMazeGenerator.Difficulties[e.d]);var clock=System.Diagnostics.Stopwatch.StartNew();var level=g.Generate(e.n);double generation=clock.Elapsed.TotalMilliseconds;var art=new NativeMazeArtwork(level,1);var read=new Texture2D(2880,2000,TextureFormat.RGBA32,false);var rt=RenderTexture.GetTemporary(2880,2000,0);Graphics.Blit(art.Maze,rt);RenderTexture.active=rt;read.ReadPixels(new Rect(0,0,2880,2000),0,0);read.Apply();File.WriteAllBytes(Path.Combine(folder,"unity-maze-"+i+".png"),read.EncodeToPNG());File.WriteAllBytes(Path.Combine(folder,"unity-relief-"+i+".bin"),art.Relief);RenderTexture.active=null;RenderTexture.ReleaseTemporary(rt);Destroy(read);Destroy(art.Maze);Destroy(art.LowReceiver);Debug.Log($"GENERATED_VISUAL {i}: generator {generation:F2}ms total {clock.Elapsed.TotalMilliseconds:F2}ms");}Application.Quit(0);}catch(Exception e){Debug.LogException(e);Application.Quit(2);}}
 }
}

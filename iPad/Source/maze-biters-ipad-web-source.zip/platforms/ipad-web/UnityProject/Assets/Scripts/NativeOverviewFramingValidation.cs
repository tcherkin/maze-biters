using System;using UnityEngine;
namespace MazeBiters.NativeStudy {
 public static class NativeOverviewFramingValidation {
  public static int Run(){int n=0;void Check(bool ok,string label){n++;if(!ok)throw new Exception("Overview framing: "+label);}
   foreach(float aspect in new[]{16f/9,16f/10,21f/9,32f/9}){
    var f=new NativeFrame(aspect,true);double z=NativeOverviewFraming.Zoom(f,1);var full=f.ProjectBoard(288,200,z);
    Check(Math.Abs(full.y)<.0001&&Math.Abs(full.yMax-f.Height)<.0001,"overview fills full height");
    Check(full.x>0&&Math.Abs(full.x-(f.Width-full.xMax))<.0001,"symmetric side stars remain");
    Check(Math.Abs(z-1.08)<.000001,"eight percent overview enlargement");
    double lastZ=z,lastTop=0;
    for(int i=0;i<=1000;i++){
     double source=1+i/1000.0,view=NativeOverviewFraming.Zoom(f,source),cy=200/source;
     double top=NativeOverviewFraming.Y(f,cy,source,view),bottom=NativeOverviewFraming.Y(f,400-cy,source,view);
     var b=f.ProjectBoard(288,top,view);var bb=f.ProjectBoard(288,bottom,view);
     Check(Math.Abs(top+bottom-400)<.000001,"top/bottom symmetry");
     Check(Math.Abs(b.y-(f.Height-bb.yMax))<.0002,"equal visible sky at both edges");
     Check(view>=lastZ&&view-lastZ<.0011,"zoom is continuous and monotone");
     Check(b.y>=lastTop-.0001&&b.y-lastTop<.17,"sky opens smoothly with zoom");
     Check(Math.Abs(NativeOverviewFraming.Y(f,200,source,view)-200)<.000001,"centre never drifts");
     lastZ=view;lastTop=b.y;
     if(i%100==0)for(int row=0;row<25;row++){
      var point=new Vector2(f.Width/2,(float)(f.Height/2+((row+.5)*16-top)*view));
      bool inside=point.y>=0&&point.y<f.Height,hit=f.PointerCell(point,288,top,view,out var cell);
      Check(hit==inside&&(!hit||cell==new Vector2Int(18,row)),"pointer matches fitted projection");
     }
    }
    Check(Math.Abs(lastTop-52)<.0001,"close-up keeps approved sky margin");
    for(int i=0;i<=200;i++){double y=100+i;Check(Math.Abs(NativeOverviewFraming.Y(f,y,2,2)-f.CameraY(y,2))<.000001,"2x composition unchanged");}
   }
   foreach(float aspect in new[]{4f/3,9f/16}){var f=new NativeFrame(aspect,true);Check(Math.Abs(NativeOverviewFraming.Zoom(f,1)-1)<.000001,"narrow screens keep entire width");}
   var wide=new NativeFrame(16f/9,true);long start=GC.GetAllocatedBytesForCurrentThread();double sum=0;for(int i=0;i<10000;i++){double z=1+(i%1000)/1000.0;sum+=NativeOverviewFraming.Y(wide,200/z,z,NativeOverviewFraming.Zoom(wide,z));}
   Check(GC.GetAllocatedBytesForCurrentThread()==start&&sum>0,"no per-frame allocation");return n;
  }
 }
}

using System;using System.IO;using System.Linq;using System.Collections;using System.Collections.Generic;using System.Diagnostics;using UnityEngine;using UnityEngine.Profiling;
namespace MazeBiters.NativeStudy {
 public sealed partial class NativeGameplayStudy {
  [Serializable] struct PoseCacheFrame {public double gapMs,simulationMs,submitMs,mainMs;public bool focused;public int gc0;}
  [Serializable] sealed class PoseCacheMemory {public long workingSet,peakWorkingSet,privateBytes,unityUsed,unityReserved,managed;public int textures,objects;}
  [Serializable] sealed class PoseCacheReport {public bool visibilityPreparation=VisibilityPreparation.Enabled,stagedPreparation=StagedNextScene,phasedGpuSurfaces=PhasedGpuSurfaces;public long visibilityBoundsChecks,snakeSkipped,hunterSkipped,scorpionSkipped,lightSkipped;public int preparedSceneHits,preparedSceneFallbacks,mazeWaits;public double lastSceneReadyMs;public bool passed,capture;public bool renderOptimized=NativeRenderOptimization.Enabled;public long renderSampleChecks;public double renderSampleError;public string variant,quality,cpu,gpu,note,stateHash;public int width,height,logicalProcessors,gc0,gc1,gc2,allyDecisions,level;public double elapsed,cpuSeconds,allyMs;public long poseCalls,poseHits,neonCalls,neonHits,eyeCalls,eyeHits;public int[] scores,lives;public PoseCacheFrame[] frames;public PoseCacheMemory before,after;public string[] events,images;}
  PoseCacheMemory PoseCacheMemorySample(){NativeMemory.TryRead(out long ws,out long peak,out long committed);return new PoseCacheMemory{workingSet=ws,peakWorkingSet=peak,privateBytes=committed,unityUsed=Profiler.GetTotalAllocatedMemoryLong(),unityReserved=Profiler.GetTotalReservedMemoryLong(),managed=GC.GetTotalMemory(false),textures=Resources.FindObjectsOfTypeAll<Texture>().Length,objects=Resources.FindObjectsOfTypeAll<GameObject>().Length};}
  ulong poseCacheHash=14695981039346656037UL;
  void PoseCacheMix(long n){unchecked{poseCacheHash=(poseCacheHash^(ulong)n)*1099511628211UL;}}
  void PoseCacheState(){PoseCacheMix(random);PoseCacheMix(world.Level);PoseCacheMix(world.Snakes.Count);PoseCacheMix(world.Hunters.Count);PoseCacheMix(world.Fruits.Count);PoseCacheMix(world.Eggs.Count);
   for(int i=0;i<world.PlayerCount;i++){var p=world.GetPlayer(i);PoseCacheMix(p.Cell.x);PoseCacheMix(p.Cell.y);PoseCacheMix(p.Dir.x);PoseCacheMix(p.Dir.y);PoseCacheMix(p.Score);PoseCacheMix(p.Lives);PoseCacheMix(p.Dead?1:0);PoseCacheMix(BitConverter.DoubleToInt64Bits(p.PowerUntil));}
   foreach(var s in world.Snakes){PoseCacheMix(s.Id);PoseCacheMix(s.Palette);PoseCacheMix(s.Dir.x);PoseCacheMix(s.Dir.y);foreach(var c in s.Body){PoseCacheMix(c.x);PoseCacheMix(c.y);}}
   foreach(var h in world.Hunters){PoseCacheMix(h.Id);PoseCacheMix(h.Cell.x);PoseCacheMix(h.Cell.y);PoseCacheMix(h.Dir.x);PoseCacheMix(h.Dir.y);}PoseCacheMix(BitConverter.DoubleToInt64Bits(gameplayCamera.X));PoseCacheMix(BitConverter.DoubleToInt64Bits(gameplayCamera.Y));PoseCacheMix(BitConverter.DoubleToInt64Bits(gameplayCamera.Zoom));if(VisibilityPreparation.Tour){PoseCacheMix(BitConverter.DoubleToInt64Bits(cameraViewX));PoseCacheMix(BitConverter.DoubleToInt64Bits(cameraViewY));PoseCacheMix(BitConverter.DoubleToInt64Bits(cameraViewZoom));}
  }
  IEnumerator BenchmarkPoseCache(){
   Directory.CreateDirectory(Path.GetDirectoryName(report));NativeDisplay.TestAspect=16f/9;
   sessionSmoke=true;Reset(12);yield return DrainProbePreparation();
   world.LifecycleEnabled=true;world.ScorpionSpawnAt=time;world.SpawnScorpion();if(world.Scorpion!=null){world.Scorpion.NextFruit=time+100000;world.Scorpion.NextEgg=time+100000;}
   for(int i=0;i<3;i++){var cell=world.Brain.Nearest(new Vector2Int(12+i*7,12));var h=new NativeHunter{Id=100+i,Cell=cell,From=cell,Dir=Vector2Int.right,Palette=i,LastMove=time};world.Hunters.Add(h);AddActor(h,false,i);}
   for(int i=0;i<4;i++)world.Fruits.Add(new NativeFruit{Cell=world.Brain.Nearest(new Vector2Int(8+i*6,6)),Kind=i,Born=time});
   // Normal shield/power clocks and nine diagnostic lives, as in the prior natural run.
   for(int i=0;i<world.PlayerCount;i++){var p=world.GetPlayer(i);p.ShieldUntil=time+3500;p.Waiting=false;p.Lives=9;p.Score=25*(i+1);p.ExactScore=p.Score;}
   PrepareLevelResources();yield return DrainProbePreparation();sessionAudio.Muted=true;
   if(NativePoseCache.Capture){yield return ValidatePoseCachePoses();}
   var counts=new Dictionary<string,int>();var originalEvent=world.Event;world.Event=e=>{counts.TryGetValue(e.Kind,out int n);counts[e.Kind]=n+1;originalEvent?.Invoke(e);};
   var visits=new[]{new Dictionary<Vector2Int,int>(),new Dictionary<Vector2Int,int>()};
   void Pilot(){for(int i=0;i<world.PlayerCount;i++)if(!world.GetPlayer(i).IsAI)using(world.ForPlayer(world.GetPlayer(i)))StallPilot(visits[i],true);}
   void Step(){time+=1000.0/120;realClock+=1000.0/120;world.RealTime=realClock;world.Tick(time);world.UpdateAllTilts(time);sessionAudio?.Sync(world,false);}
   // Focus waiting happens before simulation. No frames are discarded inside the sample.
   if(!NativePoseCache.Capture){double limit=Time.realtimeSinceStartupAsDouble+120;while(!Application.isFocused){if(Time.realtimeSinceStartupAsDouble>limit)throw new TimeoutException("Keep the Unity test focused");yield return null;}}
   for(int f=0;f<360;f++){Pilot();Step();Render();yield return null;}
   int count=3600;var a=Environment.GetCommandLineArgs();int ci=Array.IndexOf(a,"--pose-cache-frames");if(ci>=0)count=int.Parse(a[ci+1]);
   var samples=new PoseCacheFrame[count];var images=new List<string>();GC.Collect();yield return null;var before=PoseCacheMemorySample();world.MeasureAlly=true;world.AllyCpuMs=0;world.AllyDecisions=0;counts.Clear();NativePoseCache.ResetCounters();VisibilityPreparation.Reset();
   int g0=GC.CollectionCount(0),g1=GC.CollectionCount(1),g2=GC.CollectionCount(2);long start=0;double elapsed=0,cpu=0;
   using(var process=Process.GetCurrentProcess()){double cpuStart=process.TotalProcessorTime.TotalSeconds;start=Stopwatch.GetTimestamp();long previous=0;
    for(int f=0;f<count;f++){long now=Stopwatch.GetTimestamp();Pilot();long tick=Stopwatch.GetTimestamp();Step();double sim=NativeStallTrace.Ms(tick);long submit=Stopwatch.GetTimestamp();Render();double render=NativeStallTrace.Ms(submit);PoseCacheState();samples[f]=new PoseCacheFrame{gapMs=previous==0?0:NativeStallTrace.Ms(previous),simulationMs=sim,submitMs=render,mainMs=NativeStallTrace.Ms(now),focused=Application.isFocused,gc0=GC.CollectionCount(0)};
     // Gap is start-to-start, not previous-start to current-end.
     samples[f].gapMs=previous==0?0:(now-previous)*1000.0/Stopwatch.Frequency;previous=now;
     if(NativePoseCache.Capture&&(f==0||f==180||f==720||f==1500||f==3000||f==count-1)){string name=Path.GetFileNameWithoutExtension(report)+"-"+f+".png";Capture(Path.Combine(Path.GetDirectoryName(report),name));images.Add(name);}
     yield return null;
    }
    elapsed=NativeStallTrace.Ms(start)/1000;cpu=process.TotalProcessorTime.TotalSeconds-cpuStart;
   }
   var after=PoseCacheMemorySample();var result=new PoseCacheReport{passed=target.width==(quality=="4k"?3840:1920)&&target.height==(quality=="4k"?2160:1080)&&world.AllyDecisions>50,capture=NativePoseCache.Capture,variant=NativePoseCache.Variant,quality=quality,cpu=SystemInfo.processorType,gpu=SystemInfo.graphicsDeviceName,width=target.width,height=target.height,logicalProcessors=Environment.ProcessorCount,elapsed=elapsed,cpuSeconds=cpu,allyMs=world.AllyCpuMs,allyDecisions=world.AllyDecisions,level=world.Level,stateHash=poseCacheHash.ToString("X16"),scores=Enumerable.Range(0,world.PlayerCount).Select(i=>world.GetPlayer(i).Score).ToArray(),lives=Enumerable.Range(0,world.PlayerCount).Select(i=>world.GetPlayer(i).Lives).ToArray(),frames=samples,before=before,after=after,gc0=GC.CollectionCount(0)-g0,gc1=GC.CollectionCount(1)-g1,gc2=GC.CollectionCount(2)-g2,poseCalls=NativePoseCache.PoseCalls,poseHits=NativePoseCache.PoseHits,neonCalls=NativePoseCache.NeonCalls,neonHits=NativePoseCache.NeonHits,eyeCalls=NativePoseCache.EyeCalls,eyeHits=NativePoseCache.EyeHits,events=counts.OrderBy(k=>k.Key).Select(k=>k.Key+":"+k.Value).ToArray(),images=images.ToArray(),note="Integrated pose cache, render-cost and scene preparation optimizations. Legacy switches provide diagnostic controls; no quality changes. Buffer reuse and star-cache experiments are NOT integrated. Original generated level/seed 34 and DUO VS AI; diagnostic human pilots, original AI; normal shield/power timing, 9 test lives, staged initial hunter/scorpion/fruit population. 360 warmup, fixed 120Hz simulation, real start-to-start pacing and whole-process CPU. Native wide 1920x1080 / 3840x2160 targets. Capture runs are NOT performance evidence. RAM categories are not VRAM; GPU duration unavailable. Per-frame managed-allocation counter unreliable in this Mono build; GC collections reported instead. No screenshots/forced GC inside measured non-capture runs."};
   result.renderSampleChecks=NativeRenderOptimization.SampleChecks;result.renderSampleError=NativeRenderOptimization.SampleError;
   result.visibilityBoundsChecks=VisibilityPreparation.BoundsChecks;result.snakeSkipped=VisibilityPreparation.SnakeSkipped;result.hunterSkipped=VisibilityPreparation.HunterSkipped;result.scorpionSkipped=VisibilityPreparation.ScorpionSkipped;result.lightSkipped=VisibilityPreparation.LightSkipped;result.preparedSceneHits=nextSceneHits;result.preparedSceneFallbacks=nextSceneFallbacks;result.mazeWaits=nextMazeWaits;result.lastSceneReadyMs=nextSceneReadyAt;
   File.WriteAllText(report,JsonUtility.ToJson(result,true));Application.Quit(result.passed?0:2);
  }
 }
}

using System;
namespace MazeBiters.NativeStudy {
 public sealed partial class NativeGameplayWorld {
  // World.Time is gameplay milliseconds: pausing freezes this memory and game
  // speed changes its real-time duration in the same way as movement.
  public const double HunterRevengeHold=3000,HunterRevengeDuration=35000;
  public double HunterRevenge(NativeHunter hunter){
   if(UseLegacyAi||hunter==null||hunter.RevengePlayerId<=0)return 0;
   double elapsed=Math.Max(0,Time-hunter.RevengeAt);
   if(elapsed<=HunterRevengeHold)return 1;
   if(elapsed>=HunterRevengeDuration)return 0;
   double progress=(elapsed-HunterRevengeHold)/(HunterRevengeDuration-HunterRevengeHold);
   return 1-progress*progress*(3-2*progress);
  }
  public void NotifyHuntersScorpionEaten(NativePlayer actor){
   if(UseLegacyAi||actor==null)return;
   // Only already-living hunters witness this event. There is deliberately no
   // global timestamp or egg history for future hatchlings to inherit.
   foreach(var hunter in Hunters){
    hunter.RevengePlayerId=actor.Id;hunter.RevengeAt=Time;hunter.RevengeRevision++;
    hunter.HeldDirection=null;
    var state=hunter.Brain;if(state==null)continue;
    // Invalidate the old intention without moving, turning, creating a brain,
    // or consuming random draws. The next legal decision chooses its new path.
    state.intent=null;state.intentUntil=Time;state.intentPlayerId=actor.Id;
    state.mischiefSnakeId=0;state.mischiefUntil=Time;
    state.target=null;state.planUntil=Time;state.planType=null;
    state.planTargetKey="";state.planDistance=double.PositiveInfinity;state.planStalls=0;
    state.targetHunterId=0;state.targetPlayerId=actor.Id;state.targetPlayerUntil=Time;
    state.focusUntil=Time;
   }
  }
 }
}

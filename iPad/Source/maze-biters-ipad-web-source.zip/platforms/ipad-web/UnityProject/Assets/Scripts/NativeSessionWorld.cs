using System;using System.IO;using System.Collections.Generic;using System.Linq;using UnityEngine;
namespace MazeBiters.NativeStudy {
 [Serializable] public sealed class SessionStart {public int x,y;public Vector2Int dir;}
 [Serializable] public sealed class SessionLevel {public int level;public string[] geometry;public string theme;public SessionStart[] starts;[NonSerialized] public uint paletteSeed;[NonSerialized] public Vector2Int[][] safeOpening;[NonSerialized] public int openingLayoutAttempt;}
 [Serializable] public sealed class SessionCatalogue {public int seed;public double difficulty;public SessionLevel[] levels;}
 public static class NativeLevelCatalogue {
  static SessionCatalogue data;
  public static SessionLevel Get(int n){if(data==null)data=JsonUtility.FromJson<SessionCatalogue>(File.ReadAllText(Path.Combine(WebFiles.Root,"Reference/session-levels.json")));return data.levels.FirstOrDefault(x=>x.level==n);}
 }
 public sealed partial class NativeGameplayWorld {
  public const double DeathDuration=2834,ShieldDuration=4360,ClearDuration=3488,GameOverDuration=Math.PI*2*310*3;
  public bool SessionEnabled,Transition,GameOverPending,GameOver,CatalogueFinished;
  // Movement rate is independent of score rewards (notably TURBO).
  double scoreSpeed=1;
  public double ScoreSpeed {get=>scoreSpeed;set{if(double.IsNaN(value)||double.IsInfinity(value)||value<=0||value>100)throw new ArgumentOutOfRangeException(nameof(value));scoreSpeed=value;RefreshUnplayedLifeThresholds();}}
  public int FirstLifeScore=>(int)Math.Round(5000*ScoreSpeed);
  public int LifeScoreInterval=>(int)Math.Round(10000*ScoreSpeed);
  void RefreshUnplayedLifeThresholds(){for(int i=0;i<PlayerCount;i++){var p=GetPlayer(i);if(p!=null&&p.Score==0&&p.ExactScore==0&&p.ExtraLives==0)p.NextLifeScore=FirstLifeScore;}}
  public double TransitionAt,RevealAt,GameOverAt,RealTime,ConsumptionUntil;
  public Vector2Int PlayerStart,StartDirection=new Vector2Int(0,1);
  public Func<int,SessionLevel> LevelLoader;
  public uint SnakePaletteSeed {get;private set;}
  public string MusicTrack;
  readonly Dictionary<int,string> musicAssignments=new Dictionary<int,string>();
  readonly List<int>[] musicBags={new List<int>(),new List<int>()};readonly int[] lastMusic={-1,-1};
  public bool CompletionBright=>Transition&&Time>=TransitionAt&&Time-TransitionAt<ClearDuration&&(int)((Time-TransitionAt)/218)%2==0;
  public bool PlayerBright=>CompletionBright||Power&&Player.PowerBright||Player.ShieldUntil>Time&&Player.ShieldBright;
  public double DeathAlpha=>Player.Dead&&!Player.HideDeath?Pulse(Time-Player.DeathAt,872,3):0;
  public double StatusAlpha=>Transition?(Time<RevealAt?0:Pulse(Time-TransitionAt,872,4)):GameOver?Pulse(RealTime-GameOverAt,Math.PI*2*310,3):0;
  public static double Pulse(double elapsed,double cycle,int count)=>elapsed<0||elapsed>=cycle*count?0:Math.Pow(Math.Sin(Math.PI*(elapsed%cycle)/cycle),2);
  public static double Smooth(double u){u=AnimationClock.Clamp(u);return u*u*(3-2*u);}
  public double MusicGain=>CatalogueFinished?0:Transition?1-Smooth((Time-TransitionAt)/ClearDuration):GameOver?1-Smooth((RealTime-GameOverAt)/GameOverDuration):1;
  public void Sound(string name,Vector2Int? cell=null){if(SessionEnabled)Event?.Invoke(new NativeWorldEvent{Player=Player,Kind="sound",Sound=name,Cell=cell??Player.Cell,GlobalSound=!cell.HasValue,Time=Time});}
  public void RandomSound(string[] names,Vector2Int cell){if(SessionEnabled)Sound(names[Math.Min(names.Length-1,(int)(Random()*names.Length))],cell);}
  void Shuffle<T>(List<T> a){for(int i=a.Count-1;i>0;i--){int j=(int)(Random()*(i+1));var x=a[i];a[i]=a[j];a[j]=x;}}
  public string ReserveMusic(int n){if(musicAssignments.TryGetValue(n,out string assigned))return assigned;int style=(n-1)%2;var bag=musicBags[style];if(bag.Count==0){bag.AddRange(Enumerable.Range(1,9));Shuffle(bag);if(bag[bag.Count-1]==lastMusic[style]){int j=(int)(Random()*(bag.Count-1));int x=bag[j];bag[j]=bag[bag.Count-1];bag[bag.Count-1]=x;}}int track=bag[bag.Count-1];bag.RemoveAt(bag.Count-1);lastMusic[style]=track;return musicAssignments[n]="neon-"+(style==0?"stillness":"orbit")+"-level-"+track;}
  void StartMusic(){MusicTrack=ReserveMusic(Level);PickupEvent("music");}
  public void StartSession(Func<int,SessionLevel> loader){fruitVariety.Reset();ResetAdaptiveAlly();SessionEnabled=true;RefreshUnplayedLifeThresholds();TestLevelSelectionUsed=false;testNextLevel=0;LevelLoader=loader;Level=1;LevelStarted=Time;var initial=loader(1)??throw new InvalidDataException("Missing original level 1");Grid=initial.geometry;SetStarts(initial);ReserveMusic(1);for(int i=0;i<PlayerCount;i++)using(ForPlayer(GetPlayer(i)))FreshPlayer();SpawnLevelSnakes();Ally.BeginLevel();EnableLifecycle();for(int i=0;i<PlayerCount;i++)using(ForPlayer(GetPlayer(i)))ActivateShield();StartMusic();}
  void FreshPlayer(){var old=Player;var start=StartCell(old);var dir=StartDir(old);Player=new NativePlayer{Id=old.Id,IsAI=old.IsAI,Waiting=!old.IsAI,Contribution=old.Contribution,LifeSpotlight=old.LifeSpotlight,ScoreSpotlight=old.ScoreSpotlight,Palette=old.Palette,Lives=old.Lives,Score=old.Score,ExactScore=old.ExactScore,NextLifeScore=old.NextLifeScore,ExtraLives=old.ExtraLives,Dir=dir,Next=dir,Cell=start,From=start,Previous=start,MoveStarted=Time,TiltAt=Time};}
  public void ActivateShield(){Player.ShieldUntil=Time+ShieldDuration;Player.ShieldBright=true;Player.ShieldFlashAt=Time;}
  public bool StartClear(){var start=StartCell(Player);return Floor(start)&&!Occupied(start)&&!HunterAt(start)&&!ScorpionAt(start)&&!Eggs.Any(e=>e.Cell==start)&&TeammateAt(Player,start)==null;}
  public const int MaximumScore=2147483645; // Largest signed-int multiple of five.
  public void Award(int amount)=>AwardPoints(amount);
  void AwardSnake(int amount)=>AwardPoints(amount*(UseLegacyAi?1:Player.Combo.ScoreMultiplier));
  void AwardPoints(double amount){
   if(double.IsNaN(amount)||amount<=0)return;
   var p=Player;
   if(!SessionEnabled){p.Score=(int)Math.Min(MaximumScore,Math.Max(0,(double)p.Score+amount));return;}
   int leader=LeaderId;if(double.IsNaN(p.ExactScore)||p.ExactScore<p.Score)p.ExactScore=p.Score;
   p.ExactScore=Math.Min(MaximumScore,Math.Max(0,p.ExactScore+amount*Difficulty*ScoreSpeed));
   p.Score=(int)(Math.Floor((p.ExactScore+1e-9)/5)*5);bool gained=false;
   // A long doubled chain may cross many bonus thresholds at once. Compute
   // them in constant time, discard capped-life backlog as before, and keep
   // the next threshold beyond the representable score without int overflow.
   if(p.ExactScore>=p.NextLifeScore){
    long crossed=(long)Math.Floor((p.ExactScore-p.NextLifeScore)/LifeScoreInterval)+1;
    p.NextLifeScore=(int)Math.Min(int.MaxValue,(long)p.NextLifeScore+crossed*LifeScoreInterval);
    int lives=(int)Math.Min(crossed,Math.Max(0,9-p.Lives));p.Lives+=lives;p.ExtraLives+=lives;gained=lives>0;
   }
   if(gained){p.LifeSpotlight=RealTime;Sound("BonusLife@",p.Cell);}if(Multiplayer&&LeaderId==p.Id&&leader!=p.Id)p.ScoreSpotlight=RealTime;
  }
  public void SessionDeath(){
   var p=Player;if(p.Dead||GameOverPending)return;ResetCombo();Sound("HeadDie",p.Cell);if(Random()<.32)Sound("Oh_No",p.Cell);
   foreach(var s in Snakes){double old=Multiplayer?s.PersonalThreat[p.Id-1]:s.Threat;if(Multiplayer)s.PersonalThreat[p.Id-1]*=.18;else s.Threat*=.18;s.Anger=Math.Max(0,s.Anger-old*.55);s.AngerPeak=Math.Max(s.Anger,s.AngerPeak*.55);s.AngerFloor=Math.Min(s.AngerFloor,s.Anger*.6);s.LastAnger=Time;}
   foreach(var h in Hunters){if(Multiplayer)h.PersonalThreat[p.Id-1]*=.18;else h.Threat*=.18;h.Anger=Math.Max(.15,h.Anger*.65);}
   p.Pointer=null;p.PointerMomentum=false;p.Ricochet=null;p.BiteAt=p.BiteEnd=-1e6;p.PowerUntil=p.ShieldUntil=0;p.PowerBright=p.ShieldBright=false;p.Lives--;p.Dead=true;p.HideDeath=false;p.DeathAt=Time;p.RespawnAt=Time+DeathDuration;
   PickupEvent("death",p.Cell);if(AllLivesLost&&!GameOver){GameOverPending=true;gameOverUntil=p.RespawnAt;}
  }
  public void UpdateDeath(){var p=Player;if(!p.Dead||Time<p.RespawnAt)return;if(p.Lives<=0){p.HideDeath=true;p.Eliminated=true;return;}if(!StartClear()){p.HideDeath=true;return;}FreshPlayer();ActivateShield();PickupEvent("respawn",Player.Cell);}
  public bool SessionTick(){
   if(!SessionEnabled)return false;
   if(GameOverPending&&Time>=(Multiplayer?gameOverUntil:Player.RespawnAt)){GameOverPending=false;GameOver=true;GameOverAt=RealTime;for(int i=0;i<PlayerCount;i++)GetPlayer(i).HideDeath=GetPlayer(i).Eliminated=true;Sound("Game_Over");PickupEvent("gameOver");return true;}
   if(Transition){if(Time-TransitionAt>=ClearDuration)AdvanceLevel();return true;}
   for(int i=0;i<PlayerCount;i++)using(ForPlayer(GetPlayer(i))){UpdateDeath();var p=Player;if(p.ShieldUntil>Time){int toggles=(int)((Time-p.ShieldFlashAt)/218);if(toggles>0){if((toggles&1)==1)p.ShieldBright=!p.ShieldBright;p.ShieldFlashAt+=toggles*218;}}else {p.ShieldBright=false;p.ShieldUntil=0;}}
   return CatalogueFinished;
  }
  public void CheckLevelComplete(){if(!SessionEnabled||Snakes.Count!=0||Transition||GameOver||GameOverPending)return;BeginLevelTransition();}
  void BeginLevelTransition(){ResetAllCombos();Transition=true;TransitionAt=Time;RevealAt=Math.Max(Time,ConsumptionUntil);for(int i=0;i<PlayerCount;i++)RevealAt=Math.Max(RevealAt,GetPlayer(i).BiteEnd);ReserveMusic(NextLevelNumber);Sound("Congratulations");PickupEvent("levelComplete");}
  public void AdvanceLevel(){
   ResetAllCombos();long nextMark=NativeStallTrace.Stamp();bool selected=testNextLevel>0;int targetLevel=NextLevelNumber;var next=LevelLoader(targetLevel);NativeStallTrace.Add("next-maze",nextMark);nextMark=NativeStallTrace.Stamp();Transition=false;if(next==null){CatalogueFinished=true;PickupEvent("catalogueEnd");return;}
   Level=targetLevel;testNextLevel=0;Grid=next.geometry;ObstacleRevision++;SetStarts(next);for(int i=0;i<PlayerCount;i++)using(ForPlayer(GetPlayer(i))){double spot=Player.ScoreSpotlight;if(!selected)Award(500);Player.ScoreSpotlight=spot;Player.Contribution*=.35;if(Player.Lives>0)FreshPlayer();else Player.Dead=Player.Eliminated=Player.HideDeath=true;}SpawnLevelSnakes();Ally.BeginLevel();NativeStallTrace.Add("next-spawn",nextMark);nextMark=NativeStallTrace.Stamp();for(int i=0;i<PlayerCount;i++)using(ForPlayer(GetPlayer(i)))if(!Player.Dead)ActivateShield();
   Fruits.Clear();Eggs.Clear();PendingDrops.Clear();SolidEggs.Clear();Hunters.Clear();Scorpion=null;ScorpionKilled=false;eggTopology=0;LevelStarted=Time;ConsumptionUntil=0;ScorpionSpawnAt=Time+ScorpionRespawnDelay();NativeStallTrace.Add("next-lifecycle",nextMark);nextMark=NativeStallTrace.Stamp();PickupEvent("levelChanged");NativeStallTrace.Add("next-visuals",nextMark);nextMark=NativeStallTrace.Stamp();StartMusic();NativeStallTrace.Add("next-music",nextMark);
  }
  void SessionEffect(string kind,Vector2Int cell){
   if(!SessionEnabled)return;
   switch(kind){
    case "tail":case "split":case "hunterSplit":RandomSound(new[]{"Tie1","Tie2","Tie3","Tie5","TieEat"},cell);break;
    case "head":case "snakeHunterBite":Sound("HeadEat",cell);break;
    case "hunterBite":Sound("HeadEat",Player.Cell);break;
    case "fruit":RandomSound(new[]{"EatFruit1","EatFruit2","EatFruit3"},cell);break;
    case "scorpionBite":Sound("ScorpioEat",cell);break;
    case "powerWarning":Sound("Tick",Player.Cell);break;
    case "eggDrop":Sound("EggBorn",cell);break;
    case "eggCrack":Sound("EggKnock",cell);break;
    case "hatch":Sound("ManBorn",cell);break;
   }
  }
 }
}

using System;
using System.Collections;
using System.IO;
using System.Linq;
using UnityEngine;
namespace MazeBiters.NativeStudy {
 public sealed partial class NativeGameplayStudy {
  bool preparationValidation;
  [Serializable] sealed class PreparationValidationResult {
   public bool passed,stateUnchanged,loadingClockPassed;public string quality;public int images,changedPixels,lateLoads,shapes,caps,eyes,apertures,scorpionImages;public long turnBytes,scorpionBytes;
  }
  static Color32[] PreparationPixels(RenderTexture rt){
   var old=RenderTexture.active;var texture=new Texture2D(rt.width,rt.height,TextureFormat.RGBA32,false);
   try{RenderTexture.active=rt;texture.ReadPixels(new Rect(0,0,rt.width,rt.height),0,0);texture.Apply();return texture.GetPixels32();}
   finally{RenderTexture.active=old;Destroy(texture);}
  }
  IEnumerator ValidatePreparation(){
   yield return DrainProbePreparation();
   string Snapshot()=>random+"|"+time+"|"+realClock+"|"+JsonUtility.ToJson(world.Player)+"|"+events.Count+"|"+
    string.Join(";",world.Snakes.Select(JsonUtility.ToJson))+"|"+string.Join(";",world.Hunters.Select(JsonUtility.ToJson))+"|"+world.Time+"|"+world.RealTime;
   string before=Snapshot();long bytes=bank.TextureBytes;
   // Also validate a FRESH logic warmup, not merely its idempotent fast return.
   logicPrepared=false;PrepareLevelResources();
   var result=new PreparationValidationResult{quality=quality,stateUnchanged=Snapshot()==before&&bank.TextureBytes==bytes};
   // Exercise the ordinary-play loading gate too; scripted fixed-time probes
   // otherwise bypass it. No world/animation time or RNG may elapse.
   bool priorContact=contactProbe,priorSmoke=smoke;
   contactProbe=false;smoke=false;
   PrepareLevelResources();
   result.loadingClockPassed=preparationFrames==2&&WaitForLevelPreparation()&&preparationFrames==1&&
    WaitForLevelPreparation()&&preparationFrames==0&&discardPreparationDelta&&!WaitForLevelPreparation()&&Snapshot()==before;
   contactProbe=priorContact;smoke=priorSmoke;discardPreparationDelta=false;
   var scratchA=new RenderTexture(bank.Size,bank.Size,0,RenderTextureFormat.ARGB32);scratchA.Create();
   var scratchB=new RenderTexture(scratchA.descriptor);scratchB.Create();
   void Compare(RenderTexture a,RenderTexture b){
    var pa=PreparationPixels(a);var pb=PreparationPixels(b);result.images++;
    if(pa.Length!=pb.Length)throw new Exception("Preparation image size mismatch");
    for(int i=0;i<pa.Length;i++)if(!pa[i].Equals(pb[i]))result.changedPixels++;
   }
   using(var cold=new NativeTurnBank(quality,art,quad)){
    foreach(string family in new[]{"fantasy","dragon"})
     foreach(string palette in family=="fantasy"?new[]{"p1","p2","ai"}:new[]{"h1","h3","h4"})
      using(var original=new NativeTurnActor(cold,family,palette))
      using(var prepared=new NativeTurnActor(bank,family,palette))
       foreach(bool bright in family=="fantasy"?new[]{false,true}:new[]{false}){
        original.Bright=prepared.Bright=bright;
        for(int view=0;view<8;view++)foreach(int mouth in new[]{0,24,48}){
         var pose=view<4?new TurnPose{from=view,to=view,done=true}:new TurnPose{from=view<6?0:2,to=view%2==0?1:3,mix=.37};
         cold.Render(original,pose,mouth,12);
         NativeStallTrace.Begin();bank.Render(prepared,pose,mouth,12);
         if(family=="fantasy")bank.RenderIntake(prepared,pose,mouth,scratchB);
         else bank.RenderHunterEyes(prepared,pose,mouth,12,scratchB);
         result.lateLoads+=NativeStallTrace.End().Count(x=>x.name.StartsWith("load-"));
         Compare(original.Output,prepared.Output);
         if(family=="fantasy")cold.RenderIntake(original,pose,mouth,scratchA);
         else cold.RenderHunterEyes(original,pose,mouth,12,scratchA);
         Compare(scratchA,scratchB);
        }
        yield return null;
       }
   }
   // Probe every rear cap, including closures not reached by walking.
   foreach(string palette in new[]{"h1","h3","h4"})
    using(var actor=new NativeTurnActor(bank,"dragon",palette))
     for(int closure=0;closure<49;closure++){
      NativeStallTrace.Begin();bank.Render(actor,new TurnPose{from=0,to=3,mix=.5},closure,0);
      result.lateLoads+=NativeStallTrace.End().Count(x=>x.name.StartsWith("load-"));
     }
   using(var oldScorpion=new NativeScorpionArt(quad,1))
   using(var preparedScorpion=new NativeScorpionArt(quad,1,scorpionImages)){
    foreach(bool bend in new[]{false,true})for(int frame=0;frame<2;frame++){
     var motion=new NativeScorpionMotion(new Vector2Int(3,3),new Vector2Int(2,3),Vector2Int.right,
      bend?new Vector2Int(3,4):new Vector2Int(4,3),new Vector2Int(3,3),bend?Vector2Int.up:Vector2Int.right,1000,1000);
     var pose=motion.Sample(1085);pose.frame=frame;
     oldScorpion.Render(pose,quality);NativeStallTrace.Begin();preparedScorpion.Render(pose,quality);
     result.lateLoads+=NativeStallTrace.End().Count(x=>x.name.StartsWith("load-"));
     Compare((RenderTexture)oldScorpion.Display.mainTexture,(RenderTexture)preparedScorpion.Display.mainTexture);
     Compare((RenderTexture)oldScorpion.Emission.mainTexture,(RenderTexture)preparedScorpion.Emission.mainTexture);
    }
   }
   scratchA.Release();scratchB.Release();Destroy(scratchA);Destroy(scratchB);
   result.shapes=bank.ShapeCount;result.caps=bank.CapCount;result.eyes=bank.EyeCount;result.apertures=bank.ApertureCount;result.scorpionImages=scorpionImages.Count;result.turnBytes=bank.TextureBytes;result.scorpionBytes=scorpionImages.TextureBytes;
   result.passed=result.stateUnchanged&&result.loadingClockPassed&&result.changedPixels==0&&result.lateLoads==0&&result.shapes==36&&result.caps==153&&result.eyes==12&&result.apertures==4;
   Directory.CreateDirectory(Path.GetDirectoryName(report));File.WriteAllText(report,JsonUtility.ToJson(result,true));Application.Quit(result.passed?0:2);
  }
 }
}

using System;
using UnityEngine;

namespace MazeBiters.NativeStudy {
 [Serializable]public sealed class WebWallLightRecordAudit {
  public bool passed,point,clamp,linear,noMipmaps,finite,exact;
  public int width,height,sourceRecords,cellRecords,boundRecords,paddingRecords,mismatches,managedBytes;
  public long uploads;public string format,transport;
 }
 // WebGL2 guarantees fewer fragment uniforms than the complete 32-light data
 // needs on some devices. A tiny read-only float texture carries the same exact
 // float32 values, with one retained CPU array and no render target or new pass.
 internal sealed class WebWallLightRecords:IDisposable {
  internal const int Capacity=256,SourceCount=96,CellCount=96,BoundCount=32;
  internal readonly Color[] Records=new Color[Capacity];
  internal Texture2D Texture{get;private set;}
  internal long Uploads{get;private set;}
  static readonly int TextureId=Shader.PropertyToID("_MysticRouteRecords");
  internal WebWallLightRecords(){
   Texture=new Texture2D(Capacity,1,TextureFormat.RGBAFloat,false,true){name="Exact32 wall-light route records",filterMode=FilterMode.Point,wrapMode=TextureWrapMode.Clamp,anisoLevel=0};
  }
  static Color Encode(Vector4 value)=>new Color(value.x,value.y,value.z,value.w);
  static bool Same(Color a,Vector4 b)=>a.r==b.x&&a.g==b.y&&a.b==b.z&&a.a==b.w;
  static bool Same(Color a,Color b)=>a.r==b.r&&a.g==b.g&&a.b==b.b&&a.a==b.a;
  static bool Finite(float value)=>!float.IsNaN(value)&&!float.IsInfinity(value);
  static bool Finite(Color value)=>Finite(value.r)&&Finite(value.g)&&Finite(value.b)&&Finite(value.a);
  static void EncodeRecords(Color[] records,Vector4[] sources,Vector4[] cells,Vector4[] bounds){
   if(sources.Length!=SourceCount||cells.Length!=CellCount||bounds.Length!=BoundCount)throw new ArgumentException("Exact32 wall-light record dimensions");
   for(int i=0;i<SourceCount;i++)records[i]=Encode(sources[i]);
   for(int i=0;i<CellCount;i++)records[SourceCount+i]=Encode(cells[i]);
   for(int i=0;i<BoundCount;i++)records[SourceCount+CellCount+i]=Encode(bounds[i]);
   // The remaining32 texels are initialized once to zero and never sampled.
  }
  internal void Submit(Vector4[] sources,Vector4[] cells,Vector4[] bounds){
   EncodeRecords(Records,sources,cells,bounds);
   Texture.SetPixelData(Records,0);Texture.Apply(false,false);Shader.SetGlobalTexture(TextureId,Texture);Uploads++;
  }
  internal WebWallLightRecordAudit Inspect(){
   var result=new WebWallLightRecordAudit{width=Texture?Texture.width:0,height=Texture?Texture.height:0,sourceRecords=SourceCount,cellRecords=CellCount,boundRecords=BoundCount,paddingRecords=Capacity-SourceCount-CellCount-BoundCount,managedBytes=Capacity*16,uploads=Uploads,
    format=Texture?Texture.format.ToString():"missing",transport="RGBAFloat texture; one retained4096-byte CPU record array",point=Texture&&Texture.filterMode==FilterMode.Point,clamp=Texture&&Texture.wrapMode==TextureWrapMode.Clamp,linear=Texture&&!Texture.isDataSRGB,noMipmaps=Texture&&Texture.mipmapCount==1,finite=true,exact=true};
   foreach(var record in Records)if(!Finite(record))result.finite=false;
   if(Texture){var gpuSource=Texture.GetPixelData<Color>(0);for(int i=0;i<Records.Length;i++)if(!Same(gpuSource[i],Records[i]))result.mismatches++;}
   result.exact=result.mismatches==0;result.passed=result.width==256&&result.height==1&&result.format=="RGBAFloat"&&result.point&&result.clamp&&result.linear&&result.noMipmaps&&result.finite&&result.exact&&result.uploads>0;
   return result;
  }
  internal static WebWallLightRecordAudit ValidateEncoding(){
   var sources=new Vector4[SourceCount];var cells=new Vector4[CellCount];var bounds=new Vector4[BoundCount];var records=new Color[Capacity];
   for(int i=0;i<SourceCount;i++){sources[i]=new Vector4(i*6.125f-.5f,i*4.125f+1.5f,(i%3)*.18f,(i+1)+(899-i)*1024);cells[i]=new Vector4(i+13,899-i,i*3%900,0);}
   for(int i=0;i<BoundCount;i++)bounds[i]=new Vector4(i*17.5f-11.201f,i*11.25f-11.201f,i*17.5f+11.201f,i*11.25f+11.201f);
   EncodeRecords(records,sources,cells,bounds);int mismatches=0;bool finite=true;
   for(int i=0;i<SourceCount;i++)if(!Same(records[i],sources[i]))mismatches++;
   for(int i=0;i<CellCount;i++)if(!Same(records[SourceCount+i],cells[i]))mismatches++;
   for(int i=0;i<BoundCount;i++)if(!Same(records[SourceCount+CellCount+i],bounds[i]))mismatches++;
   for(int i=SourceCount+CellCount+BoundCount;i<Capacity;i++)if(!Same(records[i],Color.clear))mismatches++;
   foreach(var record in records)if(!Finite(record))finite=false;
   return new WebWallLightRecordAudit{passed=mismatches==0&&finite,width=256,height=1,sourceRecords=SourceCount,cellRecords=CellCount,boundRecords=BoundCount,paddingRecords=32,managedBytes=4096,mismatches=mismatches,finite=finite,exact=mismatches==0,format="RGBAFloat",transport="CPU exact float32 source/cell/bounds address test"};
  }
  public void Dispose(){if(Texture)UnityEngine.Object.Destroy(Texture);Texture=null;}
 }
 public sealed partial class NativeGameplayStudy {
  WebWallLightRecords webWallLightRecords;
  void SubmitWebWallLightRecords(Vector4[] sources,Vector4[] cells,Vector4[] bounds){
#if UNITY_WEBGL && !UNITY_EDITOR
   if(webWallLightRecords==null)webWallLightRecords=new WebWallLightRecords();
   webWallLightRecords.Submit(sources,cells,bounds);
#else
   // Desktop editor comparison keeps the original native uniform transport.
   Shader.SetGlobalVectorArray(SourcesId,sources);Shader.SetGlobalVectorArray(CellsId,cells);Shader.SetGlobalVectorArray(BoundsId,bounds);
#endif
  }
  void DisposeWebWallLightRecords(){webWallLightRecords?.Dispose();webWallLightRecords=null;}
 }
}

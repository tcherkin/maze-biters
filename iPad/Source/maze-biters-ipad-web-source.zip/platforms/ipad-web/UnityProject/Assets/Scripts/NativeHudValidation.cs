using System;using System.IO;using UnityEngine;
namespace MazeBiters.NativeStudy {
 [Serializable] public sealed class HudCase {public string name,image;public int score,lives,level,snakes;public double time,levelStart,lifeStart,scoreStart,lifeAlpha;}
 [Serializable] public sealed class HudCases {public int width,height;public string quality;public double scale;public HudCase[] cases;}
 public sealed class NativeHudValidation:MonoBehaviour {
  [Serializable] sealed class Result {public bool passed;public string quality,note;public int cases,pixels,maxChannelError,pixelsBeyondThree,clockChecks;public long hudTextureBytes;public double meanChannelError;}
  public static int Numeric(){
   int n=0;void Check(bool ok,string s){n++;if(!ok)throw new Exception("HUD: "+s);}
   foreach(string quality in new[]{"hd","4k"}){
    var spec=JsonUtility.FromJson<HudCases>(File.ReadAllText(Path.Combine(WebFiles.Root,"Reference/hud/"+quality+".json")));
    foreach(var c in spec.cases)Check(Math.Abs(c.lifeAlpha-NativeHud.LifeAlpha(c.lifeStart,c.time))<1e-10,c.name+" original pulse");
    Check(!NativeHud.Active(0,3720,3720),"sweep ends");Check(!NativeHud.Active(0,3720,-1),"no early sweep");
    double left=232,right=344;
    foreach(double at in new[]{1240.0,2480})Check(Math.Abs(NativeHud.BeamLeft(0,3720,3,left,right,at-1e-6,spec.scale)-NativeHud.BeamLeft(0,3720,3,left,right,at,spec.scale))<=1/spec.scale,"continuous edge reversal");
   }
   return n;
  }
  void Start(){
   string quality="hd",report=null;var args=Environment.GetCommandLineArgs();for(int i=0;i<args.Length;i++){if(args[i]=="--quality")quality=args[++i];if(args[i]=="--report")report=args[++i];}
   Application.runInBackground=true;QualitySettings.vSyncCount=0;QualitySettings.anisotropicFiltering=AnisotropicFiltering.Disable;
   var folder=Path.Combine(WebFiles.Root,"Reference/hud");var spec=JsonUtility.FromJson<HudCases>(File.ReadAllText(Path.Combine(folder,quality+".json")));
   var result=new Result{quality=quality,clockChecks=Numeric(),note="Original SOLO HUD reference images; no game artwork replaced. Native-size glyph/star/beam exports. GPU composition compared at exact HD/4K header resolution; tolerance three channel bytes."};
   var quad=new Mesh();quad.vertices=new[]{new Vector3(0,0),new Vector3(1,0),new Vector3(1,-1),new Vector3(0,-1)};quad.uv=new[]{new Vector2(0,1),new Vector2(1,1),new Vector2(1,0),new Vector2(0,0)};quad.triangles=new[]{0,1,2,0,2,3};quad.RecalculateBounds();
   var go=new GameObject("HUD validation camera");var camera=go.AddComponent<Camera>();camera.enabled=false;camera.orthographic=true;camera.orthographicSize=16;camera.aspect=18;camera.transform.position=new Vector3(288,16,-10);camera.clearFlags=CameraClearFlags.SolidColor;camera.backgroundColor=Color.black;camera.allowHDR=false;camera.allowMSAA=false;
   var target=new RenderTexture(spec.width,spec.height,0,RenderTextureFormat.ARGB32);target.Create();camera.targetTexture=target;
   var parent=new GameObject("Fixed header");var actual=new Texture2D(spec.width,spec.height,TextureFormat.RGBA32,false);var expected=new Texture2D(2,2,TextureFormat.RGBA32,false);var old=RenderTexture.active;
   long errors=0;Directory.CreateDirectory(Path.GetDirectoryName(report));
   using(var hud=new NativeHud(quad,parent.transform)){
    foreach(var c in spec.cases){
     hud.RenderValues(c.score,c.lives,c.level,c.snakes,c.time,quality,c.levelStart,c.lifeStart,c.scoreStart);
     camera.Render();RenderTexture.active=target;actual.ReadPixels(new Rect(0,0,spec.width,spec.height),0,0);actual.Apply();
     expected.LoadImage(File.ReadAllBytes(Path.Combine(folder,c.image)));var a=actual.GetPixels32();var b=expected.GetPixels32();
     for(int i=0;i<a.Length;i++){
      int r=Math.Abs(a[i].r-b[i].r),g=Math.Abs(a[i].g-b[i].g),blue=Math.Abs(a[i].b-b[i].b),alpha=Math.Abs(a[i].a-b[i].a),max=Math.Max(Math.Max(r,g),Math.Max(blue,alpha));
      errors+=r+g+blue+alpha;result.maxChannelError=Math.Max(result.maxChannelError,max);if(max>3)result.pixelsBeyondThree++;
     }
     File.WriteAllBytes(Path.Combine(Path.GetDirectoryName(report),quality+"-"+c.name+".png"),actual.EncodeToPNG());result.cases++;result.pixels+=a.Length;
    }
    result.hudTextureBytes=hud.TextureBytes;
   }
   result.meanChannelError=(double)errors/(result.pixels*4);result.passed=result.maxChannelError<=3;
   RenderTexture.active=old;File.WriteAllText(report,JsonUtility.ToJson(result,true));
   Destroy(parent);Destroy(go);Destroy(target);Destroy(actual);Destroy(expected);Destroy(quad);Application.Quit(result.passed?0:2);
  }
 }
}


using System;using System.IO;using System.Linq;using UnityEngine;using UnityEngine.InputSystem;using UnityEngine.InputSystem.LowLevel;
namespace MazeBiters.NativeStudy {
 public sealed class NativeGamepadValidation:MonoBehaviour {
  [Serializable] sealed class Result {public bool passed;public int checks;public string[] detectedDevices;public string note;}
  public static int Run(bool deviceEvents=false){
   int n=0;void Check(bool ok,string message){n++;if(!ok)throw new Exception("Gamepad: "+message);}
   var pad=new NativePadState{Id=101};
   Check(pad.Directions==0&&!pad.Tilt.HasValue,"neutral");
   foreach(float value in new[]{-.419f,0,.419f}){pad.Stick=new Vector2(value,0);Check(pad.Directions==0,"original stick threshold");}
   pad.Stick=new Vector2(.42f,-.42f);Check(pad.Directions==6,"analogue right+up");
   pad.Left=true;Check(pad.Directions==5,"D-pad wins its axis");Check(pad.Tilt==new Vector2(-1,0),"D-pad owns visual vector");pad.Left=false;
   pad.Stick=new Vector2(.2f,.1f);Check(pad.Directions==0&&pad.Tilt.HasValue,"sub-movement analogue lean");
   var menu=new NativePadMenu();pad=new NativePadState{Id=101,Down=true};
   Check(menu.Move(pad,0)==1,"D-pad immediate menu move");Check(menu.Move(pad,359)==-1,"menu initial delay");Check(menu.Move(pad,360)==1,"360ms first repeat");Check(menu.Move(pad,494)==-1&&menu.Move(pad,495)==1,"135ms repeat");
   pad.Down=false;pad.Right=true;Check(menu.Move(pad,500)==3,"changed direction immediate");Check(menu.Move(default,510)==-1,"disconnect releases UI");pad.Id=102;Check(menu.Move(pad,520)==3,"replacement controller immediate");
   var grid=new[]{"#########","#.......#","#.......#","#.......#","#.......#","#.......#","#########"};
   foreach(int mode in new[]{1,2,3,4,5}){
    var w=new NativeGameplayWorld(grid,()=>.5){Time=1000};w.SetMode(mode);
    for(int i=0;i<w.PlayerCount;i++){var p=w.GetPlayer(i);p.Cell=p.From=p.Previous=new Vector2Int(2+i*2,3);p.Dir=p.Next=Vector2Int.right;}
    var one=w.GetPlayer(0);NativeGamepadInput.Sync(w,0,new NativePadState{Id=101,Right=true},true);
    Check(one.Keys.Count==1&&!one.Waiting&&one.Next==Vector2Int.right,"P1 pad mode "+mode);
    w.AdvancePlayer();Check(one.Cell==new Vector2Int(3,3),"pad drives actual world cell mode "+mode);
    NativeGamepadInput.Sync(w,1,new NativePadState{Id=102,Down=true},true);
    if(mode==2||mode==4||mode==5){var two=w.GetPlayer(1);Check(two.Keys.Count==1&&two.Next==new Vector2Int(0,1),"second pad belongs to P2");using(w.ForPlayer(two))w.AdvancePlayer();Check(two.Cell==new Vector2Int(4,4),"P2 actual movement");}
    else Check(w.PlayerCount==1||w.GetPlayer(1).Keys.Count==0,"pad cannot drive AI");
    if(mode==4)Check(w.GetPlayer(2).Keys.Count==0,"AI3 untouched");
    NativeGamepadInput.Sync(w,0,default,true);Check(one.Keys.Count==0&&!one.GamepadTilt.HasValue,"unplug releases held direction");
    w.Press("D",Vector2Int.right);NativeGamepadInput.Sync(w,0,new NativePadState{Id=103,Up=true},true);Check(one.Keys.Count==2,"keyboard+pad coexist");
    NativeGamepadInput.Sync(w,0,default,true);Check(one.Keys.ContainsKey("D")&&one.Keys.Count==1,"unplug does not release keyboard");w.ClearAllKeys();
    NativeGamepadInput.Sync(w,0,new NativePadState{Id=103,Left=true},false);Check(one.Keys.Count==0,"paused/unfocused no input");
    one.Dead=true;NativeGamepadInput.Sync(w,0,new NativePadState{Id=103,Left=true},true);Check(one.Keys.Count==0,"dead no input");one.Dead=false;
    NativeGamepadInput.Sync(w,0,new NativePadState{Id=103,Left=true},true);Check(one.Keys.Count==1,"held stick resumes after respawn");w.ClearAllKeys();Check(!one.GamepadTilt.HasValue,"focus reset removes visual input");
   }
   var diagonal=new NativeGameplayWorld(grid,()=>.5);diagonal.Player.Cell=new Vector2Int(3,3);
   NativeGamepadInput.Sync(diagonal,0,new NativePadState{Id=101,Stick=new Vector2(1,-1)},true);
   var first=diagonal.KeyboardStep();var second=diagonal.KeyboardStep();Check(first!=second&&(first==Vector2Int.right||first==new Vector2Int(0,-1))&&(second==Vector2Int.right||second==new Vector2Int(0,-1)),"original staircase alternation");
   var serial=diagonal.Player.KeySerial;NativeGamepadInput.Sync(diagonal,0,new NativePadState{Id=101,Stick=new Vector2(1,-1)},true);Check(diagonal.Player.KeySerial==serial,"held pad doesn't create repeated presses");
   if(!deviceEvents)return n;
   // Frame-edge tests run in the standalone player, not the Editor edit-mode update loop.
   // Real Input System event decoding; no OS key injection and no physical device state changed.
   var updateMode=InputSystem.settings.updateMode;InputSystem.settings.updateMode=InputSettings.UpdateMode.ProcessEventsManually;
   var device=InputSystem.AddDevice<Gamepad>();
   try {
    void Send(GamepadState state){InputSystem.QueueStateEvent(device,state);InputSystem.Update();}
    Send(new GamepadState());
    Send(new GamepadState{leftStick=new Vector2(.75f,.5f)});
    var read=NativeGamepadInput.Read(device);Check(read.Directions==6&&read.Stick.y<0,"native raw stick and down-positive conversion");
    foreach(var direction in new[]{(GamepadButton.DpadLeft,1),(GamepadButton.DpadRight,2),(GamepadButton.DpadUp,4),(GamepadButton.DpadDown,8)}){
     Send(new GamepadState().WithButton(direction.Item1));Check(NativeGamepadInput.Read(device).Directions==direction.Item2,"native D-pad "+direction.Item1);}
    Send(new GamepadState().WithButton(GamepadButton.South));Check(NativeGamepadInput.Read(device).Confirm,"Xbox A confirm");
    Send(new GamepadState().WithButton(GamepadButton.East));Check(NativeGamepadInput.Read(device).Back,"Xbox B back");
    Send(new GamepadState().WithButton(GamepadButton.Start));Check(NativeGamepadInput.Read(device).Confirm&&NativeGamepadInput.Read(device).Pause,"Xbox Menu confirm/pause");
    Send(new GamepadState().WithButton(GamepadButton.Select));Check(NativeGamepadInput.Read(device).Exit,"Xbox View return");
    Send(new GamepadState());Check(!NativeGamepadInput.Read(device).Exit&&!NativeGamepadInput.Read(device).Pause,"released buttons");
   }finally{InputSystem.RemoveDevice(device);InputSystem.settings.updateMode=updateMode;}
   Check(!NativeGamepadInput.Read(device).Connected,"removed device no stale state");return n;
  }
  void Start(){
   string report=null;var args=Environment.GetCommandLineArgs();for(int i=0;i<args.Length;i++)if(args[i]=="--report")report=args[++i];
   var devices=Gamepad.all.Select(p=>p.displayName+" / "+p.description.interfaceName+" / "+p.description.product).ToArray();
   int count=Run(true);Directory.CreateDirectory(Path.GetDirectoryName(report));
   File.WriteAllText(report,JsonUtility.ToJson(new Result{passed=true,checks=count,detectedDevices=devices,note="Synthetic Unity Input System controller events plus original gameplay movement, both human slots, menu repeat, disconnect, pause/death and keyboard coexistence. Detection alone is not a physical hand-operated controller test."},true));Application.Quit();
  }
 }
}


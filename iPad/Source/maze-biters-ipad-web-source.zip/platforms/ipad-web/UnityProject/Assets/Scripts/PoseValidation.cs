using System;
using System.IO;
using System.Collections.Generic;
using UnityEngine;
namespace MazeBiters.NativeStudy {
 [Serializable]class PoseCases {public string quality;public int size,columns,rows;public string[] sets;public PoseCase[] cases;}
 [Serializable]class PoseCase {public int mouth,blink;}
 [Serializable]class PoseResult {public string quality,note;public int samples,pixels,maxChannelError;public double meanChannelError,fractionPixelsBeyondTwo;public bool passed;}
 public static class PoseValidation {
  // Offline conformance test, never executed in the measured frame loop.
  public static bool Run(string quality,Mesh quad,string output){
   var root=Path.Combine(WebFiles.Root,"Reference");
   var spec=JsonUtility.FromJson<PoseCases>(File.ReadAllText(Path.Combine(root,"pose-"+quality+".json")));
   int width=spec.size*spec.columns,height=spec.size*spec.rows;var objects=new List<GameObject>();
   using(var art=new PackedArt(quality)){
    var rt=new RenderTexture(width,height,0,RenderTextureFormat.ARGB32){antiAliasing=1,filterMode=FilterMode.Point};rt.Create();
    var cameraObject=new GameObject("Validation camera");var camera=cameraObject.AddComponent<Camera>();camera.enabled=false;camera.orthographic=true;camera.orthographicSize=height/2f;camera.aspect=(float)width/height;
    camera.transform.position=new Vector3(width/2f,-height/2f,-10);camera.clearFlags=CameraClearFlags.SolidColor;camera.backgroundColor=Color.clear;camera.cullingMask=1<<30;camera.allowHDR=false;camera.allowMSAA=false;camera.targetTexture=rt;
    Texture2D expected=null,actual=null;
    try{
     for(int col=0;col<spec.columns;col++)for(int row=0;row<spec.rows;row++){
      var go=new GameObject("Pose check");objects.Add(go);go.layer=30;
      go.transform.position=new Vector3(col*spec.size,-row*spec.size,0);go.transform.localScale=new Vector3(spec.size,spec.size,1);
      go.AddComponent<MeshFilter>().sharedMesh=quad;var renderer=go.AddComponent<MeshRenderer>();
      var key=spec.sets[col].Replace(":normal:",":");var material=art.materials[key];renderer.sharedMaterial=material;
      var p=new MaterialPropertyBlock();var frame=material.GetVector("_Frames");frame.x=spec.cases[row].mouth;frame.y=spec.cases[row].blink;p.SetVector("_Frames",frame);renderer.SetPropertyBlock(p);
     }
     camera.Render();var previous=RenderTexture.active;RenderTexture.active=rt;
     actual=new Texture2D(width,height,TextureFormat.RGBA32,false);actual.ReadPixels(new Rect(0,0,width,height),0,0);actual.Apply();RenderTexture.active=previous;
     expected=new Texture2D(2,2,TextureFormat.RGBA32,false);expected.LoadImage(File.ReadAllBytes(Path.Combine(root,"pose-"+quality+".png")));
     var a=actual.GetPixels32();var b=expected.GetPixels32();if(a.Length!=b.Length)throw new Exception("Reference dimensions mismatch");
     long total=0;int worst=0,bad=0;
     for(int i=0;i<a.Length;i++){
      // Canvas PNG is straight alpha; shader destination is premultiplied.
      int e0=Math.Abs(a[i].r-(int)Math.Round(b[i].r*b[i].a/255.0)),e1=Math.Abs(a[i].g-(int)Math.Round(b[i].g*b[i].a/255.0)),e2=Math.Abs(a[i].b-(int)Math.Round(b[i].b*b[i].a/255.0)),e3=Math.Abs(a[i].a-b[i].a);
      int e=Math.Max(Math.Max(e0,e1),Math.Max(e2,e3));worst=Math.Max(worst,e);if(e>2)bad++;total+=e0+e1+e2+e3;
     }
     var report=new PoseResult{quality=quality,samples=spec.columns*spec.rows,pixels=a.Length,maxChannelError=worst,meanChannelError=(double)total/(a.Length*4),fractionPixelsBeyondTwo=(double)bad/a.Length,passed=worst<=2,
      note="Native size only; exact original base/mouth/eyelid patches, all 6 palettes and 4 headings. Premultiplied RGBA comparison against browser Canvas export. Does not certify turn surfaces or full-scene parity."};
     File.WriteAllText(output,JsonUtility.ToJson(report,true));Debug.Log("POSE_PARITY "+JsonUtility.ToJson(report));return report.passed;
    }finally{foreach(var go in objects){go.SetActive(false);UnityEngine.Object.Destroy(go);}UnityEngine.Object.Destroy(cameraObject);rt.Release();UnityEngine.Object.Destroy(rt);if(actual)UnityEngine.Object.Destroy(actual);if(expected)UnityEngine.Object.Destroy(expected);}
   }
  }
 }
}

using System;
namespace MazeBiters.NativeStudy {
 // Single-human port of the frozen browser camera. Coordinates are logical
 // board pixels (Y down); simulation/input never depends on this presentation.
 public sealed class NativeGameplayCamera {
  public const double Width=576,Height=400;
  public double Zoom=1,X=288,Y=200,TargetZoom=1,TargetX=288,TargetY=200,MotionZoom=2;
  public double LastRealTime;public bool Presentation;public int Subjects,Living;
  object subject;double mx,my,mReal=double.NaN,mGame,vx,vy,speed;
  void ResetMotion(){subject=null;mReal=double.NaN;vx=vy=speed=0;MotionZoom=2;}
  public void Reset(double realTime){Zoom=TargetZoom=1;X=TargetX=288;Y=TargetY=200;LastRealTime=realTime;Presentation=false;Subjects=Living=0;ResetMotion();if(coopMotion!=null)foreach(var m in coopMotion)m.ResetMotion();}
  static double ClampCenter(double value,double size,double world)=>Math.Max(size/2,Math.Min(world-size/2,value));
  double Motion(object identity,double x,double y,double real,double game){
   double elapsed=real-mReal,dx=x-mx,dy=y-my,distance=Math.Sqrt(dx*dx+dy*dy);
   if(!ReferenceEquals(subject,identity)||double.IsNaN(mReal)||elapsed<0||elapsed>250||game<mGame||distance>Math.Max(20,elapsed*16*.045)){ResetMotion();subject=identity;}
   else if(elapsed>0){double blend=1-Math.Exp(-elapsed/500);vx+=(dx/elapsed-vx)*blend;vy+=(dy/elapsed-vy)*blend;speed+=(distance/elapsed-speed)*blend;
    double ratio=speed/(16.0/95),progress=Math.Max(Math.Abs(vx),Math.Abs(vy))/(16.0/95);
    double opening=.06*Math.Min(1,ratio)+.20*Math.Min(1,progress)+.06*Math.Min(1,Math.Max(0,progress-1));MotionZoom=opening<.0001?2:2-opening;
   }
   mx=x;my=y;mReal=real;mGame=game;return MotionZoom;
  }
  public void Update(object identity,double pixelX,double pixelY,bool dead,bool eliminated,bool hiddenDeath,bool presentation,double real,double game){
   Living=identity!=null&&!dead&&!eliminated?1:0;Presentation=presentation;
   if(dead||eliminated||presentation)ResetMotion();
   Subjects=!presentation&&identity!=null&&!eliminated&&!(dead&&hiddenDeath)?1:0;
   double motion=2;
   if(Subjects>0){if(!dead)motion=Motion(identity,pixelX,pixelY,real,game);
    double cx=ClampCenter(pixelX,Width/2,Width),cy=ClampCenter(pixelY,Height/2,Height);
    // Keep the browser union-window arithmetic, including the clamped Solo
    // centre at edges, rather than centring directly on the player at low zoom.
    double left=cx-Width/4,right=cx+Width/4,top=cy-Height/4,bottom=cy+Height/4;
    double uw=Math.Max(Width/2,right-left)+Width/motion-Width/2,uh=Math.Max(Height/2,bottom-top)+Height/motion-Height/2;
    TargetZoom=Math.Max(1,Math.Min(2,Math.Min(Width/uw,Height/uh)));
    TargetX=ClampCenter((left+right)/2,Width/TargetZoom,Width);TargetY=ClampCenter((top+bottom)/2,Height/TargetZoom,Height);
   }else{TargetZoom=1;TargetX=288;TargetY=200;}
   MotionZoom=motion;
   double elapsed=Math.Max(0,Math.Min(50,real-LastRealTime));LastRealTime=real;
   double tau=TargetZoom<Zoom?(presentation?580:290):1040;
   Zoom+=(TargetZoom-Zoom)*(1-Math.Exp(-elapsed/tau));X+=(TargetX-X)*(1-Math.Exp(-elapsed/470));Y+=(TargetY-Y)*(1-Math.Exp(-elapsed/470));
   if(Math.Abs(TargetZoom-Zoom)<.00005)Zoom=TargetZoom;if(Math.Abs(TargetX-X)<.002)X=TargetX;if(Math.Abs(TargetY-Y)<.002)Y=TargetY;
   X=ClampCenter(X,Width/Zoom,Width);Y=ClampCenter(Y,Height/Zoom,Height);
  }
  NativeGameplayCamera[] coopMotion;
  public void UpdateRoster(NativeGameplayWorld world,bool presentation,double real,double game){
   if(coopMotion==null)coopMotion=new[]{new NativeGameplayCamera(),new NativeGameplayCamera(),new NativeGameplayCamera()};
   Living=0;Subjects=0;Presentation=presentation;double left=double.PositiveInfinity,right=double.NegativeInfinity,top=double.PositiveInfinity,bottom=double.NegativeInfinity,motion=2;
   for(int i=0;i<world.PlayerCount;i++){var p=world.GetPlayer(i);if(!p.Dead&&!p.Eliminated)Living++;if(p.Dead||p.Eliminated||presentation)coopMotion[i].ResetMotion();}
   if(!presentation)for(int i=0;i<world.PlayerCount;i++){var p=world.GetPlayer(i);if(p.Eliminated||p.Dead&&(p.HideDeath||Living>0))continue;var v=p.Visual(game);double px=(v.x+.5)*16,py=(v.y+.5)*16;if(!p.Dead)motion=Math.Min(motion,coopMotion[i].Motion(p,px,py,real,game));double cx=ClampCenter(px,Width/2,Width),cy=ClampCenter(py,Height/2,Height);left=Math.Min(left,cx-Width/4);right=Math.Max(right,cx+Width/4);top=Math.Min(top,cy-Height/4);bottom=Math.Max(bottom,cy+Height/4);Subjects++;}
   MotionZoom=motion;if(Subjects>0){double uw=Math.Max(Width/2,right-left)+Width/motion-Width/2,uh=Math.Max(Height/2,bottom-top)+Height/motion-Height/2;TargetZoom=Math.Max(1,Math.Min(2,Math.Min(Width/uw,Height/uh)));TargetX=ClampCenter((left+right)/2,Width/TargetZoom,Width);TargetY=ClampCenter((top+bottom)/2,Height/TargetZoom,Height);}else{TargetZoom=1;TargetX=288;TargetY=200;}
   double elapsed=Math.Max(0,Math.Min(50,real-LastRealTime));LastRealTime=real;double tau=TargetZoom<Zoom?(presentation?580:290):1040;Zoom+=(TargetZoom-Zoom)*(1-Math.Exp(-elapsed/tau));X+=(TargetX-X)*(1-Math.Exp(-elapsed/470));Y+=(TargetY-Y)*(1-Math.Exp(-elapsed/470));if(Math.Abs(TargetZoom-Zoom)<.00005)Zoom=TargetZoom;if(Math.Abs(TargetX-X)<.002)X=TargetX;if(Math.Abs(TargetY-Y)<.002)Y=TargetY;X=ClampCenter(X,Width/Zoom,Width);Y=ClampCenter(Y,Height/Zoom,Height);
  }
  public void ScreenToWorld(double x,double y,out double wx,out double wy){wx=X+(x-288)/Zoom;wy=Y+(y-200)/Zoom;}
  public void WorldToScreen(double x,double y,out double sx,out double sy){sx=288+(x-X)*Zoom;sy=200+(y-Y)*Zoom;}
  // Header and letterbox are not navigable. Floor (not truncation) matters at
  // negative coordinates, which previously accidentally selected row zero.
  public bool PointerCell(double frameX,double frameY,out int x,out int y){x=y=-1;if(frameX<0||frameX>=576||frameY<32||frameY>=432)return false;
   ScreenToWorld(frameX,frameY-32,out double wx,out double wy);x=(int)Math.Floor(wx/16);y=(int)Math.Floor(wy/16);return x>=0&&x<36&&y>=0&&y<25;
  }
 }
}

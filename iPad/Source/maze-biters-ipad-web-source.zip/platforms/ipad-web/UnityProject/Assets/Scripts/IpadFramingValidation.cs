using System;
using UnityEngine;
namespace MazeBiters.NativeStudy {
 public static class IpadFramingValidation {
  public static int Run(){int count=0;void Check(bool b,string name){count++;if(!b)throw new Exception("iPad framing: "+name);}
   var f=new NativeFrame(4f/3,true);var safe=new Rect(0,0,f.Width,f.Height);double close=160.0*432/(16*2064);
   var overview=IpadFraming.Calculate(f,288,200,1,close,safe);var board=f.ProjectBoard(overview.x,overview.y,overview.zoom);
   Check(Math.Abs(board.y-32)<.001&&Math.Abs(board.yMax-432)<.001,"original 32 + 400 overview");Check(Math.Abs(board.x)<.001&&Math.Abs(board.xMax-576)<.001,"whole maze spans width");
   Check(Math.Abs(16*close*2064/432-160)<1e-9,"160 physical pixels at close zoom");
   double prevZ=overview.zoom,prevY=overview.y,prevHeader=32;
   for(int i=0;i<=10000;i++){double s=1+i/10000.0;var v=IpadFraming.Calculate(f,288,200,s,close,safe);Check(v.zoom>=prevZ&&v.zoom-prevZ<.00012,"continuous monotonic zoom");Check(Math.Abs(v.y-prevY)<.01&&v.header<=prevHeader+.00001,"continuous header withdrawal");prevZ=v.zoom;prevY=v.y;prevHeader=v.header;
    foreach(var b in new[]{new Rect(24,24,528,352),new Rect(24,24,64,0),new Rect(24,376,64,0),new Rect(280,184,16,32)}){var a=IpadFraming.KeepPlayers(f,v,b,safe);double px=f.Width/2-a.x*a.zoom,py=f.Height/2-a.y*a.zoom;Check(px+(b.xMin-12)*a.zoom>=-.001&&px+(b.xMax+12)*a.zoom<=f.Width+.001,"roster horizontal visibility");Check(py+(b.yMin-12)*a.zoom>=a.header-.001&&py+(b.yMax+12)*a.zoom<=f.Height+.001,"roster vertical visibility");}
   }
   var upper=IpadFraming.Calculate(f,288,100,2,close,safe);var lower=IpadFraming.Calculate(f,288,300,2,close,safe);
   Check(Math.Abs(f.ProjectBoard(upper.x,upper.y,upper.zoom).y-52)<.001,"upper close sky");Check(Math.Abs(f.Height-f.ProjectBoard(lower.x,lower.y,lower.zoom).yMax-52)<.001,"matching lower close sky");
   var left=IpadFraming.Calculate(f,144,200,2,close,safe);var right=IpadFraming.Calculate(f,432,200,2,close,safe);
   Check(Math.Abs(f.ProjectBoard(left.x,left.y,left.zoom).x-52)<.001,"left sky matches upper sky");Check(Math.Abs(f.Width-f.ProjectBoard(right.x,right.y,right.zoom).xMax-52)<.001,"right sky matches upper sky");
   foreach(double edgeX in new[]{144.0,432.0})foreach(double edgeY in new[]{100.0,300.0}){var corner=IpadFraming.Calculate(f,edgeX,edgeY,2,close,safe);var cb=f.ProjectBoard(corner.x,corner.y,corner.zoom);double sx=edgeX<288?cb.x:f.Width-cb.xMax,sy=edgeY<200?cb.y:f.Height-cb.yMax;Check(Math.Abs(sx-sy)<.001&&Math.Abs(sx-52)<.001,"balanced corner sky");}
   foreach(float aspect in new[]{4f/3,2420f/1668,16f/9}){var frame=new NativeFrame(aspect,true);var area=new Rect(8,12,frame.Width-16,frame.Height-22);var v=IpadFraming.Calculate(frame,288,200,2,close,area);var b=new Rect(24,24,528,352);v=IpadFraming.KeepPlayers(frame,v,b,area);Check(v.zoom>0&&double.IsFinite(v.x)&&double.IsFinite(v.y),"safe area and alternate aspect");}
   return count;
  }
 }
}

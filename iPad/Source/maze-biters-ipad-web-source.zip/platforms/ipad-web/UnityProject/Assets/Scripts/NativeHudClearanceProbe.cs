using System;using System.IO;using System.Linq;using System.Collections;using System.Collections.Generic;using UnityEngine;
namespace MazeBiters.NativeStudy {
 public sealed partial class NativeGameplayStudy {
  [Serializable] sealed class ClearanceCase {public string name,before,after;public double[] alpha;public bool[] contacts;public int changed,outsideChanged,maxBlendError,blendFailures;public double zoom,topSky,bottomSky;}
  [Serializable] sealed class ClearanceReport {public bool passed;public string quality,note;public int mode,players,width,height;public long contactManagedBytes,hudTextureBytes;public double contactMicroseconds;public string[] checks;public ClearanceCase[] cases;}
  Texture2D ReadHudBand(){var old=RenderTexture.active;RenderTexture.active=target;int h=(int)Math.Ceiling(64*target.height/DisplayFrame.Height);var t=new Texture2D(target.width,h,TextureFormat.RGBA32,false);t.ReadPixels(new Rect(0,target.height-h,target.width,h),0,0);t.Apply();RenderTexture.active=old;return t;}
  IEnumerator ProbeHudClearance(){
   var checks=new List<string>();var cases=new List<ClearanceCase>();void Check(bool ok,string name){if(!ok)throw new Exception("HUD contact fade: "+name);checks.Add(name);}
   string dir=Path.GetDirectoryName(report);Directory.CreateDirectory(dir);NativeDisplay.TestAspect=16f/9;fixedCamera=true;sessionSmoke=true;Reset(12);yield return DrainProbePreparation();
   gameplayCamera.Reset(realClock);realClock+=5000;var result=new ClearanceReport{quality=quality,mode=world.Mode,players=world.PlayerCount};
   void Place(params Vector2Int[] cells){for(int i=0;i<world.PlayerCount;i++){var p=world.GetPlayer(i);p.Cell=p.From=p.Previous=world.Brain.Nearest(cells[i%cells.Length]);p.LastMove=time-1000;p.Waiting=true;p.Dir=p.Next=Vector2Int.down;p.ShieldUntil=0;p.Tilt=0;actors[p.Id].turn.Reset();}}
   void Draw(){preparationLightFrame=true;Render();}
   int Error(Color32 a,Color32 b)=>Math.Max(Math.Max(Math.Abs(a.r-b.r),Math.Abs(a.g-b.g)),Math.Max(Math.Abs(a.b-b.b),Math.Abs(a.a-b.a)));
   void Pair(string name,bool expectOverlap){
    string state=MenuFullState,clock=ScalarClock(gameplayCamera);var c=new ClearanceCase{name=name,before=name+"-before.png",after=name+"-after.png",alpha=new double[8],contacts=new bool[8]};
    hud.ResetContacts();compareHudClearance=true;Draw();Draw();var old=ReadHudBand();var a=old.GetPixels32();Capture(Path.Combine(dir,c.before));
    double x=cameraViewX,y=cameraViewY,z=cameraViewZoom;compareHudClearance=false;Draw();Draw();
    for(int i=1;i<=100;i++)hud.EndContacts(realClock+i*16);camera.Render();var current=ReadHudBand();var b=current.GetPixels32();Capture(Path.Combine(dir,c.after));
    for(int i=0;i<8;i++){c.alpha[i]=hud.ContactAlpha(i);c.contacts[i]=hud.Contact(i);}
    for(int i=0;i<8;i+=2)Check(c.alpha[i]==c.alpha[i+1]&&c.contacts[i]==c.contacts[i+1],name+" / paired rows share exact opacity and contact "+i/2);
    hud.ProbeVisible(false);camera.Render();var clean=ReadHudBand();var reference=clean.GetPixels32();hud.ProbeVisible(true);camera.Render();
    double density=target.height/DisplayFrame.Height;
    for(int py=0;py<current.height;py++)for(int px=0;px<current.width;px++){
     int k=py*current.width+px;var point=new Vector2((float)((px+.5)/density),(float)((current.height-py-.5)/density));double opacity=1;bool inside=false;
     for(int i=0;i<8;i++)if(c.contacts[i]&&hud.ContactRect(i).Contains(point)){inside=true;opacity=c.alpha[i];}
     if(Error(a[k],b[k])>0)c.changed++;
     if(!inside){if(Error(a[k],b[k])>0)c.outsideChanged++;continue;}
     var r=reference[k];var original=a[k];var actual=b[k];
     int error=Math.Max(Math.Abs(actual.r-(int)Math.Round(r.r+(original.r-r.r)*opacity)),Math.Max(Math.Abs(actual.g-(int)Math.Round(r.g+(original.g-r.g)*opacity)),Math.Abs(actual.b-(int)Math.Round(r.b+(original.b-r.b)*opacity))));
     c.maxBlendError=Math.Max(c.maxBlendError,error);if(error>3)c.blendFailures++;
    }
    Destroy(old);Destroy(current);Destroy(clean);var board=DisplayFrame.ProjectBoard(x,y,z);c.zoom=z;c.topSky=Math.Max(0,board.y);c.bottomSky=Math.Max(0,DisplayFrame.Height-board.yMax);
    Check(c.outsideChanged==0,name+" / all pixels outside affected pairs unchanged");Check(c.blendFailures==0,name+" / paired rows at 25% opacity including spotlight");
    Check(expectOverlap?c.changed>0:c.changed==0,name+" / "+(expectOverlap?"actual overlapping text fades":"clear text remains exactly original"));
    Check(x==cameraViewX&&y==cameraViewY&&z==cameraViewZoom&&clock==ScalarClock(gameplayCamera),name+" / camera unchanged");Check(state==MenuFullState,name+" / simulation, RNG and animation clocks unchanged");cases.Add(c);
   }
   Place(new Vector2Int(1,1),new Vector2Int(34,23),new Vector2Int(17,11));Pair("overview",true);
   Check(Math.Abs(cameraViewZoom-1.08)<.000001&&cases.Last().topSky<.001&&cases.Last().bottomSky<.001,"full-height overview and side space preserved");yield return null;
   Place(new Vector2Int(1,1),new Vector2Int(13,1),new Vector2Int(34,1));Pair("upper-roster",true);yield return null;
   for(int i=0;i<world.PlayerCount;i++){var p=world.GetPlayer(i);actors[p.Id].turn.Request(Bank(Vector2Int.right),Bank(Vector2Int.down),time-45);p.BiteAt=time-40;p.BiteEnd=time+150;p.Tilt=17;}
   Pair("turn-bite",true);yield return null;
   // Isolate each rendered entity from other possible header contacts.
   foreach(var s in snakes.Values)s.Dispose();snakes.Clear();world.Snakes.Clear();
   foreach(var h in world.Hunters){actors[h.Id].Dispose();actors.Remove(h.Id);}world.Hunters.Clear();world.Scorpion=null;scorpionArt?.Dispose();scorpionArt=null;world.Fruits.Clear();world.Eggs.Clear();
   Place(new Vector2Int(1,23),new Vector2Int(34,23),new Vector2Int(17,23));Draw();Pair("clear",false);yield return null;
   var cell=new Vector2Int(1,1);
   for(int k=0;k<4;k++){world.Fruits.Add(new NativeFruit{Cell=cell,Kind=k,Born=time-1000});Pair("fruit-"+k,true);world.Fruits.Clear();yield return null;}
   world.Eggs.Add(new NativeEgg{Cell=cell,Born=time-1000});Pair("egg",true);world.Eggs.Clear();yield return null;
   var hunter=new NativeHunter{Id=101,Cell=cell,From=cell,Dir=Vector2Int.right,Palette=1};world.Hunters.Add(hunter);AddActor(hunter,false,1);Pair("hunter",true);world.Hunters.Clear();actors[101].Dispose();actors.Remove(101);yield return null;
   var scorpion=world.PlaceScorpion(new Vector2Int(2,1),Vector2Int.right);scorpion.Born=time-1000;scorpionArt=CreateScorpionArt();Pair("scorpion",true);world.Scorpion=null;scorpionArt.Dispose();scorpionArt=null;yield return null;
   var body=Enumerable.Range(1,7).Reverse().Select(x=>new Vector2Int(x,1)).ToArray();var model=world.AddSnake(body,Vector2Int.right,0);AddSnake(model);Pair("snake-tail-body",true);yield return null;
   // Reverse the same body: the head now occupies the header overlap.
   foreach(var s in snakes.Values)s.Dispose();snakes.Clear();world.Snakes.Clear();model=world.AddSnake(body.Reverse().ToArray(),Vector2Int.left,2);AddSnake(model);Pair("snake-head",true);yield return null;
   int meshes=hud.MeshUpdates;long textureBytes=hud.TextureBytes;
   CollectHudContacts();hud.EndContacts(realClock);
   long start=GC.GetAllocatedBytesForCurrentThread(),stamp=System.Diagnostics.Stopwatch.GetTimestamp();
   for(int i=0;i<1000;i++){CollectHudContacts();hud.EndContacts(realClock+i);}
   result.contactMicroseconds=(System.Diagnostics.Stopwatch.GetTimestamp()-stamp)*1000000.0/System.Diagnostics.Stopwatch.Frequency/1000;
   result.contactManagedBytes=GC.GetAllocatedBytesForCurrentThread()-start;
   Check(result.contactManagedBytes==0&&hud.MeshUpdates==meshes&&hud.TextureBytes==textureBytes,"contact detection and fade allocate no managed memory and retain meshes/textures");
   // Keep original rendered gameplay frozen while testing real-time response.
   foreach(var s in snakes.Values)s.Dispose();snakes.Clear();world.Snakes.Clear();Place(new Vector2Int(1,1));Draw();hud.ResetContacts();CollectHudContacts();hud.EndContacts(realClock);
   int row=Enumerable.Range(0,8).First(i=>hud.Contact(i));double last=1;
   for(int i=1;i<=6;i++){hud.EndContacts(realClock+i*16);double value=hud.ContactAlpha(row);Check(value<last,"fade-out is monotone "+i);last=value;}
   Check(last>.65&&last<.8,"gradual fade still in progress after 96ms");
   camera.Render();Capture(Path.Combine(dir,"fade-96ms.png"));
   hud.BeginContacts(DisplayFrame,cameraViewX,cameraViewY,cameraViewZoom,false);
   hud.EndContacts(realClock+112);double recovering=hud.ContactAlpha(row);Check(Math.Abs(recovering-last)<.06&&recovering>NativeHud.ContactOpacity&&recovering<1,"clearance preserves opacity and momentum without a jump");
   CollectHudContacts();hud.EndContacts(realClock+128);Check(Math.Abs(hud.ContactAlpha(row)-recovering)<.06&&hud.ContactAlpha(row)>NativeHud.ContactOpacity,"renewed overlap smoothly retargets without reset");
   Check(hud.ContactAlpha(row)==hud.ContactAlpha(row^1),"both rows remain synchronized throughout reversal");
   double beforePreparation=hud.ContactAlpha(row);preparingNextScene=true;UpdateHudClearance();preparingNextScene=false;Check(hud.ContactAlpha(row)==beforePreparation,"hidden next-scene preparation cannot advance opacity");
   hud.BeginContacts(DisplayFrame,cameraViewX,cameraViewY,cameraViewZoom,false);for(int i=1;i<=120;i++)hud.EndContacts(realClock+128+i*16);
   Check(hud.ContactAlpha(row)==1,"clear text fully restores exact original opacity");
   // Contact with either row alone must affect precisely its vertical partner.
   for(int group=0;group<2+world.PlayerCount-1;group++)for(int member=0;member<2;member++){
    int hit=group*2+member;hud.ResetContacts();hud.BeginContacts(DisplayFrame,cameraViewX,cameraViewY,cameraViewZoom);
    var r=hud.ContactRect(hit);double wx=cameraViewX+(r.center.x-DisplayFrame.Width/2)/cameraViewZoom,wy=cameraViewY+(r.center.y-DisplayFrame.Height/2-DisplayFrame.ViewOffsetY)/cameraViewZoom;
    hud.Obstacle(wx-.01,wy-.01,wx+.01,wy+.01);hud.EndContacts(realClock);hud.EndContacts(realClock+16);
    for(int i=0;i<8;i++)Check(hud.Contact(i)==(i/2==group),"single row contact affects only its pair / "+hit+" -> "+i);
    Check(hud.ContactAlpha(hit)==hud.ContactAlpha(hit^1)&&hud.ContactAlpha(hit)<1,"paired soft onset from either row / "+hit);
   }
   for(int i=0;i<world.PlayerCount;i++){var p=world.GetPlayer(i);p.Dead=p.HideDeath=true;}Draw();Pair("hidden-players",false);yield return null;
   for(int i=0;i<world.PlayerCount;i++){var p=world.GetPlayer(i);p.Dead=p.HideDeath=false;}
   Place(new Vector2Int(1,1));gameplayCamera.Zoom=2;gameplayCamera.X=144;gameplayCamera.Y=100;Pair("zoomed-edge",false);
   result.width=target.width;result.height=target.height;result.hudTextureBytes=textureBytes;
   Check(target.width==(quality=="4k"?3840:1920)&&target.height==(quality=="4k"?2160:1080),"native HD/4K output");Check(bank.Size==(quality=="4k"?160:80),"original native animation bank");
   result.passed=true;result.checks=checks.ToArray();result.cases=cases.ToArray();result.note="Frozen generated-level fixtures. Whole-row alpha verified against opaque HUD and scene without HUD (<=3/255 rounding tolerance); unaffected pixels exact. Timed fade, reversal, hidden preparation, allocation and native bank checks. Contact CPU microseconds are an isolated diagnostic, not a gameplay FPS benchmark.";
   File.WriteAllText(report,JsonUtility.ToJson(result,true));Application.Quit();
  }
 }
}

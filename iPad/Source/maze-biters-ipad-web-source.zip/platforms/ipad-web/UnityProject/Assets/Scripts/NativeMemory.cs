using System;
using System.Runtime.InteropServices;
namespace MazeBiters.NativeStudy {
 public static class NativeMemory {
  [StructLayout(LayoutKind.Sequential)]struct Counters {
   public uint cb,pageFaults;public UIntPtr peakWorking,working,peakPaged,paged,peakNonPaged,nonPaged,pagefile,peakPagefile,privateUsage;
  }
  [DllImport("psapi.dll",SetLastError=true)] [return:MarshalAs(UnmanagedType.Bool)]
  static extern bool GetProcessMemoryInfo(IntPtr process,out Counters counters,uint size);
  public static bool TryRead(out long working,out long peak,out long committed){
   working=peak=committed=-1;
   if(Environment.OSVersion.Platform!=PlatformID.Win32NT)return false;
   if(!GetProcessMemoryInfo(new IntPtr(-1),out var data,(uint)Marshal.SizeOf<Counters>()))return false;
   working=(long)data.working.ToUInt64();peak=(long)data.peakWorking.ToUInt64();committed=(long)data.privateUsage.ToUInt64();return true;
  }
 }
}

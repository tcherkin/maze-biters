#if UNITY_EDITOR
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using UnityEngine;

namespace MazeBiters.NativeStudy {
 // Focused contact regressions. The stationary snakes isolate the final-bite
 // decision; ordinary AdvancePlayer/Eat still perform all movement and scoring.
 public static class NativeCasualFinishValidation {
  static readonly Vector2Int Right=Vector2Int.right,Up=new Vector2Int(0,-1),Down=new Vector2Int(0,1);
  static string[] Grid(bool open=false){var rows=new char[11][];for(int y=0;y<11;y++){rows[y]=new string('#',15).ToCharArray();for(int x=1;x<14;x++)if(y>0&&y<10&&(open||y==5))rows[y][x]='.';}return rows.Select(r=>new string(r)).ToArray();}
  static NativeGameplayWorld World(int difficulty,bool meal=false,bool open=false,int mode=0){
   var w=new NativeGameplayWorld(Grid(open),()=>.99){AiDifficulty=difficulty,Difficulty=NativeMazeGenerator.Difficulties[difficulty],Time=1000,LevelStarted=1000,Assist=false,SessionEnabled=true};w.SetMode(mode);
   for(int i=0;i<w.PlayerCount;i++){var actor=w.GetPlayer(i);actor.Cell=actor.From=actor.Previous=new Vector2Int(2+i,5);actor.Dir=actor.Next=Right;actor.Score=0;actor.Waiting=false;}
   var p=Ai(w);p.Cell=p.From=p.Previous=new Vector2Int(6,5);p.Dir=p.Next=Right;p.Score=200;p.ExactScore=200;w.Ally.BeginLevel();p.Ai.mealInitialized=true;p.Ai.mealActive=meal;p.Ai.mealIntentUntil=10000;p.Ai.allowSplit=false;return w;
  }
  static NativePlayer Ai(NativeGameplayWorld w)=>w.GetPlayer(w.PlayerCount-1);
  static NativeGameplaySnake Add(NativeGameplayWorld w,IEnumerable<Vector2Int> cells,Vector2Int direction){var body=cells.ToList();var s=new NativeGameplaySnake{Id=10+w.Snakes.Count,Cell=body[0],Dir=direction,Body=body,Temperament=.5};w.Snakes.Add(s);return s;}
  static NativeGameplaySnake Tail(NativeGameplayWorld w,int length=4)=>Add(w,Enumerable.Range(7,length).Reverse().Select(x=>new Vector2Int(x,5)),Right);
  static void Check(NativeCasualBiteReport r,bool passed,string name,string detail=""){r.assertions++;if(!passed)r.failures++;r.checks.Add(new NativeDifficultyCheck{name=name,passed=passed,detail=detail});}
  static void Group(NativeCasualBiteReport r,string name,Action body){try{body();}catch(Exception e){Check(r,false,name+" completed",e.ToString());}}
  static void Plan(NativeCasualBiteReport r,NativeGameplayWorld w){w.Ally.Plan(Ai(w),w.Time);r.decisions++;}
  static void Advance(NativeGameplayWorld w){using(w.ForPlayer(Ai(w)))w.AdvancePlayer();w.Time+=95;}
  static void Move(NativeGameplayWorld w,Vector2Int d){var p=Ai(w);p.Next=d;p.Waiting=false;Advance(w);}
  static NativeGameplaySnake Chain(NativeCasualBiteReport r,NativeGameplayWorld w,int bites=3){var s=Tail(w);for(int i=0;i<bites;i++){Plan(r,w);Advance(w);}return s;}
  static bool EmptyMeal(NativePlayer p)=>p.Ai.casualSnake==null&&p.Ai.casualBites==0;
  static bool NoLock(NativePlayer p)=>p.Ai.locked==null&&p.Ai.split==null&&p.Ai.queue.Count==0&&!p.Ai.mealActive;
  static void ContinuousMeals(NativeCasualBiteReport r){
   foreach(int tier in new[]{0,1})foreach(bool meal in new[]{false,true})foreach(int mode in new[]{0,3}){
    string label="tier="+tier+", heldMeal="+meal+", mode="+mode;var w=World(tier,meal,mode:mode);var p=Ai(w);var s=Chain(r,w);
    Check(r,!p.Dead&&p.Cell==new Vector2Int(9,5)&&s.Body.Count==1&&p.Ai.casualSnake==s&&p.Ai.casualBites==2,"Three actual tail contacts retain a bounded same-snake streak: "+label);
    Plan(r,w);Check(r,p.Next==Right&&p.Ai.thought=="casual-finish-head","The continuous meal selects its safe final head: "+label,"next="+p.Next+", thought="+p.Ai.thought);Advance(w);
    double expected=200+200*w.Difficulty*w.ScoreSpeed;Check(r,!p.Dead&&!w.Snakes.Contains(s)&&Math.Abs(p.ExactScore-expected)<1e-9,"The final head is really consumed and normally scored: "+label);
    Check(r,EmptyMeal(p)&&NoLock(p),"Completion clears the streak without starting another hunt: "+label);
   }
  }
  static void InterruptedMeals(NativeCasualBiteReport r){
   foreach(int tier in new[]{0,1}){
    string label="tier="+tier;
    {var w=World(tier);var p=Ai(w);var s=Tail(w,2);Plan(r,w);Advance(w);Plan(r,w);Check(r,s.Body.Count==1&&p.Ai.casualBites==1&&p.Next!=Right,"One incidental segment does not force head cleanup: "+label);}
    {var w=World(tier,open:true);var p=Ai(w);var s=Chain(r,w,2);Move(w,Down);Plan(r,w);Check(r,EmptyMeal(p),"An actual empty branch step ends the continuous meal: "+label);
     Move(w,Right);Move(w,Up);Plan(r,w);Check(r,s.Body.Count==1&&p.Ai.casualSnake==s&&p.Ai.casualBites==1&&p.Next!=Right,"Returning later starts a new incidental bite, not the old commitment: "+label);}
    {var w=World(tier,open:true);var p=Ai(w);Chain(r,w,2);var other=Add(w,new[]{new Vector2Int(8,7),new Vector2Int(8,6)},Down);Move(w,Down);Plan(r,w);
     Check(r,p.Ai.casualSnake==other&&p.Ai.casualBites==1&&p.Next!=Down,"A bite of another snake cannot inherit the old final-head permission: "+label);}
    {var w=World(tier,open:true);var p=Ai(w);var s=Add(w,new[]{new Vector2Int(9,2),new Vector2Int(9,3),new Vector2Int(9,4),new Vector2Int(9,5),new Vector2Int(10,5),new Vector2Int(10,6),new Vector2Int(9,6),new Vector2Int(8,6),new Vector2Int(8,5),new Vector2Int(7,5)},Up);
     for(int i=0;i<2;i++){Plan(r,w);Advance(w);}Plan(r,w);Check(r,p.Next==Right&&p.Ai.thought=="casual-split","An available body crossing remains an ordinary split after a tail sequence: "+label);Advance(w);
     Check(r,!w.Snakes.Contains(s)&&w.Snakes.Count==2&&EmptyMeal(p)&&NoLock(p),"A real split does not transfer the streak to either fragment: "+label);}
    {var w=World(tier,open:true);var p=Ai(w);var s=Chain(r,w);s.Body[0]=s.Cell=new Vector2Int(12,5);Plan(r,w);
     Check(r,p.Ai.thought=="casual-roam"&&NoLock(p),"A departed head does not turn the meal into a distant chase: "+label);Advance(w);Plan(r,w);Check(r,EmptyMeal(p),"Moving through empty space after the head leaves clears the streak: "+label);}
    {var w=World(tier);var p=Ai(w);var s=Chain(r,w);w.Snakes.Remove(s);Plan(r,w);Check(r,EmptyMeal(p),"A removed target cannot leave stale finishing state: "+label);}
    {var w=World(tier);var p=Ai(w);Chain(r,w);w.Ally.BeginLevel();p.Ai.mealInitialized=true;p.Ai.mealActive=false;p.Ai.mealIntentUntil=w.Time+10000;Plan(r,w);
     Check(r,EmptyMeal(p)&&p.Next!=Right,"Beginning a level clears previous eating continuity: "+label);}
   }
  }
  static void FinishingSafety(NativeCasualBiteReport r){
   foreach(int tier in new[]{0,1}){
    string label="tier="+tier;
    {var w=World(tier,open:true);var p=Ai(w);var s=Chain(r,w);s.Dir=Vector2Int.left;Plan(r,w);Check(r,p.Next!=Right,"A continuous meal never overrides an unsafe head-on collision: "+label);
     s.Dir=Right;Plan(r,w);Check(r,p.Next==Right&&p.Ai.thought=="casual-finish-head","Replanning without an actual departure preserves a now-safe final bite: "+label);Advance(w);Check(r,!p.Dead&&!w.Snakes.Contains(s),"The safe reconsidered final head resolves normally: "+label);}
    {var w=World(tier,open:true);var p=Ai(w);var s=Chain(r,w);s.Body[0]=s.Cell=new Vector2Int(9,4);s.Dir=Up;Add(w,new[]{new Vector2Int(12,5),new Vector2Int(11,5),new Vector2Int(10,5)},Right);Plan(r,w);
     Check(r,p.Next==Up&&p.Ai.thought=="casual-finish-head","Finishing the current adjacent head wins over an unrelated straight-ahead snack: "+label);Advance(w);Check(r,!p.Dead&&!w.Snakes.Contains(s)&&w.Snakes.Count==1,"A safe side finish consumes only the established target: "+label);}
    {var w=World(tier,open:true);var p=Ai(w);Chain(r,w);w.Hunters.Add(new NativeHunter{Id=100,Cell=new Vector2Int(10,4),Dir=Down});Plan(r,w);Check(r,p.Next!=Right,"An approaching hunter overrides final-head appetite: "+label);}
    {var w=World(tier,open:true);var p=Ai(w);Chain(r,w);Add(w,new[]{new Vector2Int(10,4),new Vector2Int(10,3)},Down);Plan(r,w);Check(r,p.Next!=Right,"Another snake's predicted mouth step overrides final-head appetite: "+label);}
    {var w=World(tier,open:true);var p=Ai(w);Chain(r,w);Add(w,new[]{new Vector2Int(10,6),new Vector2Int(10,5)},Down);p.PowerUntil=5000;Plan(r,w);Check(r,p.Next!=Right,"Overlapping snake bodies do not bypass the same-target check, even with power: "+label);}
    {var w=World(tier,open:true);var p=Ai(w);Chain(r,w);w.SolidEggs.Add(new Vector2Int(10,5));w.ObstacleRevision++;Plan(r,w);Check(r,p.Next!=Right,"A solid egg still blocks the final bite cell: "+label);}
    {var w=World(tier,open:true,mode:3);var p=Ai(w);Chain(r,w);var human=w.GetPlayer(0);human.Cell=human.From=human.Previous=new Vector2Int(9,4);human.Dir=human.Next=Down;human.Score=500;Plan(r,w);
     Check(r,p.Ai.directive?.type=="flee"&&p.Next!=Right,"A dangerous human retains priority over completing the snake: "+label);}
   }
  }
  static void MovingSnakeGaps(NativeCasualBiteReport r){
   foreach(int tier in new[]{0,1}){
    string label="tier="+tier;
    {var w=World(tier);var p=Ai(w);var s=Tail(w);Plan(r,w);Advance(w);w.SnakeStep(s);Plan(r,w);Advance(w);Plan(r,w);
     Check(r,p.Cell==new Vector2Int(8,5)&&p.Ai.casualSnake==s&&p.Ai.casualBites==1&&p.Ai.casualGap,"A real snake step permits one straight catch-up cell without inventing another bite: "+label);
     Advance(w);Plan(r,w);Advance(w);Plan(r,w);Check(r,s.Body.Count==1&&p.Next==Right&&p.Ai.thought=="casual-finish-head","An uninterrupted meal still finishes after the moving body creates a natural gap: "+label);Advance(w);
     Check(r,!p.Dead&&!w.Snakes.Contains(s)&&EmptyMeal(p),"The moving-body catch-up sequence completes through ordinary head consumption: "+label);}
    {var w=World(tier);var p=Ai(w);var s=Chain(r,w);w.SnakeStep(s);Plan(r,w);Advance(w);Plan(r,w);
     Check(r,p.Cell==new Vector2Int(10,5)&&s.Head==new Vector2Int(11,5)&&p.Next==Right&&p.Ai.thought=="casual-finish-head","A solitary head taking one ordinary step does not break the final bite sequence: "+label);Advance(w);
     Check(r,!p.Dead&&!w.Snakes.Contains(s)&&EmptyMeal(p),"The moving solitary head is eaten after exactly one safe catch-up cell: "+label);}
   }
  }
  static void ScopeGuards(NativeCasualBiteReport r){
   foreach(int tier in new[]{2,3,4}){var w=World(tier);var p=Ai(w);Tail(w);Move(w,Right);Move(w,Right);Check(r,EmptyMeal(p),"MEDIUM and higher never record this casual-only streak: tier="+tier);}
   {var w=World(0);var p=Ai(w);w.UseLegacyAi=true;Tail(w);Move(w,Right);Move(w,Right);Check(r,EmptyMeal(p),"The historical legacy brain never records casual finishing state");}
   {var w=World(0);var p=Ai(w);Chain(r,w);w.Time=w.LevelStarted+300000;Plan(r,w);Check(r,EmptyMeal(p)&&p.Ai.mealActive,"Time escalation expires the casual exception and retains maximum-skill intent");}
  }
  public static NativeCasualBiteReport Run(){var watch=Stopwatch.StartNew();var r=new NativeCasualBiteReport{scope="Editor-only genuine Plan/AdvancePlayer/Eat and SnakeStep regressions for continuous PICNIC/EASY meals. A single straight catch-up cell toward the same nearby snake preserves continuity; branching, different snakes and splits interrupt it. No rendered performance or human balance claim."};Group(r,"continuous meals",()=>ContinuousMeals(r));Group(r,"interrupted meals",()=>InterruptedMeals(r));Group(r,"finishing safety",()=>FinishingSafety(r));Group(r,"moving snake gaps",()=>MovingSnakeGaps(r));Group(r,"scope guards",()=>ScopeGuards(r));r.elapsedMs=watch.Elapsed.TotalMilliseconds;r.passed=r.failures==0;return r;}
 }
}
#endif

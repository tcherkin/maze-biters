using System;using System.Collections;using System.Collections.Generic;using System.IO;using System.Linq;using System.Reflection;using UnityEngine;
namespace MazeBiters.NativeStudy {
 public sealed partial class NativeGameplayStudy {
  bool auraPulseProbe;
  [Serializable] sealed class AuraPulseReport {public bool passed;public string quality,error;public int width,height,maskCases,minimumChangedPixels,overshootMax;public float minimumScale,maximumScale=1;public double periodMs;public string[] checks;}
  IEnumerator ProbeAuraPulse(){
   var result=new AuraPulseReport{quality=quality,minimumScale=NativeAuraPulse.MinimumScale,periodMs=NativeAuraPulse.PeriodMs};var checks=new List<string>();string folder=Path.GetDirectoryName(report);Directory.CreateDirectory(folder);
   void Check(bool ok,string name){if(!ok)throw new Exception("Aura pulse: "+name);checks.Add(name);}
   int Difference(Color32[] a,Color32[] b){int count=0;for(int i=0;i<a.Length;i++)if(!a[i].Equals(b[i]))count++;return count;}
   Color32[] Mask()=>PreparationPixels(dusk.mask);
   IEnumerator Run(){
    double period=NativeAuraPulse.PeriodMs,minimumTime=1000+period/2,nextMaximumTime=1000+period;
    Check(NativeAuraPulse.ScaleAt(1000)==1&&NativeAuraPulse.ScaleAt(nextMaximumTime)==1,"cycle maximum exactly matches the previous size");
    Check(NativeAuraPulse.ScaleAt(minimumTime)==NativeAuraPulse.MinimumScale,"cycle minimum matches the configured scale");
    bool range=true,symmetry=true;float last=1;
    for(int t=0;t<=period;t++){float v=NativeAuraPulse.ScaleAt(1000+t);range&=v>=NativeAuraPulse.MinimumScale&&v<=1;symmetry&=v==NativeAuraPulse.ScaleAt(1000+period-t);if(t<=period/2)range&=v<=last;else range&=v>=last;last=v;}
    Check(range&&symmetry,"balanced monotone contraction and expansion with no overshoot");
    Check(1-NativeAuraPulse.ScaleAt(1001)<1e-6&&NativeAuraPulse.ScaleAt(minimumTime+1)-NativeAuraPulse.MinimumScale<1e-6,"both ends ease smoothly without a direction snap");
    foreach(double t in new[]{1000d,1050,1000+period/4,minimumTime,nextMaximumTime-1,1000000})Check(Math.Abs(NativeAuraPulse.ScaleAt(t)-NativeAuraPulse.ScaleAt(t+period))<1e-6,"stable repeated cycle "+t);
    NativeDisplay.TestAspect=16f/9;sessionSmoke=true;fixedCamera=true;GlassScene(1,4);yield return DrainProbePreparation();GlassExtras();yield return DrainProbePreparation();preparationLightFrame=true;Render();
    var positions=new[]{new Vector2Int(7,13),new Vector2Int(17,13),new Vector2Int(27,13)};
    for(int i=0;i<world.PlayerCount;i++){var p=world.GetPlayer(i);p.Cell=p.From=p.Previous=world.Brain.Nearest(positions[i]);p.Waiting=true;p.ShieldUntil=0;p.Dir=p.Next=Vector2Int.right;actors[p.Id].aura.Reset(0,1000);}
    // Frozen geometry: inspect actual GPU masks, including the cached stationary
    // case, directions, centred reversals, power and the fading death aura.
    var origin=new Vector2(17,12);var directions=new[]{Vector2.right,Vector2.up,Vector2.left,Vector2.down,new Vector2(.5f,.5f),Vector2.zero};
    var originalTarget=dusk.mask;
    foreach(var direction in directions)foreach(int state in new[]{0,1,2}){
     double power=state==1?1:0,life=state==2?.5:1;bool dead=state==2;
     dusk.RenderAuraPose(origin,direction,power,dead,life,true);var previous=Mask();
     dusk.RenderAuraPose(origin,direction,power,dead,life,false,NativeAuraPulse.ScaleAt(1000));var maximum=Mask();Check(Difference(previous,maximum)==0,"maximum preserves exact previous mask / "+direction+" / "+state);
     dusk.RenderAuraPose(origin,direction,power,dead,life,false,NativeAuraPulse.ScaleAt(minimumTime));var minimum=Mask();int changed=Difference(maximum,minimum);result.minimumChangedPixels+=changed;Check(changed>0,"stationary mask cache updates on size alone / "+direction+" / "+state);
     int overshoot=0;for(int p=0;p<maximum.Length;p++)overshoot=Math.Max(overshoot,maximum[p].a-minimum[p].a);result.overshootMax=Math.Max(result.overshootMax,overshoot);Check(overshoot<=1,"smaller aura remains inside original light footprint / "+direction+" / "+state);
     dusk.RenderAuraPose(origin,direction,power,dead,life,false,NativeAuraPulse.ScaleAt(minimumTime));Check(Difference(minimum,Mask())==0,"same time preserves exact paused mask / "+direction+" / "+state);result.maskCases++;yield return null;
    }
    var restore=dusk.PreserveClock();float savedSize=dusk.AuraSize;var savedMask=Mask();dusk.RenderAuraPose(origin,Vector2.right,size:1);restore();Check(dusk.AuraSize==savedSize,"hidden GPU preparation restores pulse size");dusk.RenderAuraPose(origin,Vector2.zero,0,true,.5,false,savedSize);Check(Difference(savedMask,Mask())==0,"restored preview mask remains exact");
    time=world.Time=realClock=world.RealTime=1000;preparationLightFrame=true;Render();Capture(Path.Combine(folder,"maximum.png"));var fullMask=Mask();Check(dusk.AuraSize==1&&world.PlayerCount==3,"all three player auras use the maximum together");
    time=world.Time=realClock=world.RealTime=minimumTime;preparationLightFrame=true;Render();Capture(Path.Combine(folder,"minimum.png"));Check(dusk.AuraSize==NativeAuraPulse.MinimumScale&&Difference(fullMask,Mask())>0,"gameplay connects the pulse to all three auras");
    paused=true;var pausedMask=Mask();for(int i=0;i<3;i++){preparationLightFrame=true;Render();Check(Difference(pausedMask,Mask())==0,"pause holds the combined aura phase "+i);yield return null;}paused=false;
    time=world.Time=realClock=world.RealTime=nextMaximumTime;preparationLightFrame=true;Render();Check(Difference(fullMask,Mask())==0,"complete cycle restores the original combined maximum mask");
    var paints=(Material[])typeof(NativeNeon).GetField("overlaysPaint",BindingFlags.NonPublic|BindingFlags.Instance).GetValue(neon);Check(paints[1].GetFloat("_Amount")==3,"approved 300 percent wall reflections preserved");
    Check(ReferenceEquals(originalTarget,dusk.mask)&&dusk.mask.IsCreated(),"pulse reuses the existing GPU mask");result.width=target.width;result.height=target.height;Check(target.width==(quality=="4k"?3840:1920)&&target.height==(quality=="4k"?2160:1080),"native HD or 4K output");
   }
   var stack=new Stack<IEnumerator>();stack.Push(Run());while(stack.Count>0){object next=null;bool more=false;try{more=stack.Peek().MoveNext();if(more)next=stack.Peek().Current;}catch(Exception e){result.error=e.ToString();Debug.LogError(e);break;}if(!more){stack.Pop();continue;}if(next is IEnumerator nested){stack.Push(nested);continue;}yield return next;}
   result.passed=result.error==null;result.checks=checks.ToArray();File.WriteAllText(report,JsonUtility.ToJson(result,true));Application.Quit(result.passed?0:2);
  }
 }
}

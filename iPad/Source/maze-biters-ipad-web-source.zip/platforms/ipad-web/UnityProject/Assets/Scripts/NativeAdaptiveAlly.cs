using System;
namespace MazeBiters.NativeStudy {
 public readonly struct NativeAdaptiveAllySnapshot {
  public readonly bool Enabled,Initialized,Active,HasComparator,MaximumPolicy;
  public readonly int PlayerId,BaseIndex,ComparatorId,AiScore,HumanScore,Lives;
  public readonly double EffectiveIntensity,ProfileIntensity,TargetIntensity,BaselineIntensity,RatePerSecond,LastDeltaMs,UpdatedAt;
  public readonly string Reason;
  internal NativeAdaptiveAllySnapshot(bool enabled,bool initialized,bool active,bool comparator,bool maximum,int id,int index,int comparatorId,int aiScore,int humanScore,int lives,double effective,double profile,double target,double baseline,double rate,double delta,double updated,string reason){
   Enabled=enabled;Initialized=initialized;Active=active;HasComparator=comparator;MaximumPolicy=maximum;PlayerId=id;BaseIndex=index;ComparatorId=comparatorId;AiScore=aiScore;HumanScore=humanScore;Lives=lives;
   EffectiveIntensity=effective;ProfileIntensity=profile;TargetIntensity=target;BaselineIntensity=baseline;RatePerSecond=rate;LastDeltaMs=delta;UpdatedAt=updated;Reason=reason;
  }
 }
 public sealed partial class NativeGameplayWorld {
  struct AdaptiveAllyState {
   internal bool initialized,active,hasClock,hasComparator,maximum;
   internal int baseIndex,comparatorId,aiScore,humanScore,lives;
   internal double effective,profile,target,baseline,rate,delta,updated,sampleBucket;
   internal string reason;
  }
  // Stable participant IDs outlive FreshPlayer and the per-level planner state.
  // These three value slots allocate once with the world, never per frame.
  readonly AdaptiveAllyState[] adaptiveAllies=new AdaptiveAllyState[3];
  public bool AdaptiveAllyEnabled=>!UseLegacyAi&&(Mode==3||Mode==4);
  public void ResetAdaptiveAlly(){Array.Clear(adaptiveAllies,0,adaptiveAllies.Length);}
  static int AdaptiveBase(int index)=>Math.Max(0,Math.Min(4,index));
  static double AdaptiveRate(int lives)=>1.0/(lives<=1?9:lives==2?15:22);
  static double AdaptiveRelaxRate(int lives)=>1.0/(lives<=1?45:lives==2?30:22);
  static double AdaptiveLeadTarget(int aiScore,int humanScore,int lives){
   double scale=Math.Max(0,Math.Max(aiScore,humanScore)),start=Math.Max(150,.05*scale),full=Math.Max(600,.20*scale);
   double u=Math.Max(0,Math.Min(1,((double)aiScore-humanScore-start)/(full-start)));
   double depth=lives<=1?.35:lives==2?.65:1;
   return 4-depth*u*u*(3-2*u);
  }
  // Called only by the active simulation, before SessionTick can replace dead
  // players or finish a transition. Accessing a profile never advances learning.
  public void UpdateAdaptiveAlly(double t){
   if(!AdaptiveAllyEnabled||double.IsNaN(t)||double.IsInfinity(t))return;
   int index=AdaptiveBase(AiDifficulty);NativePlayer comparator=null;
   for(int i=0;i<PlayerCount;i++){var candidate=GetPlayer(i);if(candidate==null||candidate.IsAI||candidate.Lives<=0)continue;if(comparator==null||candidate.Score>comparator.Score)comparator=candidate;}
   bool playing=SessionEnabled&&!Transition&&!GameOverPending&&!GameOver&&!CatalogueFinished;
   for(int i=0;i<PlayerCount;i++){
    var actor=GetPlayer(i);if(actor==null||!actor.IsAI||actor.Id<1||actor.Id>adaptiveAllies.Length)continue;
    int slot=actor.Id-1;var state=adaptiveAllies[slot];
    if(!state.initialized||state.baseIndex!=index)state=new AdaptiveAllyState{initialized=true,baseIndex=index,effective=index,profile=index,target=index,baseline=index,maximum=index==4,sampleBucket=double.NegativeInfinity};
    double elapsed=state.hasClock&&t>=state.updated?Math.Min(250,t-state.updated):0;
    bool wasActive=state.active;state.hasClock=true;state.updated=t;state.active=playing&&!actor.Dead&&actor.Lives>0;state.delta=0;
    state.aiScore=actor.Score;state.lives=actor.Lives;state.hasComparator=comparator!=null;state.comparatorId=comparator?.Id??0;state.humanScore=comparator?.Score??0;
    if(!state.active){state.reason="frozen";adaptiveAllies[slot]=state;continue;}
    // The first active frame after loading, respawn or a transition establishes
    // the clock. Suspended time is never integrated on the following frame.
    if(!wasActive)elapsed=0;
    state.baseline=NativeDifficulty.ForIndex(index,Level,Math.Max(0,t-LevelStarted)).Intensity;
    state.rate=AdaptiveRate(actor.Lives);
    if(comparator==null){state.target=Math.Max(state.effective,state.baseline);state.reason="no-human-baseline";}
    else if(index==4){
     state.target=AdaptiveLeadTarget(actor.Score,comparator.Score,actor.Lives);state.reason=state.target<4?"brutal-lead":"baseline";
     if(state.target<state.effective)state.rate=AdaptiveRelaxRate(actor.Lives);
    }else if((double)comparator.Score-actor.Score>5){state.target=4;state.reason="catch-up";}
    else {state.target=state.baseline;state.reason="baseline";}
    double change=state.rate*elapsed/1000;
    if(state.target>state.effective)state.effective=Math.Min(state.target,state.effective+change);
    else state.effective=Math.Max(state.target,state.effective-change);
    state.effective=Math.Max(index==4?3:index,Math.Min(4,state.effective));state.delta=elapsed;
    // Hysteresis avoids repeatedly changing the exact-Maximum strategy when
    // a small score swing moves the continuous value just below four.
    if(state.maximum){if(state.effective<=3.90)state.maximum=false;}else if(state.effective>=4-1e-9)state.maximum=true;
    double bucket=Math.Floor(t/250);
    if(bucket!=state.sampleBucket){state.sampleBucket=bucket;state.profile=state.effective;}
    adaptiveAllies[slot]=state;
   }
  }
  internal bool TryAdaptiveAllyProfile(NativePlayer actor,out double intensity,out bool maximum){
   intensity=0;maximum=false;if(!AdaptiveAllyEnabled||actor==null||!actor.IsAI||actor.Id<1||actor.Id>adaptiveAllies.Length)return false;
   int index=AdaptiveBase(AiDifficulty);var state=adaptiveAllies[actor.Id-1];bool ready=state.initialized&&state.baseIndex==index;
   intensity=ready?state.profile:index;maximum=ready?state.maximum:index==4;return true;
  }
  public NativeAdaptiveAllySnapshot AdaptiveAllySample(int playerId){
   var actor=PlayerById(playerId);int index=AdaptiveBase(AiDifficulty);bool enabled=AdaptiveAllyEnabled&&actor!=null&&actor.IsAI;
   var state=playerId>=1&&playerId<=adaptiveAllies.Length?adaptiveAllies[playerId-1]:default;
   if(!enabled||!state.initialized||state.baseIndex!=index){
    var ordinary=NativeDifficulty.ForIndex(index,Level,Math.Max(0,Time-LevelStarted));double initial=enabled?index:ordinary.Intensity;
    return new NativeAdaptiveAllySnapshot(enabled,false,false,false,initial>=4,playerId,index,0,actor?.Score??0,0,actor?.Lives??0,initial,initial,initial,ordinary.Intensity,0,0,Time,enabled?"not-ticked":"disabled");
   }
   return new NativeAdaptiveAllySnapshot(true,true,state.active,state.hasComparator,state.maximum,playerId,state.baseIndex,state.comparatorId,state.aiScore,state.humanScore,state.lives,state.effective,state.profile,state.target,state.baseline,state.rate,state.delta,state.updated,state.reason);
  }
 }
}

using System;
using UnityEngine;
namespace MazeBiters.NativeStudy {
 public sealed partial class NativeGameplayStudy {
  string WebPowerAuraState(){
   if(world==null||!Application.absoluteURL.Contains("diagnostic=1"))return "null";
   var strengths=new double[world.PlayerCount];var palettes=new int[world.PlayerCount];
   for(int i=0;i<world.PlayerCount;i++){var p=world.GetPlayer(i);using(world.ForPlayer(p))strengths[i]=world.PowerStrength;palettes[i]=p.Palette;}
   return JsonUtility.ToJson(new WebPowerAuraSnapshot{active=dusk!=null&&dusk.PowerTintActive,bytes=dusk?.PowerTintTargetBytes??0,draws=dusk?.PowerTintFrames??0,power=strengths,palettes=palettes});
  }
  [Serializable]sealed class WebPowerAuraSnapshot{public string revision="20261116-power-aura";public bool active;public long bytes,draws;public double[] power;public int[] palettes;}
 }
}

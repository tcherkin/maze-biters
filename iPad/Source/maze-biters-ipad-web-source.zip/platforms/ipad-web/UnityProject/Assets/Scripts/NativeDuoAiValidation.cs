using System;using System.Linq;using UnityEngine;
namespace MazeBiters.NativeStudy {
 public static class NativeDuoAiValidation {
  public static int Run(){
   int count=0;void Check(bool ok,string name){count++;if(!ok)throw new Exception("DUO VS AI: "+name);}
   NativeGameplayWorld World(){var w=new NativeGameplayWorld(NativeLevelCatalogue.Get(1).geometry,()=>.5){SessionEnabled=true,Time=1000};w.SetMode(4);w.SetStarts(NativeLevelCatalogue.Get(1));for(int i=0;i<3;i++){var p=w.GetPlayer(i);p.Cell=p.From=p.Previous=new Vector2Int(3+i*3,1);p.Dir=p.Next=Vector2Int.right;p.Waiting=false;}return w;}
   var w=World();Check(w.PlayerCount==3&&w.Competitive&&!w.Cooperative,"mode 4 three-way competition");
   Check(!w.GetPlayer(0).IsAI&&!w.GetPlayer(1).IsAI&&w.GetPlayer(2).IsAI&&w.GetPlayer(2).Palette==2,"two humans plus original AI palette");
   using(w.ForPlayer(w.GetPlayer(2))){Check(w.Player.Id==3,"third actor scope");using(w.ForPlayer(w.GetPlayer(1)))Check(w.Player.Id==2,"nested second actor scope");Check(w.Player.Id==3,"scope restoration");}Check(w.Player.Id==1,"primary context restored");
   foreach(int a in new[]{1,2,3})foreach(int b in new[]{1,2,3})if(a!=b)foreach(int rule in new[]{0,1,2,3,4}){
    var v=World();var p=v.PlayerById(a);var q=v.PlayerById(b);p.Score=rule==0?500:100;p.ExactScore=p.Score;q.Score=rule==0?100:500;q.ExactScore=q.Score;
    if(rule==1)p.PowerUntil=4000;if(rule>=2){p.ShieldUntil=4000;q.PowerUntil=5000;}if(rule==3)q.ShieldUntil=4000;if(rule==4){p.ShieldUntil=q.PowerUntil=0;p.Score=q.Score;}
    bool win=rule<3;Check(v.CanEatPlayer(p,q)==win,"pair priority "+a+"/"+b+"/"+rule);
    if(win){int before=p.Score;Check(v.EatPlayer(p,q)&&q.Dead&&q.Lives==2&&p.Score==before+1000&&!v.GameOverPending,"pair eating "+a+"/"+b+"/"+rule);}
   }
   for(int lead=0;lead<3;lead++){for(int i=0;i<3;i++)w.GetPlayer(i).Score=i==lead?200:100;Check(w.LeaderId==lead+1,"unique leader "+lead);w.GetPlayer((lead+1)%3).Score=200;Check(w.LeaderId==0,"two-way top tie "+lead);}
   for(int i=0;i<3;i++)w.GetPlayer(i).Score=0;Check(w.LeaderId==0,"three-way tie");
   var s=w.AddSnake(new[]{new Vector2Int(8,1),new Vector2Int(7,1),new Vector2Int(6,1),new Vector2Int(5,1),new Vector2Int(4,1)},Vector2Int.right,0);s.PersonalThreat[2]=7;
   using(w.ForPlayer(w.GetPlayer(2)))w.Eat(s,2);Check(w.Snakes.Count==2&&w.Snakes.All(x=>x.PersonalThreat[2]>=7),"split inherits AI personal threat");Check(w.GetPlayer(2).Contribution==2,"split contribution assigned to AI");
   var camera=new NativeGameplayCamera();camera.Reset(0);camera.UpdateRoster(w,false,16,1000);Check(camera.Subjects==3&&camera.Living==3,"camera tracks three");
   var pointer=w.PointerPlayer(w.GetPlayer(2).Cell,0,0);Check(pointer!=null&&!pointer.IsAI,"pointer never selects AI");
   var next=w.PreviewNextLevel(NativeLevelCatalogue.Get(2),()=>.5,5000);Check(next.PlayerCount==3&&next.GetPlayer(2).IsAI&&next.GetPlayer(2).Score==w.GetPlayer(2).Score+500,"preview retains AI and original bonus");
   var t=World();var creature=new NativeCreature{Cell=new Vector2Int(10,1)};creature.PersonalThreat[2]=100;
   var state=new NativeBrainState();Check(t.Brain.SelectTarget(creature,state,1000).Id==3,"enemy may target third actor");Check(t.Brain.SelectTarget(creature,state,1001).Id==3,"held third target");
   t.GetPlayer(2).Dead=true;Check(t.Brain.SelectTarget(creature,state,1002).Id!=3,"dead third target released");t.GetPlayer(1).Dead=true;Check(t.Brain.SelectTarget(creature,state,1003).Id==1,"one survivor target");
   t=World();for(int i=0;i<3;i++){t.GetPlayer(i).Lives=1;using(t.ForPlayer(t.GetPlayer(i)))t.SessionDeath();Check(t.GameOverPending==(i==2),"game over only after final participant "+i);}
   var menu=new NativeMenuState();menu.SetFocus(4,100);menu.Activate(100);Check(menu.SelectedMode==4&&menu.Pending&&!menu.StartReady(999)&&menu.StartReady(1000),"original menu confirmation");
   return count;
  }
 }
}


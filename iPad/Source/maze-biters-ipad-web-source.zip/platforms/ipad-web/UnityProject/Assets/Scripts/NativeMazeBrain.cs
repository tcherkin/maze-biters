using System;
using System.Collections.Generic;
using System.Linq;
using UnityEngine;
namespace MazeBiters.NativeStudy {
 // Native translation of game.js MazeBrain (v1.02.17.02). Direction order,
 // random draws, stable ties, held thoughts and flanking rules are significant.
 public sealed class NativeBrainState {
  public double phase,period,focus,focusUntil,planUntil,surpriseAt,targetPlayerUntil,planDistance=double.PositiveInfinity;
  public int brainId,coordinationRole=-1,targetPlayerId,targetHunterId,planStalls,mischiefSnakeId;
  public double mischiefAt,mischiefUntil;
  public int hunterRevengeSeen;public double hunterCutMissAt;
  public string intent;public double intentUntil,observedAnger;public int intentPlayerId;
  public Vector2Int? target,lastChoice;public string planType,planTargetKey="";
  public readonly List<Vector2Int> routeHistory=new List<Vector2Int>();
 }
 public struct BrainProfile {public string kind;public bool flee;public double baseline,injury,stateBoost,listenBoost;}
 public sealed partial class NativeMazeBrain {
  readonly NativeGameplayWorld world;readonly Dictionary<Vector2Int,int[]> fields=new Dictionary<Vector2Int,int[]>();string epoch="";string[] fieldGrid;int nextId=1;
  bool typedEpoch,epochReady;int epochPlayers,epochRevision;Vector2Int epochFirst,epochSecond,epochThird;bool epochFirstDead,epochSecondDead,epochThirdDead;int[] fieldQueue;
  public long FieldCalls{get;private set;}public long FieldCacheHits{get;private set;}public long FieldBuilds{get;private set;}public long FieldEpochResets{get;private set;}
  public NativeMazeBrain(NativeGameplayWorld world){this.world=world;}
  double Random()=>world.Random();static double Clamp(double x,double a,double b)=>Math.Max(a,Math.Min(b,x));
  public static double Intelligence(int level,double age,double difficulty=1)=>NativeDifficulty.For(difficulty,level,age).Skill;
  static double LegacyIntelligence(int level,double age,double difficulty=1){double progress=Clamp((1+(Math.Max(1,level)-1)*difficulty-1)/99,0,1),baseline=Clamp((.04+progress*.76)*difficulty,.02,1);if(progress>=1)return 1;double calm=30000*(1-progress)/difficulty,duration=150000*(1-progress)/difficulty;if(age<=calm)return baseline;if(duration<=0)return 1;double p=Clamp((age-calm)/duration,0,1);return baseline+(1-baseline)*p*p*(3-2*p);}
  public static double Coordination(double value){double d=Clamp(value,0,1);return d>=.999999?1:d*(.8+d*.2);}
  public Vector2Int Nearest(Vector2Int target){var p=new Vector2Int(Mathf.Clamp(target.x,0,world.Width-1),Mathf.Clamp(target.y,0,world.Height-1));if(world.Floor(p)&&(!world.SolidEgg(p)||world.PlayerAt(p)!=null))return p;for(int r=1;r<Math.Max(world.Width,world.Height);r++)for(int y=-r;y<=r;y++)for(int x=-r;x<=r;x++)if(Math.Abs(x)+Math.Abs(y)==r&&world.Floor(p+new Vector2Int(x,y))&&!world.SolidEgg(p+new Vector2Int(x,y)))return p+new Vector2Int(x,y);return world.Player.Cell;}
  public int[] Field(Vector2Int target){
   FieldCalls++;bool typed=NativeHolisticTuning.FieldEpoch;
   // Editor comparisons may toggle the implementation on an existing brain.
   // Force a clean boundary rather than letting either cache inherit stale keys.
   if(typedEpoch!=typed){typedEpoch=typed;epochReady=false;epoch="";fieldGrid=null;}
   if(typed){
    int count=world.PlayerCount;var first=world.GetPlayer(0);var second=count>1?world.GetPlayer(1):null;var third=count==3?world.GetPlayer(2):null;
    bool changed=!epochReady||!ReferenceEquals(fieldGrid,world.Grid)||epochPlayers!=count||epochRevision!=world.ObstacleRevision||epochFirst!=first.Cell||epochFirstDead!=first.Dead||
     second!=null&&(epochSecond!=second.Cell||epochSecondDead!=second.Dead)||third!=null&&(epochThird!=third.Cell||epochThirdDead!=third.Dead);
    if(changed){fields.Clear();FieldEpochResets++;epochReady=true;fieldGrid=world.Grid;epochPlayers=count;epochRevision=world.ObstacleRevision;epochFirst=first.Cell;epochFirstDead=first.Dead;if(second!=null){epochSecond=second.Cell;epochSecondDead=second.Dead;}if(third!=null){epochThird=third.Cell;epochThirdDead=third.Dead;}}
   }else{
    string key=world.GetPlayer(0).Cell+":"+world.GetPlayer(0).Dead+":"+(world.Multiplayer?world.GetPlayer(1).Cell+":"+world.GetPlayer(1).Dead:"")+":"+(world.PlayerCount==3?world.GetPlayer(2).Cell+":"+world.GetPlayer(2).Dead:"")+":"+world.ObstacleRevision;
    if(epoch!=key||!ReferenceEquals(fieldGrid,world.Grid)){fields.Clear();FieldEpochResets++;epoch=key;fieldGrid=world.Grid;}
   }
   target=Nearest(target);if(fields.TryGetValue(target,out var existing)){FieldCacheHits++;return existing;}
   FieldBuilds++;int[] field=new int[world.Width*world.Height];for(int i=0;i<field.Length;i++)field[i]=-1;field[world.Index(target)]=0;
   if(NativeHolisticTuning.FieldQueue){
    if(fieldQueue==null||fieldQueue.Length!=field.Length)fieldQueue=new int[field.Length];int read=0,write=0;fieldQueue[write++]=world.Index(target);
    while(read<write){int index=fieldQueue[read++];var p=new Vector2Int(index%world.Width,index/world.Width);foreach(var d in NativeGameplayWorld.Dirs){var n=p+d;if(!world.Floor(n)||(n!=target&&world.SolidEgg(n)))continue;int next=world.Index(n);if(field[next]>=0)continue;field[next]=field[index]+1;fieldQueue[write++]=next;}}
   }else{
    var q=new Queue<Vector2Int>();q.Enqueue(target);while(q.Count>0){var p=q.Dequeue();foreach(var d in NativeGameplayWorld.Dirs){var n=p+d;if(!world.Floor(n)||(n!=target&&world.SolidEgg(n))||field[world.Index(n)]>=0)continue;field[world.Index(n)]=field[world.Index(p)]+1;q.Enqueue(n);}}
   }
   fields[target]=field;return field;
  }
  public Vector2Int? RouteStep(NativePlayer p,Vector2Int target){target=Nearest(target);if(p.Cell==target)return null;var field=Field(target);Vector2Int? best=null;int distance=int.MaxValue;bool straight=false;foreach(var d in NativeGameplayWorld.Dirs){var n=p.Cell+d;if(!world.PlayerCellOpen(p,n)||!world.PlayerRouteSafe(p,n))continue;int value=field[world.Index(n)];bool same=d==p.Dir;if(value>=0&&(value<distance||value==distance&&same&&!straight)){best=d;distance=value;straight=same;}}return best;}
  public NativeBrainState State(NativeCreature e){if(e.Brain==null)e.Brain=new NativeBrainState{phase=Random()*Math.PI*2,period=4200+Random()*6200,surpriseAt=world.Time+9000+Random()*15000,brainId=nextId++};return e.Brain;}
  public double Aggression(NativeCreature e,BrainProfile profile){var s=State(e);double t=world.Time,slow=.5+.5*Math.Sin(t/s.period+s.phase),quick=.5+.5*Math.Sin(t/(s.period*.43)+s.phase*1.71),potential=Clamp((profile.baseline+profile.injury+profile.stateBoost+Math.Min(.24,(world.Multiplayer?e.PersonalThreat[world.Player.Id-1]:e.Threat)*.055))*world.Difficulty,.04,.90);if(t>=s.focusUntil){s.focus=Clamp(potential*(.58+slow*.34+quick*.16)+(Random()-.5)*.16,.04,.91);s.focusUntil=t+700+Random()*1700;}return e.Aggression=s.focus;}
  Vector2Int Tactical(NativeCreature e,Vector2Int origin,BrainProfile profile,double attention){var s=State(e);var p=world.Player;double t=world.Time,intelligence=LegacyIntelligence(world.Level,t-world.LevelStarted,world.Difficulty);int population=world.Snakes.Count+world.Hunters.Count;
   if(s.planType=="coordinate-center"||s.planType=="coordinate-strike"||s.planType=="chase")s.target=p.Cell;
   if(!s.target.HasValue||t>=s.planUntil){if(s.coordinationRole<0)s.coordinationRole=(s.brainId-1)%3;bool coordinate=population>=3&&intelligence>0&&Random()<Coordination(intelligence);var direction=p.Dir==Vector2Int.zero?Vector2Int.right:p.Dir;var side=new Vector2Int(-direction.y,direction.x);
    if(coordinate){int role=s.coordinationRole;if(role==0){s.target=p.Cell;s.planType="coordinate-center";}else{s.target=Nearest(p.Cell+direction*Round(intelligence*3)+side*((2+Round(intelligence*3))*(role==1?-1:1)));s.planType=role==1?"coordinate-left":"coordinate-right";}s.planUntil=t+1000+(1-intelligence)*1800+Random()*700;}
    else{bool precise=population<3&&Random()<intelligence*.94,ambush=!precise&&attention>.62&&Random()<(.02+attention*.08)*(1-intelligence*.75);if(ambush){int lead=2+(int)(Random()*4),sideAmount=(Random()<.5?-1:1)*(1+(int)(Random()*3));s.target=Nearest(p.Cell+direction*lead+side*sideAmount);s.planType="ambush";s.planUntil=t+1600+Random()*2800;}else{s.target=p.Cell;s.planType="chase";s.planUntil=t+900+Random()*1900;}}
   }
   int planned=Field(s.target.Value)[world.Index(origin)];if(planned<0){s.target=p.Cell;s.planType="chase";s.planUntil=t+900;planned=Field(s.target.Value)[world.Index(origin)];}string key=s.target.Value.x+","+s.target.Value.y;if(s.planTargetKey==key)s.planStalls=planned>=s.planDistance?s.planStalls+1:0;else{s.planTargetKey=key;s.planStalls=0;}s.planDistance=planned;
   int playerDistance=Field(p.Cell)[world.Index(origin)];if((s.planType=="coordinate-left"||s.planType=="coordinate-right")&&(planned<=1||playerDistance>=0&&playerDistance<=4+Round(intelligence*4)||s.planStalls>=3)){s.target=p.Cell;s.planType="coordinate-strike";s.planUntil=t+700+(1-intelligence)*700;s.planTargetKey=p.Cell.x+","+p.Cell.y;s.planDistance=playerDistance;s.planStalls=0;}return s.target.Value;
  }
  static int Round(double x)=>(int)Math.Floor(x+.5); // JS Math.round, not banker's rounding.
  public Vector2Int Choose(NativeCreature e,Vector2Int origin,List<Vector2Int> options,BrainProfile profile){if(!world.UseLegacyAi)return ChooseDifficulty(e,origin,options,profile);if(options.Count<=1)return ChooseForPlayer(e,origin,options,profile);var selected=SelectTarget(e,State(e),world.Time);using(world.ForPlayer(selected))return ChooseForPlayer(e,origin,options,profile);}
  public NativePlayer SelectTarget(NativeCreature e,NativeBrainState state,double t){
   var a=world.GetPlayer(0);int living=0;NativePlayer only=a;for(int i=0;i<world.PlayerCount;i++){var p=world.GetPlayer(i);if(!p.Dead&&p.Lives>0){living++;only=p;}}if(living==0)return a;if(living==1)return only;
   var current=world.PlayerById(state.targetPlayerId);if(current!=null&&!current.Dead&&current.Lives>0&&t<state.targetPlayerUntil)return current;
   double Weight(NativePlayer p)=>1+e.PersonalThreat[p.Id-1]*1.8+Math.Max(0,p.Contribution)*.055+3.0/(2+Math.Abs(e.Cell.x-p.Cell.x)+Math.Abs(e.Cell.y-p.Cell.y));
   double total=0;for(int i=0;i<world.PlayerCount;i++){var p=world.GetPlayer(i);if(!p.Dead&&p.Lives>0)total+=Weight(p);}double roll=Random()*total;var chosen=only;for(int i=0;i<world.PlayerCount;i++){var p=world.GetPlayer(i);if(p.Dead||p.Lives<=0)continue;roll-=Weight(p);if(roll<=0){chosen=p;break;}}state.targetPlayerId=chosen.Id;state.targetPlayerUntil=t+1000+Random()*2400;state.target=null;state.planUntil=0;return chosen;
  }
  Vector2Int ChooseForPlayer(NativeCreature e,Vector2Int origin,List<Vector2Int> options,BrainProfile profile){if(options.Count<1){e.VisualTarget=null;return Vector2Int.zero;}if(options.Count==1){e.VisualTarget=null;return options[0];}var s=State(e);double t=world.Time,attention=Aggression(e,profile),intelligence=LegacyIntelligence(world.Level,t-world.LevelStarted,world.Difficulty);e.Intelligence=intelligence;bool straight=options.Contains(e.Dir);double chance=Clamp(.08+attention*.94+profile.listenBoost+intelligence*.58,.10,intelligence>=.999999?1:.98);
   if(Random()>chance){e.VisualTarget=null;if(straight&&Random()<.48+(1-attention)*.28)return e.Dir;return options[(int)(Random()*options.Count)];}
   var target=profile.flee?world.Player.Cell:Tactical(e,origin,profile,attention);e.VisualTarget=target;var field=Field(target);s.routeHistory.Add(origin);if(s.routeHistory.Count>16)s.routeHistory.RemoveAt(0);var ranked=new List<(Vector2Int d,double score,int index)>();for(int i=0;i<options.Count;i++){var d=options[i];int distance=field[world.Index(origin+d)],visits=s.routeHistory.Count(p=>p==origin+d);double score=(distance<0?10000:profile.flee?-distance:distance)-(straight&&d==e.Dir?.16:0)+(s.lastChoice.HasValue&&s.lastChoice.Value==-d?.22:0)+visits*(.8+intelligence*3.2);ranked.Add((d,score,i));}ranked.Sort((a,b)=>a.score!=b.score?a.score.CompareTo(b.score):a.index.CompareTo(b.index));var choice=ranked[0];bool coordinated=s.planType!=null&&s.planType.StartsWith("coordinate-");if(!profile.flee&&!coordinated&&attention>.68&&t>=s.surpriseAt&&ranked.Count>1){s.surpriseAt=t+10000+Random()*16000;if(Random()<.24){var alternatives=ranked.Skip(1).Where(x=>x.score<10000&&x.score<=ranked[0].score+6).ToList();if(alternatives.Count>0){choice=alternatives[(int)(Random()*alternatives.Count)];int x=(Random()<.5?1:-1)*(2+(int)(Random()*4)),y=(Random()<.5?1:-1)*(2+(int)(Random()*4));s.target=Nearest(world.Player.Cell+new Vector2Int(x,y));s.planType="flank";s.planUntil=t+1800+Random()*2600;}}}s.lastChoice=choice.d;return choice.d;
  }
 }
}

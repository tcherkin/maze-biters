using System;using System.Collections;using UnityEngine;
namespace MazeBiters.NativeStudy {
 public sealed partial class NativeMenu {
  Coroutine menuArtworkLoading,recordArtworkLoading;NativeMenuRenderer menuArtworkCandidate;IDisposable recordArtworkSteps;bool menuArtworkFailed;
  bool MenuArtworkReady=>renderer!=null&&renderer.Ready&&renderer.RecordsReady&&Audio.RecordTrackReady&&renderer.Manifest.quality==State.Quality&&menuArtworkLoading==null;
  void FailMenuPreparation(Exception error){
   preloadFailed=true;preparationFailure=error.ToString();
   State.SignalPrepared(Now,false);confirmationPresentedFrame=-1;
   Debug.LogWarning("Menu preparation will recover without a cold-start frame: "+preparationFailure);
  }
  void QueueMenuArtwork(){
   if(gameplay||renderer==null||menuArtworkFailed||preparationError!=null)return;
   if(renderer.Manifest.quality!=State.Quality&&recordArtworkLoading!=null)CancelRecordArtwork();
   if(renderer.Manifest.quality==State.Quality&&(!renderer.RecordsReady||!Audio.RecordTrackReady)&&recordArtworkLoading==null)recordArtworkLoading=StartCoroutine(LoadRecordArtwork(renderer));
   if(renderer.Manifest.quality==State.Quality||menuArtworkLoading!=null)return;menuArtworkLoading=StartCoroutine(LoadMenuArtwork());
  }
  IEnumerator LoadRecordArtwork(NativeMenuRenderer owner){
   yield return null;Exception failure=null;double deadline=Time.realtimeSinceStartupAsDouble+60;
   using(var steps=owner.PrepareRecordsSteps().GetEnumerator()){recordArtworkSteps=steps;while(renderer==owner){
    bool more=false;try{if(Time.realtimeSinceStartupAsDouble>deadline)throw new TimeoutException("Record artwork preparation timed out");more=steps.MoveNext();}catch(Exception e){failure=e;}
    if(failure!=null||!more)break;yield return null;
   }}recordArtworkSteps=null;
   if(failure==null&&renderer==owner){using(var steps=Audio.PrepareRecordTrackSteps().GetEnumerator()){recordArtworkSteps=steps;while(renderer==owner){
    bool more=false;try{more=steps.MoveNext();}catch(Exception e){failure=e;}
    if(failure!=null||!more)break;yield return null;
   }}}recordArtworkSteps=null;
   recordArtworkLoading=null;if(failure!=null){menuArtworkFailed=true;FailMenuPreparation(failure);}
  }
  IEnumerator LoadMenuArtwork(){
   yield return null;
   string wanted=State.Quality;Exception failure=null;double deadline=Time.realtimeSinceStartupAsDouble+60;
   try{menuArtworkCandidate=new NativeMenuRenderer(wanted,deferred:true);}catch(Exception e){failure=e;}
   if(failure==null){
    using(var steps=menuArtworkCandidate.LoadSteps().GetEnumerator())while(State.Quality==wanted){
     bool more=false;try{if(Time.realtimeSinceStartupAsDouble>deadline)throw new TimeoutException("Menu artwork preparation timed out");more=steps.MoveNext();}catch(Exception e){failure=e;}
     if(failure!=null||!more)break;yield return null;
    }
   }
   if(failure==null&&wanted==State.Quality&&menuArtworkCandidate.Ready){
    try{menuArtworkCandidate.SetLeaderIfChanged(scores.Entries.Length>0?scores.Entries[0]:null);menuArtworkCandidate.Render(State,Now);}catch(Exception e){failure=e;}
    if(failure==null){
     using(var ready=NativePreparation.DrainSteps(menuArtworkCandidate.Target,true).GetEnumerator())while(State.Quality==wanted){
      bool more=false;try{more=ready.MoveNext();}catch(Exception e){failure=e;}
      if(failure!=null||!more)break;yield return null;
     }
    }
    if(failure==null&&wanted==State.Quality){CancelRecordArtwork();var previous=renderer;renderer=menuArtworkCandidate;menuArtworkCandidate=null;previous.Dispose();}
   }
   menuArtworkCandidate?.Dispose();menuArtworkCandidate=null;menuArtworkLoading=null;
   if(failure!=null){menuArtworkFailed=true;FailMenuPreparation(failure);}
  }
  void CancelRecordArtwork(){
   if(recordArtworkLoading!=null)StopCoroutine(recordArtworkLoading);recordArtworkLoading=null;
   // Unity coroutine cancellation does not reliably dispose nested iterators.
   // Release the owned iterator explicitly so the renderer can resume loading.
   var pending=recordArtworkSteps;recordArtworkSteps=null;pending?.Dispose();
  }
  void CancelMenuArtwork(){if(menuArtworkLoading!=null)StopCoroutine(menuArtworkLoading);CancelRecordArtwork();menuArtworkLoading=null;menuArtworkCandidate?.Dispose();menuArtworkCandidate=null;}
 }
}

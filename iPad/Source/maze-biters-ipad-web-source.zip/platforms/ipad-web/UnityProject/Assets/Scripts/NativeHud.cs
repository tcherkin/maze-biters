using System;
using System.IO;
using UnityEngine;
namespace MazeBiters.NativeStudy {
 // Original SOLO HUD: immutable native-size artwork, four retained glyph meshes.
 // No full-scene target, readbacks or per-frame glyph/string allocations.
 public sealed partial class NativeHud:IDisposable {
  const string Characters="ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789?";
  public const double LifeSweep=1240,LevelSweep=3720,LifePulseDuration=Math.PI*2*310*3;
  readonly GameObject root,background;readonly Material backgroundPaint;readonly MeshRenderer backgroundRenderer;readonly Row[] rows=new Row[8];
  Material skyPaint;Vector2 skyOffset;bool skyReady;
  float frameWidth=576;readonly Mesh starMesh=new Mesh();Texture2D font,aiFont,stars,beam;string quality;double scale;
  double levelAt=double.NegativeInfinity,lifeAt=double.NegativeInfinity;
  public double LevelAt=>levelAt;public double LifeAt=>lifeAt;
  public int MeshUpdates{get;private set;}
  internal bool PrimaryAiLabel=>rows[0].prefix=="AI "&&aiFont&&rows[0].material.mainTexture==aiFont;
  public long TextureBytes=>font?(long)(font.width*font.height+(aiFont?aiFont.width*aiFont.height:0)+stars.width*stars.height+beam.width*beam.height)*4:0;
  sealed class Row:IDisposable {
   public readonly GameObject go;public readonly Mesh mesh;public readonly Material material;
   public readonly Vector3[] vertices=new Vector3[256];public readonly Vector2[] uv=new Vector2[256];public readonly int[] triangles=new int[384];
   public string prefix;public bool centered,rightAligned,padded;public float anchor=float.NaN,yPosition=float.NaN;public int value=int.MinValue;public float left,right;public double opacity=double.NaN,beamX=double.NaN;public bool active;
   public Row(Transform parent){mesh=new Mesh{name="Retained original HUD glyphs"};mesh.MarkDynamic();material=new Material(Shader.Find("MazeBiters/HudGlyph"));go=new GameObject("HUD text");go.transform.SetParent(parent,false);go.AddComponent<MeshFilter>().sharedMesh=mesh;var r=go.AddComponent<MeshRenderer>();r.sharedMaterial=material;r.sortingOrder=102;}
   public void Dispose(){UnityEngine.Object.Destroy(go);UnityEngine.Object.Destroy(mesh);UnityEngine.Object.Destroy(material);}
  }
  public NativeHud(Mesh quad,Transform parent){
   root=new GameObject("Original fixed SOLO HUD");root.transform.SetParent(parent,false);
   background=new GameObject("Original HUD microstars");background.transform.SetParent(root.transform,false);
   background.AddComponent<MeshFilter>().sharedMesh=starMesh;starMesh.vertices=quad.vertices;starMesh.uv=quad.uv;starMesh.triangles=quad.triangles;starMesh.RecalculateBounds();backgroundPaint=new Material(Shader.Find("MazeBiters/SessionImage"));
   backgroundRenderer=background.AddComponent<MeshRenderer>();backgroundRenderer.sharedMaterial=backgroundPaint;backgroundRenderer.sortingOrder=101;
   background.transform.localPosition=new Vector3(0,32,-3);background.transform.localScale=new Vector3(576,32,1);
   for(int i=0;i<rows.Length;i++)rows[i]=new Row(root.transform);
  }
  float ipadLeft,ipadTop;
  public void SetIpadArea(NativeFrame frame,Rect area){ipadLeft=area.x;ipadTop=area.y;root.transform.localPosition=new Vector3(ipadLeft,-ipadTop,0);SetWidth(area.width);}
  public void SetWidth(float width){if(Mathf.Abs(width-frameWidth)<.001f)return;frameWidth=width;background.transform.localScale=new Vector3(width,32,1);starMesh.uv=new[]{new Vector2(0,1),new Vector2(width/576,1),new Vector2(width/576,0),new Vector2(0,0)};}
  // The HUD and exposed world share screen-space sky coordinates. Only the
  // background pans: glyph meshes, score sweeps and text anchors remain fixed.
  public void SetSky(NativeFrame frame,double x,double y){
   background.SetActive(!frame.OverlayHud);if(frame.OverlayHud)return;
   var offset=frame.SkyOffset(x,y);if(skyReady&&skyOffset==offset)return;
   if(!skyPaint){skyPaint=new Material(Shader.Find(NativeGlassPresentation.SkyShader));skyPaint.SetVector("_Rect",new Vector4(0,0,576,32));backgroundRenderer.sharedMaterial=skyPaint;}
   skyReady=true;skyOffset=offset;skyPaint.SetVector("_Offset",new Vector4(offset.x,offset.y,0,0));
  }
  public void BeginLevel(double realTime,bool fresh=false){levelAt=realTime;ResetContacts();if(fresh)lifeAt=double.NegativeInfinity;}
  public void BonusLife(double realTime,int playerId=1){if(playerId==1)lifeAt=realTime;}
  public static bool Active(double start,double duration,double t)=>double.IsFinite(start)&&t>=start&&t-start<duration;
  public static double LifeAlpha(double start,double t){
   double elapsed=t-start-LifeSweep;
   return !double.IsFinite(start)||elapsed<0||elapsed>=LifePulseDuration?1:.6+.4*Math.Cos(elapsed/310);
  }
  public static double BeamLeft(double start,double duration,int passes,double left,double right,double t,double scale){
   double position=(t-start)/duration*passes;int pass=Math.Min(passes-1,(int)Math.Floor(position));double progress=position-pass,travel=pass%2==0?progress:1-progress;
   double x=left-72+travel*(right-72*.18-(left-72));
   return Math.Floor(x*scale+.5)/scale;
  }
  static Texture2D Load(string name){
   var t=new Texture2D(2,2,TextureFormat.RGBA32,false){name=name,filterMode=FilterMode.Point,wrapMode=TextureWrapMode.Clamp};
   if(!t.LoadImage(File.ReadAllBytes(Path.Combine(WebFiles.Root,"Reference/hud",name)),true))throw new IOException(name);return t;
  }
  public void SetQuality(string value){
   if(quality==value)return;quality=value;scale=value=="4k"?5:2.5;
   if(aiFont){UnityEngine.Object.Destroy(aiFont);aiFont=null;}if(font)UnityEngine.Object.Destroy(font);if(stars)UnityEngine.Object.Destroy(stars);if(beam)UnityEngine.Object.Destroy(beam);
   font=Load(value+"-font.png");stars=Load(value+"-background.png");stars.wrapModeU=TextureWrapMode.Repeat;beam=Load(value+"-beam.png");
   backgroundPaint.mainTexture=stars;
   foreach(var row in rows){row.material.mainTexture=font;row.material.SetTexture("_Beam",beam);row.beamX=double.NaN;}
  }
  void Text(int index,int value,string prefix,float y,bool center,bool padded=false,bool right=false,float offset=0){
   var row=rows[index];float anchor=right?frameWidth:center?frameWidth/2:offset;if(row.value==value&&row.prefix==prefix&&row.anchor==anchor&&row.yPosition==y&&row.centered==center&&row.rightAligned==right&&row.padded==padded)return;row.centered=center;row.rightAligned=right;row.padded=padded;row.value=value;row.prefix=prefix;row.anchor=anchor;row.yPosition=y;MeshUpdates++;
   string text=prefix+(padded?value.ToString("D4",System.Globalization.CultureInfo.InvariantCulture):value.ToString(System.Globalization.CultureInfo.InvariantCulture));
   float left=right?frameWidth-text.Length*16:center?frameWidth/2-text.Length*8:offset;row.left=left;row.right=left+text.Length*16;
   int n=0,m=0;
   for(int i=0;i<text.Length;i++){
    int c=Characters.IndexOf(text[i]);if(c<0)continue;float x=left+i*16,u=(float)c/Characters.Length,u2=(float)(c+1)/Characters.Length;
    row.vertices[n]=new Vector3(x,32-y,-3);row.vertices[n+1]=new Vector3(x+16,32-y,-3);
    row.vertices[n+2]=new Vector3(x+16,16-y,-3);row.vertices[n+3]=new Vector3(x,16-y,-3);
    row.uv[n]=new Vector2(u,1);row.uv[n+1]=new Vector2(u2,1);row.uv[n+2]=new Vector2(u2,0);row.uv[n+3]=new Vector2(u,0);
    row.triangles[m++]=n;row.triangles[m++]=n+1;row.triangles[m++]=n+2;row.triangles[m++]=n;row.triangles[m++]=n+2;row.triangles[m++]=n+3;n+=4;
   }
   row.mesh.Clear();row.mesh.SetVertices(row.vertices,0,n);row.mesh.SetUVs(0,row.uv,0,n);row.mesh.SetTriangles(row.triangles,0,m,0);row.mesh.RecalculateBounds();
  }
  void Effect(int index,double start,double duration,int passes,double opacity,double t){
   var row=rows[index];bool on=Active(start,duration,t);double x=on?BeamLeft(start,duration,passes,row.left,row.right,t,scale):0;
   if(row.opacity!=opacity){row.opacity=opacity;row.material.SetFloat("_Opacity",(float)opacity);}
   if(row.active!=on){row.active=on;row.material.SetFloat("_BeamOn",on?1:0);}
   if(row.beamX!=x){row.beamX=x;row.material.SetFloat("_BeamX",(float)x);}
  }
  public void Render(NativeGameplayWorld world,double realTime,string quality){if(world.PlayerCount==3){RenderThree(world,realTime,quality);return;}var p=world.GetPlayer(0);RenderValues(p.Score,p.Lives,world.Level,world.Snakes.Count,realTime,quality,levelAt,lifeAt,ai:p.IsAI);if(world.Multiplayer){var p2=world.GetPlayer(1);if(p2.IsAI&&!aiFont)aiFont=Load(quality+"-ai-font.png");rows[4].material.mainTexture=p2.IsAI?aiFont:font;Text(4,p2.Score,p2.IsAI?"AI ":"P2 ",0,false,true,true);Text(5,p2.Lives,"LIVES ",16,false,false,true);rows[4].go.SetActive(true);rows[5].go.SetActive(true);Effect(0,p.ScoreSpotlight,620,1,world.ScoreAlpha(p,realTime),realTime);Effect(4,p2.ScoreSpotlight,620,1,world.ScoreAlpha(p2,realTime),realTime);Effect(1,p.LifeSpotlight,LifeSweep,1,LifeAlpha(p.LifeSpotlight,realTime),realTime);Effect(5,p2.LifeSpotlight,LifeSweep,1,LifeAlpha(p2.LifeSpotlight,realTime),realTime);}}
  void RenderThree(NativeGameplayWorld world,double t,string quality){
   SetQuality(quality);if(!aiFont)aiFont=Load(quality+"-ai-font.png");
   for(int i=0;i<world.PlayerCount;i++){var p=world.GetPlayer(i);int row=i==0?0:i==1?4:6;bool right=i==2;float x=i==1?frameWidth/4:0;
    rows[row].material.mainTexture=p.IsAI?aiFont:font;rows[row].go.SetActive(true);rows[row+1].go.SetActive(true);
    Text(row,p.Score,p.IsAI?"AI ":"P"+p.Id+" ",0,false,true,right,x);Text(row+1,p.Lives,"LIVES ",16,false,false,right,x);
    Effect(row,p.ScoreSpotlight,620,1,world.ScoreAlpha(p,t),t);Effect(row+1,p.LifeSpotlight,LifeSweep,1,LifeAlpha(p.LifeSpotlight,t),t);
   }
   Text(2,world.Level,"LEVEL ",0,false,false,false,frameWidth/2);Text(3,world.Snakes.Count,"SNAKES ",16,false,false,false,frameWidth/2);
   Effect(2,levelAt,LevelSweep,3,1,t);Effect(3,double.NegativeInfinity,1,1,1,t);
  }
  public void RenderValues(int score,int lives,int level,int snakes,double t,string quality,double levelStart,double lifeStart,double scoreStart=double.NegativeInfinity,bool ai=false){
   SetQuality(quality);for(int i=4;i<8;i++)rows[i].go.SetActive(false);
   if(ai&&!aiFont)aiFont=Load(quality+"-ai-font.png");rows[0].material.mainTexture=ai?aiFont:font;
   Text(0,score,ai?"AI ":"P1 ",0,false,true);Text(1,lives,"LIVES ",16,false);Text(2,level,"LEVEL ",0,true);Text(3,snakes,"SNAKES ",16,true);
   // A single player is not a unique multiplayer leader: no invented score pulse.
   Effect(0,scoreStart,620,1,1,t);Effect(1,lifeStart,LifeSweep,1,LifeAlpha(lifeStart,t),t);
   Effect(2,levelStart,LevelSweep,3,1,t);Effect(3,double.NegativeInfinity,1,1,1,t);
  }
  public void Dispose(){
   foreach(var row in rows)row.Dispose();UnityEngine.Object.Destroy(root);UnityEngine.Object.Destroy(starMesh);UnityEngine.Object.Destroy(backgroundPaint);
   UnityEngine.Object.Destroy(aiFont);UnityEngine.Object.Destroy(font);UnityEngine.Object.Destroy(stars);UnityEngine.Object.Destroy(beam);UnityEngine.Object.Destroy(skyPaint);
  }
 }
}


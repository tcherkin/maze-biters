using System;using System.IO;using System.Collections;using System.Collections.Generic;using UnityEngine;
namespace MazeBiters.NativeStudy {
 public sealed partial class NativeMenu {
  bool coopMenuTesting;
  [Serializable] sealed class CoopMenuReport {public bool passed;public string quality,note;public string[] checks;public double clickToPlayMs,restartClickToPlayMs;public bool gameOverReady;}
  IEnumerator CoopMenuProbe(){
   bool duoAi=Array.IndexOf(Environment.GetCommandLineArgs(),"--duo-ai")>=0;bool ai=Array.IndexOf(Environment.GetCommandLineArgs(),"--solo-ai")>=0,vs=Array.IndexOf(Environment.GetCommandLineArgs(),"--versus")>=0;int requested=duoAi?4:ai?3:vs?2:5,focus=duoAi?4:ai?3:vs?2:1;
   var result=new CoopMenuReport{quality=State.Quality};var checks=new List<string>();void Check(bool b,string n){if(!b)throw new Exception("COOP menu: "+n);checks.Add(n);}
   Directory.CreateDirectory(Path.GetDirectoryName(report));
   IEnumerator Ready(){double start=Time.realtimeSinceStartupAsDouble;while(!PreparedForSelection){if(preloadFailed||Time.realtimeSinceStartupAsDouble-start>120)throw new TimeoutException("COOP menu preload");yield return null;}}
   IEnumerator Playing(){double start=Time.realtimeSinceStartupAsDouble;while(!gameplay||!gameplay.MenuReady){if(Time.realtimeSinceStartupAsDouble-start>120)throw new TimeoutException("COOP menu start");yield return null;}}
   yield return Ready();Check(preparedGame.PreparedMode==1,"initial SOLO remains prepared");
   State.SetFocus(focus,Now);yield return Ready();Check(preparedGame.PreparedMode==requested,"changing to COOP rebuilds population but reuses art banks");Check(preparedBuilds==1,"only one source-bank load");
   double click=Time.realtimeSinceStartupAsDouble;Choose();yield return Playing();result.clickToPlayMs=(Time.realtimeSinceStartupAsDouble-click)*1000;
   Check(gameplay.MenuOptionsValid&&gameplay.CoopRosterValid&&gameplay.MenuMode==requested&&gameplay.MenuRecord.mode==requested,"original COOP starts with both identities, settings and HUD");Check(NativeBalancedLaunch.Distributed?result.clickToPlayMs>=890&&result.clickToPlayMs<960:InstantMenuStart?result.clickToPlayMs<250:result.clickToPlayMs>=890,"selected menu start policy");
   SaveFrame(State.Quality+"-coop-menu-start",gameplay.MenuTarget);gameplay.CoopLastLives();
   double until=Time.realtimeSinceStartupAsDouble+60;while(gameplay){result.gameOverReady|=gameplay.RestartPrepared;if(Time.realtimeSinceStartupAsDouble>until)throw new TimeoutException("COOP GAME OVER");yield return null;}
   while(changing)yield return null;if(records!=null)CloseRecords();yield return Ready();
   Check(result.gameOverReady,"first COOP level/GPU prepared during GAME OVER");Check(State.SelectedMode==requested&&preparedGame.PreparedMode==requested,"return to menu retains COOP");Check(preparedBuilds==1,"restart reuses both players animation banks");
   State.SetFocus(focus,Now);click=Time.realtimeSinceStartupAsDouble;Choose();yield return Playing();result.restartClickToPlayMs=(Time.realtimeSinceStartupAsDouble-click)*1000;Check(gameplay.CoopRosterValid,"cached restart restores both players");
   ReturnToMenu();while(changing)yield return null;State.SetFocus(0,Now);yield return Ready();Choose();yield return Playing();Check(gameplay.MenuMode==1&&gameplay.MenuOptionsValid,"switching back to SOLO never installs stale COOP roster");
   result.passed=true;result.checks=checks.ToArray();result.note="Muted actual menu (CLI --versus selects DUO VS mode 2) -> selected roster -> all final deaths -> GAME OVER preload -> cached COOP restart -> SOLO. Original 900ms confirmation included; timing is not an FPS benchmark. User preferences/high scores untouched.";File.WriteAllText(report,JsonUtility.ToJson(result,true));Application.Quit();
  }
 }
 public sealed partial class NativeGameplayStudy {
  public bool CoopRosterValid=>world.Multiplayer&&world.PlayerCount==(world.Mode==4?3:2)&&(world.Mode!=4||actors.ContainsKey(3)&&actors[3].art.Palette=="ai"&&world.GetPlayer(2).IsAI&&world.GetPlayer(2).Lives==3)&&actors.ContainsKey(2)&&actors[1].art.Palette=="p1"&&actors[2].art.Palette==(world.Mode==3?"ai":"p2")&&world.GetPlayer(0).Lives==3&&world.GetPlayer(1).Lives==3;
  public void CoopLastLives(){for(int i=0;i<world.PlayerCount;i++)using(world.ForPlayer(world.GetPlayer(i))){world.Player.Lives=1;world.SessionDeath();}}
 }
}


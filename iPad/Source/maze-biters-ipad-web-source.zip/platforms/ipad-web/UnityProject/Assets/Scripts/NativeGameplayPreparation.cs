using System;
using System.Collections;
using System.Collections.Generic;
using System.Diagnostics;
using UnityEngine;
namespace MazeBiters.NativeStudy {
 public sealed partial class NativeGameplayStudy {
  NativeScorpionImages scorpionImages;
  string preparedScorpionQuality;
  bool coldPreparationControl,discardPreparationDelta,preparationLightFrame;
  int preparationFrames;
  [Serializable] sealed class PreparationSample {
   public string quality;public int scenario,shapes,caps,eyes,apertures,scorpionImages;
   public double ms,logicMs;public int logicCases;public long turnTextureBytes,scorpionTextureBytes;
  }
  readonly List<PreparationSample> preparationSamples=new List<PreparationSample>();
  NativeScorpionArt CreateScorpionArt(){
   // Comparison switch is diagnostic-only. Keep the old per-instance source
   // lifetime in that control so it remains a meaningful cold-path baseline.
   if(coldPreparationControl)return new NativeScorpionArt(quad,1);
   if(scorpionImages==null)scorpionImages=new NativeScorpionImages();
   return new NativeScorpionArt(quad,1,scorpionImages);
  }
  void PrepareLevelResources(){
   if(logicPreparationInstance||coldPreparationControl||world==null||bank==null)return;
   long start=Stopwatch.GetTimestamp();
   if(world.HasAI)NativeAllyValidation.Prepare();
   bank.PrepareGameplay();
   if(scorpionImages==null)scorpionImages=new NativeScorpionImages();
   scorpionImages.Prepare();
   if(preparedScorpionQuality!=quality){
    using(var warm=new NativeScorpionArt(quad,1,scorpionImages))warm.Prepare(quality);
    preparedScorpionQuality=quality;
   }
   sessionArt?.SetQuality(quality);hud?.SetQuality(quality);
   PrepareGameplayLogic();
   scenePreparationPending=!coldSceneControl;
   preparationSamples.Add(new PreparationSample{quality=quality,scenario=scenario,ms=(Stopwatch.GetTimestamp()-start)*1000.0/Stopwatch.Frequency,
    logicMs=logicPreparationMs,logicCases=logicPreparationCases,shapes=bank.ShapeCount,caps=bank.CapCount,eyes=bank.EyeCount,apertures=bank.ApertureCount,scorpionImages=scorpionImages.Count,turnTextureBytes=bank.TextureBytes,scorpionTextureBytes=scorpionImages.TextureBytes});
   // Two non-simulation frames allow temporary Unity objects to be destroyed.
   // Fixed-time automation drains these explicitly; ordinary play uses Update.
   if(!smoke&&!contactProbe)preparationFrames=2;
  }
  bool WaitForLevelPreparation(){
   if(preparationFrames==0)return false;
   if(--preparationFrames==0){PrepareSceneGpu();GC.Collect();CaptureStartupProof();discardPreparationDelta=true;}
   return true;
  }
  IEnumerator DrainProbePreparation(){
   if(coldPreparationControl||!scenePreparationPending)yield break;
   yield return null;yield return null;PrepareSceneGpu();GC.Collect();
   // Preparation and its disposal/GC are excluded, never hidden inside a
   // measured frame. Simulation time, RNG and animation clocks have not moved.
  }
 }
}

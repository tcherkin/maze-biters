using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.CompilerServices;
using UnityEngine;

namespace MazeBiters.NativeStudy {
 // Campaign composition layered over the original native corridor fabric.
 // The original Generate method remains independently available for diagnostics;
 // families bias composition and complete motifs, rather than select a stencil.
 public static class HybridMazeStudy {
  public static readonly string[] Families={"woven","crystal","diagonal","detours"};
  public static readonly string[] FamilyNames={"Woven passages","Crystal garden","Diagonal braids","Offset cloisters"};
  static readonly ConditionalWeakTable<SessionLevel,HybridMazeReport> reports=new ConditionalWeakTable<SessionLevel,HybridMazeReport>();
  public static string FamilyForLevel(uint seed,int level){
   string previous=null;string[] bag=null;int current=Math.Max(0,level-1)/Families.Length;
   for(int cycle=0;cycle<=current;cycle++){bag=(string[])Families.Clone();var rng=NativeMazeGenerator.Rng(seed^unchecked((uint)(cycle+1)*0x9E3779B1u)^0xA341316Cu);for(int i=bag.Length-1;i>0;i--){int j=(int)Math.Floor(rng()*(i+1));string item=bag[i];bag[i]=bag[j];bag[j]=item;}if(bag[0]==previous){string item=bag[0];bag[0]=bag[1];bag[1]=item;}previous=bag[bag.Length-1];}
   return bag[Math.Max(0,level-1)%Families.Length];
  }
  public static SessionLevel Generate(uint seed,int level,double difficulty,string family="automatic"){
   if(family==null||family=="automatic")family=FamilyForLevel(seed,level);
   if(!Families.Contains(family))throw new ArgumentException("Unknown hybrid family: "+family);
   var generator=new NativeMazeGenerator(seed,difficulty);var result=generator.BuildHybrid(level,family,out var report);reports.Add(result,report);return result;
  }
  public static HybridMazeReport Report(SessionLevel level)=>level!=null&&reports.TryGetValue(level,out var report)?report:null;
  internal static void RecordFallback(SessionLevel level,uint seed,double difficulty,string family,string reason){
   reports.Add(level,new HybridMazeReport{seed=seed,level=level.level,difficulty=difficulty,family=family,familyName=FamilyNames[Array.IndexOf(Families,family)],symmetry="native fallback",fallback=true,passed=true,source="Safe native fallback after composition policy rejection",checks=new[]{reason,"Native start-access repair retained; intended family retained for level naming"}});
  }
 }
 [Serializable] public sealed class HybridDiagonalRoute {public Vector2Int[] floor,border;public Vector2Int first,second;}
 [Serializable] public sealed class HybridMazeReport {
  public string family,familyName,symmetry,source="Original native corridor growth with symmetric thematic feature rules";
  public uint seed;public double difficulty;public int level,growthStage,attempt,floorCells,openTwoByTwo,openThreeByThree,maxSolidRectangle,deepWallCells,deadEnds,pointCells,startRepairOpenings,infillOpenings,diagonalRejected,detourClosures,detourWallCells,detourAddedDistance;
  public bool passed,fallback;
  public List<HybridDiagonalRoute> diagonalRoutes=new List<HybridDiagonalRoute>();
  public string[] checks;
 }
 public sealed partial class NativeMazeGenerator {
  readonly HashSet<Vector2Int> hybridFixedWalls=new HashSet<Vector2Int>(),hybridFixedFloor=new HashSet<Vector2Int>();
  readonly List<HybridDiagonalRoute> hybridRoutes=new List<HybridDiagonalRoute>();
  string hybridFamily;int hybridTwoCap,hybridThreeCap,hybridInfill,hybridGrowth;
  static uint HybridHash(string text){unchecked{uint h=2166136261;foreach(char c in text){h^=c;h*=16777619;}return h;}}
  int HybridRooms(int size){int n=0;for(int y=1;y<=H-1-size;y++)for(int x=1;x<=W-1-size;x++){bool clear=true;for(int yy=0;yy<size&&clear;yy++)for(int xx=0;xx<size;xx++)if(At(x+xx,y+yy)!='.'){clear=false;break;}if(clear)n++;}return n;}
  int HybridDeadEnds(){int n=0;for(int y=1;y<H-1;y++)for(int x=1;x<W-1;x++)if(At(x,y)=='.'&&D.Count(d=>At(P(x,y)+d)=='.')<=1)n++;return n;}
  int HybridOrbitablePoints(){int n=0;for(int y=1;y<H-1;y++)for(int x=1;x<W-1;x++)if(At(x,y)=='#'&&Ring(P(x,y)).All(p=>p==P(x,y)||At(p)=='.'))n++;return n;}
  int HybridSolidRectangle(){int best=0;var heights=new int[W];for(int y=1;y<H-1;y++){for(int x=1;x<W-1;x++)heights[x]=At(x,y)=='#'?heights[x]+1:0;for(int x=1;x<W-1;x++){int min=H;for(int right=x;right<W-1;right++){min=Math.Min(min,heights[right]);if(min==0)break;best=Math.Max(best,min*(right-x+1));}}}return best;}
  int HybridDeepWalls(){int n=0;for(int y=2;y<H-2;y++)for(int x=2;x<W-2;x++)if(At(x,y)=='#'&&D.All(d=>At(P(x,y)+d)=='#')&&D.All(d=>At(P(x,y)+P(d.x*2,d.y*2))=='#'))n++;return n;}
  bool HybridSymmetric(){for(int y=1;y<H-1;y++)for(int x=1;x<W-1;x++)if(Copies(x,y).Any(p=>At(p)!=At(x,y)))return false;return true;}
  IEnumerable<Vector2Int[]> HybridTransforms(IEnumerable<Vector2Int> input){
   var source=input.ToArray();yield return source;
   if(style=="rotational")yield return source.Select(p=>Mirror(p.x,p.y)).ToArray();
   else if(style=="left-right")yield return source.Select(p=>P(W-1-p.x,p.y)).ToArray();
   else if(style=="four-way"){
    yield return source.Select(p=>P(W-1-p.x,p.y)).ToArray();yield return source.Select(p=>P(p.x,H-1-p.y)).ToArray();yield return source.Select(p=>Mirror(p.x,p.y)).ToArray();
   }
  }
  bool HybridExternalRoute(HybridDiagonalRoute route){
   if(At(route.first)!='.'||At(route.second)!='.'||route.floor.Any(p=>At(p)!='.'))return false;
   var blocked=new HashSet<Vector2Int>(route.floor.Where(p=>p!=route.first&&p!=route.second));
   var seen=new HashSet<Vector2Int>{route.first};var queue=new Queue<Vector2Int>();queue.Enqueue(route.first);
   while(queue.Count>0){var at=queue.Dequeue();if(at==route.second)return true;foreach(var d in D){var next=at+d;if(At(next)=='.'&&!blocked.Contains(next)&&seen.Add(next))queue.Enqueue(next);}}return false;
  }
  bool HybridAllRoutes()=>hybridRoutes.All(HybridExternalRoute);
  bool HybridAccept(bool rooms=true)=>Connected()&&HybridSymmetric()&&(!rooms||HybridRooms(2)<=hybridTwoCap&&HybridRooms(3)<=hybridThreeCap)&&HybridAllRoutes();
  bool HybridChange(Action change,bool rooms=true){var old=Snapshot();change();if(HybridAccept(rooms))return true;g=old;return false;}
  void HybridHarmonizeBase(){var open=new List<Vector2Int>();for(int y=1;y<H-1;y++)for(int x=1;x<W-1;x++)if(At(x,y)=='.')open.AddRange(Copies(x,y));foreach(var p in open)g[p.y][p.x]='.';}

  public SessionLevel BuildHybrid(int level,string family,out HybridMazeReport report){
   stage=Math.Max(1,level);adjusted=1+(stage-1)*Difficulty;absurd=Absurdity(adjusted);edge=Edge(adjusted);ultra=Ultra(adjusted);hybridFamily=family;hybridGrowth=stage<=5?stage:Math.Max(6,Round(adjusted));
   report=new HybridMazeReport{seed=Seed,level=stage,difficulty=Difficulty,growthStage=hybridGrowth,family=family,familyName=HybridMazeStudy.FamilyNames[Array.IndexOf(HybridMazeStudy.Families,family)]};
   // Late complexity retains a stronger visible composition; random local
   // corridor growth changes with every seed and level, not just two variants.
   style=family=="crystal"||family=="detours"||hybridGrowth>=35&&family=="woven"?"four-way":stage<=5?"left-right":"rotational";
   report.symmetry=style;
   hybridTwoCap=stage<=5?0:hybridGrowth<=12?8:hybridGrowth<=25?26:hybridGrowth<=45?62:hybridGrowth<=70?110:160;
   hybridThreeCap=stage<=5?0:hybridGrowth<=12?0:hybridGrowth<=25?2:hybridGrowth<=45?10:hybridGrowth<=70?24:45;
   bool success=false;
   for(int attempt=0;attempt<8&&!success;attempt++){
    report.attempt=attempt;Patterns=new MazePatterns{level=stage};diagonal.Clear();points.Clear();orthogonal.Clear();reserved.Clear();safe.Clear();hybridFixedWalls.Clear();hybridFixedFloor.Clear();hybridRoutes.Clear();hybridInfill=0;
    random=Rng(LevelSeed(stage,91) ^ HybridHash(family) ^ (uint)(attempt*0x1F123BB5));styleOffset=Integer(0,4);g=Enumerable.Range(0,H).Select(_=>Enumerable.Repeat('#',W).ToArray()).ToArray();
    BaseMaze();HybridHarmonizeBase();
    // Original early feature language, but reserve the very first phase for
    // narrow passages. Every later mutation is tested as a complete orbit.
    if(stage>5){var early=Snapshot();EarlyFeatures();HybridHarmonizeBase();if(!HybridAccept()){g=early;points.Clear();orthogonal.Clear();reserved.Clear();Patterns=new MazePatterns{level=stage};}}
    HybridShortcuts();
    if(stage>5&&hybridGrowth>=8&&family=="diagonal")HybridDiagonalBraids(report);
    if(stage>5&&hybridGrowth>=10&&family!="diagonal"&&((stage+(int)(Seed%3))%3==0))HybridDiagonalBraids(report);
    HybridPointGroups();HybridCourts();
    HybridFillSolidMass();
    StartAccessOpenedWalls=0;try{EnsureStartAccess();}catch(InvalidOperationException){continue;}
    HybridCourtDetours(report);
    // Start repair is allowed to open narrow escape routes, while the
    // final bound includes any small widening it required for safe starts.
    success=HybridAccept()&&HybridSolidRectangle()<=64&&HybridDeepWalls()<=24&&!(family=="diagonal"&&stage>5&&hybridGrowth>=8&&hybridRoutes.Count==0)&&!(family=="crystal"&&hybridGrowth>=20&&HybridOrbitablePoints()<4);
   }
   if(!success)throw new InvalidOperationException("Hybrid maze could not satisfy its geometry policy: "+family+" level "+stage+" seed "+Seed);
   var geometry=g.Select(row=>new string(row)).ToArray();report.floorCells=geometry.Sum(row=>row.Count(c=>c=='.'));report.openTwoByTwo=HybridRooms(2);report.openThreeByThree=HybridRooms(3);report.maxSolidRectangle=HybridSolidRectangle();report.deepWallCells=HybridDeepWalls();report.deadEnds=HybridDeadEnds();report.pointCells=HybridOrbitablePoints();report.startRepairOpenings=StartAccessOpenedWalls;report.infillOpenings=hybridInfill;report.diagonalRoutes=hybridRoutes.ToList();report.passed=true;
   report.checks=new[]{"Original native corridor growth", "Exact "+style+" composition", "Connected floor and safe native starting approaches", "No large unused solid centre", "All accepted diagonal routes have a separate external return path"};
   Metrics=Rate(geometry,Patterns);Target=45+Math.Min(1,(adjusted-1)/9)*75+Clamp((adjusted-10)/20)*50+Clamp((adjusted-30)/70)*120;
   return new SessionLevel{level=stage,geometry=geometry,theme=Themes[ThemeIndex(stage)],starts=Starts(),paletteSeed=Seed};
  }
  void HybridShortcuts(){
   var candidates=new List<Vector2Int>();for(int y=2;y<H-2;y++)for(int x=2;x<W-2;x++)if(At(x,y)=='#'&&!Near(P(x,y),3)&&(At(x-1,y)=='.'&&At(x+1,y)=='.'||At(x,y-1)=='.'&&At(x,y+1)=='.'))candidates.Add(P(x,y));Shuffle(candidates);
   int remaining=stage<=5?1+stage/2:3+Math.Min(9,hybridGrowth/8);
   foreach(var p in candidates){if(remaining<=0)break;if(HybridChange(()=>{foreach(var q in Copies(p.x,p.y))g[q.y][q.x]='.';}))remaining--;}
  }
  void HybridPointGroups(){
   if(stage<=5||hybridGrowth<10)return;int runs=hybridFamily=="crystal"?1+Math.Min(5,hybridGrowth/16):hybridGrowth<24?0:Math.Min(3,hybridGrowth/24);
   for(int run=0;run<runs;run++)for(int attempt=0;attempt<45;attempt++){
    bool diag=hybridGrowth>=25&&random()<(hybridFamily=="crystal"?.45:.2);bool horizontal=random()<.5;int count=hybridGrowth<25?1:2+Integer(0,hybridGrowth>60?2:1);
    int x=Integer(5,14),y=Integer(5,10);var row=Enumerable.Range(0,count).Select(i=>P(x+(horizontal||diag?i*2:0),y+(!horizontal||diag?i*2:0))).ToArray();
    var centres=HybridTransforms(row).SelectMany(a=>a).Distinct().ToArray();var rings=centres.SelectMany(Ring).Distinct().ToArray();
    if(rings.Any(p=>!Inside(p)||Near(p,4)||hybridFixedWalls.Contains(p)||hybridFixedFloor.Contains(p)))continue;
    if(centres.Any(p=>centres.Any(other=>p!=other&&Math.Abs(p.x-other.x)<=1&&Math.Abs(p.y-other.y)<=1)))continue;
    if(!HybridChange(()=>{foreach(var p in rings)g[p.y][p.x]='.';foreach(var p in centres)g[p.y][p.x]='#';}))continue;
    foreach(var p in centres){points.Add(p);hybridFixedWalls.Add(p);}foreach(var p in rings)if(!centres.Contains(p))hybridFixedFloor.Add(p);
    Patterns.orthogonalPointRuns++;break;
   }
  }
  void HybridCourts(){
   if(stage<=5||hybridGrowth<16)return;int count=hybridFamily=="detours"?2:hybridFamily=="woven"?1:0;
   for(int run=0;run<count;run++)for(int attempt=0;attempt<35;attempt++){
    int x=Integer(5,12),y=Integer(5,9),width=3+Integer(0,2),height=3+Integer(0,2);var border=new List<Vector2Int>();
    for(int xx=x;xx<=x+width;xx++){border.Add(P(xx,y));border.Add(P(xx,y+height));}for(int yy=y+1;yy<y+height;yy++){border.Add(P(x,yy));border.Add(P(x+width,yy));}
    var open=HybridTransforms(border).SelectMany(a=>a).Distinct().ToArray();if(open.Any(p=>!Inside(p)||Near(p,4)||hybridFixedWalls.Contains(p)))continue;
    if(HybridChange(()=>{foreach(var p in open)g[p.y][p.x]='.';})){foreach(var p in open)hybridFixedFloor.Add(p);break;}
   }
  }
  // Remove selected redundant links between junctions, never just cut a tunnel
  // into two blind stubs. A complete symmetry orbit is tested against the final
  // native start graph and every protected motif. Original local growth still
  // supplies the layout; there is no fixed courtyard stencil or wall template.
  void HybridCourtDetours(HybridMazeReport report){
   report.detourClosures=report.detourWallCells=report.detourAddedDistance=0;
   if(hybridFamily!="detours"||stage<=5||hybridGrowth<18)return;
   int wanted=hybridGrowth<35?1:hybridGrowth<55?2:hybridGrowth<80?3:4;
   int minimumGain=hybridGrowth<35?8:hybridGrowth<60?10:14;
   int targetGain=hybridGrowth<35?16:hybridGrowth<60?24:34;
   int budget=hybridGrowth<35?16:hybridGrowth<60?28:44;
   int Degree(Vector2Int p)=>D.Count(d=>At(p+d)=='.');
   int RouteDistance(Vector2Int from,Vector2Int to){
    var distances=Enumerable.Repeat(-1,W*H).ToArray();var queue=new Vector2Int[W*H];int read=0,count=1;queue[0]=from;distances[from.y*W+from.x]=0;
    while(read<count){var at=queue[read++];int steps=distances[at.y*W+at.x];if(at==to)return steps;foreach(var d in D){var next=at+d;if(At(next)!='.')continue;int key=next.y*W+next.x;if(distances[key]>=0)continue;distances[key]=steps+1;queue[count++]=next;}}return -1;
   }
   for(int run=0;run<wanted;run++){
    Vector2Int[] best=null;int bestScore=int.MinValue,bestGain=0;uint bestTie=uint.MaxValue;
    var seen=new HashSet<string>();
    void Consider(Vector2Int from,Vector2Int to,Vector2Int[] interior,int directDistance){
      var closed=HybridTransforms(interior).SelectMany(a=>a).Distinct().OrderBy(p=>p.y*W+p.x).ToArray();
      if(report.detourWallCells+closed.Length>budget||closed.Any(p=>At(p)!='.'||Near(p,5)||hybridFixedFloor.Contains(p)||hybridFixedWalls.Contains(p)))return;
      string key=string.Join(",",closed.Select(p=>p.y*W+p.x));int fromId=from.y*W+from.x,toId=to.y*W+to.x;if(!seen.Add(key+"@"+Math.Min(fromId,toId)+"/"+Math.Max(fromId,toId)))return;
      var ends=HybridTransforms(new[]{from,to}).ToArray();if(ends.Any(pair=>pair.Any(closed.Contains)))return;
      foreach(var p in closed)g[p.y][p.x]='#';
      // Every surviving neighbour keeps at least two exits: no new dead end.
      bool valid=closed.SelectMany(p=>D.Select(d=>p+d)).Where(p=>At(p)=='.').All(p=>Degree(p)>=2);
      int gain=valid?RouteDistance(from,to)-directDistance:-1;
      if(gain>=minimumGain)valid=HybridAccept()&&HybridSolidRectangle()<=64&&HybridDeepWalls()<=24&&Starts().All(s=>FindStartChoice(P(s.x,s.y))>=0);
      else valid=false;
      foreach(var p in closed)g[p.y][p.x]='.';
      if(!valid)return;
      // Prefer a visible, bounded detour over one extreme forced trip. Seeded
      // tie-breaking and the original fabric keep different maps different.
      int score=Math.Min(gain,targetGain)*100-Math.Max(0,gain-targetGain)*3-closed.Length*7;
      uint tie=HybridHash(Seed+"/"+stage+"/"+run+"/"+key);
      if(score>bestScore||score==bestScore&&tie<bestTie){best=closed;bestScore=score;bestTie=tie;bestGain=gain;}
    }
    for(int y=2;y<H-2;y++)for(int x=2;x<W-2;x++){
     var first=P(x,y);if(At(first)!='.'||Degree(first)<3)continue;
     // Later openness also permits a compact divider inside a junction. Its
     // opposite sides must acquire a real detour, not a two-step sidestep.
     foreach(var axis in new[]{P(1,0),P(0,1)})if(At(first+axis)=='.'&&At(first-axis)=='.')Consider(first-axis,first+axis,new[]{first},2);
     foreach(var direction in D){
      var route=new List<Vector2Int>();var previous=first;var cell=first+direction;
      while(Inside(cell)&&At(cell)=='.'&&Degree(cell)==2&&route.Count<=6){
       route.Add(cell);var next=D.Select(d=>cell+d).First(p=>p!=previous&&At(p)=='.');previous=cell;cell=next;
      }
      if(route.Count==0||route.Count>6||cell==first||At(cell)!='.'||Degree(cell)<3)continue;
      Consider(first,cell,route.ToArray(),route.Count+1);
     }
    }
    if(best==null)break;
    foreach(var p in best){g[p.y][p.x]='#';hybridFixedWalls.Add(p);}
    report.detourClosures++;report.detourWallCells+=best.Length;report.detourAddedDistance+=bestGain;
   }
  }
  void HybridDiagonalBraids(HybridMazeReport report){
   int wanted=hybridFamily=="diagonal"?hybridGrowth<25?1:2:1;
   for(int run=0;run<wanted;run++)for(int attempt=0;attempt<150;attempt++){
    int length=hybridGrowth<25?6+Integer(0,2):8+Integer(0,3),span=2+Integer(0,1),rise=random()<.5?-1:1;
    int sx=Integer(5,Math.Max(5,17-length)),sy=Integer(5,10);var route=new List<Vector2Int>();var upper=new List<Vector2Int>();var lower=new List<Vector2Int>();int yy=sy;
    for(int step=0;step<length;step++){int next=yy;if(step>0&&step%span==0)next+=rise;route.Add(P(sx+step,yy));if(next!=yy)route.Add(P(sx+step,next));upper.Add(P(sx+step,Math.Min(yy,next)-1));lower.Add(P(sx+step,Math.Max(yy,next)+1));yy=next;}
    // Fill the outside stair corners as full bordering wall motifs.
    int upperCount=upper.Count,lowerCount=lower.Count;
    for(int i=1;i<upperCount;i++)if(upper[i].y!=upper[i-1].y)upper.Add(upper[i].y>upper[i-1].y?P(upper[i].x,upper[i-1].y):P(upper[i-1].x,upper[i].y));
    for(int i=1;i<lowerCount;i++)if(lower[i].y!=lower[i-1].y)lower.Add(lower[i].y>lower[i-1].y?P(lower[i-1].x,lower[i].y):P(lower[i].x,lower[i-1].y));
    var first=P(sx-2,sy);var second=P(sx+length+1,yy);route.Insert(0,P(sx-1,sy));route.Insert(0,first);route.Add(P(sx+length,yy));route.Add(second);
    var borders=upper.Concat(lower).Distinct().ToArray();var transformedRoutes=HybridTransforms(route).ToArray();var transformedBorders=HybridTransforms(borders).ToArray();
    var floors=transformedRoutes.SelectMany(a=>a).Distinct().ToArray();var walls=transformedBorders.SelectMany(a=>a).Distinct().ToArray();
    if(floors.Any(p=>!Inside(p)||Near(p,4)||hybridFixedWalls.Contains(p))||walls.Any(p=>!Inside(p)||Near(p,4)||hybridFixedFloor.Contains(p))||floors.Intersect(walls).Any())continue;
    if(transformedRoutes.Any(a=>At(a[0])!='.'||At(a[a.Length-1])!='.'))continue;
    var added=transformedRoutes.Select((a,i)=>new HybridDiagonalRoute{floor=a.Distinct().ToArray(),border=transformedBorders[i].Distinct().ToArray(),first=a[0],second=a[a.Length-1]}).ToArray();
    var old=Snapshot();foreach(var p in floors)g[p.y][p.x]='.';foreach(var p in walls)g[p.y][p.x]='#';
    if(!HybridAccept()||added.Any(a=>!HybridExternalRoute(a))){g=old;report.diagonalRejected++;continue;}
    foreach(var p in floors)hybridFixedFloor.Add(p);foreach(var p in walls){hybridFixedWalls.Add(p);diagonal.Add(p);}hybridRoutes.AddRange(added);Patterns.diagonalCorridors+=added.Length;break;
   }
  }
  void HybridFillSolidMass(){
   // Every added run joins existing floor at BOTH ends. It is a new route,
   // never an isolated cutout, arena clearing or a blind decorative diagonal.
   for(int iteration=0;iteration<45;iteration++){
    int oldRect=HybridSolidRectangle(),oldDeep=HybridDeepWalls();if(oldRect<=30&&oldDeep<=6)break;
    var candidates=new List<(Vector2Int[] cells,int rank,uint tie)>();
    for(int y=2;y<H-2;y++)for(int x=2;x<W-2;x++)foreach(var d in new[]{P(1,0),P(0,1)}){
     if(At(x,y)!='#'||At(P(x,y)-d)!='.')continue;var row=new List<Vector2Int>();var p=P(x,y);
     while(Inside(p)&&At(p)=='#'&&row.Count<23){row.Add(p);p+=d;}if(At(p)!='.'||row.Count<1||row.Any(hybridFixedWalls.Contains)||row.Any(q=>Near(q,2)))continue;
     var all=HybridTransforms(row).SelectMany(a=>a).Distinct().ToArray();if(all.Any(hybridFixedWalls.Contains))continue;
     int rank=row.Count*5+(hybridFamily=="woven"&&d.y==1?8:0)+(hybridFamily=="detours"&&d.x==1?6:0);candidates.Add((all,rank,HybridHash(x+"/"+y+"/"+iteration+"/"+Seed)));
    }
    bool accepted=false;foreach(var candidate in candidates.OrderByDescending(c=>c.rank).ThenBy(c=>c.tie)){
     var old=Snapshot();int newCells=candidate.cells.Count(p=>At(p)=='#');foreach(var p in candidate.cells)g[p.y][p.x]='.';
     if(HybridAccept()&&(HybridSolidRectangle()<oldRect||HybridDeepWalls()<oldDeep)){hybridInfill+=newCells;accepted=true;break;}g=old;
    }if(!accepted)break;
   }
  }
 }
}

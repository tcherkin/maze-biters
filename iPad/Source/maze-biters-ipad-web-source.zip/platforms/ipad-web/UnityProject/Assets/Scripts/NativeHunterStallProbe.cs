using System;
using System.Collections;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using UnityEngine;
namespace MazeBiters.NativeStudy {
 public sealed partial class NativeGameplayStudy {
  bool hunterStallProbe;
  [Serializable] sealed class StallFrame {
   public string scenario,mode,events;
   public int index,palette,score,x,y,dx,dy,hunters,snakes,gc0;
   public bool focused,dead,waiting,transition;
   public double clock,frameGapMs,cpuMs,tickMs,renderMs,visualX,visualY,stepAge,stepDuration;
   public long allocatedBytes;
   public NativeStallTrace.Span[] stages;
  }
  [Serializable] sealed class StallContact {public string mode;public int palette,direction,count;public bool passed;public double nextMoveMs;}
  [Serializable] sealed class StallReport {
   public PreparationSample[] preparation;public string quality,note,graphics;public bool passed;public int audioAccepted,sampleRate;public double audioEnergy;
   public StallContact[] contacts;public StallFrame[] frames;
  }
  readonly List<StallFrame> stallFrames=new List<StallFrame>(12000);
  readonly List<string> stallEvents=new List<string>(32);
  void TraceWorldEvent(NativeWorldEvent e){
   if(NativeStallTrace.Enabled)stallEvents.Add(e.Kind);
   long stamp=NativeStallTrace.Stamp();OnEvent(e);
   if(NativeStallTrace.Enabled)NativeStallTrace.Add("event:"+e.Kind+(e.Kind=="sound"?":"+e.Sound:""),stamp);
  }
  StallFrame MeasureStallFrame(string scene,string mode,int index,long previous){
   var f=new StallFrame{scenario=scene,mode=mode,index=index,focused=Application.isFocused,frameGapMs=previous==0?0:NativeStallTrace.Ms(previous)};
   stallEvents.Clear();NativeStallTrace.Begin();long start=Stopwatch.GetTimestamp(),bytes=GC.GetAllocatedBytesForCurrentThread();int gc=GC.CollectionCount(0);
   // Fixed simulation increments isolate workload from OS/background pacing.
   // frameGap still records the real player-loop interval independently.
   time+=1000.0/120;realClock+=1000.0/120;world.RealTime=realClock;
   long stamp=NativeStallTrace.Stamp();sessionAudio?.Sync(world,false);NativeStallTrace.Add("audio-sync",stamp);
   stamp=NativeStallTrace.Stamp();world.Tick(time);world.UpdateTilt(time);f.tickMs=NativeStallTrace.Ms(stamp);
   stamp=NativeStallTrace.Stamp();Render();f.renderMs=NativeStallTrace.Ms(stamp);
   f.cpuMs=NativeStallTrace.Ms(start);f.allocatedBytes=GC.GetAllocatedBytesForCurrentThread()-bytes;f.gc0=GC.CollectionCount(0)-gc;
   f.stages=NativeStallTrace.End();f.events=string.Join(",",stallEvents);
   var p=world.Player;var pos=p.Visual(time);f.clock=time;f.x=p.Cell.x;f.y=p.Cell.y;f.dx=p.Dir.x;f.dy=p.Dir.y;f.visualX=pos.x;f.visualY=pos.y;f.stepAge=time-p.MoveStarted;f.stepDuration=p.MoveDuration;f.palette=p.Palette;f.score=p.Score;f.hunters=world.Hunters.Count;f.snakes=world.Snakes.Count;f.dead=p.Dead;f.waiting=p.Waiting;f.transition=world.Transition;
   if(consistencyProbe||generationProbe)RecordConsistency(f);else stallFrames.Add(f);return f;
  }
  void StallSession(){
   time=world.Time=realClock=world.RealTime=2000;world.SessionEnabled=true;
   if(sessionAudio==null){sessionAudio=new GameObject("Stall diagnostic audio").AddComponent<NativeSessionAudio>();sessionAudio.Initialize(true,prepare:!coldLogicControl);}
   sessionAudio.ResetBus();sessionAudio.SetTrack(world.ReserveMusic(1),realClock);
   world.Event=TraceWorldEvent;world.Player.LastMove=time;world.Player.Waiting=false;
  }
  // Only the diagnostic pilot chooses input. The original world Tick/AI,
  // collision, animation, lighting, sound mixing and disposal all still run.
  void StallPilot(Dictionary<Vector2Int,int> visited,bool avoidCreatures){
   var p=world.Player;
   if(time+1000.0/120-p.LastMove<=world.PlayerDelay)return;
   var open=NativeGameplayWorld.Dirs.Where(d=>world.Floor(p.Cell+d)&&!world.SolidEgg(p.Cell+d)&&
    (!avoidCreatures||!world.Occupied(p.Cell+d)&&!world.HunterAt(p.Cell+d)&&!world.ScorpionAt(p.Cell+d))).ToArray();
   if(open.Length==0){p.Waiting=true;return;}
   var direction=open.OrderBy(d=>(visited.TryGetValue(p.Cell+d,out int n)?n:0)*10+(d==-p.Dir?4:0)+(d==p.Dir?0:1)).First();
   visited.TryGetValue(p.Cell+direction,out int count);visited[p.Cell+direction]=count+1;
   p.Waiting=false;p.Next=direction;
  }
  IEnumerator ProbeHunterStalls(){
   var checks=new List<StallContact>();bool passed=true;
   // First traversal vs repeat with exactly the same input/world seed. No
   // eating; no enemies in this phase. Turn-bank caches remain between passes.
   for(int pass=0;pass<2;pass++){
    Reset(9);yield return DrainProbePreparation();StallSession();world.LifecycleEnabled=true;world.ScorpionSpawnAt=double.PositiveInfinity;
    world.Player.Cell=world.Player.From=world.Player.Previous=new Vector2Int(1,1);
    var visits=new Dictionary<Vector2Int,int>();long previous=0;
    for(int frame=0;frame<1800;frame++){
     StallPilot(visits,false);long now=Stopwatch.GetTimestamp();MeasureStallFrame(pass==0?"walk-alone-first":"walk-alone-repeat","normal",frame,previous);previous=now;yield return null;
    }
    passed&=world.Player.Score==0&&!world.Player.Dead;
   }
   // All five snakes, scorpion and three independently moving hunters. Avoid
   // deliberate eating, including at AI junctions, and record any incidental
   // contacts so they cannot be mistaken for no-contact evidence.
   Reset(0);yield return DrainProbePreparation();StallSession();world.EnableLifecycle();world.Scorpion.NextFruit=time+100000;world.Scorpion.NextEgg=time+100000;
   world.Player.Cell=world.Player.From=world.Player.Previous=new Vector2Int(2,1);world.Player.ShieldUntil=time+100000;
   var crowdVisits=new Dictionary<Vector2Int,int>();long crowdPrevious=0;
   for(int frame=0;frame<2400;frame++){
    StallPilot(crowdVisits,true);long now=Stopwatch.GetTimestamp();MeasureStallFrame("walk-live-crowd","spawn",frame,crowdPrevious);crowdPrevious=now;yield return null;
   }
   // 3 palettes x 4 directions x shield+power/ramp/stable/expiry = 48 full-Tick
   // encounters. Target is half-way through its ORIGINAL 95ms movement and
   // turn at contact; it is not forcibly eaten through a direct EatHunter call.
   // Busy cases also enqueue a bounded synthetic existing SFX overlap.
   var modes=new[]{"power-with-shield","power-ramp","power-stable","power-ending"};
   var locations=new[]{new Vector2Int(4,1),new Vector2Int(4,1),new Vector2Int(1,8),new Vector2Int(1,8)};
   var directions=new[]{Vector2Int.right,Vector2Int.left,Vector2Int.up,Vector2Int.down};
   for(int mode=0;mode<4;mode++){
    Reset(0);yield return DrainProbePreparation();StallSession();world.LifecycleEnabled=false;
    // Keep the full rendering/AI load, but clear the scripted contact lanes of
    // incidental snakes so assertions concern enemy hunters alone.
    foreach(var s in world.Snakes.ToArray())if(s.Body.Any(c=>c.y==1||c.x==1)){world.Snakes.Remove(s);snakes[s.Id].Dispose();snakes.Remove(s.Id);}
    foreach(var h in world.Hunters.ToArray()){actors[h.Id].Dispose();actors.Remove(h.Id);}world.Hunters.Clear();
    for(int test=0;test<12;test++){
     int palette=test/4,dir=test%4;var d=directions[dir];var cell=locations[dir];var p=world.Player;
     world.ClearKeys();p.Cell=p.From=p.Previous=cell-d;p.Dir=dir<2?Vector2Int.up:Vector2Int.right;p.Next=d;p.Waiting=true;p.Pointer=null;p.Ricochet=null;p.Dead=false;p.BiteAt=p.BiteEnd=-1e6;p.Score=0;p.ExactScore=0;p.NextLifeScore=5000;p.ShieldUntil=0;p.PowerUntil=0;
     world.Time=time;if(mode==0)world.ActivateShield();world.ActivatePower();if(mode==2){p.RampAt=time-1500;p.PowerUntil=time+5500;}if(mode==3){p.RampAt=time-6500;p.PowerUntil=time+500;}
     int id=500+test;var enemy=new NativeHunter{Id=id,Palette=palette,Cell=cell,From=cell+d,Dir=-d,LastMove=time+100000,MoveStarted=time,MoveDuration=95};
     world.Hunters.Add(enemy);var visual=AddActor(enemy,false,palette);
     // Stabilize creation outside the measured window. Moving presentation
     // starts at the contact window; AI for all other creatures remains active.
     for(int i=0;i<6;i++){Render();yield return null;}
     enemy.LastMove=time-40;enemy.MoveStarted=time-40;visual.turn.Request(Bank(dir<2?Vector2Int.up:Vector2Int.right),Bank(-d),time-40);
     p.Waiting=false;p.LastMove=time-world.PlayerDelay;
     var check=new StallContact{mode=modes[mode],palette=palette,direction=dir};checks.Add(check);
     var origin=p.Cell;double contactAt=time+1000.0/120;long previous=0;bool next=false;
     if(test>=6){for(int voice=0;voice<16;voice++)sessionAudio.Play("Tie1",new Vector2Int(voice+1,3),false,realClock);}
     for(int frame=0;frame<36;frame++){
      long now=Stopwatch.GetTimestamp();var sample=MeasureStallFrame("hunter-contact-"+test,modes[mode],frame,previous);previous=now;
      if(frame==0)check.passed=!world.Hunters.Contains(enemy)&&p.Cell==cell&&p.Score==200&&!p.Dead&&!p.Waiting&&p.Ricochet==null;
      if(sample.events.Contains("hunterBite"))check.count++;
      if(!next&&p.Cell!=cell&&p.Cell!=origin){check.nextMoveMs=time-contactAt;next=true;}
      yield return null;
     }
     check.passed&=next&&check.count==1;passed&=check.passed;
     // Repositioning between fixtures is excluded from frame intervals.
    }
   }
   NativeStallTrace.Enabled=false;
   var result=new StallReport{preparation=preparationSamples.ToArray(),passed=passed,quality=quality,graphics=SystemInfo.graphicsDeviceName,sampleRate=AudioSettings.outputSampleRate,audioAccepted=sessionAudio.Accepted,audioEnergy=sessionAudio.OutputEnergy,contacts=checks.ToArray(),frames=stallFrames.ToArray(),
    note="Diagnostic only. Original Tick, visuals and effects. Fixed 120Hz simulation, real CPU elapsed and player-loop gaps recorded separately. No screenshot readback or per-frame file writes. First frame after setup has gap=0 and is not steady-state. Stage timings nest. Live SFX callback/music run muted; inspect log for output-device fallback. Background/OS scheduling and GPU execution are not inferred from CPU submission timings. Crowded pilot avoids deliberate eating; events identify incidental contacts. Extra 16 overlapping SFX in second half of each contact mode is synthetic stress."};
   Directory.CreateDirectory(Path.GetDirectoryName(report));File.WriteAllText(report,JsonUtility.ToJson(result,true));Application.Quit(passed?0:2);
  }
 }
}

using System;
using System.Collections.Generic;
using System.Linq;
using UnityEngine;
namespace MazeBiters.NativeStudy {
 // Cosmetic paths from the exact painter's connectivity. Never consumes world RNG.
 internal sealed class NativeWallLightRoutes {
  sealed class Part {
   internal Vector2 A,B,C;internal float Start,Length,Radius,Angle,Sweep;
   internal Vector2 At(float u)=>Radius==0?Vector2.Lerp(A,B,u):C+new Vector2(Mathf.Cos(Angle+Sweep*u),Mathf.Sin(Angle+Sweep*u))*Radius;
  }
  sealed class Route {
   internal Part[] Parts;internal float Length;internal bool Cap;
   internal Vector2 At(float d){d=Mathf.Clamp(d,0,Length);foreach(var p in Parts)if(d<=p.Start+p.Length)return p.At(Mathf.Clamp01((d-p.Start)/p.Length));return Parts[Parts.Length-1].At(1);}
  }
  internal const int StreamCount=16;
  readonly Route[] routes;readonly Vector4[] sources=new Vector4[StreamCount*3];
  internal readonly Vector4[] SourceCells=new Vector4[StreamCount*3],StreamBounds=new Vector4[StreamCount];
  readonly int[] selectedRoutes=new int[StreamCount];
  int evaluatedStreams;
  double evaluatedSeconds=double.NaN;
  internal long Evaluations {get;private set;}
  readonly int[,] masks;
  static readonly Vector2Int[] D={Vector2Int.up,Vector2Int.right,Vector2Int.down,Vector2Int.left};
  // Painter Y grows down. Use explicit cells, not Unity's up convention.
  static readonly Vector2Int[] Cells={new Vector2Int(0,-1),new Vector2Int(1,0),new Vector2Int(0,1),new Vector2Int(-1,0)};
  internal int Count=>routes.Length;
  internal NativeWallLightRoutes(int[,] connectivity){
   masks=connectivity;int w=masks.GetLength(0),h=masks.GetLength(1);
   var nodes=new Dictionary<int,List<int>>();
   for(int y=0;y<h;y++)for(int x=0;x<w;x++)if(masks[x,y]>=0){
    int id=x+y*w;var neighbours=new List<int>();
    for(int d=0;d<4;d++)if((masks[x,y]&(1<<d))!=0){int nx=x+Cells[d].x,ny=y+Cells[d].y;
     if(nx<0||ny<0||nx>=w||ny>=h||(masks[nx,ny]&(1<<((d+2)%4)))==0)throw new InvalidOperationException("Broken wall connectivity");neighbours.Add(nx+ny*w);
    }nodes[id]=neighbours;
   }
   var used=new HashSet<long>();var paths=new List<List<int>>();
   long Edge(int a,int b)=>((long)Math.Min(a,b)<<32)|(uint)Math.Max(a,b);
   foreach(int start in nodes.Keys.OrderBy(n=>nodes[n].Count==2?1:0).ThenBy(n=>n))foreach(int first in nodes[start]){
    if(used.Contains(Edge(start,first)))continue;
    var path=new List<int>{start};int old=start,next=first;
    for(int guard=0;guard<2048;guard++){
     if(!used.Add(Edge(old,next)))break;path.Add(next);
     if(nodes[next].Count!=2||next==start)break;
     int following=nodes[next][0]==old?nodes[next][1]:nodes[next][0];old=next;next=following;
    }paths.Add(path);
   }
   var result=new List<Route>();
   foreach(var path in paths){
    if(path.Count<4)continue;
    // Outer frame may breathe with ambient light, but the small travelling
    // accents belong to interior architecture, not a bright screen border.
    int inner=path.Count(id=>id%w>0&&id%w<w-1&&id/w>0&&id/w<h-1);
    if(inner<path.Count*.5f)continue;
    for(int begin=0;begin<path.Count-3;begin+=19){
     int end=Math.Min(path.Count-1,begin+20);var points=new List<Vector2>();
     for(int i=begin;i<=end;i++)points.Add(new Vector2((path[i]%w+.5f)*16,(path[i]/w+.5f)*16));
     // Collapse straight junction-free cells before rounding their bends.
     for(int i=points.Count-2;i>0;i--)if((points[i]-points[i-1]).normalized==(points[i+1]-points[i]).normalized)points.RemoveAt(i);
     result.Add(Build(points,nodes[path[end]].Count==1));
    }
   }
   routes=result.ToArray();
#if UNITY_EDITOR || DEVELOPMENT_BUILD
   Validate();
#endif
  }
  static Route Build(List<Vector2> points,bool cap){
   var parts=new List<Part>();float total=0,radius=16*.23f;Vector2 last=points[0];
   void Line(Vector2 a,Vector2 b){float length=(b-a).magnitude;if(length<.001f)return;parts.Add(new Part{A=a,B=b,Start=total,Length=length});total+=length;}
   for(int i=1;i<points.Count-1;i++){
    var p=points[i];var incoming=(p-points[i-1]).normalized;var outgoing=(points[i+1]-p).normalized;
    if(Vector2.Dot(incoming,outgoing)>.99f){Line(last,p);last=p;continue;}
    var entry=p-incoming*radius;var exit=p+outgoing*radius;var centre=p-incoming*radius+outgoing*radius;Line(last,entry);
    var a=entry-centre;var b=exit-centre;float sweep=Mathf.Atan2(a.x*b.y-a.y*b.x,Vector2.Dot(a,b));float length=Mathf.Abs(sweep)*radius;
    parts.Add(new Part{A=entry,B=exit,C=centre,Radius=radius,Angle=Mathf.Atan2(a.y,a.x),Sweep=sweep,Start=total,Length=length});total+=length;last=exit;
   }
   Line(last,points[points.Count-1]);return new Route{Parts=parts.ToArray(),Length=total,Cap=cap};
  }
  static int Cell(Vector2 p)=>Mathf.Clamp((int)(p.x/16),0,35)+36*Mathf.Clamp((int)(p.y/16),0,24);
  internal Vector4[] Evaluate(double seconds,bool force=false,int streams=StreamCount){
   if(streams!=4&&streams!=8&&streams!=StreamCount)throw new ArgumentOutOfRangeException(nameof(streams));
   if(!force&&seconds==evaluatedSeconds&&streams==evaluatedStreams)return sources;
   evaluatedSeconds=force?double.NaN:seconds;evaluatedStreams=streams;Evaluations++;
   if(routes.Length==0)return sources;
   const double slot=12.5;
   for(int stream=0;stream<StreamCount;stream++){
    if(stream>=streams){for(int trail=0;trail<3;trail++){sources[stream*3+trail]=Vector4.zero;SourceCells[stream*3+trail]=Vector4.zero;}StreamBounds[stream]=new Vector4(1,1,-1,-1);continue;}
    // Preserve the original eight accents. The next eight fill the gaps
    // between their phases, on separate routes, without per-frame allocation.
    double offset=(stream%4)*slot/4+((stream/4)%2)*slot/8+(stream/8)*slot/16;
    double t=Math.Max(0,seconds)+offset;int cycle=(int)(t/slot);float phase=(float)(t-cycle*slot);
    int routeIndex=(cycle*5+stream*(routes.Length/4+1))%routes.Length;
    if(stream>=4&&routes.Length>=(stream<8?8:StreamCount)){
     for(int guard=0;guard<streams;guard++){bool used=false;for(int prior=0;prior<stream;prior++)if(selectedRoutes[prior]==routeIndex){used=true;break;}if(!used)break;routeIndex=(routeIndex+1)%routes.Length;}
    }
    selectedRoutes[stream]=routeIndex;var route=routes[routeIndex];
    // Full rounded cap is reached before the pearl dissolves. No teleporting
    // bright source at route changes; there is a quiet interval between runs.
    float fade=Mathf.SmoothStep(0,1,phase/.7f)*(1-Mathf.SmoothStep(0,1,(phase-10.4f)/.8f));
    float distance=route.Length*Mathf.Clamp01(phase/9.6f)+10*Mathf.SmoothStep(0,1,(phase-9.6f)/.5f);
    float cap=route.Cap?1+.10f*Mathf.Sin(Mathf.Clamp01((phase-9.5f)/.9f)*Mathf.PI):1;
    float minX=float.PositiveInfinity,minY=float.PositiveInfinity,maxX=float.NegativeInfinity,maxY=float.NegativeInfinity;
    for(int trail=0;trail<3;trail++){
     float d=distance-trail*4.2f;var p=route.At(d);int before=Cell(route.At(d-8)),after=Cell(route.At(d+8));
     sources[stream*3+trail]=new Vector4(p.x,p.y,fade*cap*(trail==0?.53f:trail==1?.39f:.18f),(before+1)+(after+1)*1024);
     if(!force){SourceCells[stream*3+trail]=new Vector4(Cell(p),before,after,0);
      minX=Mathf.Min(minX,p.x);minY=Mathf.Min(minY,p.y);maxX=Mathf.Max(maxX,p.x);maxY=Mathf.Max(maxY,p.y);}
    }
    // Conservative union of the three EXACT 11.2-pixel kernels. The tiny
    // margin keeps rounding at the edge inside; no visible tail is truncated.
    if(!force)StreamBounds[stream]=fade>0?new Vector4(minX-11.201f,minY-11.201f,maxX+11.201f,maxY+11.201f):new Vector4(1,1,-1,-1);
   }return sources;
  }
  internal void Validate(){
   foreach(var route in routes){Vector2 previous=route.At(0);
    for(float d=0;d<route.Length;d+=.5f){var p=route.At(d);int x=(int)(p.x/16),y=(int)(p.y/16);
     if(x<0||x>=36||y<0||y>=25||masks[x,y]<0)throw new InvalidOperationException("Light left its wall tile");
     if((p-previous).magnitude>1)throw new InvalidOperationException("Discontinuous rounded light route");previous=p;
    }
   }
  }
 }
}

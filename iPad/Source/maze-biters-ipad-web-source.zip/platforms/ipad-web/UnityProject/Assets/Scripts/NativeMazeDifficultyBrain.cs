using System;
using System.Collections.Generic;
using UnityEngine;
namespace MazeBiters.NativeStudy {
 public sealed partial class NativeMazeBrain {
  // Reused bounded workspace: no per-option graph/queue allocation. Shared
  // distance fields use the existing obstacle/player epoch cache.
  readonly int[][] threatFields=new int[3][];
  int threatCount;int[] scanSeen,scanQueue,scanDepth,huntDistances,huntQueue;int scanStamp;bool[] occupiedForDecision;
  struct Prospect {public int room,depth,clearance;}
  bool Alive(NativePlayer p)=>p!=null&&!p.Dead&&p.Lives>0;
  bool Powered(NativePlayer p)=>p.PowerUntil>world.Time||p.ShieldUntil>world.Time;
  int DistanceAt(int[] field,Vector2Int cell){if(!world.Floor(cell))return -1;return field[world.Index(cell)];}
  int Clearance(Vector2Int cell){int best=1000;for(int i=0;i<threatCount;i++){int d=DistanceAt(threatFields[i],cell);if(d>=0)best=Math.Min(best,d);}return best;}
  void ReadThreats(){threatCount=0;for(int i=0;i<world.PlayerCount;i++){var p=world.GetPlayer(i);if(Alive(p))threatFields[threatCount++]=Field(p.Cell);}}
  NativePlayer DifficultyTarget(NativeCreature e,NativeBrainState state,Vector2Int origin,NativeDifficultyProfile tuning){
   var previous=world.PlayerById(state.targetPlayerId);
   if(Alive(previous)&&!Powered(previous)&&world.Time<state.targetPlayerUntil&&DistanceAt(Field(previous.Cell),origin)>=0)return previous;
   NativePlayer chosen=null;double best=double.PositiveInfinity;
   for(int i=0;i<world.PlayerCount;i++){
    var p=world.GetPlayer(i);if(!Alive(p)||Powered(p))continue;
    int distance=DistanceAt(Field(p.Cell),origin);if(distance<0)continue;
    // A wounded creature remembers its attacker, but does not ignore a much
    // nearer threat or change targets on every movement tick.
    double score=distance-Math.Min(3,e.PersonalThreat[p.Id-1])*(.4+tuning.Skill);
    if(score<best){best=score;chosen=p;}
   }
   if(chosen!=null){if(state.targetPlayerId!=chosen.Id){state.target=null;state.planUntil=0;}state.targetPlayerId=chosen.Id;state.targetPlayerUntil=world.Time+600+(1-tuning.Skill)*1400;}
   return chosen;
  }
  double AttackChance(NativeCreature e,BrainProfile profile,NativeDifficultyProfile tuning){
   if(profile.flee)return 0;
   double temperament=e is NativeGameplaySnake snake?snake.Temperament:.5;
   double chance=tuning.Maximum?.99:tuning.Attack*(.82+.36*temperament);
   double wound=Clamp(Math.Max(e.Anger/4,profile.injury/.34),0,1);
   chance+=tuning.Revenge*wound;
   if(profile.kind=="hunter")chance+=tuning.Attack*.15+(e is NativeHunter h&&!h.MotherAlive?tuning.Revenge*.5:0);
   if(profile.stateBoost>0)chance+=profile.stateBoost*(.025+.115*Math.Max(0,Math.Min(1,tuning.Intensity-1)));
   return Clamp(chance,0,1);
  }
  void ReadOccupancy(NativeCreature e,Vector2Int origin){
   int n=world.Width*world.Height;if(occupiedForDecision==null||occupiedForDecision.Length!=n)occupiedForDecision=new bool[n];else Array.Clear(occupiedForDecision,0,n);
   foreach(var cell in world.SolidEggs)if(world.Floor(cell))occupiedForDecision[world.Index(cell)]=true;
   foreach(var egg in world.Eggs)if(world.Floor(egg.Cell)&&world.SolidEgg(egg.Cell))occupiedForDecision[world.Index(egg.Cell)]=true;
   foreach(var snake in world.Snakes)for(int i=0;i<snake.Body.Count;i++){
    var c=snake.Body[i];
    // The tail will vacate on the next forward step; all other body cells
    // remain obstacles. This is lookahead, never a change to contact rules.
    if(ReferenceEquals(e,snake)&&(c==origin||i==snake.Body.Count-1&&!snake.Reversing))continue;
    if(world.Floor(c))occupiedForDecision[world.Index(c)]=true;
   }
   foreach(var hunter in world.Hunters)if(!ReferenceEquals(e,hunter)&&world.Floor(hunter.Cell))occupiedForDecision[world.Index(hunter.Cell)]=true;
   if(world.Scorpion!=null&&!ReferenceEquals(e,world.Scorpion)){if(world.Floor(world.Scorpion.Cell))occupiedForDecision[world.Index(world.Scorpion.Cell)]=true;if(world.Floor(world.Scorpion.Tail))occupiedForDecision[world.Index(world.Scorpion.Tail)]=true;}
  }
  bool Walkable(NativeCreature e,Vector2Int c,Vector2Int origin)=>world.Floor(c)&&!occupiedForDecision[world.Index(c)];
  Prospect Inspect(NativeCreature e,Vector2Int origin,Vector2Int start,int depthLimit){
   int n=world.Width*world.Height;
   if(scanSeen==null||scanSeen.Length!=n){scanSeen=new int[n];scanQueue=new int[n];scanDepth=new int[n];scanStamp=0;}
   if(scanStamp==int.MaxValue){Array.Clear(scanSeen,0,n);scanStamp=0;}int stamp=++scanStamp;
   int read=0,write=1;scanQueue[0]=world.Index(start);scanDepth[0]=0;scanSeen[world.Index(origin)]=stamp;scanSeen[scanQueue[0]]=stamp;
   var result=new Prospect{clearance=Clearance(start)};
   while(read<write&&read<96){int key=scanQueue[read],depth=scanDepth[read++];var cell=new Vector2Int(key%world.Width,key/world.Width);result.room++;result.depth=Math.Max(result.depth,depth);result.clearance=Math.Max(result.clearance,Clearance(cell));if(depth>=depthLimit)continue;
    foreach(var d in NativeGameplayWorld.Dirs){var next=cell+d;if(!Walkable(e,next,origin))continue;int k=world.Index(next);if(scanSeen[k]==stamp)continue;scanSeen[k]=stamp;if(write>=96)continue;scanQueue[write]=k;scanDepth[write++]=depth+1;}
   }return result;
  }
  Vector2Int HuntTarget(NativeCreature e,NativeBrainState state,Vector2Int origin,NativePlayer player,NativeDifficultyProfile tuning){
   if(state.target.HasValue&&world.Time<state.planUntil){
    if(state.planType=="chase"||state.planType=="coordinate-strike"){state.target=player.Cell;return player.Cell;}
    int remaining=DistanceAt(Field(state.target.Value),origin),direct=DistanceAt(Field(player.Cell),origin);
    state.planStalls=remaining>=state.planDistance?state.planStalls+1:0;state.planDistance=remaining;
    if(remaining>1&&direct>4&&state.planStalls<3)return state.target.Value;
    state.target=player.Cell;state.planType="coordinate-strike";state.planUntil=world.Time+1200;state.planStalls=0;return player.Cell;
   }
   state.planType="chase";state.target=player.Cell;
   // Higher settings coordinate two wings around a visible heading. Plans
   // remain reachable and bounded; no knowledge of future player inputs.
   if(tuning.Skill>=.65&&world.Snakes.Count+world.Hunters.Count>=3){
    int role=(state.brainId-1)%3;var dir=player.Dir==Vector2Int.zero?Vector2Int.right:player.Dir;
    if(role!=0){var side=new Vector2Int(-dir.y,dir.x);var proposed=Nearest(player.Cell+dir*Round(tuning.Skill*3)+side*(role==1?2:-2));int route=DistanceAt(Field(proposed),origin),direct=DistanceAt(Field(player.Cell),origin);
     if(route>1&&direct>4&&route<=direct+5){state.target=proposed;state.planType=role==1?"coordinate-left":"coordinate-right";}
    }
   }
   state.planUntil=world.Time+450+(1-tuning.Skill)*1100;state.planDistance=DistanceAt(Field(state.target.Value),origin);state.planStalls=0;
   return state.target.Value;
  }
  int[] HuntField(NativeCreature e,Vector2Int origin,Vector2Int goal,int[] fallback){
   int n=world.Width*world.Height;if(huntDistances==null||huntDistances.Length!=n){huntDistances=new int[n];huntQueue=new int[n];}
   for(int i=0;i<n;i++)huntDistances[i]=-1;
   int read=0,write=1;huntQueue[0]=world.Index(goal);huntDistances[huntQueue[0]]=0;
   while(read<write){int key=huntQueue[read++];var cell=new Vector2Int(key%world.Width,key/world.Width);
    foreach(var d in NativeGameplayWorld.Dirs){var next=cell+d;if(!Walkable(e,next,origin))continue;var player=world.PlayerAt(next);if(player!=null&&Powered(player))continue;int k=world.Index(next);if(huntDistances[k]>=0)continue;huntDistances[k]=huntDistances[key]+1;huntQueue[write++]=k;}
   }
   return huntDistances[world.Index(origin)]>=0?huntDistances:fallback;
  }
  Vector2Int ChooseDifficulty(NativeCreature e,Vector2Int origin,List<Vector2Int> options,BrainProfile profile){
   e.VisualTarget=null;if(options.Count==0)return Vector2Int.zero;
   var state=State(e);var tuning=world.DifficultyProfile;e.Intelligence=tuning.Skill;
   ReadThreats();var target=DifficultyTarget(e,state,origin,tuning);
   bool frightened=false;for(int i=0;i<world.PlayerCount;i++){var p=world.GetPlayer(i);if(Alive(p)&&Powered(p)){int d=DistanceAt(Field(p.Cell),origin);if(d>=0&&d<=tuning.Notice){frightened=true;break;}}}
   double chance=AttackChance(e,profile,tuning);e.Aggression=chance;
   bool injured=e.Anger>state.observedAnger+.001;state.observedAnger=e.Anger;
   if(state.intent==null||world.Time>=state.intentUntil||injured||state.intent=="hunt"&&target==null){
    string previousIntent=state.intent;
    state.intent=profile.flee?"evade":target!=null&&Random()<chance?"hunt":Clearance(origin)<=tuning.Notice?"evade":"wander";
    state.intentUntil=world.Time+tuning.DecisionMs*(.85+Random()*.3);state.intentPlayerId=target?.Id??0;
    // Renewing the same intention must not discard a nearly completed flank
    // or strike. Target changes already invalidate the route separately.
    if(state.intent!=previousIntent){state.target=null;state.planUntil=0;}
   }
   // Self-preservation overrides a held attack without rerolling aggression.
   string intent=frightened||profile.flee?"evade":state.intent;
   if(threatCount==0)intent="wander";
   if(intent=="evade"&&state.intent!="evade"){state.intent="evade";state.intentUntil=world.Time+tuning.DecisionMs;state.target=null;}
   if(options.Count==1){state.lastChoice=options[0];return options[0];}
   ReadOccupancy(e,origin);
   Vector2Int goal=origin;int[] routeField=null;
   if(intent=="hunt"&&target!=null){goal=HuntTarget(e,state,origin,target,tuning);routeField=Field(goal);if(tuning.Skill>=.7)routeField=HuntField(e,origin,goal,routeField);e.VisualTarget=goal;}
   else if(intent=="evade"){int nearest=1001;for(int i=0;i<world.PlayerCount;i++){var p=world.GetPlayer(i);if(!Alive(p))continue;int d=DistanceAt(Field(p.Cell),origin);if(d>=0&&d<nearest){nearest=d;e.VisualTarget=p.Cell;}}}
   state.routeHistory.Add(origin);if(state.routeHistory.Count>16)state.routeHistory.RemoveAt(0);
   Vector2Int chosen=options[0],second=chosen;double best=double.PositiveInfinity,runner=best;
   int currentClearance=Clearance(origin);
   foreach(var direction in options){var next=origin+direction;if(!world.Floor(next)||world.SolidEgg(next))continue;
    var prospect=Inspect(e,origin,next,6+Round(tuning.Skill*6));int visits=0;foreach(var cell in state.routeHistory)if(cell==next)visits++;
    double score=visits*(intent=="hunt"?1.2:5)+(direction==e.Dir?-.25:0);
    int clearance=Clearance(next);
    if(intent=="evade"){
     score-=Math.Min(40,clearance)*12+Math.Min(40,prospect.clearance)*3+Math.Min(12,prospect.room)*.4+prospect.depth*.4;
     if(prospect.room<=2)score+=75;if(clearance==0)score+=10000;
    }else if(routeField!=null){int distance=DistanceAt(routeField,next);score+=distance<0?100000:distance*12;if(prospect.room<=2&&next!=goal)score+=(tuning.Skill>=.7?50:18)*tuning.Skill;
    }else {score+=(prospect.room<=2?30:0)-Math.Min(12,prospect.room)*.4;if(clearance<=1)score+=200;}
    // Never prefer walking into a protected player over an open alternative.
    var contact=world.PlayerAt(next);if(contact!=null&&Powered(contact))score+=100000;
    if(score<best){runner=best;second=chosen;best=score;chosen=direction;}else if(score<runner){runner=score;second=direction;}
   }
   double error=intent=="evade"?1-tuning.EscapeSkill:tuning.Error;
   if(error>0&&runner<best+8&&Random()<error&&Clearance(origin+second)>=Math.Min(2,currentClearance))chosen=second;
   state.lastChoice=chosen;return chosen;
  }
 }
}

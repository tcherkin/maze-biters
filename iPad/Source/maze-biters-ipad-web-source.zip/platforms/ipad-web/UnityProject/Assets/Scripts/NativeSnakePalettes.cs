using System;
using System.Collections.Generic;
using System.Linq;
namespace MazeBiters.NativeStudy {
 // Appearance IDs never overlap the legacy non-snake effect slots.
 public static class NativeSnakePalettes {
  public static readonly string[] Names={"Green","Yellow","Blue","Pink","Orange","Cobalt","Ember","Pearl"};
  public static readonly string[] BiteNames={"Green","Yellow","Blue","Pink","Orange","Scorpion","Hunter1","Hunter3","Hunter4","Player1","Player2","Player3","Cobalt","Ember","Pearl"};
  public static int LightSlot(int palette)=>palette<5?palette:11+palette-5;
  public static int BiteSlot(int palette)=>palette<5?palette:12+palette-5;
  // Consume precisely the old appearance RNG first. A separate campaign-seeded
  // shuffle varies opening colours without advancing movement or AI randomness.
  // Shared menu/next-level previews receive the same seed as the live level.
  public static List<int> Expand(IReadOnlyList<int> original,int level,uint campaignSeed=0){
   uint state=unchecked((0x81e24a37u+(uint)Math.Max(1,level)*0x9e3779b9u)^campaignSeed);
   foreach(int c in original)state=unchecked((state^(uint)(c+1))*16777619u);
   uint Next(){unchecked{state+=0x6D2B79F5;uint v=(state^(state>>15))*(1|state);v^=v+(v^(v>>7))*(61|v);return v^(v>>14);}}
   var result=new List<int>();
   while(result.Count<original.Count){
    int[] bag=Enumerable.Range(0,Names.Length).ToArray();
    for(int i=bag.Length-1;i>0;i--){int j=(int)(Next()%(uint)(i+1));int t=bag[i];bag[i]=bag[j];bag[j]=t;}
    if(result.Count>0&&result[result.Count-1]==bag[0]){int t=bag[0];bag[0]=bag[1];bag[1]=t;}
    result.AddRange(bag.Take(original.Count-result.Count));
   }
   return result;
  }
 }
}

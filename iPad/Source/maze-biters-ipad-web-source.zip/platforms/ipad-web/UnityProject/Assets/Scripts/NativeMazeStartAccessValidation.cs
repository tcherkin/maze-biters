#if UNITY_EDITOR
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using UnityEngine;

namespace MazeBiters.NativeStudy {
 [Serializable] public sealed class NativeMazeStartAccessExample {
  public uint seed;
  public int difficulty,level,openedCells;
  public string style;
  public int[] beforeDistances,afterDistances,beforeCoreDistances,afterCoreDistances;
  public string[] before,after;
 }
 [Serializable] public sealed class NativeMazeStartAccessReport {
  public bool passed;
  public int assertions,failures,generatedCases,syntheticCases,changedCases,unchangedCases,previouslyUnsafeStarts;
  public int maximumBeforeDistance,maximumAfterDistance,maximumBeforeCoreDistance,maximumAfterCoreDistance,minimumOpenedCells,maximumOpenedCells,retainedRemoteDeadEnds;
  public double averageOpenedCells,elapsedMs,oldGenerationMs,newGenerationMs;
  public int maxChoiceDistance,escapeRadius,editRadius;
  public string scope="Independent geometric checks of the iPad start-access post-pass. A reachable cyclic region and two vertex-disjoint onward routes in the global leaf-peeled core must leave the local start area. Editor timing is diagnostic, not a device performance comparison.";
  public List<string> styles=new List<string>();
  public List<string> failureDetails=new List<string>();
  public List<NativeMazeStartAccessExample> examples=new List<NativeMazeStartAccessExample>();
 }
 public static class NativeMazeStartAccessValidation {
  static readonly Vector2Int[] Directions={Vector2Int.right,Vector2Int.left,Vector2Int.up,Vector2Int.down};
  static void Check(NativeMazeStartAccessReport r,bool passed,string detail){r.assertions++;if(passed)return;r.failures++;if(r.failureDetails.Count<80)r.failureDetails.Add(detail);}
  static bool Floor(string[] grid,Vector2Int p)=>p.y>=0&&p.y<grid.Length&&p.x>=0&&p.x<grid[0].Length&&grid[p.y][p.x]!='#';
  static int Manhattan(Vector2Int a,Vector2Int b)=>Math.Abs(a.x-b.x)+Math.Abs(a.y-b.y);
  static IEnumerable<Vector2Int> Neighbours(string[] grid,Vector2Int p){foreach(var d in Directions)if(Floor(grid,p+d))yield return p+d;}
  static Dictionary<Vector2Int,int> Distances(string[] grid,Vector2Int start,out Dictionary<Vector2Int,Vector2Int> parents){
   var result=new Dictionary<Vector2Int,int>();parents=new Dictionary<Vector2Int,Vector2Int>();if(!Floor(grid,start))return result;
   var queue=new Queue<Vector2Int>();result[start]=0;queue.Enqueue(start);
   while(queue.Count>0){var p=queue.Dequeue();foreach(var n in Neighbours(grid,p))if(!result.ContainsKey(n)){result[n]=result[p]+1;parents[n]=p;queue.Enqueue(n);}}
   return result;
  }
  sealed class Edge {public int to,reverse,capacity;public Edge(int to,int reverse,int capacity){this.to=to;this.reverse=reverse;this.capacity=capacity;}}
  // This is deliberately separate from the production topology. Split every
  // floor vertex into an in/out pair of capacity one and seek two augmenting
  // paths to distinct outside cells. A degree-three blind spur, or two sides
  // of a small loop sharing a later gate, cannot manufacture a second route.
  static bool TwoRoutes(string[] grid,Vector2Int start,Vector2Int candidate,int radius,HashSet<Vector2Int> blocked,HashSet<Vector2Int> core){
   var local=new List<Vector2Int>();for(int y=0;y<grid.Length;y++)for(int x=0;x<grid[0].Length;x++){var p=new Vector2Int(x,y);if(core.Contains(p)&&Manhattan(start,p)<=radius&&!blocked.Contains(p))local.Add(p);}
   var index=new Dictionary<Vector2Int,int>();for(int i=0;i<local.Count;i++)index[local[i]]=i;
   if(!index.ContainsKey(candidate))return false;int sink=local.Count*2,source=index[candidate]*2;var graph=Enumerable.Range(0,sink+1).Select(_=>new List<Edge>()).ToArray();
   void Add(int a,int b,int capacity){var forward=new Edge(b,graph[b].Count,capacity);var reverse=new Edge(a,graph[a].Count,0);graph[a].Add(forward);graph[b].Add(reverse);}
   foreach(var p in local){int i=index[p];Add(i*2,i*2+1,p==candidate?2:1);if(Manhattan(start,p)==radius){Add(i*2+1,sink,1);continue;}foreach(var n in Neighbours(grid,p))if(index.TryGetValue(n,out int j))Add(i*2+1,j*2,2);}
   for(int flow=0;flow<2;flow++){
    var parent=Enumerable.Repeat(-1,graph.Length).ToArray();var edgeIndex=new int[graph.Length];var queue=new Queue<int>();queue.Enqueue(source);parent[source]=source;
    while(queue.Count>0&&parent[sink]<0){int at=queue.Dequeue();for(int i=0;i<graph[at].Count;i++){var e=graph[at][i];if(e.capacity<=0||parent[e.to]>=0)continue;parent[e.to]=at;edgeIndex[e.to]=i;queue.Enqueue(e.to);}}
    if(parent[sink]<0)return false;
    for(int at=sink;at!=source;at=parent[at]){var e=graph[parent[at]][edgeIndex[at]];e.capacity--;graph[at][e.reverse].capacity++;}
   }
   return true;
  }
  static int ChoiceDistance(string[] grid,Vector2Int start,int radius,int maximum){
   var distance=Distances(grid,start,out var parent);var core=CycleCore(grid,distance.Keys);
   foreach(var candidate in distance.OrderBy(p=>p.Value).ThenBy(p=>p.Key.y).ThenBy(p=>p.Key.x)){
    if(candidate.Value>maximum)break;
    if(!core.Contains(candidate.Key))continue;
    var blocked=new HashSet<Vector2Int>();var p=candidate.Key;while(p!=start){p=parent[p];blocked.Add(p);}
    if(Neighbours(grid,candidate.Key).Count(n=>!blocked.Contains(n))<2)continue;
    if(TwoRoutes(grid,start,candidate.Key,radius,blocked,core))return candidate.Value;
   }
   return -1;
  }
  static string[] Grid(int width,int height,IEnumerable<Vector2Int> cells){var result=Enumerable.Range(0,height).Select(_=>Enumerable.Repeat('#',width).ToArray()).ToArray();foreach(var c in cells)result[c.y][c.x]='.';return result.Select(r=>new string(r)).ToArray();}
  static Vector2Int Rotate(Vector2Int p,int turns){for(int i=0;i<turns;i++)p=new Vector2Int(-p.y,p.x);return p;}
  static void OracleFixtures(NativeMazeStartAccessReport r){
   // The oracle itself is checked against hand-built geometries before it is
   // used to judge generated maps, including every rotation of the failure.
   foreach(string name in new[]{"long stem","blind side forks","loop with one gate","long pair of blind branches","short stem with genuine split","two independent exits"})foreach(int turn in Enumerable.Range(0,4)){
    var cells=new HashSet<Vector2Int>();void Line(int x1,int y1,int x2,int y2){int dx=Math.Sign(x2-x1),dy=Math.Sign(y2-y1);int x=x1,y=y1;cells.Add(new Vector2Int(x,y));while(x!=x2||y!=y2){x+=dx;y+=dy;cells.Add(new Vector2Int(x,y));}}
    bool expected=name=="short stem with genuine split"||name=="two independent exits";
    if(name=="two independent exits"){Line(0,0,14,0);Line(0,0,0,14);Line(14,0,14,14);Line(0,14,14,14);}
    else if(name=="short stem with genuine split"){Line(0,0,3,0);Line(3,0,16,0);Line(3,0,3,13);Line(16,0,16,13);Line(3,13,16,13);}
    else if(name=="long pair of blind branches"){Line(0,0,16,0);Line(0,0,0,16);}
    else {Line(0,0,16,0);Line(13,0,13,12);if(name=="blind side forks"){Line(2,0,2,3);Line(5,0,5,-2);}if(name=="loop with one gate"){Line(0,0,0,3);Line(0,3,5,3);Line(5,3,5,0);}}
    var rotated=cells.Select(c=>Rotate(c,turn)).ToArray();var offset=new Vector2Int(1-rotated.Min(c=>c.x),1-rotated.Min(c=>c.y));var grid=Grid(rotated.Max(c=>c.x)+offset.x+2,rotated.Max(c=>c.y)+offset.y+2,rotated.Select(c=>c+offset));
    int choice=ChoiceDistance(grid,offset,10,6);Check(r,(choice>=0)==expected,"oracle "+name+" rotation="+turn+" choice="+choice);r.syntheticCases++;
   }
  }
  static int CornerDistance(Vector2Int c,int width,int height)=>Math.Min(Math.Min(Manhattan(c,new Vector2Int(1,1)),Manhattan(c,new Vector2Int(width-2,1))),Math.Min(Manhattan(c,new Vector2Int(1,height-2)),Manhattan(c,new Vector2Int(width-2,height-2))));
  static HashSet<Vector2Int> CycleCore(string[] grid,IEnumerable<Vector2Int> cells){
   var degree=cells.ToDictionary(p=>p,p=>Neighbours(grid,p).Count());var core=new HashSet<Vector2Int>(degree.Keys);var trim=new Queue<Vector2Int>(degree.Where(p=>p.Value<2).Select(p=>p.Key));
   while(trim.Count>0){var p=trim.Dequeue();if(!core.Remove(p))continue;foreach(var n in Neighbours(grid,p))if(core.Contains(n)&&--degree[n]<2)trim.Enqueue(n);}
   return core;
  }
  static int DistanceToCore(string[] grid,Vector2Int start){
   var distance=Distances(grid,start,out _);var core=CycleCore(grid,distance.Keys);
   return core.Count==0?-1:core.Min(p=>distance[p]);
  }
  static void RepairFixtures(NativeMazeStartAccessReport r){
   foreach(bool falseLoop in new[]{false,true})foreach(bool rotate in new[]{false,true})foreach(bool remotePassage in new[]{false,true}){
    var cells=new HashSet<Vector2Int>();void Line(int x1,int y1,int x2,int y2){int dx=Math.Sign(x2-x1),dy=Math.Sign(y2-y1);int x=x1,y=y1;cells.Add(new Vector2Int(x,y));while(x!=x2||y!=y2){x+=dx;y+=dy;cells.Add(new Vector2Int(x,y));}}
    for(int y=7;y<=17;y++)for(int x=10;x<=25;x++)cells.Add(new Vector2Int(x,y));
    Line(1,1,1,11);Line(1,11,10,11);Line(1,1,3,1);
    Line(1,15,1,23);Line(1,15,10,15);Line(1,23,3,23);
    Line(34,13,34,23);Line(25,13,34,13);Line(32,23,34,23);
    // The fourth corner is present too so a half-turn fixture still supplies
    // every real player's fixed starting cell.
    Line(34,1,34,9);Line(25,9,34,9);Line(32,1,34,1);
    // Existing remote passages cross the local frontier separately; the repair
    // must connect to them instead of drawing a new free-floating dead branch.
    if(remotePassage){Line(9,3,9,11);Line(9,11,10,11);Line(9,15,9,21);Line(9,15,10,15);
     Line(26,3,26,9);Line(25,9,26,9);Line(26,13,26,21);Line(25,13,26,13);}
    if(falseLoop){Line(1,1,5,1);Line(5,1,5,5);Line(1,5,5,5);}else {Line(1,4,4,4);Line(34,20,31,20);}
    if(rotate)cells=new HashSet<Vector2Int>(cells.Select(p=>new Vector2Int(35-p.x,24-p.y)));
    var before=Grid(36,25,cells);string label="actual repair "+(falseLoop?"single gate loop":"blind forks")+" rotate="+rotate+" second existing frontier="+remotePassage;
    try {
     int beforeFailures=NativeMazeGenerator.Starts().Count(s=>ChoiceDistance(before,new Vector2Int(s.x,s.y),r.escapeRadius,r.maxChoiceDistance)<0);
     Check(r,beforeFailures>0,label+" fixture really fails start access before repair");
     var after=NativeMazeGenerator.RepairStartAccessGeometry(before);
     foreach(var s in NativeMazeGenerator.Starts())Check(r,ChoiceDistance(after,new Vector2Int(s.x,s.y),r.escapeRadius,r.maxChoiceDistance)>=0,label+" start="+s.x+","+s.y+" becomes escapable");
     Check(r,!before.SequenceEqual(after),label+" actually changes walls");
     Check(r,after.SequenceEqual(NativeMazeGenerator.RepairStartAccessGeometry(after)),label+" reapplying is idempotent");
     Check(r,before.SequenceEqual(Grid(36,25,cells)),label+" input array remains unchanged");
     GeometryChecks(r,before,after,label);
    }catch(Exception e){Check(r,false,label+" exception: "+e.GetType().Name+" "+e.Message);}
    r.syntheticCases++;
   }
   var open=Grid(36,25,from y in Enumerable.Range(1,23) from x in Enumerable.Range(1,34) select new Vector2Int(x,y));
   Check(r,open.SequenceEqual(NativeMazeGenerator.RepairStartAccessGeometry(open)),"already open starting regions stay unchanged");r.syntheticCases++;
  }
  static int GeometryChecks(NativeMazeStartAccessReport r,string[] before,string[] after,string label){
   Check(r,before.Length==after.Length&&before[0].Length==after[0].Length,label+" grid dimensions preserved");int width=before[0].Length,height=before.Length,opened=0;
   if(after.Length!=height||after.Any(row=>row.Length!=width))return 0;
   var starts=NativeMazeGenerator.Starts();var distance=Distances(after,new Vector2Int(starts[0].x,starts[0].y),out _);
   Check(r,distance.Count==after.Sum(row=>row.Count(c=>c!='#')),label+" all floor cells remain connected");
   foreach(var start in starts)Check(r,distance.ContainsKey(new Vector2Int(start.x,start.y)),label+" fixed starting cell reachable "+start.x+","+start.y);
   for(int y=0;y<height;y++)for(int x=0;x<width;x++){
    var p=new Vector2Int(x,y);
    if(x==0||y==0||x==width-1||y==height-1)Check(r,after[y][x]=='#',label+" closed outside boundary at "+p);
    if(before[y][x]==after[y][x])continue;
    Check(r,before[y][x]=='#'&&after[y][x]=='.',label+" only wall opening, never lost floor at "+p);
    Check(r,CornerDistance(p,width,height)<=r.editRadius,label+" local corner edit at "+p);opened++;
   }
   foreach(var p in new[]{new Vector2Int(2,2),new Vector2Int(33,22),new Vector2Int(2,22)})Check(r,before[p.y][p.x]==after[p.y][p.x],label+" original corner joint preserved at "+p);
   return opened;
  }
  static void LongBlindPairRegression(NativeMazeStartAccessReport r){
   const uint seed=2;const int level=1;double difficulty=NativeMazeGenerator.Difficulties[0];
   try {
    var before=new NativeMazeGenerator(seed,difficulty,legacyStartCorridors:true).Generate(level);var after=new NativeMazeGenerator(seed,difficulty).Generate(level);var start=before.starts[2];var origin=new Vector2Int(start.x,start.y);
    Check(r,DistanceToCore(before.geometry,origin)==38,"seed 2 PICNIC level 1 third start reproduces the 38-cell blind-arm regression");
    Check(r,ChoiceDistance(before.geometry,origin,r.escapeRadius,r.maxChoiceDistance)<0,"long blind pair cannot qualify as an escape choice merely by crossing the local frontier");
    Check(r,DistanceToCore(after.geometry,origin)<=r.maxChoiceDistance,"long blind pair now reaches the cyclic maze within six steps");
    Check(r,ChoiceDistance(after.geometry,origin,r.escapeRadius,r.maxChoiceDistance)>=0,"long blind pair now supplies genuine independent onward routes in the core");
   }catch(Exception e){Check(r,false,"long blind pair regression exception: "+e.GetType().Name+" "+e.Message);}
   r.syntheticCases++;
  }
  public static NativeMazeStartAccessReport Run(){
   var report=new NativeMazeStartAccessReport{maxChoiceDistance=NativeMazeGenerator.MaxStartChoiceDistance,escapeRadius=NativeMazeGenerator.StartExitRadius,editRadius=NativeMazeGenerator.MaxStartEditRadius,minimumOpenedCells=int.MaxValue};var watch=Stopwatch.StartNew();OracleFixtures(report);RepairFixtures(report);LongBlindPairRegression(report);
   int totalOpened=0;
   foreach(uint seed in new uint[]{0,1,2,3,4,5,17,34,99,913,7719,45678,0x00C0FFEE,uint.MaxValue,101,10001})foreach(int difficulty in Enumerable.Range(0,5)){
    if(difficulty==0)UnityEngine.Debug.Log("IPAD_START_CORRIDORS_PROGRESS seed="+seed+" completed="+report.generatedCases+" failures="+report.failures+" elapsedMs="+watch.Elapsed.TotalMilliseconds.ToString("F0"));
    var oldGenerator=new NativeMazeGenerator(seed,NativeMazeGenerator.Difficulties[difficulty],legacyStartCorridors:true);var generator=new NativeMazeGenerator(seed,NativeMazeGenerator.Difficulties[difficulty]);
    foreach(int level in new[]{1,2,3,4,5,6,7,8,9,10,15,30,50,100,130,200}){
     string label="seed="+seed+" difficulty="+difficulty+" level="+level;
     try {
      var timer=Stopwatch.StartNew();var before=oldGenerator.Generate(level);timer.Stop();report.oldGenerationMs+=timer.Elapsed.TotalMilliseconds;
      timer.Restart();var after=generator.Generate(level);timer.Stop();report.newGenerationMs+=timer.Elapsed.TotalMilliseconds;
      string style=(string)typeof(NativeMazeGenerator).GetField("style",System.Reflection.BindingFlags.Instance|System.Reflection.BindingFlags.NonPublic).GetValue(generator);
      if(!report.styles.Contains(style))report.styles.Add(style);
      int opened=GeometryChecks(report,before.geometry,after.geometry,label);totalOpened+=opened;report.minimumOpenedCells=Math.Min(report.minimumOpenedCells,opened);report.maximumOpenedCells=Math.Max(report.maximumOpenedCells,opened);if(opened>0)report.changedCases++;else report.unchangedCases++;
      Check(report,before.theme==after.theme&&before.level==after.level,label+" level and palette unchanged");
      Check(report,before.starts.Length==after.starts.Length&&before.starts.Where((s,i)=>s.x!=after.starts[i].x||s.y!=after.starts[i].y||s.dir!=after.starts[i].dir).Count()==0,label+" fixed starts and directions unchanged");
      Check(report,JsonUtility.ToJson(oldGenerator.Patterns)==JsonUtility.ToJson(generator.Patterns),label+" established decorative patterns unchanged");
      Check(report,Math.Abs(oldGenerator.Target-generator.Target)<1e-9,label+" difficulty target unchanged");
      var beforeDistances=new int[3];var afterDistances=new int[3];var beforeCoreDistances=new int[3];var afterCoreDistances=new int[3];
      for(int i=0;i<after.starts.Length;i++){
       var start=after.starts[i];var cell=new Vector2Int(start.x,start.y);
       beforeDistances[i]=ChoiceDistance(before.geometry,cell,report.escapeRadius,report.maxChoiceDistance);afterDistances[i]=ChoiceDistance(after.geometry,cell,report.escapeRadius,report.maxChoiceDistance);beforeCoreDistances[i]=DistanceToCore(before.geometry,cell);
       int afterCoreDistance=DistanceToCore(after.geometry,cell);afterCoreDistances[i]=afterCoreDistance;report.maximumAfterCoreDistance=Math.Max(report.maximumAfterCoreDistance,afterCoreDistance);
       if(beforeDistances[i]<0)report.previouslyUnsafeStarts++;
       report.maximumBeforeDistance=Math.Max(report.maximumBeforeDistance,beforeDistances[i]);report.maximumAfterDistance=Math.Max(report.maximumAfterDistance,afterDistances[i]);report.maximumBeforeCoreDistance=Math.Max(report.maximumBeforeCoreDistance,beforeCoreDistances[i]);
       Check(report,afterDistances[i]>=0&&afterDistances[i]<=report.maxChoiceDistance,label+" genuine onward choice within bound for start "+i+", found="+afterDistances[i]);
       Check(report,afterCoreDistance>=0&&afterCoreDistance<=report.maxChoiceDistance,label+" reachable cyclic region within bound for start "+i+", found="+afterCoreDistance);
      }
      Check(report,opened==0||beforeDistances.Any(d=>d<0),label+" no unnecessary edits when all original starts already satisfy the rule");
      Check(report,after.geometry.SequenceEqual(generator.Generate(level).geometry),label+" repeated generation deterministic");
      Check(report,before.geometry.SequenceEqual(oldGenerator.Generate(level).geometry),label+" historical generation remains deterministic");
      if(level==1){generator.Generate(2);Check(report,after.geometry.SequenceEqual(generator.Generate(1).geometry),label+" generation 1,2,1 has no leaked state");}
      for(int y=1;y<24;y++)for(int x=1;x<35;x++){var p=new Vector2Int(x,y);if(CornerDistance(p,36,25)>report.editRadius+1&&Floor(before.geometry,p)&&Neighbours(before.geometry,p).Count()==1){Check(report,Neighbours(after.geometry,p).Count()==1,label+" remote dead end retained "+p);report.retainedRemoteDeadEnds++;}}
      if(opened>0&&report.examples.Count<6&&(!report.examples.Any(e=>e.seed==seed)||report.examples.Count<2))report.examples.Add(new NativeMazeStartAccessExample{seed=seed,difficulty=difficulty,level=level,style=style,openedCells=opened,beforeDistances=beforeDistances,afterDistances=afterDistances,beforeCoreDistances=beforeCoreDistances,afterCoreDistances=afterCoreDistances,before=before.geometry,after=after.geometry});
     }catch(Exception e){Check(report,false,label+" exception: "+e.GetType().Name+" "+e.Message);}
     report.generatedCases++;
    }
   }
   Check(report,report.styles.Count==5,"every maze symmetry style covered: "+string.Join(",",report.styles));Check(report,report.previouslyUnsafeStarts>0&&report.changedCases>0,"real generated long-start failures were repaired");Check(report,report.unchangedCases>0,"already safe generated maps were retained");Check(report,report.retainedRemoteDeadEnds>0,"long/dead-end structure outside the start zones remains represented");
   report.averageOpenedCells=report.generatedCases==0?0:(double)totalOpened/report.generatedCases;if(report.minimumOpenedCells==int.MaxValue)report.minimumOpenedCells=0;
   watch.Stop();report.elapsedMs=watch.Elapsed.TotalMilliseconds;report.passed=report.failures==0;return report;
  }
 }
}
#endif

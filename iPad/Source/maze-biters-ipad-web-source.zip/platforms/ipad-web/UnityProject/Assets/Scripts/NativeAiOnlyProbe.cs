using System;using System.IO;using System.Linq;using System.Collections;using System.Collections.Generic;using UnityEngine;
namespace MazeBiters.NativeStudy {
 public sealed partial class NativeGameplayStudy {
  bool aiOnlyProbe;
  [Serializable] sealed class AiOnlyResult {public bool passed;public string quality,note;public string[] checks,naturalEvents;public int naturalMoves,naturalScore,intakePixels;public long workingSetBytes,peakWorkingSetBytes;}
  public bool AiOnlyRosterValid=>world.Mode==0&&world.PlayerCount==1&&world.Player.IsAI&&world.Player.Palette==2&&!world.Player.Waiting&&actors.ContainsKey(1)&&actors[1].art.Palette=="ai"&&actors[1].neon==null;
  public bool HumanSoloRosterValid=>world.Mode==1&&!world.Player.IsAI&&actors[1].art.Palette=="p1";
  public Vector2Int ObservedPlayerCell=>world.Player.Cell;
  void AiOnlyFixture(){Reset(9);world.SetMode(0);actors[1].Dispose();actors.Remove(1);AddActor(world.Player,true,2);world.LifecycleEnabled=true;world.ScorpionSpawnAt=double.PositiveInfinity;PrepareLevelResources();}
  IEnumerator ProbeAiOnly(){
   var checks=new List<string>();void Check(bool ok,string label){if(!ok)throw new Exception("AI ONLY live: "+label);checks.Add(label);}
   Directory.CreateDirectory(Path.GetDirectoryName(report));sessionSmoke=true;Reset(12);yield return DrainProbePreparation();Render();
   Check(AiOnlyRosterValid&&world.Player.Lives==3,"generated solo AI, original palette and three lives");Check(MenuRecord==null,"AI run cannot become a human high score");Check(hud.PrimaryAiLabel,"AI score label and original AI font");Capture(Path.ChangeExtension(report,null)+"-start.png");
   int moved=0;var previous=world.Player.Cell;events.Clear();
   for(int f=0;f<2400&&!world.GameOver;f++){
    time+=1000.0/120;realClock+=1000.0/120;world.RealTime=realClock;world.Tick(time);world.UpdateAllTilts(time);if(scenePreparationPending)yield return DrainProbePreparation();Render();
    if(world.Player.Cell!=previous){moved++;previous=world.Player.Cell;}yield return null;
   }
   var observed=events.Distinct().ToArray();int score=world.Player.Score;
   Check(moved>20&&world.Player.Ai!=null,"AI hunts and travels without any injected player input");Check(score>0,"autonomous AI earns points in the actual campaign");
   Check(gameplayCamera.Subjects==1||world.Player.Dead||world.Transition,"camera tracks the sole AI");Capture(Path.ChangeExtension(report,null)+"-autonomous.png");
   int peak=0;
   foreach(string kind in new[]{"tail","split","head","hunter","scorpion"}){
    AiOnlyFixture();yield return DrainProbePreparation();var p=world.Player;p.Cell=p.From=p.Previous=new Vector2Int(kind=="split"?5:2,1);p.Dir=p.Next=Vector2Int.right;p.Waiting=false;p.ShieldUntil=0;p.PowerUntil=0;if(kind=="head"||kind=="hunter")world.ActivatePower();
    if(kind=="tail"||kind=="split"){var s=world.AddSnake(Enumerable.Range(3,7).Reverse().Select(x=>new Vector2Int(x,1)),Vector2Int.right,1);s.LastMove=time;AddSnake(s);}
    else if(kind=="head")AddSnake(world.AddSnake(new[]{new Vector2Int(3,1)},Vector2Int.left,3));
    else if(kind=="hunter"){var h=new NativeHunter{Id=100,Palette=1,Cell=new Vector2Int(3,1),From=new Vector2Int(3,1),Dir=Vector2Int.left};world.Hunters.Add(h);AddActor(h,false,1);}
    else{world.PlaceScorpion(new Vector2Int(4,1),Vector2Int.right);scorpionArt=CreateScorpionArt();}
    Render();world.AdvancePlayer();int wanted=kind=="tail"?25:kind=="split"?10:kind=="head"?125:kind=="hunter"?200:150;
    Check(p.Score==wanted&&!p.Dead&&p.BiteEnd>time,"AI "+kind+" uses original collision, scoring and bite animation");
    for(int f=0;f<40;f++){time+=1000.0/120;world.Time=time;realClock+=1000.0/120;Render();peak=Math.Max(peak,intake.Probe());if(f==10)Capture(Path.ChangeExtension(report,null)+"-"+kind+".png");yield return null;}
   }
   Check(peak>0,"AI mouth occlusion contains consumed tail");
   foreach(var d in NativeLevelStudy.Directions){var p=world.Player;actors[1].turn.Request(Bank(p.Dir),Bank(d),time);p.Dir=p.Next=d;for(int f=0;f<14;f++){time+=1000.0/120;world.Time=time;Render();yield return null;}}
   Check(actors[1].art.Palette=="ai","smooth turns keep the AI identity");
   string initialQuality=quality;quality=quality=="hd"?"4k":"hd";SetQuality();yield return DrainProbePreparation();Render();Check(AiOnlyRosterValid&&hud.PrimaryAiLabel,"HD/4K switch preserves AI art, mouth/blink and HUD");quality=initialQuality;SetQuality();yield return DrainProbePreparation();
   Reset(12);yield return DrainProbePreparation();world.Player.Score=150;world.Player.ExactScore=150;world.SessionDeath();time+=1000;world.Time=time;Render();Check(world.DeathAlpha>0&&world.Player.Lives==2,"original skull/death presentation");Capture(Path.ChangeExtension(report,null)+"-death.png");
   world.Snakes.Clear();world.Hunters.Clear();world.Scorpion=null;world.Eggs.Clear();time=world.Player.RespawnAt;world.Time=time;world.SessionTick();Render();Check(AiOnlyRosterValid&&world.Player.Score==150&&world.Player.ShieldUntil>time,"AI respawns without waiting for user input");
   world.CheckLevelComplete();for(int f=0;f<750;f++){time+=1000.0/120;realClock+=1000.0/120;world.Time=time;world.RealTime=realClock;world.SessionTick();Render();if(scenePreparationPending)yield return DrainProbePreparation();yield return null;}
   Check(world.Level==2&&AiOnlyRosterValid&&world.Player.Score==650,"prepared level two retains AI, animations and original 500-point bonus");Capture(Path.ChangeExtension(report,null)+"-level2.png");
   world.Player.Lives=1;world.SessionDeath();Check(world.GameOverPending,"last AI life schedules GAME OVER");world.Time=time+NativeGameplayWorld.DeathDuration;world.RealTime=realClock+NativeGameplayWorld.DeathDuration;world.SessionTick();Check(world.GameOver&&MenuRecord==null,"GAME OVER never offers an AI high-score entry");
   NativeMemory.TryRead(out var ws,out var high,out _);File.WriteAllText(report,JsonUtility.ToJson(new AiOnlyResult{passed=true,quality=quality,checks=checks.ToArray(),naturalMoves=moved,naturalScore=score,naturalEvents=observed,intakePixels=peak,workingSetBytes=ws,peakWorkingSetBytes=high,note="20 simulated seconds of unassisted original AI, then staged encounters and lifecycle checks. Original AI decision oracle is separately validated. HD/4K visual/functional checks, not a foreground performance benchmark; RAM is not VRAM. Browser untouched."},true));Application.Quit();
  }
 }
}

using System;
using System.Linq;
using UnityEngine;
namespace MazeBiters.NativeStudy {
 // Conservative preparation rejection only. Simulation, clocks and resource
 // preflight are never culled. Unknown/deforming curve types stay on the old path.
 public struct VisibilityBounds {
  public double left,top,right,bottom;
  public static VisibilityBounds Point(double x,double y)=>new VisibilityBounds{left=x,right=x,top=y,bottom=y};
  public void Add(double x,double y){left=Math.Min(left,x);right=Math.Max(right,x);top=Math.Min(top,y);bottom=Math.Max(bottom,y);}
 }
 public static class VisibilityPreparation {
  public static readonly bool Enabled=!Environment.GetCommandLineArgs().Contains("--legacy-scene-optimizations")&&!Environment.GetCommandLineArgs().Contains("--legacy-visibility-preparation");
  public static readonly bool Tour=Environment.GetCommandLineArgs().Contains("--visibility-tour");
  public static bool Active{get;private set;}static double left,top,right,bottom;
  public static long SnakeChecks,SnakeSkipped,HunterChecks,HunterSkipped,LightChecks,LightSkipped,BoundsChecks,ScorpionChecks,ScorpionSkipped;
  // Includes the complete 12-pass separable blur support, down/up sampling,
  // MSAA resolve and projected-mask bilinear footprints (under 40 world units).
  // Keep 64 on every side; this is not a visibility threshold for gameplay.
  const double EffectGuard=64;
  public static void Begin(Camera camera,bool preflight){
   Active=Enabled&&!preflight;if(!Active)return;double h=camera.orthographicSize,w=h*camera.aspect;
   left=camera.transform.position.x-w-EffectGuard;right=camera.transform.position.x+w+EffectGuard;
   top=-camera.transform.position.y-h-EffectGuard;bottom=-camera.transform.position.y+h+EffectGuard;
  }
  public static void End()=>Active=false;
  public static void Reset(){SnakeChecks=SnakeSkipped=HunterChecks=HunterSkipped=LightChecks=LightSkipped=BoundsChecks=ScorpionChecks=ScorpionSkipped=0;}
  static bool Outside(double l,double t,double r,double b)=>r<left||l>right||b<top||t>bottom;
  public static bool RejectSnake(SnakePose pose){
   if(!Active)return false;SnakeChecks++;
   if(pose.consumed||pose.paintScale!=1||pose.paintAngle!=0||pose.paintX!=0||pose.paintY!=0)return false;
   double start=Math.Min(pose.Tip,pose.head-SnakeMotion.Tail),end=pose.head+1;
   if(!pose.rail.TryVisibilityBounds(start,end,out var bounds))return false;
   var rear=pose.rigidRear??pose.rail.Sample(pose.Rear);bounds.Add(rear.x,rear.y);
   double margin=50+Math.Abs(pose.bendDx)+Math.Abs(pose.bendDy),scale=16.0/36;
   bool skip=Outside((bounds.left-margin)*scale,(bounds.top-margin)*scale,(bounds.right+margin)*scale,(bounds.bottom+margin)*scale);
   if(skip)SnakeSkipped++;return skip;
  }
  public static bool RejectHunter(Vector2 position){if(!Active)return false;HunterChecks++;double x=(position.x+.5)*16,y=(position.y+.5)*16;bool skip=Outside(x-20,y-20,x+20,y+20);if(skip)HunterSkipped++;return skip;}
  public static bool RejectScorpion(ScorpionPose pose){if(!Active)return false;ScorpionChecks++;double r=48*Math.Max(1,pose.scale);bool skip=Outside(pose.targetX-r,pose.targetY-r,pose.targetX+r,pose.targetY+r);if(skip)ScorpionSkipped++;return skip;}
  public static bool RejectLight(double x,double y){if(!Active)return false;LightChecks++;const double radius=25;bool skip=Outside(x-radius,y-radius,x+radius,y+radius);if(skip)LightSkipped++;return skip;}
  public static void CheckPreparedBounds(Bounds body,Bounds head){BoundsChecks++;body.Encapsulate(head);if(!Outside(body.min.x,-body.max.y,body.max.x,-body.min.y))throw new Exception("Early snake rejection crossed the effect guard");}
 }
}

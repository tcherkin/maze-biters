using System;
namespace MazeBiters.NativeStudy {
 // Pure metadata: these titles never advance topology, palette or actor RNG.
 public static class HybridLevelNames {
  [Serializable] public sealed class Entry {
   public string Bulgarian,English,Theme,Family;public int Level,NounIndex,QualifierIndex;public uint Seed;
  }
  sealed class Word {public readonly string Bg,En;public readonly int Gender;public Word(string bg,string en,int gender=0){Bg=bg;En=en;Gender=gender;}}
  static readonly string[] Themes={"green","orange","blue-violet","ruby-red","turquoise","gold","amethyst","rose-quartz","moonstone"};
  static readonly string[] Gems={"Emerald","Amber","Sapphire","Ruby","Aquamarine","Champagne","Amethyst","Rosequartz","Moonstone"};
  // Feminine, masculine, neuter: the optional Bulgarian metadata agrees naturally.
  static readonly string[][] BgGems={
   new[]{"Изумрудена","Изумруден","Изумрудено"},new[]{"Кехлибарена","Кехлибарен","Кехлибарено"},new[]{"Сапфирена","Сапфирен","Сапфирено"},
   new[]{"Рубинена","Рубинен","Рубинено"},new[]{"Аквамаринена","Аквамаринен","Аквамаринено"},new[]{"Златиста","Златист","Златисто"},
   new[]{"Аметистова","Аметистов","Аметистово"},new[]{"Розовокварцова","Розовокварцов","Розовокварцово"},new[]{"Лунна","Лунен","Лунно"}};
  // Distinct family vocabularies: dreamlike, crystalline, cosmic, architectural.
  static readonly Word[][] Nouns={
   new[]{
    new Word("сън","Dream",1),new Word("ехо","Echo",2),new Word("шепот","Whisper",1),new Word("блян","Reverie",1),
    new Word("мираж","Mirage",1),new Word("чудо","Wonder",2),new Word("загадка","Riddle"),new Word("тайна","Secret"),
    new Word("мистерия","Mystery"),new Word("хармония","Harmony"),new Word("серенада","Serenade"),new Word("симфония","Symphony"),
    new Word("ноктюрно","Nocturne",2),new Word("приспивна","Lullaby"),new Word("спомен","Memory",1),new Word("видение","Vision",2),
    new Word("обещание","Promise",2),new Word("желание","Wish",2),new Word("заклинание","Spell",2),new Word("енигма","Enigma"),
    new Word("безкрайност","Infinity"),new Word("вечност","Eternity"),new Word("ведрина","Serenity"),new Word("утеха","Solace"),
    new Word("унес","Trance",1),new Word("пробуждане","Awakening",2),new Word("фантазия","Fantasia"),new Word("мозайка","Mosaic"),
    new Word("гоблен","Tapestry",1),new Word("плетеница","Weave"),new Word("арабеска","Arabesque"),new Word("дантела","Lace")},
   new[]{
    new Word("градина","Garden"),new Word("корона","Crown"),new Word("геода","Geode"),new Word("пещера","Cavern"),
    new Word("долина","Valley"),new Word("цвят","Blossom",1),new Word("цъфтеж","Bloom",1),new Word("лилия","Lily"),
    new Word("лотос","Lotus",1),new Word("роза","Rose"),new Word("листенце","Petal",2),new Word("роса","Dew"),
    new Word("капчица","Droplet"),new Word("фонтан","Fountain",1),new Word("извор","Spring",1),new Word("оазис","Oasis",1),
    new Word("лагуна","Lagoon"),new Word("светилище","Sanctuary",2),new Word("убежище","Haven",2),new Word("зора","Aurora"),
    new Word("сияние","Radiance",2),new Word("проблясък","Glimmer",1),new Word("блещукане","Shimmer",2),new Word("искра","Spark"),
    new Word("призма","Prism"),new Word("фасета","Facet"),new Word("пещерка","Grotto"),new Word("рай","Paradise",1),
    new Word("горичка","Grove"),new Word("поляна","Glade"),new Word("тераса","Terrace"),new Word("разцвет","Flourish",1)},
   new[]{
    new Word("пътешествие","Voyage",2),new Word("орбита","Orbit"),new Word("комета","Comet"),new Word("спирала","Spiral"),
    new Word("мъглявина","Nebula"),new Word("нова","Nova"),new Word("галактика","Galaxy"),new Word("космос","Cosmos",1),
    new Word("хоризонт","Horizon",1),new Word("зенит","Zenith",1),new Word("слънцестоене","Solstice",2),new Word("равноденствие","Equinox",2),
    new Word("затъмнение","Eclipse",2),new Word("звездопрах","Stardust",1),new Word("астероид","Asteroid",1),new Word("метеор","Meteor",1),
    new Word("звездопад","Starfall",1),new Word("разсъмване","Daybreak",2),new Word("здрач","Dusk",1),new Word("сумрак","Twilight",1),
    new Word("полунощ","Midnight"),new Word("луноизгрев","Moonrise",1),new Word("изгрев","Sunrise",1),new Word("одисея","Odyssey"),
    new Word("дрейф","Drift",1),new Word("полет","Glide",1),new Word("каскада","Cascade"),new Word("течение","Current",2),
    new Word("лента","Ribbon"),new Word("вълна","Wave"),new Word("дъга","Arc"),new Word("траектория","Trajectory")},
   new[]{
    new Word("замък","Castle",1),new Word("катедрала","Cathedral"),new Word("дворец","Palace",1),new Word("цитадела","Citadel"),
    new Word("крепост","Fortress"),new Word("обител","Cloister"),new Word("абатство","Abbey",2),new Word("храм","Temple",1),
    new Word("олтар","Shrine",1),new Word("параклис","Chapel",1),new Word("шпил","Spire",1),new Word("кула","Tower"),
    new Word("порта","Gate"),new Word("портал","Portal",1),new Word("аркада","Arcade"),new Word("галерия","Gallery"),
    new Word("ротонда","Rotunda"),new Word("двор","Court",1),new Word("донжон","Keep",1),new Word("бастион","Bastion",1),
    new Word("библиотека","Library"),new Word("обсерватория","Observatory"),new Word("лабиринт","Labyrinth",1),new Word("проход","Passage",1),
    new Word("кръстопът","Crossroads",1),new Word("камера","Chamber"),new Word("зала","Hall"),new Word("свод","Vault",1),
    new Word("приют","Refuge",1),new Word("усамотение","Retreat",2),new Word("праг","Threshold",1),new Word("арка","Arch")}
  };
  static readonly string[] Families={"woven","crystal","diagonal","detours"};
  static uint Hash(string value){unchecked{uint hash=2166136261;foreach(char c in value){hash^=c;hash*=16777619;}return hash;}}
  static uint Next(ref uint state){unchecked{state+=0x6D2B79F5;uint value=state;value=(value^(value>>15))*(value|1);value^=value+(value^(value>>7))*(value|61);return value^(value>>14);}}
  static int Select(uint seed,int level,string theme,string family,int count){
   // Each actual colour occurs once per nine-level palette bag. Advancing by
   // this occurrence gives 32 fresh names per colour/family (288 levels) before
   // reshuffling, without map construction, a mutable cache or global RNG.
   // Artificially requesting the same colour at every level is not a campaign.
   int target=(Math.Max(1,level)-1)/Themes.Length,previous=-1;int[] bag=null;
   for(int cycle=0;cycle<=target/count;cycle++){
    bag=new int[count];for(int i=0;i<count;i++)bag[i]=i;
    uint state=seed^Hash(theme+"/"+family)^unchecked((uint)(cycle+1)*0x9E3779B1u)^0xD1B54A35u;
    for(int i=count-1;i>0;i--){int j=(int)(Next(ref state)%(uint)(i+1));int item=bag[i];bag[i]=bag[j];bag[j]=item;}
    if(bag[0]==previous){int item=bag[0];bag[0]=bag[1];bag[1]=item;}previous=bag[count-1];
   }return bag[target%count];
  }
  public static Entry Describe(uint seed,int level,string theme,string family){
   int palette=Array.IndexOf(Themes,theme);if(palette<0)throw new ArgumentException("Unknown actual maze palette: "+theme,nameof(theme));
   if(string.IsNullOrEmpty(family)||family=="automatic")family=HybridMazeStudy.FamilyForLevel(seed,level);
   int vocabulary=family=="original"?0:Array.IndexOf(Families,family);if(vocabulary<0)throw new ArgumentException("Unknown maze family: "+family,nameof(family));
   int noun=Select(seed,level,theme,family,Nouns[vocabulary].Length);var word=Nouns[vocabulary][noun];
   return new Entry{Bulgarian=BgGems[palette][word.Gender]+" "+word.Bg,English=Gems[palette]+" "+word.En,Theme=theme,Family=family,Level=Math.Max(1,level),Seed=seed,NounIndex=noun,QualifierIndex=0};
  }
  public static Entry Describe(SessionLevel level){if(level==null)throw new ArgumentNullException(nameof(level));return Describe(level.paletteSeed,level.level,level.theme,HybridMazeStudy.Report(level)?.family??"original");}
  public static string Name(SessionLevel level)=>Describe(level).Bulgarian;
  public static string Name(uint seed,int level,string theme,string family)=>Describe(seed,level,theme,family).Bulgarian;
  public static string EnglishName(SessionLevel level)=>Describe(level).English;
  public static string EnglishName(uint seed,int level,string theme,string family)=>Describe(seed,level,theme,family).English;
 }
}
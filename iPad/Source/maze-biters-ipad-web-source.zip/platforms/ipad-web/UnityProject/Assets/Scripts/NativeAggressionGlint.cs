using System;
namespace MazeBiters.NativeStudy {
 // Original presentation-only scheduler, independent of gameplay RNG. Unity
 // study supplies explicit test attention; a future AI port must supply its
 // authoritative cached attention rather than infer it from visual distance.
 public sealed class NativeAggressionGlint {
  internal NativeAggressionGlint Copy()=>(NativeAggressionGlint)MemberwiseClone();
  uint random;double aggression,start=double.NegativeInfinity,duration=1000,next=double.PositiveInfinity,waitSpan,jitter;bool active,initialPending;
  public int Events{get;private set;}
  double Random(){random=unchecked(random*1664525+1013904223);return random/4294967296.0;}
  static double Clamp(double v)=>Math.Max(0,Math.Min(1,v));static double Smooth(double v){v=Clamp(v);return v*v*(3-2*v);}
  public NativeAggressionGlint(uint seed){random=seed^0x9e3779b9u;waitSpan=500+Random()*1500;jitter=Random();}
  double Gap(){double[] levels={.2,.45,.7,1},low={6000,5000,4000,2500},high={12000,8000,6000,4000};int k=0;while(k<3&&aggression>levels[k])k++;double a=k==0?0:Clamp((aggression-levels[k-1])/(levels[k]-levels[k-1]));double lo=k==0?low[0]:low[k-1]+(low[k]-low[k-1])*a,hi=k==0?high[0]:high[k-1]+(high[k]-high[k-1])*a;return lo+(hi-lo)*jitter;}
  bool Pulsing(double now)=>now>=start&&now<start+duration;
  void Schedule(double now){initialPending=false;if(!active){next=double.PositiveInfinity;return;}jitter=Random();waitSpan=Gap();next=now+waitSpan;}
  void Start(double now){start=now;duration=1000+Random()*150;Events++;Schedule(now);}
  public void SetAggression(double value,double now){value=Clamp(value);if(value==aggression)return;bool was=active;aggression=value;active=was?value>.08:value>=.12;if(!active){next=double.PositiveInfinity;initialPending=false;return;}if(!was){if(Pulsing(now))Schedule(start);else Start(now);}else if(!initialPending){double remaining=double.IsInfinity(next)?1:Clamp((next-now)/waitSpan);waitSpan=Gap();next=Math.Max(now+remaining*waitSpan,start+2500);}}
  public double Sample(double now){if(active&&next<=now){if(now-next>1150)Schedule(now);else if(!Pulsing(now))Start(now);}double elapsed=now-start;if(elapsed<=0||elapsed>=duration)return 0;double t=elapsed/duration;return t<.38?Smooth(t/.38):1-Smooth((t-.38)/.62);}
 }
}

using System;
using System.Collections.Generic;
using UnityEngine;

namespace MazeBiters.NativeStudy {
 // A bounded envelope of possible arrivals, not a simulation of future input
 // or an assertion that an enemy occupies every reachable branch at once.
 public sealed class NativeAllyThreatForecast {
  const double Infinity=double.PositiveInfinity;
  enum Kind { Snake,Hunter,Player,Egg }
  sealed class Threat {
   internal NativeCreature source;
   internal NativeGameplaySnake snake;
   internal NativeGameplaySnake contactParent;
   internal int contactCut=-1;
   internal Kind kind;
   internal Vector2Int origin,direction;
   internal double firstDue,born,period;
   internal double[] arrival;
   internal float[] confidence;
   internal int[] seen;
   internal int epoch;
   internal NativePlayer player;
  }
  readonly List<Threat> threats=new List<Threat>();
  readonly NativePlayer observer=new NativePlayer();
  readonly NativePlayer hypotheticalObserver=new NativePlayer();
  readonly Threat contactThreat=new Threat();
  readonly NativeGameplaySnake contactFragment=new NativeGameplaySnake { Body=new List<Vector2Int>(128) };
  bool contactReady;
  NativeGameplayWorld world;
  double now,horizon,combinedThreatWeight=.18;
  int width,height,cells,active,expansionLimit=512;
  bool[] floor,permanentEgg;
  double[] solidFrom,hatchAt,releaseAt,distance;
  NativeCreature[] occupant;
  int[] bodyIndex,heap,heapAt,steps,searchSeen;
  float[] certainty;
  int heapCount,searchEpoch;
  public int ExpandedStates {get;private set;}
  public bool Truncated {get;private set;}

  public void Build(NativeGameplayWorld w,NativePlayer p,double t,double horizonMs=2400,int expansionLimit=512,double combinedThreatWeight=.18){
   world=w;now=t;horizon=Math.Max(0,Math.Min(6000,horizonMs));active=0;ExpandedStates=0;Truncated=false;contactReady=false;
   this.expansionLimit=Math.Max(64,Math.Min(512,expansionLimit));
   this.combinedThreatWeight=Finite(combinedThreatWeight)?Math.Max(0,Math.Min(1,combinedThreatWeight)):.18;
   if(w==null||p==null||w.Grid==null||w.Grid.Length==0){cells=0;return;}
   width=w.Width;height=w.Height;Ensure(width*height);CopyPlayer(p,observer);CopyPlayer(p,hypotheticalObserver);
   for(int k=0;k<cells;k++){
    floor[k]=w.Floor(Cell(k));permanentEgg[k]=false;solidFrom[k]=hatchAt[k]=Infinity;
    releaseAt[k]=0;occupant[k]=null;bodyIndex[k]=-1;
   }
   foreach(var egg in w.SolidEggs)if(Inside(egg))permanentEgg[Index(egg)]=true;
   foreach(var egg in w.Eggs){
    if(!Inside(egg.Cell)||Covered(egg))continue;
    int k=Index(egg.Cell);solidFrom[k]=Math.Max(0,egg.Born+10000-t);hatchAt[k]=Math.Max(0,egg.Born+13000-t);
   }
   foreach(var s in w.Snakes){
    double period=s.Reversing?436:218,first=Due(s.LastMove,period);
    for(int i=0;i<s.Body.Count;i++){
     var c=s.Body[i];if(!Inside(c))continue;int k=Index(c);
     occupant[k]=s;bodyIndex[k]=i;
     // Optimistic vacating times only. Later movement may leave other cells
     // occupied; the forecast therefore supplies risk, never collision truth.
     releaseAt[k]=Math.Max(releaseAt[k],first+(s.Reversing?i:s.Body.Count-1-i)*period);
    }
   }
   foreach(var h in w.Hunters)SetOccupancy(h.Cell,h,Due(h.LastMove,95));
   if(w.Scorpion!=null){var s=w.Scorpion;double first=Due(s.LastMove,218);SetOccupancy(s.Tail,s,first);SetOccupancy(s.Cell,s,first+218);}
   foreach(var s in w.Snakes){
    if(s.Body.Count==0||!Inside(s.Head))continue;
    var f=Add(Kind.Snake,s,s.Head,s.Dir,s.Reversing?436:218,Due(s.LastMove,s.Reversing?436:218));f.snake=s;Search(f);
   }
   foreach(var h in w.Hunters){if(!Inside(h.Cell))continue;Search(Add(Kind.Hunter,h,h.Cell,h.Dir,95,Due(h.LastMove,95)));}
   if(w.Competitive)for(int i=0;i<w.PlayerCount;i++){
    var other=w.GetPlayer(i);if(other==p||other.Dead||other.Lives<=0||!Inside(other.Cell))continue;
    var f=Add(Kind.Player,other,other.Cell,other.Dir,95,0);
    if(f.player==null)f.player=new NativePlayer();CopyPlayer(other,f.player);
    f.firstDue=Due(other.LastMove,PlayerPeriod(f.player,t));
    if(!Finite(DangerStart(f,0,horizon))){active--;continue;}Search(f);
   }
   foreach(var egg in w.Eggs){
    if(!Inside(egg.Cell)||Covered(egg))continue;double birth=Math.Max(0,egg.Born+13000-t);if(birth>horizon)continue;
    var f=Add(Kind.Egg,null,egg.Cell,Vector2Int.zero,95,birth+95);f.born=birth;Search(f);
   }
  }

  public double Arrival(Vector2Int cell,NativeCreature ignored=null){
   if(!Inside(cell))return Infinity;int k=Index(cell);double best=Infinity;
   for(int i=0;i<active;i++){
    var f=threats[i];if(f.seen[k]!=f.epoch||ignored!=null&&ReferenceEquals(f.source,ignored))continue;double at=f.arrival[k];
    if(f.kind==Kind.Player&&Finite(at))at=DangerStart(f,at,horizon);
    if(at<best)best=at;
   }return best;
  }

  // acquiredPowerMs is a hypothetical remaining duration from Build's clock,
  // e.g. a fruit collected by the proposed move. Rival shields/score priority
  // still use the original CanEatPlayer rules; this is not blanket immunity.
  NativePlayer ObserverWithPower(double acquiredPowerMs){
   if(acquiredPowerMs<=0)return observer;
   hypotheticalObserver.PowerUntil=Math.Max(observer.PowerUntil,now+acquiredPowerMs);return hypotheticalObserver;
  }
  public double DangerousArrival(Vector2Int cell,double fromMs,double untilMs,NativeCreature ignored=null,double acquiredPowerMs=0){
   if(!Inside(cell))return Infinity;int k=Index(cell);double best=Infinity;
   var defender=ObserverWithPower(acquiredPowerMs);double from=Math.Max(0,fromMs),until=untilMs-.00001;
   if(until<from)return Infinity;
   for(int i=0;i<active;i++){
    var f=threats[i];if(f.seen[k]!=f.epoch||ignored!=null&&ReferenceEquals(f.source,ignored))continue;
    double eta=f.arrival[k];if(eta>until)continue;
    double at=DangerStart(f,Math.Max(from,eta),until,defender);if(at<best)best=at;
   }return best;
  }
  public double Risk(Vector2Int cell,double arrivalMs,double stayMs,NativeCreature ignored=null,double acquiredPowerMs=0){
   if(!Inside(cell)||!Finite(arrivalMs))return 0;int k=Index(cell);
   var defender=ObserverWithPower(acquiredPowerMs);
   double start=Math.Max(0,arrivalMs),end=start+Math.Max(.0001,stayMs),best=0,second=0;
   for(int i=0;i<active;i++){
    var f=threats[i];if(ignored!=null&&ReferenceEquals(f.source,ignored))continue;double risk=SingleRisk(f,k,start,end,defender);
    if(risk>best){second=best;best=risk;}else if(risk>second)second=risk;
   }
   // Independent approaching creatures increase concern without turning a
   // large reachable union into an unavoidable-death map.
   return Math.Max(0,Math.Min(1,best+second*combinedThreatWeight));
  }
  // Supplement Risk after a proposed split or powered head bite at time zero.
  // The old tail becomes a new forward-moving head. Fragments have LastMove=0
  // in the real world and can move in this same tick. Existing threats remain
  // in Risk; this adds only the newly created rear head, without mutating them.
  public double RiskAfterContact(NativeGameplaySnake snake,int cutIndex,Vector2Int cell,double arrivalMs,double stayMs,double acquiredPowerMs=0){
   if(snake==null||!Inside(cell)||!Finite(arrivalMs)||cutIndex<0||cutIndex>=snake.Body.Count-1)return 0;
   if(!contactReady||!ReferenceEquals(contactThreat.contactParent,snake)||contactThreat.contactCut!=cutIndex){
    contactFragment.Body.Clear();for(int i=snake.Body.Count-1;i>cutIndex;i--)contactFragment.Body.Add(snake.Body[i]);
    contactFragment.Dir=contactFragment.Body[0]-(contactFragment.Body.Count>1?contactFragment.Body[1]:snake.Body[cutIndex]);
    contactFragment.Cell=contactFragment.Body[0];contactFragment.Reversing=false;contactFragment.Pending=null;contactFragment.HeldDirection=null;
    contactFragment.GuideDir=null;contactFragment.Guide=null;contactFragment.ReverseSteps=0;
    ResetThreat(contactThreat,Kind.Snake,contactFragment,contactFragment.Cell,contactFragment.Dir,218,0);
    contactThreat.snake=contactFragment;contactThreat.contactParent=snake;contactThreat.contactCut=cutIndex;contactReady=true;Search(contactThreat);
   }
   double start=Math.Max(0,arrivalMs);return SingleRisk(contactThreat,Index(cell),start,start+Math.Max(.0001,stayMs),ObserverWithPower(acquiredPowerMs));
  }
  double SingleRisk(Threat f,int k,double start,double end,NativePlayer defender){
   if(f.seen[k]!=f.epoch)return 0;double eta=f.arrival[k];if(!Finite(eta)||eta>=end-.00001)return 0;
   // Players depart before enemy movement on an equal-time tick. Residence
   // is [arrival, departure), so an enemy arriving at departure cannot hit.
   double dangerStart=DangerStart(f,start,end-.00001,defender);if(!Finite(dangerStart))return 0;
   double period=f.kind==Kind.Player?PlayerPeriod(f.player,now+dangerStart):f.period,risk;
   if(eta>=dangerStart)risk=.98;
   else {
    // An early possible visit does not mean the enemy camps here forever.
    double age=dangerStart-eta;
    risk=age<=period?.88-.18*age/Math.Max(1,period):.12+.50*Math.Exp(-(age-period)/(450+period*2));
   }
   return risk*(.68+.32*f.confidence[k])/(1+eta/9000);
  }

  void Ensure(int n){
   cells=n;if(floor!=null&&floor.Length==n)return;
   floor=new bool[n];permanentEgg=new bool[n];solidFrom=new double[n];hatchAt=new double[n];releaseAt=new double[n];
   occupant=new NativeCreature[n];bodyIndex=new int[n];
   // Four headings and a forward/withdrawal bit for snakes. Hunters need
   // no cut counter: incidental crossings have no mechanical cooldown.
   distance=new double[n*8];certainty=new float[n*8];steps=new int[n*8];heap=new int[n*8];heapAt=new int[n*8];searchSeen=new int[n*8];searchEpoch=0;
  }
  Threat Add(Kind kind,NativeCreature source,Vector2Int origin,Vector2Int direction,double period,double first){
   if(active==threats.Count)threats.Add(new Threat());var f=threats[active++];
   ResetThreat(f,kind,source,origin,direction,period,first);return f;
  }
  void ResetThreat(Threat f,Kind kind,NativeCreature source,Vector2Int origin,Vector2Int direction,double period,double first){
   f.kind=kind;f.source=source;f.snake=null;f.contactParent=null;f.contactCut=-1;f.origin=origin;f.direction=direction;f.period=period;f.firstDue=first;f.born=0;
   if(f.arrival==null||f.arrival.Length!=cells){f.arrival=new double[cells];f.confidence=new float[cells];f.seen=new int[cells];f.epoch=0;}
   if(f.epoch==int.MaxValue){Array.Clear(f.seen,0,f.seen.Length);f.epoch=0;}f.epoch++;
  }
  void SetOccupancy(Vector2Int c,NativeCreature source,double until){if(!Inside(c))return;int k=Index(c);occupant[k]=source;releaseAt[k]=Math.Max(releaseAt[k],until);}
  bool Covered(NativeEgg egg){
   // The runtime EggCovered/Occupied helpers contain LINQ predicates. Keep
   // these hot forecasts allocation-free and preserve their coverage rules.
   for(int i=0;i<world.PlayerCount;i++){var p=world.GetPlayer(i);if(p.Cell==egg.Cell&&(!world.Multiplayer||!p.HideDeath))return true;}
   foreach(var s in world.Snakes)for(int i=0;i<s.Body.Count;i++)if(s.Body[i]==egg.Cell)return true;
   foreach(var h in world.Hunters)if(h.Cell==egg.Cell)return true;
   if(world.Scorpion!=null&&(world.Scorpion.Cell==egg.Cell||world.Scorpion.Tail==egg.Cell))return true;
   foreach(var fruit in world.Fruits)if(fruit.Cell==egg.Cell)return true;return false;
  }
  static void CopyPlayer(NativePlayer from,NativePlayer to){
   to.Id=from.Id;to.Cell=from.Cell;to.Dir=from.Dir;to.Next=from.Next;to.LastMove=from.LastMove;
   to.Dead=from.Dead;to.Lives=from.Lives;to.Score=from.Score;to.PowerUntil=from.PowerUntil;to.ShieldUntil=from.ShieldUntil;
   to.RampAt=from.RampAt;to.RampDuration=from.RampDuration;to.RampFrom=from.RampFrom;
   to.Combo.CopyMotionFrom(from.Combo);
  }
  static double PlayerPeriod(NativePlayer p,double t){
   double strength=0;
   if(p.PowerUntil>t){double elapsed=Math.Max(0,t-p.RampAt),duration=Math.Max(1,p.RampDuration==0?1000:p.RampDuration);
    if(elapsed<duration){double u=elapsed/duration;strength=p.RampFrom+(1-p.RampFrom)*(1-(1-u)*(1-u));}
    else {double left=Math.Max(0,p.PowerUntil-t);strength=left<3000?1-Math.Pow(1-left/3000,2):1;}
   }
   // Rival envelopes deliberately allow an existing chain to continue: this
   // is the earliest plausible interception, not invented attack power.
   return 95/NativeGameplayWorld.CombineMovementSpeed(strength,p.Combo.StrengthAt(t));
  }
  double DangerStart(Threat f,double from,double until,NativePlayer defender=null){
   if(until<from)return Infinity;
   if(defender==null)defender=observer;
   if(f.kind!=Kind.Player){double protectedUntil=Math.Max(defender.PowerUntil,defender.ShieldUntil)-now;return protectedUntil>until?Infinity:Math.Max(from,protectedUntil);}
   if(world.CanEatPlayer(f.player,defender,now+from))return from;
   double best=Infinity;
   CheckExpiry(f.player.PowerUntil);CheckExpiry(f.player.ShieldUntil);CheckExpiry(defender.PowerUntil);CheckExpiry(defender.ShieldUntil);
   void CheckExpiry(double expiry){double at=expiry-now;if(at<from||at>until||at>=best)return;if(world.CanEatPlayer(f.player,defender,now+at))best=at;}
   return best;
  }
  double Due(double last,double period)=>Math.Max(0,last+period-now);
  bool Inside(Vector2Int c)=>cells>0&&c.x>=0&&c.y>=0&&c.x<width&&c.y<height;
  int Index(Vector2Int c)=>c.y*width+c.x;
  Vector2Int Cell(int k)=>new Vector2Int(k%width,k/width);
  static bool Finite(double x)=>!double.IsInfinity(x)&&!double.IsNaN(x);
  static int Direction(Vector2Int d){for(int i=0;i<4;i++)if(NativeGameplayWorld.Dirs[i]==d)return i;return 0;}
  bool HunterCutRequired(Threat f,int k,double at,bool first)=>
   (f.kind==Kind.Hunter||f.kind==Kind.Egg)&&occupant[k] is NativeGameplaySnake&&(first||releaseAt[k]>at+.001);
  bool HunterCutPossible(Threat f,int k,double at,bool first){
   if(!world.CreatureFeuds||!HunterCutRequired(f,k,at,first))return false;
   var snake=(NativeGameplaySnake)occupant[k];int index=bodyIndex[k];
   if(index<=0||index>=snake.Body.Count-1)return false;
   // Further body crossings remain possible. This is a bounded arrival
   // envelope, not a simulation of cut fragments or invented new heads.
   // At the first step current player contacts are known. Beyond that their
   // positions are not predicted, so they cannot be treated as permanent walls.
   if(first&&world.PlayerAt(Cell(k))!=null)return false;
   return true;
  }
  bool Open(Threat f,Vector2Int c,double at,bool first,int mode=0,bool reverseNeck=false){
   if(!Inside(c))return false;int k=Index(c);if(!floor[k]||permanentEgg[k]||at>=solidFrom[k]&&at<hatchAt[k])return false;
   var owner=occupant[k];bool contactBody=f.contactParent!=null&&ReferenceEquals(owner,f.contactParent);
   if(contactBody&&bodyIndex[k]==f.contactCut)owner=null;
   bool cut=HunterCutPossible(f,k,at,first);
   bool eatsHunter=world.CreatureFeuds&&f.kind==Kind.Snake&&mode==0&&owner is NativeHunter;
   if(owner!=null&&!cut&&!eatsHunter){
    bool own=ReferenceEquals(owner,f.source)||contactBody&&bodyIndex[k]>f.contactCut;
    int ownIndex=contactBody?f.contactParent.Body.Count-1-bodyIndex[k]:bodyIndex[k];
    double released=contactBody?(bodyIndex[k]>f.contactCut?bodyIndex[k]-f.contactCut-1:f.contactCut-1-bodyIndex[k])*218:releaseAt[k];
    if(reverseNeck&&own)return true;
    if(first){if(!(own&&f.snake!=null&&ownIndex==f.snake.Body.Count-1))return false;}
    else if(released>at+.001&&!own)return false;
    else if(own&&f.snake!=null&&released>at+.001)return false;
   }
   if(first&&f.kind!=Kind.Player)for(int i=0;i<world.PlayerCount;i++){
    var p=world.GetPlayer(i);if(p.Id!=observer.Id&&!p.Dead&&p.Lives>0&&p.Cell==c&&(p.ShieldUntil>now+at||p.PowerUntil>now+at))return false;
   }
   return true;
  }

  void Search(Threat f){
   if(searchEpoch==int.MaxValue){Array.Clear(searchSeen,0,searchSeen.Length);searchEpoch=0;}searchEpoch++;heapCount=0;
   if(f.kind==Kind.Egg){for(int d=0;d<4;d++)Offer(Index(f.origin),d,0,f.born,.75f,0);}
   else Offer(Index(f.origin),Direction(f.direction),f.snake!=null&&f.snake.Reversing?1:0,0,1,0);
   int expanded=0;
   while(heapCount>0&&expanded<expansionLimit){
    int state=Pop(),mode=state&1,heading=(state>>1)&3,key=state>>3,depth=steps[state];double at=distance[state];
    if(at>horizon)break;expanded++;var c=Cell(key);float confidence=certainty[state];
    if(f.seen[key]!=f.epoch||at<f.arrival[key]-.001||Math.Abs(at-f.arrival[key])<=.001&&confidence>f.confidence[key]){f.seen[key]=f.epoch;f.arrival[key]=at;f.confidence[key]=confidence;}
    if(depth==0&&f.snake!=null&&f.snake.Reversing){SeedRetreat(f,confidence);continue;}
    double period=f.kind==Kind.Player?PlayerPeriod(f.player,now+at):f.kind==Kind.Snake?(mode==1?436:218):95;
    double nextTime=depth==0?f.firstDue:at+period;if(nextTime>horizon)continue;
    int available=0,nonReverse=0,reverse=heading^1;
    for(int d=0;d<4;d++){
     var next=c+NativeGameplayWorld.Dirs[d];bool neck=mode==1&&f.snake!=null&&depth+1<f.snake.Body.Count&&next==f.snake.Body[depth+1];
     int movementMode=mode;
     if(f.kind==Kind.Snake){if(mode==0&&d==reverse)movementMode=1;else if(mode==1&&d!=heading&&!neck)movementMode=0;}
     if(!Open(f,next,nextTime,depth==0,movementMode,neck))continue;available|=1<<d;if(d!=reverse)nonReverse|=1<<d;
    }
    int choices=f.kind==Kind.Player?available:nonReverse!=0?nonReverse:available;
    if(depth==0&&f.source!=null){
     Vector2Int? forced=f.source.HeldDirection;if(f.snake!=null&&f.snake.Pending.HasValue)forced=f.snake.Pending;
     if(forced.HasValue&&(choices&(1<<Direction(forced.Value)))!=0)choices=1<<Direction(forced.Value);
    }
    int count=0;for(int d=0;d<4;d++)if((choices&(1<<d))!=0)count++;
    for(int d=0;d<4;d++)if((choices&(1<<d))!=0){
     int nextMode=mode;double arrival=nextTime;float branch=count<=1?1:d==heading?.94f:.78f;
     if(f.kind==Kind.Player&&d==reverse)branch*=.8f;
     if(f.kind==Kind.Snake&&mode==0&&d==reverse){arrival+=436;nextMode=1;branch*=.8f;}
     if(f.kind==Kind.Snake&&mode==1&&d!=heading){
      var next=c+NativeGameplayWorld.Dirs[d];bool neck=depth+1<f.snake.Body.Count&&next==f.snake.Body[depth+1];
      if(!neck){arrival+=218;nextMode=0;branch*=.8f;}
     }
     Offer(Index(c+NativeGameplayWorld.Dirs[d]),d,nextMode,arrival,Math.Max(.25f,confidence*branch),depth+1);
    }
    // A forward snake cannot instantly turn through its own neck. A blocked
    // attempt enters withdrawal, and only the following 436 ms step moves it.
    if(depth==0&&choices==0&&f.snake!=null&&f.snake.Body.Count>1){
     var neck=f.snake.Body[1];if(CanWithdraw(f.snake))Offer(Index(neck),Direction(neck-c),1,nextTime+436,confidence*.85f,1);
    }
   }
   ExpandedStates+=expanded;if(heapCount>0&&expanded>=expansionLimit)Truncated=true;
  }
  bool CanWithdraw(NativeGameplaySnake s){
   if(s.Body.Count<2)return false;var guideDir=s.GuideDir??(s.Tail-s.Body[s.Body.Count-2]);
   foreach(var d in NativeGameplayWorld.Dirs){var c=s.Tail+d;if(d==-guideDir)continue;
    if(!Inside(c))continue;int k=Index(c);if(!floor[k]||permanentEgg[k]||solidFrom[k]<=0)continue;
    if(occupant[k]!=null||world.PlayerAt(c)!=null)continue;return true;
   }return false;
  }
  void SeedRetreat(Threat f,float confidence){
   var s=f.snake;var c=f.origin;double due=f.firstDue;
   if(s.Body.Count>1){
    if(CanWithdraw(s)){var next=s.Body[1];Offer(Index(next),Direction(next-c),1,due,confidence*.95f,1);}
    // A withdrawal junction changes state first; forward motion follows 218 ms later.
    if(s.ReverseSteps>=1||!CanWithdraw(s))for(int d=0;d<4;d++){
     var next=c+NativeGameplayWorld.Dirs[d];if(next==s.Body[1]||!Open(f,next,due+218,true))continue;
     Offer(Index(next),d,0,due+218,confidence*.7f,1);
    }
   }else{
    Vector2Int? previous=s.Trail.Count>0?(Vector2Int?)s.Trail[s.Trail.Count-1]:null;
    for(int d=0;d<4;d++){
     bool back=NativeGameplayWorld.Dirs[d]!=s.Dir;
     var next=c+NativeGameplayWorld.Dirs[d];if(!Open(f,next,due,true,back?1:0))continue;
     Offer(Index(next),d,back?1:0,due,confidence*(previous==next?.95f:back?.7f:.5f),1);
    }
   }
  }
  void Offer(int cell,int direction,int mode,double at,float confidence,int depth){
   if(at>horizon)return;int state=(cell<<3)|(direction<<1)|mode;
   if(searchSeen[state]!=searchEpoch){searchSeen[state]=searchEpoch;distance[state]=Infinity;heapAt[state]=-1;}
   if(at>=distance[state]-.001)return;distance[state]=at;certainty[state]=confidence;steps[state]=depth;
   int place=heapAt[state];if(place<0){place=heapCount++;heap[place]=state;heapAt[state]=place;}
   while(place>0){int parent=(place-1)>>1;if(distance[heap[parent]]<=at)break;Swap(place,parent);place=parent;}
  }
  int Pop(){int state=heap[0];heapAt[state]=-1;heapCount--;if(heapCount==0)return state;heap[0]=heap[heapCount];heapAt[heap[0]]=0;int place=0;
   while(true){int child=place*2+1;if(child>=heapCount)break;if(child+1<heapCount&&distance[heap[child+1]]<distance[heap[child]])child++;if(distance[heap[place]]<=distance[heap[child]])break;Swap(place,child);place=child;}return state;
  }
  void Swap(int a,int b){int s=heap[a];heap[a]=heap[b];heap[b]=s;heapAt[heap[a]]=a;heapAt[heap[b]]=b;}
 }
}

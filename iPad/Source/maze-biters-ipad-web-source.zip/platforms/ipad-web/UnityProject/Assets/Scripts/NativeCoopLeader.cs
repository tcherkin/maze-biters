using System;using System.Collections.Generic;using UnityEngine;
namespace MazeBiters.NativeStudy {
 // Original native-size outlines/16 spark frames. Only a live turning outline
 // needs the same GPU shadow/dilation recipe as the frozen Pixi compositor.
 public sealed class NativeCoopArt:IDisposable {
  public readonly int Size;public readonly bool Legacy;public Texture2D Sparks{get;private set;}readonly Dictionary<string,Texture2D> outlines=new Dictionary<string,Texture2D>();
  // PNG exports are straight alpha; all consumers use premultiplied blending.
  // Convert before filtering so translucent edges do not become solid colored disks.
  // The legacy switch exists only for the isolated before/after validation.
  public NativeCoopArt(string quality,bool legacy=false,bool deferred=false){Legacy=legacy;Size=quality=="4k"?160:80;if(!deferred)foreach(var step in LoadSteps(quality)){} }
  public IEnumerable<object> LoadSteps(string quality){
   Sparks=NativeLightField.Load("coop/"+quality+"-sparks.png",!Legacy);yield return null;
   foreach(string p in new[]{"p1","p2","ai"})foreach(string light in new[]{"normal","bright"})foreach(string d in NativeLevelStudy.DirectionNames){outlines.Add(p+":"+light+":"+d,NativeLightField.Load("coop/"+quality+"-"+p+"-"+light+"-"+d+"-outline.png",!Legacy));yield return null;}
  }
  public Texture2D Outline(NativeTurnActor actor,int d)=>outlines[actor.Palette+":"+(actor.Bright?"bright":"normal")+":"+NativeLevelStudy.DirectionNames[d]];
  public void Dispose(){UnityEngine.Object.Destroy(Sparks);foreach(var image in outlines.Values)UnityEngine.Object.Destroy(image);}
 }
 public sealed class NativeCoopLeader:IDisposable {
  readonly NativeCoopArt assets;readonly Material process,blur,sparkPaint;readonly RenderTexture mask,soft,temp,outline,output,sparkFrame;
  readonly GameObject sparks;readonly Mesh quad;readonly bool steppedMotion,immediateHeading;readonly NativeAuraHeading heading=new NativeAuraHeading();double sparkHeading;int sparkPalette;bool warmed,gpuWarm;
  public readonly Material Display;public float Scale=1.1f;
  public NativeCoopLeader(NativeCoopArt assets,Mesh quad,bool steppedMotion=false,bool immediateHeading=false){this.assets=assets;this.quad=quad;this.steppedMotion=steppedMotion||assets.Legacy;this.immediateHeading=immediateHeading;int s=assets.Size,p=Math.Max(4,(int)Math.Ceiling(s*.05));Scale=(s+2f*p)/s;
   RenderTexture Make(int n){var rt=new RenderTexture(n,n,0,RenderTextureFormat.ARGB32){filterMode=FilterMode.Bilinear,wrapMode=TextureWrapMode.Clamp};rt.Create();return rt;}
   mask=Make(s+2*p);soft=Make(s+2*p);temp=Make(s+2*p);outline=Make(s+2*p);output=Make(s+2*p);sparkFrame=Make(s);
   process=new Material(Shader.Find("MazeBiters/CoopLeader"));process.SetFloat("_Size",s);process.SetFloat("_Padding",p);process.SetFloat("_Legacy",assets.Legacy?1:0);blur=new Material(Shader.Find("MazeBiters/NeonBlur"));
   Display=new Material(Shader.Find("MazeBiters/PremultipliedImage")){mainTexture=output};sparkPaint=new Material(Display){mainTexture=sparkFrame};
   sparks=new GameObject("Original leader wisps");sparks.AddComponent<MeshFilter>().sharedMesh=quad;var r=sparks.AddComponent<MeshRenderer>();r.sharedMaterial=sparkPaint;r.sortingOrder=9;sparks.SetActive(false);
  }
  public void Render(NativeTurnActor actor,TurnPose pose,NativePlayer p,double t,bool active){
   sparks.SetActive(active);if(!active)heading.Reset();if(!active&&warmed)return;warmed=true;
   bool turning=pose.from!=pose.to&&pose.mix>1e-9&&pose.mix<1-1e-9;
   Texture contour;
   int sparkId=p.IsAI?3:p.Id;process.SetColor("_Tint",p.IsAI?new Color(1,216/255f,93/255f):p.Id==2?new Color(102/255f,186/255f,1):new Color(109/255f,1,114/255f));
   if(turning){
    // WebGL validates every active sampler, even when _Mode skips its branch.
    // The previous frame's outline must not remain bound while we write it.
    process.SetTexture("_Outline",Texture2D.blackTexture);
    process.SetFloat("_Mode",0);Graphics.Blit(actor.Output,mask,process);Graphics.Blit(mask,soft);
    double variance=0;for(int i=0;i<6;i++)variance+=Math.Pow(.5,i*2);float first=(float)(Math.Max(2,assets.Size*.03)*.5/Math.Sqrt(variance));
    for(int axis=0;axis<2;axis++)for(int pass=0;pass<6;pass++){float step=first*(float)Math.Pow(.5,pass)/soft.width;blur.SetVector("_Step",axis==0?new Vector4(step,0,0,0):new Vector4(0,step,0,0));Graphics.Blit(pass%2==0?soft:temp,pass%2==0?temp:soft,blur);}
    process.SetFloat("_Mode",1);process.SetTexture("_Soft",soft);Graphics.Blit(actor.Output,outline,process);contour=outline;
   }else contour=assets.Outline(actor,pose.mix>1-1e-9?pose.to:pose.from);
   process.SetFloat("_Mode",2);process.SetTexture("_Outline",contour);Graphics.Blit(actor.Output,output,process);
   if(steppedMotion){int frame=((int)Math.Floor(t/72)+p.Id*5)%16;process.SetFloat("_Mode",4);process.SetVector("_Rect",new Vector4((frame%8)/8f,1-((p.Id-1)*2+frame/8+1)/6f,1/8f,1/6f));}
   else{
    if(sparkPalette!=sparkId){sparkPalette=sparkId;process.SetVector("_Source0",NativeLeaderAuraMotion.Source(0));process.SetVector("_Source1",NativeLeaderAuraMotion.Source(1));process.SetVector("_StampRect0",NativeLeaderAuraMotion.SourceRect(sparkId,0));process.SetVector("_StampRect1",NativeLeaderAuraMotion.SourceRect(sparkId,1));}
    double phase=NativeLeaderAuraMotion.Phase(t,p.Id);process.SetFloat("_Mode",5);process.SetVector("_Wisp0",NativeLeaderAuraMotion.Geometry(phase,0));process.SetVector("_Wisp1",NativeLeaderAuraMotion.Geometry(phase,1));
   }
   Graphics.Blit(assets.Sparks,sparkFrame,process);
   double requested=NativeLeaderAuraMotion.Heading(pose,p.Tilt);
   sparkHeading=steppedMotion?-Math.Atan2(p.Dir.y,p.Dir.x)*180/Math.PI-p.Tilt:!active||immediateHeading?requested:heading.Sample(requested,t);
   var pos=p.Visual(t);var q=Quaternion.Euler(0,0,(float)sparkHeading);sparks.transform.rotation=q;sparks.transform.localScale=new Vector3(16*1.85f,16*1.85f,1);sparks.transform.position=new Vector3((pos.x+.5f)*16,-(pos.y+.5f)*16,-1)-q*new Vector3(8*1.85f,-8*1.85f,0);
  }
  internal double ValidationHeading=>sparkHeading;
  internal RenderTexture ValidationOutput=>output;internal RenderTexture ValidationSparks=>sparkFrame;
  public bool Visible{get=>sparks.activeSelf;set=>sparks.SetActive(value);}
  public void Warm(NativeTurnActor actor,NativePlayer p,double time){if(gpuWarm)return;Render(actor,new TurnPose{from=0,to=1,mix=.5,angle=.5},p,time,true);gpuWarm=true;sparks.SetActive(false);heading.Reset();}
  public void Submit(UnityEngine.Rendering.CommandBuffer cmd){if(sparks.activeSelf)cmd.DrawMesh(quad,sparks.transform.localToWorldMatrix,sparkPaint);}
  public void Dispose(){UnityEngine.Object.Destroy(sparks);UnityEngine.Object.Destroy(process);UnityEngine.Object.Destroy(blur);UnityEngine.Object.Destroy(Display);UnityEngine.Object.Destroy(sparkPaint);foreach(var rt in new[]{mask,soft,temp,outline,output,sparkFrame}){if(RenderTexture.active==rt)RenderTexture.active=null;rt.Release();UnityEngine.Object.Destroy(rt);}}
 }
}

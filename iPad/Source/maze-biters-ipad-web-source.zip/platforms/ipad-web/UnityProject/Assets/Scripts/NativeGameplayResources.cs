namespace MazeBiters.NativeStudy {
 public sealed partial class NativeGameplayStudy {
  // A split replaces the logical snake, not its authored art.
  // Keep the meshes, textures and scratch targets (and therefore the matching
  // NativeNeon emitter). Only the existing split-motion state and model change.
  // This avoids re-decoding/uploading both texture sets on contact without changing
  // logical identity, eye-glint identity, birth animation, AI or bite timing.
  void RetainSplitVisual(Snake visual,NativeGameplaySnake model,NativeLiveSnake motion){
   visual.model=model;visual.motion=motion;snakes.Add(model.Id,visual);
  }
  // No AI/path query here: a potential exit doesn't mean the snake is moving
  // yet. A stationary/held snake must retire eaten material even while waiting
  // for its next reverse attempt. Active locomotion retains its 95 ms clock.
  bool FinishStationaryTailWithStep(Snake visual)=>visual.motion.Stationary(time);
 }
}

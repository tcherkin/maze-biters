using System;using UnityEngine;
namespace MazeBiters.NativeStudy {
 public static class NativeMenuBoot {
  static NativeMenuRenderer prepared;static string quality;
  internal static System.Collections.Generic.IEnumerable<object> PrepareWeb(){
   Dispose();quality=IpadPresentation.DefaultQuality;prepared=new NativeMenuRenderer(quality,deferred:true);
   foreach(var step in prepared.LoadSteps())yield return step;prepared.RetainForMenuStartup();
   Application.quitting+=Dispose;
  }
  internal static void Prepare(){
   if(!NativeBalancedLaunch.Distributed||!NativeStartupLoading.Enabled)return;
   var args=Environment.GetCommandLineArgs();bool menu=IpadPresentation.DefaultMenu||args.Length==1||Array.IndexOf(args,"--menu")>=0||Array.IndexOf(args,"--menu-smoke")>=0||Array.IndexOf(args,"--records-smoke")>=0;
   if(!menu)return;int at=Array.IndexOf(args,"--quality");quality=at<0?IpadPresentation.DefaultQuality:args[at+1];
   if(quality!="hd"&&quality!="4k")return;
   long mark=NativeStartupLoading.Stamp();
   prepared=new NativeMenuRenderer(quality);prepared.RetainForMenuStartup();prepared.WarmMenu();
   NativeStartupLoading.Add("priority menu preparation",mark);NativeStartupLoading.Mark("menu prepared before level work");
   NativeTurnBank.QueueCageSources();WarmBlitShaders();
   Application.quitting+=Dispose;
  }
  internal static NativeMenuRenderer Take(string q){if(prepared==null)return null;if(q!=quality){Dispose();return null;}var result=prepared;prepared=null;return result;}
  static void Dispose(){prepared?.Dispose();prepared=null;}
  static void WarmBlitShaders(){
   long mark=NativeStartupLoading.Stamp();var previous=RenderTexture.active;
   var target=new RenderTexture(2,2,0,RenderTextureFormat.ARGB32);target.Create();
   try{foreach(string name in new[]{"MazeBiters/CoopLeader","MazeBiters/SnakeComposite","MazeBiters/IntakeComposite"}){
     var m=new Material(Shader.Find(name));try{m.SetFloat("_Size",80);m.SetFloat("_Padding",4);foreach(int mode in new[]{0,1,2,5}){m.SetFloat("_Mode",mode);Graphics.Blit(Texture2D.whiteTexture,target,m);}}finally{UnityEngine.Object.Destroy(m);}
    }NativePreparation.Drain(target);
   }finally{RenderTexture.active=previous;target.Release();UnityEngine.Object.Destroy(target);}
   NativeStartupLoading.Add("post-menu shader preparation",mark);
  }
 }
 public sealed partial class NativeMenuRenderer {
  internal void RetainForMenuStartup(){UnityEngine.Object.DontDestroyOnLoad(camera.gameObject);}
  internal void WarmMenu(){
   var s=new NativeMenuState{Quality=Manifest.quality,Active="mode:1",ActiveAt=0};s.Shots.Add(0);Render(s,200);Render(s,8000);Render(new NativeMenuState{Quality=Manifest.quality},0);NativePreparation.Drain(Target);
  }
 }
}

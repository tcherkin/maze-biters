using Screen = UnityEngine.Device.Screen;
using System;using UnityEngine;
namespace MazeBiters.NativeStudy {
 // Presentation only: the original 576 x 400 playfield and camera solver stay intact.
 public readonly struct NativeFrame {
  public readonly float Width,Height;public readonly bool OverlayHud;
  // Frozen reference renders keep their original HUD reservation; interactive
  // play uses the entire screen, with only the score glyphs overlaid on it.
  public NativeFrame(float aspect,bool overlayHud=false){aspect=Mathf.Clamp(aspect,.4f,5f);Height=Mathf.Max(432,576/aspect);Width=Height*aspect;OverlayHud=overlayHud;}
  public float ViewOffsetY=>OverlayHud?0:16;
  public float TopInset=>OverlayHud?0:32;
  public Rect Board=>ProjectBoard(288,200,1);
  // Project the actual level edges, not a permanent 4:3 viewing aperture.
  public Rect ProjectBoard(double x,double y,double zoom)=>new Rect((float)(Width/2-x*zoom),(float)(Height/2+ViewOffsetY-y*zoom),(float)(576*zoom),(float)(400*zoom));
  // A little vertical breathing room appears only while zoomed near an edge.
  // Keep the original tracking solver intact; this is a smooth presentation offset.
  public static double EdgeY(double y,double zoom,double extra=20){if(zoom<=1)return y;double span=Math.Min(64/zoom,200-200/zoom);if(span<=0)return y;double Smooth(double t){t=Math.Max(0,Math.Min(1,t));return t*t*(3-2*t);}double top=Smooth(1-(y-200/zoom)/span),bottom=Smooth(1-(400-200/zoom-y)/span);return y+extra*Smooth((zoom-1)/.5)/zoom*(bottom-top);}
  // At full zoom the screenshot's 32+20 units of upper sky are retained,
  // mirrored below. The extra space eases away towards the centre/overview.
  public double CameraY(double y,double zoom)=>EdgeY(y,zoom,OverlayHud?Math.Max(0,52-(Height/2-200)):20);
  // Decorative breathing room must not crop an already-visible participant.
  // A partly cropped silhouette yields gradually, avoiding a camera jump at
  // the visibility threshold. Fully off-screen actors do not affect the offset.
  public double KeepVisibleY(double originalY,double desiredY,double zoom,double playerY,double radius=12){
   double half=(Height-TopInset)/(2*zoom),outside=Math.Max(0,Math.Abs(playerY-originalY)+radius-half),t=Math.Min(1,outside/(2*radius)),weight=1-t*t*(3-2*t);
   double protectedY=Math.Max(Math.Min(originalY,playerY+radius-half),Math.Min(Math.Max(originalY,playerY-radius+half),desiredY));
   return desiredY+(protectedY-desiredY)*weight;
  }
  // Distant stars translate at 16% of world-camera travel and never zoom.
  public Vector2 SkyOffset(double x,double y)=>new Vector2((float)((x-288)*NativeGlassPresentation.Parallax)-(Width-576)/2,(float)((y-200)*NativeGlassPresentation.Parallax)-(Height-432)/2);
  public void WorldPoint(Vector2 point,double x,double y,double zoom,out double wx,out double wy){wx=x+(point.x-Width/2)/zoom;wy=y+(point.y-Height/2-ViewOffsetY)/zoom;}
  public bool PointerCell(Vector2 point,double x,double y,double zoom,out Vector2Int cell){cell=default;if(zoom<=0||point.x<0||point.x>=Width||point.y<TopInset||point.y>=Height)return false;WorldPoint(point,x,y,zoom,out double wx,out double wy);if(wx<0||wx>=576||wy<0||wy>=400)return false;cell=new Vector2Int((int)Math.Floor(wx/16),(int)Math.Floor(wy/16));return true;}
  public Rect Original=>new Rect((Width-576)/2,(Height-432)/2,576,432);
  public Vector2Int Pixels(string quality){if(IpadPresentation.Enabled)return IpadPresentation.Pixels(quality);int h=quality=="4k"?2160:1080;return new Vector2Int(Mathf.RoundToInt(h*Width/Height),h);}
  public Vector2 ToOriginal(Vector2 p)=>p-Original.position;
  public Vector2 Logical(Vector2 mouse,Rect viewport,int screenHeight)=>new Vector2((mouse.x-viewport.x)*Width/viewport.width,(screenHeight-mouse.y-viewport.y)*Height/viewport.height);
 }
 [DefaultExecutionOrder(-10000)]
 public sealed class NativeDisplay:MonoBehaviour {
  static NativeDisplay instance;public static float? TestAspect;
  public static bool Enabled{get;private set;}
  public static bool Probe{get;private set;}
  public static NativeFrame Frame=>new NativeFrame(Enabled?(TestAspect??(IpadPresentation.Enabled?IpadPresentation.Aspect:(float)Screen.width/Math.Max(1,Screen.height))):4f/3,Enabled);
  public static bool AltEnter=>Application.isFocused&&(Input.GetKey(KeyCode.LeftAlt)||Input.GetKey(KeyCode.RightAlt))&&(Input.GetKeyDown(KeyCode.Return)||Input.GetKeyDown(KeyCode.KeypadEnter));
  public static bool AcceptEnter=>!Input.GetKey(KeyCode.LeftAlt)&&!Input.GetKey(KeyCode.RightAlt)&&(Input.GetKeyDown(KeyCode.Return)||Input.GetKeyDown(KeyCode.KeypadEnter));
  int windowWidth,windowHeight;double switchedAt=-10;bool requestedFull;
  public static bool Stable=>!instance||Time.realtimeSinceStartupAsDouble-instance.switchedAt>.2;
  [RuntimeInitializeOnLoadMethod(RuntimeInitializeLoadType.BeforeSceneLoad)]static void Boot(){
   var args=Environment.GetCommandLineArgs();Probe=Array.IndexOf(args,"--display-probe")>=0;
   bool diagnostic=Array.IndexOf(args,"--report")>=0;
   Enabled=IpadPresentation.Enabled||Probe||Array.IndexOf(args,"--responsive")>=0||!diagnostic&&(args.Length==1||Array.IndexOf(args,"--menu")>=0||Array.IndexOf(args,"--gameplay")>=0);
   if(!Enabled)return;if(IpadPresentation.Enabled)Input.simulateMouseWithTouches=false;instance=new GameObject("Native borderless display").AddComponent<NativeDisplay>();DontDestroyOnLoad(instance.gameObject);
   var desktop=Screen.currentResolution;instance.windowWidth=Math.Min(1440,Mathf.RoundToInt(desktop.width*.8f));instance.windowHeight=Mathf.RoundToInt(instance.windowWidth*(float)desktop.height/Math.Max(1,desktop.width));
   if(!Application.isEditor&&Application.platform!=RuntimePlatform.IPhonePlayer&&!IpadPresentation.Enabled&&!Probe&&Array.IndexOf(args,"--windowed")<0)instance.Fullscreen();else instance.requestedFull=Screen.fullScreen;
  }
  void Fullscreen(){var display=Screen.mainWindowDisplayInfo;int w=display.width,h=display.height;if(w<=0||h<=0){w=Screen.currentResolution.width;h=Screen.currentResolution.height;}Screen.SetResolution(w,h,FullScreenMode.FullScreenWindow);requestedFull=true;switchedAt=Time.realtimeSinceStartupAsDouble;}
  public static void Toggle(){if(!instance)return;if(instance.requestedFull){Screen.SetResolution(instance.windowWidth,instance.windowHeight,FullScreenMode.Windowed);instance.requestedFull=false;instance.switchedAt=Time.realtimeSinceStartupAsDouble;}else{instance.windowWidth=Screen.width;instance.windowHeight=Screen.height;instance.Fullscreen();}}
  void Update(){if(AltEnter)Toggle();}
  public static Rect Fit(float aspect){float h=Math.Min(Screen.height,Screen.width/aspect),w=h*aspect;return new Rect((Screen.width-w)/2,(Screen.height-h)/2,w,h);}
  public static bool ExitMenu(bool records,bool pending,bool escape)=>escape&&!records&&!pending;
 }
}


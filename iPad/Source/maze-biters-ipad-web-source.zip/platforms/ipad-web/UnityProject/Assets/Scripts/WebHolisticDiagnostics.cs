using System;
using UnityEngine;
namespace MazeBiters.NativeStudy {
 public sealed partial class NativeGameplayStudy {
  // Read-only observability. Ordinary play has no snapshot or query allocation.
  string WebHolisticState(){
   if(world==null||!Application.absoluteURL.Contains("diagnostic=1"))return "null";
   return JsonUtility.ToJson(new WebHolisticSnapshot{
    reference=NativeHolisticTuning.Reference,fieldEpoch=NativeHolisticTuning.FieldEpoch,fieldQueue=NativeHolisticTuning.FieldQueue,
    hud=NativeHolisticTuning.Hud,hiddenTitle=NativeHolisticTuning.Title,meshSubmission=NativeHolisticTuning.MeshSubmission,
    lightReceivers=NativeHolisticTuning.LightReceivers,lightHeadTrig=NativeHolisticTuning.LightHeadTrig,
    coreAngles=NativeHolisticTuning.CoreAngles,routeSearch=NativeHolisticTuning.RouteSearch,routeSelect=NativeHolisticTuning.RouteSelect,
    audioConstants=NativeHolisticTuning.AudioConstants,fieldCalls=world.Brain.FieldCalls,fieldHits=world.Brain.FieldCacheHits,
    fieldBuilds=world.Brain.FieldBuilds,fieldEpochResets=world.Brain.FieldEpochResets,
    hudVisibilityWrites=hud?.StateVisibilityWrites??0,hudVisibilityToggles=hud?.StateVisibilityToggles??0,
    hudFontWrites=hud?.StateFontWrites??0,hudEffectWrites=hud?.StateEffectWrites??0,
    titleSubmissions=TitleSubmissionCalls,titleSkips=TitleSkippedSubmissions});
  }
  [Serializable]sealed class WebHolisticSnapshot {
   public string revision="20261116-holistic-optimization",audioPath="browser WebAudio graph; cached PCM fallback is Editor/native only";
   public bool reference,fieldEpoch,fieldQueue,hud,hiddenTitle,meshSubmission,lightReceivers,lightHeadTrig,coreAngles,routeSearch,routeSelect,audioConstants;
   public long fieldCalls,fieldHits,fieldBuilds,fieldEpochResets,hudVisibilityWrites,hudVisibilityToggles,hudFontWrites,hudEffectWrites,titleSubmissions,titleSkips;
  }
 }
}

using System;
using System.IO;
using System.Runtime.InteropServices;
using System.Text;
namespace MazeBiters.NativeStudy {
 // Synchronous localStorage commit on the browser main thread. The independent
 // namespace neither reads nor changes the original JavaScript game's records.
 internal static class NativeWebScores {
  internal const string Key="MazeBiters:iPad:v1:scores";
  internal static string Read(bool backup=false){
#if UNITY_WEBGL && !UNITY_EDITOR
   int which=backup?1:0;
   for(int attempt=0;attempt<2;attempt++){
    int length=MBWScoreRead(which,null,0);if(length==0)return null;
    if(length<0||length>1048576)throw new IOException("Browser score storage could not be read");
    var bytes=new byte[length];int copied=MBWScoreRead(which,bytes,bytes.Length);
    if(copied==0)return null;
    if(copied<0)throw new IOException("Browser score storage could not be read");
    if(copied<=bytes.Length)return Encoding.UTF8.GetString(bytes,0,copied-1);
   }
   throw new IOException("Browser scores changed while being read");
#else
   throw new PlatformNotSupportedException();
#endif
  }
  internal static void Write(string json,bool preserveUnreadable){
#if UNITY_WEBGL && !UNITY_EDITOR
   int result=MBWScoreCommit(json,preserveUnreadable?1:0);
   if(result!=1)throw new IOException("Browser score storage commit failed ("+result+")");
#else
   throw new PlatformNotSupportedException();
#endif
  }
#if UNITY_WEBGL && !UNITY_EDITOR
  [DllImport("__Internal")] static extern int MBWScoreRead(int backup,[Out] byte[] buffer,int capacity);
  [DllImport("__Internal")] static extern int MBWScoreCommit(string json,int preserveUnreadable);
#endif
 }
}

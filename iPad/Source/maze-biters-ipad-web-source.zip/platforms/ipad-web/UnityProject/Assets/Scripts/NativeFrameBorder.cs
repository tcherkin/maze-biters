using System;using UnityEngine;
namespace MazeBiters.NativeStudy {
 // One distant sky backs the translucent maze. Four retained surround panels
 // follow the projected WORLD edges and use the same continuous star field.
 // No oversized star texture, raster work, random game state or animation clocks.
 public sealed class NativeFrameBorder:IDisposable {
  readonly GameObject[] panels=new GameObject[4];readonly Material[] paints=new Material[4];GameObject sky;Material skyPaint;NativeFrame previous;double previousX,previousY,previousZoom;bool ready;
  public NativeFrameBorder(Mesh quad,Transform parent){for(int i=0;i<4;i++){var p=panels[i]=new GameObject("Quiet star surround "+i);p.transform.SetParent(parent,false);p.AddComponent<MeshFilter>().sharedMesh=quad;paints[i]=new Material(Shader.Find(NativeGlassPresentation.SkyShader));var r=p.AddComponent<MeshRenderer>();r.sharedMaterial=paints[i];r.sortingOrder=99;}}
  public void Layout(NativeFrame frame,double x,double y,double zoom){if(ready&&previous.Width==frame.Width&&previous.Height==frame.Height&&previous.OverlayHud==frame.OverlayHud&&previousX==x&&previousY==y&&previousZoom==zoom)return;ready=true;previous=frame;previousX=x;previousY=y;previousZoom=zoom;var b=frame.ProjectBoard(x,y,zoom);
   if(NativeTunnelSky.Enabled&&frame.OverlayHud){
    if(!sky){sky=new GameObject("Continuous distant sky behind labyrinth");sky.transform.SetParent(panels[0].transform.parent,false);sky.AddComponent<MeshFilter>().sharedMesh=panels[0].GetComponent<MeshFilter>().sharedMesh;skyPaint=new Material(Shader.Find(NativeGlassPresentation.SkyShader)){renderQueue=1900};var renderer=sky.AddComponent<MeshRenderer>();renderer.sharedMaterial=skyPaint;renderer.sortingOrder=-100;}
    sky.SetActive(true);sky.transform.localPosition=new Vector3(0,32,-3);sky.transform.localScale=new Vector3(frame.Width,frame.Height,1);skyPaint.SetVector("_Rect",new Vector4(0,0,frame.Width,frame.Height));var drift=frame.SkyOffset(x,y);skyPaint.SetVector("_Offset",new Vector4(drift.x,drift.y,0,0));
   }else if(sky)sky.SetActive(false);
   float inset=frame.TopInset,left=Mathf.Clamp(b.xMin,0,frame.Width),right=Mathf.Clamp(b.xMax,0,frame.Width),top=Mathf.Clamp(b.yMin,inset,frame.Height),bottom=Mathf.Clamp(b.yMax,inset,frame.Height);
   Set(0,new Rect(0,inset,left,frame.Height-inset));Set(1,new Rect(right,inset,frame.Width-right,frame.Height-inset));
   Set(2,new Rect(left,inset,right-left,top-inset));Set(3,new Rect(left,bottom,right-left,frame.Height-bottom));
   var offset=frame.SkyOffset(x,y);foreach(var paint in paints)paint.SetVector("_Offset",new Vector4(offset.x,offset.y,0,0));
  }
  void Set(int i,Rect r){panels[i].SetActive(r.width>.01f&&r.height>.01f);panels[i].transform.localPosition=new Vector3(r.x,32-r.y,-3);panels[i].transform.localScale=new Vector3(r.width,r.height,1);paints[i].SetVector("_Rect",new Vector4(r.x,r.y,r.width,r.height));}
  internal void SetBackgroundVisible(bool visible){if(sky)sky.SetActive(visible);}
  public void Dispose(){foreach(var p in panels)UnityEngine.Object.Destroy(p);foreach(var m in paints)UnityEngine.Object.Destroy(m);UnityEngine.Object.Destroy(sky);UnityEngine.Object.Destroy(skyPaint);}
 }
}


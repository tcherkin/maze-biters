using System;using System.Collections;using System.Collections.Generic;using System.Diagnostics;using System.IO;using System.Linq;using UnityEngine;
namespace MazeBiters.NativeStudy {
 // Opt-in deterministic contact microbenchmark. Never used by interactive play.
 public sealed partial class NativeGameplayStudy {
  bool contactProbe;
  [Serializable] sealed class ContactSample {public string mode,kind;public int palette;public double contactMs,soundMs,visualEventMs,renderMs,followupMaxMs;public bool passed;}
  [Serializable] sealed class ContactReport {public string quality,note;public bool passed;public ContactSample[] samples;}
  IEnumerator ProbeContacts(){
   var samples=new List<ContactSample>();string folder=Path.ChangeExtension(report,null);Directory.CreateDirectory(folder);
   for(int test=0;test<24;test++){
    random=34;Reset(9);time=world.Time=realClock=world.RealTime=2000;world.SessionEnabled=true;
    if(sessionAudio==null){sessionAudio=new GameObject("Contact audio").AddComponent<NativeSessionAudio>();sessionAudio.Initialize(true);}
    sessionAudio.ResetBus();world.LifecycleEnabled=false;world.Player.Waiting=false;
    int kind=test%4,palette=test/8;bool power=(test/4)%2==1;
    var sample=new ContactSample{kind=new[]{"front-body","front-solo","hunter","tail-control"}[kind],mode=power?"power":"spawn",palette=palette};samples.Add(sample);
    var player=world.Player;player.Cell=player.From=player.Previous=new Vector2Int(3,1);player.Dir=player.Next=Vector2Int.right;
    if(power)world.ActivatePower();else world.ActivateShield();
    // Keep the completion transition out of a contact-only timing sample.
    var sentinel=world.AddSnake(new[]{new Vector2Int(27,9)},Vector2Int.right,4);AddSnake(sentinel);
    if(kind==2){var hunter=new NativeHunter{Id=100,Cell=new Vector2Int(4,1),From=new Vector2Int(4,1),Dir=Vector2Int.left,Palette=palette};world.Hunters.Add(hunter);AddActor(hunter,false,palette);}
    else {var body=kind==1?new[]{new Vector2Int(4,1)}:Enumerable.Range(4,7).Select(x=>new Vector2Int(x,1)).ToArray();if(kind==3)Array.Reverse(body);AddSnake(world.AddSnake(body,kind==3?Vector2Int.right:Vector2Int.left,palette));}
    // Establish the pre-contact rendering, with actual audio callback running.
    for(int i=0;i<8;i++){Render();yield return null;}
    world.Event=e=>{var timer=Stopwatch.StartNew();OnEvent(e);double ms=timer.Elapsed.TotalMilliseconds;if(e.Kind=="sound")sample.soundMs+=ms;else sample.visualEventMs+=ms;};
    var watch=Stopwatch.StartNew();world.AdvancePlayer();sample.contactMs=watch.Elapsed.TotalMilliseconds;
    sample.passed=player.Cell==new Vector2Int(4,1)&&!player.Dead&&!player.Waiting&&player.Ricochet==null&&player.Score==(kind==2?200:kind==3?25:125);
    watch.Restart();Render();sample.renderMs=watch.Elapsed.TotalMilliseconds;
    Capture(Path.Combine(folder,test+"-0.png"));yield return null;
    for(int frame=1;frame<=24;frame++){time=world.Time=realClock=world.RealTime=2000+frame*8.333333333;watch.Restart();Render();sample.followupMaxMs=Math.Max(sample.followupMaxMs,watch.Elapsed.TotalMilliseconds);if(frame==6||frame==18)Capture(Path.Combine(folder,test+"-"+frame+".png"));yield return null;}
    // The next logical move must not wait for the consumption effect.
    world.Event=OnEvent;world.AdvancePlayer();sample.passed&=player.Cell==new Vector2Int(5,1)&&!player.Dead;
   }
   bool passed=samples.All(s=>s.passed);File.WriteAllText(report,JsonUtility.ToJson(new ContactReport{passed=passed,quality=quality,samples=samples.ToArray(),note="24 staged contacts, actual rendering and muted live audio callback. CPU elapsed contact/render submission times, not FPS or GPU frame duration. PNG readback excluded from timings; no AI/level transition timing claim."},true));Application.Quit(passed?0:2);
  }
 }
}

using System;using UnityEngine;
namespace MazeBiters.NativeStudy {
 public sealed partial class NativeGameplayWorld {
  // A detached visual-only prediction. Never advances the authoritative RNG,
  // scoring, IDs, event stream or music. Normal AdvanceLevel still owns gameplay.
  public NativeGameplayWorld PreviewNextLevel(SessionLevel next,Func<double> copiedRandom,double at){
   long stamp=NativeStallTrace.Stamp();var copy=new NativeGameplayWorld(next.geometry,copiedRandom){nextId=nextId,UseLegacyAi=UseLegacyAi,Difficulty=Difficulty,AiDifficulty=AiDifficulty,Level=next.level,Time=at,SessionEnabled=true,LifecycleEnabled=true,PlayerStart=new Vector2Int(next.starts[0].x,next.starts[0].y),StartDirection=next.starts[0].dir};
   copy.SetMode(Mode);copy.SetStarts(next);copy.ScoreSpeed=ScoreSpeed;for(int i=0;i<PlayerCount;i++){var p=GetPlayer(i);using(copy.ForPlayer(copy.GetPlayer(i))){copy.Player=new NativePlayer{Id=p.Id,IsAI=p.IsAI,Palette=p.Palette,Lives=p.Lives,Score=p.Score,ExactScore=p.ExactScore,NextLifeScore=p.NextLifeScore,ExtraLives=p.ExtraLives,Contribution=p.Contribution*.35};copy.Award(500);if(copy.Player.Lives>0){copy.FreshPlayer();copy.ActivateShield();}else copy.Player.Dead=copy.Player.Eliminated=copy.Player.HideDeath=true;}}NativeStallTrace.Add("prep-preview-world",stamp);stamp=NativeStallTrace.Stamp();copy.SpawnLevelSnakes();NativeStallTrace.Add("prep-preview-snakes",stamp);stamp=NativeStallTrace.Stamp();copy.Ally.BeginLevel();Ally.PrepareFrom(copy.Ally);NativeStallTrace.Add("prep-preview-ai",stamp);return copy;
  }
 }
}

using System;
using System.Runtime.InteropServices;
using UnityEngine;
using UnityEngine.Rendering;
namespace MazeBiters.NativeStudy {
 // Completion is latched in the callback: Unity readback handles expire one
 // frame after completion, while menu navigation can legitimately defer polling.
 // The marker owns its tiny target, so cancelling a scene never waits for GPU.
 internal sealed class NativeGpuCompletion:IDisposable {
  bool done,error,cancelled,useFence,finished;GraphicsFence fence;
  readonly double started;double fenceStarted;readonly int token;
  readonly int submittedFrame;RenderTexture marker;
#if UNITY_WEBGL && !UNITY_EDITOR
  int webFence;
  [DllImport("__Internal")] static extern int MBWGpuSubmit();
  [DllImport("__Internal")] static extern int MBWGpuPoll(int id);
  [DllImport("__Internal")] static extern void MBWGpuRelease(int id);
#endif
  const double ReadbackTimeout=5,FenceTimeout=10;
  internal static int RecoveredReadbacks,TimedOutReadbacks;
  static double Now=>WebLifecycle.Realtime;
  internal NativeGpuCompletion(){
   started=Now;submittedFrame=Time.frameCount;token=NativeResponsiveStartFaults.BeginReadback();
#if UNITY_WEBGL && !UNITY_EDITOR
   webFence=MBWGpuSubmit();
   if(webFence<=0)throw new NotSupportedException("WebGL 2 GPU preparation fence is unavailable");
#else
   if(SystemInfo.supportsAsyncGPUReadback){
    var surface=marker=new RenderTexture(1,1,0,RenderTextureFormat.ARGB32){name="Preparation completion marker"};surface.Create();
    var previous=RenderTexture.active;
    try{
     Graphics.Blit(Texture2D.blackTexture,surface);
     AsyncGPUReadback.Request(surface,0,TextureFormat.RGBA32,r=>{
      error=r.hasError;done=true;
      if(RenderTexture.active==surface)RenderTexture.active=null;
      surface.Release();UnityEngine.Object.Destroy(surface);marker=null;
     });
    }catch{surface.Release();UnityEngine.Object.Destroy(surface);marker=null;done=error=true;}
    finally{RenderTexture.active=previous;}
   }else if(SystemInfo.supportsGraphicsFence)BeginFence();
   else throw new NotSupportedException("This graphics backend cannot confirm preparation asynchronously");
#endif
  }
  void BeginFence(){
   if(!SystemInfo.supportsGraphicsFence)throw new InvalidOperationException("Asynchronous GPU readiness could not be confirmed");
   // CPU synchronisation fences are query-only; they do not require async compute.
   fence=Graphics.CreateGraphicsFence(GraphicsFenceType.CPUSynchronisation,SynchronisationStageFlags.AllGPUOperations);
   useFence=true;fenceStarted=Now;
  }
  internal bool Poll(){
   if(cancelled)throw new ObjectDisposedException(nameof(NativeGpuCompletion));if(finished)return true;
#if UNITY_WEBGL && !UNITY_EDITOR
   int state=MBWGpuPoll(webFence);
   if(state>0){MBWGpuRelease(webFence);webFence=0;return finished=true;}
   if(state<0)throw new InvalidOperationException("WebGL context was lost during GPU preparation");
   if(Now-started>FenceTimeout)throw new TimeoutException("WebGL GPU preparation timed out");
   return false;
#else
   if(useFence){if(fence.passed)return finished=true;if(Now-fenceStarted>FenceTimeout)throw new TimeoutException("GPU completion fence timed out");return false;}
   bool completed=done,failed=error;NativeResponsiveStartFaults.ReadbackResult(token,ref completed,ref failed);
   if(Now-started<NativeResponsiveStartFaults.ReadbackDelayMs/1000.0)return false;
   if(completed&&!failed)return finished=true;
   if(completed&&failed||Now-started>ReadbackTimeout){RecoveredReadbacks++;if(!completed)TimedOutReadbacks++;BeginFence();return false;}
   return false;
#endif
  }
  public void Dispose(){cancelled=true;
#if UNITY_WEBGL && !UNITY_EDITOR
   if(webFence>0){MBWGpuRelease(webFence);webFence=0;}
#endif
   /* Completion callback releases its own marker, never the scene's target. */}
 }
}

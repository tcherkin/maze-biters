using System;
using UnityEngine;
namespace MazeBiters.NativeStudy {
 public sealed partial class NativeTurnBank {
  int capCapacity=64;
  public bool GameplayPrepared{get;private set;}
  public int ShapeCount=>shapes.Count;
  public int CapCount=>caps.Count;
  public int EyeCount=>hunterEyes.Count;
  public int ApertureCount=>apertures.Count;
  public void PrepareGameplay(){foreach(var step in PrepareGameplaySteps()){} }
  public System.Collections.Generic.IEnumerable<object> PrepareGameplaySteps(bool asynchronous=false){
   if(GameplayPrepared)yield break;
   // Exact finite catalogue: 3 enemies * (49 back closures + 2 side caps).
   // The old 64-entry eviction would undo preloading and reload caps in play.
   capCapacity=3*(49+2);
   foreach(string palette in new[]{"p1","p2","ai"})
    foreach(string light in new[]{"","-bright"})
     for(int direction=0;direction<4;direction++){Shape(Key("fantasy",palette+light,direction));yield return null;}
   foreach(string palette in new[]{"h1","h3","h4"}){
    for(int direction=0;direction<4;direction++){Shape(Key("dragon",palette,direction));HunterEyes(palette,direction);yield return null;}
    foreach(int side in new[]{0,2})Cap(Key("dragon",palette,side),0);
    for(int mouth=0;mouth<=48;mouth++){Cap(Key("dragon",palette,3),mouth);if(NativeSmoothLoading.Enabled||mouth%8==7)yield return null;}
   }
   for(int direction=0;direction<4;direction++){Aperture(direction);yield return null;}
   var scratch=new RenderTexture(Size,Size,0,RenderTextureFormat.ARGB32);
   scratch.Create();
   try {
    foreach(string family in new[]{"fantasy","dragon"})
     foreach(string palette in family=="fantasy"?new[]{"p1","p2","ai"}:new[]{"h1","h3","h4"})
      using(var actor=new NativeTurnActor(this,family,palette))
      using(var glow=family=="dragon"?new NativeHunterNeon(quad,Size,17):null){
       void Warm(TurnPose pose,int mouth,int blink){
        long stamp=NativeStallTrace.Stamp();
        Render(actor,pose,mouth,blink);
        if(family=="fantasy")RenderIntake(actor,pose,mouth,scratch);
        else glow.Render(this,actor,pose,mouth,blink,1000,.5,Matrix4x4.identity,0,true);
        NativeStallTrace.Add("warm-bank:"+family+":"+palette+":"+pose.from+":"+pose.to+":"+mouth,stamp);
       }
       foreach(bool bright in family=="fantasy"?new[]{false,true}:new[]{false}){
        actor.Bright=bright;
        for(int direction=0;direction<4;direction++){
         Warm(new TurnPose{from=direction,to=direction,done=true},0,0);
         if(NativeSmoothLoading.Enabled)yield return null;
         Warm(new TurnPose{from=direction,to=direction,done=true},48,24);
         if(NativeBalancedLaunch.Distributed)yield return null;
        }
        foreach(int side in new[]{0,2})foreach(int end in new[]{1,3})
         foreach(int mouth in new[]{0,18,24,48}){Warm(new TurnPose{from=side,to=end,mix=.5},mouth,12);if(NativeBalancedLaunch.Distributed)yield return null;}
        yield return null;
       }
      }
    // Compile the pure animation paths without sampling any live actor clock.
    var turn=new NativeTurnClock();
    for(int from=0;from<4;from++)for(int to=0;to<4;to++){turn.Request(from,to,1000);turn.Sample(1045,to);turn.Sample(1090,to);}
    var blink=new BlinkClock(1,1000);blink.Sample(1000);blink.Sample(1070);blink.Sample(1220);
    AnimationClock.Bite(1100,1000,1140,.4,.3);
    Graphics.Blit(Texture2D.blackTexture,scratch);foreach(var step in NativePreparation.DrainSteps(scratch,asynchronous))yield return step;
    GameplayPrepared=true;
   }finally{if(RenderTexture.active==scratch)RenderTexture.active=null;scratch.Release();UnityEngine.Object.Destroy(scratch);}
  }
 }
 // Only during preparation. A tiny readback waits for queued warm-up commands,
 // so their first-use GPU work cannot spill into the first controllable frame.
 public static class NativePreparation {
  internal static System.Collections.Generic.IEnumerable<object> DrainSteps(RenderTexture target,bool asynchronous){
   if(!asynchronous){Drain(target);yield break;}
   using(var completion=new NativeGpuCompletion())while(!completion.Poll())yield return "wait";
  }
  public static void Drain(RenderTexture target){
   var previous=RenderTexture.active;
   var pixel=new Texture2D(1,1,TextureFormat.RGBA32,false);
   try{RenderTexture.active=target;pixel.ReadPixels(new Rect(0,0,1,1),0,0,false);}
   finally{RenderTexture.active=previous;UnityEngine.Object.Destroy(pixel);}
  }
 }
}

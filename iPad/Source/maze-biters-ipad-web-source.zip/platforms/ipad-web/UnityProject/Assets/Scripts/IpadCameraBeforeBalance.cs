using System;
using UnityEngine;
namespace MazeBiters.NativeStudy {
 // One camera follow stage, with the PC's 470 ms response. Tablet framing is
 // part of the destination, not a second warp applied after the follow step.
 public sealed class IpadCameraBeforeBalance {
  bool ready,settleSource,reframing;double stamp,zoomCeiling;IpadView current;float width,height;Rect lastSafe;double lastClose;
  public int EmergencyCorrections{get;private set;}
  // SOLO takes about three 1040 ms response intervals to cover 95% of its
  // opening zoom. Use that same main duration with shared ease-in/ease-out.
  public const double SoloZoomResponse=1040,RevealDuration=3*SoloZoomResponse;
  public static double RevealProgress(double elapsed){
   double u=Clamp(elapsed/RevealDuration,0,1);
   return u*u*u*(10+u*(-15+6*u));
  }
  public int JoiningMask{get;private set;}
  public bool Revealing=>reframing;
  double revealStarted,vx,vy,vs,vh,fromVx,fromVy,fromVs,fromVh;IpadView revealFrom,revealDestination;bool destinationReady;
  public void Reset(){ready=false;settleSource=false;reframing=false;JoiningMask=0;vx=vy=vs=vh=0;EmergencyCorrections=0;}
  // Called by the original respawn event, never by its countdown or spawn cache.
  public void BeginReveal(double real,int playerId){
   if(!ready)return;JoiningMask|=1<<(playerId-1);BeginRosterMotion(real);
  }
  public void BeginLoss(double real,int playerId){
   if(!ready)return;JoiningMask&=~(1<<(playerId-1));BeginRosterMotion(real);
  }
  void BeginRosterMotion(double real){
   reframing=true;destinationReady=false;revealFrom=current;revealStarted=real;
   fromVx=vx;fromVy=vy;fromVs=vs;fromVh=vh;
  }
  IpadView Commit(IpadView view,double dt){
   if(dt>0){vx=(view.x-current.x)/dt;vy=(view.y-current.y)/dt;vs=(1/view.zoom-1/current.zoom)/dt;vh=(view.header-current.header)/dt;}
   current=view;return view;
  }
  static double Clamp(double x,double a,double b)=>a>b?(a+b)/2:Math.Max(a,Math.Min(b,x));
  static double Blend(double dt,double tau)=>1-Math.Exp(-dt/tau);
  // Ease the same follow stage forward before an actor reaches the edge.
  // This avoids switching directly to the actor's 95 ms cell interpolation.
  static double Response(double clearance,double minimum=170)=>470-(470-minimum)*IpadFraming.Smooth((40-clearance)/40);
  public IpadView Sample(NativeFrame f,double x,double y,double zoom,double close,Rect safe,Rect? bounds,double real,double? targetX=null,double? targetY=null,Rect? retainedBounds=null,double? targetZoom=null){
   var desired=IpadFraming.Calculate(f,x,y,zoom,close,safe);
   bool reset=!ready||real<stamp||width!=f.Width||height!=f.Height||lastSafe!=safe||lastClose!=close;
   if(reset){ready=true;width=f.Width;height=f.Height;lastSafe=safe;lastClose=close;stamp=real;zoomCeiling=close;JoiningMask=0;reframing=false;settleSource=false;vx=vy=vs=vh=0;current=bounds.HasValue?IpadFraming.KeepPlayers(f,desired,bounds.Value,safe):desired;return current;}
   if(real==stamp)return current;
   double dt=Math.Max(0,Math.Min(50,real-stamp));stamp=real;
   double sx=targetX??x,sy=targetY??y;
   var goal=IpadFraming.Calculate(f,sx,sy,zoom,close,safe);
   double ceilingTarget=targetZoom.HasValue?IpadFraming.Calculate(f,sx,sy,targetZoom.Value,close,safe).zoom:close;
   if(Revealing){
    var destination=IpadFraming.Calculate(f,sx,sy,targetZoom??zoom,close,safe);
    if(JoiningMask!=0)destination.zoom=Math.Min(destination.zoom,revealFrom.zoom);
    // Survivors can keep moving or turn during the transition. Follow that
    // changing destination continuously instead of importing raw target steps.
    if(destinationReady){
     destination.x=revealDestination.x+(destination.x-revealDestination.x)*Blend(dt,470);
     destination.y=revealDestination.y+(destination.y-revealDestination.y)*Blend(dt,470);
     destination.zoom=revealDestination.zoom+(destination.zoom-revealDestination.zoom)*Blend(dt,SoloZoomResponse);
     destination.header=revealDestination.header+(destination.header-revealDestination.header)*Blend(dt,SoloZoomResponse);
    }
    if(bounds.HasValue)destination=IpadFraming.KeepPlayers(f,destination,bounds.Value,safe);
    revealDestination=destination;destinationReady=true;
    double elapsed=Math.Max(0,real-revealStarted),u=Clamp(elapsed/RevealDuration,0,1),ease=RevealProgress(elapsed);
    // Preserve current velocity when a new death/birth interrupts a transition.
    // Both this carry and the shared easing settle smoothly at the endpoint.
    double tangent=RevealDuration*u*Math.Pow(1-u,3);
    // Continuous position, size and initial velocity, including another respawn
    // during an unfinished reveal. The newly alive player enters the view as it opens.
    var reveal=destination;
    double dx=destination.x-revealFrom.x,dy=destination.y-revealFrom.y,dz=destination.zoom-revealFrom.zoom,dh=destination.header-revealFrom.header;
    reveal.x=revealFrom.x+dx*ease+fromVx*tangent;
    reveal.y=revealFrom.y+dy*ease+fromVy*tangent;
    reveal.zoom=Clamp(revealFrom.zoom+dz*ease+(-fromVs*revealFrom.zoom*revealFrom.zoom)*tangent,.01,close);
    reveal.header=Clamp(revealFrom.header+dh*ease+fromVh*tangent,0,32+safe.yMin);
    if(retainedBounds.HasValue)reveal=IpadFraming.KeepPlayers(f,reveal,retainedBounds.Value,safe);
    if(u>=1){JoiningMask=0;reframing=false;settleSource=true;zoomCeiling=reveal.zoom;}
    return Commit(reveal,dt);
   }
   zoomCeiling+=(ceilingTarget-zoomCeiling)*Blend(dt,ceilingTarget<zoomCeiling?230:1040);
   if(settleSource){
    // The underlying follow may still be catching up after a roster change.
    // Hand back continuously, even if the survivors started moving meanwhile.
    double target=Math.Min(goal.zoom,zoomCeiling),headerTarget=goal.header;
    goal.zoom=current.zoom+(target-current.zoom)*Blend(dt,SoloZoomResponse);
    goal.header=current.header+(headerTarget-current.header)*Blend(dt,SoloZoomResponse);
    if(Math.Abs(target-goal.zoom)<.00001&&Math.Abs(headerTarget-goal.header)<.001)settleSource=false;
   }else goal.zoom=Math.Min(goal.zoom,zoomCeiling);
   double tauX=470,tauY=470;
   if(bounds.HasValue){var b=bounds.Value;double z=goal.zoom,top=Math.Max(safe.yMin,goal.header);
    double minX=b.xMax+12-(safe.xMax-f.Width/2)/z,maxX=b.xMin-12+(f.Width/2-safe.xMin)/z;
    double minY=b.yMax+12-(safe.yMax-f.Height/2)/z,maxY=b.yMin-12+(f.Height/2-top)/z;
    // A wide roster can approach opposite edges simultaneously; catch up
    // earlier within the same follow stage instead of activating a hard clamp.
    double minimum=b.width>24||b.height>24?100:170;
    tauX=Response(Math.Min(current.x-minX,maxX-current.x),minimum);tauY=Response(Math.Min(current.y-minY,maxY-current.y),minimum);
    var active=bounds.Value;double margin=12;
    if(active.width>24||active.height>24){
     // Keep moving participants away from the last visible pixel, using
     // only spare space already available at this zoom.
     double spare=Math.Min((safe.xMax-safe.xMin)/goal.zoom-active.width,(safe.yMax-top)/goal.zoom-active.height)/2;
     margin=Math.Max(12,Math.Min(32,spare-1));
    }
    double requestedZoom=goal.zoom;goal=IpadFraming.KeepPlayers(f,goal,active,safe,margin);
    if(goal.zoom<requestedZoom)zoomCeiling=Math.Min(zoomCeiling,goal.zoom);
   }
   var view=goal;view.x=current.x+(goal.x-current.x)*Blend(dt,tauX);view.y=current.y+(goal.y-current.y)*Blend(dt,tauY);
   // The PC world-boundary clamp, expressed in the tablet viewport.
   double sky=52*IpadFraming.Smooth((zoom-1)/.5),minWorldX=(f.Width/2-sky)/view.zoom,maxWorldX=576-minWorldX;
   double minWorldY=(f.Height/2-view.header-sky)/view.zoom,maxWorldY=400-(f.Height/2-sky)/view.zoom;
   view.x=Clamp(view.x,minWorldX,maxWorldX);view.y=Clamp(view.y,minWorldY,maxWorldY);
   if(bounds.HasValue){var protectedView=IpadFraming.KeepPlayers(f,view,bounds.Value,safe);
    if(Math.Abs(protectedView.x-view.x)>.001||Math.Abs(protectedView.y-view.y)>.001||Math.Abs(protectedView.zoom-view.zoom)>.00001)EmergencyCorrections++;
    // Release a visibility limit with the original slow zoom-in response.
    // Removing a participant must not reveal an already advanced raw zoom.
    if(protectedView.zoom<view.zoom)zoomCeiling=Math.Min(zoomCeiling,protectedView.zoom);
    view=protectedView;
   }
   return Commit(view,dt);
  }
 }
}

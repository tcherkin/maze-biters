using System;
using Unity.Collections;
namespace MazeBiters.NativeStudy {
 public sealed partial class NativeMazeArtwork {
  // A property deliberately avoids cross-partial static field initialization
  // order (the compact-cache flag can be initialized after this source file).
  static readonly bool LegacyGlassPeakMemory=Array.IndexOf(Environment.GetCommandLineArgs(),"--legacy-glass-peak-memory")>=0;
  public static bool BoundedGlassPreparation=>CompactGlassCache&&!LegacyGlassPeakMemory;

  // Every output of a box pass depends on one original scanline only. Retain
  // that scanline, not an entire second image. Sum order and float casts match
  // GlassBox exactly; columns/rows owned by different workers never intersect.
  void GlassBlurBounded(NativeArray<float> field,double sigma){
   double ideal=Math.Sqrt(4*sigma*sigma+1);int low=(int)Math.Floor(ideal);if((low&1)==0)low--;
   int high=low+2,n=GlassRound((12*sigma*sigma-3*low*low-12*low-9)/(-4.0*low-4));
   for(int k=0;k<3;k++){int radius=((k<n?low:high)-1)/2;GlassBoxBounded(field,radius,true);GlassBoxBounded(field,radius,false);}
  }
  void GlassBoxBounded(NativeArray<float> field,int radius,bool horizontal){
   int outer=horizontal?glassHeight:glassWidth,inner=horizontal?glassWidth:glassHeight,stride=horizontal?1:glassWidth;double divisor=2*radius+1;
   GlassRows(GlassPainterWorkers,worker=>{
    var line=new float[inner];int first=outer*worker/GlassPainterWorkers,last=outer*(worker+1)/GlassPainterWorkers;
    for(int q=first;q<last;q++){
     glassCancellation.ThrowIfCancellationRequested();
     int origin=horizontal?q*glassWidth:q;
     if(horizontal)NativeArray<float>.Copy(field,origin,line,0,inner);else for(int p=0;p<inner;p++)line[p]=field[origin+p*stride];
     double sum=0;for(int k=-radius;k<=radius;k++)sum+=line[Math.Max(0,Math.Min(inner-1,k))];
     for(int p=0;p<inner;p++){
      field[origin+p*stride]=(float)(sum/divisor);
      sum+=(double)line[Math.Max(0,Math.Min(inner-1,p+radius+1))]-line[Math.Max(0,Math.Min(inner-1,p-radius))];
     }
    }
   });
  }
  void GlassSeedRow(NativeArray<float> ring,int offset,float[] seed,int y){
   int radius=Math.Max(1,GlassRound(glassSize*.024));double divisor=radius*2+1,sum=0;
   for(int k=-radius;k<=radius;k++)sum+=GlassSeed(seed,Math.Max(0,Math.Min(glassWidth-1,k)),y);
   for(int x=0;x<glassWidth;x++){
    ring[offset+x]=(float)(sum/divisor);
    sum+=(double)GlassSeed(seed,Math.Min(glassWidth-1,x+radius+1),y)-GlassSeed(seed,Math.Max(0,x-radius),y);
   }
  }
  // Each worker owns a y-stripe plus its caustic source halo. Only the previous
  // max(dy)+1 softened rows must exist. Composition consumes one glint row before
  // it is reused, and can overwrite the edge field with its final emission pixel.
  void GlassStreamGlints(float[] seed,Action<int,float[]> composeRow){
   int[] dx=new int[9],dy=new int[9];double[] weight=new double[9];
   for(int k=0;k<9;k++){int step=k+1;dx[k]=GlassRound(step*glassSize*.004);dy[k]=GlassRound(step*glassSize*.055);weight[k]=Math.Exp(-step*.27);}
   int rows=dy[8]+1;
   GlassRows(GlassPainterWorkers,worker=>{
    int first=glassHeight*worker/GlassPainterWorkers,last=glassHeight*(worker+1)/GlassPainterWorkers;var glintRow=new float[glassWidth];
    using(var ring=new NativeArray<float>(rows*glassWidth,Allocator.Persistent,NativeArrayOptions.UninitializedMemory)){
     for(int y=Math.Max(0,first-dy[8]);y<first;y++)GlassSeedRow(ring,(y%rows)*glassWidth,seed,y);
     for(int y=first;y<last;y++){
      glassCancellation.ThrowIfCancellationRequested();
      GlassSeedRow(ring,(y%rows)*glassWidth,seed,y);
      for(int x=0;x<glassWidth;x++){
       double value=0;for(int k=0;k<9;k++)if(y>=dy[k])value+=ring[((y-dy[k])%rows)*glassWidth+Math.Max(0,x-dx[k])]*weight[k];
       glintRow[x]=(float)(value*.28);
      }
      composeRow(y,glintRow);
     }
    }
   });
  }
 }
}

#if UNITY_EDITOR
using System;
using System.Collections.Generic;

namespace MazeBiters.NativeStudy {
 [Serializable] public sealed class LevelPreparationWatchdogReport {
  public bool passed,allocationCounterAvailable;
  public int checks,failures,slowProgressSamples,retriesBeforeFailure;
  public long steadyAllocatedBytes,allocationCalibrationBytes;
  public string scope="Pure transition watchdog with deterministic clocks and actual progress-signature fields. Tests inactivity, slow healthy work, two retry attempts, the absolute 300-second bound, transition reset and steady allocations. This is not a browser loading-time or frame-rate measurement.";
  public List<string> issues=new List<string>();
 }
 public static class NativeLevelPreparationWatchdogValidation {
  static void Check(LevelPreparationWatchdogReport report,bool okay,string label){report.checks++;if(!okay){report.failures++;report.issues.Add(label);}}
  public static LevelPreparationWatchdogReport Run(){
   var r=new LevelPreparationWatchdogReport();
   try{
    var progress=new LevelPreparationProgress{scene=new object(),mazeTask=new object()};
    var watch=new LevelPreparationWatchdog();watch.Reset(0,progress);
    Check(r,watch.Observe(89.999,progress)==LevelPreparationWatchdogStatus.Waiting,"Unchanged work has the full 90-second inactivity allowance");
    Check(r,watch.Observe(90,progress)==LevelPreparationWatchdogStatus.Stalled,"Unchanged work stalls at exactly 90 seconds");

    // Reproduce the reported slow WebGL transition: uploads and then actual
    // scene steps continue beyond the old absolute 90-second attempt deadline.
    watch.Reset(0,progress);
    for(int second=1;second<=299;second++){
     if(second%40==0){if(second<=80)progress.packedUploads++;else if(second==120)progress.stage=3;else if(second<=200)progress.neonSteps++;else if(second==240)progress.primedSnakes++;else progress.passes++;}
     Check(r,watch.Observe(second,progress)==LevelPreparationWatchdogStatus.Waiting,"Healthy slow work at second "+second);r.slowProgressSamples++;
    }
    progress.index++;
    Check(r,watch.Observe(300,progress)==LevelPreparationWatchdogStatus.Deadline,"Even new work cannot extend the absolute transition deadline");

    // Every field is independently meaningful; no polling counter is used.
    for(int field=0;field<19;field++){
     var first=new LevelPreparationProgress();var changed=first;
     switch(field){
      case 0:changed.scene=new object();break;case 1:changed.mazeTask=new object();break;case 2:changed.publishingMaze=new object();break;case 3:changed.readyMaze=new object();break;
      case 4:changed.taskStatus++;break;case 5:changed.publicationStage++;break;case 6:changed.publicationOffset++;break;case 7:changed.stage++;break;case 8:changed.index++;break;
      case 9:changed.passes++;break;case 10:changed.primedSnakes++;break;case 11:changed.actors++;break;case 12:changed.snakes++;break;case 13:changed.neonSteps++;break;
      case 14:changed.packedUploads++;break;case 15:changed.flags=1;break;case 16:changed.flags=16;break;case 17:changed.flags=32;break;case 18:changed.cpuSteps++;break;
     }
     watch.Reset(0,first);
     Check(r,watch.Observe(89,changed)==LevelPreparationWatchdogStatus.Waiting,"Progress field "+field+" renews inactivity allowance");
     Check(r,watch.Observe(178.999,changed)==LevelPreparationWatchdogStatus.Waiting,"Progress field "+field+" permits another 89.999 seconds");
     Check(r,watch.Observe(179,changed)==LevelPreparationWatchdogStatus.Stalled,"Progress field "+field+" does not hide a later real stall");
    }

    watch.Reset(0,progress);int retries=0;bool terminal=false;
    foreach(double now in new[]{90.0,180.0,270.0}){
     Check(r,watch.Observe(now,progress)==LevelPreparationWatchdogStatus.Stalled,"Stalled attempt reaches its own inactivity deadline");
     if(retries>=2){terminal=true;break;}retries++;watch.RestartAttempt(now,progress);
    }
    r.retriesBeforeFailure=retries;
    Check(r,terminal&&retries==2,"A stalled transition fails after three attempts, with only two retries");
    watch.Reset(0,progress);watch.RestartAttempt(80,progress);watch.RestartAttempt(160,progress);progress.index++;
    Check(r,watch.Observe(240,progress)==LevelPreparationWatchdogStatus.Waiting,"A retry can continue making healthy progress");
    Check(r,watch.Observe(300,progress)==LevelPreparationWatchdogStatus.Deadline,"Retries do not reset the overall 300-second limit");

    // Gate calls Reset when either the world or TransitionAt changes. A fresh
    // transition must not inherit a previous timeout or progress identity.
    progress.scene=new object();watch.Reset(1000,progress);
    Check(r,watch.Observe(1089.999,progress)==LevelPreparationWatchdogStatus.Waiting,"A different transition receives a fresh inactivity allowance");
    Check(r,watch.Observe(1090,progress)==LevelPreparationWatchdogStatus.Stalled,"The new transition still detects a real stall");
    watch.Reset(1000000000,progress);progress.index++;
    Check(r,watch.Observe(1000000299,progress)==LevelPreparationWatchdogStatus.Waiting,"Long real-time clocks retain progress precision");
    Check(r,watch.Observe(1000000300,progress)==LevelPreparationWatchdogStatus.Deadline,"Long real-time clocks retain the hard deadline");

    // Repeated observations and changing value snapshots allocate no managed
    // objects. Calibrate the counter so an unsupported zero counter cannot pass.
    var method=typeof(GC).GetMethod("GetAllocatedBytesForCurrentThread",Type.EmptyTypes);
    if(method!=null){
     var allocated=(Func<long>)Delegate.CreateDelegate(typeof(Func<long>),method);long begin=allocated();var calibration=new byte[65536];GC.KeepAlive(calibration);r.allocationCalibrationBytes=allocated()-begin;r.allocationCounterAvailable=r.allocationCalibrationBytes>=65536;
     if(r.allocationCounterAvailable){
      watch.Reset(0,progress);for(int i=0;i<1000;i++){progress.neonSteps++;watch.Observe(i*.001,progress);}
      begin=allocated();for(int i=0;i<100000;i++){progress.publicationOffset++;watch.Observe(i*.001,progress);}r.steadyAllocatedBytes=allocated()-begin;
      Check(r,r.steadyAllocatedBytes==0,"Steady watchdog snapshots and observations allocate zero managed bytes");
     }
    }
   }catch(Exception error){r.failures++;r.issues.Add(error.ToString());}
   r.passed=r.failures==0;return r;
  }
 }
}
#endif

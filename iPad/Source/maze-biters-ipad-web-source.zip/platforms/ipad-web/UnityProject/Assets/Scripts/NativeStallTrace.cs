using System;
using System.Collections.Generic;
using System.Diagnostics;
namespace MazeBiters.NativeStudy {
 // Opt-in main-thread instrumentation. Disabled in ordinary play. Timings can
 // nest: an asset load belongs to its render stage, not additional frame time.
 public static class NativeStallTrace {
  [Serializable] public sealed class Span {public string name;public double ms;}
  public static bool Enabled;
  static readonly List<Span> spans=new List<Span>(64);
  public static long Stamp()=>Enabled?Stopwatch.GetTimestamp():0;
  public static double Ms(long stamp)=>(Stopwatch.GetTimestamp()-stamp)*1000.0/Stopwatch.Frequency;
  public static void Begin(){spans.Clear();Enabled=true;}
  public static void Add(string name,long stamp){if(Enabled)spans.Add(new Span{name=name,ms=Ms(stamp)});}
  public static Span[] End(){Enabled=false;return spans.ToArray();}
 }
}

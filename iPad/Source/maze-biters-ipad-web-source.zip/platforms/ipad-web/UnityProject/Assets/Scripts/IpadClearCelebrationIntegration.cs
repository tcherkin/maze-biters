using System;
using System.Collections.Generic;
namespace MazeBiters.NativeStudy {
 public sealed partial class NativeGameplayStudy {
  IpadClearCelebration clearCelebration;
  bool ClearCelebrationActive=>clearCelebration!=null&&ReferenceEquals(clearCelebration.World,world)&&world.Transition&&clearCelebration.Started==world.TransitionAt&&!preparingScene&&!preparingNextScene;
  double CreaturePresentationTime=>ClearCelebrationActive?clearCelebration.Time:time;
  List<NativeHunter> PresentedHunters=>ClearCelebrationActive?clearCelebration.Hunters:world.Hunters;
  NativeScorpion PresentedScorpion=>ClearCelebrationActive?clearCelebration.Scorpion:world.Scorpion;
  void AdvanceClearCelebration(){
   if(preparingScene||preparingNextScene)return;
   if(!IpadPresentation.Enabled||!world.Transition){clearCelebration=null;return;}
   if(!ClearCelebrationActive)clearCelebration=new IpadClearCelebration(world);
   double clock=time+(levelGateWaiting?levelGateExtraTime:0);
   clearCelebration.Advance(clock,(h,old,at)=>{
    if(old!=h.Dir&&actors.TryGetValue(h.Id,out var a))a.turn.Request(Bank(old),Bank(h.Dir),at);
   });
  }
 }
}

using UnityEngine;
namespace MazeBiters.NativeStudy {
 public sealed partial class NativeScorpionArt {
  // Call on an isolated preparation actor, never on a live moving ghost.
  public void Prepare(string quality){
   images.Prepare();
   var straight=new NativeScorpionMotion(new Vector2Int(3,3),new Vector2Int(2,3),Vector2Int.right,new Vector2Int(4,3),new Vector2Int(3,3),Vector2Int.right,1000,1000);
   var bent=new NativeScorpionMotion(new Vector2Int(3,3),new Vector2Int(2,3),Vector2Int.right,new Vector2Int(3,4),new Vector2Int(3,3),Vector2Int.up,1000,1000);
   foreach(var motion in new[]{straight,bent})for(int frame=0;frame<assets.frames.Length;frame++){
    var pose=motion.Sample(1085);pose.frame=frame;Render(pose,quality);
   }
   Graphics.Blit(Texture2D.blackTexture,raw);NativePreparation.Drain(raw);
   visible.enabled=false;
  }
 }
}

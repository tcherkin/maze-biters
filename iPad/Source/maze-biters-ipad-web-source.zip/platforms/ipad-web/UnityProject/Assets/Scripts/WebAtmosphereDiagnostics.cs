using System;using UnityEngine;
namespace MazeBiters.NativeStudy {
 public sealed partial class NativeGameplayStudy {
  string WebAtmosphereState(){
   if(!Application.absoluteURL.Contains("diagnostic=1"))return "null";
   return JsonUtility.ToJson(new WebAtmosphereSnapshot{seconds=levelAtmosphereSeconds,pulse=NativeLevelAtmosphere.Pulse(levelAtmosphereSeconds),halfCycleSeconds=NativeLevelAtmosphere.HalfCycleSeconds,streams=NativeLevelAtmosphere.ActiveStreams,routes=boundWallLightRoutes?.Count??0,stars=Shader.GetGlobalFloat("_MysticStarStrength"),depthBytes=levelAtmosphereDepth?levelAtmosphereDepth.width*levelAtmosphereDepth.height:0,correctMaze=boundAtmosphereArt==sceneMazeArt,receiver=crystalPaint&&crystalPaint.GetTexture("_MysticReceiver")==neon?.MysticWallReceiver,optimized=!NativeLevelAtmosphere.Reference,uploads=atmosphereUploads,skipped=atmosphereSkipped,routeEvaluations=boundWallLightRoutes?.Evaluations??0});
  }
  [Serializable]sealed class WebAtmosphereSnapshot {public string revision="20261107-living-levels",rendererRevision="20261108-eight-wall-lights";public double seconds,halfCycleSeconds;public float pulse,stars;public int streams,routes,depthBytes;public bool correctMaze,receiver,optimized;public long uploads,skipped,routeEvaluations;}
 }
}

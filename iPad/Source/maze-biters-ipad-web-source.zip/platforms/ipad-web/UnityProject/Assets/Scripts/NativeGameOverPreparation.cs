using System;
using System.IO;
using System.Threading.Tasks;
using UnityEngine;
namespace MazeBiters.NativeStudy {
 public sealed partial class NativeGameplayStudy {
  bool restartPreparing;
  uint restartSeed,restartRandom;
  int restartDifficulty,restartMode=1;
  void QueueGameOverPreparation(){
   if(!MenuOwner||menuPreparing||!world.GameOver||restartPreparing||
      Array.IndexOf(Environment.GetCommandLineArgs(),"--cold-menu-start")>=0)return;
   // Keep the completed world, its score and GAME OVER animation untouched.
   // Only the future world's CPU data crosses to the worker.
   CancelNextMaze();restartPreparing=true;restartDifficulty=difficultyIndex;restartMode=world.Mode;
   restartSeed=mazeSeed;
   if(!seedFixed){var bytes=new byte[4];using(var rng=System.Security.Cryptography.RandomNumberGenerator.Create())rng.GetBytes(bytes);restartSeed=BitConverter.ToUInt32(bytes,0);}
   uint seed=restartSeed;double difficulty=NativeMazeGenerator.Difficulties[restartDifficulty];
   string source=Path.Combine(WebFiles.Root,"Reference/maze-brushes"),artQuality=GlassQuality;
   nextMazeNumber=1;nextMazeTask=NativeMazeWorker.Run(()=>BuildMenuMaze(seed,difficulty,source,artQuality),out nextMazeCancellation);
  }
  public bool RestartPrepared=>restartPreparing&&nextScene?.ready==true;
 }
}


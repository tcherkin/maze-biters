using System;using System.Collections;using System.Collections.Generic;using System.IO;using System.Linq;using UnityEngine;using UnityEngine.Profiling;
namespace MazeBiters.NativeStudy {
 public sealed partial class NativeGameplayStudy {
  [Serializable] sealed class CameraProbeResult {public bool passed;public string quality,note;public int oracleChecks,frames;public long workingSet,privateBytes,unityUsed,liveSnakeSurfaceBytes;public string[] checks;}
  IEnumerator ProbeCamera(){
   sessionSmoke=true;var checks=new List<string>();int oracle=NativeCameraValidation.Run(),count=0;
   void Assert(bool ok,string message){if(!ok)throw new InvalidOperationException("Camera probe: "+message);checks.Add(message);}
   void Draw(){cameraFrame=-1;preparationLightFrame=true;Render();count++;}
   void Shot(string name){Capture(Path.ChangeExtension(report,null)+"-"+name+".png");}
   // Hold simulation fixed while testing presentation. This separates camera
   // transform errors from AI/contact changes. Existing session smoke advances
   // the real original world separately (death, intake, respawn, level change).
   Reset(0);yield return DrainProbePreparation();
   string state=ScalarClock(gameplayCamera);scenePreparationPending=true;PrepareSceneGpu();Assert(state==ScalarClock(gameplayCamera),"initial GPU preparation preserves camera clocks");
   Draw();Shot("full");long preparedBytes=snakes.Values.Sum(s=>s.art.SurfaceBytes);var expected=PreparationPixels(target);Draw();var repeated=PreparationPixels(target);Assert(expected.SequenceEqual(repeated),"repeat render at same clock is pixel-stable");
   for(int i=0;i<480;i++){realClock+=1000.0/120;Draw();if(i==120)Shot("opening");yield return null;}
   Assert(gameplayCamera.Zoom>1.97&&gameplayCamera.Zoom<=2,"stationary camera eases toward 2x");Assert(preparedBytes==snakes.Values.Sum(s=>s.art.SurfaceBytes),"opening zoom reuses prepared snake resolve surfaces");Shot("close");
   // Inverse Unity projection and pointer conversion must agree, including
   // the top 32-unit reserved header, corners and both output resolutions.
   for(int yy=0;yy<4;yy++)for(int xx=0;xx<4;xx++){
    double sx=10+xx*180,sy=10+yy*125;gameplayCamera.ScreenToWorld(sx,sy,out double wx,out double wy);
    var v=camera.WorldToViewportPoint(new Vector3((float)wx,(float)-wy,0));
    Assert(Math.Abs(v.x*576-sx)<.001&&Math.Abs((1-v.y)*432-32-sy)<.001,"projection/pointer "+xx+","+yy);
   }
   var baseQuality=quality;double z=gameplayCamera.Zoom,x=gameplayCamera.X,y=gameplayCamera.Y;
   quality=quality=="hd"?"4k":"hd";SetQuality();yield return DrainProbePreparation();Assert(z==gameplayCamera.Zoom&&x==gameplayCamera.X&&y==gameplayCamera.Y,"HD/4K switch preserves camera");
   quality=baseQuality;SetQuality();yield return DrainProbePreparation();Draw();Shot("quality-return");
   for(int i=0;i<240;i++){realClock+=1000.0/120;var p=world.Player;p.Cell=p.From=new Vector2Int(2+i/8,1);Draw();yield return null;}
   Assert(gameplayCamera.MotionZoom<1.9,"actual visual displacement opens motion framing");Shot("moving-edge");
   paused=true;for(int i=0;i<480;i++){realClock+=1000.0/120;Draw();yield return null;}
   Assert(gameplayCamera.Zoom<1.002&&gameplayCamera.Presentation,"pause reveals full board while game time is stopped");Shot("pause");paused=false;
   Reset(12);yield return DrainProbePreparation();Assert(gameplayCamera.Zoom==1,"campaign starts full board");
   // Keep the old player close enough to make a wrong preview follow obvious.
   for(int i=0;i<200;i++){realClock+=1000.0/120;Draw();yield return null;}
   world.Snakes.Clear();foreach(var s in snakes.Values)s.Dispose();snakes.Clear();world.CheckLevelComplete();
   for(int i=0;i<1200&&(nextScene==null||!nextScene.ready);i++){realClock+=1000.0/120;Draw();yield return null;}
   Assert(nextScene!=null&&nextScene.ready,"next scene prepared during LEVEL CLEARED");
   state=ScalarClock(gameplayCamera);var position=camera.transform.position;var size=camera.orthographicSize;
   WarmNextScene(nextScene);Assert(state==ScalarClock(gameplayCamera)&&position==camera.transform.position&&size==camera.orthographicSize,"future GPU preview preserves camera state and projection");
   while(nextScene.gpuPending&&!nextScene.gpuDone)yield return null;
   Draw();Shot("level-cleared");int hits=nextSceneHits;time=world.Time=world.TransitionAt+NativeGameplayWorld.ClearDuration;world.AdvanceLevel();
   Assert(nextSceneHits==hits+1&&world.Level==2&&gameplayCamera.Zoom==1&&gameplayCamera.X==288&&gameplayCamera.Y==200,"prefetched level adoption resets camera exactly once");Draw();Shot("next-level");
   NativeMemory.TryRead(out long ws,out _,out long committed);
   File.WriteAllText(report,JsonUtility.ToJson(new CameraProbeResult{passed=true,quality=quality,oracleChecks=oracle,frames=count,checks=checks.ToArray(),workingSet=ws,privateBytes=committed,unityUsed=Profiler.GetTotalAllocatedMemoryLong(),liveSnakeSurfaceBytes=snakes.Values.Sum(s=>s.art.SurfaceBytes),note="Functional GPU checks with deterministic camera clocks, not a foreground FPS/CPU benchmark. Fixed simulation in camera scenes; real simulation covered by session smoke. No browser source changed."},true));Application.Quit();
  }
 }
}

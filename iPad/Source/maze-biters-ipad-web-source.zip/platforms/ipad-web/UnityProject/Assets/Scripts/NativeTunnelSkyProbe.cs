using System;using System.Collections.Generic;using UnityEngine;
namespace MazeBiters.NativeStudy {
 public sealed partial class NativeGameplayStudy {
  static Texture2D ReadTunnelTexture(Texture texture){
   var previous=RenderTexture.active;var rt=RenderTexture.GetTemporary(texture.width,texture.height,0,RenderTextureFormat.ARGB32);
   try{Graphics.Blit(texture,rt);return DisplayRead(rt);}finally{RenderTexture.active=previous;RenderTexture.ReleaseTemporary(rt);}
  }
  void SetTunnelSkyVisible(bool visible){sessionArt.SetDistantSkyVisible(visible);mazePaint.SetFloat("_SkyVisibility",visible?NativeTunnelSky.StarVisibility:0);}
  void CheckTunnelSky(List<string> checks){
   void Check(bool ok,string message){if(!ok)throw new Exception("Tunnel sky GPU: "+message);checks.Add(message);}
   var before=new NativeMazeArtwork(currentGeneratedLevel,world.Level,starSky:false);
   Texture2D original=null,transparent=null,on=null,off=null;
   try{
    original=ReadTunnelTexture(before.Maze);transparent=ReadTunnelTexture(maze);var a=original.GetPixels32();var b=transparent.GetPixels32();
    int width=maze.width,height=maze.height,hue=NativeMazeGenerator.Hues[Array.IndexOf(NativeMazeGenerator.Themes,currentGeneratedLevel.theme)],dots=0,holes=0;
    bool wallExact=true,onlyDots=true,alphaValid=true;
    for(int y=0;y<height;y++)for(int x=0;x<width;x++){
     int top=height-1-y,cx=x/80,cy=top/80,index=y*width+x;bool wall=world.Grid[cy][cx]=='#';
     var p=a[index];var q=b[index];bool rgb=p.r!=q.r||p.g!=q.g||p.b!=q.b;
     if(wall){if(rgb||q.a!=255)wallExact=false;continue;}
     if(q.a<153)alphaValid=false;if(q.a<255)holes++;
     if(rgb){int hash=cx*73+cy*151+world.Level*19+hue*7,px=(3+hash%10)*5,py=(3+(hash>>4)%10)*5;
      onlyDots&=hash%6==0&&x%80>=px&&x%80<px+5&&top%80>=py&&top%80<py+5;dots++;
     }
    }
    Check(wallExact,"original opaque wall pixels and contours are unchanged");
    Check(onlyDots&&dots>0,"only baked floor microstars are removed from maze RGB");
    Check(alphaValid&&holes>100000,"40 percent tunnel transparency with opaque soft edges");
    // Only toggle the distant background; do not tick or rerender animation clocks.
    on=DisplayRead(target);SetTunnelSkyVisible(false);camera.Render();off=DisplayRead(target);
    var sky=on.GetPixels32();var black=off.GetPixels32();int revealed=0,wallChanges=0;var frame=DisplayFrame;
    for(int py=0;py<target.height;py++)for(int px=0;px<target.width;px++){
     float lx=(px+.5f)*frame.Width/target.width,ly=(target.height-py-.5f)*frame.Height/target.height;if(ly<32)continue;
     frame.WorldPoint(new Vector2(lx,ly),cameraViewX,cameraViewY,cameraViewZoom,out double wx,out double wy);
     if(wx<0||wy<0||wx>=576||wy>=400)continue;int cx=(int)(wx/16),cy=(int)(wy/16),i=py*target.width+px;
     int difference=Math.Max(Math.Abs(sky[i].r-black[i].r),Math.Max(Math.Abs(sky[i].g-black[i].g),Math.Abs(sky[i].b-black[i].b)));
     if(world.Grid[cy][cx]!='#'){if(difference>2)revealed++;}
     else if(wx%16>.5&&wx%16<15.5&&wy%16>.5&&wy%16<15.5&&difference>1)wallChanges++;
    }
    Check(revealed>50,"real distant stars are visible through rendered tunnels");
    Check(wallChanges==0,"background stars cannot shine through solid walls");
    CheckTunnelStarLighting(checks);
   }finally{
    SetTunnelSkyVisible(true);camera.Render();before.Discard();
    if(original)Destroy(original);if(transparent)Destroy(transparent);if(on)Destroy(on);if(off)Destroy(off);
   }
  }
  void CheckTunnelStarLighting(List<string> checks){
   // Difference-of-renders isolates sky radiance from the lit floor and actors.
   // Keep the world/camera/animation clock frozen while moving the actual beam.
   var saved=RenderTexture.GetTemporary(dusk.mask.width,dusk.mask.height,0,RenderTextureFormat.ARGB32);Graphics.Blit(dusk.mask,saved);var restoreClock=dusk.PreserveClock();
   (Color32[] stars,Color32[] floor) Sample(){
    SetTunnelSkyVisible(true);camera.Render();var lit=DisplayRead(target);var sky=lit.GetPixels32();Destroy(lit);
    SetTunnelSkyVisible(false);camera.Render();var unlit=DisplayRead(target);var floor=unlit.GetPixels32();Destroy(unlit);
    for(int i=0;i<sky.Length;i++)sky[i]=new Color32((byte)Math.Max(0,sky[i].r-floor[i].r),(byte)Math.Max(0,sky[i].g-floor[i].g),(byte)Math.Max(0,sky[i].b-floor[i].b),255);
    return(sky,floor);
   }
   try{
    dusk.Render(new Vector2(18,12),Vector2.right,0,true,true,0,true,0);var dark=Sample();int affectedStars=0,samples=0,max=0;long sum=0;var frame=DisplayFrame;
    for(int heading=0;heading<5;heading++){
     dusk.Render(new Vector2(18,12),new[]{Vector2.right,Vector2.down,Vector2.left,Vector2.up,Vector2.right}[heading],0,true,true,heading==4?1:0);
     var beam=Sample();
     for(int py=0;py<target.height;py++)for(int px=0;px<target.width;px++){
      float lx=(px+.5f)*frame.Width/target.width,ly=(target.height-py-.5f)*frame.Height/target.height;if(ly<32)continue;
      frame.WorldPoint(new Vector2(lx,ly),cameraViewX,cameraViewY,cameraViewZoom,out double wx,out double wy);
      if(wx<0||wy<0||wx>=576||wy>=400||world.Grid[(int)(wy/16)][(int)(wx/16)]=='#')continue;
      // Exclude local wall-reflection fringe, which remains unchanged on purpose.
      if(wx%16<2||wx%16>14||wy%16<2||wy%16>14)continue;
      int i=py*target.width+px;var a=dark.stars[i];var b=beam.stars[i];int error=Math.Max(Math.Abs(a.r-b.r),Math.Max(Math.Abs(a.g-b.g),Math.Abs(a.b-b.b)));
      max=Math.Max(max,error);sum+=error;samples++;
      var c=dark.floor[i];var d=beam.floor[i];if(Math.Max(a.r,Math.Max(a.g,a.b))>3&&Math.Max(Math.Abs(c.r-d.r),Math.Max(Math.Abs(c.g-d.g),Math.Abs(c.b-d.b)))>4)affectedStars++;
     }
    }
    Debug.Log("TUNNEL_STAR_LIGHTING max="+max+" mean="+(double)sum/Math.Max(1,samples)+" crossedStars="+affectedStars);
    if(max>3||sum/(double)Math.Max(1,samples)>.15||affectedStars<50)throw new Exception("Distant stars changed with flashlight: max="+max+" crossed="+affectedStars);
    checks.Add("distant star radiance is independent of all four flashlight headings and power mode");
    checks.Add("the flashlight still changes the actual tunnel floor beneath those stars");
   }finally{Graphics.Blit(saved,dusk.mask);RenderTexture.ReleaseTemporary(saved);restoreClock();SetTunnelSkyVisible(true);camera.Render();}
  }
 }
}

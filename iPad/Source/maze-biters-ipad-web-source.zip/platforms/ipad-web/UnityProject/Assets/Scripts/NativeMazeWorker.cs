using System;using System.Collections.Concurrent;using System.Threading;using System.Threading.Tasks;
namespace MazeBiters.NativeStudy {
 // One stable owner for large speculative CPU maps. The four existing scanline
 // workers remain parallel. Replaced jobs cancel cooperatively; no main-thread
 // waiting, texture creation, gameplay state or RNG crosses this boundary.
 public static class NativeMazeWorker {
  public static readonly bool Enabled=Array.IndexOf(Environment.GetCommandLineArgs(),"--legacy-lifetime-memory")<0;
  [ThreadStatic] static CancellationToken current;
  internal static CancellationToken CurrentToken=>current;
  static readonly BlockingCollection<Action> Jobs=new BlockingCollection<Action>();
  static readonly Lazy<Thread> Worker=new Lazy<Thread>(()=>{var thread=new Thread(()=>{foreach(var job in Jobs.GetConsumingEnumerable())job();}){IsBackground=true,Name="Maze CPU preparation"};thread.Start();return thread;});
  public static Task<T> Run<T>(Func<T> build,out CancellationTokenSource cancellation){
#if UNITY_WEBGL && !UNITY_EDITOR
   cancellation=new CancellationTokenSource();var token=cancellation.Token;
   return WebWorkQueue.Run(()=>{current=token;try{return build();}finally{current=default;}},token);
#else
   if(!Enabled){cancellation=null;return Task.Run(build);}
   cancellation=new CancellationTokenSource();var token=cancellation.Token;
   var result=new TaskCompletionSource<T>(TaskCreationOptions.RunContinuationsAsynchronously);var worker=Worker.Value;
   Jobs.Add(()=>{try{token.ThrowIfCancellationRequested();current=token;result.TrySetResult(build());}catch(OperationCanceledException){result.TrySetCanceled();}catch(Exception e){result.TrySetException(e);}finally{current=default;}});
   return result.Task;
#endif
  }
 }
}

using System;using System.Collections.Generic;using System.Diagnostics;
namespace MazeBiters.NativeStudy {
 // Optional process-memory diagnostics; safe to call from the material worker.
 // Never calls Unity APIs, collects garbage or retains a texture/resource.
 public static class NativeGlassPeakTrace {
  public static readonly bool Enabled=Array.IndexOf(Environment.GetCommandLineArgs(),"--peak-memory-probe")>=0;
  [Serializable] public sealed class Sample {public string stage;public double ms;public long working,processLifetimePeak,privateBytes;}
  static readonly object Gate=new object();static readonly List<Sample> Samples=new List<Sample>(256);
  static readonly Stopwatch Clock=Stopwatch.StartNew();
  public static void Mark(string stage){NativeLifetimeMemoryProbe.MainThreadCheckpoint();if(!Enabled)return;if(!NativeMemory.TryRead(out var working,out var peak,out var committed))return;
   lock(Gate){if(Samples.Count<256)Samples.Add(new Sample{stage=stage,ms=Clock.Elapsed.TotalMilliseconds,working=working,processLifetimePeak=peak,privateBytes=committed});}
  }
  public static Sample[] Snapshot(){lock(Gate)return Samples.ToArray();}
 }
}

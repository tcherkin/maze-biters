using System;
using System.Collections.Generic;
using UnityEngine;
namespace MazeBiters.NativeStudy {
 public sealed partial class NativeMazeArtwork {
  public const double CoreGlassBodyOpacity=.90;
  CrystalOuterSample gemBody,gemReverse,gemDeep,gemSpecular,gemHotSpecular;
  Color32 gemEnvironmentCatch;
  const int GemBevelAlong=128,GemBevelDepth=64;
  Color32[] gemBevelTopRgb,gemBevelTopLight,gemBevelLowerRgb,gemBevelLowerLight;
  static double GemPeak(CrystalOuterSample p)=>Math.Max(p.er,Math.Max(p.eg,p.eb));
  static CrystalOuterSample GemAdd(CrystalOuterSample a,CrystalOuterSample b)=>new CrystalOuterSample{r=a.r+b.r,g=a.g+b.g,b=a.b+b.b,er=a.er+b.er,eg=a.eg+b.eg,eb=a.eb+b.eb};
  static CrystalOuterSample GemGain(CrystalOuterSample p,double gain)=>new CrystalOuterSample{r=p.r*gain,g=p.g*gain,b=p.b*gain,er=p.er*gain,eg=p.eg*gain,eb=p.eb*gain};
  // Calibrate a material, not a stretched strip texture: all broad faces share
  // the same clean authored glass substance. Atlas micro-shading is averaged.
  void PrepareGemCoreMaterial(byte[] wall,float[] emission){
   if(!crystalCores)return;
   int scale=glassSize/80;
   OuterCrystalMaterial=new CrystalOuterMaterialAudit{theme=Theme,quality=GlassQuality,topMin=20*scale,topMax=30*scale,bottomMin=52*scale,bottomMax=58*scale};
   // Integrate the whole safe native band. A sparse grid can alias the narrow
   // authored 4K glints and accidentally make its material duller than HD.
   var samples=new List<CrystalOuterSample>((28*scale+1)*(16*scale+2));var top=new CrystalOuterSample();var lower=new CrystalOuterSample();int nt=0,nl=0;
   for(int x=6*scale;x<=34*scale;x++){
    for(int y=20*scale;y<=30*scale;y++){var p=SampleCrystalOuter(wall,emission,x,y,false);samples.Add(p);top=GemAdd(top,p);nt++;}
    for(int y=52*scale;y<=58*scale;y++){var p=SampleCrystalOuter(wall,emission,x,y,true);samples.Add(p);lower=GemAdd(lower,p);nl++;}
   }
   top=GemGain(top,1.0/nt);lower=GemGain(lower,1.0/nl);
   samples.Sort((a,b)=>GemPeak(a).CompareTo(GemPeak(b)));
   gemBody=CrystalMix(top,lower,.28);gemReverse=lower;
   gemDeep=samples[(int)Math.Floor((samples.Count-1)*.25)];
   gemSpecular=samples[(int)Math.Floor((samples.Count-1)*.95)];
   gemHotSpecular=samples[(int)Math.Floor((samples.Count-1)*.99)];
   if(GemPeak(gemHotSpecular)>.52)gemHotSpecular=GemGain(gemHotSpecular,.52/GemPeak(gemHotSpecular));
   // A tiny neutral environmental reflection is calibrated from an authored
   // near-white highlight on corner6. It is NOT claimed as an outer-body band,
   // and its RGB alone is used: no luminous-channel emission enters the body.
   gemEnvironmentCatch=new Color32(220,225,230,255);double best=-1;
   for(int y=29*scale;y<=33*scale;y++)for(int x=30*scale;x<=34*scale;x++){
    int at=(y*16*glassSize+6*glassSize+x)*4;if(wall[at+3]<240)continue;
    double lo=Math.Min(wall[at],Math.Min(wall[at+1],wall[at+2])),hi=Math.Max(wall[at],Math.Max(wall[at+1],wall[at+2]));
    double score=lo-(hi-lo)*.5;if(score<=best)continue;best=score;gemEnvironmentCatch=new Color32(wall[at],wall[at+1],wall[at+2],255);
   }
   // Conservative analytic surface bound; avoids racy max updates while the
   // independent composition rows are prepared in parallel.
   OuterCrystalMaterial.maxEmissionSurface=.62;
   // The actual outer glass profile is copied only onto the narrow physical
   // bevel. The broad planar faces above retain their layered clean glazing.
   int length=GemBevelAlong*GemBevelDepth;
   gemBevelTopRgb=new Color32[length];gemBevelTopLight=new Color32[length];gemBevelLowerRgb=new Color32[length];gemBevelLowerLight=new Color32[length];
   for(int y=0;y<GemBevelDepth;y++)for(int x=0;x<GemBevelAlong;x++){
    double along=x/(double)(GemBevelAlong-1),depth=y/(double)(GemBevelDepth-1),sx=(6+28*along)*scale;int at=y*GemBevelAlong+x;
    var upper=SampleCrystalOuter(wall,emission,sx,(20+10*depth)*scale,false);
    var reverse=SampleCrystalOuter(wall,emission,sx,(58-6*depth)*scale,true);
    gemBevelTopRgb[at]=new Color32(Byte(upper.r),Byte(upper.g),Byte(upper.b),255);gemBevelTopLight[at]=new Color32(Byte(upper.er*255),Byte(upper.eg*255),Byte(upper.eb*255),255);
    gemBevelLowerRgb[at]=new Color32(Byte(reverse.r),Byte(reverse.g),Byte(reverse.b),255);gemBevelLowerLight[at]=new Color32(Byte(reverse.er*255),Byte(reverse.eg*255),Byte(reverse.eb*255),255);
   }
  }
  void ReleaseGemCoreMaterialStaging(){gemBevelTopRgb=gemBevelTopLight=gemBevelLowerRgb=gemBevelLowerLight=null;}
  static CrystalOuterSample GemBevelTexel(Color32[] rgb,Color32[] emission,int at){var p=rgb[at];var e=emission[at];return new CrystalOuterSample{r=p.r,g=p.g,b=p.b,er=e.r/255.0,eg=e.g/255.0,eb=e.b/255.0};}
  CrystalOuterSample GemBevelLookup(Color32[] rgb,Color32[] emission,double u,double v){
   double sx=GlassClamp(u)*(GemBevelAlong-1),sy=GlassClamp(v)*(GemBevelDepth-1);int x=(int)sx,y=(int)sy,x1=Math.Min(x+1,GemBevelAlong-1),y1=Math.Min(y+1,GemBevelDepth-1);
   var a=CrystalMix(GemBevelTexel(rgb,emission,y*GemBevelAlong+x),GemBevelTexel(rgb,emission,y*GemBevelAlong+x1),sx-x);
   var b=CrystalMix(GemBevelTexel(rgb,emission,y1*GemBevelAlong+x),GemBevelTexel(rgb,emission,y1*GemBevelAlong+x1),sx-x);
   return CrystalMix(a,b,sy-y);
  }
  static double GemWorldAlong(double coordinate){double turn=coordinate-Math.Floor(coordinate/2)*2;return turn<=1?turn:2-turn;}
  // facet UV is the WHOLE component. Its one broad reflected window crosses
  // the panel collection continuously; it never restarts on each small tile.
  void GemCorePixel(int x,int y,CrystalFacetSample facet,ref Color32 maze,ref Color32 light){
   double u=GlassClamp(facet.u),v=GlassClamp(facet.v),rawDistance=Math.Max(0,facet.distance);
   // Each tile stops before the measured joint. The black smoked gap exposes
   // the same distant sky as the floor; neither reflection nor emission bridges it.
   double tileCoverage=GlassSmooth(.0085*glassSize,.012*glassSize,rawDistance);
   if(tileCoverage<=0){maze=new Color32(0,0,0,64);light=new Color32(0,0,0,0);return;}
   double distance=Math.Max(0,rawDistance-.012*glassSize);
   double facing=GlassClamp(.5+.5*(.65*facet.nx+.76*facet.ny));
   double plane=.68*u+.53*v;
   // A broad, palette-tinted reflected field softly rolls through the glass.
   // No narrow white window-edge or displaced diagonal streak is drawn across
   // the tiles; their own polished rims retain the precise specular detail.
   double window=GlassSmooth(.08,.30,plane)*(1-GlassSmooth(.40,.70,plane));
   double echo=GlassSmooth(.17,.39,plane)*(1-GlassSmooth(.49,.79,plane));
   // A deep coloured substrate below a clear reflected window. The displaced
   // darker echo reads as thickness beneath the polished top surface.
   var face=CrystalMix(gemBody,gemReverse,.15+.20*v);
   face=GemGain(face,(.54+.10*(1-v)+.025*u)*(1-.10*echo*(1-window)));
   // Quiet coloured volume below a reflective coating, rather than a uniformly
   // luminous plastic panel. The authored palette and calibration stay intact.
   face.er*=.80;face.eg*=.80;face.eb*=.80;
   face=CrystalMix(face,gemSpecular,.035+.18*window);
   // Slimmer glass edge, with the original curved optical profile inside it.
   // Rounded geometry supplies a continuous normal through each tile corner.
   double width=.060*glassSize,joint=.0045*glassSize;
   double progress=GlassClamp((distance-joint)/Math.Max(1,width-joint));
   double profileDepth=progress*progress*(3-2*progress);
   double bevelAmount=1-GlassSmooth(width-.018*glassSize,width+.018*glassSize,distance);
   double sourcePolish=1;
   if(bevelAmount>0){
    CrystalOuterSample front,reverse;
    if(facet.authoredCurve||facet.roundedCorner){
     // A rounded normal changes continuously. Blend the two world-oriented
     // optical profiles with it instead of switching UV axes at 45 degrees.
     double alongX=GemWorldAlong((x+.5)/glassSize),alongY=GemWorldAlong((y+.5)/glassSize);
     double nx2=facet.nx*facet.nx,ny2=facet.ny*facet.ny,axisWeight=nx2/Math.Max(1e-12,nx2+ny2);
     front=CrystalMix(GemBevelLookup(gemBevelTopRgb,gemBevelTopLight,alongX,profileDepth),GemBevelLookup(gemBevelTopRgb,gemBevelTopLight,alongY,profileDepth),axisWeight);
     reverse=CrystalMix(GemBevelLookup(gemBevelLowerRgb,gemBevelLowerLight,alongX,profileDepth),GemBevelLookup(gemBevelLowerRgb,gemBevelLowerLight,alongY,profileDepth),axisWeight);
    }else{
     double along=GemWorldAlong((Math.Abs(facet.nx)>Math.Abs(facet.ny)?y+.5:x+.5)/glassSize);
     front=GemBevelLookup(gemBevelTopRgb,gemBevelTopLight,along,profileDepth);
     reverse=GemBevelLookup(gemBevelLowerRgb,gemBevelLowerLight,along,profileDepth);
    }
    var profile=CrystalMix(reverse,front,.20+.70*facing);
    // Carry the authored glass's local specular variation into the coating.
    // This adds no random flecks and does not invent another per-tile pattern.
    sourcePolish=GlassSmooth(.60,1.25,GemPeak(profile)/Math.Max(.04,GemPeak(gemSpecular)));
    var cut=GemGain(profile,.85+.35*facing);
    cut=CrystalMix(cut,gemHotSpecular,.04*window);face=CrystalMix(face,cut,bevelAmount);
   }
   // One etched joint, even at crossings; no accumulated mortar or pillow rim.
   double etched=1-GlassSmooth(.0015*glassSize,.0060*glassSize,distance);
   face=GemGain(face,1-.24*etched);
   // Keep the polished line about one native HD texel wide. A much narrower
   // point-sampled line disappears between texels instead of looking glossy.
   double innerCatch=GlassClamp(1-Math.Abs(distance-width)/(.010*glassSize));
   double outerCatch=GlassClamp(1-Math.Abs(distance-.008*glassSize)/(.012*glassSize));
   // One readable polished outer lip, with a subdued inner return rather than
   // two equally strong nested frames. Its local brightness follows the same
   // authored optical profile as the surrounding wall segments.
   double grazing=facing*facing;
   double catchAmount=GlassClamp(.010*window
    +innerCatch*(.015+.24*grazing)*(.35+.65*window)*(.65+.35*sourcePolish)
    +outerCatch*(.025+.62*grazing)*(.60+.40*sourcePolish),0,.85);
   double cr=gemEnvironmentCatch.r*.97,cg=gemEnvironmentCatch.g,cb=Math.Min(255,gemEnvironmentCatch.b*1.035);
   double r=face.r+(cr-face.r)*catchAmount,g=face.g+(cg-face.g)*catchAmount,b=face.b+(cb-face.b)*catchAmount;
   double er=Math.Min(.62,face.er+cr/255.0*catchAmount*.72),eg=Math.Min(.62,face.eg+cg/255.0*catchAmount*.72),eb=Math.Min(.62,face.eb+cb/255.0*catchAmount*.72);
   byte Join(byte panel,byte original,double amount)=>Byte(panel+original*amount*(1-panel/255.0));
   // A slightly transmitting face beneath a denser polished glass edge. Keep
   // the soft joint premultiplied correctly; lowering alpha alone would merely
   // add sky over an unchanged opaque material instead of transmitting it.
   double surfaceAlpha=CoreGlassBodyOpacity+(1-CoreGlassBodyOpacity)*bevelAmount;
   double alpha=(64+(255*surfaceAlpha-64)*tileCoverage)/255.0;
   double edge=surfaceAlpha*tileCoverage/alpha;
   maze=new Color32(Byte(Join(Byte(r),maze.r,.12)*edge),Byte(Join(Byte(g),maze.g,.12)*edge),Byte(Join(Byte(b),maze.b,.12)*edge),Byte(alpha*255));
   light=new Color32(Join(Byte(er*255),light.r,.25),Join(Byte(eg*255),light.g,.25),Join(Byte(eb*255),light.b,.25),Byte(255*tileCoverage));
   // Quantization can round a tiny feather sample to the exact black gap
   // colour. Keep that texel unambiguously non-emissive as well.
   if(maze.r==0&&maze.g==0&&maze.b==0&&maze.a==64)light=new Color32(0,0,0,0);
  }
 }
}

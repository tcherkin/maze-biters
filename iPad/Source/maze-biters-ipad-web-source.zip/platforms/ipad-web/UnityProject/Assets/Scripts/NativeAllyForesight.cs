using System;
using UnityEngine;
namespace MazeBiters.NativeStudy {
 public struct NativeAllyForesightSample {
  public double risk,interceptRisk,pocketRisk,exitArrivalMs,returnMs;
  public bool pocket,lethal;public int expanded;public string reason;
 }
 public sealed partial class NativeAllyBrain {
#if UNITY_EDITOR
  public bool DisablePredictivePlanning;
#endif
  bool PredictivePlanning=>!w.UseLegacyAi&&Balance.Maximum
#if UNITY_EDITOR
   &&!DisablePredictivePlanning
#endif
   ;
  readonly NativeAllyThreatForecast foresight=new NativeAllyThreatForecast();
  bool foresightReady;NativePlayer foresightPlayer;double foresightTime;
  NativeGameplaySnake forecastCutSnake;int forecastCutIndex;
  bool[] forecastFloor;int[] pocketSeen,pocketQueue,pocketDepth;int pocketStamp;
  const int ForecastSteps=10,ForecastBeam=16;
  struct FutureStep {public Vector2Int cell,previous;public double peak,sum,rank;public NativeCreature consumed;}
  readonly FutureStep[] futureA=new FutureStep[ForecastBeam],futureB=new FutureStep[ForecastBeam];
  readonly double[] futureTime=new double[ForecastSteps+1],futureDelay=new double[ForecastSteps+1];
  readonly NativeAllyForesightSample[] directionForecast=new NativeAllyForesightSample[4];
  public void Plan(NativePlayer p,double t){
   if(p==null||!p.IsAI||p.Dead)return;
   foresightReady=false;
   if(PredictivePlanning)PrepareForesight(p,t);
   PlanCore(p,t);
   if(foresightReady&&!p.Waiting)ReviewForesight(p,t);
  }
  void PrepareForesight(NativePlayer p,double t){
   int n=w.Width*w.Height;
   if(forecastFloor==null||forecastFloor.Length!=n){forecastFloor=new bool[n];pocketSeen=new int[n];pocketQueue=new int[n];pocketDepth=new int[n];pocketStamp=0;}
   for(int i=0;i<n;i++)forecastFloor[i]=w.Floor(new Vector2Int(i%w.Width,i/w.Width));
   foreach(var c in w.SolidEggs)if(w.Floor(c))forecastFloor[w.Index(c)]=false;
   foreach(var egg in w.Eggs)if(t-egg.Born>=10000&&!w.EggCovered(egg)&&w.Floor(egg.Cell))forecastFloor[w.Index(egg.Cell)]=false;
   futureTime[0]=0;for(int i=0;i<=ForecastSteps;i++){futureDelay[i]=PredictPlayerDelay(p,t+futureTime[i]);if(i<ForecastSteps)futureTime[i+1]=futureTime[i]+futureDelay[i];}
   foresight.Build(w,p,t,2400);foresightPlayer=p;foresightTime=t;foresightReady=true;
  }
  static double PredictPlayerDelay(NativePlayer p,double t){
   if(p.PowerUntil<=t)return 95;
   double elapsed=Math.Max(0,t-p.RampAt),duration=Math.Max(1,p.RampDuration==0?1000:p.RampDuration),strength;
   if(elapsed<duration){double u=elapsed/duration;strength=p.RampFrom+(1-p.RampFrom)*(1-(1-u)*(1-u));}
   else if(p.PowerUntil-t<3000){double u=(p.PowerUntil-t)/3000;strength=1-(1-u)*(1-u);}
   else strength=1;
   return 95/(1+strength);
  }
  bool FutureFloor(Vector2Int c)=>c.x>=0&&c.y>=0&&c.x<w.Width&&c.y<w.Height&&forecastFloor[w.Index(c)];
  AllyObjective ContactObjective(NativePlayer p,Vector2Int d,double t){
   var c=p.Cell+d;
   foreach(var snake in w.Snakes){int i=snake.Body.IndexOf(c);if(i>=0)return new AllyObjective{snake=snake,target=c,kind=i==0?"head":i==snake.Body.Count-1?"tail":"split",bodyIndex=i,immediate=true,dir=d};}
   if(Combat(p,t))foreach(var hunter in w.Hunters)if(hunter.Cell==c)return new AllyObjective{hunter=hunter,target=c,kind="hunter",immediate=true,dir=d};
   var other=w.TeammateAt(p,c);if(other!=null&&S(p).directive?.type=="hunt"&&S(p).directive.target==other)return new AllyObjective{player=other,target=c,kind="player",immediate=true,dir=d};
   return null;
  }
  NativeCreature RemovedByContact(NativePlayer p,AllyObjective contact,double t){
   if(contact?.kind=="head")return contact.snake;
   if(contact?.hunter!=null&&Combat(p,t))return contact.hunter;
   if(contact?.player!=null&&w.CanEatPlayer(p,contact.player,t))return contact.player;
   return null;
  }
  double ImmediateProtection(Vector2Int c){foreach(var fruit in w.Fruits)if(fruit.Cell==c)return 7000;return 0;}
  double FutureRisk(Vector2Int c,int depth,NativeCreature removed,double acquiredProtection){
   double risk=foresight.Risk(c,futureTime[depth],futureDelay[depth],removed,acquiredProtection);
   if(forecastCutSnake!=null)risk=Math.Max(risk,foresight.RiskAfterContact(forecastCutSnake,forecastCutIndex,c,futureTime[depth],futureDelay[depth],acquiredProtection));
   return risk;
  }
  // A bounded time-expanded beam asks whether there is a survivable continuation,
  // not whether every possible enemy branch can occupy every cell at once.
  double ContinuationRisk(Vector2Int first,Vector2Int origin,NativeCreature removed,Vector2Int? target,double acquiredProtection,out int expanded){
   var current=futureA;var next=futureB;int count=1;expanded=0;
   double initial=FutureRisk(first,0,removed,acquiredProtection);
   current[0]=new FutureStep{cell=first,previous=origin,peak=initial,sum=initial,consumed=removed};
   double best=initial;
   for(int depth=1;depth<ForecastSteps;depth++){
    int written=0;
    for(int i=0;i<count;i++)foreach(var d in dirs){
     var c=current[i].cell+d;if(!FutureFloor(c))continue;
     // Assess the corridor we are actually entering. Calling every approach
     // safe because it can immediately undo itself hides future interception
     // and creates repeated advance/reverse decisions at a dangerous junction.
     if(depth<=4&&c==current[i].previous){
      bool reassessMeal=false;
      // Close to an edible head, its next observed movement becomes a new
      // decision point. Permit reassessment there instead of either inventing
      // a future kill or blindly forcing four steps through moving prey.
      foreach(var snake in w.Snakes){var approach=snake.Head-current[i].cell;if(Man(current[i].cell,snake.Head)==1&&(snake.Body.Count==1?approach!=-snake.Dir:approach==snake.Dir)){reassessMeal=true;break;}}
      bool onward=false;foreach(var nd in dirs)if(current[i].cell+nd!=current[i].previous&&FutureFloor(current[i].cell+nd)){onward=true;break;}if(onward&&!reassessMeal)continue;
     }
     expanded++;
     var consumed=current[i].consumed;
     // Preserve the consequence of a legal meal in the branch. Otherwise a
     // safely swallowed head keeps chasing us in its own forecast afterwards.
     foreach(var snake in w.Snakes)if(snake.Head==c&&futureTime[depth]<=Math.Max(0,snake.LastMove+(snake.Reversing?436:218)-foresightTime)&&(snake.Body.Count==1?d!=-snake.Dir:d==snake.Dir)&&(snake.Body.Count==1||Math.Max(foresightPlayer.PowerUntil,foresightPlayer.ShieldUntil)<=foresightTime+futureTime[depth]&&acquiredProtection<=futureTime[depth])){consumed=snake;break;}
     double risk=FutureRisk(c,depth,consumed,acquiredProtection),peak=Math.Max(current[i].peak,risk),sum=current[i].sum+risk;
     // Risk dominates, while a tiny progress/tie preference prevents a safe food
     // route losing every beam slot to equivalent backwards oscillations.
     double rank=peak+sum*.015+(c==current[i].previous?.006:0)+(target.HasValue?Math.Min(30,Man(c,target.Value))*.0002:0);
     int duplicate=-1;for(int j=0;j<written;j++)if(next[j].cell==c&&next[j].consumed==consumed){duplicate=j;break;}
     if(duplicate>=0){if(next[duplicate].rank<=rank)continue;for(int j=duplicate;j<written-1;j++)next[j]=next[j+1];written--;}
     int slot=written;while(slot>0&&next[slot-1].rank>rank)slot--;
     if(slot>=ForecastBeam)continue;int last=Math.Min(written,ForecastBeam-1);for(int j=last;j>slot;j--)next[j]=next[j-1];
     next[slot]=new FutureStep{cell=c,previous=current[i].cell,peak=peak,sum=sum,rank=rank,consumed=consumed};if(written<ForecastBeam)written++;
    }
    if(written==0)return Math.Max(best,.95);
    best=next[0].peak;var swap=current;current=next;next=swap;count=written;
   }
   return best;
  }
  void PocketRisk(NativePlayer p,Vector2Int first,Vector2Int? target,NativeCreature removed,double acquiredProtection,ref NativeAllyForesightSample result){
   if(pocketStamp==int.MaxValue){Array.Clear(pocketSeen,0,pocketSeen.Length);pocketStamp=0;}int stamp=++pocketStamp;
   int read=0,write=1,maxDepth=1,targetDepth=0;bool alternate=false;
   int start=w.Index(first);pocketQueue[0]=start;pocketDepth[start]=1;pocketSeen[start]=stamp;pocketSeen[w.Index(p.Cell)]=stamp;
   while(read<write&&write<=64){
    int key=pocketQueue[read++];var c=new Vector2Int(key%w.Width,key/w.Width);int depth=pocketDepth[key];maxDepth=Math.Max(maxDepth,depth);
    if(target.HasValue&&target.Value==c)targetDepth=depth;
    if(c!=first&&Man(c,p.Cell)==1){alternate=true;break;}
    foreach(var d in dirs){var n=c+d;if(!FutureFloor(n))continue;int k=w.Index(n);if(pocketSeen[k]==stamp)continue;pocketSeen[k]=stamp;pocketDepth[k]=depth+1;pocketQueue[write++]=k;}
   }
   if(alternate||write>64)return;
   result.pocket=true;
   // An alternative opening into a room is an escape, not a proposed round
   // trip back to the endangered cell. Only budget a return for food inside.
   if(target.HasValue&&targetDepth==0)return;
   int depthToVisit=targetDepth>0?targetDepth:Math.Min(3,maxDepth);
   // Eating a tail often continues toward its head. Budget that visible return
   // route as well, rather than declaring the first tasty segment an escape.
   if(targetDepth>0)foreach(var snake in w.Snakes)if(snake.Body.Contains(target.Value))foreach(var c in snake.Body)if(FutureFloor(c)&&pocketSeen[w.Index(c)]==stamp)depthToVisit=Math.Max(depthToVisit,Math.Min(targetDepth+6,pocketDepth[w.Index(c)]));
   double elapsed=0;for(int i=0;i<Math.Min(40,depthToVisit*2);i++)elapsed+=PredictPlayerDelay(p,foresightTime+elapsed);
   result.returnMs=elapsed;result.exitArrivalMs=foresight.DangerousArrival(p.Cell,0,elapsed+95,removed,acquiredProtection);
   if(double.IsInfinity(result.exitArrivalMs)||result.exitArrivalMs>elapsed+95)return;
   // Arrival is a possibility, not an omniscient future. It becomes a serious
   // trap only when a live threat can reach the sole gate before the return.
   double margin=elapsed-result.exitArrivalMs;
   result.pocketRisk=Math.Min(.94,.58+Math.Max(0,margin)/Math.Max(190,elapsed)*.32);
  }
  NativeAllyForesightSample EvaluateForesight(NativePlayer p,double t,Vector2Int d,Vector2Int? target){
   var first=p.Cell+d;var result=new NativeAllyForesightSample{exitArrivalMs=double.PositiveInfinity};
   if(!FutureFloor(first)||!SafeRoute(p,first,t)){result.lethal=true;result.risk=1;result.reason="blocked";return result;}
   var contact=ContactObjective(p,d,t);
   if(Collision(p,d,first,t,contact)>=100000){result.lethal=true;result.risk=1;result.reason="contact";return result;}
   var removed=RemovedByContact(p,contact,t);double acquired=ImmediateProtection(first);
   forecastCutSnake=contact?.snake!=null&&(contact.kind=="split"||contact.kind=="head"&&contact.snake.Body.Count>1&&Combat(p,t))?contact.snake:null;
   forecastCutIndex=contact?.kind=="head"?0:contact?.bodyIndex??0;
   result.interceptRisk=ContinuationRisk(first,p.Cell,removed,target,acquired,out result.expanded);
   PocketRisk(p,first,target,removed,acquired,ref result);
   result.risk=Math.Max(result.interceptRisk,result.pocketRisk);
   result.reason=result.pocketRisk>result.interceptRisk?"exit-interception":"route-interception";return result;
  }
  public NativeAllyForesightSample InspectForesight(NativePlayer p,double t,Vector2Int d,Vector2Int? target=null){PrepareForesight(p,t);return EvaluateForesight(p,t,d,target);}
  // Cheap objective guidance uses the same gate race. The full continuation
  // search runs only once per legal first direction after the original planner.
  double ObjectiveForesightRisk(NativePlayer p,double t,AllyObjective o,short[] field){
   if(!foresightReady||foresightPlayer!=p)return 0;
   int here=field[w.Index(p.Cell)];double best=1;bool found=false;
   foreach(var d in dirs){var c=p.Cell+d;if(!FutureFloor(c)||field[w.Index(c)]<0||field[w.Index(c)]>=here)continue;
    var result=new NativeAllyForesightSample();var contact=ContactObjective(p,d,t);if(Collision(p,d,c,t,contact)>=100000)continue;
    var removed=RemovedByContact(p,contact,t);double acquired=ImmediateProtection(c);
    PocketRisk(p,c,o.target,removed,acquired,ref result);
    double risk=Math.Max(result.pocketRisk,foresight.Risk(c,0,futureDelay[0],removed,acquired));best=Math.Min(best,risk);found=true;
   }
   return found?best:0;
  }
  void ReviewForesight(NativePlayer p,double t){
   var a=S(p);Vector2Int? target=w.Floor(a.thoughtTarget)?(Vector2Int?)a.thoughtTarget:null;
   int original=Array.IndexOf(dirs,p.Next),best=-1;double bestScore=double.PositiveInfinity;
   for(int i=0;i<dirs.Length;i++){
    var sample=EvaluateForesight(p,t,dirs[i],target);directionForecast[i]=sample;if(sample.lethal)continue;
    var c=p.Cell+dirs[i];double immediate=Danger(p,dirs[i],c,t);
    double score=sample.risk+(immediate>=105?1:0)+(i==original?-.045:0);
    if(target.HasValue){double distance=Distance(c,target.Value);if(Finite(distance))score+=Math.Min(30,distance)*.0005;}
    if(score<bestScore){bestScore=score;best=i;}
   }
   if(original<0||best<0)return;
   var before=directionForecast[original];var after=directionForecast[best];a.foresightRisk=before.risk;a.foresightChosenRisk=after.risk;a.foresightReason=before.reason;a.foresightExpanded=foresight.ExpandedStates;
   if(best==original||before.risk<.55||before.risk-after.risk<.14)return;
   // Do not trade an uncertain future for a known immediate lethal/near-mouth move.
   if(Danger(p,dirs[best],p.Cell+dirs[best],t)>=105&&Danger(p,p.Next,p.Cell+p.Next,t)<105)return;
   var rejected=a.locked;if(rejected!=null){a.cooldowns[rejected]=t+950;a.locked=null;a.bitten=false;a.split=null;a.commitMode=a.targetKind=null;a.graded=null;a.snakeChoiceUntil=0;}
   ClearRetreat(p);Choose(p,dirs[best],t);Thought(p,"anticipate-"+before.reason,p.Cell+dirs[best],after.risk*100,before.risk-after.risk);
  }
 }
}

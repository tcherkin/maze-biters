#if UNITY_EDITOR
using System;
using System.Collections.Generic;
using System.Diagnostics;
using UnityEngine;

namespace MazeBiters.NativeStudy {
 [Serializable] public sealed class IpadExitCameraCheck {public string name,detail;public bool passed;}
 [Serializable] public sealed class IpadExitCameraReport {
  public bool passed;public int assertions,failures,samples;public double elapsedMs;
  public string scope;
  public List<IpadExitCameraCheck> checks=new List<IpadExitCameraCheck>();
 }

 // Controlled presentation-time samples, without a running scene, graphics,
 // gameplay ticks or altered readiness. This is not a device/FPS benchmark.
 public static class IpadExitCameraValidation {
  const double Tolerance=1e-8;
  static readonly NativeFrame Frame=new NativeFrame(4f/3,true);
  const double Close=160.0*432/(16*2064);
  static IpadView Overview=>IpadFraming.Calculate(Frame,288,200,1,Close,new Rect(0,0,Frame.Width,Frame.Height));
  static readonly IpadView[] Starts={
   new IpadView{x=144,y=100,zoom=Close,header=0},
   new IpadView{x=432,y=300,zoom=Close,header=0},
   new IpadView{x=288,y=200,zoom=1.3,header=10},
  };
  static void Check(IpadExitCameraReport r,bool ok,string name,string detail=""){
   r.assertions++;if(!ok)r.failures++;r.checks.Add(new IpadExitCameraCheck{name=name,passed=ok,detail=detail});
  }
  static bool Finite(double value)=>!double.IsNaN(value)&&!double.IsInfinity(value);
  static double[] Project(NativeFrame f,IpadView v)=>new[]{
   v.zoom,v.header,
   f.Width/2-v.x*v.zoom,f.Height/2-v.y*v.zoom,
   f.Width/2+(576-v.x)*v.zoom,f.Height/2-v.y*v.zoom,
   f.Width/2-v.x*v.zoom,f.Height/2+(400-v.y)*v.zoom,
   f.Width/2+(576-v.x)*v.zoom,f.Height/2+(400-v.y)*v.zoom,
  };
  static double Difference(double[] a,double[] b){double worst=0;for(int i=0;i<a.Length;i++)worst=Math.Max(worst,Math.Abs(a[i]-b[i]));return worst;}
  static bool Same(NativeFrame f,IpadView a,IpadView b)=>Difference(Project(f,a),Project(f,b))<Tolerance;
  static bool Valid(IpadView v)=>Finite(v.x)&&Finite(v.y)&&Finite(v.zoom)&&Finite(v.header)&&v.zoom>0;
  static IpadView Sample(IpadExitCameraReport r,IpadExitCamera camera,double elapsed,bool ready=true){r.samples++;return camera.Sample(elapsed,ready);}

  static void Nominal(IpadExitCameraReport r,double duration,int fps,int position){
   string name="nominal "+duration.ToString("F3")+"ms / "+fps+"Hz / position "+position;
   var from=Starts[position];var to=Overview;var camera=new IpadExitCamera();camera.Begin(Frame,from,to,duration);
   Check(r,camera.Active,name+" begins active");
   var first=Sample(r,camera,0);Check(r,Same(Frame,first,from)&&Math.Abs(camera.Progress)<Tolerance&&!camera.Complete,name+" preserves first visible frame");
   int count=(int)Math.Ceiling(duration*fps/1000);double previous=0,previousStep=double.PositiveInfinity;
   bool monotone=true,decelerates=true,finite=true,notEarly=true,forwardZoom=true;double zoom=first.zoom;
   var a=Project(Frame,from);var b=Project(Frame,to);double worstPath=0;
   for(int i=1;i<count;i++){
    var view=Sample(r,camera,duration*i/count);double p=camera.Progress,step=p-previous;
    monotone&=p>=previous-Tolerance&&p>=0&&p<1;
    decelerates&=step<=previousStep+Tolerance;finite&=Valid(view);notEarly&=!camera.Complete;
    forwardZoom&=view.zoom<=zoom+Tolerance&&view.zoom>=to.zoom-Tolerance;zoom=view.zoom;
    var projected=Project(Frame,view);
    for(int j=0;j<a.Length;j++)worstPath=Math.Max(worstPath,Math.Abs(projected[j]-(a[j]+(b[j]-a[j])*p)));
    previous=p;previousStep=step;
   }
   Check(r,monotone&&forwardZoom,name+" never reverses or overshoots");
   Check(r,decelerates,name+" successive equal-time steps become smaller");
   Check(r,finite&&notEarly,name+" remains moving and finite until deadline");
   Check(r,worstPath<Tolerance,name+" corners, scale and header share one screen-space path","max error="+worstPath.ToString("G17"));
   var last=Sample(r,camera,duration);Check(r,camera.Complete&&Math.Abs(camera.Progress-1)<Tolerance&&Same(Frame,last,to),name+" completes at exact duration");
   Check(r,Math.Abs(camera.EndElapsed-duration)<Tolerance,name+" uses supplied transition duration");
   Check(r,Same(Frame,Sample(r,camera,duration+1000),to),name+" completed endpoint is stable");
  }

  static void CadenceAndResolution(IpadExitCameraReport r){
   foreach(int fps in new[]{30,60,120}){
    var dense=new IpadExitCamera();var direct=new IpadExitCamera();dense.Begin(Frame,Starts[0],Overview,3488);direct.Begin(Frame,Starts[0],Overview,3488);
    for(int i=0;i<fps;i++)Sample(r,dense,1000.0*i/fps);
    Check(r,Same(Frame,Sample(r,dense,1000),Sample(r,direct,1000)),"sample cadence "+fps+"Hz does not alter elapsed-time position");
   }
   var hdFrame=new NativeFrame(1376f/1032,true);var fourFrame=new NativeFrame(2752f/2064,true);
   var hd=new IpadExitCamera();var four=new IpadExitCamera();hd.Begin(hdFrame,Starts[1],Overview,3488);four.Begin(fourFrame,Starts[1],Overview,3488);
   double maxLogical=0,maxPixel=0;
   foreach(double t in new[]{0d,173,872,1744,2616,3400,3488}){
    var a=Project(hdFrame,Sample(r,hd,t));var b=Project(fourFrame,Sample(r,four,t));maxLogical=Math.Max(maxLogical,Difference(a,b));
    for(int i=2;i<a.Length;i++)maxPixel=Math.Max(maxPixel,Math.Abs(b[i]*2064/fourFrame.Height-2*a[i]*1032/hdFrame.Height));
   }
   Check(r,maxLogical<Tolerance,"HD and 4K use identical logical framing","max error="+maxLogical.ToString("G17"));
   Check(r,maxPixel<Tolerance,"4K projection is precisely twice HD, without a different camera trajectory","max error="+maxPixel.ToString("G17"));
  }

  static void WaitingAndRecovery(IpadExitCameraReport r){
   const double duration=3488,cycle=872;var camera=new IpadExitCamera();camera.Begin(Frame,Starts[0],Overview,duration,cycle);
   bool monotone=true,finite=true,notComplete=true;double previous=-1;IpadView last=default;
   // A genuine delay beyond the normal fourth blink, through eight more
   // complete pulses. The completed view must never be installed speculatively.
   for(int i=0;i<=1440;i++){
    double elapsed=i*1000.0/120;last=Sample(r,camera,elapsed,false);
    monotone&=camera.Progress>=previous-Tolerance;previous=camera.Progress;
    finite&=Valid(last);notComplete&=!camera.Complete&&camera.Progress<1&&!Same(Frame,last,Overview);
   }
   Check(r,monotone&&finite,"cache wait keeps a finite forward-only path");
   Check(r,notComplete&&double.IsPositiveInfinity(camera.EndElapsed),"cache wait never reaches exact overview or invents a completion deadline");
   double heldProgress=camera.Progress;var paused=last;
   for(int i=0;i<60;i++)last=Sample(r,camera,12000,false);
   Check(r,Same(Frame,paused,last)&&Math.Abs(heldProgress-camera.Progress)<Tolerance,"frozen transition clock preserves wait position during pause");
   var resume=Sample(r,camera,12000,true);double end=camera.EndElapsed;
   Check(r,Same(Frame,resume,last),"readiness arrival does not jump to a new position");
   Check(r,Finite(end)&&end>=12000+cycle/2-Tolerance,"late readiness reserves at least half a pulse to finish");
   Check(r,Finite(end)&&Math.Abs(end/cycle-Math.Round(end/cycle))<Tolerance,"late readiness finishes on a complete blink boundary");
   if(!Finite(end)||end<=12000)return;
   monotone=true;notComplete=true;double lastProgress=camera.Progress;
   for(int i=1;i<120;i++){
    var view=Sample(r,camera,12000+(end-12000)*i/120,true);
    monotone&=camera.Progress>=lastProgress-Tolerance&&camera.Progress<1&&Valid(view);lastProgress=camera.Progress;
    notComplete&=!camera.Complete;
   }
   Check(r,monotone&&notComplete,"recovered tail moves monotonically until its locked endpoint");
   Check(r,Same(Frame,Sample(r,camera,end,true),Overview)&&camera.Complete,"recovered tail reaches exact overview only at release");
  }

  static void ReadinessRevoked(IpadExitCameraReport r){
   const double duration=3488,cycle=872;var camera=new IpadExitCamera();camera.Begin(Frame,Starts[2],Overview,duration,cycle);
   Sample(r,camera,0,true);Sample(r,camera,1000,false);
   for(int i=1;i<=60;i++)Sample(r,camera,1000+i*2000.0/60,false);
   var before=Sample(r,camera,3000,false);var accepted=Sample(r,camera,3000,true);
   Check(r,Same(Frame,before,accepted),"ready gain preserves current visible position");
   Check(r,Math.Abs(camera.EndElapsed-duration)<Tolerance,"ready with sufficient time retains original deadline");
   var lost=Sample(r,camera,3000,false);
   Check(r,Same(Frame,accepted,lost)&&!camera.Complete,"same-frame readiness loss is continuous");
   bool forward=true;double previous=camera.Progress;
   for(int i=1;i<=240;i++){
    Sample(r,camera,3000+i*1000.0/120,false);
    forward&=camera.Progress>=previous-Tolerance&&camera.Progress<1&&!camera.Complete;previous=camera.Progress;
   }
   Check(r,forward&&double.IsPositiveInfinity(camera.EndElapsed),"revoked readiness cancels release without reversing");
   var waiting=Sample(r,camera,5000,false);var recovered=Sample(r,camera,5000,true);double end=camera.EndElapsed;
   Check(r,Same(Frame,waiting,recovered)&&Finite(end)&&end>5000,"second readiness recovery is continuous and finite");
   if(Finite(end)&&end>5000)Check(r,Same(Frame,Sample(r,camera,end,true),Overview)&&camera.Complete,"second readiness recovery can finish normally");
  }

  static void LateFirstReadinessLoss(IpadExitCameraReport r){
   const double duration=3488,cycle=872;var camera=new IpadExitCamera();camera.Begin(Frame,Starts[0],Overview,duration,cycle);
   Sample(r,camera,0,true);double elapsed=duration*.9;
   var before=Sample(r,camera,elapsed,true);double progress=camera.Progress;
   var after=Sample(r,camera,elapsed,false);
   Check(r,Same(Frame,before,after)&&Math.Abs(camera.Progress-progress)<Tolerance,"first readiness loss after 75% cannot rewind the nominal camera");
   bool forward=true;double previous=camera.Progress;
   for(int i=1;i<=120;i++){
    var view=Sample(r,camera,elapsed+i*1000.0/120,false);
    forward&=Valid(view)&&camera.Progress>=previous-Tolerance&&camera.Progress<1&&!camera.Complete;previous=camera.Progress;
   }
   Check(r,forward&&double.IsPositiveInfinity(camera.EndElapsed),"late first readiness loss preserves direction while waiting");
  }

  static void RestartAndStationary(IpadExitCameraReport r){
   var camera=new IpadExitCamera();camera.Begin(Frame,Starts[0],Overview,3488,872);Sample(r,camera,5000,false);camera.Reset();
   Check(r,!camera.Active,"reset clears the previous transition");
   camera.Begin(Frame,Starts[1],Overview,5843.362335677);var start=Sample(r,camera,0);
   Check(r,Same(Frame,start,Starts[1])&&Math.Abs(camera.Progress)<Tolerance&&!camera.Complete,"new transition has no stale wait, position or progress");
   var held=Sample(r,camera,2000);for(int i=0;i<30;i++)Check(r,Same(Frame,held,Sample(r,camera,2000)),"repeated same-time render "+i+" cannot advance exit");
   camera.Reset();camera.Begin(Frame,Overview,Overview,3488);
   bool stable=true;foreach(double t in new[]{0d,100,872,1744,3000,3488}){var view=Sample(r,camera,t);stable&=Valid(view)&&Same(Frame,view,Overview);}
   Check(r,stable,"already-full overview remains valid rather than manufacturing camera motion");
  }

  public static IpadExitCameraReport Run(){
   var watch=Stopwatch.StartNew();var r=new IpadExitCameraReport{scope="Pure exit-camera presentation controller. Nominal/extended timing, screen-space composition, cadence and logical HD/4K parity. No rendered images, actual loading performance or device smoothness claim."};
   foreach(double duration in new[]{3488d,NativeGameplayWorld.GameOverDuration})foreach(int fps in new[]{30,60,120})for(int p=0;p<Starts.Length;p++)Nominal(r,duration,fps,p);
   CadenceAndResolution(r);WaitingAndRecovery(r);ReadinessRevoked(r);LateFirstReadinessLoss(r);RestartAndStationary(r);
   r.passed=r.failures==0;r.elapsedMs=watch.Elapsed.TotalMilliseconds;return r;
  }
 }
}
#endif

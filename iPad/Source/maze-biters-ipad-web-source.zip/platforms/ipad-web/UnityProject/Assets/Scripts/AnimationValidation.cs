using System;
using System.IO;
using UnityEngine;
using UnityEngine.Rendering;
namespace MazeBiters.NativeStudy {
 [Serializable]class SnakeChecks {public RailCheck[] rails;public PulseCheck[] pulses;}
 [Serializable]class RailCheck {public Vector2Int[] cells;public double[] distances;public RailSample[] samples;}
 [Serializable]class RailSample {public double s,x,y,tx,ty,angle,curve,span;}
 [Serializable]class PulseCheck {public double phase,length,mouthPhase,progress,compression,width;public bool backwards;}
 [Serializable]class TurnFixture {public int size,columns,rows;public TurnCase[] samples;}
 [Serializable]class TurnCase {public string family,palette;public int from,to,mouth,blink;public double mix;}
 [Serializable]class TurnClockFixture {public ClockCase[] cases;}
 [Serializable]class SnakeImageFixture {public int width,height,columns,rows;public SnakeImageCase[] samples;}
 [Serializable]class SnakeImageCase {public string name,palette;public Vector2Int[] cells;public double head,length,compression,phase,frontMaterial;public bool solo;}
 [Serializable]class ClockRequest {public int from,to;public double time;}
 [Serializable]class ClockCase {public ClockRequest[] requests;public double time,angle,mix,progress;public int from,to;public bool done;}
 [Serializable]public class AnimationCheck {public string quality,note;public int samples,pixels,maxChannelError,clockSamples,motionSamples;public double meanChannelError,fractionPixelsBeyondTwo;public bool passed,strictTwoBytePassed;}
 public static class AnimationValidation {
  public static int SnakeTests(){
   var data=JsonUtility.FromJson<SnakeChecks>(File.ReadAllText(Path.Combine(WebFiles.Root,"Animation/snake-motion-reference.json")));int samples=0;
   void Eq(double a,double b,string name){if(Math.Abs(a-b)>1e-6)throw new Exception("Snake "+name+" "+a+" != "+b);}
   foreach(var r in data.rails){var rail=new SnakeRail(r.cells);for(int i=0;i<r.distances.Length;i++)Eq(rail.CellDistances[i],r.distances[i],"cell occurrence");foreach(var s in r.samples){var p=rail.Sample(s.s);Eq(p.x,s.x,"x");Eq(p.y,s.y,"y");Eq(p.tx,s.tx,"tangent X");Eq(p.ty,s.ty,"tangent Y");Eq(p.curve,s.curve,"curve");Eq(rail.RibbonSpan(s.s,36),s.span,"strip span");samples++;}}
   foreach(var s in data.pulses){var p=SnakeMotion.Pulse(s.phase,s.length,s.backwards);Eq(p.progress,s.progress,"travel");Eq(p.compression,s.compression,"compression");Eq(p.phase,s.mouthPhase,"mouth rhythm");Eq(SnakeMotion.TailWidth(s.phase),s.width,"tail contour");samples++;}
   return samples;
  }
  public static int ClockTests(){
   var data=JsonUtility.FromJson<TurnClockFixture>(File.ReadAllText(Path.Combine(WebFiles.Root,"Animation/turn-clock-reference.json")));
   foreach(var c in data.cases){var clock=new NativeTurnClock();foreach(var r in c.requests)clock.Request(r.from,r.to,r.time);var p=clock.Sample(c.time);
    if(Math.Abs(p.angle-c.angle)>1e-9||Math.Abs(p.mix-c.mix)>1e-9||p.from!=c.from||p.to!=c.to||p.done!=c.done)throw new Exception("Turn clock mismatch at "+c.time+" angle "+p.angle+" expected "+c.angle);
   }return data.cases.Length;
  }
  public static bool Turns(string quality,PackedArt art,Mesh quad,string output,string prefix="anim"){
   int clockSamples=ClockTests();var root=Path.Combine(WebFiles.Root,"Reference");var fixture=JsonUtility.FromJson<TurnFixture>(File.ReadAllText(Path.Combine(root,prefix+"-"+quality+"-turns.json")));
   int w=fixture.columns*fixture.size,h=fixture.rows*fixture.size;var atlas=new RenderTexture(w,h,0,RenderTextureFormat.ARGB32){antiAliasing=1};atlas.Create();
   using(var bank=new NativeTurnBank(quality,art,quad))using(var fantasy=new NativeTurnActor(bank,"fantasy","p1"))using(var dragon=new NativeTurnActor(bank,"dragon","p1")){
    for(int n=0;n<fixture.samples.Length;n++){var c=fixture.samples[n];var actor=c.family=="fantasy"?fantasy:dragon;actor.Palette=c.palette;bank.Render(actor,new TurnPose{from=c.from,to=c.to,mix=c.mix},c.mouth,c.blink);
     Graphics.CopyTexture(actor.Output,0,0,0,0,fixture.size,fixture.size,atlas,0,0,n%fixture.columns*fixture.size,(fixture.rows-1-n/fixture.columns)*fixture.size);
    }
    var previous=RenderTexture.active;RenderTexture.active=atlas;var actual=new Texture2D(w,h,TextureFormat.RGBA32,false);actual.ReadPixels(new Rect(0,0,w,h),0,0);actual.Apply();RenderTexture.active=previous;
    var expected=new Texture2D(2,2,TextureFormat.RGBA32,false);expected.LoadImage(File.ReadAllBytes(Path.Combine(root,prefix+"-"+quality+"-turns.png")));
    var a=actual.GetPixels32();var b=expected.GetPixels32();long error=0;int worst=0,bad=0;
    for(int i=0;i<a.Length;i++){int r=Math.Abs(a[i].r-(int)Math.Round(b[i].r*b[i].a/255.0)),g=Math.Abs(a[i].g-(int)Math.Round(b[i].g*b[i].a/255.0)),bl=Math.Abs(a[i].b-(int)Math.Round(b[i].b*b[i].a/255.0)),alpha=Math.Abs(a[i].a-b[i].a);int e=Math.Max(Math.Max(r,g),Math.Max(bl,alpha));error+=r+g+bl+alpha;worst=Math.Max(worst,e);if(e>2)bad++;}
    var report=new AnimationCheck{quality=quality,samples=fixture.samples.Length,pixels=a.Length,clockSamples=clockSamples,motionSamples=SnakeTests(),maxChannelError=worst,meanChannelError=(double)error/(a.Length*4),fractionPixelsBeyondTwo=(double)bad/a.Length,strictTwoBytePassed=worst<=2,passed=worst<=8&&(double)bad/a.Length<=1e-6&&(double)error/(a.Length*4)<=.01,note=(prefix=="power"?"Three authored bright player palettes, 120 poses: ":"Six normal palettes: ")+"Frozen WebGL vs native D3D11. Strict 2/255 result is reported separately, NOT claimed exact. Cross-backend tolerance: max 8/255, at most one pixel per million beyond 2/255, mean <=.01/255. Both sides/front/back, closure and blinking. No gameplay/neon certification."};
    File.WriteAllText(output,JsonUtility.ToJson(report,true));File.WriteAllBytes(Path.ChangeExtension(output,".png"),actual.EncodeToPNG());Debug.Log("TURN_PARITY "+JsonUtility.ToJson(report));UnityEngine.Object.Destroy(actual);UnityEngine.Object.Destroy(expected);atlas.Release();UnityEngine.Object.Destroy(atlas);return report.passed;
   }
  }
  public static bool Snakes(string quality,string output){
   var root=Path.Combine(WebFiles.Root,"Reference");var f=JsonUtility.FromJson<SnakeImageFixture>(File.ReadAllText(Path.Combine(root,"anim-"+quality+"-snakes.json")));
   var rt=new RenderTexture(f.width,f.height,24,RenderTextureFormat.ARGB32){antiAliasing=1};rt.Create();var atlas=new Texture2D(f.width*f.columns,f.height*f.rows,TextureFormat.RGBA32,false);
   var go=new GameObject("Snake validation camera");var camera=go.AddComponent<Camera>();camera.enabled=false;camera.orthographic=true;camera.orthographicSize=120f*16/36;camera.aspect=400f/240;camera.transform.position=new Vector3(200f*16/36,-120f*16/36,-10);camera.cullingMask=0;camera.backgroundColor=new Color(8/255f,16/255f,25/255f,1);camera.clearFlags=CameraClearFlags.SolidColor;camera.allowHDR=false;camera.allowMSAA=true;camera.targetTexture=rt;
   var commands=new CommandBuffer();camera.AddCommandBuffer(CameraEvent.BeforeForwardAlpha,commands);var tile=new Texture2D(f.width,f.height,TextureFormat.RGBA32,false);
   for(int n=0;n<f.samples.Length;n++){var c=f.samples[n];using(var snake=new NativeSnake(c.palette)){var pose=new SnakePose{rail=new SnakeRail(c.cells),head=c.head,length=c.length,compression=c.compression,phase=c.phase,frontMaterial=c.frontMaterial,solo=c.solo};commands.Clear();snake.Prepare(pose);snake.Submit(commands,1,camera);camera.Render();var previous=RenderTexture.active;RenderTexture.active=rt;tile.ReadPixels(new Rect(0,0,f.width,f.height),0,0);tile.Apply();RenderTexture.active=previous;atlas.SetPixels32(n%f.columns*f.width,(f.rows-1-n/f.columns)*f.height,f.width,f.height,tile.GetPixels32());}}
   atlas.Apply();var expected=new Texture2D(2,2,TextureFormat.RGBA32,false);expected.LoadImage(File.ReadAllBytes(Path.Combine(root,"anim-"+quality+"-snakes.png")));var a=atlas.GetPixels32();var b=expected.GetPixels32();long total=0;int max=0,bad=0;for(int i=0;i<a.Length;i++){int r=Math.Abs(a[i].r-b[i].r),g=Math.Abs(a[i].g-b[i].g),bl=Math.Abs(a[i].b-b[i].b),alpha=Math.Abs(a[i].a-b[i].a),e=Math.Max(Math.Max(r,g),Math.Max(bl,alpha));max=Math.Max(max,e);total+=r+g+bl+alpha;if(e>2)bad++;}
   var report=new AnimationCheck{quality=quality,samples=f.samples.Length,pixels=a.Length,maxChannelError=max,meanChannelError=(double)total/(a.Length*4),fractionPixelsBeyondTwo=(double)bad/a.Length,motionSamples=SnakeTests(),strictTwoBytePassed=max<=2,passed=max<=2,note="Original production Pixi ribbon vs D3D11. Five palettes, straight/corner/hairpin/reverse/two-cell/solo. Opaque common background; strict 2/255 gate. No neon or AI certification."};File.WriteAllText(output,JsonUtility.ToJson(report,true));File.WriteAllBytes(Path.ChangeExtension(output,".png"),atlas.EncodeToPNG());camera.RemoveCommandBuffer(CameraEvent.BeforeForwardAlpha,commands);commands.Dispose();rt.Release();foreach(var o in new UnityEngine.Object[]{go,rt,atlas,tile,expected})UnityEngine.Object.Destroy(o);Debug.Log("SNAKE_PARITY "+JsonUtility.ToJson(report));return report.passed;
  }
 }
}

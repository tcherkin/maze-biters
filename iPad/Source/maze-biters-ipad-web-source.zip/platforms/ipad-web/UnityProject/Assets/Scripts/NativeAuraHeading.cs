using System;
namespace MazeBiters.NativeStudy {
 // Visual-only inertia for the wisps. Exact critically damped response to a
 // piecewise-linear target keeps it smooth at 30/60/120 Hz without substeps.
 // Simulation time (not wall time) means pausing freezes the trail as well.
 public sealed class NativeAuraHeading {
  const double Frequency=16;
  bool ready;double time,raw,target,angle,velocity;
  public double Angle=>angle;
  public double Velocity=>velocity;
  public void Reset(){ready=false;}
  public double Sample(double requested,double now){
   if(!ready||now<time){ready=true;time=now;raw=target=angle=requested;velocity=0;return angle;}
   if(now==time)return angle;
   double dt=(now-time)/1000,delta=(requested-raw)%360;
   // Preserve the chosen direction at exactly 180 degrees, including left->right.
   if(delta>180)delta-=360;else if(delta< -180)delta+=360;
   double next=target+delta,slope=(next-target)/dt;
   double displacement=angle-target+2*slope/Frequency;
   double b=velocity-slope+Frequency*displacement,decay=Math.Exp(-Frequency*dt);
   angle=next-2*slope/Frequency+(displacement+b*dt)*decay;
   velocity=slope+(velocity-slope-Frequency*b*dt)*decay;
   raw=requested;target=next;time=now;
   if(Math.Abs(angle-target)<.005&&Math.Abs(velocity)<.05){angle=target;velocity=0;}
   return angle;
  }
  public static int Validate(){
   int checks=0;void Check(bool ok,string name){if(!ok)throw new Exception("Aura heading: "+name);checks++;}
   void Near(double a,double b,string n,double tolerance=1e-8)=>Check(Math.Abs(a-b)<=tolerance,n);
   foreach(double start in new[]{-360.0,-270,-180,-90,0,90,180,270,360})foreach(double delta in new[]{-180.0,-90,90,180})foreach(int fps in new[]{30,60,120}){
    var heading=new NativeAuraHeading();Near(heading.Sample(start,0),start,"activation");
    double previous=start,peak=0;
    for(int f=1;f<=fps;f++){
     double t=f*1000.0/fps,u=Math.Min(1,t/90),ease=u*u*u*(10+u*(-15+6*u));
     double result=heading.Sample(start+delta*ease,t);
     Check((result-previous)*delta>=-1e-7,"single turn has no bounce");
     Check((result-start)*delta>=-1e-7&&(start+delta-result)*delta>=-1e-7,"single turn bounded");
     peak=Math.Max(peak,Math.Abs(heading.Velocity));previous=result;
     Near(heading.Sample(start+delta*ease,t),result,"duplicate render / pause");
    }
    Near(previous,start+delta,"settles",.02);Check(peak<1100,"angular speed softened");
   }
   var wrap=new NativeAuraHeading();wrap.Sample(-359,0);Check(wrap.Sample(-1,16)<-359,"no full spin across wrap");
   var reverse=new NativeAuraHeading();reverse.Sample(180,0);Check(reverse.Sample(0,16)<180,"180 tie retains direction");
   var reset=new NativeAuraHeading();reset.Sample(0,0);reset.Sample(90,50);reset.Reset();Near(reset.Sample(-90,50),-90,"leader/reactivation reset");Near(reset.Sample(180,10),180,"scene time rewind");
   // Response is exactly independent of sample rate for the same linear target.
   double[] ends=new double[3];int k=0;foreach(int fps in new[]{30,60,120}){
    var follow=new NativeAuraHeading();follow.Sample(0,0);for(int f=1;f<=fps/2;f++)follow.Sample(f*180.0/fps,f*1000.0/fps);ends[k++]=follow.Angle;
   }
   Near(ends[0],ends[1],"30/60 Hz linear response");Near(ends[1],ends[2],"60/120 Hz linear response");
   // Rapid reversals retain angular position and velocity at the instant of change.
   var interrupted=new NativeAuraHeading();interrupted.Sample(0,0);interrupted.Sample(90,70);double a=interrupted.Angle,v=interrupted.Velocity;
   Near(interrupted.Sample(-90,70),a,"interruption position");Near(interrupted.Velocity,v,"interruption velocity");
   for(int i=1;i<=120;i++){double n=interrupted.Sample(-90,70+i*1000.0/120);Check(!double.IsNaN(n)&&!double.IsInfinity(n)&&Math.Abs(n)<360,"rapid reversal remains finite");}
   Near(interrupted.Angle,-90,"rapid reversal settles",.02);
   return checks;
  }
 }
}


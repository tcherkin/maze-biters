using System;
namespace MazeBiters.NativeStudy {
 // Approved render-cost experiment, enabled for normal gameplay. This switch
 // restores only the old render preparation for A/B tests; pose caching stays on.
 public static class NativeRenderOptimization {
  static readonly string[] Arguments=Environment.GetCommandLineArgs();
  // The historical renderer diagnostic still requires tangent angles. Keep
  // its original path intact instead of feeding angle-free render samples.
  public static readonly bool Enabled=Array.IndexOf(Arguments,"--legacy-render-preparation")<0&&Array.IndexOf(Arguments,"--baseline-renderer")<0;
  public static long SampleChecks;
  public static double SampleError;
  // Called only by the opt-in capture validator, never by normal gameplay.
  public static void CheckSample(SnakeCurve curve,double s,RailPoint actual){
   if(!Enabled)return;
   var expected=curve.Sample(s);SampleChecks++;
   SampleError=Math.Max(SampleError,Math.Max(Math.Max(Math.Abs(expected.x-actual.x),Math.Abs(expected.y-actual.y)),Math.Max(Math.Abs(expected.tx-actual.tx),Math.Abs(expected.ty-actual.ty))));
   if(SampleError!=0)throw new InvalidOperationException("Render-only rail sampling changed position/tangent: "+SampleError);
  }
 }
}

using System;
using System.Collections.Generic;
using System.IO;
using System.IO.Compression;
using UnityEngine;
using UnityEngine.Rendering;
namespace MazeBiters.NativeStudy {
 // Production menu owns one approved architecture and one atlas pair. Source
 // decoding and optical preparation complete before the renderer becomes Ready.
 public sealed class GlassMenuBackdrop : IDisposable {
  const double Tau=Math.PI*2;
  readonly string quality;readonly MaterialPropertyBlock properties=new MaterialPropertyBlock();
  Material material;Texture2D wall,emission,optics;Mesh geometry;Stream sourceReader;bool disposed,ready;
  public long TextureBytes{get;private set;}
  static readonly int MainTex=Shader.PropertyToID("_MainTex"),EmissionTex=Shader.PropertyToID("_EmissionTex"),OpticalField=Shader.PropertyToID("_OpticalField"),FieldRect=Shader.PropertyToID("_FieldRect"),Viewport=Shader.PropertyToID("_Viewport"),Pan=Shader.PropertyToID("_Pan"),AuraA=Shader.PropertyToID("_AuraA"),AuraB=Shader.PropertyToID("_AuraB"),Style=Shader.PropertyToID("_Style"),Champagne=Shader.PropertyToID("_Champagne"),LightBlue=Shader.PropertyToID("_LightBlue"),TravelEnabled=Shader.PropertyToID("_TravelEnabled"),AlignedLayout=Shader.PropertyToID("_AlignedLayout"),TravelOffset=Shader.PropertyToID("_TravelOffset"),BoundedMaze=Shader.PropertyToID("_BoundedMaze"),ArchitecturalLayout=Shader.PropertyToID("_ArchitecturalLayout"),TravelA=Shader.PropertyToID("_TravelA"),TravelB=Shader.PropertyToID("_TravelB"),TravelC=Shader.PropertyToID("_TravelC"),TravelD=Shader.PropertyToID("_TravelD");
  public GlassMenuBackdrop(string quality){if(quality!="hd"&&quality!="4k")throw new ArgumentOutOfRangeException(nameof(quality));this.quality=quality;}
  void Check(){if(disposed)throw new ObjectDisposedException(nameof(GlassMenuBackdrop));}
  public IEnumerable<object> LoadSteps(){
   Check();if(ready)yield break;int size=quality=="4k"?160:80,width=size*16;
   string source=Path.Combine(WebFiles.Root,"Reference","glass-brushes","blue-violet",quality);
   var pixels=new byte[width*size*4];foreach(var step in ReadSteps(Path.Combine(source,"wall.rgba.gz"),pixels))yield return step;
   Check();wall=Texture(width,size,"Approved ice glass menu atlas");wall.LoadRawTextureData(pixels);wall.Apply(false,true);TextureBytes+=(long)width*size*4;yield return "menu glass wall upload";
   var raw=new byte[width*size*12];foreach(var step in ReadSteps(Path.Combine(source,"emission.f32.gz"),raw))yield return step;
   Check();float[] values=new float[raw.Length/4];Buffer.BlockCopy(raw,0,values,0,raw.Length);raw=null;
   var lights=new Color32[width*size];for(int i=0;i<lights.Length;i++)lights[i]=new Color32(Channel(values[i*3]),Channel(values[i*3+1]),Channel(values[i*3+2]),255);values=null;
   emission=Texture(width,size,"Approved ice glass menu emission");emission.SetPixels32(lights);emission.Apply(false,true);lights=null;TextureBytes+=(long)width*size*4;yield return "menu glass light upload";
   Check();geometry=ArchitecturalMenuLayout.BuildMesh(size);yield return "menu glass architecture";
   Check();optics=ArchitecturalMenuLayout.BuildOptics(pixels,size);pixels=null;TextureBytes+=(long)optics.width*optics.height*4;yield return "menu glass optical field";
   Check();var shader=Shader.Find("MazeBiters/GlassMenuBackdrop");if(!shader)throw new InvalidOperationException("Glass menu backdrop shader is missing");
   material=new Material(shader){name="Retained approved glass menu backdrop",hideFlags=HideFlags.HideAndDontSave};material.SetTexture(MainTex,wall);material.SetTexture(EmissionTex,emission);material.SetTexture(OpticalField,optics);material.SetVector(FieldRect,new Vector4(-302,-242,38*44,32*44));ready=true;
  }
  IEnumerable<object> ReadSteps(string path,byte[] bytes){
   using(var file=File.OpenRead(path))using(var gzip=new GZipStream(file,CompressionMode.Decompress)){
    sourceReader=gzip;try{int offset=0;while(offset<bytes.Length){Check();int n=gzip.Read(bytes,offset,Math.Min(262144,bytes.Length-offset));if(n==0)throw new EndOfStreamException(path);offset+=n;yield return "menu glass source decode";}
    if(gzip.ReadByte()!=-1)throw new InvalidDataException("Unexpected glass atlas size: "+path);
    }finally{if(ReferenceEquals(sourceReader,gzip))sourceReader=null;}
   }
  }
  public void Draw(CommandBuffer draw,Mesh quad,Rect logicalViewport,double milliseconds,double effectMilliseconds){
   Check();if(!ready)throw new InvalidOperationException("Glass menu backdrop is not ready");if(draw==null||!quad||logicalViewport.width<=0||logicalViewport.height<=0)return;
   const float brightness=.55f,motion=1,glow=.6f,starSpeed=2.5f,zoomAmplitude=.10f;
   double t=(Math.Max(0,milliseconds)*.001*motion)%3600;
   float zoom=1+Mathf.Clamp(zoomAmplitude,0,.20f)*.5f*(1-(float)Math.Cos(t*Tau/120));zoom=1+Mathf.Min(.02f,(zoom-1)*.2f);
   float starSeconds=(float)((Math.Max(0,effectMilliseconds)*.001*motion*Mathf.Max(0,starSpeed))%120);
   float breath=.94f+.06f*(float)Math.Cos(t*Tau/2.4);
   var a=new Vector4(150+(float)Math.Sin(t*Tau/120)*108,495+(float)Math.Sin(t*Tau/180)*74,173*breath,.76f);
   var b=new Vector4(897+(float)Math.Sin(t*Tau/180+.8)*90,154+(float)Math.Cos(t*Tau/120)*78,201*breath,.61f);
   properties.Clear();properties.SetTexture(OpticalField,optics);properties.SetVector(Viewport,new Vector4(logicalViewport.x,logicalViewport.y,logicalViewport.width,logicalViewport.height));
   properties.SetVector(Pan,new Vector4(0,0,zoom,0));properties.SetVector(AuraA,a);properties.SetVector(AuraB,b);properties.SetVector(Style,new Vector4(brightness,glow,starSeconds,0));
   properties.SetTexture(MainTex,wall);properties.SetTexture(EmissionTex,emission);properties.SetFloat(Champagne,0);properties.SetFloat(LightBlue,1);properties.SetFloat(TravelEnabled,1);properties.SetFloat(AlignedLayout,0);properties.SetVector(TravelOffset,Vector4.zero);properties.SetFloat(BoundedMaze,1);properties.SetFloat(ArchitecturalLayout,1);
   double seconds=(Math.Max(0,effectMilliseconds)*.001*motion)%3600;ArchitecturalMenuLayout.Evaluate(seconds,1,out var ta,out var tb,out var tc,out var td);properties.SetVector(TravelA,ta);properties.SetVector(TravelB,tb);properties.SetVector(TravelC,tc);properties.SetVector(TravelD,td);
   draw.DrawMesh(quad,Matrix4x4.TRS(new Vector3(logicalViewport.x,-logicalViewport.y,0),Quaternion.identity,new Vector3(logicalViewport.width,logicalViewport.height,1)),material,0,0,properties);
   draw.DrawMesh(geometry,Matrix4x4.TRS(new Vector3(512*(1-zoom),-384*(1-zoom),0),Quaternion.identity,new Vector3(zoom,zoom,1)),material,0,1,properties);
  }
  static Texture2D Texture(int width,int height,string name)=>new Texture2D(width,height,TextureFormat.RGBA32,false,false){name=name,filterMode=FilterMode.Bilinear,wrapMode=TextureWrapMode.Clamp,hideFlags=HideFlags.HideAndDontSave};
  static byte Channel(float value)=>(byte)Mathf.Clamp(Mathf.FloorToInt(value*255+.5f),0,255);
  public void Dispose(){if(disposed)return;disposed=true;ready=false;sourceReader?.Dispose();sourceReader=null;UnityEngine.Object.Destroy(material);UnityEngine.Object.Destroy(wall);UnityEngine.Object.Destroy(emission);UnityEngine.Object.Destroy(optics);UnityEngine.Object.Destroy(geometry);material=null;wall=emission=optics=null;geometry=null;TextureBytes=0;}
 }
}

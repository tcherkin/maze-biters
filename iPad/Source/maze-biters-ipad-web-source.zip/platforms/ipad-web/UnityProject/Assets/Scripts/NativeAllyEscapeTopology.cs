using System;
using UnityEngine;

namespace MazeBiters.NativeStudy {
 // Geometry only. Dynamic blockers belong in the floor snapshot supplied by
 // the caller; no actor state, clocks or random choices are read here.
 public sealed class NativeAllyEscapeTopology {
  static readonly Vector2Int Invalid=new Vector2Int(-1,-1);
  bool[] floor,removed;
  int width,height,cells;
  int[] degree,queue,peel,depth,gate,parent,subtree;
  int[] regionDistances;
  readonly int[] regionStarts=new int[4],regionSizes=new int[4],regionDepths=new int[4];
  readonly bool[] regionClosed=new bool[4];
  bool originPrepared;
  int origin=-1;

  public void Build(bool[] nextFloor,int nextWidth,int nextHeight){
   if(nextFloor==null)throw new ArgumentNullException(nameof(nextFloor));
   if(nextWidth<=0)throw new ArgumentOutOfRangeException(nameof(nextWidth));
   if(nextHeight<=0)throw new ArgumentOutOfRangeException(nameof(nextHeight));
   int count=checked(nextWidth*nextHeight);
   if(nextFloor.Length!=count)throw new ArgumentException("Floor dimensions do not match its length",nameof(nextFloor));
   bool changed=floor==null||width!=nextWidth||height!=nextHeight;
   if(!changed){for(int i=0;i<count;i++)if(floor[i]!=nextFloor[i]){changed=true;break;}}
   if(!changed)return;
   width=nextWidth;height=nextHeight;cells=count;
   if(floor==null||floor.Length!=count){
    floor=new bool[count];removed=new bool[count];degree=new int[count];queue=new int[count];peel=new int[count];
    depth=new int[count];gate=new int[count];parent=new int[count];subtree=new int[count];regionDistances=new int[checked(count*4)];
   }
   Array.Copy(nextFloor,floor,count);originPrepared=false;origin=-1;
   BuildDepths();
  }

  int Neighbour(int key,int direction){
   int x=key%width,y=key/width;
   switch(direction){case 0:return x+1<width?key+1:-1;case 1:return x>0?key-1:-1;case 2:return y+1<height?key+width:-1;default:return y>0?key-width:-1;}
  }
  int Key(Vector2Int cell)=>floor!=null&&cell.x>=0&&cell.y>=0&&cell.x<width&&cell.y<height?cell.y*width+cell.x:-1;
  Vector2Int Cell(int key)=>key<0?Invalid:new Vector2Int(key%width,key/width);

  void BuildDepths(){
   int read=0,write=0,peeled=0;
   for(int i=0;i<cells;i++){
    removed[i]=false;degree[i]=0;depth[i]=gate[i]=parent[i]=-1;
    if(!floor[i])continue;
    for(int d=0;d<4;d++){int n=Neighbour(i,d);if(n>=0&&floor[n])degree[i]++;}
    if(degree[i]<=1)queue[write++]=i;
   }
   while(read<write){
    int key=queue[read++];removed[key]=true;peel[peeled++]=key;
    for(int d=0;d<4;d++){int n=Neighbour(key,d);if(n<0||!floor[n]||removed[n])continue;if(--degree[n]==1)queue[write++]=n;}
   }
   // The 2-core keeps loops AND bridges connecting loop regions. Only their
   // hanging trees acquire depth, rather than every narrow bridge becoming a trap.
   for(int i=0;i<cells;i++)if(floor[i]&&!removed[i]){depth[i]=0;gate[i]=i;}
   for(int i=peeled-1;i>=0;i--){
    int key=peel[i],toward=-1;
    for(int d=0;d<4;d++){int n=Neighbour(key,d);if(n>=0&&floor[n]&&depth[n]>=0&&(toward<0||depth[n]<depth[toward]))toward=n;}
    if(toward>=0){depth[key]=depth[toward]+1;gate[key]=gate[toward];}
   }
   // A wholly acyclic component has no 2-core. Give it a deterministic tree
   // centroid, so retreat toward its centre is still distinguished from going deeper.
   for(int i=0;i<cells;i++)if(floor[i]&&depth[i]==-1)RootTree(i);
  }

  void RootTree(int start){
   int read=0,write=1;queue[0]=start;depth[start]=-2;parent[start]=-1;
   while(read<write){int key=queue[read++];for(int d=0;d<4;d++){int n=Neighbour(key,d);if(n<0||!floor[n]||depth[n]!=-1)continue;depth[n]=-2;parent[n]=key;queue[write++]=n;}}
   int count=write,centre=start,bestLargest=count;
   for(int i=count-1;i>=0;i--){
    int key=queue[i],largest=0;subtree[key]=1;
    for(int d=0;d<4;d++){int n=Neighbour(key,d);if(n>=0&&floor[n]&&parent[n]==key){subtree[key]+=subtree[n];largest=Math.Max(largest,subtree[n]);}}
    largest=Math.Max(largest,count-subtree[key]);
    if(largest<bestLargest||largest==bestLargest&&key<centre){bestLargest=largest;centre=key;}
   }
   read=0;write=1;queue[0]=centre;depth[centre]=0;gate[centre]=centre;
   while(read<write){int key=queue[read++];for(int d=0;d<4;d++){int n=Neighbour(key,d);if(n<0||!floor[n]||depth[n]!=-2)continue;depth[n]=depth[key]+1;gate[n]=centre;queue[write++]=n;}}
  }

  public int Depth(Vector2Int cell){int key=Key(cell);return key>=0&&floor[key]?depth[key]:-1;}
  public Vector2Int Gate(Vector2Int cell){int key=Key(cell);return key>=0&&floor[key]?Cell(gate[key]):Invalid;}
  public bool IsDeeper(Vector2Int from,Vector2Int to){
   int a=Key(from),b=Key(to);
   return a>=0&&b>=0&&floor[a]&&floor[b]&&Math.Abs(from.x-to.x)+Math.Abs(from.y-to.y)==1&&depth[b]>depth[a];
  }

  public void PrepareOrigin(Vector2Int cell){
   int key=Key(cell);if(key>=0&&!floor[key])key=-1;
   if(originPrepared&&origin==key)return;
   originPrepared=true;origin=key;
   for(int d=0;d<4;d++){regionStarts[d]=-1;regionSizes[d]=0;regionDepths[d]=-1;regionClosed[d]=false;}
   if(floor==null||key<0)return;
   for(int i=0;i<regionDistances.Length;i++)regionDistances[i]=-1;
   // Four reusable distance fields, with the origin removed. No search budget
   // can turn a long closed corridor into an apparent second exit.
   for(int d=0;d<4;d++){
    int first=Neighbour(origin,d);if(first<0||!floor[first])continue;
    regionStarts[d]=first;int offset=d*cells,read=0,write=1,maximum=0;
    queue[0]=first;regionDistances[offset+first]=0;bool closed=true;
    while(read<write){
     int at=queue[read++],distance=regionDistances[offset+at];maximum=Math.Max(maximum,distance);
     for(int nd=0;nd<4;nd++){
      int next=Neighbour(at,nd);if(next==origin){if(at!=first)closed=false;continue;}
      if(next<0||!floor[next]||regionDistances[offset+next]>=0)continue;
      regionDistances[offset+next]=distance+1;queue[write++]=next;
     }
    }
    regionClosed[d]=closed;regionSizes[d]=write;regionDepths[d]=maximum;
   }
  }
  int Region(Vector2Int first){int key=Key(first);if(!originPrepared||origin<0||key<0)return -1;for(int d=0;d<4;d++)if(regionStarts[d]==key)return d;return -1;}
  public bool Closed(Vector2Int first){int r=Region(first);return r>=0&&regionClosed[r];}
  public int RegionSize(Vector2Int first){int r=Region(first);return r>=0?regionSizes[r]:0;}
  // Distances start at first, not origin: Distance(first,first) is zero.
  // Add one step when budgeting travel from the prepared origin.
  public int Distance(Vector2Int first,Vector2Int target){int r=Region(first),key=Key(target);return r>=0&&key>=0?regionDistances[r*cells+key]:-1;}
  public int MaxDepth(Vector2Int first){int r=Region(first);return r>=0?regionDepths[r]:-1;}
 }
}

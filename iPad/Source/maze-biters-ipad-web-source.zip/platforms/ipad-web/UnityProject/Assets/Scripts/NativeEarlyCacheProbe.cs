using System;using System.Collections;using System.Collections.Generic;using System.Diagnostics;using System.IO;using System.Linq;using UnityEngine;
namespace MazeBiters.NativeStudy {
 public sealed partial class NativeGameplayStudy {
  [Serializable] sealed class EarlyCacheCase {
   public int from,to;public bool cpuReadyBeforeClear,sceneReadyBeforeSwitch,passed;
   public double playWallMs,playProcessCpuMs,workerMs,switchMs,clearLogicalMs,sceneReadyMs;
   public long peakWorkingSet,peakUnityUsed,peakUnityReserved,peakPrivateBytes,readyWorkingSet,readyUnityUsed,readyUnityReserved,cacheBytes,rawCacheBytes,processLifetimePeak;public double packingMs;public int waits,sceneHits,sceneFallbacks;
   public string stateBeforeClear,stateAfter;
  }
  [Serializable] sealed class EarlyCacheResult {
   public bool passed,early,cancelPassed,coldFallbackPassed,compactCache,boundedPreparation,peakMemoryProbe,stableMazeWorker;public string quality,note;
   public NativeGlassPeakTrace.Sample[] preparationMemory;
   public EarlyCacheCase[] cases;public ConsistencyFrame[] frames;public ConsistencyMemory[] memory;
  }
  IEnumerator ProbeEarlyCache(){
   sessionSmoke=true;bool focus=Array.IndexOf(Environment.GetCommandLineArgs(),"--require-focus")>=0,peakProbe=NativeGlassPeakTrace.Enabled;
   consistencyFrames.Capacity=6000;var cases=new List<EarlyCacheCase>();
   Directory.CreateDirectory(Path.GetDirectoryName(report));
   foreach(int n in new[]{1,10,100}){
    Reset(12);if(n!=1){world.Level=n-1;world.AdvanceLevel();}yield return DrainProbePreparation();
    world.Event=TraceWorldEvent;sessionAudio.Muted=true;world.Player.ShieldUntil=time+60000;
    var sample=new EarlyCacheCase{from=n,peakWorkingSet=-1,peakPrivateBytes=-1,readyWorkingSet=-1};var visits=new Dictionary<Vector2Int,int>();
    void SampleCacheMemory(){
     if(NativeMemory.TryRead(out var working,out var lifetimePeak,out var committed)){sample.peakWorkingSet=Math.Max(sample.peakWorkingSet,working);sample.peakPrivateBytes=Math.Max(sample.peakPrivateBytes,committed);sample.processLifetimePeak=Math.Max(sample.processLifetimePeak,lifetimePeak);}
     sample.peakUnityUsed=Math.Max(sample.peakUnityUsed,UnityEngine.Profiling.Profiler.GetTotalAllocatedMemoryLong());sample.peakUnityReserved=Math.Max(sample.peakUnityReserved,UnityEngine.Profiling.Profiler.GetTotalReservedMemoryLong());
    }
    long previous=0;double start=Time.realtimeSinceStartupAsDouble;
    using(var process=Process.GetCurrentProcess()){
     double cpu=process.TotalProcessorTime.TotalMilliseconds;
     // Fixed 12 seconds of actual Tick/AI/animation/rendering, NOT a wait-until-
     // cache-ready shortcut. The same pilot/seed is used by the late control.
     for(int f=0;f<1440;f++){
      while(focus&&!Application.isFocused){previous=0;yield return null;}
      StallPilot(visits,true);long now=Stopwatch.GetTimestamp();MeasureStallFrame("cache-play-"+n,"normal",f,previous);previous=now;
      if(peakProbe||f%30==0)SampleCacheMemory();
      yield return null;
     }
     sample.playWallMs=(Time.realtimeSinceStartupAsDouble-start)*1000;sample.playProcessCpuMs=process.TotalProcessorTime.TotalMilliseconds-cpu;
    }
    sample.stateBeforeClear=GenerationState();sample.cpuReadyBeforeClear=nextMazeTask?.Status==System.Threading.Tasks.TaskStatus.RanToCompletion&&nextMazeNumber==n+1;
    if(EarlyMazePreparation&&(!sample.cpuReadyBeforeClear||publishingMaze!=null||nextMaze!=null||nextScene!=null))throw new InvalidOperationException("Early cache must be CPU-ready only, with no future GPU scene during play");
    if(sample.cpuReadyBeforeClear){var cached=nextMazeTask.Result.art;sample.cacheBytes=cached.GlassStagingBytes;sample.rawCacheBytes=cached.GlassRawStagingBytes;sample.packingMs=cached.GlassPackingMs;}
    NativeMemory.TryRead(out sample.readyWorkingSet,out _,out _);sample.readyUnityUsed=UnityEngine.Profiling.Profiler.GetTotalAllocatedMemoryLong();sample.readyUnityReserved=UnityEngine.Profiling.Profiler.GetTotalReservedMemoryLong();
    if(!peakProbe)Capture(Path.ChangeExtension(report,null)+"-play-"+n+".png");
    world.Snakes.Clear();foreach(var s in snakes.Values)s.Dispose();snakes.Clear();world.Hunters.Clear();world.Scorpion=null;world.CheckLevelComplete();
    int waits=nextMazeWaits,hits=nextSceneHits,fallbacks=nextSceneFallbacks;double at=time;nextSceneReadyAt=0;previous=0;
    for(int f=0;f<500;f++){
     while(focus&&!Application.isFocused){previous=0;yield return null;}
     int oldLevel=world.Level;bool ready=nextScene?.ready==true;long now=Stopwatch.GetTimestamp();var watch=Stopwatch.StartNew();
     MeasureStallFrame("cache-clear-"+n,"normal",f,previous);previous=now;
     if(world.Level!=oldLevel){sample.sceneReadyBeforeSwitch=ready;sample.clearLogicalMs=time-at;yield return DrainProbePreparation();sample.switchMs=watch.Elapsed.TotalMilliseconds;previous=0;preparationFrames=0;discardPreparationDelta=false;}
     sample.peakUnityUsed=Math.Max(sample.peakUnityUsed,UnityEngine.Profiling.Profiler.GetTotalAllocatedMemoryLong());if(peakProbe||f%30==0)SampleCacheMemory();yield return null;
    }
    sample.to=world.Level;sample.workerMs=nextMazeWorkerMs;sample.sceneReadyMs=nextSceneReadyAt;sample.waits=nextMazeWaits-waits;sample.sceneHits=nextSceneHits-hits;sample.sceneFallbacks=nextSceneFallbacks-fallbacks;sample.stateAfter=GenerationState();
    sample.passed=sample.to==n+1&&sample.clearLogicalMs>=NativeGameplayWorld.ClearDuration&&sample.clearLogicalMs<NativeGameplayWorld.ClearDuration+1000.0/120+1e-6;
    if(EarlyMazePreparation)sample.passed&=sample.sceneReadyBeforeSwitch&&sample.waits==0&&sample.sceneHits==1&&sample.sceneFallbacks==0;
    if(!peakProbe)Capture(Path.ChangeExtension(report,null)+"-next-"+n+".png");cases.Add(sample);
    Reset(12);yield return DrainProbePreparation();SampleConsistencyMemory();
   }
   // Cancel CPU-only speculative work on restart. It can finish on its worker,
   // but cannot install into or mutate the new session.
   PollNextMaze();var abandoned=nextMazeTask;Reset(12);yield return DrainProbePreparation();
   while(abandoned!=null&&!abandoned.IsCompleted)yield return null;
   bool cancelled=nextMaze==null&&nextMazeTask==null&&nextScene==null&&world.Level==1;
   // A truly immediate clear still has a safe fully initialized fallback.
   world.Snakes.Clear();foreach(var s in snakes.Values)s.Dispose();snakes.Clear();world.CheckLevelComplete();PollNextMaze();
   time=world.Time=world.TransitionAt+NativeGameplayWorld.ClearDuration;world.AdvanceLevel();yield return DrainProbePreparation();
   bool fallback=world.Level==2&&maze&&glassEmission&&neon!=null&&!scenePreparationPending;
   Reset(12);yield return DrainProbePreparation();SampleConsistencyMemory();
   var result=new EarlyCacheResult{passed=cancelled&&fallback&&cases.All(c=>c.passed),early=EarlyMazePreparation,compactCache=NativeMazeArtwork.CompactGlassCache,quality=quality,cancelPassed=cancelled,coldFallbackPassed=fallback,cases=cases.ToArray(),frames=consistencyFrames.ToArray(),memory=consistencyMemory.ToArray(),note="Same binary, seed, pilot and fixed 120Hz simulation; 1440 live frames before each natural 3488ms LEVEL CLEARED transition. Only the final removal of remaining snakes is staged. No wait-until-ready in the timed sequence. CPU material work happens during play; all future GPU scene work remains in CLEAR. --legacy-glass-cache-memory selects the previous raw staging while keeping early scheduling enabled. OS working/private memory and Unity reserved are sampled every 30 frames during movement and CLEAR; Unity allocated also sampled each CLEAR frame. OS is not VRAM. Screenshots and cancellation/cold safety checks outside timings. Late scheduling control may miss the readiness deadline and reports that without being labelled incorrect gameplay."};
   result.boundedPreparation=NativeMazeArtwork.BoundedGlassPreparation;result.peakMemoryProbe=peakProbe;result.preparationMemory=NativeGlassPeakTrace.Snapshot();
   result.stableMazeWorker=NativeMazeWorker.Enabled;
   if(peakProbe)result.note="Same compact cache and early scheduling in both variants; --legacy-glass-peak-memory disables only bounded optical fields and early raw-buffer retirement. OS working/private and Unity used/reserved sampled every timed frame. Process lifetime peak includes initial loading, diagnostic resets and safety checks; reported separately from timed gameplay/CLEAR peaks. No screenshots/readbacks anywhere in this process. OS memory is not dedicated VRAM. Native worker snapshots use Win32 only. Fixed seed/pilot, 1440 live 120Hz frames at levels 1,10,100; unchanged 3488ms CLEAR deadline. Forced diagnostic GC checkpoints remain outside timed phases; no forced GC added to production.";
   File.WriteAllText(report,JsonUtility.ToJson(result,true));Application.Quit(result.passed?0:2);
  }
 }
}

using System;using System.IO;using UnityEngine;
namespace MazeBiters.NativeStudy {
 public static class NativeCameraValidation {
  [Serializable] sealed class Oracle {public Sample[] cases;}
  [Serializable] sealed class Sample {public string name;public double x,y,real,game,zoom,cx,cy,targetZoom,tx,ty,motionZoom;public bool dead,hidden,eliminated,pause,complete,over,reset,replace;public int subjects,living;}
  public static int Run(){var data=JsonUtility.FromJson<Oracle>(File.ReadAllText(Path.Combine(WebFiles.Root,"Reference/camera-oracle.json")));var camera=new NativeGameplayCamera();object player=new object();int checks=0;
   void Equal(double a,double b,string name){checks++;if(Math.Abs(a-b)>1e-9)throw new Exception("Camera "+name+": "+a+" != "+b);}
   foreach(var s in data.cases){if(s.replace)player=new object();if(s.reset)camera.Reset(s.real);camera.Update(player,s.x,s.y,s.dead,s.eliminated,s.hidden,s.pause||s.complete||s.over,s.real,s.game);
    Equal(camera.Zoom,s.zoom,s.name+" zoom");Equal(camera.X,s.cx,s.name+" x");Equal(camera.Y,s.cy,s.name+" y");Equal(camera.TargetZoom,s.targetZoom,s.name+" targetZoom");Equal(camera.TargetX,s.tx,s.name+" tx");Equal(camera.TargetY,s.ty,s.name+" ty");Equal(camera.MotionZoom,s.motionZoom,s.name+" motion");Equal(camera.Subjects,s.subjects,s.name+" subjects");Equal(camera.Living,s.living,s.name+" living");
    foreach(double px in new[]{0.0,288,575.9})foreach(double py in new[]{0.0,200,399.9}){camera.ScreenToWorld(px,py,out double wx,out double wy);camera.WorldToScreen(wx,wy,out double sx,out double sy);Equal(sx,px,"roundtrip x");Equal(sy,py,"roundtrip y");if(!camera.PointerCell(px,py+32,out int x,out int y))throw new Exception("Valid camera pointer rejected");Equal(x,Math.Floor(wx/16),"cell x");Equal(y,Math.Floor(wy/16),"cell y");}
    foreach(var p in new[]{new Vector2(-1,32),new Vector2(576,32),new Vector2(0,31.999f),new Vector2(0,432)}){checks++;if(camera.PointerCell(p.x,p.y,out _,out _))throw new Exception("Header/outside pointer accepted");}
   }return checks;
  }
 }
}

using System;using System.IO;using System.Linq;using System.Collections.Generic;using UnityEngine;
namespace MazeBiters.NativeStudy {
 public static class NativeAllyValidation {
  [Serializable] public class Entity {public int id,x,y,score,kind;public Vector2Int dir;public double powerModeUntil,spawnShieldUntil;public bool setScore,setPower,setShield,setPose;public Vector2Int[] body,trail;public bool reversing;}
  [Serializable] public class Expected {public Vector2Int next,target;public string thought,kind,directive;public double score,danger;public int locked,draws;public bool bitten;}
  [Serializable] public class Event {public int id;public string kind;public Entity[] parts;}
  [Serializable] public class Step {public double time;public Entity p,opponent,opponent2;public Event @event;public Expected expected;}
  [Serializable] public class Scenario {public string name;public int difficulty,seed;public string[] grid;public Entity[] players,snakes,hunters,fruits;public Vector2Int[] eggs,scorpion;public Step[] steps;}
  [Serializable] public class Spec {public Scenario[] scenarios;}
  static NativeGameplaySnake Snake(Entity s)=>new NativeGameplaySnake{Id=s.id,Cell=s.body[0],Body=s.body.ToList(),Dir=s.dir,Reversing=s.reversing,Trail=(s.trail??Array.Empty<Vector2Int>()).ToList()};
  static bool prepared;
  public static void Prepare(string reference=null){if(prepared)return;Run(true,reference:reference);Run(true,true,reference:reference);Run(true,false,true,reference);prepared=true;}
  public static int Run(bool preparation=false,bool duo=false,bool only=false,string reference=null){
   var spec=JsonUtility.FromJson<Spec>(File.ReadAllText(Path.Combine(reference??Path.Combine(WebFiles.Root,"Reference"),(only?"only":duo?"duo":"solo")+"-ai-"+(preparation?"warm":"oracle")+".json")));int checks=0;
   foreach(var c in spec.scenarios){
    uint random=(uint)c.seed;int draws=0;double Next(){unchecked{draws++;random+=0x6D2B79F5;uint v=(random^(random>>15))*(1|random);v^=v+(v^(v>>7))*(61|v);return (v^(v>>14))/4294967296.0;}}
    var w=new NativeGameplayWorld(c.grid,Next){AiDifficulty=c.difficulty,Time=1000,UseLegacyAi=true};w.SetMode(only?0:duo?4:3);
    for(int i=0;i<c.players.Length;i++){var p=w.GetPlayer(i);var src=c.players[i];p.Cell=new Vector2Int(src.x,src.y);p.Dir=p.Next=src.dir;p.Score=src.score;p.PowerUntil=src.powerModeUntil;p.ShieldUntil=src.spawnShieldUntil;}
    foreach(var s in c.snakes)w.Snakes.Add(Snake(s));foreach(var h in c.hunters)w.Hunters.Add(new NativeHunter{Id=h.id,Cell=new Vector2Int(h.x,h.y),Dir=h.dir});
    foreach(var f in c.fruits)w.Fruits.Add(new NativeFruit{Cell=new Vector2Int(f.x,f.y),Kind=f.kind});foreach(var e in c.eggs)w.SolidEggs.Add(e);
    w.Scorpion=new NativeScorpion{Cell=c.scorpion[0],Tail=c.scorpion[1]};w.Ally.BeginLevel();var ai=w.GetPlayer(w.PlayerCount-1);
    int index=0;foreach(var step in c.steps){w.Time=step.time;
     void Apply(NativePlayer p,Entity v,bool pose){if(pose){p.Cell=new Vector2Int(v.x,v.y);p.Dir=v.dir;}if(v.setScore)p.Score=v.score;if(v.setPower)p.PowerUntil=v.powerModeUntil;if(v.setShield)p.ShieldUntil=v.spawnShieldUntil;}
     Apply(ai,step.p,true);if(!only)Apply(w.GetPlayer(0),step.opponent,false);if(step.opponent2!=null)Apply(w.GetPlayer(1),step.opponent2,step.opponent2.setPose);
     var e=step.@event;if(e!=null&&!string.IsNullOrEmpty(e.kind)){var old=w.Snakes.First(s=>s.Id==e.id);if(e.kind=="tail"){old.Body.RemoveAt(old.Body.Count-1);w.Ally.TailBite(ai,old);}if(e.kind=="head"){w.Snakes.Remove(old);w.Ally.Completed(ai,old);}if(e.kind=="split"){int slot=w.Snakes.IndexOf(old);w.Snakes.RemoveAt(slot);var parts=e.parts.Select(Snake).ToList();w.Snakes.InsertRange(slot,parts);w.Ally.Split(ai,old,parts);}}
     w.Ally.Plan(ai,w.Time);var a=ai.Ai;var b=step.expected;
     void Check(bool ok,string name){checks++;if(!ok)throw new Exception("Original AllyBrain "+c.name+"/"+index+" "+name+" native="+ai.Next+"/"+a.thought+"/"+a.thoughtTarget+"/"+a.thoughtScore+"/"+draws+" original="+b.next+"/"+b.thought+"/"+b.target+"/"+b.score+"/"+b.draws);}
     Check(ai.Next==b.next,"direction");Check((a.thought??"")==b.thought,"objective");Check(a.thoughtTarget==b.target,"target");Check(Math.Abs(a.thoughtScore-b.score)<1e-6,"rank");Check(a.thoughtDanger==b.danger,"danger");Check((a.locked?.Id??0)==b.locked,"prey identity");Check(a.bitten==b.bitten,"finish commitment");Check((a.targetKind??"")==b.kind,"attack kind");Check((a.directive?.type??"")==b.directive,"competitive directive");Check(draws==b.draws,"RNG draws");index++;
    }
   }
   var menu=new NativeMenuState();menu.SetFocus(only?5:duo?4:3,100);menu.Activate(100);if(menu.SelectedMode!=(only?0:duo?4:3)||!menu.Pending||menu.StartReady(999)||!menu.StartReady(1000))throw new Exception("SOLO VS AI confirmation");
   return checks+1;
  }
 }
}


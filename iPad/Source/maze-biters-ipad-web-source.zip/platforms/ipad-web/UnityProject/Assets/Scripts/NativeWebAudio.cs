using System;
using System.Collections.Generic;
using System.IO;
using System.Runtime.InteropServices;
using UnityEngine;
namespace MazeBiters.NativeStudy {
 // Original uncompressed SFX samples go to Web Audio directly: WebGL does not
 // invoke OnAudioFilterRead. Native admission clocks remain in NativeSessionAudio.
 internal sealed class NativeWebAudio:IDisposable {
  internal sealed class Sound {internal string name;internal int channels,rate;internal float[] samples;}
  internal readonly Dictionary<string,Sound> Sounds=new Dictionary<string,Sound>();
  int bus;
  internal NativeWebAudio(){
#if UNITY_WEBGL && !UNITY_EDITOR
   bus=MBWAudioCreate();if(bus<=0)throw new NotSupportedException("Web Audio is unavailable");
   try{
    using(var reader=new BinaryReader(File.OpenRead(Path.Combine(WebFiles.Root,"WebAudio/sfx.bytes")))){
     if(reader.ReadInt32()!=0x4d425741)throw new InvalidDataException("Web sound bank header");
     int count=reader.ReadInt32();if(count<1||count>128)throw new InvalidDataException("Web sound count");
     for(int i=0;i<count;i++){
      var sound=new Sound{name=reader.ReadString(),channels=reader.ReadInt32(),rate=reader.ReadInt32()};int length=reader.ReadInt32();
      if(sound.channels<1||sound.channels>2||sound.rate<8000||sound.rate>192000||length<1||length>sound.rate*sound.channels*60||length%sound.channels!=0)throw new InvalidDataException("Web sound dimensions");
      sound.samples=new float[length];for(int j=0;j<length;j++)sound.samples[j]=reader.ReadSingle();
      if(MBWAudioRegister(bus,sound.name,sound.samples,length,sound.channels,sound.rate)==0)throw new IOException("Cannot register Web sound "+sound.name);
      Sounds.Add(sound.name,sound);
     }
     if(reader.BaseStream.Position!=reader.BaseStream.Length)throw new InvalidDataException("Web sound bank trailing bytes");
    }
   }catch{Dispose();throw;}
#endif
  }
  internal int Play(string name,float pan){
#if UNITY_WEBGL && !UNITY_EDITOR
   return bus>0?MBWAudioPlay(bus,name,pan):0;
#else
   return 0;
#endif
  }
  internal bool Playing(int voice){
#if UNITY_WEBGL && !UNITY_EDITOR
   return bus>0&&voice>0&&MBWAudioPlaying(bus,voice)!=0;
#else
   return false;
#endif
  }
  internal void Stop(int voice){
#if UNITY_WEBGL && !UNITY_EDITOR
   if(bus>0&&voice>0)MBWAudioStop(bus,voice);
#endif
  }
  internal void Mute(bool muted){
#if UNITY_WEBGL && !UNITY_EDITOR
   if(bus>0)MBWAudioMute(bus,muted?1:0);
#endif
  }
  public void Dispose(){
#if UNITY_WEBGL && !UNITY_EDITOR
   if(bus>0)MBWAudioDestroy(bus);bus=0;
#endif
   Sounds.Clear();
  }
#if UNITY_WEBGL && !UNITY_EDITOR
  [DllImport("__Internal")] static extern int MBWAudioCreate();
  [DllImport("__Internal")] static extern int MBWAudioRegister(int bus,string name,float[] samples,int length,int channels,int rate);
  [DllImport("__Internal")] static extern int MBWAudioPlay(int bus,string name,float pan);
  [DllImport("__Internal")] static extern int MBWAudioPlaying(int bus,int voice);
  [DllImport("__Internal")] static extern void MBWAudioStop(int bus,int voice);
  [DllImport("__Internal")] static extern void MBWAudioMute(int bus,int muted);
  [DllImport("__Internal")] static extern void MBWAudioDestroy(int bus);
#endif
 }
}

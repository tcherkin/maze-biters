using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using Unity.Collections;
using UnityEngine;

namespace MazeBiters.NativeStudy {
 public sealed partial class NativeMazeArtwork {
  NativeMazeArtwork(SessionLevel level,string sourceRoot){StarSky=true;fast=true;brushRoot=sourceRoot;grid=level.geometry;Theme=level.theme;hue=NativeMazeGenerator.Hues[Array.IndexOf(NativeMazeGenerator.Themes,level.theme)];}
  // Editor-only entrypoint compares CPU RGBA bytes before upload, independently
  // of WebGL shader validation and without changing source assets or gameplay.
  public static string ValidateWebPainter(string quality){
   string root=Path.Combine(WebFiles.Root,"Reference/maze-brushes");
   var level=new NativeMazeGenerator(34,NativeMazeGenerator.Difficulties[2]).Generate(1);
   var before=new NativeMazeArtwork(level,1,true,true,root,glassQuality:quality,packGlassCache:false);
   string expected=before.WebPixelHash();before.DisposeStaging();
   var after=new NativeMazeArtwork(level,root);int slices=0;
   try{foreach(var step in after.BuildGlassWeb(level,quality,true,new PreparationProfile{optimized=true},false))slices++;if(slices<1000)throw new Exception("Web painter did not yield scanlines");string actual=after.WebPixelHash();if(actual!=expected)throw new Exception("Cooperative painter pixels differ: "+expected+" != "+actual);}
   finally{after.DisposeStaging();}
   var cancelled=new NativeMazeArtwork(level,root);
   using(var work=cancelled.BuildGlassWeb(level,quality,true,new PreparationProfile{optimized=true},false).GetEnumerator()){for(int i=0;i<20;i++)if(!work.MoveNext())throw new Exception("Painter completed before cancellation check");}
   if(cancelled.pixels.IsCreated||cancelled.glassEmissionPixels.IsCreated)throw new Exception("Cancelled Web paint retained staging");
   return quality+" exact SHA256="+expected+" slices="+slices+" cancellation=passed";
  }
  string WebPixelHash(){
   using(var hash=System.Security.Cryptography.SHA256.Create()){
    var chunk=new byte[65536];
    foreach(var array in new[]{pixels,glassEmissionPixels}){var data=array.Reinterpret<byte>(4);for(int offset=0;offset<data.Length;offset+=chunk.Length){int count=Math.Min(chunk.Length,data.Length-offset);NativeArray<byte>.Copy(data,offset,chunk,0,count);hash.TransformBlock(chunk,0,count,null,0);}}
    hash.TransformBlock(Relief,0,Relief.Length,null,0);
    for(int i=0;i<pendingLow.Length;i++){var p=pendingLow[i];chunk[0]=p.r;chunk[1]=p.g;chunk[2]=p.b;chunk[3]=p.a;hash.TransformBlock(chunk,0,4,null,0);}
    hash.TransformFinalBlock(Array.Empty<byte>(),0,0);return BitConverter.ToString(hash.Hash).Replace("-","");
   }
  }
  // Same native-texel painter, sum order and float casts as the approved glass.
  // The Web variant yields between complete scanlines instead of using threads.
  IEnumerable<object> BuildGlassWeb(SessionLevel level,string quality,bool deferUpload,PreparationProfile profile,bool packGlassCache){
   if(quality!="hd"&&quality!="4k")throw new ArgumentOutOfRangeException(nameof(quality));
   if(level.geometry==null||level.geometry.Length!=25)throw new InvalidDataException("Glass maze requires25rows");
   foreach(var row in level.geometry)if(row==null||row.Length!=36)throw new InvalidDataException("Glass maze requires36columns");
   IsGlass=true;GlassQuality=quality;glassSize=quality=="4k"?160:80;glassWidth=36*glassSize;glassHeight=25*glassSize;
   if(!CompactGlassCache||!BoundedGlassPreparation)throw new NotSupportedException("Web preparation requires the approved bounded glass painter");
   string root=Path.Combine(Path.GetDirectoryName(brushRoot),"glass-brushes"),prefix=Path.Combine(root,level.theme,quality);
   int atlasPixels=16*glassSize*glassSize,count=glassWidth*glassHeight,collections=GC.CollectionCount(0);
   var timer=Stopwatch.StartNew();NativeArray<float> broad=default,edge=default;bool complete=false;
   try{
    var wall=GlassRead(Path.Combine(prefix,"wall.rgba.gz"),atlasPixels*4);yield return null;
    var wallEmission=GlassFloats(Path.Combine(prefix,"emission.f32.gz"),atlasPixels*3);yield return null;
    var detail=GlassRead(Path.Combine(prefix,"receiver.r8.gz"),atlasPixels);yield return null;
    var low=GlassRead(Path.Combine(prefix,"receiver-low.r8.gz"),256*16);yield return null;
    var seed=GlassFloats(Path.Combine(root,"common",quality,"glint-seed.f32.gz"),atlasPixels);yield return null;
    var coefficients=GlassCoefficients(Path.Combine(prefix,"floor-coefficients.f64"));
    profile.backdropMs=timer.Elapsed.TotalMilliseconds;timer.Restart();Topology();profile.topologyMs=timer.Elapsed.TotalMilliseconds;timer.Restart();yield return null;
    broad=new NativeArray<float>(count,Allocator.Persistent,NativeArrayOptions.UninitializedMemory);yield return null;
    foreach(var step in WebFillGlass(broad,wall))yield return step;
    foreach(var step in WebBlurGlass(broad,glassSize*.42))yield return step;
    edge=new NativeArray<float>(count,Allocator.Persistent,NativeArrayOptions.UninitializedMemory);yield return null;
    foreach(var step in WebFillGlass(edge,wall))yield return step;
    foreach(var step in WebBlurGlass(edge,glassSize*.09))yield return step;
    profile.floorsMs=timer.Elapsed.TotalMilliseconds;timer.Restart();
    var compositionBroad=broad;var compositionEdge=edge;
    pixels=broad.Reinterpret<Color32>(4);broad=default;glassEmissionPixels=edge.Reinterpret<Color32>(4);edge=default;
    Relief=new byte[count];pendingLow=new Color32[576*400];yield return null;
    var compose=GlassComposer(compositionBroad,compositionEdge,default,wall,wallEmission,detail,coefficients);
    foreach(var step in WebComposeGlass(seed,compose))yield return step;
    for(int gy=0;gy<25;gy++){for(int gx=0;gx<36;gx++){
     int tile=masks[gx,gy];if(tile<0)continue;
     for(int y=0;y<16;y++)for(int x=0;x<16;x++){byte value=low[y*256+tile*16+x];pendingLow[(gy*16+y)*576+gx*16+x]=new Color32(value,value,value,value);}
    }yield return null;}
    using(var row=new NativeArray<Color32>(glassWidth,Allocator.Persistent,NativeArrayOptions.UninitializedMemory)){
     for(int y=0;y<glassHeight/2;y++){
      int a=y*glassWidth,b=(glassHeight-1-y)*glassWidth;
      NativeArray<Color32>.Copy(glassEmissionPixels,a,row,0,glassWidth);NativeArray<Color32>.Copy(glassEmissionPixels,b,glassEmissionPixels,a,glassWidth);NativeArray<Color32>.Copy(row,0,glassEmissionPixels,b,glassWidth);
      NativeArray<Color32>.Copy(pixels,a,row,0,glassWidth);NativeArray<Color32>.Copy(pixels,b,pixels,a,glassWidth);NativeArray<Color32>.Copy(row,0,pixels,b,glassWidth);yield return null;
     }
    }
    flipped=true;profile.wallsMs=timer.Elapsed.TotalMilliseconds;
    profile.totalMs=profile.backdropMs+profile.topologyMs+profile.floorsMs+profile.wallsMs;profile.collections=GC.CollectionCount(0)-collections;Profile=profile;
    if(deferUpload&&packGlassCache)foreach(var step in PackGlassWeb())yield return step;
    if(!deferUpload)while(!PublishGlassStep())yield return null;
    complete=true;
   }finally{if(broad.IsCreated)broad.Dispose();if(edge.IsCreated)edge.Dispose();if(!complete)DisposeStaging();}
  }
  IEnumerable<object> WebFillGlass(NativeArray<float> field,byte[] wall){
   for(int y=0;y<glassHeight;y++){
    int gy=y/glassSize,localY=y%glassSize;
    for(int gx=0;gx<36;gx++){int tile=masks[gx,gy],at=y*glassWidth+gx*glassSize,src=(localY*16*glassSize+tile*glassSize)*4;
     for(int x=0;x<glassSize;x++)field[at+x]=tile<0?0:(float)(wall[src+x*4+3]/255.0);
    }yield return null;
   }
  }
  IEnumerable<object> WebBlurGlass(NativeArray<float> field,double sigma){
   double ideal=Math.Sqrt(4*sigma*sigma+1);int low=(int)Math.Floor(ideal);if((low&1)==0)low--;
   int high=low+2,n=GlassRound((12*sigma*sigma-3*low*low-12*low-9)/(-4.0*low-4));
   for(int k=0;k<3;k++){int radius=((k<n?low:high)-1)/2;
    foreach(var step in WebBoxGlass(field,radius,true))yield return step;
    foreach(var step in WebBoxGlass(field,radius,false))yield return step;
   }
  }
  IEnumerable<object> WebBoxGlass(NativeArray<float> field,int radius,bool horizontal){
   int outer=horizontal?glassHeight:glassWidth,inner=horizontal?glassWidth:glassHeight,stride=horizontal?1:glassWidth;double divisor=2*radius+1;
   var line=new float[inner];
   for(int q=0;q<outer;q++){
    int origin=horizontal?q*glassWidth:q;
    if(horizontal)NativeArray<float>.Copy(field,origin,line,0,inner);else for(int p=0;p<inner;p++)line[p]=field[origin+p*stride];
    double sum=0;for(int k=-radius;k<=radius;k++)sum+=line[Math.Max(0,Math.Min(inner-1,k))];
    for(int p=0;p<inner;p++){field[origin+p*stride]=(float)(sum/divisor);sum+=(double)line[Math.Max(0,Math.Min(inner-1,p+radius+1))]-line[Math.Max(0,Math.Min(inner-1,p-radius))];}
    yield return null;
   }
  }
  IEnumerable<object> WebComposeGlass(float[] seed,Action<int,float[]> compose){
   int[] dx=new int[9],dy=new int[9];double[] weight=new double[9];
   for(int k=0;k<9;k++){int step=k+1;dx[k]=GlassRound(step*glassSize*.004);dy[k]=GlassRound(step*glassSize*.055);weight[k]=Math.Exp(-step*.27);}
   int rows=dy[8]+1;var glint=new float[glassWidth];
   using(var ring=new NativeArray<float>(rows*glassWidth,Allocator.Persistent,NativeArrayOptions.UninitializedMemory)){
    for(int y=0;y<glassHeight;y++){
     GlassSeedRow(ring,(y%rows)*glassWidth,seed,y);
     for(int x=0;x<glassWidth;x++){double value=0;for(int k=0;k<9;k++)if(y>=dy[k])value+=ring[((y-dy[k])%rows)*glassWidth+Math.Max(0,x-dx[k])]*weight[k];glint[x]=(float)(value*.28);}
     compose(y,glint);yield return null;
    }
   }
  }
  IEnumerable<object> PackGlassWeb(){
   if(!IsGlass||!pixels.IsCreated||HasPackedGlass)yield break;
   var timer=Stopwatch.StartNew();bool complete=false;
   try{
    foreach(var step in PackWebPixels(pixels,true))yield return step;pixels.Dispose();pixels=default;
    foreach(var step in PackWebPixels(glassEmissionPixels,false))yield return step;glassEmissionPixels.Dispose();glassEmissionPixels=default;
    complete=true;
   }finally{if(!complete)DisposeStaging();}
   GlassPackingMs=timer.Elapsed.TotalMilliseconds;Profile.totalMs+=GlassPackingMs;
  }
  IEnumerable<object> PackWebPixels(NativeArray<Color32> source,bool maze){
   var words=source.Reinterpret<uint>(4);var blocks=new StartupPixelBlock[(words.Length+GlassChunkPixels-1)/GlassChunkPixels];
   if(maze)runGlassMaze=blocks;else runGlassEmission=blocks;
   var input=new uint[GlassChunkPixels];var work=new uint[GlassChunkPixels+1];var table=new int[65536];
   for(int i=0;i<blocks.Length;i++){
    int offset=i*GlassChunkPixels,count=Math.Min(GlassChunkPixels,words.Length-offset);NativeArray<uint>.Copy(words,offset,input,0,count);
    int used=NativeStartupPixels.Encode(input,count,work,table,out bool raw);
    blocks[i]=new StartupPixelBlock{data=new NativeArray<uint>(used,Allocator.Persistent,NativeArrayOptions.UninitializedMemory),raw=raw};
    NativeArray<uint>.Copy(raw?input:work,0,blocks[i].data,0,used);yield return null;
   }
  }
 }
}

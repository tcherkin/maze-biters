using System;
namespace MazeBiters.NativeStudy {
 // Accepted exact-work reuse is enabled for ordinary browser sessions.
 // Reference switches remain available to Editor/CLI and explicit Web QA URLs.
 public static partial class NativeHolisticTuning {
  public static bool HasArgument(string flag){
   if(Array.IndexOf(Environment.GetCommandLineArgs(),flag)>=0)return true;
#if UNITY_WEBGL && !UNITY_EDITOR
   string url=UnityEngine.Application.absoluteURL;
   if(!Query(url,"diagnostic"))return false;
   string raw=flag.TrimStart('-');var words=raw.Split('-');string key=words[0];for(int i=1;i<words.Length;i++)if(words[i].Length>0)key+=char.ToUpperInvariant(words[i][0])+words[i].Substring(1);
   return Query(url,key)||Query(url,raw);
#else
   return false;
#endif
  }
#if UNITY_WEBGL && !UNITY_EDITOR
  static bool Query(string url,string key){int query=url.IndexOf('?');if(query<0)return false;string wanted=key+"=1";foreach(string item in url.Substring(query+1).Split('&'))if(item==wanted)return true;return false;}
#endif
  // A property avoids initialization-order dependence between partial files.
  public static bool Reference=>HasArgument("--holistic-reference")||HasArgument("--holistic-referenceall");
  public static bool FieldEpoch=!Reference&&!HasArgument("--legacy-field-epoch");
  public static bool FieldQueue=!Reference&&!HasArgument("--legacy-field-queue");
  public static bool Hud=!Reference&&!HasArgument("--legacy-hud-state");
  public static bool Title=!Reference&&!HasArgument("--legacy-hidden-title");
  public static bool AudioConstants=!Reference&&!HasArgument("--legacy-audio-constants");
 }
}

using System;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Rendering;
namespace MazeBiters.NativeStudy {
 // Deterministic locomotion showcase. NOT a replacement for original snake AI.
 // Routes consist only of traversable cells in the unchanged level-one maze.
 public sealed class NativeSnakeStudy:IDisposable {
  readonly Camera camera;readonly CommandBuffer commands;readonly NativeSnake[] snakes=new NativeSnake[5];readonly SnakeRail[] rails=new SnakeRail[5];readonly Vector2Int[][] routes=new Vector2Int[5][];
  readonly SnakePose[] poses=new SnakePose[5];public NativeSnake[] Snakes=>snakes;public SnakePose[] Poses=>poses;public int Count{get;private set;}=7;public bool Enabled=true;public long TextureBytes{get;private set;}
  public long SurfaceBytes {get{long n=0;foreach(var snake in snakes)n+=snake.SurfaceBytes;return n;}}
  public NativeSnakeStudy(Camera camera,LevelData level){this.camera=camera;commands=new CommandBuffer{name="Native approved snake ribbons"};camera.AddCommandBuffer(CameraEvent.BeforeForwardAlpha,commands);
   var seeds=new[]{new Vector2Int(1,1),new Vector2Int(9,23),new Vector2Int(15,1),new Vector2Int(21,23),new Vector2Int(33,1)};var colors=new[]{"Green","Yellow","Blue","Pink","Orange"};
   for(int i=0;i<5;i++){routes[i]=Route(level,seeds[i]);rails[i]=new SnakeRail(routes[i]);snakes[i]=new NativeSnake(colors[i],"lit");TextureBytes+=snakes[i].TextureBytes;poses[i]=new SnakePose{rail=rails[i]};}
  }
  static Vector2Int[] Route(LevelData level,Vector2Int start){
   bool Floor(Vector2Int p)=>p.x>=0&&p.y>=0&&p.x<36&&p.y<25&&level.geometry[p.y][p.x]!='#';
   var prior=new Dictionary<Vector2Int,Vector2Int>();var distance=new Dictionary<Vector2Int,int>();var q=new Queue<Vector2Int>();q.Enqueue(start);prior[start]=start;distance[start]=0;var far=start;
   while(q.Count>0){var p=q.Dequeue();if(distance[p]>distance[far])far=p;if(distance[p]>=48)continue;foreach(var d in NativeLevelStudy.Directions){var n=p+d;if(Floor(n)&&!prior.ContainsKey(n)){prior[n]=p;distance[n]=distance[p]+1;q.Enqueue(n);}}}
   var list=new List<Vector2Int>();for(var p=far;;p=prior[p]){list.Add(p);if(p==start)break;}list.Reverse();if(list.Count<14)throw new Exception("Study rail too short");return list.ToArray();
  }
  public void CycleLength(){Count=Count==7?2:Count==2?1:7;}
  public void ResetSurfaces(){foreach(var s in snakes)s.ResetSurfaces();}
  public Vector2Int[][] Routes=>routes;
  public void Apply(BenchFrame frame){commands.Clear();for(int i=0;i<5;i++){var c=frame.snakes[i];var p=poses[i];p.head=c.head;p.length=c.length;p.compression=c.compression;p.phase=c.phase;p.frontMaterial=c.frontMaterial;p.solo=false;p.rigidRear=null;snakes[i].Prepare(p);snakes[i].Submit(commands,i+1,camera);}}
  public void Update(double clock){commands.Clear();if(!Enabled)return;
   for(int i=0;i<5;i++){
    var route=routes[i];var rail=rails[i];var pose=poses[i];int low=Count==1?2:Count+1,high=route.Length-3,steps=high-low;double duration=steps*218.0,cycle=duration*3,t=(clock+i*1250)%cycle;bool reverse=t>=duration;
    double movingTime=reverse?(t-duration)/436:t/218;int whole=Math.Min(steps-1,(int)movingTime);double phase=movingTime-whole;
    int from=reverse?high-whole:low+whole,to=from+(reverse?-1:1);var pulse=SnakeMotion.Pulse(phase,Count*36,reverse);
    double a=rail.CellDistances[from]+SnakeMotion.Head/2,b=rail.CellDistances[to]+SnakeMotion.Head/2;
    double lengthA=Count==1?SnakeMotion.Head:a-(rail.CellDistances[from-Count+1]-(36-SnakeMotion.Head/2)),lengthB=Count==1?SnakeMotion.Head:b-(rail.CellDistances[to-Count+1]-(36-SnakeMotion.Head/2));
    pose.head=a+(b-a)*pulse.progress;pose.length=Count==1?SnakeMotion.Head:Math.Max(SnakeMotion.Head+SnakeMotion.Tail,lengthA+(lengthB-lengthA)*pulse.progress);
    var finalPulse=SnakeMotion.Pulse(phase,pose.length,reverse);pose.compression=finalPulse.compression;pose.phase=finalPulse.phase;pose.solo=Count==1;
    // World/material distance advances with the whole body; markings cannot
    // remain anchored to grid cells and be born at the leading end.
    pose.frontMaterial=Count*36;pose.rigidRear=null;
    if(pose.solo){
     var old=route[from]-route[from-1];var next=route[to]-route[to-1];double aa=Math.Atan2(old.y,old.x),ba=Math.Atan2(next.y,next.x),delta=Math.Atan2(Math.Sin(ba-aa),Math.Cos(ba-aa)),angle=aa+delta*pulse.progress;
     double x=(route[from].x+.5)*36+(route[to].x-route[from].x)*36*pulse.progress,y=(route[from].y+.5)*36+(route[to].y-route[from].y)*36*pulse.progress;
     pose.rigidRear=new RailPoint{x=x-Math.Cos(angle)*SnakeMotion.Head/2,y=y-Math.Sin(angle)*SnakeMotion.Head/2,angle=angle,tx=Math.Cos(angle),ty=Math.Sin(angle)};
    }
    snakes[i].Prepare(pose);snakes[i].Submit(commands,i+1,camera);
   }
  }
  public void Dispose(){if(camera)camera.RemoveCommandBuffer(CameraEvent.BeforeForwardAlpha,commands);commands.Dispose();foreach(var s in snakes)s.Dispose();}
 }
}

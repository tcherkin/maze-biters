using System;
using System.Collections.Generic;
using UnityEngine;
namespace MazeBiters.NativeStudy {
 public sealed partial class NativeMazeBrain {
  NativeCreature HunterIntentTarget(NativeHunter hunter,NativeBrainState state,Vector2Int origin,NativeDifficultyProfile tuning,double revenge){
   var offender=world.PlayerById(hunter.RevengePlayerId);
   if(revenge>0&&Alive(offender)&&!Powered(offender)&&DistanceAt(Field(offender.Cell),origin)>=0){
    if(state.targetPlayerId!=offender.Id){state.target=null;state.planUntil=0;}
    state.targetHunterId=0;state.targetPlayerId=offender.Id;state.targetPlayerUntil=world.Time+600;
    return offender;
   }
   return DifficultyTarget(hunter,state,origin,tuning);
  }
  void HunterIntentWeights(NativeHunter hunter,NativeBrainState state,NativeDifficultyProfile tuning,NativeCreature target,double revenge,out double mischief,out double pursuit){
   var policy=NativeCreatureFeudProfile.ForIntensity(tuning.Intensity);
   double temperament=Math.Sin(state.phase)*.05;
   mischief=policy.Chance*(1+temperament);pursuit=policy.Pursuit*(1-temperament);
   // A small role preference discourages an entire group from choosing the
   // same job. It never instructs a hunter to reverse or invents a cut target.
   int chasing=0,cutting=0;foreach(var other in world.Hunters){if(ReferenceEquals(other,hunter)||other.Brain==null||other.Brain.intentUntil<=world.Time)continue;if(other.Brain.intent=="hunt")chasing++;else if(other.Brain.intent=="mischief")cutting++;}
   double shift=.04*tuning.Skill*(chasing-cutting)/(1+chasing+cutting)*(1-revenge);
   mischief=Clamp(mischief+shift,0,.95);pursuit=Clamp(pursuit-shift,0,.95);
   mischief*=1-.94*revenge;
   // Increased revenge belongs only to the actual eater. A dead, protected or
   // unreachable offender cannot lend that increased aggression to a bystander.
   if(target is NativePlayer player&&player.Id==hunter.RevengePlayerId)pursuit+=(.88-pursuit)*revenge;
   if(target==null)pursuit=0;
   double sum=mischief+pursuit;if(sum>.98){mischief*=.98/sum;pursuit*=.98/sum;}
  }
  Vector2Int ChooseHunterDifficulty(NativeHunter hunter,NativeBrainState state,Vector2Int origin,List<Vector2Int> options,BrainProfile profile,NativeDifficultyProfile tuning){
   if(state.hunterRevengeSeen!=hunter.RevengeRevision){
    state.hunterRevengeSeen=hunter.RevengeRevision;state.intent=null;state.intentUntil=0;
    state.target=null;state.planUntil=0;state.targetPlayerUntil=0;state.mischiefSnakeId=0;state.hunterCutMissAt=0;
   }
   // A corridor has no strategic choice. Collision, incidental splitting and
   // head ricochets are resolved by the world without another graph search.
   if(options.Count==1){state.lastChoice=options[0];return options[0];}
   ReadThreats(hunter);ReadOccupancy(hunter,origin);
   double revenge=world.HunterRevenge(hunter);var target=HunterIntentTarget(hunter,state,origin,tuning,revenge);
   bool frightened=profile.flee;
   for(int i=0;i<world.PlayerCount&&!frightened;i++){var p=world.GetPlayer(i);if(!Alive(p)||!Powered(p))continue;int d=DistanceAt(Field(p.Cell),origin);frightened=d>=0&&d<=tuning.Notice;}
   HunterIntentWeights(hunter,state,tuning,target,revenge,out double mischief,out double pursuit);hunter.Aggression=pursuit;
   bool invalidHunt=state.intent=="hunt"&&(target==null||target.Id!=state.intentPlayerId);
   bool choose=state.intent==null||world.Time>=state.intentUntil||invalidHunt||frightened!=(state.intent=="evade");
   Vector2Int goal=origin;int[] route=null;
   if(choose){
    string previous=state.intent;state.mischiefSnakeId=0;
    double roll=Random();state.intent=frightened?"evade":roll<mischief?"mischief":roll<mischief+pursuit?"hunt":"wander";
    var policy=NativeCreatureFeudProfile.ForIntensity(tuning.Intensity);
    state.intentUntil=world.Time+Clamp(policy.DecisionMs*(.9+Random()*.2),2000,4000);
    if(revenge>0)state.intentUntil=Math.Min(state.intentUntil,hunter.RevengeAt+NativeGameplayWorld.HunterRevengeDuration);
    state.intentPlayerId=state.intent=="hunt"&&target!=null?target.Id:0;
    if(state.intent!=previous){state.target=null;state.planUntil=0;state.planType=null;}
    state.mischiefAt=world.Time;state.mischiefUntil=state.intentUntil;
   }
   if(state.intent=="mischief"){
    if(world.Time>=state.hunterCutMissAt&&TryMischief(hunter,state,origin,options,out goal,out route,out int snakeId)){
     state.mischiefSnakeId=snakeId;hunter.VisualTarget=goal;
    }else{
     // No meaningful two-fragment split is available: keep this interval
     // casual instead of rerolling it into an extra pursuit opportunity.
     state.intent="wander";state.mischiefSnakeId=0;state.hunterCutMissAt=world.Time+650;state.target=null;state.planUntil=0;
    }
   }else if(state.intent=="hunt"&&target!=null){
    goal=HuntTarget(hunter,state,origin,target,tuning);route=Field(goal);
    if(tuning.Skill>=.7)route=HuntField(hunter,origin,goal,route);hunter.VisualTarget=goal;
   }else if(state.intent=="evade"){
    int nearest=1001;for(int i=0;i<world.PlayerCount;i++){var p=world.GetPlayer(i);if(!Alive(p))continue;int d=DistanceAt(Field(p.Cell),origin);if(d>=0&&d<nearest){nearest=d;hunter.VisualTarget=p.Cell;}}
   }
   return RankDifficultyDirections(hunter,state,origin,options,tuning,state.intent,goal,route);
  }
 }
}

using System;using System.Collections;using System.Collections.Generic;using System.IO;using System.Linq;using UnityEngine;
namespace MazeBiters.NativeStudy {
 public sealed partial class NativeGameplayStudy {
  bool glassIntegrationProbe;
  [Serializable] sealed class GlassProbeCase {public string theme,image,geometry;public int level,mode,players,width,height,mazeWidth,mazeHeight,emissionWidth,emissionHeight,snakes,hunters,fruit,eggs;public double minimumPickupAlpha,scorpionOpacity;}
  [Serializable] sealed class GlassProbeResult {public string revision="main-glass-integration-v1",quality,note,error;public bool passed;public string[] checks;public GlassProbeCase[] cases;public int actorCoreSamples,actorCoreChanged,actorCoreMax,restorePixels,restoreChanged,restoreMax;}
  GlassProbeResult glassResult;readonly List<string> glassChecks=new List<string>();readonly List<GlassProbeCase> glassCases=new List<GlassProbeCase>();
  void GlassCheck(bool ok,string label){if(!ok)throw new InvalidOperationException("Glass integration: "+label);glassChecks.Add(label);}
  string GlassAuraState()=>string.Join(";",actors.OrderBy(p=>p.Key).Select(p=>p.Key+":"+JsonUtility.ToJson(new GlassAuraSnapshot(p.Value.aura))));
  [Serializable] sealed class GlassAuraSnapshot {public Vector2 current,velocity,target,brakeEnd;public double started,brake;public bool viaCenter;public GlassAuraSnapshot(NativeLanternGlide a){current=a.Current;velocity=a.Velocity;target=a.Target;brakeEnd=a.BrakeEnd;started=a.Started;brake=a.BrakeMs;viaCenter=a.ViaCenter;}}
  IEnumerator ProbeGlassIntegration(){
   glassResult=new GlassProbeResult{quality=quality,note="Bounded staged regression, not a performance benchmark. Actual generated campaign topology/spawns and live renderer; six palettes, modes SOLO/DUO VS/DUO VS AI, original art/effects, independent aura clocks, power/death/respawn, HD/4K switch and future-scene binding restoration. Core pixel comparison samples only eroded opaque actor coverage; antialiased silhouettes and illumination changes are intentionally excluded."};
   Directory.CreateDirectory(Path.GetDirectoryName(report));var stack=new Stack<IEnumerator>();stack.Push(RunGlassIntegration());
   while(stack.Count>0){object value=null;bool more=false;try{more=stack.Peek().MoveNext();if(more)value=stack.Peek().Current;}catch(Exception e){glassResult.error=e.ToString();Debug.LogError(e);break;}if(!more){stack.Pop();continue;}if(value is IEnumerator nested){stack.Push(nested);continue;}yield return value;}
   glassResult.passed=string.IsNullOrEmpty(glassResult.error);glassResult.checks=glassChecks.ToArray();glassResult.cases=glassCases.ToArray();File.WriteAllText(report,JsonUtility.ToJson(glassResult,true));Application.Quit(glassResult.passed?0:2);
  }
  void GlassBindings(string label){
   ValidateLevelAtmosphere(label);
   int scale=quality=="4k"?160:80;
   GlassCheck(NativeGlassPresentation.Enabled&&dusk.GlassLightingEnabled,label+" approved glass enabled");
   GlassCheck(maze&&glassEmission&&maze.width==36*scale&&maze.height==25*scale&&glassEmission.width==maze.width&&glassEmission.height==maze.height,label+" native maze/emission dimensions");
   GlassCheck(mazePaint.mainTexture==maze&&crystalPaint.mainTexture==glassEmission&&crystalPaint.GetTexture("_Dusk")==dusk.mask&&crystalPaint.GetTexture("_Actors")==neon.ActorCoverage,label+" live maze/emission/dusk/actor coverage bindings");
   GlassCheck(crystalOverlay.enabled&&mazePaint.shader.name=="MazeBiters/LuminousTunnelMaze"&&crystalPaint.shader.name=="MazeBiters/FocusedCrystal",label+" approved shader chain");
   GlassCheck(Math.Abs(crystalPaint.GetFloat("_DistantEmission")-.22f)<1e-6&&Math.Abs(crystalPaint.GetFloat("_NearEmission")-.97f)<1e-6&&Math.Abs(NativeGlassPresentation.Parallax-.15f)<1e-6,label+" approved emission and star parallax");
  }
  void GlassScene(int requestedLevel,int mode){
   Reset(9);ConfigureGeneration();world.Event=null;world.SetMode(mode);world.StartSession(LoadCampaignLevel);while(world.Level<requestedLevel)world.AdvanceLevel();world.Event=OnEvent;scenario=12;RebuildSessionVisuals();
   foreach(int i in Enumerable.Range(0,world.PlayerCount)){var p=world.GetPlayer(i);p.ShieldUntil=0;p.Waiting=true;}
  }
  void GlassExtras(){
   world.LifecycleEnabled=true;world.ScorpionSpawnAt=double.PositiveInfinity;
   for(int i=0;i<3;i++){var cell=world.Brain.Nearest(new Vector2Int(12+i*6,11));var h=new NativeHunter{Id=100+i,Cell=cell,From=cell,Dir=Vector2Int.right,Palette=i,LastMove=time};world.Hunters.Add(h);AddActor(h,false,i);}
   for(int i=0;i<4;i++)world.Fruits.Add(new NativeFruit{Cell=world.Brain.Nearest(new Vector2Int(8+i*5,7)),Kind=i,Born=time-400});
   world.Eggs.Add(new NativeEgg{Cell=world.Brain.Nearest(new Vector2Int(18,17)),Born=time-400});var head=world.Brain.Nearest(new Vector2Int(26,15));var direction=NativeLevelStudy.Directions.First(d=>world.Floor(head-d));world.PlaceScorpion(head,direction).Born=time-400;scorpionArt=CreateScorpionArt();PrepareLevelResources();
  }
  void GlassCapture(string name){Capture(Path.Combine(Path.GetDirectoryName(report),quality+"-"+name+".png"));}
  void GlassCorePixels(){
   preparationLightFrame=true;Render();var coverage=PreparationPixels(neon.ActorCoverage);var after=PreparationPixels(target);crystalPaint.SetFloat("_Amount",0);preparationLightFrame=true;Render();var before=PreparationPixels(target);crystalPaint.SetFloat("_Amount",1);
   int w=neon.ActorCoverage.width,h=neon.ActorCoverage.height;
   for(int y=2;y<h-2;y++)for(int x=2;x<w-2;x++){
    bool opaque=true;for(int j=-2;j<=2&&opaque;j++)for(int i=-2;i<=2;i++)if(coverage[(y+j)*w+x+i].a!=255){opaque=false;break;}if(!opaque)continue;
    var v=camera.WorldToViewportPoint(new Vector3((x+.5f)*576/w,-400+(y+.5f)*400/h,0));int px=(int)(v.x*target.width),py=(int)(v.y*target.height);if(px<0||py<0||px>=target.width||py>=target.height)continue;int p=py*target.width+px;
    int d=Math.Max(Math.Abs(after[p].r-before[p].r),Math.Max(Math.Abs(after[p].g-before[p].g),Math.Abs(after[p].b-before[p].b)));glassResult.actorCoreSamples++;if(d>0)glassResult.actorCoreChanged++;glassResult.actorCoreMax=Math.Max(glassResult.actorCoreMax,d);
   }
   GlassCheck(glassResult.actorCoreMax<=1,"material overlay preserves eroded opaque actor core samples within one channel byte");preparationLightFrame=true;Render();
  }
  IEnumerator RunGlassIntegration(){
   sessionSmoke=true;fixedCamera=true;ConfigureGeneration();var first=new int[6];for(int n=1;n<=100&&first.Any(v=>v==0);n++){int t=generator.ThemeIndex(n);if(first[t]==0)first[t]=n;}GlassCheck(first.All(n=>n>0),"all six themes occur in seeded original campaign");
   for(int t=0;t<6;t++){
    int mode=new[]{1,2,4}[t%3];GlassScene(first[t],mode);yield return DrainProbePreparation();GlassExtras();yield return DrainProbePreparation();preparationLightFrame=true;Render();GlassBindings(NativeMazeGenerator.Themes[t]);
    GlassCheck(currentGeneratedLevel.theme==NativeMazeGenerator.Themes[t]&&world.Grid.SequenceEqual(currentGeneratedLevel.geometry),"generated theme/topology "+t);
    GlassCheck(world.PlayerCount==new[]{1,2,3}[t%3]&&actors.Count==world.PlayerCount+3,"original roster and three distinct hunter palettes "+t);
    GlassCheck(world.Hunters.All(h=>actors[h.Id].neon!=null)&&scorpionArt!=null&&pickups!=null&&world.Fruits.Count==4&&world.Eggs.Count==1&&world.Snakes.Count>0,"all creature and pickup effect owners "+t);
    GlassCheck(pickups.Poses.Count==5&&pickups.Poses.All(p=>p.alpha>.5)&&scorpionArt.Opacity==1&&world.Floor(world.Scorpion.Cell)&&world.Floor(world.Scorpion.Tail),"pickup/scorpion fade completed and both scorpion cells walkable "+t);
    GlassCorePixels();if(t==0)ValidateLevelAtmosphere("phase comparison",true);string name=quality+"-"+currentGeneratedLevel.theme+".png";GlassCapture(currentGeneratedLevel.theme);glassCases.Add(new GlassProbeCase{theme=currentGeneratedLevel.theme,image=name,geometry=string.Join("\n",world.Grid),level=world.Level,mode=world.Mode,players=world.PlayerCount,width=target.width,height=target.height,mazeWidth=maze.width,mazeHeight=maze.height,emissionWidth=glassEmission.width,emissionHeight=glassEmission.height,snakes=world.Snakes.Count,hunters=world.Hunters.Count,fruit=world.Fruits.Count,eggs=world.Eggs.Count,minimumPickupAlpha=pickups.Poses.Min(p=>p.alpha),scorpionOpacity=scorpionArt.Opacity});
    yield return null;
   }
   // The last generated palette has all three players and every effect type.
   GlassCheck(glassResult.actorCoreSamples>50,"six-scene opaque actor sampling is nonempty and substantive");double start=time;
   for(int i=0;i<3;i++){var p=world.GetPlayer(i);p.Dir=p.Next=NativeLevelStudy.Directions[i];actors[p.Id].aura.Reset(i,time);}
   Render();var other=actors[2].aura.Current;var third=actors[3].aura.Current;var p1=world.GetPlayer(0);actors[1].turn.Request(0,2,time);p1.Dir=p1.Next=NativeLevelStudy.Directions[2];Render();time=world.Time=start+120;Render();
   GlassCheck(actors[1].aura.Current.sqrMagnitude<1e-10&&actors[2].aura.Current==other&&actors[3].aura.Current==third,"180-degree aura crosses hero centre while other players stay independent");
   var mask=PreparationPixels(dusk.mask);for(int i=0;i<3;i++){var pos=world.GetPlayer(i).Visual(time);int x=(int)((pos.x+.5f)*16),y=399-(int)((pos.y+.5f)*16);GlassCheck(mask[y*576+x].a<=1,"player "+(i+1)+" core remains lit in combined mask");}GlassCapture("three-player-reverse");
   time=world.Time=start+240;Render();GlassCheck((actors[1].aura.Current-Vector2.left).sqrMagnitude<1e-10,"180-degree aura completes at 240ms");
   p1.Dir=p1.Next=NativeLevelStudy.Directions[1];Render();time=world.Time=start+300;Render();var beforeVector=actors[1].aura.Current;var beforeSpeed=actors[1].aura.Velocity;p1.Dir=p1.Next=NativeLevelStudy.Directions[3];Render();
   GlassCheck((beforeVector-actors[1].aura.Current).sqrMagnitude<1e-12&&(beforeSpeed-actors[1].aura.Velocity).sqrMagnitude<1e-16,"rapid retarget preserves actual actor aura position and velocity");string pausedAura=GlassAuraState();Render();GlassCheck(pausedAura==GlassAuraState(),"same-time render holds all aura clocks");
   using(world.ForPlayer(world.GetPlayer(1)))world.ActivatePower();time+=500;world.Time=time;Render();GlassCheck(actors[2].art.Bright&&!actors[1].art.Bright&&!actors[3].art.Bright,"power rendering belongs only to selected player");GlassCapture("power");
   var dead=world.GetPlayer(2);using(world.ForPlayer(dead))world.SessionDeath();time+=1000;world.Time=time;Render();GlassCheck(dead.Dead&&!world.GetPlayer(0).Dead&&!world.GetPlayer(1).Dead&&sessionArt.PlayerSkullMaterial(2)!=null,"AI death retains other player lights and original skull");GlassCapture("death");
   world.Snakes.Clear();foreach(var s in snakes.Values)s.Dispose();snakes.Clear();world.Hunters.Clear();world.Scorpion=null;world.Eggs.Clear();time=world.Time=dead.RespawnAt;world.SessionTick();Render();var revived=world.GetPlayer(2);GlassCheck(!revived.Dead&&revived.IsAI&&revived.Palette==2&&actors[3].art.Palette=="ai","AI respawn restores original identity and fresh aura");
   // Change quality while the next level is being built, not just in an idle scene.
   world.CheckLevelComplete();for(int f=0;f<2400&&publishingMaze==null&&nextMaze==null;f++){Render();yield return null;}GlassCheck(publishingMaze!=null||nextMaze!=null,"future glass publication started before quality change");
   string oldQuality=quality,auras=GlassAuraState();quality=quality=="hd"?"4k":"hd";SetQuality();yield return DrainProbePreparation();Render();GlassBindings("alternate quality");GlassCheck(GlassAuraState()==auras,"quality switch preserves player aura phase");quality=oldQuality;SetQuality();yield return DrainProbePreparation();Render();GlassBindings("restored quality");
   // One real LEVEL CLEARED preparation/adoption, including GPU preview restore.
   world.CheckLevelComplete();for(int f=0;f<2400&&(nextScene==null||!nextScene.ready);f++){Render();yield return null;}GlassCheck(nextScene!=null&&nextScene.ready,"next generated scene fully prepared");
   preparationLightFrame=true;Render();var expected=PreparationPixels(target);var oldMaze=maze;var oldEmission=glassEmission;var oldNeon=neon;string clock=SceneClockState(),auraClock=GlassAuraState();WarmNextScene(nextScene);
   GlassCheck(clock==SceneClockState()&&auraClock==GlassAuraState(),"future GPU preview preserves world RNG original animation clocks and independent aura clocks");
   GlassCheck(maze==oldMaze&&glassEmission==oldEmission&&neon==oldNeon,"future GPU preview restores resource ownership");GlassBindings("preview restored");
   // The production readiness marker now latches completion until polled.
   // This extra diagnostic render starts from an already-ready plan, so it
   // must poll its own marker rather than wait for normal preparation again.
   for(int frame=0;nextScene.gpuPending&&!nextScene.gpuDone&&frame<600;frame++){
    if(nextScene.gpuCompletion.Poll()){nextScene.gpuDone=true;nextScene.gpuPending=false;nextScene.ReleaseReadiness();break;}yield return null;
   }
   GlassCheck(nextScene.gpuDone&&!nextScene.gpuPending,"diagnostic GPU preview completion confirmed");preparationLightFrame=true;Render();var actual=PreparationPixels(target);glassResult.restorePixels=actual.Length;
   for(int p=0;p<actual.Length;p++){int d=Math.Max(Math.Abs(expected[p].r-actual[p].r),Math.Max(Math.Abs(expected[p].g-actual[p].g),Math.Abs(expected[p].b-actual[p].b)));if(d>0)glassResult.restoreChanged++;glassResult.restoreMax=Math.Max(glassResult.restoreMax,d);}GlassCheck(glassResult.restoreMax==0,"GPU preview restores exact visible composite at fixed clocks");
   int hits=nextSceneHits,levelBefore=world.Level;time=world.Time=world.TransitionAt+NativeGameplayWorld.ClearDuration;world.AdvanceLevel();Render();GlassCheck(world.Level==levelBefore+1&&nextSceneHits==hits+1&&!scenePreparationPending,"prepared glass level adopts without a second cold preparation");GlassBindings("adopted next scene");GlassCapture("next-level");
  }
 }
}

using System;
using UnityEngine;
namespace MazeBiters.NativeStudy {
 // Approved flowing light/aura clock. The sprite retains its original 90ms head clock.
 // Never normalize this vector: its length is the directional-bias strength.
 public sealed class NativeLanternGlide {
  public const double DurationMs=240;
  public const double MaxBrakeMs=24,MaxBrakeTravel=.03;
  public const float WidthScale=.90f;
  Vector2 start,current,velocity,startVelocity,brakeEnd;int target;double started,lastTime,brakeMs;bool initialized,viaCenter;
  // All state is value-typed; this snapshot is independent and owns no resources.
  public NativeLanternGlide Copy()=>(NativeLanternGlide)MemberwiseClone();
  public Vector2 Current=>current;
  public Vector2 Velocity=>velocity;
  public Vector2 BrakeEnd=>brakeEnd;
  public double BrakeMs=>brakeMs;
  public Vector2 Target=>Cardinal(target);
  public bool ViaCenter=>viaCenter;
  public double Started=>started;
  public static int Wrap(int direction)=>(direction%4+4)%4;
  public static Vector2 Cardinal(int direction){switch(Wrap(direction)){case 0:return Vector2.right;case 1:return Vector2.up;case 2:return Vector2.left;default:return Vector2.down;}}
  public void Reset(int direction,double time){Check(time);target=Wrap(direction);start=brakeEnd=current=Cardinal(target);velocity=startVelocity=Vector2.zero;brakeMs=0;started=time-DurationMs;lastTime=time;initialized=true;viaCenter=false;}
  // Switch from trace-local time to the live absolute clock without consuming
  // the pending transition or changing its visible pose/remaining duration.
  public void RebaseTime(double time){Check(time);if(!initialized){Reset(0,time);return;}started+=time-lastTime;lastTime=time;}
  static void Check(double time){if(double.IsNaN(time)||double.IsInfinity(time))throw new ArgumentOutOfRangeException(nameof(time));}
  static float Ease(double p){p=Math.Max(0,Math.Min(1,p));return (float)(p*p*p*(10+p*(-15+6*p)));}
  static float EaseSpeed(double p){p=Math.Max(0,Math.Min(1,p));return (float)(30*p*p*(1-p)*(1-p));}
  static double BrakeDuration(Vector2 p,Vector2 v){
   double speed2=(double)v.x*v.x+(double)v.y*v.y;if(speed2<1e-24)return 0;
   double dot=(double)p.x*v.x+(double)p.y*v.y,room=Math.Max(0,1-((double)p.x*p.x+(double)p.y*p.y));
   // Positive intersection of p+s*v with the unit disk. The stop displacement
   // is .5*T*v; bound its TIME, never clamp/normalize the visible velocity.
   double root=Math.Sqrt(dot*dot+speed2*room);
   double ray=dot>=0?(root+dot>0?room/(root+dot):0):(-dot+root)/speed2;
   return Math.Max(0,Math.Min(MaxBrakeMs,Math.Min(2*MaxBrakeTravel/Math.Sqrt(speed2),2*ray)));
  }
  Vector2 Evaluate(double time,out Vector2 speed){
   double elapsed=time-started;
   if(elapsed<=0){speed=startVelocity;return start;}
   if(elapsed>=DurationMs){speed=Vector2.zero;return Target;}
   if(brakeMs>0&&elapsed<brakeMs){speed=startVelocity*(float)(1-elapsed/brakeMs);return start+startVelocity*(float)(elapsed-elapsed*elapsed/(2*brakeMs));}
   double remaining=DurationMs-brakeMs,p=(elapsed-brakeMs)/remaining;
   if(viaCenter){
    double half=remaining*.5,u=p<=.5?p*2:p*2-1;var a=p<=.5?brakeEnd:Vector2.zero;var b=p<=.5?Vector2.zero:Target;
    speed=(b-a)*(EaseSpeed(u)/(float)half);return Vector2.LerpUnclamped(a,b,Ease(u));
   }
   speed=(Target-brakeEnd)*(EaseSpeed(p)/(float)remaining);return Vector2.LerpUnclamped(brakeEnd,Target,Ease(p));
  }
  public Vector2 Sample(double time,int requestedDirection){
   Check(time);requestedDirection=Wrap(requestedDirection);
   if(!initialized||time<lastTime){Reset(requestedDirection,time);return current;}
   current=Evaluate(time,out velocity);
   if(requestedDirection!=target){
    bool opposite=Wrap(requestedDirection-target)==2;
    viaCenter=opposite&&((current-Target).sqrMagnitude>0||velocity.sqrMagnitude>0);
    start=current;startVelocity=velocity;brakeMs=BrakeDuration(start,startVelocity);brakeEnd=start+startVelocity*(float)(brakeMs*.5);
    target=requestedDirection;started=time;
   }
   lastTime=time;return current;
  }
 }
}

using System;
using UnityEngine;
namespace MazeBiters.NativeStudy {
 // Deterministic presentation fixture. Only probes call it; gameplay input and
 // collision algorithms never route through this controlled camera exercise.
 public sealed class IpadRosterScenario {
  readonly NativeGameplayWorld world;readonly string kind;readonly double pace;
  readonly int[] waypoint=new int[3];readonly bool[] killed=new bool[3];
  readonly Vector2Int[][] routes;NativeHunter blocker;
  public int Deaths,Respawns;public string Event="";
  public IpadRosterScenario(NativeGameplayWorld w,string name,double speed){world=w;kind=name=="farfinal"?"elimination":name;pace=speed;
   var starts=new[]{new SessionStart{x=34,y=23,dir=Vector2Int.left},new SessionStart{x=1,y=1,dir=Vector2Int.down},new SessionStart{x=34,y=1,dir=Vector2Int.down}};
   world.SetStarts(new SessionLevel{starts=starts,geometry=world.Grid});world.SessionEnabled=true;
   routes=new[]{new[]{new Vector2Int(34,23),new Vector2Int(1,23),new Vector2Int(1,1),new Vector2Int(34,1)},new[]{new Vector2Int(1,1),new Vector2Int(34,1),new Vector2Int(34,23),new Vector2Int(1,23)},new[]{new Vector2Int(34,1),new Vector2Int(34,23),new Vector2Int(1,23),new Vector2Int(1,1)}};
   for(int i=0;i<world.PlayerCount;i++){var p=world.GetPlayer(i);p.Cell=p.From=p.Previous=name=="movement"?new Vector2Int(1+i*2,23):name=="farfinal"?new Vector2Int(starts[i].x,starts[i].y):new Vector2Int(30+i,23);p.MoveStarted=-1e6;p.LastMove=1000;p.Lives=3;p.Dead=p.Eliminated=p.HideDeath=false;p.ShieldUntil=0;p.Waiting=true;waypoint[i]=1;}
  }
  public void Step(double real,Action<NativePlayer,Vector2Int,Vector2Int> turn=null){
   double game=1000+real*pace;world.Time=game;world.RealTime=1000+real;Event="";
   for(int i=1;i<world.PlayerCount;i++)if(kind!="movement"&&!killed[i]&&real>=6000+(kind=="simultaneous"?0:(i-1)*550)){
    var p=world.GetPlayer(i);if(kind=="elimination")p.Lives=1;
    using(world.ForPlayer(p))world.SessionDeath();killed[i]=true;Deaths++;Event="death-"+p.Id;
    if(kind=="blocked"&&i==1){blocker=new NativeHunter{Cell=world.IpadCameraSpawn(p)};world.Hunters.Add(blocker);}
   }
   if(blocker!=null&&real>=12000){world.Hunters.Remove(blocker);blocker=null;}
   for(int i=0;i<world.PlayerCount;i++){var before=world.GetPlayer(i);bool dead=before.Dead;using(world.ForPlayer(before))world.UpdateDeath();var p=world.GetPlayer(i);if(dead&&!p.Dead){Respawns++;Event="respawn-"+p.Id;waypoint[i]=1;p.LastMove=game;}
    if(p.Dead||real<2500||game-p.LastMove<=95)continue;
    if(kind!="movement"&&i>0)continue;
    Vector2Int dest;
    if(kind=="movement"){
     if(real<7500)dest=i==1?new Vector2Int(1,1):i==2?new Vector2Int(34,23):p.Cell.x==34?new Vector2Int(34,1):new Vector2Int(34,23);
     else if(real<14500)dest=p.Cell.y!=23?new Vector2Int(p.Cell.x,23):new Vector2Int(1+i*2,23);
     else if(real<17000||real>=19500&&real<23000)dest=new Vector2Int(34,23);
     else if(real<19500)dest=new Vector2Int(1,23);
     else dest=p.Cell.x==34?new Vector2Int(34,1):new Vector2Int(34,23);
    }
    else dest=waypoint[i]%2==1?new Vector2Int(34,23):new Vector2Int(30,23);
    if(p.Cell==dest){if(kind=="movement")continue;waypoint[i]++;dest=waypoint[i]%2==1?new Vector2Int(34,23):new Vector2Int(30,23);}
    var d=dest-p.Cell;var dir=d.x!=0?new Vector2Int(Math.Sign(d.x),0):new Vector2Int(0,Math.Sign(d.y));
    var old=p.Dir;p.Dir=p.Next=dir;p.From=p.Previous=p.Cell;p.Cell+=dir;p.MoveStarted=p.LastMove=game;p.MoveDuration=95;p.Waiting=false;if(old!=dir)turn?.Invoke(p,old,dir);
   }
  }
 }
}

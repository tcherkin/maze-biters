using Screen = UnityEngine.Device.Screen;
using UnityEngine;
namespace MazeBiters.NativeStudy {
 public sealed partial class NativeGameplayStudy {
  readonly NativeGameplayCamera gameplayCamera=new NativeGameplayCamera();
  readonly IpadCameraMotion ipadCameraMotion=new IpadCameraMotion();
  readonly IpadCameraMotionBeforeRoster ipadRosterPreviousCamera=new IpadCameraMotionBeforeRoster();
  readonly IpadCameraAnticipatoryReference ipadAnticipatoryReference=new IpadCameraAnticipatoryReference();
  readonly IpadCameraFastRespawnReference ipadFastRespawnReference=new IpadCameraFastRespawnReference();
  readonly IpadCameraBeforeBalance ipadBeforeBalance=new IpadCameraBeforeBalance();
  bool ipadBalanceProbe,ipadRosterBeforeProbe,ipadPostRespawnProbe,ipadSoloPaceProbe;
  bool ipadLegacyCameraProbe;
  double cameraViewX=288,cameraViewY=200,cameraViewZoom=1;
  int cameraFrame=-1;bool fixedCamera,cameraProbe;
  void ResetGameplayCamera(){gameplayCamera.Reset(realClock);ipadCameraMotion.Reset();ipadRosterPreviousCamera.Reset();ipadAnticipatoryReference.Reset();ipadFastRespawnReference.Reset();ipadBeforeBalance.Reset();ResetIpadExitCamera();cameraFrame=-1;ApplyGameplayCamera();}
  void UpdateGameplayCamera(){
   // GPU preflight renders are not displayed frames. They must neither follow
   // the future player nor consume the visible camera's easing history.
   if(preparingScene||preparingNextScene)return;
   if(cameraFrame!=Time.frameCount){cameraFrame=Time.frameCount;
    if(!fixedCamera&&world.Multiplayer)gameplayCamera.UpdateRoster(world,paused||world.GameOver||world.Transition,realClock,time);
    else if(!fixedCamera){var p=world.Player;var pos=p.Visual(time);gameplayCamera.Update(p,(pos.x+.5)*16,(pos.y+.5)*16,p.Dead,p.Eliminated,p.HideDeath,paused||world.GameOver||world.Transition,realClock,time);}
   }
   ApplyGameplayCamera();
  }
  void ApplyGameplayCamera()=>SetGameplayCameraView(gameplayCamera.X,gameplayCamera.Y,gameplayCamera.Zoom,true);
  void SetGameplayCameraView(double x,double y,double zoom,bool follow=false){if(!camera)return;
   if(IpadPresentation.Enabled){Rect? bounds=null;var frame=DisplayFrame;var safe=IpadPresentation.SafeRect(frame);double close=IpadPresentation.CloseZoom(frame);
    bounds=IpadCameraRoster.Bounds(world,time);var retained=IpadCameraRoster.Bounds(world,time,excludeMask:ipadCameraMotion.JoiningMask);
    IpadView view;if(follow&&!fixedCamera&&!ipadLegacyCameraProbe&&!preparingScene&&!preparingNextScene){
     if(ipadRosterBeforeProbe&&ipadBalanceProbe)view=ipadBeforeBalance.Sample(frame,x,y,zoom,close,safe,bounds,realClock,gameplayCamera.TargetX,gameplayCamera.TargetY,IpadCameraRoster.Bounds(world,time,excludeMask:ipadBeforeBalance.JoiningMask),gameplayCamera.TargetZoom);
     else if(ipadRosterBeforeProbe&&ipadSoloPaceProbe)view=ipadFastRespawnReference.Sample(frame,x,y,zoom,close,safe,bounds,realClock,gameplayCamera.TargetX,gameplayCamera.TargetY,IpadCameraRoster.Bounds(world,time,excludeMask:ipadFastRespawnReference.JoiningMask),gameplayCamera.TargetZoom);
     else if(ipadRosterBeforeProbe&&ipadPostRespawnProbe)view=ipadAnticipatoryReference.Sample(frame,x,y,zoom,close,safe,bounds,realClock,gameplayCamera.TargetX,gameplayCamera.TargetY,IpadCameraRoster.Upcoming(world,time,bounds),gameplayCamera.TargetZoom);
     else if(ipadRosterBeforeProbe)view=ipadRosterPreviousCamera.Sample(frame,x,y,zoom,close,safe,IpadCameraRoster.Bounds(world,time,true),realClock,gameplayCamera.TargetX,gameplayCamera.TargetY);
     else view=ipadCameraMotion.Sample(frame,x,y,zoom,close,safe,bounds,realClock,gameplayCamera.TargetX,gameplayCamera.TargetY,retained,gameplayCamera.TargetZoom,paused||world!=null&&(world.GameOver||world.Transition));
    }
    else{view=IpadFraming.Calculate(frame,x,y,zoom,close,safe);if(bounds.HasValue)view=IpadFraming.KeepPlayers(frame,view,bounds.Value,safe);}
    if(follow&&ExitCameraEnabled&&!preparingScene&&!preparingNextScene)view=ApplyIpadExitCamera(view);
    x=view.x;y=view.y;zoom=view.zoom;
   }else if(NativeDisplay.Enabled){double originalY=y;
    if(NativeOverviewFraming.Legacy)y=DisplayFrame.CameraY(y,zoom);
    else{double sourceZoom=zoom;zoom=NativeOverviewFraming.Zoom(DisplayFrame,sourceZoom);y=NativeOverviewFraming.Y(DisplayFrame,y,sourceZoom,zoom);}
    if(world!=null&&y!=originalY)for(int i=0;i<world.PlayerCount;i++){var p=world.GetPlayer(i);if(p.Eliminated||p.Dead&&p.HideDeath)continue;var position=p.Visual(time);y=DisplayFrame.KeepVisibleY(originalY,y,zoom,(position.y+.5)*16);}
   }
   cameraViewX=x;cameraViewY=y;cameraViewZoom=zoom;
   // Interactive play is centred in the complete target. The HUD is a fixed
   // transparent overlay, not a clipped strip. Reference probes keep old framing.
   camera.orthographicSize=(float)(DisplayFrame.Height/2/zoom);
   camera.transform.position=new Vector3((float)x,(float)(-y+DisplayFrame.ViewOffsetY/zoom),-10);
   sessionArt?.SetCamera(x,y,zoom,DisplayFrame);if(IpadPresentation.Enabled)hud?.SetIpadArea(DisplayFrame,IpadPresentation.SafeRect(DisplayFrame));else hud?.SetWidth(DisplayFrame.Width);if(NativeDisplay.Enabled)hud?.SetSky(DisplayFrame,x,y);
   if(NativeTunnelSky.Enabled&&mazePaint){var projected=DisplayFrame.ProjectBoard(x,y,zoom);var skyOffset=DisplayFrame.SkyOffset(x,y);mazePaint.SetVector("_SkyRect",new Vector4(projected.x+skyOffset.x,projected.y+skyOffset.y,projected.width,projected.height));if(dusk!=null)mazePaint.SetTexture("_Dusk",dusk.mask);}
  }
  bool GameplayPointer(Vector2 screen,out Vector2Int cell){var r=Viewport();cell=default;
   return DisplayFrame.PointerCell(DisplayFrame.Logical(screen,r,Screen.height),cameraViewX,cameraViewY,cameraViewZoom,out cell);
  }
 }
}

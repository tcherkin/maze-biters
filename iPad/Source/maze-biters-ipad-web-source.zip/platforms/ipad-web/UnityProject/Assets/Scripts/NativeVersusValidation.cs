using System;using System.IO;using System.Linq;using System.Collections.Generic;using UnityEngine;
namespace MazeBiters.NativeStudy {
 public static class NativeVersusValidation {
  [Serializable] sealed class Case {public int mode,sa,sb;public double shieldA,shieldB,powerA,powerB;public bool eatA,eatB,block,safe;}
  [Serializable] sealed class Cases {public Case[] cases;}
  public static int Run(){
   int checks=0;void Check(bool ok,string n){checks++;if(!ok)throw new Exception("DUO VS: "+n);}
   NativeGameplayWorld World(int mode=2){var w=new NativeGameplayWorld(new[]{"##########","#........#","##########"},()=>.5){SessionEnabled=true,Time=1000,RealTime=1000,Assist=true};w.SetMode(mode);for(int i=0;i<2;i++){var p=w.GetPlayer(i);p.Cell=p.From=p.Previous=new Vector2Int(3+i,1);p.Dir=p.Next=i==0?Vector2Int.right:Vector2Int.left;p.Waiting=false;}return w;}
   var oracle=JsonUtility.FromJson<Cases>(File.ReadAllText(Path.Combine(WebFiles.Root,"Reference/versus-oracle.json")));
   foreach(var c in oracle.cases){var w=World(c.mode);var a=w.GetPlayer(0);var b=w.GetPlayer(1);a.Score=c.sa;b.Score=c.sb;a.ShieldUntil=c.shieldA;b.ShieldUntil=c.shieldB;a.PowerUntil=c.powerA;b.PowerUntil=c.powerB;
    Check(w.CanEatPlayer(a,b)==c.eatA&&w.CanEatPlayer(b,a)==c.eatB,"source contact priority");
    Check(w.PlayerContactBlocks(a,b.Cell)==c.block,"source blocking");Check(w.PlayerRouteSafe(a,b.Cell)==c.safe,"source route safety");
    using(w.ForPlayer(a))w.AdvancePlayer();
    Check(c.block?a.Cell.x==3&&!a.Dead&&!b.Dead:a.Cell.x==4&&a.Dead==c.eatB&&b.Dead==c.eatA,"real keyboard advance/knockout");
    Check(a.Score==c.sa&&b.Score==c.sb,"contact never awards points");
    Check(a.Lives==3-(c.eatB?1:0)&&b.Lives==3-(c.eatA?1:0),"single life loss");Check(w.Player.Id==1,"scoped victim/winner context restored");
   }
   foreach(int id in new[]{1,2}){
    var w=World();var a=w.PlayerById(id);var b=w.PlayerById(id==1?2:1);a.Score=100;b.Score=200;var events=new List<NativeWorldEvent>();w.Event=events.Add;
    using(w.ForPlayer(a))w.AdvancePlayer();Check(a.Dead&&!b.Dead&&b.Score==200,"weaker mover loses to stationary rival");
    Check(events.Count(e=>e.Kind=="playerBite")==1&&events.Single(e=>e.Kind=="playerBite").Player==b&&events.Single(e=>e.Kind=="playerBite").Victim==a,"winner owns mouth/bloom");
    Check(events.Count(e=>e.Sound=="HeadDie")==1&&!events.Any(e=>e.Sound=="HeadEat"),"own death sound, no snake sound");
    Check(b.BiteEnd>w.Time&&!w.EatPlayer(b,a),"no duplicate reward from dead player");
    a.Dead=false;a.Lives=3;a.ShieldUntil=1001;Check(w.CanEatPlayer(a,b)&&!w.CanEatPlayer(b,a),"respawn reverses hunter and prey");
    w.Time=1001;Check(!w.CanEatPlayer(a,b)&&w.CanEatPlayer(b,a),"shield expiry exact boundary");
    a.PowerUntil=2000;Check(w.CanEatPlayer(a,b),"power outranks score");
    a.PowerUntil=0;a.Score=2000;Check(w.CanEatPlayer(a,b),"live score changes priority");
    a.Score=b.Score;Check(!w.CanEatPlayer(a,b)&&!w.CanEatPlayer(b,a),"tie blocks");a.Lives=0;Check(!w.CanEatPlayer(a,b),"eliminated cannot attack");a.Lives=3;b.Dead=true;Check(!w.CanEatPlayer(a,b),"dead cannot be eaten");
   }
   foreach(double difficulty in NativeMazeGenerator.Difficulties)foreach(double speed in NativeMenuState.Speeds){
    var w=World();w.Difficulty=difficulty;w.ScoreSpeed=speed;var a=w.GetPlayer(0);var b=w.GetPlayer(1);a.Score=4995;a.ExactScore=4995;Check(w.EatPlayer(a,b),"scaled bite");
    Check(a.ExactScore==4995&&a.Score==4995&&a.Lives==3&&a.ExtraLives==0,"no points or bonus lives for eating a player");
   }
   {
    var w=World();var a=w.GetPlayer(0);var b=w.GetPlayer(1);b.Score=500;
    Check(!w.Brain.RouteStep(a,new Vector2Int(8,1)).HasValue||w.Brain.RouteStep(a,new Vector2Int(8,1))!=Vector2Int.right,"pointer does not route into stronger opponent");
    Check(!w.Hazard(Vector2Int.right),"original reaction assist does not rescue deliberate VS attack");
    a.Score=600;Check(w.Brain.RouteStep(a,new Vector2Int(8,1))==Vector2Int.right,"pointer may hunt weaker opponent");
    a.ShieldUntil=b.ShieldUntil=2000;using(w.ForPlayer(a))w.AdvancePlayer();using(w.ForPlayer(b))w.AdvancePlayer();Check(a.Cell.x==3&&b.Cell.x==4,"double shield prevents overlap or swap");
   }
   var menu=new NativeMenuState();menu.SetFocus(2,100);menu.Activate(100);Check(menu.SelectedMode==2&&menu.Pending&&!menu.StartReady(999)&&menu.StartReady(1000),"mode 2 / original menu confirmation");
   return checks;
  }
 }
}

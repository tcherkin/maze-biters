using System;
using System.IO;
using System.Collections.Generic;
using UnityEngine;
namespace MazeBiters.NativeStudy {
 public sealed class PackedArt : IDisposable {
  public readonly Dictionary<string,Material> materials=new Dictionary<string,Material>();
  readonly Dictionary<string,Texture2D> textures=new Dictionary<string,Texture2D>();
  public long TextureBytes {get;private set;}
  public PackedArt(string quality,bool includeBright=false,bool deferred=false){if(!deferred)foreach(var step in LoadSteps(quality,includeBright)){} }
  public IEnumerable<object> LoadSteps(string quality,bool includeBright=false){
   var root=Path.Combine(WebFiles.Root,"Art");
   var manifest=JsonUtility.FromJson<ArtManifest>(File.ReadAllText(Path.Combine(root,"manifest.json")));
   foreach(var profile in manifest.profiles)if(profile.quality==quality)foreach(var s in profile.sets){if(s.light=="bright"&&!includeBright)continue;
    var m=new Material(Shader.Find("MazeBiters/PackedCharacter")){name=s.key};
    materials.Add(s.family+":"+s.palette+(s.light=="bright"?"-bright":"")+":"+s.direction,m);
    m.mainTexture=Load(root,s.@base);if(NativeBalancedLaunch.Distributed)yield return null;
    Configure(m,"_Mouth",s.mouth,root);if(NativeBalancedLaunch.Distributed)yield return null;
    for(int i=0;i<s.blink.Length;i++){Configure(m,"_Eye"+i,s.blink[i],root);if(NativeBalancedLaunch.Distributed)yield return null;}
    m.SetVector("_Mirrors",new Vector4(s.mouth.mirrorX?1:0,s.blink.Length>0&&s.blink[0].mirrorX?1:0,s.blink.Length>1&&s.blink[1].mirrorX?1:0,0));
    m.SetVector("_Frames",new Vector4(0,0,s.blink.Length,s.size));yield return null;
   }
  }
  Texture2D Load(string root,string file){
   if(textures.TryGetValue(file,out var existing))return existing;
   var t=new Texture2D(2,2,TextureFormat.RGBA32,false,false){name=file,filterMode=FilterMode.Point,wrapMode=TextureWrapMode.Clamp};
   if(!t.LoadImage(File.ReadAllBytes(Path.Combine(root,file)),true))throw new IOException("Cannot decode "+file);
   TextureBytes+=(long)t.width*t.height*4;textures.Add(file,t);return t;
  }
  void Configure(Material m,string name,Patch p,string root){
   if(p.columns<1||p.frames<1||p.width<1)throw new InvalidDataException("Invalid patch "+p.file);
   m.SetTexture(name+"Tex",Load(root,p.file));m.SetVector(name+"Rect",new Vector4(p.x,p.y,p.width,p.height));
   m.SetVector(name+"Pack",new Vector4(p.columns,p.cellWidth,p.stride,p.guard));
  }
  public void Dispose(){foreach(var m in materials.Values)UnityEngine.Object.Destroy(m);foreach(var t in textures.Values)UnityEngine.Object.Destroy(t);materials.Clear();textures.Clear();}
 }
}

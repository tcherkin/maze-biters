using System;
using UnityEngine;
namespace MazeBiters.NativeStudy {
 public static partial class NativeHolisticTuning {
  public static bool MeshSubmission=!Reference&&!HasArgument("--legacy-mesh-submission");
  public static bool LightReceivers=!Reference&&!HasArgument("--legacy-light-receivers");
  public static bool LightHeadTrig=!Reference&&!HasArgument("--legacy-light-head-trig");
 }
 public sealed partial class NativeSnake {
  // Only the four-vertex head/resolve quads have immutable topology. Ribbon
  // geometry, MSAA resolves, clipping and material samples are unchanged.
  sealed class QuadSubmission {
   public bool valid;public readonly Vector3[] vertices=new Vector3[4];public readonly Vector2[] uv=new Vector2[4];
  }
  readonly QuadSubmission retainedHead=new QuadSubmission(),retainedBodyResolve=new QuadSubmission(),retainedHeadResolve=new QuadSubmission();
  bool retainedPaint;float retainedNape,retainedOpacity;Texture retainedHeadTexture;
  void PrepareHeadPaint(SnakePose pose){
   float nape=pose.solo?0:(float)pose.soloAmount,opacity=pose.rearBirth?(float)pose.birthProgress:1;Texture texture=pose.solo?solo:mouth;
   if(!NativeHolisticTuning.MeshSubmission){retainedPaint=false;headPaint.SetFloat("_Nape",nape);headPaint.SetFloat("_Opacity",opacity);headPaint.mainTexture=texture;return;}
   if(!retainedPaint||retainedNape!=nape)headPaint.SetFloat("_Nape",nape);
   if(!retainedPaint||retainedOpacity!=opacity)headPaint.SetFloat("_Opacity",opacity);
   if(!retainedPaint||retainedHeadTexture!=texture)headPaint.mainTexture=texture;
   retainedNape=nape;retainedOpacity=opacity;retainedHeadTexture=texture;retainedPaint=true;
  }
  static void SubmitQuad(Mesh mesh,Vector3[] vertices,Vector2[] uv,QuadSubmission state){
   if(!NativeHolisticTuning.MeshSubmission){state.valid=false;mesh.Clear();mesh.vertices=vertices;mesh.uv=uv;mesh.triangles=QuadIndices;return;}
   bool moved=!state.valid,retextured=!state.valid;
   for(int i=0;i<4;i++){moved|=!vertices[i].Equals(state.vertices[i]);retextured|=!uv[i].Equals(state.uv[i]);}
   if(moved){mesh.vertices=vertices;mesh.RecalculateBounds();Array.Copy(vertices,state.vertices,4);}
   if(retextured){mesh.uv=uv;Array.Copy(uv,state.uv,4);}
   if(!state.valid)mesh.triangles=QuadIndices;
   state.valid=true;
  }
 }
 public sealed partial class NativeLightField {
  struct FloorReceiver {public double left,top,right,bottom;public Vector4 rectangle;}
  FloorReceiver[,] floorReceivers;
  void PrepareFloorReceivers(){
   floorReceivers=new FloorReceiver[grid[0].Length,grid.Length];const float depth=1.6f;
   for(int y=0;y<grid.Length;y++)for(int x=0;x<grid[0].Length;x++){
    double l=x*16,r=l+16,t=y*16,b=t+16;byte f=receiverFlags[x,y];
    l+=(f&1)!=0?depth:0;r-=(f&2)!=0?depth:0;t+=(f&4)!=0?depth:0;b-=(f&8)!=0?depth:0;
    floorReceivers[x,y]=new FloorReceiver{left=l,top=t,right=r,bottom=b,rectangle=new Vector4((float)l,(float)t,(float)r,(float)b)};
   }
  }
 }
}

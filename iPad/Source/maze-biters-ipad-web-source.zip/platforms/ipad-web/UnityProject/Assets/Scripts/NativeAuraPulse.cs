using System;
namespace MazeBiters.NativeStudy {
 // A balanced breathing cycle. Game time freezes with pause; direction changes
 // cannot restart this phase, and hidden preparation owns no extra clock state.
 public static class NativeAuraPulse {
  public const double PeriodMs=2400;
  public const float MinimumScale=.88f;
  public static float ScaleAt(double gameTime){
   if(double.IsNaN(gameTime)||double.IsInfinity(gameTime))throw new ArgumentOutOfRangeException(nameof(gameTime));
   double phase=(gameTime-1000)%PeriodMs;
   return 1f-(1f-MinimumScale)*.5f*(float)(1-Math.Cos(phase*(2*Math.PI/PeriodMs)));
  }
 }
}

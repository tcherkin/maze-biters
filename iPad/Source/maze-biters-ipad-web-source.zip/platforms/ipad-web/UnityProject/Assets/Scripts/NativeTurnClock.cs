using System;
namespace MazeBiters.NativeStudy {
 // Scalar port of frozen fantasy-turn-clock.js. Visual state never changes
 // the simulation heading or delays a committed movement.
 [Serializable] public struct TurnPose {public double angle,mix,progress;public int from,to;public bool done;}
 public sealed class NativeTurnClock {
  int kind,from,to,deltaPlan;double started,last,start,target,delta,velocity,brakeMs,brakeEnd;bool active;
  readonly bool rememberHorizontal;int lastHorizontal;
  public int LastHorizontal=>lastHorizontal;
  // Opt-in for human players only. Hunters and frozen reference fixtures keep
  // their original routing. Directions: right=0, down=1, left=2, up=3.
  public NativeTurnClock(bool rememberHorizontal=false,int initialDirection=0){this.rememberHorizontal=rememberHorizontal;lastHorizontal=initialDirection==2?2:0;}
  static double Clamp(double x)=>Math.Max(0,Math.Min(1,x));
  static double Ease(double x)=>x*x*x*(10+x*(-15+6*x));
  static double Speed(double x)=>30*x*x*(1-x)*(1-x);
  static double Wrap(double x)=>(x%4+4)%4;
  static int Dir(double x)=>(int)Wrap(x);
  public void Reset(){active=false;lastHorizontal=0;}
  public TurnPose Request(int a,int b,double time){
   if(a<0||a>3||b<0||b>3||double.IsNaN(time)||double.IsInfinity(time))throw new ArgumentException("Invalid turn request");
   // Request is called for a COMMITTED heading, not a held/blocked input key.
   // Sampling, mouth/blink rendering and hidden scene preparation never write
   // this memory. Repeated vertical reversals keep the same chosen side.
   if(rememberHorizontal){if(a%2==0)lastHorizontal=a;if(b%2==0)lastHorizontal=b;}
   bool verticalReverse=rememberHorizontal&&a%2==1&&b%2==1&&a!=b;
   int plan=verticalReverse?((a==3)==(lastHorizontal==0)?2:-2):AnimationClock.TurnDelta(a,b);
   if(active&&(time<last||(to!=a&&to!=b)))active=false;
   if(active&&to==b){last=time;return Sample(time,out _);}
   var prior=active?Sample(time,out _):default;double priorVelocity=0;if(active)Sample(time,out priorVelocity);
   double nextStart=active?prior.angle:a,cw=Wrap(b-Wrap(nextStart));
   double d=cw==0?0:a==2&&b==0?cw-4:cw>2?cw-4:cw;
   // Also apply the chosen half-circle to interrupted turns. The existing
   // braking/easing keeps the current pose and velocity continuous (90ms).
   if(verticalReverse&&cw!=0)d=plan>0?cw:cw-4;
   double nextTarget=Math.Round(nextStart+d);
   bool native=!active||prior.done;
   from=a;to=b;started=last=time;start=nextStart;target=nextTarget;delta=target-start;velocity=priorVelocity;
   deltaPlan=plan;kind=0;
   if(!native){bool aligned=velocity*delta>0;
    if(Math.Abs(velocity)<1e-12||aligned&&Math.Abs(velocity)*90<=2.5*Math.Abs(delta))kind=1;
    else {kind=2;brakeMs=Math.Min(12,2*.025/Math.Abs(velocity));if(aligned)brakeMs=Math.Min(brakeMs,Math.Abs(delta/velocity));
     if(verticalReverse){
      // Near an endpoint, braking must not briefly poke into the opposite
      // half-circle before returning. Preserve the existing braking elsewhere.
      double center=lastHorizontal+4*Math.Round((start-lastHorizontal)/4);
      if(start>=center-1&&start<=center+1){double room=Math.Max(0,(center+Math.Sign(velocity)-start)*Math.Sign(velocity));brakeMs=Math.Min(brakeMs,2*room/Math.Abs(velocity));}
     }
     brakeEnd=start+velocity*brakeMs/2;}
   }
   active=true;return Sample(time,out _);
  }
  public TurnPose Sample(double time,int fallback=0){return active?Sample(time,out _):new TurnPose{angle=fallback,from=fallback,to=fallback,done=true};}
  TurnPose Sample(double time,out double speed){
   double elapsed=Math.Max(0,time-started),u=Clamp(elapsed/90);speed=0;
   if(kind==0){
    if(deltaPlan==0||u==1)return new TurnPose{angle=start+deltaPlan,from=to,to=to,done=true,progress=u};
    var e=Clamp(Ease(u));int sign=Math.Sign(deltaPlan);double traveled=Math.Abs(deltaPlan)*e;int segment=Math.Min(Math.Abs(deltaPlan)-1,(int)Math.Floor(traveled));
    speed=u>0&&u<1?deltaPlan*Speed(u)/90:0;
    return new TurnPose{angle=start+deltaPlan*e,from=Dir(from+sign*segment),to=Dir(from+sign*(segment+1)),mix=Clamp(traveled-segment),progress=u};
   }
   if(u==1)return new TurnPose{angle=target,from=to,to=to,done=true,progress=1};
   double angle;
   if(kind==2){if(elapsed<brakeMs){angle=start+velocity*(elapsed-elapsed*elapsed/(2*brakeMs));speed=velocity*(1-elapsed/brakeMs);}
    else {double remaining=90-brakeMs,v=Clamp((elapsed-brakeMs)/remaining);angle=brakeEnd+(target-brakeEnd)*Ease(v);speed=(target-brakeEnd)*Speed(v)/remaining;}}
   else{double m=velocity*90,a=10*delta-6*m,b=-15*delta+8*m,c=6*delta-3*m;
    angle=start+m*u+a*u*u*u+b*u*u*u*u+c*u*u*u*u*u;speed=(m+3*a*u*u+4*b*u*u*u+5*c*u*u*u*u)/90;}
   int step=Math.Sign(speed);if(step==0)step=Math.Sign(delta);if(step==0)step=1;double at=step>0?Math.Floor(angle):Math.Ceiling(angle);
   return new TurnPose{angle=angle,from=Dir(at),to=Dir(at+step),mix=Clamp(Math.Abs(angle-at)),progress=u};
  }
 }
}

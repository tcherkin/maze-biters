using System;using System.Collections;using System.Collections.Generic;using System.Diagnostics;using System.IO;using System.Linq;using UnityEngine;
namespace MazeBiters.NativeStudy {
 public sealed partial class NativeGameplayStudy {
  bool splitProbe;
  [Serializable] sealed class SplitSample {public int palette,index,textureDecodes;public double contactMs,renderMs;public bool passed;}
  [Serializable] sealed class TailSample {public string mode;public double time,length,desiredLength,tipX,tipY,playerX,playerY;public int cells;public bool trim,birth,backwards;}
  [Serializable] sealed class SplitReport {public string quality;public bool passed;public SplitSample[] splits;public TailSample[] tails;}
  IEnumerator ProbeSplits(){
   var splits=new List<SplitSample>();var tails=new List<TailSample>();bool tailChecks=true;string folder=Path.ChangeExtension(report,null);Directory.CreateDirectory(folder);
   for(int test=0;test<10;test++){
    Reset(9);time=world.Time=2000;var p=world.Player;int palette=test/2,index=test%2==0?3:1;
    var s=world.AddSnake(Enumerable.Range(0,7).Select(i=>new Vector2Int(9-i,1)),Vector2Int.right,palette);AddSnake(s);
    p.Cell=p.From=p.Previous=s.Body[index]+Vector2Int.up;p.Dir=p.Next=Vector2Int.down;p.Waiting=true;
    for(int i=0;i<6;i++){Render();yield return null;}
    int decoded=NativeSnakeTextures.DecodeCount;long resident=NativeSnakeTextures.ResidentBytes;
    var watch=Stopwatch.StartNew();world.Eat(s,index);double contact=watch.Elapsed.TotalMilliseconds;watch.Restart();Render();double render=watch.Elapsed.TotalMilliseconds;
    int extraDecodes=NativeSnakeTextures.DecodeCount-decoded;
    splits.Add(new SplitSample{palette=palette,index=index,contactMs=contact,renderMs=render,textureDecodes=extraDecodes,passed=world.Snakes.Count==2&&world.Snakes.Sum(x=>x.Body.Count)==6&&world.Player.Score==10&&extraDecodes==0&&NativeSnakeTextures.ResidentBytes==resident});
    Capture(Path.Combine(folder,"split-"+test+"-0.png"));yield return null;
    for(int i=1;i<=24;i++){time=world.Time=2000+i*8.33333333;Render();if(i==6||i==18)Capture(Path.Combine(folder,"split-"+test+"-"+i+".png"));yield return null;}
   }
   // A real dead end in the unchanged maze: no advance or sideways exit.
   // Actual original world tick, alternating retreat/forward attempts and input.
   for(int direction=0;direction<4;direction++)foreach(bool powered in new[]{false,true}){
    Reset(9);time=world.Time=2000;var head=new[]{new Vector2Int(34,1),new Vector2Int(11,5),new Vector2Int(11,9),new Vector2Int(24,9)}[direction];var dir=new[]{Vector2Int.down,Vector2Int.up,Vector2Int.left,Vector2Int.right}[direction];int count=direction==0?7:direction==1?3:2;
    string mode=(powered?"power":"normal")+(direction==0?"":new[]{"","-down","-left","-right"}[direction]);
    var s=world.AddSnake(Enumerable.Range(0,count).Select(i=>head-dir*i),dir,0);AddSnake(s);
    var p=world.Player;p.Cell=p.From=p.Previous=head-dir*count;p.Dir=p.Next=dir;p.Waiting=false;world.Press("probe",dir);if(powered)world.ActivatePower();
    for(int i=0;i<200;i++){
     time=2000+i*8.33333333;world.Tick(time);Render();
     if(world.Snakes.Count>0){var live=snakes.Values.First().motion;var pose=live.Evaluate(time);var tip=pose.rail.Sample(pose.Tip);var player=p.Visual(time);tails.Add(new TailSample{mode=mode,time=time,length=pose.length,desiredLength=live.trim?.to??live.birth?.to??pose.length,tipX=tip.x/36-.5,tipY=tip.y/36-.5,playerX=player.x,playerY=player.y,cells=live.Count,trim=live.trim!=null,birth=live.birth!=null,backwards=live.Backwards});}
     if(i%20==0)Capture(Path.Combine(folder,"blocked-"+mode+"-"+i+".png"));yield return null;
    }
    tailChecks&=!p.Dead&&world.Snakes.Count==0&&p.Score==25*(count-1)+125;
   }
   bool passed=tailChecks&&splits.All(x=>x.passed);File.WriteAllText(report,JsonUtility.ToJson(new SplitReport{quality=quality,passed=passed,splits=splits.ToArray(),tails=tails.ToArray()},true));Application.Quit(passed?0:2);
  }
 }
}

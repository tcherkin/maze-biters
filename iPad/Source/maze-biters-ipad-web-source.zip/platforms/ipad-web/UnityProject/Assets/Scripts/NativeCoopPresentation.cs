using System;using UnityEngine;
namespace MazeBiters.NativeStudy {
 public sealed partial class NativeGameplayStudy {
  readonly TurnPose[] humanPoses=new TurnPose[3];readonly int[] humanMouths=new int[3];
  NativeIntakeLayer PlayerIntake(int id)=>id==1?intake:id==2?secondIntake:thirdIntake;
  void RenderPlayers(){
   Array.Clear(leaderLayers,0,leaderLayers.Length);
   if(world.Multiplayer&&(coopArt==null||coopArtQuality!=quality)){coopArt?.Dispose();coopArt=new NativeCoopArt(quality);coopArtQuality=quality;}
   for(int i=0;i<world.PlayerCount;i++)using(world.ForPlayer(world.GetPlayer(i))){
    var p=world.Player;var actor=actors[p.Id];var pose=actor.turn.Sample(time,Bank(p.Dir));
    double walking=AnimationClock.Mouth(time-p.MoveStarted,p.MoveDuration,p.From==p.Cell?0:1);
    int mouth=AnimationClock.Frame(AnimationClock.Bite(time,p.BiteAt,p.BiteEnd,world.Multiplayer?actor.biteInitial:biteInitial,walking),48);
    actor.art.Bright=world.PlayerBright;bank.Render(actor.art,pose,mouth,AnimationClock.Frame(actor.blink.Sample(time),24));
    bool leader=world.Multiplayer&&!p.Dead&&world.LeaderId==p.Id;if(world.Multiplayer){if(actor.leader==null)actor.leader=new NativeCoopLeader(coopArt,quad);actor.leader.Render(actor.art,pose,p,time,leader);leaderLayers[i]=actor.leader;}
    actor.renderer.sharedMaterial=leader?actor.leader.Display:actor.art.Display;Position(actor,p.Visual(time),p.Tilt);actor.renderer.transform.localScale=new Vector3(16,16,1);if(leader){float s=actor.leader.Scale;var q=actor.renderer.transform.rotation;var v=p.Visual(time);actor.renderer.transform.localScale=new Vector3(16*s,16*s,1);actor.renderer.transform.position=new Vector3((v.x+.5f)*16,-(v.y+.5f)*16,-1)-q*new Vector3(8*s,-8*s,0);}actor.renderer.enabled=!p.Dead;
    humanPoses[i]=pose;humanMouths[i]=mouth;
   }
  }
  void RenderPlayerIntakes(){for(int i=0;i<world.PlayerCount;i++){var p=world.GetPlayer(i);PlayerIntake(p.Id).Render(bank,actors[p.Id].art,humanPoses[i],humanMouths[i],p,time);}}
  void RenderPlayerLights(){for(int i=0;i<world.PlayerCount;i++)using(world.ForPlayer(world.GetPlayer(i))){
   var p=world.Player;double life=p.Dead?world.DeathAlpha:1;
   if(NativeGlassPresentation.Enabled&&glassEmission){var vector=actors[p.Id].aura.Sample(time,Bank(p.Dir));float auraSize=NativeAuraPulse.ScaleAt(time);if(i==0)dusk.RenderAuraPose(p.Visual(time),vector,world.PowerStrength,p.Dead,life,world.Multiplayer,auraSize);else dusk.AppendAuraPose(p.Visual(time),vector,world.PowerStrength,p.Dead,life,auraSize);}
   else if(i==0)dusk.RenderHeadPose(p.Visual(time),humanPoses[i],p.Tilt,world.PowerStrength,p.Dead,life,world.Multiplayer);
   else dusk.AppendHeadPose(p.Visual(time),humanPoses[i],p.Tilt,world.PowerStrength,p.Dead,life);
  }}
  Material CoopPlayerMaterial(int slot=1){var p=world.GetPlayer(slot);using(world.ForPlayer(p))return p.Dead?(world.DeathAlpha>0?sessionArt.PlayerSkullMaterial(slot):null):actors[p.Id].renderer.sharedMaterial;}
  Matrix4x4 CoopPlayerTransform(int slot=1)=>world.GetPlayer(slot).Dead?sessionArt.PlayerSkullTransform(slot):actors[world.GetPlayer(slot).Id].renderer.transform.localToWorldMatrix;
 }
}

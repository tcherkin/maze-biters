using System;
using System.IO;
using System.Collections;
using System.Collections.Generic;
using System.Text;
using System.Globalization;
using UnityEngine;
namespace MazeBiters.NativeStudy {
 public sealed partial class NativeGameplayStudy {
  [Serializable] sealed class IpadRosterRenderResult {public bool passed;public int width,height,players,frames,checks,deaths,respawns;public string note;public List<string> images;}
  IEnumerator ProbeIpadRosterCamera(){
   ipadBalanceProbe=Array.IndexOf(Environment.GetCommandLineArgs(),"--ipad-balance-probe")>=0;
   ipadSoloPaceProbe=Array.IndexOf(Environment.GetCommandLineArgs(),"--ipad-solo-pace-probe")>=0;
   ipadPostRespawnProbe=Array.IndexOf(Environment.GetCommandLineArgs(),"--ipad-post-respawn-probe")>=0;
   string dir=Path.GetDirectoryName(report);Directory.CreateDirectory(dir);int checks=0,frames=0,deaths=0,respawns=0;
   string movieDir=Path.Combine(dir,"motion");if(ipadBalanceProbe&&quality=="hd")Directory.CreateDirectory(movieDir);
   var images=new List<string>();void Check(bool ok,string label){checks++;if(!ok)throw new Exception("iPad roster rendering: "+label);}
   foreach(string kind in (ipadBalanceProbe||ipadSoloPaceProbe)?new[]{"farfinal","respawn"}:new[]{"movement","respawn"}){
    sessionSmoke=true;fixedCamera=false;ipadRosterBeforeProbe=false;Reset(12);yield return DrainProbePreparation();
    Check(world.PlayerCount>=2,"multiplayer fixture");var scenario=new IpadRosterScenario(world,kind,1.4);
    realClock=time=1000;ResetGameplayCamera();
    var csv=new StringBuilder("frame,time,event,oldX,oldY,oldZoom,newX,newY,newZoom,oldCorrections,newCorrections,revealing\n");int count=kind=="movement"?1680:840;
    for(int frame=0;frame<count;frame++){
     double elapsed=frame*1000.0/60;scenario.Step(elapsed,(p,from,to)=>actors[p.Id].turn.Request(Bank(from),Bank(to),world.Time));
     realClock=1000+elapsed;time=world.Time;string state=MenuFullState;
     bool shot=kind=="movement"?(frame==400||frame==850||frame==1400):frame==350||frame==470||frame==490||frame==505||frame==700||frame==835||scenario.Event.StartsWith("respawn")||kind=="farfinal"&&scenario.Event.StartsWith("death")||frame==600;
     string label=kind+"-"+(scenario.Event.Length>0?scenario.Event:frame.ToString());
     bool movie=ipadBalanceProbe&&quality=="hd"&&world.PlayerCount==3&&kind=="farfinal"&&frame>=330&&frame<840&&frame%2==0;
     ipadRosterBeforeProbe=true;preparationLightFrame=true;Render();double bx=cameraViewX,by=cameraViewY,bz=cameraViewZoom;
     if(movie)Capture(Path.Combine(movieDir,"before-"+((frame-330)/2).ToString("D4")+".png"));
     if(shot){Capture(Path.Combine(dir,"before-"+label+".png"));images.Add(label);}
     ipadRosterBeforeProbe=false;preparationLightFrame=true;Render();
     Check(MenuFullState==state,"render preserves original simulation "+kind+" "+frame);
     var bounds=IpadCameraRoster.Bounds(world,time,excludeMask:ipadCameraMotion.JoiningMask);var f=DisplayFrame;
     if(bounds.HasValue){var b=bounds.Value;var board=f.ProjectBoard(cameraViewX,cameraViewY,cameraViewZoom);
      Check(board.x+(b.xMin-12)*cameraViewZoom>=-.01&&board.x+(b.xMax+12)*cameraViewZoom<=f.Width+.01&&board.y+(b.yMin-12)*cameraViewZoom>=-.01&&board.y+(b.yMax+12)*cameraViewZoom<=f.Height+.01,"all active silhouettes visible");
     }
     for(int i=0;i<world.PlayerCount;i++){var p=world.GetPlayer(i);if(p.Dead||p.Eliminated)continue;var v=p.Visual(time);var center=actors[p.Id].renderer.transform.TransformPoint(new Vector3(.5f,-.5f,0));var screen=camera.WorldToViewportPoint(center);
      double sx=f.Width/2+((v.x+.5)*16-cameraViewX)*cameraViewZoom,sy=f.Height/2+((v.y+.5)*16-cameraViewY)*cameraViewZoom;
      Check(Math.Abs(screen.x*f.Width-sx)<.003&&Math.Abs((1-screen.y)*f.Height-sy)<.003,"actor projection and unchanged interpolation");
     }
     if(movie)Capture(Path.Combine(movieDir,"after-"+((frame-330)/2).ToString("D4")+".png"));
     if(shot)Capture(Path.Combine(dir,"after-"+label+".png"));
     if(frame==650){var position=camera.transform.position;float size=camera.orthographicSize;scenePreparationPending=true;PrepareSceneGpu();Check(position==camera.transform.position&&size==camera.orthographicSize,"GPU preflight preserves roster camera");}
     csv.Append(frame).Append(',').Append(realClock.ToString("R",CultureInfo.InvariantCulture)).Append(',').Append(scenario.Event);
     foreach(double value in new[]{bx,by,bz,cameraViewX,cameraViewY,cameraViewZoom,(double)(ipadBalanceProbe?ipadBeforeBalance.EmergencyCorrections:ipadSoloPaceProbe?ipadFastRespawnReference.EmergencyCorrections:ipadPostRespawnProbe?ipadAnticipatoryReference.EmergencyCorrections:ipadRosterPreviousCamera.EmergencyCorrections),ipadCameraMotion.EmergencyCorrections,ipadCameraMotion.Revealing?1:0})csv.Append(',').Append(value.ToString("R",CultureInfo.InvariantCulture));csv.AppendLine();frames++;yield return null;
    }
    deaths+=scenario.Deaths;respawns+=scenario.Respawns;
    Check(kind=="movement"||scenario.Deaths==world.PlayerCount-1&&scenario.Respawns==(kind=="farfinal"?0:world.PlayerCount-1),"original death and respawn completed");
    File.WriteAllText(Path.Combine(dir,kind+".csv"),csv.ToString());
   }
   File.WriteAllText(report,JsonUtility.ToJson(new IpadRosterRenderResult{passed=true,width=target.width,height=target.height,players=world.PlayerCount,frames=frames,checks=checks,deaths=deaths,respawns=respawns,images=images,note="Controlled 60 Hz samples with real rendering and original SessionDeath / UpdateDeath. Coherent affine camera; death1560 ms / respawn3120 ms with bounded forward carry, one reference and no handoff: existing participants remain visible; a distant newly born participant enters the view during the reveal. No camera anticipation. Not measured FPS or M5 device performance."},true));Application.Quit();
  }
 }
}

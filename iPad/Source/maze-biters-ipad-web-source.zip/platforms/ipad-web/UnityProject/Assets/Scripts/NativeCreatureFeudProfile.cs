using System;
namespace MazeBiters.NativeStudy {
 // Mischief is independent of appetite: a hunter severs a body to open a path,
 // never receives food, points or power. The existing level clock grades intent.
 public struct NativeCreatureFeudProfile {
  public double Chance,Pursuit,DecisionMs,Notice,CutCooldownMs;
  static readonly double[] chance={.05,.16,.34,.47,.54},pursuit={.025,.10,.26,.37,.44},decision={3600,3300,3000,2700,2400};
  static readonly double[] notice={3,5,8,12,18},cooldown={2600,2200,1700,1200,850};
  static double Blend(double[] a,double x){int lo=(int)x,hi=Math.Min(4,lo+1);return a[lo]+(a[hi]-a[lo])*(x-lo);}
  public static NativeCreatureFeudProfile ForIntensity(double intensity){
   double x=double.IsNaN(intensity)?0:Math.Max(0,Math.Min(4,intensity));
   return new NativeCreatureFeudProfile{Chance=Blend(chance,x),Pursuit=Blend(pursuit,x),DecisionMs=Blend(decision,x),Notice=Blend(notice,x),CutCooldownMs=Blend(cooldown,x)};
  }
 }
}

using System;using UnityEngine;
namespace MazeBiters.NativeStudy {
 public sealed partial class NativeHud {
  static readonly int OcclusionOpacity=Shader.PropertyToID("_OcclusionOpacity");
  internal const double ContactOpacity=.25;
  readonly bool[] contacts=new bool[8];
  readonly double[] contactAlpha={1,1,1,1,1,1,1,1};
  readonly double[] contactVelocity=new double[4];
  double contactAt=double.NaN,contactZoom=1,contactX,contactY;
  bool contactEnabled;
  // Exact critically damped response, in milliseconds. Preserve velocity as well
  // as opacity when contact changes, so starts and reversals have no abrupt slope.
  // About 95% of the change occurs in 340ms out / 530ms back.
  internal static double FadeContact(double current,ref double velocity,bool touching,double milliseconds){
   double dt=Math.Max(0,Math.Min(50,milliseconds));if(dt==0)return current;
   double goal=touching?ContactOpacity:1;
   double omega=touching?.014:.009,delta=current-goal,step=(velocity+omega*delta)*dt,decay=Math.Exp(-omega*dt);
   double value=goal+(delta+step)*decay;velocity=(velocity-omega*step)*decay;
   if(value<ContactOpacity){velocity=0;return ContactOpacity;}if(value>1){velocity=0;return 1;}
   if(Math.Abs(value-goal)<.0001&&Math.Abs(velocity)<.000001){velocity=0;return goal;}
   return value;
  }
  internal void ResetContacts(){
   contactAt=double.NaN;Array.Clear(contacts,0,contacts.Length);
   Array.Clear(contactVelocity,0,contactVelocity.Length);
   for(int i=0;i<rows.Length;i++){contactAlpha[i]=1;rows[i].material.SetFloat(OcclusionOpacity,1);}
  }
  internal void BeginContacts(NativeFrame frame,double cx,double cy,double zoom,bool enabled=true){
   Array.Clear(contacts,0,contacts.Length);contactEnabled=frame.OverlayHud&&enabled;
   contactZoom=zoom;contactX=frame.Width/2-cx*zoom-ipadLeft;contactY=frame.Height/2+frame.ViewOffsetY-cy*zoom-ipadTop;
  }
  internal bool NearHeader(double left,double top,double right,double bottom){
   return contactEnabled&&bottom*contactZoom+contactY>=-2&&top*contactZoom+contactY<=34&&right*contactZoom+contactX>=-2&&left*contactZoom+contactX<=frameWidth+2;
  }
  internal void Obstacle(double left,double top,double right,double bottom){
   if(!NearHeader(left,top,right,bottom))return;
   double l=left*contactZoom+contactX-2,r=right*contactZoom+contactX+2,t=top*contactZoom+contactY-2,b=bottom*contactZoom+contactY+2;
   for(int i=0;i<rows.Length;i++){var row=rows[i];if(!contacts[i]&&row.go.activeSelf&&l<row.right&&r>row.left&&t<row.yPosition+16&&b>row.yPosition)contacts[i]=true;}
  }
  internal bool NearHeader(Bounds bounds)=>NearHeader(bounds.min.x,-bounds.max.y,bounds.max.x,-bounds.min.y);
  internal void Obstacle(Bounds bounds)=>Obstacle(bounds.min.x,-bounds.max.y,bounds.max.x,-bounds.min.y);
  internal void EndContacts(double realTime){
   double elapsed=double.IsNaN(contactAt)?0:Math.Max(0,realTime-contactAt);contactAt=realTime;
   for(int i=0;i<rows.Length;i+=2){
    // Score/lives and level/snakes always share one contact envelope. Original
    // score and life animations still compose independently under that envelope.
    bool touching=contacts[i]||contacts[i+1];contacts[i]=contacts[i+1]=touching;
    double value=FadeContact(contactAlpha[i],ref contactVelocity[i/2],touching,elapsed);
    if(value==contactAlpha[i])continue;contactAlpha[i]=contactAlpha[i+1]=value;
    rows[i].material.SetFloat(OcclusionOpacity,(float)value);rows[i+1].material.SetFloat(OcclusionOpacity,(float)value);
   }
  }
  internal double ContactAlpha(int row)=>contactAlpha[row];
  internal bool Contact(int row)=>contacts[row];
  internal Rect ContactRect(int row)=>new Rect(rows[row].left,rows[row].yPosition,rows[row].right-rows[row].left,16);
  internal void ProbeVisible(bool visible)=>root.SetActive(visible);
 }
 public sealed partial class NativeSnake {
  // Already prepared silhouette includes bending, splitting and intake transforms.
  // Broad rejection avoids traversing the bodies of snakes below the header.
  internal void AddHudObstacles(NativeHud hud){
   if(Culled||!ReadyForCulling)return;
   if(!intakeOnly)hud.Obstacle(headMesh.bounds);
   if(oi.Count==0||!hud.NearHeader(outline.bounds))return;
   for(int i=0;i<oi.Count;i+=6){
    var p=ov[oi[i]];float left=p.x,right=p.x,top=-p.y,bottom=-p.y;
    for(int j=1;j<6;j++){p=ov[oi[i+j]];left=Math.Min(left,p.x);right=Math.Max(right,p.x);top=Math.Min(top,-p.y);bottom=Math.Max(bottom,-p.y);}
    hud.Obstacle(left,top,right,bottom);
   }
  }
 }
 public sealed partial class NativeGameplayStudy {
  static readonly bool legacyHudClearance=Array.IndexOf(Environment.GetCommandLineArgs(),"--legacy-hud-clearance")>=0;
  bool compareHudClearance;
  void HudHead(Vector2 cell,double radius=10){double x=(cell.x+.5)*16,y=(cell.y+.5)*16;hud.Obstacle(x-radius,y-radius,x+radius,y+radius);}
  void CollectHudContacts(){
   hud.BeginContacts(DisplayFrame,cameraViewX,cameraViewY,cameraViewZoom,NativeDisplay.Enabled&&!legacyHudClearance&&!compareHudClearance);
   if(!NativeDisplay.Enabled||legacyHudClearance||compareHudClearance||world==null)return;
   for(int i=0;i<world.PlayerCount;i++){
    var p=world.GetPlayer(i);if(p.Dead?p.HideDeath:p.Eliminated)continue;
    HudHead(p.Dead?(Vector2)p.Cell:p.Visual(time),p.Dead?8:10);
   }
   foreach(var h in PresentedHunters){if(actors.TryGetValue(h.Id,out var a)&&a.renderer.enabled)HudHead(Vector2.Lerp(h.From,h.Cell,(float)Math.Max(0,Math.Min(1,(CreaturePresentationTime-h.MoveStarted)/h.MoveDuration))));}
   if(drawn!=null)for(int i=0;i<drawn.Length;i++)drawn[i]?.AddHudObstacles(hud);
   if(pickups!=null)foreach(var p in pickups.Poses)if(p.alpha>0)HudHead(p.cell,8);
   if(renderScorpions!=null)foreach(var s in renderScorpions){
    if(s==null||!s.Visible||s.Opacity<=0||s.Pose==null||s.Pose.scale<=0)continue;var pose=s.Pose;
    for(int i=-16;i<=16;i+=8){var p=pose.Sample(i);double x=pose.targetX+(p.x-pose.x)*pose.scale,y=pose.targetY+(p.y-pose.y)*pose.scale,r=8*pose.scale;hud.Obstacle(x-r,y-r,x+r,y+r);}
   }
  }
  void UpdateHudClearance(){
   // Hidden preparation cannot advance the live fade or expose future actors.
   if(hud==null||preparingScene||preparingNextScene||menuPreparing)return;
   CollectHudContacts();hud.EndContacts(realClock);
  }
 }
}

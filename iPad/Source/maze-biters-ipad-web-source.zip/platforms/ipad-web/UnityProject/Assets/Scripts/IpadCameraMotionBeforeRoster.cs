using System;
using UnityEngine;
namespace MazeBiters.NativeStudy {
 // One camera follow stage, with the PC's 470 ms response. Tablet framing is
 // part of the destination, not a second warp applied after the follow step.
 public sealed class IpadCameraMotionBeforeRoster {
  bool ready;double stamp;IpadView current;float width,height;Rect lastSafe;double lastClose;
  public int EmergencyCorrections{get;private set;}
  public void Reset(){ready=false;EmergencyCorrections=0;}
  static double Clamp(double x,double a,double b)=>a>b?(a+b)/2:Math.Max(a,Math.Min(b,x));
  static double Blend(double dt,double tau)=>1-Math.Exp(-dt/tau);
  // Ease the same follow stage forward before an actor reaches the edge.
  // This avoids switching directly to the actor's 95 ms cell interpolation.
  static double Response(double clearance)=>470-300*IpadFraming.Smooth((40-clearance)/40);
  public IpadView Sample(NativeFrame f,double x,double y,double zoom,double close,Rect safe,Rect? bounds,double real,double? targetX=null,double? targetY=null){
   var desired=IpadFraming.Calculate(f,x,y,zoom,close,safe);
   bool reset=!ready||real<stamp||width!=f.Width||height!=f.Height||lastSafe!=safe||lastClose!=close;
   if(reset){ready=true;width=f.Width;height=f.Height;lastSafe=safe;lastClose=close;stamp=real;current=bounds.HasValue?IpadFraming.KeepPlayers(f,desired,bounds.Value,safe):desired;return current;}
   if(real==stamp)return current;
   double dt=Math.Max(0,Math.Min(50,real-stamp));stamp=real;
   double sx=targetX??x,sy=targetY??y;
   var goal=IpadFraming.Calculate(f,sx,sy,zoom,close,safe);
   double tauX=470,tauY=470;
   if(bounds.HasValue){var b=bounds.Value;double z=goal.zoom,top=Math.Max(safe.yMin,goal.header);
    double minX=b.xMax+12-(safe.xMax-f.Width/2)/z,maxX=b.xMin-12+(f.Width/2-safe.xMin)/z;
    double minY=b.yMax+12-(safe.yMax-f.Height/2)/z,maxY=b.yMin-12+(f.Height/2-top)/z;
    tauX=Response(Math.Min(current.x-minX,maxX-current.x));tauY=Response(Math.Min(current.y-minY,maxY-current.y));
    goal=IpadFraming.KeepPlayers(f,goal,b,safe);
   }
   var view=goal;view.x=current.x+(goal.x-current.x)*Blend(dt,tauX);view.y=current.y+(goal.y-current.y)*Blend(dt,tauY);
   // The PC world-boundary clamp, expressed in the tablet viewport.
   double sky=52*IpadFraming.Smooth((zoom-1)/.5),minWorldX=(f.Width/2-sky)/view.zoom,maxWorldX=576-minWorldX;
   double minWorldY=(f.Height/2-view.header-sky)/view.zoom,maxWorldY=400-(f.Height/2-sky)/view.zoom;
   view.x=Clamp(view.x,minWorldX,maxWorldX);view.y=Clamp(view.y,minWorldY,maxWorldY);
   if(bounds.HasValue){var protectedView=IpadFraming.KeepPlayers(f,view,bounds.Value,safe);
    if(Math.Abs(protectedView.x-view.x)>.001||Math.Abs(protectedView.y-view.y)>.001||Math.Abs(protectedView.zoom-view.zoom)>.00001)EmergencyCorrections++;
    view=protectedView;
   }
   current=view;return view;
  }
 }
}


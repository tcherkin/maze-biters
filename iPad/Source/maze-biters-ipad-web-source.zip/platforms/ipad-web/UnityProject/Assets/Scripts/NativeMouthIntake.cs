using System;
using UnityEngine;
namespace MazeBiters.NativeStudy {
 // Exact Fantasy Biter cavity destination, including approved +12.5% fit.
 // Pure presentation: never changes the player or collision coordinates.
 public static class NativeMouthIntake {
  public const double SideReach=72.0/160;
  public static RailPoint Target(Vector2 position,Vector2Int direction,double tilt,double tile=36){
   double x=80,y=52;
   if(direction.x>0){x=111.5;y=111;}
   else if(direction.x<0){x=48.5;y=111;}
   else if(direction.y>0){y=110;}
   double dx=(x-80)*tile/160,dy=(y-80)*tile/160,angle=tilt*Math.PI/180;
   return new RailPoint{x=(position.x+.5)*tile+dx*Math.Cos(angle)-dy*Math.Sin(angle),y=(position.y+.5)*tile+dx*Math.Sin(angle)+dy*Math.Cos(angle)};
  }
 }
}

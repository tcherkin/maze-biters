using System;using System.Collections.Generic;using UnityEngine;
namespace MazeBiters.NativeStudy {
 public static class SnakeResourceValidation {
  public static int Run(){
   int checks=0;long initial=NativeSnakeTextures.ResidentBytes;
   void Check(bool value,string message){checks++;if(!value)throw new Exception("SNAKE RESOURCE: "+message);}
   foreach(string palette in NativeGameplayStudy.Colors){
    var first=new NativeSnake(palette,"lit");long bytes=NativeSnakeTextures.ResidentBytes;int decoded=NativeSnakeTextures.DecodeCount;
    var second=new NativeSnake(palette,"lit");
    Check(NativeSnakeTextures.ResidentBytes==bytes&&NativeSnakeTextures.DecodeCount==decoded,"split reused "+palette);
    Check(first.TextureBytes+second.TextureBytes==bytes-initial,"shared accounting "+palette);
    var tail=new NativeSnake(palette,"lit",null,true);
    Check(NativeSnakeTextures.ResidentBytes==bytes&&NativeSnakeTextures.DecodeCount==decoded,"intake reused material "+palette);
    first.Dispose();
    Check(NativeSnakeTextures.ResidentBytes==bytes&&second.TextureBytes+tail.TextureBytes==bytes-initial,"ownership transfer "+palette);
    var glow=new NativeSnake(palette,"emission",second);long both=NativeSnakeTextures.ResidentBytes;decoded=NativeSnakeTextures.DecodeCount;
    var otherGlow=new NativeSnake(palette,"emission",second);
    Check(NativeSnakeTextures.ResidentBytes==both&&NativeSnakeTextures.DecodeCount==decoded,"split glow reused "+palette);
    glow.Dispose();otherGlow.Dispose();
    Check(NativeSnakeTextures.ResidentBytes==bytes,"glow released "+palette);
    second.Dispose();Check(NativeSnakeTextures.ResidentBytes>initial,"intake still owns material "+palette);
    tail.Dispose();Check(NativeSnakeTextures.ResidentBytes==initial,"last owner freed "+palette);
   }
   // Independent bite clock: a stationary/held tail finishes on the player's
   // step even without another locomotion event. No snap at contact.
   foreach(double step in new[]{95.0,47.5})foreach(bool reverse in new[]{false,true})foreach(bool held in new[]{false,true}){
    var s=new NativeGameplaySnake{Dir=Vector2Int.right,Reversing=reverse};
    for(int i=0;i<7;i++)s.Body.Add(new Vector2Int(9-i,1));
    var live=new NativeLiveSnake(s,1000);if(held)live.HeldAt=1000;
    var p=new NativePlayer{MoveDuration=step};double clock=1100;
    for(int n=7;n>1;n--){
     var before=live.Evaluate(clock);s.Body.RemoveAt(n-1);live.BiteTail(s,n,clock,p,true);
     Check(Math.Abs(live.Evaluate(clock).length-before.length)<1e-8,"no contact snap");
     double prior=before.length;
     for(int frame=0;frame<=20;frame++){double value=live.Evaluate(clock+step*frame/20).length;Check(value<=prior+1e-8,"monotonic retirement");prior=value;}
     var done=live.Evaluate(clock+step);
     Check(Math.Abs(done.length-live.trim.to)<1e-8,"no retired tail behind next bite");
     clock+=step+1;
    }
    Check(live.Evaluate(clock).solo,"final tail becomes solo");
   }
   return checks;
  }
 }
}

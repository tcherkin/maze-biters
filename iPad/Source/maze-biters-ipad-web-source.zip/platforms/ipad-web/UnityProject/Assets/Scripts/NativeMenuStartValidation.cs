using System;
using System.IO;
using System.Linq;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
namespace MazeBiters.NativeStudy {
 [Serializable] sealed class StartupResult {
  public bool passed,cold,early,gameOverReady,visualOnly,mazeStartedBeforeAssets;
  public string quality,note,initialState,largestPreparationStage;
  public double preloadMs,clickToPlayMs,restartClickToPlayMs,largestPreparationStepMs;
  public int preparationSteps,preparedBuilds;
  public long menuWorkingSetBytes,gameWorkingSetBytes,peakWorkingSetBytes;
  public string[] checks;
 }
 public sealed partial class NativeMenu {
  bool startupTesting;
  IEnumerator StartupProbe(){
   Directory.CreateDirectory(Path.GetDirectoryName(report));
   var checks=new List<string>();var result=new StartupResult{quality=State.Quality,cold=ColdMenuStart,visualOnly=Array.IndexOf(Environment.GetCommandLineArgs(),"--startup-proof-only")>=0,early=Array.IndexOf(Environment.GetCommandLineArgs(),"--early-solo")>=0};
   void Check(bool pass,string text){if(!pass)throw new InvalidOperationException("Startup check: "+text);checks.Add(text);}
   IEnumerator Ready(){
    double start=Time.realtimeSinceStartupAsDouble;
    while(!PreparedForSelection){if(preloadFailed||Time.realtimeSinceStartupAsDouble-start>180)throw new TimeoutException("Menu preload");yield return null;}
   }
   IEnumerator Playing(){
    double start=Time.realtimeSinceStartupAsDouble;
    while(!gameplay||!gameplay.MenuReady){if(Time.realtimeSinceStartupAsDouble-start>180)throw new TimeoutException("SOLO playable");yield return null;}
   }
   yield return null;
   if(!ColdMenuStart&&!result.early){
    yield return Ready();result.preloadMs=preparationMs;result.mazeStartedBeforeAssets=preparedGame.MenuMazeStartedBeforeAssets;
    if(Array.IndexOf(Environment.GetCommandLineArgs(),"--late-maze-preparation")<0)Check(result.mazeStartedBeforeAssets,"first-level CPU cache starts before animation asset loading and before click");
    string clocks=preparedGame.MenuClockProof;string track=Audio.Track;int sounds=Audio.Accepted;
    yield return new WaitForSecondsRealtime(.25f);
    Check(preparedGame.MenuClockProof==clocks,"prepared scene clocks and RNG remain frozen");
    Check(Audio.Track==track&&Audio.Accepted==sounds&&track=="neon-orbit-menu","preparation does not start music or SFX");
   }
   NativeMemory.TryRead(out result.menuWorkingSetBytes,out _,out _);
   State.SetFocus(0,Now);double click=Time.realtimeSinceStartupAsDouble;Choose();
   yield return Playing();result.preloadMs=preparationMs;result.clickToPlayMs=(Time.realtimeSinceStartupAsDouble-click)*1000;
   Check(gameplay.MenuOptionsValid,"SOLO uses selected settings");
   Check(NativeBalancedLaunch.Distributed?result.early||result.clickToPlayMs>=890&&result.clickToPlayMs<960:InstantMenuStart?result.early||result.clickToPlayMs<250:result.clickToPlayMs>=890,"selected confirmation policy retained without extra loading pause");
   result.initialState=gameplay.StartupState;
   Check(!string.IsNullOrEmpty(result.initialState),"frozen first-frame proof captured");
   if(result.visualOnly){result.passed=true;result.checks=checks.ToArray();File.WriteAllText(report,JsonUtility.ToJson(result,true));Application.Quit();yield break;}
   NativeMemory.TryRead(out result.gameWorkingSetBytes,out result.peakWorkingSetBytes,out _);
   // Use the actual last-life -> death -> GAME OVER flow, without a timed
   // shortcut. This exercises the real interval available for preparing level 1.
   gameplay.StartupLastLife();
   double end=Time.realtimeSinceStartupAsDouble+45;
   while(gameplay){
    result.gameOverReady|=gameplay.RestartPrepared;
    if(Time.realtimeSinceStartupAsDouble>end)throw new TimeoutException("GAME OVER return");
    yield return null;
   }
   while(changing)yield return null;
   if(records!=null)CloseRecords();
   if(!ColdMenuStart){
    Check(result.gameOverReady,"next first-level GPU scene ready during GAME OVER");
    yield return Ready();
    Check(preparedBuilds==1,"GAME OVER reuses existing art/animation banks");
   }
   State.SetFocus(0,Now);click=Time.realtimeSinceStartupAsDouble;Choose();yield return Playing();
   result.restartClickToPlayMs=(Time.realtimeSinceStartupAsDouble-click)*1000;
   Check(gameplay.MenuOptionsValid,"restart settings valid");
   Check(gameplay.StartupState==result.initialState,"restart preserves original fresh-session state with fixed seed");
   ReturnToMenu();while(changing)yield return null;
   if(!ColdMenuStart){
    // Change a cached difficulty, then change only speed/music. Art must be
    // retained and scoring must use the LAST selected rate, not the warm rate.
    State.Difficulty=4;State.Speed=0;State.Music=0;Audio.MusicSetting=0;
    yield return Ready();State.Speed=4;
    Check(preparedBuilds==1,"difficulty reuses art banks");
    State.SetFocus(0,Now);Choose();yield return Playing();
    Check(gameplay.MenuOptionsValid,"late speed/music changes and BRUTAL difficulty are not stale");
    Check(gameplay.CheckCancelledRestart(),"manual restart discards an in-flight GAME OVER cache");
    ReturnToMenu();while(changing)yield return null;
    // Rapid HD/4K change while a scene is pending: obsolete work must never
    // install, and only one quality's source banks remain owned by the menu.
    State.Quality=State.Quality=="hd"?"4k":"hd";yield return null;
    // Change selection while source-bank initialization is actually underway.
    double pendingAt=Time.realtimeSinceStartupAsDouble;
    while(!preparedGame||preparedGame.MenuQuality!=State.Quality){if(Time.realtimeSinceStartupAsDouble-pendingAt>30)throw new TimeoutException("quality switch");yield return null;}
    State.Quality=result.quality;yield return Ready();
    Check(preparedGame.PreparedRasterValid,"interrupted quality load never mixes art banks and targets");
    State.Quality=State.Quality=="hd"?"4k":"hd";yield return Ready();
    State.SetFocus(0,Now);Choose();yield return Playing();
    Check(gameplay.MenuOptionsValid,"other resolution starts with its actual native art bank and target");
    ReturnToMenu();while(changing)yield return null;
    State.Quality=result.quality;yield return Ready();
    Check(PreparedForSelection,"rapid quality changes settle on final selection");
   }
   result.passed=true;result.preparationSteps=preparationSteps;result.preparedBuilds=preparedBuilds;result.largestPreparationStepMs=largestPreparationStepMs;result.largestPreparationStage=largestPreparationStage;result.checks=checks.ToArray();
   result.note="Same build cold-start control versus menu preload. Fixed seed 34, original 900ms confirmation; timings include OS scheduling and are not foreground FPS. No game simulation runs while cached. Working set includes native allocations and menu residency; not VRAM.";
   File.WriteAllText(report,JsonUtility.ToJson(result,true));Application.Quit();
  }
 }
 public sealed partial class NativeGameplayStudy {
  public string StartupState{get;private set;}
  public string MenuClockProof=>SceneClockState();
  public bool PreparedRasterValid=>bank!=null&&quality==bank.Quality&&target&&target.height==NativeDisplay.Frame.Pixels(quality).y;
  void CaptureStartupProof(){
   if(!MenuOwner||Array.IndexOf(Environment.GetCommandLineArgs(),"--menu-start-probe")<0)return;
   // Identical first frame, before the first simulation Tick.
   StartupState=mazeSeed+"|"+difficultyIndex+"|"+random+"|"+time+"|"+world.MusicTrack+"|"+string.Join("/",world.Grid)+"|"+JsonUtility.ToJson(world.Player)+"|"+string.Join(";",world.Snakes.Select(JsonUtility.ToJson));
   if(Array.IndexOf(Environment.GetCommandLineArgs(),"--startup-proof-only")<0)return;
   preparationLightFrame=true;Render();NativePreparation.Drain(target);
   string path=Path.Combine(Path.GetDirectoryName(report),"first-frame.png");
   if(!File.Exists(path))Capture(path);
  }
  public void StartupLastLife(){world.Player.Lives=1;world.SessionDeath();}
  public bool CheckCancelledRestart(){
   world.GameOver=true;world.GameOverAt=realClock;QueueGameOverPreparation();
   bool queued=restartPreparing&&nextMazeTask!=null;Reset(12);
   return queued&&!restartPreparing&&nextMazeTask==null&&nextMaze==null&&nextScene==null&&world.Level==1&&!world.GameOver;
  }
 }
}


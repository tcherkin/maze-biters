using System;using System.IO;using UnityEngine;
namespace MazeBiters.NativeStudy {
 [Serializable]class SessionLightCases {public SessionLightCase[] cases;}
 [Serializable]class SessionLightCase {public float x,y,dx,dy;public double alpha;}
 [Serializable]class SessionVisualReport {public string quality,note;public bool passed,audio,audioPreparationIdentity,powerModeAudio;public SessionLogicResult logic;public AudioFullAudit audioAudit;public int lightSamples,lightPixels,maxAlphaError;public double meanAlphaError,audioEnergy;}
 public sealed class SessionVisualValidation:MonoBehaviour {
  void Start(){
   string quality="hd",report=null;var args=Environment.GetCommandLineArgs();for(int i=0;i<args.Length;i++){if(args[i]=="--quality")quality=args[++i];if(args[i]=="--report")report=args[++i];}
   Application.runInBackground=true;QualitySettings.vSyncCount=0;QualitySettings.anisotropicFiltering=AnisotropicFiltering.Disable;Directory.CreateDirectory(Path.GetDirectoryName(report));
   var result=new SessionVisualReport{quality=quality,logic=SessionValidation.Run(),note="16 original death-light masks; original JS session oracle. Muted PCM/voice-cap DSP validation, not a subjective listening test or PCM identity to browser resampling/compression."};
   var quad=new Mesh();quad.vertices=new[]{new Vector3(0,0),new Vector3(1,0),new Vector3(1,-1),new Vector3(0,-1)};quad.uv=new[]{new Vector2(0,1),new Vector2(1,1),new Vector2(1,0),new Vector2(0,0)};quad.triangles=new[]{0,1,2,0,2,3};quad.RecalculateBounds();
   var go=new GameObject("Death light validation");var camera=go.AddComponent<Camera>();camera.enabled=false;
   var root=Path.Combine(WebFiles.Root,"Reference");var specs=JsonUtility.FromJson<SessionLightCases>(File.ReadAllText(Path.Combine(root,"session-light.json")));
   var expected=new Texture2D(2,2,TextureFormat.RGBA32,false);expected.LoadImage(File.ReadAllBytes(Path.Combine(root,"session-light.png")));var b=expected.GetPixels32();var actual=new Texture2D(576,400,TextureFormat.RGBA32,false);var previous=RenderTexture.active;long total=0;
   using(var dusk=new NativeDusk(quad,camera)){for(int k=0;k<specs.cases.Length;k++){var p=specs.cases[k];dusk.Render(new Vector2(p.x,p.y),new Vector2(p.dx,p.dy),16,false,true,0,true,p.alpha);RenderTexture.active=dusk.mask;actual.ReadPixels(new Rect(0,0,576,400),0,0);actual.Apply();var a=actual.GetPixels32();
    for(int y=0;y<400;y++)for(int x=0;x<576;x++){int e=Math.Abs(a[y*576+x].a-b[((3-k/4)*400+y)*2304+(k%4)*576+x].a);total+=e;result.maxAlphaError=Math.Max(result.maxAlphaError,e);}
   }RenderTexture.active=previous;}
   var audioObject=new GameObject("Muted SFX validation");var sound=audioObject.AddComponent<NativeSessionAudio>();sound.Initialize(true,false);
   var coldObject=new GameObject("Cold SFX validation");var cold=coldObject.AddComponent<NativeSessionAudio>();cold.Initialize(true,false,false);
   result.audioPreparationIdentity=sound.Voices==0&&sound.Accepted==0&&sound.Rejected==0&&sound.OutputEnergy==0&&sound.Track==null;
   // Neither AudioSource was started. Compare real PCM values, not muted zero
   // buffers, including panning and compressor history after the hidden warmup.
   sound.Muted=cold.Muted=false;
   var preparedPcm=new float[8192];var coldPcm=new float[8192];
   foreach(string name in new[]{"Tie1","HeadEat","ScorpioEat","HeadDie","snakeSTART@"}){
    sound.Play(name,new Vector2Int(12,1),false,100);cold.Play(name,new Vector2Int(12,1),false,100);
    sound.MixForValidation(preparedPcm,2);cold.MixForValidation(coldPcm,2);
    for(int i=0;i<preparedPcm.Length;i++)result.audioPreparationIdentity&=preparedPcm[i]==coldPcm[i];
   }
   result.powerModeAudio=CheckPowerModeAudio(sound,cold);
   Destroy(coldObject);sound.Muted=true;sound.ResetBus();
   sound.Play("HeadDie",new Vector2Int(1,1),false,1000);sound.MixForValidation(new float[65536],2);result.audioEnergy=sound.OutputEnergy;bool ok=result.audioEnergy>0&&result.audioPreparationIdentity&&result.powerModeAudio; sound.ResetBus();
   for(int n=0;n<30;n++)sound.Play("Tie1",new Vector2Int(34,1),false,2000);ok&=sound.Voices==16;sound.Play("Tick",default,true,2000);sound.Play("Tick",default,true,2001);ok&=sound.Voices==17&&sound.Rejected==1;
   for(int n=0;n<40;n++)sound.Play("HeadEat",default,true,2100);ok&=sound.Voices<=32;for(int n=0;n<8;n++)sound.Play("HeadDie",default,true,2200);ok&=sound.Voices<=32;
   sound.MixForValidation(new float[65536],2);ok&=double.IsFinite(sound.OutputEnergy)&&NativeSessionAudio.Compression(2)<1;result.audio=ok;Destroy(audioObject);
   result.audioAudit=NativeAudioAudit.Mixer();
   result.lightSamples=specs.cases.Length;result.lightPixels=result.lightSamples*576*400;result.meanAlphaError=total/(double)result.lightPixels;result.passed=result.logic.passed&&result.audio&&result.audioAudit.passed&&result.maxAlphaError<=2;
   File.WriteAllText(report,JsonUtility.ToJson(result,true));Destroy(expected);Destroy(actual);Destroy(go);Destroy(quad);Debug.Log("SESSION_VALIDATION "+result.passed);Application.Quit(result.passed?0:2);
  }
  static bool CheckPowerModeAudio(NativeSessionAudio sound,NativeSessionAudio fruitOnly){
   // Neither source is playing: feed actual collection events into the native
   // mixer, and prove the power clip contributes PCM beyond the fruit alone.
   sound.ResetBus();fruitOnly.ResetBus();sound.Muted=fruitOnly.Muted=false;
   var w=new NativeGameplayWorld(NativeLevelCatalogue.Get(1).geometry,()=>0){SessionEnabled=true,Time=1000};
   w.Player.Cell=new Vector2Int(12,1);int cues=0;bool fruit=false,power=false;
   w.Event=e=>{if(e.Kind!="sound")return;cues++;fruit|=e.Sound.StartsWith("EatFruit",StringComparison.Ordinal);power|=e.Sound=="snakeSTART@";sound.Play(e.Sound,e.Cell,e.GlobalSound,w.Time);if(e.Sound.StartsWith("EatFruit",StringComparison.Ordinal))fruitOnly.Play(e.Sound,e.Cell,e.GlobalSound,w.Time);};
   w.Fruits.Add(new NativeFruit{Cell=w.Player.Cell,Kind=0});w.CollectFruit();
   bool ok=w.Power&&cues==2&&fruit&&power&&sound.Voices==2&&fruitOnly.Voices==1;
   var mixed=new float[65536];var baseline=new float[mixed.Length];sound.MixForValidation(mixed,2);fruitOnly.MixForValidation(baseline,2);
   double difference=0;for(int i=0;i<mixed.Length;i++)difference+=Math.Abs(mixed[i]-baseline[i]);ok&=difference>.01;
   sound.ResetBus();fruitOnly.ResetBus();cues=0;fruit=power=false;w.Time+=500;w.Fruits.Add(new NativeFruit{Cell=w.Player.Cell,Kind=1});w.CollectFruit();
   ok&=cues==2&&fruit&&power&&sound.Voices==2&&w.Player.PowerUntil==w.Time+7000;
   sound.ResetBus();sound.Play("snakeSTART@",w.Player.Cell,false,2000);ok&=sound.Voices==1;sound.MixForValidation(mixed,2);
   double energy=0;foreach(float sample in mixed){ok&=float.IsFinite(sample);energy+=sample*sample;}return ok&&energy>.0001;
  }
 }
}

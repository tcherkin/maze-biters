using System;using System.Collections.Generic;using UnityEngine;
namespace MazeBiters.NativeStudy {
 // Runtime behaviour checks intentionally exercise the new default, separately
 // from NativeAllyValidation's frozen translation/RNG oracles.
 public static class NativeAllyDifficultyValidation {
  static readonly string[] Arena={"###########","#.........#","#.........#","#.........#","#.........#","#.........#","###########"};
  static NativeGameplayWorld World(int mode,int difficulty,Func<double> random,bool food=true){
   var w=new NativeGameplayWorld(Arena,random){AiDifficulty=difficulty,Time=1000};w.SetMode(mode);
   for(int i=0;i<w.PlayerCount;i++){var p=w.GetPlayer(i);p.Cell=p.From=p.Previous=new Vector2Int(p.IsAI?3:5,3+i);p.Dir=p.Next=Vector2Int.right;p.Score=p.IsAI?200:0;p.Waiting=false;}
   var ai=w.GetPlayer(w.PlayerCount-1);ai.Cell=ai.From=ai.Previous=new Vector2Int(3,3);if(mode==0)ai.Score=0;
   if(food)w.Snakes.Add(new NativeGameplaySnake{Id=10,Cell=new Vector2Int(7,3),Dir=Vector2Int.right,Body=new List<Vector2Int>{new Vector2Int(7,3),new Vector2Int(6,3)}});
   w.Ally.BeginLevel();return w;
  }
  static Func<double> Seeded(int seed){uint state=(uint)seed;return ()=>{unchecked{state+=0x6D2B79F5;uint n=(state^(state>>15))*(1|state);n^=n+(n^(n>>7))*(61|n);return (n^(n>>14))/4294967296.0;}};}
  static void Move(NativeGameplayWorld w,NativePlayer p,double at){w.Time=at;w.Ally.Plan(p,at);using(w.ForPlayer(p))w.AdvancePlayer();}
  public static int Run(){
   int checks=0;void Check(bool ok,string message){checks++;if(!ok)throw new Exception("ALLY DIFFICULTY: "+message);}
   foreach(int mode in new[]{0,3,4}){
    int draws=0;var w=World(mode,0,()=>{draws++;return .99;});var p=w.GetPlayer(w.PlayerCount-1);
    Check(!w.UseLegacyAi&&p.Ai.locked==null,"runtime starts without an automatic prey lock, mode "+mode);
    w.Ally.Plan(p,1000);int firstDraws=draws;
    Check(!p.Ai.mealActive&&p.Ai.thought=="casual-roam"&&p.Ai.directive==null,"Picnic chooses a casual stroll, mode "+mode);
    for(int i=1;i<=12;i++){Move(w,p,1000+i*100);Check(!p.Dead&&w.Floor(p.Cell),"casual movement stays alive and legal, mode "+mode);}
    Check(draws==firstDraws&&p.Ai.locked==null&&!p.Ai.mealActive,"a failed meal/hunt roll is held across movement, mode "+mode);
    Check(!p.Ai.mealActive&&p.Ai.locked==null&&p.Ai.queue.Count==0,"incidental food never turns the stroll into a committed cleanup, mode "+mode);
   }
   {
    int draws=0;var w=World(3,0,()=>{draws++;return .99;},false);var p=w.GetPlayer(1);var human=w.GetPlayer(0);human.Cell=p.Cell+Vector2Int.right;
    w.Ally.Plan(p,1000);int held=draws;double assessment=p.Ai.assessmentAt;
    for(int i=1;i<20;i++)w.Ally.Plan(p,1000+i*50);
    Check(p.Ai.directive==null&&draws==held&&p.Ai.assessmentAt==assessment,"a rejected human hunt is not rerolled every tile");
    Check(p.Next!=Vector2Int.right,"a resting AI does not step into an edible human");
    Move(w,p,2100);Check(!human.Dead&&human.Lives==3,"casual movement leaves the adjacent human alive");
    human.Cell=p.Cell+Vector2Int.right;human.Score=500;w.Ally.Plan(p,2150);
    Check(p.Ai.directive?.type=="flee"&&p.Next!=Vector2Int.right,"immediate danger interrupts the held casual decision");
   }
   {
    var w=World(3,0,()=>0,false);var p=w.GetPlayer(1);w.Ally.Plan(p,1000);
    Check(p.Ai.directive?.type=="hunt","a rare Picnic hunt can still happen");double until=p.Ai.opponentHuntUntil;w.Ally.Plan(p,until);
    Check(p.Ai.directive==null&&p.Ai.opponentRestUntil>until,"Picnic human pursuit ends after a short burst");
    w.Ally.Plan(p,until+500);Check(p.Ai.directive==null,"human pursuit cannot immediately restart during cooldown");
   }
   {
    int draws=0;var w=World(4,0,()=>++draws<=2?0:.99,false);var p=w.GetPlayer(2);var human=w.GetPlayer(0);human.Cell=p.Cell+Vector2Int.right;
    Move(w,p,1000);Check(human.Dead,"an accepted hunt can actually bite a human");w.Ally.Plan(p,1100);
    Check(p.Ai.directive==null&&p.Ai.opponentRestUntil>1100,"a successful bite also rests before hunting the other human");
   }
   {
    var w=World(0,0,()=>.99,false);var p=w.Player;w.Hunters.Add(new NativeHunter{Cell=p.Cell+Vector2Int.right,Dir=Vector2Int.left});Move(w,p,1000);
    Check(!p.Dead&&p.Cell!=new Vector2Int(4,3),"Picnic wandering still avoids an immediate lethal collision");
   }
   {
    var w=new NativeGameplayWorld(new[]{"####","#..#","####"},()=>.5){AiDifficulty=4};w.SetMode(3);var p=w.GetPlayer(1);var human=w.GetPlayer(0);
    p.Cell=p.From=p.Previous=new Vector2Int(1,1);p.Dir=p.Next=Vector2Int.right;p.Waiting=false;human.Cell=new Vector2Int(2,1);human.Score=500;w.Ally.BeginLevel();Move(w,p,1000);
    Check(p.Waiting&&!p.Dead&&p.Cell==new Vector2Int(1,1),"a stronger human blocking the only exit cannot trigger stale movement");
    human.Dead=true;Move(w,p,1100);Check(!p.Waiting&&!p.Dead&&p.Cell==new Vector2Int(2,1),"an AI resumes once a safe exit is available");
   }
   {
    var w=World(0,0,()=>0);var p=w.Player;p.Cell=p.From=p.Previous=new Vector2Int(5,3);Move(w,p,1000);
    Check(p.Score==25&&w.Snakes[0].Body.Count==1,"an interested Picnic AI can take a nearby meal");
    Check(!p.Ai.mealActive&&p.Ai.locked==null&&p.Ai.mealIntentUntil>1000,"one easy bite returns to roaming instead of permanent cleanup");
    Move(w,p,1100);Check(p.Score==150&&w.Snakes.Count==0&&!p.Ai.mealActive&&p.Ai.locked==null,"an easy AI accepts the adjacent safe lone head without committing to a hunt");
   }
   foreach(double draw in new[]{.01,.99}){
    var w=World(0,4,()=>draw);var p=w.Player;
    for(int i=0;i<4;i++)Move(w,p,1000+i*100);
    Check(!p.Dead&&p.Score==150&&w.Snakes.Count==0,"Brutal takes the direct safe route and finishes the snake, draw "+draw);
    w.Ally.Plan(p,1000000);Check(p.Ai.mealActive&&double.IsPositiveInfinity(p.Ai.mealIntentUntil),"Brutal retains purposeful intent without a forced stroll");
   }
   {
    const int samples=128;var meals=new int[5];var hunts=new int[5];
    for(int difficulty=0;difficulty<5;difficulty++)for(int seed=1;seed<=samples;seed++){
     var w=World(3,difficulty,Seeded(seed),false);var p=w.GetPlayer(1);w.Ally.Plan(p,1000);if(p.Ai.mealActive)meals[difficulty]++;if(p.Ai.directive?.type=="hunt")hunts[difficulty]++;
    }
    Check(meals[0]<samples/4&&hunts[0]<samples/16,"seeded Picnic decisions produce few meals and very rare human hunts");
    for(int difficulty=1;difficulty<5;difficulty++){Check(meals[difficulty]>meals[difficulty-1],"meal interest rises at tier "+difficulty);Check(hunts[difficulty]>hunts[difficulty-1],"human pursuit rises at tier "+difficulty);}
    Check(meals[4]==samples&&hunts[4]==samples,"Brutal never deliberately ignores a safe available objective");
   }
   return checks;
  }
 }
}

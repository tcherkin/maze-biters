using System;
using System.IO;
using System.Collections.Generic;
using UnityEngine;
namespace MazeBiters.NativeStudy {
 // Exact build-time decoding, native channel layout, color space and alpha.
 // Only the archive index stays resident; decoded CPU pixels are not cached.
 public static class NativePreparedLight {
  public sealed class Pixels {
   public int width,height;public TextureFormat format;public bool linear;public uint[] words;
  }
  public sealed class Archive:IDisposable {
   readonly BinaryReader reader;readonly Dictionary<string,(long offset,int length)> entries=new Dictionary<string,(long,int)>();
   public Archive(string path){
    reader=new BinaryReader(File.OpenRead(path));
    try{if(reader.ReadInt32()!=0x4d424c32)throw new InvalidDataException(path);int count=reader.ReadInt32();if(count<0||count>4096)throw new InvalidDataException(path);
     for(int i=0;i<count;i++){string key=reader.ReadString();int length=reader.ReadInt32();long offset=reader.BaseStream.Position;if(length<17||length>reader.BaseStream.Length-offset)throw new InvalidDataException(path);entries.Add(key,(offset,length));reader.BaseStream.Position+=length;}
     if(reader.BaseStream.Position!=reader.BaseStream.Length)throw new InvalidDataException(path);
    }catch{reader.Dispose();throw;}
   }
   public Pixels Read(string key){if(!entries.TryGetValue(key,out var e))return null;reader.BaseStream.Position=e.offset;return Decode(reader,e.length);}
   public void Dispose()=>reader.Dispose();
  }
  static Archive archive;static bool opened;
  public static void Write(string path,Texture2D texture,byte[] bytes){
   var words=new uint[bytes.Length/4];Buffer.BlockCopy(bytes,0,words,0,bytes.Length);
   var packed=NativeStartupPixels.Pack(words,words.Length,new uint[words.Length+1]);
   using(var w=new BinaryWriter(File.Create(path))){w.Write(texture.width);w.Write(texture.height);w.Write((int)texture.format);w.Write(texture.isDataSRGB?0:1);w.Write(packed);}
  }
  static Pixels Decode(BinaryReader r,int length){
   var p=new Pixels{width=r.ReadInt32(),height=r.ReadInt32(),format=(TextureFormat)r.ReadInt32(),linear=r.ReadInt32()!=0};
   if(p.width<=0||p.height<=0||p.width>16384||p.height>16384||(p.format!=TextureFormat.RGBA32&&p.format!=TextureFormat.ARGB32))throw new InvalidDataException("Prepared texture representation");
   int count=checked(p.width*p.height);if(length<17||length-16>count*4L+1)throw new InvalidDataException("Prepared texture length");
   var bytes=r.ReadBytes(length-16);p.words=new uint[count];NativeStartupPixels.UnpackWords(bytes,p.words,count);return p;
  }
  public static Pixels Read(string path){using(var f=File.OpenRead(path))using(var r=new BinaryReader(f))return Decode(r,checked((int)f.Length));}
  internal static Texture2D Load(string name,bool premultiply){
   if(!opened){opened=true;string path=Path.Combine(WebFiles.Root,"PreparedLight.bytes");if(File.Exists(path)){archive=new Archive(path);Application.quitting+=()=>{archive.Dispose();archive=null;};}}
   if(archive==null)return null;
   long mark=NativeStallTrace.Stamp();var pixels=archive.Read(name+(premultiply?".pm.pixels":".raw.pixels"));if(pixels==null)return null;
   NativeStallTrace.Add("light-read:"+name,mark);long create=NativeStallTrace.Stamp();
   var t=new Texture2D(pixels.width,pixels.height,pixels.format,false,pixels.linear){filterMode=FilterMode.Bilinear,wrapMode=TextureWrapMode.Clamp};
   NativeStallTrace.Add("light-create:"+name,create);long upload=NativeStallTrace.Stamp();
   try{t.SetPixelData(pixels.words,0);t.Apply(false,true);}catch{UnityEngine.Object.Destroy(t);throw;}
   NativeStallTrace.Add("light-upload:"+name,upload);NativeStallTrace.Add("prepared-light:"+name,mark);return t;
  }
 }
}

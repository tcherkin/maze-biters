#if UNITY_EDITOR
using System;
namespace MazeBiters.NativeStudy {
 public static class NativeHudComboValidation {
  public static int Numeric(){
   int checks=0;void Check(bool ok,string name){checks++;if(!ok)throw new Exception("COMBO HUD: "+name);}
   Check(NativeHud.ComboDisplayLabel(1)=="COMBO X2","second snake label");
   Check(NativeHud.ComboDisplayLabel(2)=="COMBO X4","third snake label");
   Check(NativeHud.ComboDisplayLabel(3)=="COMBO X8","fourth snake label");
   Check(NativeHud.ComboDisplayLabel(30)=="COMBO X1073741824","large exact integer label");
   Check(NativeHud.ComboDisplayLabel(31)=="COMBO X2^31","large multiplier uses honest exponent label");
   Check(NativeHud.ComboDisplayLabel(int.MaxValue)=="COMBO X2^2147483647","bounded label handles the largest count without shifting overflow");
   const double start=700,left=144,right=240;
   foreach(double density in new[]{2.5,5.0}){
    double x0=NativeHud.ComboBeamLeft(start,left,right,start,density),x1=NativeHud.ComboBeamLeft(start,left,right,start+620,density),x2=NativeHud.ComboBeamLeft(start,left,right,start+1240,density);
    Check(x0>x1&&x1>x2,"first sweep travels right to left at density "+density);
    Check(NativeHud.ComboBeamLeft(start,left,right,start+1860,density)>x2&&NativeHud.ComboBeamLeft(start,left,right,start+2480,density)==x0,"return sweep travels left to right at density "+density);
    for(int pass=1;pass<=100;pass++){
     double t=start+1240*pass;
     Check(Math.Abs(NativeHud.ComboBeamLeft(start,left,right,t-1e-6,density)-NativeHud.ComboBeamLeft(start,left,right,t,density))<=1/density+.000001,"continuous pass boundary "+pass+" / "+density);
    }
    foreach(double elapsed in new[]{0,125.0,620,1240,1860,2479.99,1000000}){
     double x=NativeHud.ComboBeamLeft(start,left,right,start+elapsed,density);
     Check(double.IsFinite(x)&&x>=left-72-1/density&&x<=right-72*.18+1/density,"beam remains finite and bounded");
     Check(Math.Abs(x-NativeHud.ComboBeamLeft(start,left,right,start+elapsed+2480,density))<.000001,"uninterrupted cycle retains the same phase");
    }
   }
   Check(NativeHud.ComboPulseAlpha(start,start)==1&&NativeHud.ComboPulseAlpha(start,start+620)==1,"upgrade pulse joins its baseline without a discontinuity");
   Check(Math.Abs(NativeHud.ComboPulseAlpha(start,start+310)-.7)<1e-12,"upgrade pulse is gentle and bounded");
   for(int i=-10;i<=1000;i+=10){double alpha=NativeHud.ComboPulseAlpha(start,start+i);Check(double.IsFinite(alpha)&&alpha>=.7-1e-12&&alpha<=1,"pulse cannot exceed original opacity");}
   Check(NativeHud.ComboPulseAlpha(double.NegativeInfinity,10000)==1,"inactive pulse has no invalid opacity");
   return checks;
  }
 }
}
#endif

using System;
using System.IO;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
namespace MazeBiters.NativeStudy {
 // Offline art validation only. Uses the production turn bank and aura, including
 // the old straight-alpha bug as an explicit A/B reference; never runs in gameplay.
 public sealed class NativeLeaderAuraStudy:MonoBehaviour {
  [Serializable]sealed class Result {
   public string quality,note;public bool passed;public int cases,interiorPixels,interiorMaxError,premultipliedViolations,legacyViolations,frames;
   public int auraMaxError,motionSamples,oldFrozenFrames,newFrozenFrames,oldBoundaryMax,newBoundaryMax;
   public int turnCases,sparkMaxError,headingStateCases;public double oldAngularStep,newAngularStep,settleError;
  }
  Mesh quad;PackedArt art;NativeTurnBank bank;NativeCoopArt previous,current;
  NativeTurnActor[] actors;NativeCoopLeader[] leaders;NativePlayer[] players;GameObject[] heads;
  Camera cameraView;RenderTexture view;string quality="hd",output;int size,padding;Result result;bool motionComparison,turnComparison;
    IEnumerator Start(){
   var args=Environment.GetCommandLineArgs();motionComparison=Array.IndexOf(args,"--leader-aura-motion")>=0;turnComparison=Array.IndexOf(args,"--leader-aura-turn")>=0;for(int i=0;i<args.Length;i++){
    if(args[i]=="--quality"&&i+1<args.Length)quality=args[++i];
    if(args[i]=="--report"&&i+1<args.Length)output=args[++i];
   }
   if(quality!="hd"&&quality!="4k")throw new ArgumentException("Quality must be HD or 4K");
   if(string.IsNullOrEmpty(output))throw new ArgumentException("--report required");
   Directory.CreateDirectory(Path.GetDirectoryName(output));Application.runInBackground=true;QualitySettings.vSyncCount=0;Application.targetFrameRate=120;QualitySettings.anisotropicFiltering=AnisotropicFiltering.Disable;
   result=new Result{quality=quality,note="Production GPU compositor: both leader colors, all cardinal poses, all four quarter-turns, normal/bright art, mouth and blink. PNGs are premultiplied BEFORE filtering. No new runtime render targets, textures or passes. Not a performance benchmark."};
   quad=new Mesh{name="Aura validation quad",vertices=new[]{new Vector3(0,0),new Vector3(1,0),new Vector3(1,-1),new Vector3(0,-1)},uv=new[]{new Vector2(0,1),new Vector2(1,1),new Vector2(1,0),new Vector2(0,0)},triangles=new[]{0,1,2,0,2,3}};quad.RecalculateBounds();
   art=new PackedArt(quality,true);bank=new NativeTurnBank(quality,art,quad);size=bank.Size;padding=Math.Max(4,(int)Math.Ceiling(size*.05));
   if(motionComparison)result.note="Production aura: approved colors retained, continuous positions/size/fade from the original 1152 ms path, 90 ms head-synchronized heading. Both palettes; GPU 120 Hz samples and 72 ms boundary checks. Two atlas samples instead of one in the existing tiny pass. No new textures or render targets. Not a frame-rate benchmark.";
   if(turnComparison)result.note="Production aura orientation only: critically damped follower (frequency 16/s), game-time clock, unwrapped turns, reset on hidden/respawn/warmup. Same local spark pixels and exact same head/outline. GPU 120 Hz quarter/half-turn samples. No shader or resource changes; not a performance benchmark.";
   previous=new NativeCoopArt(quality,!(motionComparison||turnComparison));current=new NativeCoopArt(quality);
   actors=new[]{new NativeTurnActor(bank,"fantasy","p1"),new NativeTurnActor(bank,"fantasy","p2")};
   leaders=new NativeCoopLeader[4];players=new NativePlayer[4];heads=new GameObject[4];
   for(int row=0;row<2;row++)for(int col=0;col<2;col++){
    int k=row*2+col;var cell=new Vector2Int(2+col*5,1+row*3);
    players[k]=new NativePlayer{Id=row+1,Cell=cell,From=cell,Dir=Vector2Int.right};
    leaders[k]=new NativeCoopLeader(col==0?previous:current,quad,motionComparison&&col==0,!turnComparison||col==0);
    var head=heads[k]=new GameObject("Leader "+row+" / "+col);head.AddComponent<MeshFilter>().sharedMesh=quad;
    var mesh=head.AddComponent<MeshRenderer>();mesh.sharedMaterial=leaders[k].Display;mesh.sortingOrder=10;
    float extent=16*leaders[k].Scale;head.transform.localScale=new Vector3(extent,extent,1);head.transform.position=new Vector3((cell.x+.5f)*16-extent/2,-(cell.y+.5f)*16+extent/2,0);
   }
   cameraView=new GameObject("Aura capture").AddComponent<Camera>();cameraView.enabled=false;cameraView.orthographic=true;cameraView.orthographicSize=48;cameraView.aspect=160f/96;cameraView.transform.position=new Vector3(80,-48,-10);
   cameraView.clearFlags=CameraClearFlags.SolidColor;cameraView.backgroundColor=new Color(7/255f,16/255f,25/255f);cameraView.cullingMask=~(1<<28);cameraView.allowHDR=cameraView.allowMSAA=false;
   view=new RenderTexture(size*10,size*6,0,RenderTextureFormat.ARGB32){antiAliasing=1};view.Create();cameraView.targetTexture=view;
   yield return null;
   foreach(bool bright in new[]{false,true})foreach(int mouth in new[]{0,19,34})foreach(int blink in new[]{0,24})for(int poseIndex=0;poseIndex<8;poseIndex++){
    var pose=new TurnPose{from=poseIndex%4,to=poseIndex<4?poseIndex%4:(poseIndex+1)%4,mix=poseIndex<4?0:.5,angle=poseIndex%4};
    for(int row=0;row<2;row++){
     var actor=actors[row];actor.Bright=bright;bank.Render(actor,pose,mouth,blink);
     leaders[row*2].Render(actor,pose,players[row*2],poseIndex*72,true);
     leaders[row*2+1].Render(actor,pose,players[row*2+1],poseIndex*72,true);
     Check(actor,leaders[row*2],leaders[row*2+1]);result.cases++;
    }
    yield return null;
   }
   // Ensure all 16 authored spark frames retain valid premultiplied edges.
   for(int frame=0;frame<16;frame++)for(int row=0;row<2;row++){
    var pose=new TurnPose{from=0,to=0};actors[row].Bright=false;bank.Render(actors[row],pose,19,0);
    leaders[row*2+1].Render(actors[row],pose,players[row*2+1],frame*72,true);
    var pixels=Read(leaders[row*2+1].ValidationSparks);result.premultipliedViolations+=Violations(pixels.GetPixels32());Destroy(pixels);
   }
   if(motionComparison)foreach(var step in CheckMotion())yield return step;
   if(turnComparison)foreach(var step in CheckTurns())yield return step;
   int count=quality=="hd"?(turnComparison?540:motionComparison?360:180):4;string folder=Path.Combine(Path.GetDirectoryName(output),quality+"-frames");Directory.CreateDirectory(folder);
   for(int frame=0;frame<count;frame++){
    double t=quality=="hd"?frame*1000.0/(motionComparison||turnComparison?60:30):(turnComparison?new[]{0,1060,1250,2400}:new[]{0,1060,2160,3260})[frame];
    Render(t);var image=Read(view);File.WriteAllBytes(Path.Combine(folder,frame.ToString("D4")+".png"),image.EncodeToPNG());Destroy(image);result.frames++;
    yield return null;
   }
   result.passed=result.cases==192&&result.interiorPixels>100000&&result.interiorMaxError<=1&&result.premultipliedViolations==0&&(turnComparison?result.legacyViolations==0&&result.auraMaxError==0&&result.sparkMaxError==0&&result.turnCases==9&&result.headingStateCases==4&&result.newAngularStep<result.oldAngularStep*.5&&result.settleError<1.5:motionComparison?result.legacyViolations==0&&result.auraMaxError==0&&result.oldFrozenFrames>200&&result.newFrozenFrames<8&&result.newBoundaryMax<=2&&result.oldBoundaryMax>10:result.legacyViolations>0);
   File.WriteAllText(output,JsonUtility.ToJson(result,true));Debug.Log("LEADER_AURA "+JsonUtility.ToJson(result));Application.Quit(result.passed?0:2);
  }
  void Render(double t){
   int section=(int)(t/1100);double phase=t%1100;int[] route={0,2,0,3,1,2,3,0};
   int from=turnComparison?route[section%route.Length]:section%4,to=turnComparison?route[(section+1)%route.Length]:(section+1)%4;bool turning=phase>1010;
   var clock=new NativeTurnClock(true,from);if(turning)clock.Request(from,to,t-phase+1010);var pose=clock.Sample(t,from);
   for(int row=0;row<2;row++){
    int mouth=(int)Math.Round(48*AnimationClock.Mouth(t+(row*31),95));int blink=t%3000>2200&&t%3000<2420?(int)Math.Round(24*AnimationClock.Blink(t%3000-2200)):0;
    var actor=actors[row];actor.Bright=false;bank.Render(actor,pose,mouth,blink);
    for(int col=0;col<2;col++){int k=row*2+col;players[k].Dir=NativeLevelStudy.Directions[turning?to:from];leaders[k].Render(actor,pose,players[k],t,true);}
   }
   cameraView.Render();
  }
  void Check(NativeTurnActor actor,NativeCoopLeader old,NativeCoopLeader next){
   var source=Read(actor.Output);var before=Read(old.ValidationOutput);var after=Read(next.ValidationOutput);var sparks=Read(next.ValidationSparks);
   var s=source.GetPixels32();var a=before.GetPixels32();var b=after.GetPixels32();int w=before.width;
   if(turnComparison){var oldSpark=Read(old.ValidationSparks);result.sparkMaxError=Math.Max(result.sparkMaxError,Difference(oldSpark.GetPixels32(),sparks.GetPixels32()));Destroy(oldSpark);}
   if(motionComparison||turnComparison)result.auraMaxError=Math.Max(result.auraMaxError,Difference(a,b));
   result.premultipliedViolations+=Violations(b)+Violations(sparks.GetPixels32());result.legacyViolations+=Violations(a);
   for(int y=1;y<size-1;y++)for(int x=1;x<size-1;x++){
    bool opaque=true;for(int oy=-1;oy<=1;oy++)for(int ox=-1;ox<=1;ox++)opaque&=s[(y+oy)*size+x+ox].a==255;
    if(!opaque)continue;int i=(y+padding)*w+x+padding;
    int error=Math.Max(Math.Max(Math.Abs(a[i].r-b[i].r),Math.Abs(a[i].g-b[i].g)),Math.Max(Math.Abs(a[i].b-b[i].b),Math.Abs(a[i].a-b[i].a)));
    result.interiorMaxError=Math.Max(result.interiorMaxError,error);result.interiorPixels++;
   }
   Destroy(source);Destroy(before);Destroy(after);Destroy(sparks);
  }
  IEnumerable<object> CheckMotion(){
   var pose=new TurnPose{from=0,to=0};
   Color32[] Sample(int row,int col,double t){
    leaders[row*2+col].Render(actors[row],pose,players[row*2+col],t,true);
    var texture=Read(leaders[row*2+col].ValidationSparks);var pixels=texture.GetPixels32();Destroy(texture);result.premultipliedViolations+=Violations(pixels);return pixels;
   }
   for(int row=0;row<2;row++){
    actors[row].Bright=false;bank.Render(actors[row],pose,19,0);Color32[] old=null,next=null;
    for(int frame=0;frame<=144;frame++){
     double t=frame*1000.0/120;var a=Sample(row,0,t);var b=Sample(row,1,t);
     if(old!=null){if(Difference(old,a)==0)result.oldFrozenFrames++;if(Difference(next,b)==0)result.newFrozenFrames++;result.motionSamples++;}
     old=a;next=b;yield return null;
    }
    for(int frame=1;frame<=16;frame++){
     double t=frame*72;
     result.oldBoundaryMax=Math.Max(result.oldBoundaryMax,Difference(Sample(row,0,t-.01),Sample(row,0,t+.01)));
     result.newBoundaryMax=Math.Max(result.newBoundaryMax,Difference(Sample(row,1,t-.01),Sample(row,1,t+.01)));
    }
   }
  }
  IEnumerable<object> CheckTurns(){
   using(var lifecycle=new NativeCoopLeader(current,quad)){
    var actor=actors[0];var p=players[0];
    void Verify(bool ok,string name){if(!ok)throw new Exception("Aura lifecycle: "+name);result.headingStateCases++;}
    lifecycle.Render(actor,new TurnPose{from=0,to=0,angle=0},p,0,false);
    lifecycle.Render(actor,new TurnPose{from=2,to=2,angle=2},p,100,true);
    Verify(Math.Abs(lifecycle.ValidationHeading+180)<1e-8,"first visible frame has no hidden heading history");
    lifecycle.Render(actor,new TurnPose{from=1,to=1,angle=1},p,116,true);double paused=lifecycle.ValidationHeading;
    lifecycle.Render(actor,new TurnPose{from=1,to=1,angle=1},p,116,true);Verify(lifecycle.ValidationHeading==paused,"pause freezes heading");
    lifecycle.Render(actor,new TurnPose{from=0,to=0,angle=0},p,200,false);
    lifecycle.Render(actor,new TurnPose{from=0,to=0,angle=0},p,200,true);Verify(lifecycle.ValidationHeading==0,"leader reacquisition");
    lifecycle.Warm(actor,p,200);lifecycle.Render(actor,new TurnPose{from=3,to=3,angle=3},p,200,true);
    Verify(lifecycle.ValidationHeading==-270,"warmup is not visible turn history");
   }
   int[] froms={0,1,2,3,0,2,3,1,2},tos={1,2,3,0,2,0,1,3,0};
   for(int c=0;c<froms.Length;c++){
    int row=c==8?1:0;var actor=actors[row];actor.Bright=false;var clock=new NativeTurnClock(true,froms[c]);clock.Request(froms[c],tos[c],0);
    var first=clock.Sample(0);leaders[row*2].Render(actor,first,players[row*2],0,false);leaders[row*2+1].Render(actor,first,players[row*2+1],0,false);
    double old=0,next=0;
    for(int f=0;f<=60;f++){
     double t=f*1000.0/120;var pose=clock.Sample(t);bank.Render(actor,pose,19,0);
     leaders[row*2].Render(actor,pose,players[row*2],t,true);leaders[row*2+1].Render(actor,pose,players[row*2+1],t,true);
     double a=leaders[row*2].ValidationHeading,b=leaders[row*2+1].ValidationHeading;
     if(f>0){result.oldAngularStep=Math.Max(result.oldAngularStep,Math.Abs(a-old));result.newAngularStep=Math.Max(result.newAngularStep,Math.Abs(b-next));}
     old=a;next=b;yield return null;
    }
    result.settleError=Math.Max(result.settleError,Math.Abs(UnityEngine.Mathf.DeltaAngle((float)old,(float)next)));result.turnCases++;
   }
  }
  static int Difference(Color32[] a,Color32[] b){
   int max=0;for(int i=0;i<a.Length;i++)max=Math.Max(max,Math.Max(Math.Max(Math.Abs(a[i].r-b[i].r),Math.Abs(a[i].g-b[i].g)),Math.Max(Math.Abs(a[i].b-b[i].b),Math.Abs(a[i].a-b[i].a))));return max;
  }
  static int Violations(Color32[] pixels){int n=0;foreach(var p in pixels)if(p.r>p.a+2||p.g>p.a+2||p.b>p.a+2)n++;return n;}
  static Texture2D Read(RenderTexture texture){
   var prior=RenderTexture.active;RenderTexture.active=texture;var image=new Texture2D(texture.width,texture.height,TextureFormat.RGBA32,false);
   image.ReadPixels(new Rect(0,0,texture.width,texture.height),0,0);image.Apply();RenderTexture.active=prior;return image;
  }
  void OnDestroy(){
   if(cameraView){cameraView.targetTexture=null;Destroy(cameraView.gameObject);}
   if(view){if(RenderTexture.active==view)RenderTexture.active=null;view.Release();Destroy(view);}if(heads!=null)foreach(var head in heads)if(head)Destroy(head);
   if(leaders!=null)foreach(var leader in leaders)leader?.Dispose();if(actors!=null)foreach(var actor in actors)actor?.Dispose();
   bank?.Dispose();art?.Dispose();previous?.Dispose();current?.Dispose();if(quad)Destroy(quad);
  }
 }
}


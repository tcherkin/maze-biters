using System;using UnityEngine;
namespace MazeBiters.NativeStudy {
 public static class NativeDisplayValidation {
  public static int Run(){int n=0;void Check(bool b,string label){n++;if(!b)throw new Exception("Display layout: "+label);}
   foreach(float aspect in new[]{4f/3,16f/9,16f/10,21f/9,32f/9,9f/16}){var f=new NativeFrame(aspect);Check(f.Width>=575.999&&f.Height>=431.999,"no original content cropped");
    Check(Math.Abs(f.Width/f.Height-aspect)<.00001,"square logical pixels");Check(Math.Abs(f.Board.width-576)<.001&&Math.Abs(f.Board.height-400)<.001,"unchanged original playfield");var cam=new NativeGameplayCamera();cam.Reset(1000);
    for(int y=0;y<25;y++)for(int x=0;x<36;x++){var p=f.ToOriginal(new Vector2(f.Board.x+(x+.5f)*16,f.Board.y+(y+.5f)*16));Check(cam.PointerCell(p.x,p.y,out int xx,out int yy)&&xx==x&&yy==y,"pointer roundtrip");}
    if(f.Original.x>0){var p=f.ToOriginal(new Vector2(f.Board.x-1,200));Check(!cam.PointerCell(p.x,p.y,out _,out _),"stars are not navigable");}
    foreach(string q in new[]{"hd","4k"}){var p=f.Pixels(q);Check(p.y==(q=="4k"?2160:1080),"native target height");Check(Math.Abs((float)p.x/p.y-aspect)<.001,"target aspect");}
   }
   Check(new NativeFrame(16f/9).Pixels("hd")==new Vector2Int(1920,1080),"native HD widescreen");
   Check(new NativeFrame(16f/9).Pixels("4k")==new Vector2Int(3840,2160),"native 4K widescreen");
   Check(NativeDisplay.ExitMenu(false,false,true),"ESC quits title");Check(!NativeDisplay.ExitMenu(true,false,true),"records ESC is back, not quit");Check(!NativeDisplay.ExitMenu(false,true,true),"pending confirmation cannot quit accidentally");
   return n+NativeWideWorldValidation.Run();
  }
 }
}


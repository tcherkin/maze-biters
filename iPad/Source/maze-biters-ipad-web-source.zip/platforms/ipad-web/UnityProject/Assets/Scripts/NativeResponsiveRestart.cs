using System.Collections;
namespace MazeBiters.NativeStudy {
 public sealed partial class NativeMenu {
  internal void RestartFromGameplay(){if(changing||!gameplay)return;StartCoroutine(RestartWithConfirmation());}
  IEnumerator RestartWithConfirmation(){
   int mode=gameplay.MenuMode;ReturnToMenu();while(changing)yield return null;
   State.SetFocus(System.Array.IndexOf(NativeMenuState.Modes,mode),Now);Choose();
  }
 }
}

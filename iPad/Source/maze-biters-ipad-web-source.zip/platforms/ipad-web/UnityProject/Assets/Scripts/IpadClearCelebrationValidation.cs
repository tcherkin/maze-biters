#if UNITY_EDITOR
using System;
using System.Collections;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Reflection;
using System.Runtime.CompilerServices;
using System.Text;
using UnityEngine;
namespace MazeBiters.NativeStudy {
 public static class IpadClearCelebrationValidation {
  sealed class Tape {
   public uint state;public int draws;
   public Tape(uint seed){state=seed;}
   public double Next(){draws++;unchecked{state=state*1664525u+1013904223u;}return state/4294967296.0;}
   public Tape Copy()=>new Tape(state);
  }
  sealed class Fixture {public NativeGameplayWorld world;public Tape tape;public int events;}
  static readonly Vector2Int Right=Vector2Int.right;
  static int Distance(Vector2Int a,Vector2Int b)=>Math.Abs(a.x-b.x)+Math.Abs(a.y-b.y);
  static string[] Room(int width=16,int height=10)=>Enumerable.Range(0,height).Select(y=>y==0||y==height-1?new string('#',width):"#"+new string('.',width-2)+"#").ToArray();
  static string[] Passage(params Vector2Int[] cells){var rows=Enumerable.Range(0,9).Select(_=>new string('#',16).ToCharArray()).ToArray();foreach(var c in cells)rows[c.y][c.x]='.';return rows.Select(r=>new string(r)).ToArray();}
  static Fixture Make(int mode=1,string[] grid=null){
   var f=new Fixture{tape=new Tape(12345)};var w=f.world=new NativeGameplayWorld(grid??Room(),f.tape.Next){Time=1000,RealTime=2000,Transition=true,TransitionAt=1000,RevealAt=1000,SessionEnabled=true,LifecycleEnabled=true};
   w.SetMode(mode);w.Event=_=>f.events++;
   for(int i=0;i<w.PlayerCount;i++){var p=w.GetPlayer(i);p.Cell=new Vector2Int(2+i*3,2);p.From=p.Cell-Right;p.Previous=p.From;p.Score=125+i*50;p.ExactScore=p.Score;p.Lives=3;p.MoveStarted=980;p.MoveDuration=95;p.PowerUntil=6000;p.ShieldUntil=4000;p.PersonalThreat[i]=.75;}
   return f;
  }
  static NativeHunter AddHunter(NativeGameplayWorld w,Vector2Int cell,Vector2Int dir,double at=1000){var h=new NativeHunter{Id=1000+w.Hunters.Count,Cell=cell,From=cell,Dir=dir,Palette=w.Hunters.Count%3,LastMove=at,MoveStarted=at,MoveDuration=95,NextCutAt=1700,BiteAt=850,BiteEnd=980,Anger=.4,Threat=.5,Aggression=.6,RevengePlayerId=1,RevengeAt=700};h.PersonalThreat[0]=.7;w.Hunters.Add(h);return h;}
  static void AddContents(Fixture f){var w=f.world;AddHunter(w,new Vector2Int(4,5),Right);AddHunter(w,new Vector2Int(10,6),Vector2Int.left);w.PlaceScorpion(new Vector2Int(7,7),Right);w.Scorpion.NextEgg=1001;w.Scorpion.NextFruit=1001;w.Fruits.Add(new NativeFruit{Cell=new Vector2Int(8,5),Kind=2,Born=500});w.Eggs.Add(new NativeEgg{Cell=new Vector2Int(9,5),Born=-15000,CrackStage=1});w.SolidEggs.Add(new Vector2Int(9,5));w.PendingDrops.Add(new NativeDrop{Cell=new Vector2Int(12,6),Egg=true,Ready=1001});var snake=new NativeGameplaySnake{Id=50,Cell=new Vector2Int(3,7),Dir=Right,Body=new List<Vector2Int>{new Vector2Int(3,7),new Vector2Int(2,7)},Anger=.3,LastMove=950};snake.HunterThreat[1000]=2;w.Snakes.Add(snake);}

  // Capture public gameplay values and collection contents, but never traverse
  // the brain/world reference graph. Identity is checked separately for actors.
  static bool Scalar(Type t)=>t.IsPrimitive||t.IsEnum||t==typeof(string)||t.IsValueType;
  static string Value(object value,int depth=0){
   if(value==null)return "null";var type=value.GetType();if(Scalar(type))return Convert.ToString(value,CultureInfo.InvariantCulture);
   if(depth>5)return type.FullName+"@"+RuntimeHelpers.GetHashCode(value);
   if(value is IDictionary dictionary){var entries=new List<string>();foreach(DictionaryEntry entry in dictionary)entries.Add(Value(entry.Key,depth+1)+":"+Value(entry.Value,depth+1));entries.Sort(StringComparer.Ordinal);return "{"+string.Join(";",entries)+"}";}
   if(value is IEnumerable sequence){var entries=new List<string>();foreach(var entry in sequence)entries.Add(Value(entry,depth+1));if(type.IsGenericType&&type.GetGenericTypeDefinition()==typeof(HashSet<>))entries.Sort(StringComparer.Ordinal);return "["+string.Join(";",entries)+"]";}
   if(type==typeof(NativeMazeBrain)||type==typeof(NativeAllyBrain)||type==typeof(NativeAllyState)||type==typeof(NativeBrainState)||value is Delegate)return type.FullName+"@"+RuntimeHelpers.GetHashCode(value);
   var output=new StringBuilder(type.Name);foreach(var field in type.GetFields(BindingFlags.Public|BindingFlags.Instance).OrderBy(f=>f.Name,StringComparer.Ordinal))output.Append('|').Append(field.Name).Append('=').Append(Value(field.GetValue(value),depth+1));return output.ToString();
  }
  static string SourceState(NativeGameplayWorld w){
   var output=new StringBuilder();foreach(var field in typeof(NativeGameplayWorld).GetFields(BindingFlags.Public|BindingFlags.Instance).Where(f=>Scalar(f.FieldType)).OrderBy(f=>f.Name,StringComparer.Ordinal))output.Append(field.Name).Append('=').Append(Value(field.GetValue(w))).Append(';');
   output.Append(Value(w.Grid)).Append(Value(w.Snakes)).Append(Value(w.Hunters)).Append(Value(w.Scorpion)).Append(Value(w.Fruits)).Append(Value(w.Eggs)).Append(Value(w.PendingDrops)).Append(Value(w.SolidEggs));
   for(int i=0;i<w.PlayerCount;i++)output.Append("player@").Append(RuntimeHelpers.GetHashCode(w.GetPlayer(i))).Append(Value(w.GetPlayer(i)));return output.ToString();
  }
  static string MotionState(IpadClearCelebration c)=>Value(c.Hunters)+Value(c.Scorpion);
  static string SpawnState(NativeGameplayWorld w){var output=new StringBuilder(string.Join("/",w.Grid));output.Append('|').Append(w.Level).Append('|').Append(w.Mode).Append('|').Append(Value(w.Snakes));for(int i=0;i<w.PlayerCount;i++){var p=w.GetPlayer(i);output.Append('|').Append(p.Id).Append(':').Append(p.Cell).Append(':').Append(p.From).Append(':').Append(p.Dir).Append(':').Append(p.Score).Append(':').Append(p.Lives).Append(':').Append(p.Palette).Append(':').Append(p.ShieldUntil);}return output.ToString();}
  static Fixture Campaign(int mode){
   var generator=new NativeMazeGenerator(34,1);var levels=new Dictionary<int,SessionLevel>();SessionLevel Load(int n){if(!levels.TryGetValue(n,out var level)){level=generator.Generate(n);levels.Add(n,level);}return level;}
   var f=new Fixture{tape=new Tape(76543)};var w=f.world=new NativeGameplayWorld(Load(1).geometry,f.tape.Next){Time=1000,RealTime=1000};w.SetMode(mode);w.StartSession(Load);w.Event=_=>f.events++;w.Snakes.Clear();w.CheckLevelComplete();
   var open=Enumerable.Range(0,w.Width*w.Height).Select(i=>new Vector2Int(i%w.Width,i/w.Width)).First(c=>w.Floor(c)&&w.PlayerAt(c)==null);AddHunter(w,open,Right);return f;
  }
  public static int Run(){
   int count=0;void Check(bool ok,string name){count++;if(!ok)throw new Exception("IPAD CLEAR CELEBRATION: "+name);}
   void Near(double a,double b,string name)=>Check(Math.Abs(a-b)<1e-8,name);
   void AwayPlayers(NativeGameplayWorld w,IpadClearCelebration c){foreach(var h in c.Hunters)for(int i=0;i<w.PlayerCount;i++){var p=w.GetPlayer(i);if(p.Dead||p.Lives<=0)continue;Check(h.Cell!=p.Cell,"hunter avoids living player "+i);if(c.Time<p.MoveStarted+p.MoveDuration)Check(h.Cell!=p.From,"hunter avoids moving player source "+i);}if(c.Scorpion!=null)for(int i=0;i<w.PlayerCount;i++){var p=w.GetPlayer(i);if(p.Dead||p.Lives<=0)continue;Check(c.Scorpion.Cell!=p.Cell&&c.Scorpion.Tail!=p.Cell,"scorpion avoids living player "+i);}}

   for(int mode=0;mode<=5;mode++){
    var f=Make(mode);AddContents(f);var w=f.world;string before=SourceState(w);int draws=f.tape.draws,events=f.events;var originals=w.Hunters.ToArray();var scorpion=w.Scorpion;var c=new IpadClearCelebration(w);
    Check(ReferenceEquals(c.World,w)&&c.Started==w.TransitionAt&&c.Time==c.Started,"source/time identity mode "+mode);
    Check(c.Hunters.Count==2&&!ReferenceEquals(c.Hunters[0],originals[0])&&!ReferenceEquals(c.Hunters[1],originals[1]),"detached hunters mode "+mode);
    Check(c.Scorpion!=null&&!ReferenceEquals(c.Scorpion,scorpion),"detached scorpion mode "+mode);
    for(int i=0;i<2;i++){var a=c.Hunters[i];var b=originals[i];Check(a.Id==b.Id&&a.Palette==b.Palette&&a.Cell==b.Cell&&a.From==b.From&&a.Dir==b.Dir&&a.MoveStarted==b.MoveStarted&&a.MoveDuration==b.MoveDuration&&a.BiteAt==b.BiteAt&&a.BiteEnd==b.BiteEnd,"initial hunter visual state mode "+mode);}
    var pose=c.Scorpion.Motion.Sample(c.Started);var sourcePose=scorpion.Motion.Sample(c.Started);Near(pose.x,sourcePose.x,"initial scorpion pose x");Near(pose.y,sourcePose.y,"initial scorpion pose y");Near(pose.angle,sourcePose.angle,"initial scorpion angle");
    int turns=0;for(int step=1;step<=120;step++){c.Advance(c.Started+step*100,(h,old,t)=>{turns++;Check(c.Hunters.Contains(h)&&!w.Hunters.Contains(h),"callback contains detached actor");Check(t==c.Time&&Distance(old,Vector2Int.zero)==1,"callback absolute time/old direction");});AwayPlayers(w,c);foreach(var h in c.Hunters)Check(w.Floor(h.Cell)&&!w.SolidEggs.Contains(h.Cell),"presentation hunter stays on open floor");}
    Check(turns>0,"presentation moves mode "+mode);Check(SourceState(w)==before,"all authoritative state frozen mode "+mode);Check(f.tape.draws==draws&&f.events==events,"no authoritative RNG/events mode "+mode);Check(ReferenceEquals(w.Hunters[0],originals[0])&&ReferenceEquals(w.Scorpion,scorpion),"source identities frozen mode "+mode);
    Check(w.Fruits.Count==1&&w.Eggs.Count==1&&w.PendingDrops.Count==1,"no eating, hatching or drops mode "+mode);
   }

   // Speeds use the existing move deadline; late calls advance one cell only.
   {
    var f=Make(grid:Passage(Enumerable.Range(1,12).Select(x=>new Vector2Int(x,5)).ToArray()));var h=AddHunter(f.world,new Vector2Int(3,5),Right);var c=new IpadClearCelebration(f.world);
    c.Advance(1094);Check(c.Hunters[0].Cell==h.Cell,"hunter waits before 95 ms");c.Advance(1095);Check(c.Hunters[0].Cell==new Vector2Int(4,5)&&c.Hunters[0].From==h.Cell,"hunter steps at 95 ms");Near(c.Hunters[0].MoveDuration,95,"hunter original duration");
    string state=MotionState(c);double time=c.Time;c.Advance(time);c.Advance(time-500);c.Advance(double.NaN);c.Advance(double.PositiveInfinity);c.Advance(double.NegativeInfinity);Check(c.Time==time&&MotionState(c)==state,"repeated/backward/invalid timestamps ignored");
    var old=c.Hunters[0].Cell;int callbacks=0;c.Advance(100000,(a,d,t)=>callbacks++);Check(Distance(c.Hunters[0].Cell,old)==1&&callbacks==1,"no hunter catch-up after stall");old=c.Hunters[0].Cell;c.Advance(100001);Check(c.Hunters[0].Cell==old,"fresh hunter deadline after stall");
   }
   {
    var f=Make(grid:Passage(Enumerable.Range(1,12).Select(x=>new Vector2Int(x,5)).ToArray()));f.world.PlaceScorpion(new Vector2Int(4,5),Right);var c=new IpadClearCelebration(f.world);c.Advance(1217);Check(c.Scorpion.Cell==new Vector2Int(4,5),"scorpion waits before 218 ms");c.Advance(1218);Check(c.Scorpion.Cell==new Vector2Int(5,5)&&c.Scorpion.Tail==new Vector2Int(4,5),"scorpion original 218 ms step");var old=c.Scorpion.Cell;c.Advance(100000);Check(Distance(old,c.Scorpion.Cell)==1,"no scorpion catch-up after stall");old=c.Scorpion.Cell;c.Advance(100001);Check(c.Scorpion.Cell==old,"fresh scorpion deadline after stall");
   }
   {
    var f=Make(grid:Passage(Enumerable.Range(1,10).Select(x=>new Vector2Int(x,5)).ToArray()));var h=AddHunter(f.world,new Vector2Int(3,5),Right,850);h.From=new Vector2Int(2,5);h.MoveStarted=975;var c=new IpadClearCelebration(f.world);c.Advance(1069);Check(c.Hunters[0].Cell==h.Cell&&c.Hunters[0].From==h.From,"in-flight hunter completes before new move");c.Advance(1070);Check(c.Hunters[0].Cell==new Vector2Int(4,5),"hunter resumes after in-flight end");
   }
   {
    var f=Make();f.world.PlaceScorpion(new Vector2Int(6,6),Vector2Int.up);var s=f.world.Scorpion;s.LastMove=850;s.Tail=new Vector2Int(6,5);s.Motion=new NativeScorpionMotion(new Vector2Int(6,5),new Vector2Int(5,5),Right,s.Cell,s.Tail,s.Dir,975,700);var c=new IpadClearCelebration(f.world);
    Check(!ReferenceEquals(c.Scorpion.Motion,s.Motion),"mutable in-flight curve is copied");string motion=Value(c.Scorpion.Motion);s.Motion.fromX+=500;Check(Value(c.Scorpion.Motion)==motion,"source curve changes do not affect snapshot");c.Advance(1192);Check(c.Scorpion.Cell==new Vector2Int(6,6)&&Value(c.Scorpion.Motion)==motion,"in-flight scorpion curve completes before step");c.Advance(1193);Check(Distance(c.Scorpion.Cell,new Vector2Int(6,6))==1,"scorpion resumes after quarter turn");
   }

   // Deliberate small topologies make the routing expectations unambiguous.
   {
    var f=Make(grid:Passage(Enumerable.Range(1,5).Select(x=>new Vector2Int(x,5)).ToArray()));AddHunter(f.world,new Vector2Int(3,5),Right);var c=new IpadClearCelebration(f.world);c.Advance(1095);Check(c.Hunters[0].Cell==new Vector2Int(4,5),"no arbitrary reverse with forward passage");c.Advance(1190);c.Advance(1285);Check(c.Hunters[0].Cell==new Vector2Int(4,5)&&c.Hunters[0].Dir==-Right,"reverse at dead end");
   }
   {
    var f=Make(grid:Passage(new Vector2Int(2,5),new Vector2Int(3,5)));AddHunter(f.world,new Vector2Int(3,5),Right);var c=new IpadClearCelebration(f.world);c.Advance(1095);Check(c.Hunters[0].Cell==new Vector2Int(2,5),"blocked front permits ricochet");
   }
   {
    var f=Make(grid:Passage(new Vector2Int(2,5),new Vector2Int(3,5),new Vector2Int(3,4)));AddHunter(f.world,new Vector2Int(3,5),Right);var c=new IpadClearCelebration(f.world);c.Advance(1095);Check(c.Hunters[0].Cell==new Vector2Int(3,4),"available side branch preferred to U-turn");
   }
   {
    var f=Make(grid:Passage(new Vector2Int(3,5)));AddHunter(f.world,new Vector2Int(3,5),Right);var c=new IpadClearCelebration(f.world);int turns=0;c.Advance(5000,(h,d,t)=>turns++);Check(c.Hunters[0].Cell==new Vector2Int(3,5)&&turns==0,"fully blocked hunter stays without turn callback");
   }
   {
    var f=Make();f.world.Player.Cell=f.world.Player.From=new Vector2Int(6,5);AddHunter(f.world,new Vector2Int(4,5),Right);var c=new IpadClearCelebration(f.world);c.Advance(1095);Check(c.Hunters[0].Dir!=Right&&c.Hunters[0].Dir!=-Right&&Distance(c.Hunters[0].Cell,f.world.Player.Cell)>2,"near player prefers an outward side route");
   }
   {
    var f=Make(grid:Passage(Enumerable.Range(1,7).Select(x=>new Vector2Int(x,5)).ToArray()));AddHunter(f.world,new Vector2Int(3,5),Right);f.world.SolidEggs.Add(new Vector2Int(4,5));var c=new IpadClearCelebration(f.world);f.world.SolidEggs.Clear();c.Advance(1095);Check(c.Hunters[0].Cell==new Vector2Int(2,5),"solid egg remains blocked in snapshot");
   }
   {
    var f=Make(grid:Passage(Enumerable.Range(1,7).Select(x=>new Vector2Int(x,5)).ToArray()));AddHunter(f.world,new Vector2Int(3,5),Right);var c=new IpadClearCelebration(f.world);f.world.Grid=f.world.Grid.Select(r=>new string('#',r.Length)).ToArray();c.Advance(1095);Check(c.Hunters[0].Cell==new Vector2Int(4,5),"floor snapshot survives source grid replacement");
   }
   {
    var f=Make(grid:Passage(Enumerable.Range(1,5).Select(x=>new Vector2Int(x,5)).ToArray()));var p=f.world.Player;p.Cell=new Vector2Int(3,5);p.From=new Vector2Int(2,5);p.MoveStarted=980;p.MoveDuration=95;AddHunter(f.world,new Vector2Int(1,5),Right,850);var c=new IpadClearCelebration(f.world);c.Advance(1001);Check(c.Hunters[0].Cell==new Vector2Int(1,5),"active player source cell reserved");c.Advance(1100);Check(c.Hunters[0].Cell==new Vector2Int(2,5),"player source reservation expires after motion");p.Cell=new Vector2Int(5,5);c.Advance(1195);Check(c.Hunters[0].Cell!=new Vector2Int(3,5),"player destination remains a snapshot");
   }
   {
    var f=Make(grid:Passage(Enumerable.Range(1,5).Select(x=>new Vector2Int(x,5)).ToArray()));f.world.Player.Cell=new Vector2Int(3,5);f.world.Player.From=new Vector2Int(2,5);f.world.Player.Dead=true;AddHunter(f.world,new Vector2Int(1,5),Right,850);var c=new IpadClearCelebration(f.world);c.Advance(1001);Check(c.Hunters[0].Cell==new Vector2Int(2,5),"dead player does not reserve corridor");
   }
   {
    var a=Make(4);var b=Make(4);AddContents(a);AddContents(b);var ca=new IpadClearCelebration(a.world);var cb=new IpadClearCelebration(b.world);for(int i=1;i<=80;i++){ca.Advance(1000+i*110);cb.Advance(1000+i*110);}Check(MotionState(ca)==MotionState(cb),"local presentation stream deterministic");Check(a.tape.draws==0&&b.tape.draws==0,"local presentation randomness never draws gameplay RNG");
   }

   // Compare independent real sessions, including the existing next-level
   // preview. A visual intermission must not alter future spawn/music outcomes.
   for(int mode=0;mode<=5;mode++){
    var a=Campaign(mode);var b=Campaign(mode);var wa=a.world;var wb=b.world;Check(a.tape.state==b.tape.state,"campaign baseline RNG mode "+mode);var c=new IpadClearCelebration(wa);int draws=a.tape.draws,events=a.events;for(int i=1;i<=60;i++)c.Advance(c.Started+i*1000);Check(a.tape.draws==draws&&a.events==events,"long intermission leaves next RNG/events mode "+mode);
    var nextA=wa.LevelLoader(2);var nextB=wb.LevelLoader(2);double at=wa.TransitionAt+NativeGameplayWorld.ClearDuration;var copyA=a.tape.Copy();var copyB=b.tape.Copy();var pa=wa.PreviewNextLevel(nextA,copyA.Next,at);var pb=wb.PreviewNextLevel(nextB,copyB.Next,at);Check(SpawnState(pa)==SpawnState(pb),"next preview unchanged mode "+mode);Check(a.tape.draws==draws,"preview leaves original RNG mode "+mode);
    wa.Time=wb.Time=at;wa.AdvanceLevel();wb.AdvanceLevel();Check(SpawnState(wa)==SpawnState(wb),"actual next level unchanged mode "+mode);Check(SpawnState(pa)==SpawnState(wa),"prepared spawn matches actual next level mode "+mode);Check(wa.MusicTrack==wb.MusicTrack&&wa.ScorpionSpawnAt==wb.ScorpionSpawnAt&&a.tape.state==b.tape.state&&a.tape.draws==b.tape.draws,"next music/lifecycle/RNG parity mode "+mode);Near(a.tape.Next(),b.tape.Next(),"future RNG continuation mode "+mode);
   }
   return count;
  }
 }
}
#endif

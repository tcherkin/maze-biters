using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using System.IO.Compression;
using CompressionLevel=System.IO.Compression.CompressionLevel;
using System.Threading.Tasks;
using Unity.Collections;
using UnityEngine;

namespace MazeBiters.NativeStudy {
 // Explicit validation-only entry point. Normal play never exports/readbacks art.
 public sealed class NativeGlassArtworkValidation:MonoBehaviour {
  [Serializable] sealed class Result {
   public string theme,quality;public bool passed,workerPreparation,publishedBoth,nonReadable,compactCache,boundedPreparation;
   public long cacheBytes,rawCacheBytes;public double packingMs;
   public int width,height,publicationSteps,painterWorkers;public long reliefBytes;public NativeMazeArtwork.PreparationProfile profile;
  }
  static string Argument(string name,string fallback){var args=Environment.GetCommandLineArgs();int i=Array.IndexOf(args,name);return i>=0&&i+1<args.Length?args[i+1]:fallback;}
  IEnumerator Start(){
   string folder=Argument("--report",Path.Combine(Application.persistentDataPath,"glass-art-validation"));
   string qualityFilter=Argument("--quality","all"),themeFilter=Argument("--theme","all");
   string root=Path.Combine(WebFiles.Root,"Reference/maze-brushes");
   string fixture=File.ReadAllText(Path.Combine(WebFiles.Root,"Reference/glass-brushes/validation-level.json"));
   foreach(string quality in new[]{"hd","4k"})foreach(string theme in NativeMazeGenerator.Themes){
    if(qualityFilter!="all"&&qualityFilter!=quality||themeFilter!="all"&&themeFilter!=theme)continue;
    var level=JsonUtility.FromJson<SessionLevel>(fixture);level.theme=theme;
    Task<NativeMazeArtwork> task=null;
    try{task=WebWorkQueue.Run(()=>new NativeMazeArtwork(level,1,true,true,root,true,quality));}catch(Exception e){Debug.LogException(e);Application.Quit(2);yield break;}
    while(!task.IsCompleted)yield return null;
    if(task.IsFaulted){Debug.LogException(task.Exception);Application.Quit(2);yield break;}
    var art=task.Result;string destination=Path.Combine(folder,theme,quality);Exception failure=null;
    try{Directory.CreateDirectory(destination);art.WriteGlassValidationStaging(destination);}catch(Exception e){failure=e;}
    if(failure!=null){art.Discard();Debug.LogException(failure);Application.Quit(2);yield break;}
    long cacheBytes=art.GlassStagingBytes,rawCacheBytes=art.GlassRawStagingBytes;int steps=0;bool done=false;
    while(!done){try{done=art.PublishStep();steps++;}catch(Exception e){failure=e;}if(failure!=null)break;yield return null;}
    try{
     if(failure!=null)throw failure;
     bool published=art.Maze&&art.Emission&&art.LowReceiver;
     if(!published||art.Maze.width!=art.Width||art.Emission.height!=art.Height||art.Relief.LongLength!=(long)art.Width*art.Height)throw new InvalidDataException("Incomplete glass publication");
     bool nonReadable=!art.Maze.isReadable&&!art.Emission.isReadable&&!art.LowReceiver.isReadable;
     if(!nonReadable)throw new InvalidDataException("Glass texture staging retained");
     using(var relief=new NativeWallReceiver("",art.Relief,art.Width,art.Height)){
      if(relief.Texture.width!=art.Width||relief.Texture.height!=art.Height||relief.TextureBytes!=(long)art.Width*art.Height)throw new InvalidDataException("Wrong native relief dimensions");
     }
     var result=new Result{theme=theme,quality=quality,passed=true,workerPreparation=true,publishedBoth=published,nonReadable=nonReadable,width=art.Width,height=art.Height,publicationSteps=steps,painterWorkers=NativeMazeArtwork.GlassPainterWorkers,reliefBytes=art.Relief.LongLength,profile=art.Profile,compactCache=NativeMazeArtwork.CompactGlassCache,cacheBytes=cacheBytes,rawCacheBytes=rawCacheBytes,packingMs=art.GlassPackingMs};
     result.boundedPreparation=NativeMazeArtwork.BoundedGlassPreparation;
     File.WriteAllText(Path.Combine(destination,"result.json"),JsonUtility.ToJson(result,true));
     Debug.Log($"GLASS_ART_VALIDATION {theme}/{quality} {art.Width}x{art.Height} {steps} publication steps {art.Profile.totalMs:F2}ms PASS");
    }catch(Exception e){failure=e;}finally{art.Discard();}
    if(failure!=null){Debug.LogException(failure);Application.Quit(2);yield break;}
    // Destruction is deferred to end of frame; do not overlap successive 4K cases.
    yield return null;
   }
   Application.Quit(0);
  }
 }
 public sealed partial class NativeMazeArtwork {
  internal void WriteGlassValidationStaging(string folder){
   if(!IsGlass)throw new InvalidOperationException("Glass CPU staging unavailable");
   if(runGlassMaze!=null){WriteStartupGlassValidation(Path.Combine(folder,"maze.rgba.gz"),runGlassMaze);WriteStartupGlassValidation(Path.Combine(folder,"emission.rgba.gz"),runGlassEmission);}
   else if(packedGlassMaze!=null){WritePackedGlassValidation(Path.Combine(folder,"maze.rgba.gz"),packedGlassMaze);WritePackedGlassValidation(Path.Combine(folder,"emission.rgba.gz"),packedGlassEmission);}
   else{
    if(!pixels.IsCreated||!glassEmissionPixels.IsCreated)throw new InvalidOperationException("Glass CPU staging unavailable");
    WriteGlassNative(Path.Combine(folder,"maze.rgba.gz"),pixels.Reinterpret<byte>(4));
    WriteGlassNative(Path.Combine(folder,"emission.rgba.gz"),glassEmissionPixels.Reinterpret<byte>(4));
   }
   using(var file=File.Create(Path.Combine(folder,"relief.r8.gz")))using(var gzip=new GZipStream(file,CompressionLevel.Fastest))gzip.Write(Relief,0,Relief.Length);
   var low=new byte[pendingLow.Length*4];for(int i=0;i<pendingLow.Length;i++){low[i*4]=pendingLow[i].r;low[i*4+1]=pendingLow[i].g;low[i*4+2]=pendingLow[i].b;low[i*4+3]=pendingLow[i].a;}
   using(var file=File.Create(Path.Combine(folder,"receiver.rgba.gz")))using(var gzip=new GZipStream(file,CompressionLevel.Fastest))gzip.Write(low,0,low.Length);
  }
  static void WriteGlassNative(string file,NativeArray<byte> bytes){
   var buffer=new byte[1024*1024];using(var output=File.Create(file))using(var gzip=new GZipStream(output,CompressionLevel.Fastest)){
    for(int offset=0;offset<bytes.Length;offset+=buffer.Length){int count=Math.Min(buffer.Length,bytes.Length-offset);NativeArray<byte>.Copy(bytes,offset,buffer,0,count);gzip.Write(buffer,0,count);}
   }
  }
 }
}

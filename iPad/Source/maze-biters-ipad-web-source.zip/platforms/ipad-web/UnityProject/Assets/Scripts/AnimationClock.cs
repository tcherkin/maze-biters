using System;
namespace MazeBiters.NativeStudy {
 // Direct scalar ports of live-mouth.js and fantasy-blink-timing.js.
 // No Unity frame time or gameplay RNG is consumed by these functions.
 public static class AnimationClock {
  public static double Clamp(double t)=>Math.Max(0,Math.Min(1,t));
  public static double Ease(double t){t=Clamp(t);return t*t*t*(10+t*(-15+6*t));}
  public static double Blink(double elapsed){
   if(elapsed<0||elapsed>=220)return 0;
   if(elapsed<70)return Ease(elapsed/70);
   if(elapsed<105)return 1;
   return 1-Ease((elapsed-105)/115);
  }
  public static double Mouth(double elapsed,double duration,double distance=1){
   var phase=duration>0&&distance<=1.01?(Clamp(elapsed/duration)*distance)%1:0;
   return .5*(.66+.14*Math.Cos(2*Math.PI*phase));
  }
  public static double Bite(double now,double at,double end,double initial,double walking){
   if(now<at)return walking;
   if(now<=end)return initial+(1-initial)*Ease((now-at)/(end-at));
   if(now<end+90)return 1+(walking-1)*Ease((now-end)/90);
   return walking;
  }
  public static int Frame(double value,int max)=>Math.Max(0,Math.Min(max,(int)Math.Floor(value*max+.5)));
  public static int TurnDelta(int from,int to){var delta=(to-from+4)%4;return from==2&&to==0?-2:delta==3?-1:delta;}
  public static double TurnAngle(int from,int to,double elapsed)=>from+TurnDelta(from,to)*Ease(elapsed/90);
 }
 public sealed class BlinkClock {
  uint state;double started=double.NegativeInfinity,next;
  internal BlinkClock Copy()=>(BlinkClock)MemberwiseClone();
  public BlinkClock(uint seed,double firstAt){state=seed;next=firstAt;}
  public double Sample(double now){
   if(now>=next&&now>=started+220){started=now;next=now+220+3000+Random()*4000;}
   return AnimationClock.Blink(now-started);
  }
  double Random(){unchecked{state+=0x6D2B79F5;uint v=(state^(state>>15))*(1|state);v^=v+(v^(v>>7))*(61|v);return (v^(v>>14))/4294967296.0;}}
 }
}

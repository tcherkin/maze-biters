using System;
using UnityEngine;
namespace MazeBiters.NativeStudy {
 public sealed class NativeTurnGallery:IDisposable {
  readonly NativeTurnBank bank;readonly NativeTurnActor[] actors=new NativeTurnActor[6];readonly NativeTurnClock[] clocks=new NativeTurnClock[6];readonly BlinkClock[] blinks=new BlinkClock[6];readonly GameObject root;
  int previous=-1;public bool Visible;public string Caption{get;private set;}
  static readonly int[,] Pairs={{0,1},{1,0},{1,2},{2,1},{2,3},{3,2},{3,0},{0,3},{0,2},{2,0},{1,3},{3,1}};
  public NativeTurnGallery(NativeTurnBank bank,Mesh quad){this.bank=bank;root=new GameObject("Six-character turn inspection");string[] palettes={"p1","p2","ai","h1","h3","h4"};
   for(int i=0;i<6;i++){actors[i]=new NativeTurnActor(bank,i<3?"fantasy":"dragon",palettes[i]);clocks[i]=new NativeTurnClock();blinks[i]=new BlinkClock((uint)(1000+i*97),i*280+300);var go=new GameObject(palettes[i]);go.transform.SetParent(root.transform);go.transform.position=new Vector3(48+(i%3)*176,-65-(i/3)*152,-3);go.transform.localScale=new Vector3(128,128,1);go.AddComponent<MeshFilter>().sharedMesh=quad;var r=go.AddComponent<MeshRenderer>();r.sortingOrder=30;r.sharedMaterial=actors[i].Display;}
   root.SetActive(false);
  }
  public void Update(double clock){root.SetActive(Visible);if(!Visible)return;int step=(int)(clock/400),pair=step%12,from=Pairs[pair,0],to=Pairs[pair,1];double start=step*400;
   if(step!=previous){for(int i=0;i<6;i++){clocks[i].Reset();clocks[i].Request(from,to,start);}previous=step;}
   Caption=NativeLevelStudy.DirectionNames[from]+" -> "+NativeLevelStudy.DirectionNames[to]+" | "+Math.Min(90,Math.Max(0,clock-start)).ToString("0")+" / 90 ms";
   for(int i=0;i<6;i++)bank.Render(actors[i],clocks[i].Sample(clock),AnimationClock.Frame(AnimationClock.Mouth(clock%95,95),48),AnimationClock.Frame(blinks[i].Sample(clock),24));
  }
  public void Dispose(){foreach(var a in actors)a.Dispose();UnityEngine.Object.Destroy(root);}
 }
}

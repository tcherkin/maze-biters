using System;
using UnityEngine;

namespace MazeBiters.NativeStudy {
 // Two small procedural UI quads: no atlas, blur render target or CPU rasterization.
 // Radius/offsets use physical display pixels, independently of the game's HD/4K target.
 public sealed class IpadOrbitRenderer:IDisposable {
  const float DesignRadius=60,Padding=18,ThumbRatio=(128*.26f+120*.52f)/2/120;
  static readonly int ThumbId=Shader.PropertyToID("_Thumb"),LightId=Shader.PropertyToID("_Light");
  readonly Material[] paints=new Material[2];
  readonly GUIContent[] labels={new GUIContent("P1"),new GUIContent("P2")};
  static bool shaderWarmed;
  GUIStyle labelStyle;
  int labelSize;
  bool disposed;

  public IpadOrbitRenderer(){
   // Resources keeps this UI-only shader in native and WebGL builds without a scene reference.
   var shader=Resources.Load<Shader>("OrbitTouch");
   if(!shader)throw new InvalidOperationException("The Orbit touch shader is missing.");
   for(int i=0;i<paints.Length;i++)paints[i]=new Material(shader){name="Orbit moonstone P"+(i+1),hideFlags=HideFlags.HideAndDontSave};
   Warmup();
  }

  void Warmup(){
   if(shaderWarmed||SystemInfo.graphicsDeviceType==UnityEngine.Rendering.GraphicsDeviceType.Null)return;
   var previous=RenderTexture.active;
   var surface=RenderTexture.GetTemporary(4,4,0,RenderTextureFormat.ARGB32);
   try{Graphics.Blit(Texture2D.whiteTexture,surface,paints[0],0);shaderWarmed=true;}
   finally{RenderTexture.active=previous;RenderTexture.ReleaseTemporary(surface);}
  }

  public void Draw(IpadOrbitInput input,float width,float height){
   if(disposed||input==null||Event.current==null||Event.current.type!=EventType.Repaint)return;
   DrawPads(input,width,height,true);
  }

  void DrawPads(IpadOrbitInput input,float width,float height,bool drawLabels){
   var oldColor=drawLabels?GUI.color:Color.white;var oldMatrix=drawLabels?GUI.matrix:Matrix4x4.identity;
   try {
    if(drawLabels){GUI.color=Color.white;GUI.matrix=Matrix4x4.identity;}
    for(int i=0;i<2;i++){
     var pad=input.Pads[i];
     if(pad==null||pad.Alpha<.002f||pad.Radius<=0)continue;
     float scale=pad.Radius/DesignRadius,extent=(DesignRadius+Padding)*scale;
     var rect=new Rect(pad.Center.x-extent,height-pad.Center.y-extent,extent*2,extent*2);
     if(rect.xMax<=0||rect.yMax<=0||rect.xMin>=width||rect.yMin>=height)continue;
     var paint=paints[i];
     paint.SetVector(ThumbId,new Vector4(pad.ThumbOffset.x/scale,pad.ThumbOffset.y/scale,DesignRadius*ThumbRatio,0));
     paint.SetVector(LightId,new Vector4(pad.LightAngle,pad.LightStrength,pad.Alpha,.64f));
     Graphics.DrawTexture(rect,Texture2D.whiteTexture,paint);
     if(drawLabels&&input.Duo){
      if(labelStyle==null)labelStyle=new GUIStyle(GUI.skin.label){alignment=TextAnchor.MiddleCenter,fontStyle=FontStyle.Normal,clipping=TextClipping.Overflow};
      int size=Mathf.Max(10,Mathf.RoundToInt(11*scale));
      if(labelSize!=size){labelSize=size;labelStyle.fontSize=size;}
      float alpha=pad.Alpha*pad.Alpha*(3-2*pad.Alpha);
      labelStyle.normal.textColor=new Color(.847f,.910f,1,alpha*.8f);
      GUI.Label(new Rect(pad.Center.x-24*scale,height-pad.Center.y-pad.Radius-22*scale,48*scale,18*scale),labels[i],labelStyle);
     }
    }
   }finally{if(drawLabels){GUI.matrix=oldMatrix;GUI.color=oldColor;}}
  }

 #if UNITY_EDITOR
  // Editor visual audits use the identical material and quad path over a supplied
  // background. Text labels belong to OnGUI, so this capture intentionally omits them.
  public void DrawToTarget(RenderTexture target,IpadOrbitInput input){
   if(disposed||!target||input==null)return;
   var previous=RenderTexture.active;
   GL.PushMatrix();
   try{RenderTexture.active=target;GL.LoadPixelMatrix(0,target.width,target.height,0);DrawPads(input,target.width,target.height,false);}
   finally{RenderTexture.active=previous;GL.PopMatrix();}
  }
 #endif

  public void Dispose(){
   if(disposed)return;disposed=true;
   for(int i=0;i<paints.Length;i++)if(paints[i]){
    if(Application.isPlaying)UnityEngine.Object.Destroy(paints[i]);else UnityEngine.Object.DestroyImmediate(paints[i]);
    paints[i]=null;
   }
  }
 }
}

using System;using System.Collections.Generic;using System.IO;using UnityEngine;using UnityEngine.Profiling;
namespace MazeBiters.NativeStudy {
 // A closed, lazy library, not a growing level cache. Streaming/import settings
 // are unchanged: only the original 2 x 9 tracks can be retained. No decoding,
 // playback or RNG is started by preparing/retaining a resource.
 public sealed class NativeMusicResources:IDisposable {
  sealed class Entry {public AudioClip clip;public ResourceRequest request;public Exception failure;public long started;}
  readonly Dictionary<string,Entry> entries=new Dictionary<string,Entry>(18);bool disposed;
  public const int Capacity=18;
  internal const double PreparationTimeoutSeconds=60;
  internal static long PreparationStamp()=>WebFiles.IsWeb?1+(long)(WebLifecycle.Realtime*System.Diagnostics.Stopwatch.Frequency):System.Diagnostics.Stopwatch.GetTimestamp();
  internal static bool PreparationTimedOut(long started)=>started!=0&&(PreparationStamp()-started)/(double)System.Diagnostics.Stopwatch.Frequency>=PreparationTimeoutSeconds;
  public static bool IsTrack(string name){
   if(name==null)return false;
   foreach(string prefix in new[]{"neon-stillness-level-","neon-orbit-level-"})
    if(name.Length==prefix.Length+1&&name.StartsWith(prefix,StringComparison.Ordinal)&&name[name.Length-1]>='1'&&name[name.Length-1]<='9')return true;
   return false;
  }
  Entry Find(string name){
   if(disposed)throw new ObjectDisposedException(nameof(NativeMusicResources));
   if(!IsTrack(name))throw new ArgumentException("Music is outside the original 18-track catalogue",nameof(name));
   if(!entries.TryGetValue(name,out var e)){e=new Entry();entries.Add(name,e);}return e;
  }
  public void Prepare(string name){
   var e=Find(name);if(e.clip)return;
   if(e.request!=null&&e.request.isDone)Complete(e,e.request,name);
   if(e.clip)return;
   if(e.request!=null){
    // An explicit retry can reuse a timed-out Unity request; it cannot be
    // cancelled, so do not queue duplicate loads or wait for it on this thread.
    if(e.failure!=null){e.failure=null;e.started=PreparationStamp();}
    return;
   }
   e.failure=null;e.started=PreparationStamp();
   try{var request=e.request=Resources.LoadAsync<AudioClip>("SessionAudio/"+name);request.completed+=_=>Complete(e,request,name);}
   catch(Exception error){e.failure=new IOException("Could not prepare music "+name,error);throw e.failure;}
  }
  void Complete(Entry e,ResourceRequest request,string name){
   if(!ReferenceEquals(e.request,request))return;
   var clip=request.asset as AudioClip;e.request=null;
   // Level cancellation keeps a reusable track; owner destruction releases
   // late completion. A superseded callback must not mutate the current entry.
   if(disposed){if(clip)Resources.UnloadAsset(clip);return;}
   e.clip=clip;e.failure=clip?null:new IOException("Prepared music completed without an AudioClip: SessionAudio/"+name);
  }
  public bool Ready(string name){
   if(name==null||!entries.TryGetValue(name,out var e))return false;
   if(e.request!=null&&e.request.isDone)Complete(e,e.request,name);
   if(e.clip)return true;
   if(e.failure==null&&e.request!=null&&PreparationTimedOut(e.started))e.failure=new TimeoutException("Music preparation exceeded "+PreparationTimeoutSeconds+" seconds: "+name);
   if(e.failure!=null)throw e.failure;
   return false;
  }
  public AudioClip Get(string name){
   var e=Find(name);if(e.request!=null&&e.request.isDone)Complete(e,e.request,name);
   if(e.failure!=null)throw e.failure;
   if(!e.clip)e.clip=Resources.Load<AudioClip>("SessionAudio/"+name);
   if(!e.clip)throw new IOException("Missing music "+name);return e.clip;
  }
  public int Count=>entries.Count;
  public int Pending{get{int n=0;foreach(var e in entries.Values)if(e.request!=null&&!e.request.isDone)n++;return n;}}
  // Unity's per-asset accounting; streaming/mixer pools are additionally
  // measured through total Unity allocation and OS process memory in probes.
  public long AssetBytes{get{long n=0;foreach(var e in entries.Values)if(e.clip){long size=Profiler.GetRuntimeMemorySizeLong(e.clip);if(size<=0)return -1;n+=size;}return n;}}
  public void Dispose(){
   if(disposed)return;disposed=true;
   foreach(var e in entries.Values){var clip=e.clip?e.clip:e.request!=null&&e.request.isDone?e.request.asset as AudioClip:null;if(clip)Resources.UnloadAsset(clip);e.clip=null;}
   entries.Clear();
  }
 }
}

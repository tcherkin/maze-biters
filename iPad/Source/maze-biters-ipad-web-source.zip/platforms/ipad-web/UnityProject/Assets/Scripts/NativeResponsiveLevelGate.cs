using System;
using UnityEngine;
namespace MazeBiters.NativeStudy {
 public sealed partial class NativeGameplayStudy {
  NativeGameplayWorld levelGateWorld;
  bool levelGateWaiting,levelGateFailed,responsiveLevelInstalling;
  int levelGateRetries;
  double levelGateTransitionAt,levelGateAttemptAt,levelGateReleaseTime,levelGateExtraTime,levelGateReadyCycle=-1;
  double levelGateTestNotBefore; // Set only by the opt-in functional probe.
  LevelPreparationWatchdog levelGateWatchdog;
  const double LevelGateCycle=872;
  bool ResponsiveLevelEligible=>IpadPresentation.Enabled&&NativeBalancedLaunch.Distributed&&NativeMenu.InstantMenuStart&&MenuOwner&&!menuPreparing&&!restartPreparing&&!logicPreparationInstance&&!contactProbe&&!catalogueControl&&!NativeMazeArtwork.LegacyPreparation&&!NoNextScene&&StagedNextScene;
  bool ResponsiveNextReady=>WebLifecycle.Realtime>=levelGateTestNotBefore&&!nextMazeFailed&&!nextSceneFailed&&nextMaze!=null&&nextMaze.level.level==world.NextLevelNumber&&nextScene?.ready==true&&nextScene.quality==quality&&nextScene.preview.Level==world.NextLevelNumber&&nextScene.preview.Mode==world.Mode;
  double? ResponsiveLevelStatusAlpha=>levelGateWaiting&&ReferenceEquals(levelGateWorld,world)&&world.Transition&&!preparingScene&&!preparingNextScene
   ?NativeGameplayWorld.Pulse(levelGateExtraTime,LevelGateCycle,int.MaxValue):(double?)null;

  LevelPreparationProgress ResponsivePreparationProgress(){
   var plan=nextScene;var publishing=publishingMaze?.art;
   return new LevelPreparationProgress{
    scene=plan,mazeTask=nextMazeTask,publishingMaze=publishingMaze,readyMaze=nextMaze,cpuSteps=WebWorkQueue.CompletedWork(nextMazeTask),
    taskStatus=nextMazeTask==null?-1:(int)nextMazeTask.Status,
    publicationStage=publishing?.PublishStage??-1,publicationOffset=publishing?.ResponsivePublicationOffset??-1,
    stage=plan?.stage??-1,index=plan?.index??-1,passes=plan?.passes??-1,primedSnakes=plan?.primedSnakes??-1,
    actors=plan?.actors.Count??-1,snakes=plan?.snakes.Count??-1,neonSteps=plan?.neon?.PreparationProgress??-1,packedUploads=NativeSnakeTextures.PackedUploads,
    flags=(nextMazeQueued?1:0)|(nextMazeFailed?2:0)|(nextSceneFailed?4:0)|(plan?.ready==true?8:0)|(plan?.gpuPending==true?16:0)|(plan?.gpuDone==true?32:0)
   };
  }

  // Only the presentation clock extends while loading. The original session
  // still advances once, at its originally scheduled simulation timestamp.
  bool HoldResponsiveLevel(ref double nextTime){
   if(!ResponsiveLevelEligible||!world.Transition){levelGateWorld=null;levelGateWaiting=false;return false;}
   double end=world.TransitionAt+NativeGameplayWorld.ClearDuration;
   AdvanceIpadExitCamera(levelGateWaiting?NativeGameplayWorld.ClearDuration+levelGateExtraTime+Math.Max(0,nextTime-time):nextTime-world.TransitionAt);
   if(nextTime<end&&!levelGateWaiting)return false;
   if(!ReferenceEquals(levelGateWorld,world)||levelGateTransitionAt!=world.TransitionAt){
    levelGateWorld=world;levelGateTransitionAt=world.TransitionAt;levelGateWaiting=levelGateFailed=false;levelGateRetries=0;
    levelGateAttemptAt=WebLifecycle.Realtime;levelGateReadyCycle=-1;levelGateExtraTime=0;
    levelGateWatchdog.Reset(levelGateAttemptAt,ResponsivePreparationProgress());
   }
   if(!levelGateWaiting&&ResponsiveNextReady&&IpadExitCameraCanLeave){responsiveLevelInstalling=true;return false;}
   if(!levelGateWaiting){levelGateWaiting=true;levelGateReleaseTime=nextTime;}
   else levelGateExtraTime+=Math.Max(0,nextTime-time);
   var watchdog=levelGateWatchdog.Observe(WebLifecycle.Realtime,ResponsivePreparationProgress());
   if(watchdog==LevelPreparationWatchdogStatus.Deadline){FailResponsiveLevel(new TimeoutException("Next-level preparation exceeded the 300-second transition limit"));return true;}
   if(ResponsiveNextReady){
    if(levelGateReadyCycle<0){
     levelGateReadyCycle=Math.Ceiling(levelGateExtraTime/LevelGateCycle)*LevelGateCycle;
     if(ExitCameraEnabled&&ExitCameraMatches)levelGateReadyCycle=Math.Max(levelGateReadyCycle,ipadExitCamera.EndElapsed-NativeGameplayWorld.ClearDuration);
    }
    if(levelGateExtraTime>=levelGateReadyCycle&&IpadExitCameraCanLeave){nextTime=levelGateReleaseTime;levelGateWaiting=false;responsiveLevelInstalling=true;return false;}
   }else{
    levelGateReadyCycle=-1;
    bool expired=watchdog==LevelPreparationWatchdogStatus.Stalled;
    if(nextMazeFailed||nextSceneFailed||expired){
     if(levelGateRetries>=2){FailResponsiveLevel(new InvalidOperationException("Next-level preparation did not finish after three attempts"));return true;}
     levelGateRetries++;levelGateAttemptAt=WebLifecycle.Realtime;
     // A finished map survives a GPU/audio retry. Failed/incomplete CPU work
     // is cancelled cooperatively and replaced without waiting for its worker.
     if(nextMaze!=null&&!nextMazeFailed)CancelNextScene();
     else {CancelNextMaze();QueueNextMaze();}
     levelGateWatchdog.RestartAttempt(levelGateAttemptAt,ResponsivePreparationProgress());
     Debug.LogWarning("Retrying next-level preparation while LEVEL CLEARED remains visible ("+levelGateRetries+"/2)");
    }
    if(nextMaze==null&&publishingMaze==null&&nextMazeTask==null)QueueNextMaze();
   }
   time=Math.Max(time,end-.001);world.Time=time;
   return true;
  }
  bool AdvanceResponsiveGameplay(double nextTime){
   if(HoldResponsiveLevel(ref nextTime)){if(!levelGateFailed)AdvanceClearCelebration();return !levelGateFailed;}
   time=nextTime;
   try{world.Tick(time);world.UpdateAllTilts(time);}
   catch(Exception error)when(responsiveLevelInstalling){FailResponsiveLevel(error);return false;}
   finally{responsiveLevelInstalling=false;}
   AdvanceClearCelebration();
   return true;
  }
  void FailResponsiveLevel(Exception error){
   levelGateFailed=true;levelGateWaiting=false;responsiveLevelInstalling=false;
   Debug.LogWarning("Next level returned to the responsive menu instead of cold-loading: "+error);
   CancelNextMaze();MenuOwner.ReturnAfterLevelPreparationFailure(error);
  }
 }
 public sealed partial class NativeMazeArtwork {
  // Read-only publication cursor: copying another chunk is real progress even
  // when it remains within the same publication stage.
  internal int ResponsivePublicationOffset=>IsGlass?glassPublishOffset:publishingOffset;
 }
 public sealed partial class NativeMenu {
  internal void ReturnAfterLevelPreparationFailure(Exception error){
   StartCoroutine(ShowLevelPreparationFailure(error));
  }
  System.Collections.IEnumerator ShowLevelPreparationFailure(Exception error){
   ReturnToMenu();
   // Open resets preparation messages. Publish the failure after return has
   // completed, including any future asynchronous scene-release steps.
   while(changing)yield return null;
   preparationFailure=error.ToString();
   preparationError="Следващото ниво не се подготви. Изберете режим за нова игра.";
  }
 }
}

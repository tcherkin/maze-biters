using System;
using UnityEngine;
namespace MazeBiters.NativeStudy {
 public sealed partial class NativeGameplayStudy {
  NativeGameplayWorld levelGateWorld;
  bool levelGateWaiting,levelGateFailed,responsiveLevelInstalling;
  int levelGateRetries;
  double levelGateTransitionAt,levelGateAttemptAt,levelGateReleaseTime,levelGateExtraTime,levelGateReadyCycle=-1;
  double levelGateTestNotBefore; // Set only by the opt-in functional probe.
  const double LevelGateCycle=872,LevelGateAttemptSeconds=90;
  bool ResponsiveLevelEligible=>IpadPresentation.Enabled&&NativeBalancedLaunch.Distributed&&NativeMenu.InstantMenuStart&&MenuOwner&&!menuPreparing&&!restartPreparing&&!logicPreparationInstance&&!contactProbe&&!catalogueControl&&!NativeMazeArtwork.LegacyPreparation&&!NoNextScene&&StagedNextScene;
  bool ResponsiveNextReady=>Time.realtimeSinceStartupAsDouble>=levelGateTestNotBefore&&!nextMazeFailed&&!nextSceneFailed&&nextMaze!=null&&nextMaze.level.level==world.Level+1&&nextScene?.ready==true&&nextScene.quality==quality&&nextScene.preview.Level==world.Level+1&&nextScene.preview.Mode==world.Mode;
  double? ResponsiveLevelStatusAlpha=>levelGateWaiting&&ReferenceEquals(levelGateWorld,world)&&world.Transition&&!preparingScene&&!preparingNextScene
   ?NativeGameplayWorld.Pulse(levelGateExtraTime,LevelGateCycle,int.MaxValue):(double?)null;

  // Only the presentation clock extends while loading. The original session
  // still advances once, at its originally scheduled simulation timestamp.
  bool HoldResponsiveLevel(ref double nextTime){
   if(!ResponsiveLevelEligible||!world.Transition){levelGateWorld=null;levelGateWaiting=false;return false;}
   double end=world.TransitionAt+NativeGameplayWorld.ClearDuration;
   if(nextTime<end&&!levelGateWaiting)return false;
   if(!ReferenceEquals(levelGateWorld,world)||levelGateTransitionAt!=world.TransitionAt){
    levelGateWorld=world;levelGateTransitionAt=world.TransitionAt;levelGateWaiting=levelGateFailed=false;levelGateRetries=0;
    levelGateAttemptAt=Time.realtimeSinceStartupAsDouble;levelGateReadyCycle=-1;levelGateExtraTime=0;
   }
   if(!levelGateWaiting&&ResponsiveNextReady){responsiveLevelInstalling=true;return false;}
   if(!levelGateWaiting){levelGateWaiting=true;levelGateReleaseTime=nextTime;}
   else levelGateExtraTime+=Math.Max(0,nextTime-time);
   if(ResponsiveNextReady){
    if(levelGateReadyCycle<0)levelGateReadyCycle=Math.Ceiling(levelGateExtraTime/LevelGateCycle)*LevelGateCycle;
    if(levelGateExtraTime>=levelGateReadyCycle){nextTime=levelGateReleaseTime;levelGateWaiting=false;responsiveLevelInstalling=true;return false;}
   }else{
    levelGateReadyCycle=-1;
    bool expired=Time.realtimeSinceStartupAsDouble-levelGateAttemptAt>=LevelGateAttemptSeconds;
    if(nextMazeFailed||nextSceneFailed||expired){
     if(levelGateRetries>=2){FailResponsiveLevel(new InvalidOperationException("Next-level preparation did not finish after three attempts"));return true;}
     levelGateRetries++;levelGateAttemptAt=Time.realtimeSinceStartupAsDouble;
     // A finished map survives a GPU/audio retry. Failed/incomplete CPU work
     // is cancelled cooperatively and replaced without waiting for its worker.
     if(nextMaze!=null&&!nextMazeFailed)CancelNextScene();
     else {CancelNextMaze();QueueNextMaze();}
     Debug.LogWarning("Retrying next-level preparation while LEVEL CLEARED remains visible ("+levelGateRetries+"/2)");
    }
    if(nextMaze==null&&publishingMaze==null&&nextMazeTask==null)QueueNextMaze();
   }
   time=Math.Max(time,end-.001);world.Time=time;
   return true;
  }
  bool AdvanceResponsiveGameplay(double nextTime){
   if(HoldResponsiveLevel(ref nextTime))return !levelGateFailed;
   time=nextTime;
   try{world.Tick(time);world.UpdateAllTilts(time);}
   catch(Exception error)when(responsiveLevelInstalling){FailResponsiveLevel(error);return false;}
   finally{responsiveLevelInstalling=false;}
   return true;
  }
  void FailResponsiveLevel(Exception error){
   levelGateFailed=true;levelGateWaiting=false;responsiveLevelInstalling=false;
   Debug.LogWarning("Next level returned to the responsive menu instead of cold-loading: "+error);
   CancelNextMaze();MenuOwner.ReturnAfterLevelPreparationFailure(error);
  }
 }
 public sealed partial class NativeMenu {
  internal void ReturnAfterLevelPreparationFailure(Exception error){
   StartCoroutine(ShowLevelPreparationFailure(error));
  }
  System.Collections.IEnumerator ShowLevelPreparationFailure(Exception error){
   ReturnToMenu();
   // Open resets preparation messages. Publish the failure after return has
   // completed, including any future asynchronous scene-release steps.
   while(changing)yield return null;
   preparationFailure=error.ToString();
   preparationError="Следващото ниво не се подготви. Изберете режим за нова игра.";
  }
 }
}

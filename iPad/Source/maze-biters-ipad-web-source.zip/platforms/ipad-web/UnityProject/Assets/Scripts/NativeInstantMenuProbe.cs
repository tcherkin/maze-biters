using System;
using System.IO;
using System.Linq;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
namespace MazeBiters.NativeStudy {
 public sealed partial class NativeMenu {
  bool instantMenuTesting;
  [Serializable] sealed class InstantMenuResult {
   public bool passed,instant,clickFocused;public string quality,note;public int selectedMode;
   public double startupToMenuMs,clickToPlayMs;public double[] modeSwitchMs;
   public long readyWorkingSetBytes,playWorkingSetBytes,peakWorkingSetBytes;
   public string[] states,checks;
  }
  IEnumerator InstantMenuProbe(){
   Directory.CreateDirectory(Path.GetDirectoryName(report));var args=Environment.GetCommandLineArgs();
   int at=Array.IndexOf(args,"--mode"),chosen=at>=0?int.Parse(args[at+1]):1;
   bool images=Array.IndexOf(args,"--instant-menu-images")>=0;
   var r=new InstantMenuResult{instant=InstantMenuStart,quality=State.Quality,selectedMode=chosen};var checks=new List<string>();
   void Check(bool b,string n){if(!b)throw new Exception("Instant menu: "+n);checks.Add(n);}
   IEnumerator Ready(){double until=Time.realtimeSinceStartupAsDouble+180;while(!PreparedForSelection){if(preloadFailed||Time.realtimeSinceStartupAsDouble>until)throw new TimeoutException("First-level preparation");yield return null;}}
   yield return Ready();r.startupToMenuMs=Time.realtimeSinceStartupAsDouble*1000;
   NativeStartupLoading.Save(report);
   Check(!InstantMenuStart||LaunchReady&&preparedGame.AllMenuModesReady,"all original modes ready before the launch gate opens");
   string resources=preparedGame.MenuSharedResourceProof;var timings=new List<double>();var states=new List<string>();
   foreach(int mode in NativeMenuState.Modes){
    double start=Time.realtimeSinceStartupAsDouble;State.SetFocus(Array.IndexOf(NativeMenuState.Modes,mode),Now);yield return Ready();timings.Add((Time.realtimeSinceStartupAsDouble-start)*1000);
    Check(preparedGame.PreparedMode==mode,"prepared original mode "+mode);
    if(InstantMenuStart)Check(preparedGame.MenuSharedResourceProof==resources,"mode "+mode+" keeps the SAME map, lighting and art banks");
    string frozen=preparedGame.MenuClockProof;yield return null;yield return null;
    Check(frozen==preparedGame.MenuClockProof,"mode "+mode+" is frozen while waiting");
    states.Add(preparedGame.MenuFullState);
    if(images)SaveFrame("mode-"+mode,preparedGame.MenuTarget);
   }
   // Click a DIFFERENT mode in the same input turn: no hover dwell is required.
   State.SetFocus(Array.IndexOf(NativeMenuState.Modes,chosen==1?4:1),Now);yield return Ready();
   State.Speed=4;State.Music=0;Audio.MusicSetting=0;
   NativeMemory.TryRead(out r.readyWorkingSetBytes,out _,out _);
   r.clickFocused=Application.isFocused;
   double click=Time.realtimeSinceStartupAsDouble;State.SetFocus(Array.IndexOf(NativeMenuState.Modes,chosen),Now);Choose();
   while(!gameplay||!gameplay.MenuReady){if(Time.realtimeSinceStartupAsDouble-click>180)throw new TimeoutException("Playable first frame");yield return null;}
   r.clickToPlayMs=(Time.realtimeSinceStartupAsDouble-click)*1000;r.clickFocused&=Application.isFocused;
   Check(gameplay.MenuMode==chosen&&gameplay.MenuOptionsValid,"selected mode and late speed/music choices released correctly");
   Check(NativeBalancedLaunch.Distributed?r.clickToPlayMs>=890&&r.clickToPlayMs<960:!InstantMenuStart||r.clickToPlayMs<250,"warm click follows selected confirmation policy without extra loading pause");
   Check(gameplay.InstantMenuState==states[Array.IndexOf(NativeMenuState.Modes,chosen)],"selection preserves generated state, ALL players, snakes, music and RNG");
   NativeMemory.TryRead(out r.playWorkingSetBytes,out r.peakWorkingSetBytes,out _);
   r.modeSwitchMs=timings.ToArray();r.states=states.ToArray();r.checks=checks.ToArray();r.passed=true;
   r.note="Startup measured separately from click. Same compiled legacy control (--legacy-menu-preload), fixed seed only when explicitly passed. No simulation Tick in cache. Memory is process working set, not VRAM. Images/readback excluded from click timing. Muted audio.";
   File.WriteAllText(report,JsonUtility.ToJson(r,true));Application.Quit();
  }
 }
 public sealed partial class NativeGameplayStudy {
  public string MenuSharedResourceProof=>maze.GetEntityId()+"|"+glassEmission.GetEntityId()+"|"+neon.GetHashCode()+"|"+bank.GetHashCode();
  public string MenuFullState=>mazeSeed+"|"+difficultyIndex+"|"+random+"|"+time+"|"+world.Mode+"|"+world.MusicTrack+"|"+string.Join("/",world.Grid)+"|"+string.Join(";",Enumerable.Range(0,world.PlayerCount).Select(i=>JsonUtility.ToJson(world.GetPlayer(i))))+"|"+string.Join(";",world.Snakes.Select(JsonUtility.ToJson));
  public string InstantMenuState{get;private set;}
  void CaptureInstantMenuProof(){var args=Environment.GetCommandLineArgs();if(Array.IndexOf(args,"--instant-menu-probe")>=0||Array.IndexOf(args,"--balanced-start-probe")>=0||Array.IndexOf(args,"--responsive-start-probe")>=0)InstantMenuState=MenuFullState;}
 }
}

using System;
using System.IO;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace MazeBiters.NativeStudy {
 public sealed partial class NativeGameplayStudy {
  [Serializable] sealed class IpadCapture {public string name,image;public double zoom,sourceZoom,topSky,bottomSky,leftSky,rightSky,actorPixels;public bool visible;}
  [Serializable] sealed class IpadResult {public bool passed;public string quality,note;public int width,height,players,checks,numericChecks;public IpadCapture[] images;public long workingSetBytes;}
  IEnumerator ProbeIpadFraming(){
   var captures=new List<IpadCapture>();int checks=0;
   void Check(bool ok,string name){checks++;if(!ok)throw new Exception("iPad GPU probe: "+name);}
   Directory.CreateDirectory(Path.GetDirectoryName(report));fixedCamera=true;sessionSmoke=true;
   Reset(12);yield return DrainProbePreparation();
   Check(target.width==IpadPresentation.Pixels(quality).x&&target.height==IpadPresentation.Pixels(quality).y,"native iPad surface");
   Check(bank.Size==(quality=="4k"?160:80),"unchanged source animation resolution");
   void Place(params Vector2Int[] cells){for(int i=0;i<world.PlayerCount;i++){var p=world.GetPlayer(i);p.Cell=p.From=p.Previous=world.Brain.Nearest(cells[Math.Min(i,cells.Length-1)]);p.LastMove=time-1000;p.Waiting=true;p.ShieldUntil=0;p.Dir=p.Next=i%2==0?Vector2Int.down:Vector2Int.right;actors[p.Id].turn.Reset();}}
   void CaptureView(string name,double x,double y,double sourceZoom){
    gameplayCamera.X=x;gameplayCamera.Y=y;gameplayCamera.Zoom=sourceZoom;
    string state=MenuFullState;double clock=time;preparationLightFrame=true;Render();Render();
    var f=DisplayFrame;var b=f.ProjectBoard(cameraViewX,cameraViewY,cameraViewZoom);bool visible=true;var safe=IpadPresentation.SafeRect(f);
    for(int i=0;i<world.PlayerCount;i++){var p=world.GetPlayer(i).Visual(time);double px=b.x+(p.x+.5)*16*cameraViewZoom,py=b.y+(p.y+.5)*16*cameraViewZoom,r=12*cameraViewZoom;
     visible&=px-r>=safe.xMin-.01&&px+r<=safe.xMax+.01&&py-r>=safe.yMin-.01&&py+r<=safe.yMax+.01;
     var v=camera.WorldToViewportPoint(new Vector3((p.x+.5f)*16,-(p.y+.5f)*16,0));Check(Math.Abs(v.x-px/f.Width)<.00001&&Math.Abs(v.y-(1-py/f.Height))<.00001,"camera projection");
     f.WorldPoint(new Vector2((float)px,(float)py),cameraViewX,cameraViewY,cameraViewZoom,out double wx,out double wy);Check(Math.Abs(wx-(p.x+.5)*16)<.001&&Math.Abs(wy-(p.y+.5)*16)<.001,"pointer inverse");
    }
    Check(visible,name+" keeps all player silhouettes");Check(MenuFullState==state&&time==clock,name+" preserves simulation state");
    string file=name+".png";Capture(Path.Combine(Path.GetDirectoryName(report),file));
    captures.Add(new IpadCapture{name=name,image=file,zoom=cameraViewZoom,sourceZoom=sourceZoom,topSky=Math.Max(0,b.y),bottomSky=Math.Max(0,f.Height-b.yMax),leftSky=Math.Max(0,b.x),rightSky=Math.Max(0,f.Width-b.xMax),actorPixels=16*cameraViewZoom*target.height/f.Height,visible=visible});
   }
   Place(new Vector2Int(1,1),new Vector2Int(34,23),new Vector2Int(18,12));CaptureView("overview",288,200,1);
   Check(Math.Abs(captures[0].topSky-(32+IpadPresentation.SafeRect(DisplayFrame).yMin))<.01,"overview HUD reservation");Check(captures[0].bottomSky<.01,"overview reaches bottom");yield return null;
   CaptureView("separated",288,200,1.2);yield return null;
   Place(new Vector2Int(14,1),new Vector2Int(17,1),new Vector2Int(20,1));CaptureView("upper-medium",288,200/1.3,1.3);yield return null;
   CaptureView("upper-close",288,100,2);yield return null;
   Place(new Vector2Int(14,23),new Vector2Int(17,23),new Vector2Int(20,23));CaptureView("lower-close",288,300,2);yield return null;
   Place(new Vector2Int(1,10),new Vector2Int(1,12),new Vector2Int(1,14));CaptureView("left-close",144,200,2);yield return null;
   Place(new Vector2Int(34,10),new Vector2Int(34,12),new Vector2Int(34,14));CaptureView("right-close",432,200,2);yield return null;
   Check(Math.Abs(captures[5].leftSky-captures[3].topSky)<.01&&Math.Abs(captures[6].rightSky-captures[3].topSky)<.01,"equal side and upper sky in rendered scene");
   Place(new Vector2Int(16,11),new Vector2Int(18,12),new Vector2Int(20,13));CaptureView("centre-close",288,200,2);
   Check(Math.Abs(captures[captures.Count-1].actorPixels-(quality=="4k"?160:80))<.001,"native-size close actors");yield return null;
   // Continuous zoom and edge transition uses the same real camera application.
   double previousY=cameraViewY,maxJump=0;
   for(int i=0;i<=600;i++){double z=1+IpadFraming.Smooth(i/600.0);gameplayCamera.X=288;gameplayCamera.Y=200;gameplayCamera.Zoom=z;ApplyGameplayCamera();if(i>0)maxJump=Math.Max(maxJump,Math.Abs(cameraViewY-previousY));previousY=cameraViewY;if(i%100==0)yield return null;}
   Check(maxJump<.2,"continuous header/camera movement");
   double previousX=0,maxEdgeJump=0;
   for(int i=0;i<=600;i++){double z=1+IpadFraming.Smooth(i/600.0);gameplayCamera.X=288/z;gameplayCamera.Y=200;gameplayCamera.Zoom=z;ApplyGameplayCamera();if(i>0)maxEdgeJump=Math.Max(maxEdgeJump,Math.Abs(cameraViewX-previousX));previousX=cameraViewX;if(i%100==0)yield return null;}
   Check(maxEdgeJump<1,"continuous side camera movement");
   NativeMemory.TryRead(out long working,out _,out _);
   File.WriteAllText(report,JsonUtility.ToJson(new IpadResult{passed=true,quality=quality,width=target.width,height=target.height,players=world.PlayerCount,checks=checks,numericChecks=IpadFramingValidation.Run(),images=captures.ToArray(),workingSetBytes=working,note="Windows layout/render verification at iPad pixels; not an M5, Metal or device performance benchmark. Artwork, shaders, animation clocks and game rules are copied unchanged from the protected PC baseline. HD uses half-size output, native uses existing 4K artwork."},true));Application.Quit();
  }
 }
}

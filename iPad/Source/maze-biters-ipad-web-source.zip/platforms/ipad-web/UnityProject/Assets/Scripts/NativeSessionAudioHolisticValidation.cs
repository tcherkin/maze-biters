#if UNITY_EDITOR
using System;
using System.Text;
namespace MazeBiters.NativeStudy {
 public sealed partial class NativeSessionAudio {
  public sealed class HolisticClip {public string name;public float[] samples;public int channels,rate;}
  public void HolisticConfigure(int sampleRate,bool muted,HolisticClip[] source){lock(gate){ready=false;rate=sampleRate;PrepareMixerConstants();clips.Clear();voices.Clear();serial=0;Accepted=Rejected=0;OutputEnergy=0;compressorGain=1;Muted=muted;for(int i=0;i<lastAt.Length;i++)lastAt[i]=-1e6;foreach(var clip in source)clips.Add(clip.name,MakeClip(clip.samples,clip.channels,clip.rate));ready=true;}}
  public void HolisticChangeRate(int sampleRate){lock(gate){rate=sampleRate;PrepareMixerConstants();foreach(var clip in clips.Values)clip.step=(double)clip.rate/rate;}}
  public void HolisticWarm()=>PrepareSilentBus();
  public string HolisticMixerState(){lock(gate){var b=new StringBuilder();b.Append(rate).Append('|').Append(Accepted).Append('|').Append(Rejected).Append('|').Append(serial).Append('|').Append(BitConverter.ToInt32(BitConverter.GetBytes(compressorGain),0)).Append('|').Append(BitConverter.DoubleToInt64Bits(OutputEnergy));foreach(double t in lastAt)b.Append('|').Append(BitConverter.DoubleToInt64Bits(t));foreach(var v in voices)b.Append(';').Append(v.group).Append(',').Append(v.priority).Append(',').Append(v.order).Append(',').Append(BitConverter.DoubleToInt64Bits(v.position)).Append(',').Append(BitConverter.ToInt32(BitConverter.GetBytes(v.pan),0)).Append(',').Append(v.clip.channels).Append(',').Append(v.clip.rate);return b.ToString();}}
 }
}
#endif

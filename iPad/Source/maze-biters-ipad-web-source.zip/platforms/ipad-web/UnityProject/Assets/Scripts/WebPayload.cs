using System;
using System.Collections.Generic;
using System.IO;
using System.IO.Compression;
using System.Security.Cryptography;
using System.Text;

namespace MazeBiters.NativeStudy {
 // Validate a response before it becomes cached bootstrap state or visible art.
 // Hashing and decompression are both bounded, cooperative pieces on WebGL.
 internal static class WebPayload {
  const int Chunk=131072;
  static readonly UTF8Encoding Utf8=new UTF8Encoding(false,true);
  internal static void Validate(WebBootstrap.Manifest manifest){
   if(manifest==null||manifest.version!=1||manifest.packs==null||manifest.packs.Length==0||manifest.packs.Length>512)throw new InvalidDataException("Invalid asset manifest");
   bool runtime=false,menu=false;var files=new HashSet<string>(StringComparer.Ordinal);
   foreach(var pack in manifest.packs){
    if(pack==null||string.IsNullOrEmpty(pack.file)||!pack.file.EndsWith(".mbpack.gz",StringComparison.Ordinal)||pack.file.Length>128)throw new InvalidDataException("Invalid asset package name");
    foreach(char c in pack.file)if(!(c>='a'&&c<='z'||c>='0'&&c<='9'||c=='-'||c=='.'))throw new InvalidDataException("Invalid asset package name");
    if(!files.Add(pack.file)||pack.bytes<=0||pack.bytes>134217728||pack.rawBytes<=0||pack.rawBytes>536870912||pack.fileCount<=0||pack.fileCount>100000)throw new InvalidDataException("Invalid asset package dimensions");
    if(pack.sha256==null||pack.sha256.Length!=64)throw new InvalidDataException("Missing asset package fingerprint");
    foreach(char c in pack.sha256)if(!(c>='a'&&c<='f'||c>='A'&&c<='F'||c>='0'&&c<='9'))throw new InvalidDataException("Invalid asset package fingerprint");
    if(pack.stage=="menu"){if(runtime)throw new InvalidDataException("Menu packages must precede level packages");menu=true;}
    else if(pack.stage=="runtime")runtime=true;
    else throw new InvalidDataException("Invalid asset package stage");
   }
   if(!menu||!runtime)throw new InvalidDataException("Incomplete asset manifest");
  }
  internal static IEnumerable<object> Verify(WebBootstrap.Pack pack,byte[] data){
   if(data==null||data.LongLength!=pack.bytes)throw new InvalidDataException("Incomplete asset package: "+pack.file);
   using(var digest=SHA256.Create()){
    var budget=System.Diagnostics.Stopwatch.StartNew();int frameBytes=0;
    for(int offset=0;offset<data.Length;){
     int count=Math.Min(Chunk,data.Length-offset);digest.TransformBlock(data,offset,count,data,offset);offset+=count;frameBytes+=count;
     if(offset<data.Length&&(budget.Elapsed.TotalMilliseconds>=2||frameBytes>=Chunk*4)){yield return null;budget.Restart();frameBytes=0;}
    }
    digest.TransformFinalBlock(Array.Empty<byte>(),0,0);
    var hex=BitConverter.ToString(digest.Hash).Replace("-","");
    if(!string.Equals(hex,pack.sha256,StringComparison.OrdinalIgnoreCase))throw new InvalidDataException("Asset package fingerprint mismatch: "+pack.file);
   }
  }
  internal static IEnumerable<object> Unpack(WebBootstrap.Pack pack,byte[] data,string root){
   string boundary=Path.GetFullPath(root).TrimEnd(Path.DirectorySeparatorChar,Path.AltDirectorySeparatorChar)+Path.DirectorySeparatorChar;
   long unpacked=0;int fileCount=0;var files=new HashSet<string>(StringComparer.Ordinal);
   using(var memory=new MemoryStream(data))using(var zip=new GZipStream(memory,CompressionMode.Decompress))using(var reader=new BinaryReader(zip)){
    var buffer=new byte[Chunk];
    while(true){
     int nameLength=reader.ReadInt32();unpacked+=4;
     if(nameLength==0)break;
     if(nameLength<1||nameLength>4096)throw new InvalidDataException("Asset package path");
     byte[] nameBytes=reader.ReadBytes(nameLength);if(nameBytes.Length!=nameLength)throw new EndOfStreamException("Asset package path");
     string name=Utf8.GetString(nameBytes);
     if(Path.IsPathRooted(name)||name.IndexOf('\\')>=0||name.IndexOf(':')>=0)throw new InvalidDataException("Asset package path");
     foreach(string part in name.Split('/'))if(part.Length==0||part=="."||part=="..")throw new InvalidDataException("Asset package path");
     string path=Path.GetFullPath(Path.Combine(root,name));if(!path.StartsWith(boundary,StringComparison.Ordinal)||!files.Add(path))throw new InvalidDataException("Asset package boundary or duplicate");
     int remaining=reader.ReadInt32();unpacked+=nameLength+4;
     if(remaining<0||remaining>134217728||unpacked+remaining>pack.rawBytes)throw new InvalidDataException("Asset package size");
     Directory.CreateDirectory(Path.GetDirectoryName(path));
     using(var output=File.Create(path))while(remaining>0){int count=reader.Read(buffer,0,Math.Min(remaining,buffer.Length));if(count<=0)throw new EndOfStreamException(name);output.Write(buffer,0,count);remaining-=count;unpacked+=count;yield return null;}
     fileCount++;
    }
    if(unpacked!=pack.rawBytes||fileCount!=pack.fileCount||zip.ReadByte()!=-1)throw new InvalidDataException("Asset package ending or dimensions");
   }
  }
 }
}

using System;
using System.Collections.Generic;
using UnityEngine;

namespace MazeBiters.NativeStudy {
 // Menu-specific architecture. Corners and caps retain the complete approved
 // atlas tile; only straight connectors fit the distance between menu groups.
 // Coordinates are logical menu pixels, not a camera enlargement of a map.
 internal static class ArchitecturalMenuLayout {
  internal const float Module=58;
  const int FieldWidth=418,FieldHeight=352;
  const float OriginX=-302,OriginY=-242,FieldSizeX=1672,FieldSizeY=1408;
  const double SlotSeconds=10;
  struct Piece {internal Rect Bounds;internal int Mask;}
  struct Arc {
   internal Vector2 A,B,Centre;internal float Start,Length,Radius,Angle,Sweep;
   internal Vector2 At(float distance){float u=Mathf.Clamp01(distance/Length);return Radius==0?Vector2.LerpUnclamped(A,B,u):Centre+new Vector2(Mathf.Cos(Angle+Sweep*u),Mathf.Sin(Angle+Sweep*u))*Radius;}
  }
  sealed class Route {internal Arc[] Parts;internal float Length;internal Vector2 End;}
  static readonly Vector2[][] Paths=CreatePaths();
  static readonly Piece[] Pieces=CreatePieces();
  static readonly Route[] Routes=CreateRoutes();
  internal static int RouteCount=>Routes.Length;
  static Vector2[] Points(params float[] xy){var p=new Vector2[xy.Length/2];for(int i=0;i<p.Length;i++)p[i]=new Vector2(xy[i*2],xy[i*2+1]);return p;}
  static Vector2[][] CreatePaths(){
   var paths=new List<Vector2[]>();
   void Pair(params float[] xy){var left=Points(xy);paths.Add(left);var right=new Vector2[left.Length];for(int i=0;i<left.Length;i++)right[i]=new Vector2(1024-left[i].x,left[i].y);paths.Add(right);}
   // Small upper returns leave the title and score as the primary landmarks.
   Pair(126,54, 52,54, 52,112, 126,112);
   // The main runs pass outside the complete three-button group, then turn
   // into the open strip beneath the helper buttons, without outlining a box.
   Pair(282,170, 42,170, 42,448, 178,448, 178,568, 246,568);
   // Low side returns accompany the settings; their caps stay outside both
   // the cards and the central keyboard instruction, even at peak breathing.
   Pair(112,536, 42,536, 42,700);
   paths.Add(Points(512,208, 512,434));
   paths.Add(Points(330,590, 694,590));
   return paths.ToArray();
  }
  static int Direction(Vector2 delta){if(Mathf.Abs(delta.x)>0.001f&&Mathf.Abs(delta.y)>0.001f)throw new InvalidOperationException("Architectural wall must be axis aligned");return delta.x>0?2:delta.x<0?8:delta.y>0?4:1;}
  static Piece[] CreatePieces(){
   var result=new List<Piece>();float h=Module*.5f;
   foreach(var path in Paths){
    for(int i=0;i<path.Length;i++){
     int mask=0;if(i>0)mask|=Direction(path[i-1]-path[i]);if(i+1<path.Length)mask|=Direction(path[i+1]-path[i]);
     result.Add(new Piece{Bounds=new Rect(path[i].x-h,path[i].y-h,Module,Module),Mask=mask});
    }
    for(int i=1;i<path.Length;i++){
     var delta=path[i]-path[i-1];float distance=delta.magnitude;
     if(distance<Module-.001f)throw new InvalidOperationException("Full architectural corner tiles overlap along their path");
     float gap=distance-Module;if(gap<.001f)continue;
     Vector2 direction=delta/distance,start=path[i-1]+direction*h;int count=Mathf.CeilToInt(gap/Module);float step=gap/count;
     for(int j=0;j<count;j++){
      Vector2 a=start+direction*(j*step),b=start+direction*((j+1)*step);
      result.Add(new Piece{Mask=Mathf.Abs(delta.x)>.001f?10:5,Bounds=Mathf.Abs(delta.x)>.001f?new Rect(Mathf.Min(a.x,b.x),a.y-h,step,Module):new Rect(a.x-h,Mathf.Min(a.y,b.y),Module,step)});
     }
    }
   }
   return result.ToArray();
  }
  internal static Mesh BuildMesh(int tileSize){
   var vertices=new List<Vector3>();var uv=new List<Vector2>();var world=new List<Vector2>();var triangles=new List<int>();
   foreach(var p in Pieces){
    int i=vertices.Count;Rect r=p.Bounds;
    vertices.Add(new Vector3(r.xMin,-r.yMin,0));vertices.Add(new Vector3(r.xMax,-r.yMin,0));vertices.Add(new Vector3(r.xMax,-r.yMax,0));vertices.Add(new Vector3(r.xMin,-r.yMax,0));
    world.Add(new Vector2(r.xMin,r.yMin));world.Add(new Vector2(r.xMax,r.yMin));world.Add(new Vector2(r.xMax,r.yMax));world.Add(new Vector2(r.xMin,r.yMax));
    float u0=(p.Mask*tileSize+.5f)/(16*tileSize),u1=((p.Mask+1)*tileSize-.5f)/(16*tileSize),v0=.5f/tileSize,v1=1-.5f/tileSize;
    uv.Add(new Vector2(u0,v0));uv.Add(new Vector2(u1,v0));uv.Add(new Vector2(u1,v1));uv.Add(new Vector2(u0,v1));
    triangles.Add(i);triangles.Add(i+1);triangles.Add(i+2);triangles.Add(i);triangles.Add(i+2);triangles.Add(i+3);
   }
   var mesh=new Mesh{name="Symmetric substantial menu architecture",hideFlags=HideFlags.HideAndDontSave};mesh.SetVertices(vertices);mesh.SetUVs(0,uv);mesh.SetUVs(1,world);mesh.SetTriangles(triangles,0);mesh.RecalculateBounds();mesh.UploadMeshData(true);return mesh;
  }
  static float PixelAlpha(byte[] pixels,int size,Piece piece,float x,float y){
   int sx=Mathf.Clamp((int)((x-piece.Bounds.x)/piece.Bounds.width*size),0,size-1),sy=Mathf.Clamp((int)((y-piece.Bounds.y)/piece.Bounds.height*size),0,size-1);
   return pixels[(sy*16*size+piece.Mask*size+sx)*4+3]/255f;
  }
  internal static Texture2D BuildOptics(byte[] pixels,int tileSize){
   int count=FieldWidth*FieldHeight;var source=new float[count];var temp=new float[count];var broad=new float[count];float pitchX=FieldSizeX/FieldWidth,pitchY=FieldSizeY/FieldHeight;
   foreach(var p in Pieces){
    int x0=Math.Max(0,Mathf.CeilToInt((p.Bounds.xMin-OriginX)/pitchX-.5f)),x1=Math.Min(FieldWidth,Mathf.CeilToInt((p.Bounds.xMax-OriginX)/pitchX-.5f));
    int y0=Math.Max(0,Mathf.CeilToInt((p.Bounds.yMin-OriginY)/pitchY-.5f)),y1=Math.Min(FieldHeight,Mathf.CeilToInt((p.Bounds.yMax-OriginY)/pitchY-.5f));
    for(int y=y0;y<y1;y++)for(int x=x0;x<x1;x++){int index=y*FieldWidth+x;source[index]=Math.Max(source[index],PixelAlpha(pixels,tileSize,p,OriginX+(x+.5f)*pitchX,OriginY+(y+.5f)*pitchY));}
   }
   Array.Copy(source,broad,count);Box(source,temp,2,true);Box(temp,source,2,false);for(int i=0;i<3;i++){Box(broad,temp,5,true);Box(temp,broad,5,false);}
   var colors=new Color32[count];for(int y=0;y<FieldHeight;y++)for(int x=0;x<FieldWidth;x++){int i=y*FieldWidth+x;colors[i]=new Color32(Channel(broad[i]),Channel(source[i]),Channel(broad[Math.Max(0,y-4)*FieldWidth+x]),255);}
   var texture=new Texture2D(FieldWidth,FieldHeight,TextureFormat.RGBA32,false,false){name="Matched architectural glass reflections",filterMode=FilterMode.Bilinear,wrapMode=TextureWrapMode.Clamp,hideFlags=HideFlags.HideAndDontSave};texture.SetPixels32(colors);texture.Apply(false,true);return texture;
  }
  static byte Channel(float value)=>(byte)Mathf.Clamp(Mathf.FloorToInt(value*255+.5f),0,255);
  static void Box(float[] source,float[] destination,int radius,bool horizontal){
   int length=horizontal?FieldWidth:FieldHeight,lines=horizontal?FieldHeight:FieldWidth,stride=horizontal?1:FieldWidth;float reciprocal=1f/(radius*2+1);
   for(int line=0;line<lines;line++){int origin=horizontal?line*FieldWidth:line;float sum=0;for(int p=-radius;p<=radius;p++)sum+=source[origin+Math.Max(0,Math.Min(length-1,p))*stride];for(int p=0;p<length;p++){destination[origin+p*stride]=sum*reciprocal;sum+=source[origin+Math.Min(length-1,p+radius+1)*stride]-source[origin+Math.Max(0,p-radius)*stride];}}
  }
  static Route[] CreateRoutes(){var routes=new List<Route>();foreach(var path in Paths){var parts=new List<Arc>();float total=0,radius=Module*.23f;Vector2 last=path[0];
   void Line(Vector2 a,Vector2 b){float length=Vector2.Distance(a,b);if(length<.0001f)return;parts.Add(new Arc{A=a,B=b,Start=total,Length=length});total+=length;}
   for(int i=1;i<path.Length-1;i++){Vector2 point=path[i],incoming=(point-path[i-1]).normalized,outgoing=(path[i+1]-point).normalized;
    Vector2 entry=point-incoming*radius,exit=point+outgoing*radius,centre=point-incoming*radius+outgoing*radius;Line(last,entry);
    Vector2 a=entry-centre,b=exit-centre;float sweep=Mathf.Atan2(a.x*b.y-a.y*b.x,Vector2.Dot(a,b)),length=Mathf.Abs(sweep)*radius;
    parts.Add(new Arc{A=entry,B=exit,Centre=centre,Radius=radius,Angle=Mathf.Atan2(a.y,a.x),Sweep=sweep,Start=total,Length=length});total+=length;last=exit;
   }
   Line(last,path[path.Length-1]);routes.Add(new Route{Parts=parts.ToArray(),Length=total,End=path[path.Length-1]});
  }return routes.ToArray();}
  static Vector2 Position(Route route,float distance){distance=Mathf.Clamp(distance,0,route.Length);foreach(var part in route.Parts)if(distance<=part.Start+part.Length)return part.At(distance-part.Start);return route.End;}
  static Vector4 Sample(Route route,float distance,float strength){var p=Position(route,distance);return new Vector4(p.x,p.y,strength,0);}
  internal static void Evaluate(double seconds,float amount,out Vector4 a,out Vector4 b,out Vector4 c,out Vector4 d){
   double elapsed=Math.Max(0,seconds)%(SlotSeconds*Routes.Length);int index=(int)(elapsed/SlotSeconds);float local=(float)(elapsed-index*SlotSeconds);
   float fade=Mathf.SmoothStep(0,1,local/1.1f)*(1-Mathf.SmoothStep(0,1,(local-9.15f)/.55f))*Mathf.Clamp(amount,0,2);var route=Routes[index];
   const float spacing=10.56f;float distance=route.Length*Mathf.Clamp01(local/8.8f)+spacing*3*Mathf.SmoothStep(0,1,(local-8.8f)/.3f);
   a=Sample(route,distance,fade*.40f);b=Sample(route,distance-spacing,fade*.65f);c=Sample(route,distance-spacing*2,fade*.40f);d=Sample(route,distance-spacing*3,fade*.15f);
  }
  internal static string Validate(){
   for(int pair=0;pair<6;pair+=2)for(int i=0;i<Paths[pair].Length;i++)if((Paths[pair][i]-new Vector2(1024-Paths[pair+1][i].x,Paths[pair+1][i].y)).sqrMagnitude>.00001f)throw new InvalidOperationException("Architectural sides are not mirrored");
   for(int route=0;route<Routes.Length;route++){
    Evaluate(route*SlotSeconds+9.1,1,out var a,out var b,out var c,out var d);if(a.z<.39f||Vector2.Distance(new Vector2(d.x,d.y),Routes[route].End)>.001f)throw new InvalidOperationException("Architectural cap pulse did not gather");
    Evaluate(route*SlotSeconds+9.7,1,out a,out b,out c,out d);if(a.z>.00001f||b.z>.00001f||c.z>.00001f||d.z>.00001f)throw new InvalidOperationException("Architectural route changes before its light is dark");
   }
   return "58px full-detail glass modules; three exactly mirrored pairs and two central paths; "+Pieces.Length+" retained tiles, eight rounded light routes and true cap endpoints; unchanged menu hitboxes and text positions";
  }
 }
}

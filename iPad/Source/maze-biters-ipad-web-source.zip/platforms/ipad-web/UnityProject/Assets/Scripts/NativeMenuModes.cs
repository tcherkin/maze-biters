using System;
using System.Collections.Generic;
using System.Linq;
using UnityEngine;
namespace MazeBiters.NativeStudy {
 public sealed partial class NativeGameplayStudy {
  // Six small original simulation states, ONE map, ONE lighting compositor,
  // ONE set of snake surfaces and at most three player renderers. A mode choice
  // never generates, repaints, uploads or duplicates the first-level maze.
  sealed class MenuModePlan {public NativeGameplayWorld world;public uint random;}
  readonly Dictionary<int,MenuModePlan> menuModes=new Dictionary<int,MenuModePlan>();
  readonly Dictionary<int,Snake> menuSnakePool=new Dictionary<int,Snake>();
  readonly HashSet<int> menuGpuReady=new HashSet<int>();
  public bool MenuModeGpuReady=>menuGpuReady.Contains(menuMode);
  public bool AllMenuModesReady{get;private set;}
  void ClearMenuModes(){AllMenuModesReady=false;menuModes.Clear();menuSnakePool.Clear();menuGpuReady.Clear();}
  IEnumerable<object> PrepareMenuModes(){
   ClearMenuModes();int initial=menuMode;
   menuModes.Add(initial,new MenuModePlan{world=world,random=random});
   menuGpuReady.Add(initial); // PrepareMenuWorld/GAME OVER already warmed this exact roster.
   foreach(var snake in snakes.Values)menuSnakePool.Add(snake.model.Palette,snake);
   NativeAllyValidation.Prepare();yield return "all-mode AI preparation";
   foreach(int mode in NativeMenuState.Modes){
    if(!menuModes.ContainsKey(mode)){
     uint copied=34;
     double CopyRandom(){unchecked{copied+=0x6D2B79F5;uint v=(copied^(copied>>15))*(1|copied);v^=v+(v^(v>>7))*(61|v);return (v^(v>>14))/4294967296.0;}}
     var w=new NativeGameplayWorld(currentGeneratedLevel.geometry,CopyRandom){Difficulty=world.Difficulty,AiDifficulty=difficultyIndex,ScoreSpeed=MenuSpeed};
     w.SetMode(mode);w.StartSession(_=>currentGeneratedLevel);
     menuModes.Add(mode,new MenuModePlan{world=w,random=copied});
    }
    if(NativeBalancedLaunch.Distributed){yield return "mode population";continue;}
    SelectPreparedMenuMode(mode);
    scenePreparationPending=true;PrepareSceneGpu();preparationFrames=0;
    yield return "mode GPU preparation";
   }
   SelectPreparedMenuMode(initial);
   preparationLightFrame=true;Render();foreach(var step in NativePreparation.DrainSteps(target,NativeSmoothLoading.Enabled))yield return step;
   AllMenuModesReady=true;
  }
  public IEnumerable<object> PrepareSelectedMenuMode(int mode){
   if(menuMode!=mode)SelectPreparedMenuMode(mode);
   if(!menuGpuReady.Contains(mode)){
    scenePreparationPending=true;foreach(var step in PrepareSceneGpuSteps(true))yield return step;
    preparationFrames=0;menuGpuReady.Add(mode);
   }
   preparationLightFrame=true;Render();foreach(var step in NativePreparation.DrainSteps(target,NativeSmoothLoading.Enabled))yield return step;
  }
  public void SelectPreparedMenuMode(int mode){
   if(!menuModes.TryGetValue(mode,out var plan))throw new InvalidOperationException("First-level mode is not prepared: "+mode);
   world=plan.world;random=plan.random;world.Random=Random;world.LevelLoader=LoadCampaignLevel;world.Event=OnEvent;
   menuMode=mode;time=realClock=1000;biteInitial=.4;world.ScoreSpeed=MenuSpeed;
   // Mode-specific snake head safety decisions/IDs are kept exactly as generated.
   // Only immutable colour geometry and retained GPU surfaces are shared.
   snakes.Clear();
   foreach(var model in world.Snakes){
    if(!menuSnakePool.TryGetValue(model.Palette,out var visual))throw new InvalidOperationException("Unexpected initial snake palette");
    visual.model=model;visual.motion=new NativeLiveSnake(model,time);visual.eaten=double.PositiveInfinity;visual.eater=null;
    snakes.Add(model.Id,visual);
   }
   foreach(var a in actors.Values){a.renderer.enabled=false;if(a.leader!=null)a.leader.Visible=false;}
   for(int i=0;i<world.PlayerCount;i++){
    var p=world.GetPlayer(i);if(!actors.TryGetValue(p.Id,out var a))a=AddActor(p,true,p.Palette);
    a.art.Palette=new[]{"p1","p2","ai"}[p.Palette];a.turn=new NativeTurnClock(true,Bank(p.Dir));
    a.blink=new BlinkClock((uint)(p.Id*9721),time+900);a.aura.Reset(Bank(p.Dir),time);a.biteInitial=.4;a.renderer.enabled=true;
   }
   hud?.BeginLevel(realClock,true);ResetGameplayCamera();
   preparationLightFrame=true;Render();
  }
  void ReleaseUnusedMenuPlayers(){
   if(!NativeMenu.InstantMenuStart)return;
   foreach(int id in actors.Keys.Where(id=>world.PlayerById(id)==null).ToArray()){actors[id].Dispose();actors.Remove(id);}
  }
 }
}

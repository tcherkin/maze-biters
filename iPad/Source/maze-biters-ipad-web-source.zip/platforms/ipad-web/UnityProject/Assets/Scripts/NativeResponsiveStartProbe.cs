using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using UnityEngine;

namespace MazeBiters.NativeStudy {
 // Opt-in fault injection. It is armed only after the menu has opened, so
 // ordinary play and before-splash shader preparation are unaffected.
 public static class NativeResponsiveStartFaults {
  static readonly string[] Args=Environment.GetCommandLineArgs();
  public static readonly string Mode=Argument("--responsive-fault","none");
  static bool armed,preparationThrown,preparationReleased,errorThrown,stallObserved;static int tokens,steps;
  public static int PreparationInjected{get;private set;}
  public static int ReadbackErrorsInjected{get;private set;}
  public static int ReadbackStallsInjected{get;private set;}
  public static int DelayedReadbacks{get;private set;}
  public static int ReadbackPolls{get;private set;}
  public static double ReadbackDelayMs=>armed&&Mode=="readback-delay"&&tokens==1?125:0;
  public static string Argument(string key,string fallback){int at=Array.IndexOf(Args,key);return at>=0&&at+1<Args.Length?Args[at+1]:fallback;}
  public static bool Flag(string key)=>Array.IndexOf(Args,key)>=0;
  public static void Arm(){
   armed=Flag("--responsive-start-probe");tokens=steps=0;preparationThrown=preparationReleased=errorThrown=stallObserved=false;
   PreparationInjected=ReadbackErrorsInjected=ReadbackStallsInjected=DelayedReadbacks=ReadbackPolls=0;
  }
  public static int BeginReadback(){
   if(!armed)return 0;int token=++tokens;if(token==1&&Mode=="readback-delay")DelayedReadbacks++;return token;
  }
  public static void ReadbackResult(int token,ref bool done,ref bool error){
   if(!armed||token==0)return;ReadbackPolls++;
   if(token!=1)return;
   if(Mode=="readback-stall"){
    if(!stallObserved){stallObserved=true;ReadbackStallsInjected++;}
    // Deliberately never completes. Production timeout/fence recovery must
    // release this ticket; the test itself does not eventually unblock it.
    done=false;error=false;
   }else if(Mode=="readback-error"&&done&&!errorThrown){errorThrown=true;ReadbackErrorsInjected++;error=true;}
  }
  public static void BeforePreparationStep(){
   if(!armed||preparationReleased||Mode!="preparation"&&Mode!="preparation-persistent"||Mode=="preparation"&&preparationThrown)return;
   if(++steps<8)return;preparationThrown=true;PreparationInjected++;
   throw new InvalidOperationException("Injected responsive-start preparation failure");
  }
  public static void ReleasePreparationFault(){preparationReleased=true;}
 }

 public static class NativeResponsiveStartValidation {
  public static int Run(){
   int checks=0;void Check(bool ok,string name){checks++;if(!ok)throw new Exception("Responsive start clock: "+name);}
   foreach(int mode in NativeMenuState.Modes)foreach(double delay in new[]{0,899.9,900,900.1,1199.9,1200,1200.1,1800,5000}){
    var state=new NativeMenuState{WaitForPreparation=true};state.SetFocus(Array.IndexOf(NativeMenuState.Modes,mode),1000);state.Activate(1000);
    state.SignalPrepared(1000+delay,false);Check(!state.StartReady(10000),"unfinished preparation never releases "+mode);
    Check(!state.SetFocus(11,1100)&&state.Activate(1100)==null,"pending choice cannot be replaced "+mode);
    foreach(double elapsed in new[]{150,450,750,1050,1950,4950})Check(Math.Abs(state.Alpha("mode:"+mode,1000+elapsed)-.15)<1e-10,"blink continues while waiting "+mode);
    state.SignalPrepared(1000+delay,true);double finish=state.PendingFinishAt;
    Check((finish>=1900&&finish>=1000+delay&&finish<1000+delay+300.001)||(delay<900&&finish==1900),"bounded full-cycle confirmation "+mode);
    Check(Math.Abs((finish-1000)/300-Math.Round((finish-1000)/300))<1e-10,"whole blink cycles "+mode);
    Check(!state.StartReady(finish-.001)&&state.StartReady(finish)&&state.Alpha("mode:"+mode,finish)==1,"bright final frame "+mode);
    state.SignalPrepared(finish+600,true);Check(state.PendingFinishAt==finish,"ready deadline does not drift "+mode);
    state.SignalPrepared(finish+601,false);Check(!state.StartReady(finish+900),"lost readiness revokes release "+mode);
    state.SignalPrepared(finish+950,true);Check(state.PendingFinishAt>=finish+950,"restored readiness gets a new complete cycle "+mode);
    state.CancelStart();state.SignalPrepared(finish+2000,true);Check(!state.Pending&&!state.StartReady(finish+3000),"cancelled selection cannot release later "+mode);
   }
   return checks;
  }
 }

 public sealed partial class NativeMenu {
  bool responsiveStartTesting;
  int responsiveMenuRenderFrame=-1;double responsiveMenuRenderClock,responsiveMenuRenderAlpha=1,responsiveMenuPendingAt,responsiveMenuFinishAt;
  bool responsiveMenuRenderPending;
  // Called after the real menu/record compositor renders, not by the sampler.
  void ResponsiveMenuRendered(double t){
   if(!responsiveStartTesting)return;
   responsiveMenuRenderFrame=Time.frameCount;responsiveMenuRenderClock=t;responsiveMenuRenderPending=State.Pending&&records==null;
   responsiveMenuPendingAt=State.PendingAt;responsiveMenuFinishAt=State.PendingFinishAt;
   responsiveMenuRenderAlpha=State.Alpha("mode:"+State.SelectedMode,t);
  }
  [Serializable] sealed class ResponsiveFrame {
   public string phase;public int frame,menuRenderFrame,gameplayFrames;public double ms,gapMs,menuClock,renderClock,alpha,pendingAt,finishAt,gameClock,levelAlpha,levelPulse;
   public bool focused,menuVisible,recordsVisible,pending,prepared,launchReady,renderPending,levelWaiting;
  }
  [Serializable] sealed class ResponsiveLaunch {
   public string phase,state,quality;public int mode,players,bank,width,height;public double clickMs,readyAfterMs=-1,plannedBlinkMs,clickToPlayMs;public bool optionsValid;
  }
  [Serializable] sealed class ResponsiveResult {
   public bool passed,focused=true,gameOverReady,functional;public string quality,startingQuality,endingQuality,fault,failure,note;public int mode,numericChecks,preparationRetries,preparedBuilds,recoveredReadbacks,timedOutReadbacks;
   public int preparationFaults,readbackErrors,readbackStalls,readbackDelays,pixelChecks,levelTests,levelWaitSamples,qualitySwitches,restartTests;
   public double menuAvailableMs,maxGapMs,gapBudgetMs;public string[] checks;public ResponsiveLaunch[] launches;public ResponsiveFrame[] frames;
  }
  ResponsiveResult responsiveResult;readonly List<ResponsiveFrame> responsiveFrames=new List<ResponsiveFrame>(16384);
  readonly List<ResponsiveLaunch> responsiveLaunches=new List<ResponsiveLaunch>();readonly List<string> responsiveChecks=new List<string>();
  double responsiveLastFrame,responsiveDeadlineMs;int responsiveMaxPreparationRetries,responsiveRecoveryStart,responsiveTimeoutStart;
  static double ResponsiveNow=>Time.realtimeSinceStartupAsDouble*1000;
  void ResponsiveCheck(bool ok,string message){if(!ok)throw new InvalidOperationException("Responsive start: "+message);responsiveChecks.Add(message);}
  void ResponsiveFrameSample(string phase){
   double now=ResponsiveNow,gap=responsiveLastFrame==0?0:now-responsiveLastFrame;responsiveLastFrame=now;
   var frame=new ResponsiveFrame{phase=phase,frame=Time.frameCount,ms=now,gapMs=gap,focused=Application.isFocused,
    menuVisible=renderer!=null&&!gameplay&&!changing,recordsVisible=records!=null&&renderer!=null&&renderer.RecordsReady&&!gameplay,pending=State.Pending,prepared=PreparedForSelection,launchReady=LaunchReady,
    menuClock=Now,menuRenderFrame=responsiveMenuRenderFrame,renderClock=responsiveMenuRenderClock,alpha=responsiveMenuRenderAlpha,
    renderPending=responsiveMenuRenderPending,pendingAt=responsiveMenuPendingAt,finishAt=double.IsInfinity(responsiveMenuFinishAt)?-1:responsiveMenuFinishAt,
    gameplayFrames=gameplay?gameplay.ResponsiveRenderedFrames:0,gameClock=gameplay?gameplay.ResponsiveGameClock:0,
    levelWaiting=gameplay&&gameplay.ResponsiveLevelWaiting,levelAlpha=gameplay?gameplay.ResponsiveLevelAlpha:0,levelPulse=gameplay?gameplay.ResponsiveLevelPulseElapsed:0};
   responsiveFrames.Add(frame);responsiveResult.focused&=frame.focused;responsiveResult.maxGapMs=Math.Max(responsiveResult.maxGapMs,gap);
   responsiveMaxPreparationRetries=Math.Max(responsiveMaxPreparationRetries,preparationRetries);
  }
  IEnumerable<object> ResponsiveFramesFor(int count,string phase){for(int i=0;i<count;i++){yield return null;ResponsiveFrameSample(phase);}}
  IEnumerable<object> ResponsiveWait(Func<bool> ready,string phase){
   double end=ResponsiveNow+responsiveDeadlineMs;
   while(!ready()){
    if(ResponsiveNow>end)throw new TimeoutException("Responsive start "+phase+": "+preparationError);
    yield return null;ResponsiveFrameSample(phase);
   }
  }
  void ResponsiveSave(bool passed,string failure=""){
   responsiveResult.passed=passed;responsiveResult.failure=failure;responsiveResult.preparationRetries=Math.Max(preparationRetries,responsiveMaxPreparationRetries);responsiveResult.preparedBuilds=preparedBuilds;
   responsiveResult.quality=responsiveResult.endingQuality=State.Quality;
   responsiveResult.preparationFaults=NativeResponsiveStartFaults.PreparationInjected;responsiveResult.readbackErrors=NativeResponsiveStartFaults.ReadbackErrorsInjected;
   responsiveResult.readbackStalls=NativeResponsiveStartFaults.ReadbackStallsInjected;responsiveResult.readbackDelays=NativeResponsiveStartFaults.DelayedReadbacks;
   responsiveResult.recoveredReadbacks=NativeGpuCompletion.RecoveredReadbacks-responsiveRecoveryStart;responsiveResult.timedOutReadbacks=NativeGpuCompletion.TimedOutReadbacks-responsiveTimeoutStart;
   responsiveResult.checks=responsiveChecks.ToArray();responsiveResult.frames=responsiveFrames.ToArray();responsiveResult.launches=responsiveLaunches.ToArray();
   File.WriteAllText(report,JsonUtility.ToJson(responsiveResult,true));if(passed)NativeStartupLoading.Save(report);
  }
  IEnumerator ResponsiveStartProbe(){
   Directory.CreateDirectory(Path.GetDirectoryName(report));responsiveFrames.Clear();responsiveLaunches.Clear();responsiveChecks.Clear();
   responsiveResult=new ResponsiveResult{quality=State.Quality,startingQuality=State.Quality,endingQuality=State.Quality,fault=NativeResponsiveStartFaults.Mode,functional=NativeResponsiveStartFaults.Flag("--responsive-functional"),
    mode=int.Parse(NativeResponsiveStartFaults.Argument("--mode","1")),gapBudgetMs=double.Parse(NativeResponsiveStartFaults.Argument("--responsive-max-gap-ms","100"),System.Globalization.CultureInfo.InvariantCulture),
    note="iPad-project real menu/player-loop probe. No screenshots, pixel readback or report writes inside timing windows. Six modes are selected with --mode in fresh processes. Phases include preparation, confirmation, first play, settings churn, records, GAME OVER and return. startingQuality is the command-line quality; endingQuality and quality record the final selection; every launch records its actual raster. Faults include recoverable/persistent preparation failure, readback error, indefinitely stalled first readback, and delayed polling. --responsive-functional preserves all frame-gap data but makes no foreground or hardware performance claim and does not enforce frame-gap/handoff upper limits."};
   responsiveDeadlineMs=double.Parse(NativeResponsiveStartFaults.Argument("--responsive-timeout-ms","60000"),System.Globalization.CultureInfo.InvariantCulture);
   responsiveRecoveryStart=NativeGpuCompletion.RecoveredReadbacks;responsiveTimeoutStart=NativeGpuCompletion.TimedOutReadbacks;
   NativeResponsiveStartFaults.Arm();var steps=ResponsiveStartSteps().GetEnumerator();
   while(true){
    bool more=false;object next=null;Exception failure=null;
    try{more=steps.MoveNext();if(more)next=steps.Current;}catch(Exception e){failure=e;}
    if(failure!=null){steps.Dispose();ResponsiveSave(false,failure.ToString());Debug.LogException(failure);Application.Quit(2);yield break;}
    if(!more){steps.Dispose();ResponsiveSave(true);Application.Quit();yield break;}
    yield return next;
   }
  }
  IEnumerable<object> ResponsiveClick(int mode,string phase,bool alreadyPending=false){
   ResponsiveCheck(Array.IndexOf(NativeMenuState.Modes,mode)>=0,"valid requested mode "+mode);
   if(!alreadyPending)State.SetFocus(Array.IndexOf(NativeMenuState.Modes,mode),Now);
   var launch=new ResponsiveLaunch{phase=phase,mode=mode,clickMs=alreadyPending?entered*1000+State.PendingAt:ResponsiveNow};responsiveLaunches.Add(launch);int firstFrame=responsiveFrames.Count;
   string preparedState=null;if(!alreadyPending)Choose();ResponsiveCheck(State.Pending&&State.SelectedMode==mode,"choice starts animated confirmation "+phase);
   double deadline=ResponsiveNow+responsiveDeadlineMs;
   while(!gameplay||!gameplay.MenuReady){
    if(LaunchReady&&PreparedForSelection&&launch.readyAfterMs<0){launch.readyAfterMs=ResponsiveNow-launch.clickMs;preparedState=preparedGame.MenuFullState;}
    if(ResponsiveNow>deadline)throw new TimeoutException("Responsive launch "+phase+": "+preparationError);
    yield return null;ResponsiveFrameSample(phase);
   }
   launch.clickToPlayMs=ResponsiveNow-launch.clickMs;launch.plannedBlinkMs=State.PendingFinishAt-State.PendingAt;
   launch.state=gameplay.InstantMenuState;launch.players=gameplay.IpadPlayerCount;launch.bank=gameplay.ResponsiveBankIdentity;launch.optionsValid=gameplay.MenuOptionsValid;
   launch.quality=gameplay.MenuQuality;launch.width=gameplay.MenuTarget.width;launch.height=gameplay.MenuTarget.height;
   ResponsiveCheck(launch.optionsValid&&gameplay.MenuMode==mode&&gameplay.ResponsiveRosterValid,"correct roster and latest settings "+phase);
   ResponsiveCheck(!string.IsNullOrEmpty(launch.state)&&launch.state.Split('|')[3]=="1000","first world captured before simulation advances "+phase);
   if(preparedState!=null)ResponsiveCheck(preparedState==launch.state,"ready world installed without simulation/RNG changes "+phase);
   ResponsiveCheck(!double.IsInfinity(launch.plannedBlinkMs)&&launch.plannedBlinkMs>=900-1e-6&&Math.Abs(launch.plannedBlinkMs/300-Math.Round(launch.plannedBlinkMs/300))<1e-8,"whole original confirmation cycles "+phase);
   ResponsiveCheck(launch.clickToPlayMs>=launch.plannedBlinkMs-1&&(responsiveResult.functional||launch.clickToPlayMs<=launch.plannedBlinkMs+responsiveResult.gapBudgetMs+34),"handoff waits for completed final blink "+phase);
   ResponsiveCheck(confirmationPresentedFrame>=0,"completed bright menu frame precedes gameplay "+phase);
   var blink=responsiveFrames.Skip(firstFrame).Where(f=>f.renderPending&&f.menuRenderFrame==f.frame).ToArray();
   ResponsiveCheck(blink.Length>5&&blink.Min(f=>f.alpha)<.35&&blink.Max(f=>f.alpha)>.85,"real menu compositor continues blinking "+phase);
   double lastBlinkClock=double.NegativeInfinity;
   foreach(var frame in blink){
    if(frame.renderClock<lastBlinkClock)throw new Exception("Rendered menu blink clock moved backwards during "+phase);lastBlinkClock=frame.renderClock;
    double age=frame.renderClock-frame.pendingAt;
    double expected=frame.finishAt>=0&&frame.renderClock>=frame.finishAt?1:.15+.85*(.5+.5*Math.Cos(Math.PI*2*(age%300)/300));
    if(Math.Abs(frame.alpha-expected)>1e-8)throw new Exception("Rendered menu blink clock changed during "+phase);
   }
   ResponsiveCheck(blink.Any(f=>f.menuRenderFrame==confirmationPresentedFrame&&Math.Abs(f.alpha-1)<1e-8),"bright completion was sampled as an actual rendered frame "+phase);
   foreach(var step in ResponsiveFramesFor(240,phase+" first-play"))yield return step;
   ResponsiveCheck(gameplay&&gameplay.ResponsiveRenderedFrames>0,"ordinary gameplay Update renders after handoff "+phase);
  }
  IEnumerable<object> ResponsiveReturn(){
   ReturnToMenu();foreach(var step in ResponsiveWait(()=>!changing&&gameplay==null,"return-to-menu"))yield return step;
   foreach(var step in ResponsiveFramesFor(2,"returned-menu"))yield return step;
  }
  IEnumerable<object> ResponsiveLevelCase(){
   string fault=NativeResponsiveStartFaults.Argument("--responsive-level-fault","none");
   ResponsiveCheck(new[]{"none","retry","terminal"}.Contains(fault),"supported new-level readiness scenario");
   var game=gameplay;int initialLevel=game.ResponsiveLevel,sceneHits=game.ResponsiveLevelSceneHits;game.ResponsiveBeginLevelGate();
   foreach(var step in ResponsiveWait(()=>gameplay&&game.ResponsiveLevelWaiting,"level-clear-to-readiness-gate"))yield return step;
   ResponsiveCheck(game.ResponsiveLevel==initialLevel&&Math.Abs(game.ResponsiveGameClock-game.ResponsiveLevelExpectedHoldTime)<1e-6,"next level waits at original clear deadline");
   string frozen=game.ResponsiveLevelFreezeProof;double startReal=game.ResponsiveRealClock,minAlpha=1,maxAlpha=0,lastPulse=game.ResponsiveLevelPulseElapsed;
   double deadline=ResponsiveNow+responsiveDeadlineMs;
   while(game.ResponsiveLevelPulseElapsed<1744||!game.ResponsivePreparedNextScene){
    if(ResponsiveNow>deadline)throw new TimeoutException("Held level readiness did not progress");
    yield return null;ResponsiveFrameSample("level-clear-held");responsiveResult.levelWaitSamples++;
    ResponsiveCheck(gameplay&&game.ResponsiveLevelWaiting&&game.ResponsiveLevel==initialLevel,"held transition cannot advance the level");
    ResponsiveCheck(game.ResponsiveLevelFreezeProof==frozen,"held transition freezes world, RNG and actor blink clocks");
    ResponsiveCheck(game.ResponsiveLevelPulseElapsed>=lastPulse,"LEVEL CLEARED presentation clock advances monotonically");lastPulse=game.ResponsiveLevelPulseElapsed;
    minAlpha=Math.Min(minAlpha,game.ResponsiveLevelAlpha);maxAlpha=Math.Max(maxAlpha,game.ResponsiveLevelAlpha);
   }
   ResponsiveCheck(game.ResponsiveRealClock>startReal&&minAlpha<.2&&maxAlpha>.8,"LEVEL CLEARED keeps visibly pulsing while gameplay is frozen");
   double releaseTime=game.ResponsiveLevelReleaseTime;
   if(fault=="terminal"){
    game.ResponsiveInjectLevelFailure(true);
    foreach(var step in ResponsiveWait(()=>gameplay==null&&!changing&&preparationError!=null,"level-failure-return"))yield return step;
    ResponsiveCheck(renderer!=null&&preparationError!=null&&!State.Pending,"failed level preparation returns to selectable menu");
    foreach(var step in ResponsiveFramesFor(4,"level-failure-menu"))yield return step;
    foreach(var step in ResponsiveClick(responsiveResult.mode,"level-failure-new-game"))yield return step;
   }else{
    if(fault=="retry"){
     object map=game.ResponsivePreparedNextMap;game.ResponsiveInjectLevelFailure(false);
     foreach(var step in ResponsiveWait(()=>gameplay&&game.ResponsiveLevelRetries==1,"level-scene-retry"))yield return step;
     ResponsiveCheck(ReferenceEquals(map,game.ResponsivePreparedNextMap),"GPU-scene retry retains the completed map");
     ResponsiveCheck(game.ResponsiveLevelFreezeProof==frozen,"retry preserves authoritative world and blink clocks");
    }
    game.ResponsiveReleaseLevelDelay();
    foreach(var step in ResponsiveWait(()=>gameplay&&game.ResponsiveLevel==initialLevel+1,"level-ready-handoff"))yield return step;
    ResponsiveCheck(game.ResponsiveLevelSceneHits==sceneHits+1&&game.ResponsiveRosterValid,"new level installs its prepared scene and original roster");
    ResponsiveCheck(Math.Abs(game.ResponsiveLevelStarted-releaseTime)<1e-6,"new level uses the original crossing time without loading catch-up");
    foreach(var step in ResponsiveFramesFor(180,"new-level-first-play"))yield return step;
   }
   responsiveResult.levelTests++;
  }
  IEnumerable<object> ResponsiveStartSteps(){
   ResponsiveCheck(IpadPresentation.Enabled,"probe runs with iPad presentation");
   ResponsiveCheck(NativeBalancedLaunch.Distributed,"probe uses the responsive confirmation policy");
   ResponsiveCheck(new[]{"none","preparation","preparation-persistent","readback-error","readback-stall","readback-delay"}.Contains(responsiveResult.fault),"supported fault scenario");
   responsiveResult.numericChecks=NativeResponsiveStartValidation.Run();
   // Constructor/before-splash cost is a startup milestone, not an interactive
   // frame gap. Once the first menu frame appears all later gaps are retained.
   while(Time.frameCount<=openedFrame)yield return null;
   responsiveLastFrame=ResponsiveNow;responsiveResult.menuAvailableMs=responsiveLastFrame;ResponsiveFrameSample("first-visible-menu");
   bool recordsTest=NativeResponsiveStartFaults.Flag("--responsive-records");
   if(recordsTest){
    State.SetFocus(6,Now);Choose();ResponsiveCheck(records!=null&&!records.Entry,"record board opens during preparation");
    foreach(var step in ResponsiveWait(()=>renderer!=null&&renderer.RecordsReady,"record-artwork-readiness"))yield return step;
    foreach(var step in ResponsiveFramesFor(2,"record-board-first-render"))yield return step;
    foreach(var step in ResponsiveFramesFor(90,"records-during-preparation"))yield return step;
    ResponsiveCheck(gameplay==null&&!State.Pending,"record board does not accidentally launch a game");CloseRecords();
   }
   if(NativeResponsiveStartFaults.Flag("--responsive-churn")){
    string original=State.Quality;State.SetFocus(8,Now);Choose();State.SetFocus(10,Now);Choose();
    foreach(var step in ResponsiveFramesFor(3,"quality-difficulty-churn"))yield return step;
    foreach(var step in ResponsiveWait(()=>preparedGame&&preparedGame.MenuQuality==State.Quality,"replacement-quality-starts"))yield return step;
    State.SetFocus(10,Now);Choose();State.Difficulty=4;State.Speed=4;State.Music=0;Audio.MusicSetting=0;
    ResponsiveCheck(State.Quality==original,"rapid quality change returns to requested raster");
   }
   int mode=responsiveResult.mode;
   if(NativeResponsiveStartFaults.Flag("--responsive-quality-switch")){
    string original=State.Quality;var originalRenderer=renderer;
    State.SetFocus(Array.IndexOf(NativeMenuState.Modes,mode),Now);State.SetFocus(10,Now);Choose();
    string selected=State.Quality;ResponsiveCheck(selected!=original,"stable quality switch selects the opposite raster");
    foreach(var step in ResponsiveWait(()=>MenuArtworkReady&&PreparedForSelection&&LaunchReady,"stable-quality-publication"))yield return step;
    foreach(var step in ResponsiveFramesFor(2,"published-quality-menu"))yield return step;
    var pixels=NativeDisplay.Frame.Pixels(selected);
    ResponsiveCheck(!ReferenceEquals(originalRenderer,renderer)&&renderer.Manifest.quality==selected,"replacement menu artwork is actually published");
    ResponsiveCheck(State.Quality==selected&&preparedGame.MenuQuality==selected&&preparedGame.PreparedMode==mode&&preparedGame.PreparedRasterValid,"selected mode is prepared with the new quality");
    ResponsiveCheck(renderer.Target.width==pixels.x&&renderer.Target.height==pixels.y&&preparedGame.MenuTarget.width==pixels.x&&preparedGame.MenuTarget.height==pixels.y,"published menu and prepared gameplay use the selected native dimensions");
    ResponsiveCheck(!State.Pending&&gameplay==null,"quality publication does not start gameplay before selection");responsiveResult.qualitySwitches++;
   }
   if(responsiveResult.fault=="preparation-persistent"){
    State.SetFocus(Array.IndexOf(NativeMenuState.Modes,mode),Now);Choose();
    foreach(var step in ResponsiveWait(()=>preparationError!=null,"bounded-preparation-failure"))yield return step;
    ResponsiveCheck(!State.Pending&&gameplay==null&&preparationRetries==2&&NativeResponsiveStartFaults.PreparationInjected>=3,"persistent failure stops after bounded retries with an interactive menu");
    foreach(var step in ResponsiveFramesFor(60,"recoverable-preparation-error"))yield return step;
    ResponsiveCheck(renderer!=null&&responsiveMenuRenderFrame==Time.frameCount,"error state keeps the real menu rendering");
    NativeResponsiveStartFaults.ReleasePreparationFault();State.SetFocus(9,Now);Choose();
    ResponsiveCheck(preparationError==null&&!State.Pending,"settings remain usable and allow a fresh retry after failure");
   }
   if(NativeResponsiveStartFaults.Flag("--responsive-warm")){
    State.SetFocus(Array.IndexOf(NativeMenuState.Modes,mode),Now);
    foreach(var step in ResponsiveWait(()=>PreparedForSelection&&LaunchReady,"warm-ready"))yield return step;
    string clocks=preparedGame.MenuClockProof;
    foreach(var step in ResponsiveFramesFor(4,"frozen-ready-menu"))yield return step;
    ResponsiveCheck(clocks==preparedGame.MenuClockProof,"prepared world, actor blink clocks and RNG remain frozen");
   }
   if(NativeResponsiveStartFaults.Flag("--responsive-cancel")){
    State.SetFocus(Array.IndexOf(NativeMenuState.Modes,mode),Now);Choose();
    foreach(var step in ResponsiveFramesFor(24,"cancel-pending-selection"))yield return step;
    ResponsiveCheck(State.Pending&&gameplay==null,"pending selection is cancellable before release");
    State.CancelStart();confirmationPresentedFrame=-1;
    ResponsiveCheck(!State.Pending&&!State.StartReady(Now+10000),"cancelled preparation cannot release stale gameplay");
    foreach(var step in ResponsiveFramesFor(4,"cancelled-selection-menu"))yield return step;
   }
   foreach(var step in ResponsiveClick(mode,"initial-confirmation"))yield return step;
   if(NativeResponsiveStartFaults.Flag("--responsive-restart")){
    int restartMode=gameplay.MenuMode,bank=gameplay.ResponsiveBankIdentity,builds=preparedBuilds;string restartQuality=gameplay.MenuQuality;
    RestartFromGameplay();ResponsiveFrameSample("manual-restart-request");
    foreach(var step in ResponsiveWait(()=>gameplay==null&&!changing&&State.Pending,"manual-restart-menu-return"))yield return step;
    ResponsiveCheck(renderer!=null&&State.SelectedMode==restartMode,"manual restart returns to the retained menu and selects the same mode");
    foreach(var step in ResponsiveClick(restartMode,"manual-restart-confirmation",true))yield return step;
    ResponsiveCheck(gameplay.MenuMode==restartMode&&gameplay.MenuQuality==restartQuality&&gameplay.ResponsiveBankIdentity==bank&&preparedBuilds==builds,"manual restart preserves mode, quality and resident art banks");
    responsiveResult.restartTests++;
   }
   if(NativeResponsiveStartFaults.Flag("--responsive-level"))foreach(var step in ResponsiveLevelCase())yield return step;
   if(NativeResponsiveStartFaults.Flag("--responsive-lifecycle")||recordsTest){
    int bank=gameplay.ResponsiveBankIdentity,builds=preparedBuilds;if(recordsTest&&mode!=0)gameplay.ResponsiveSetRecordScore();
    gameplay.CoopLastLives();double deadline=ResponsiveNow+responsiveDeadlineMs;
    while(gameplay){
     responsiveResult.gameOverReady|=gameplay.RestartPrepared;
     if(ResponsiveNow>deadline)throw new TimeoutException("Responsive GAME OVER return");
     yield return null;ResponsiveFrameSample("game-over");
    }
    foreach(var step in ResponsiveWait(()=>!changing,"game-over-return"))yield return step;
    if(recordsTest){
     ResponsiveCheck(mode==0?records==null:records!=null&&records.Entry,"correct record entry eligibility after original GAME OVER");
     if(records!=null){foreach(var step in ResponsiveWait(()=>renderer!=null&&renderer.RecordsReady,"record-entry-artwork-readiness"))yield return step;records.SetDraft("START TEST",Now);foreach(var step in ResponsiveFramesFor(90,"record-entry"))yield return step;CloseRecords();}
    }else if(records!=null)CloseRecords();
    foreach(var step in ResponsiveFramesFor(2,"game-over-menu"))yield return step;
    int calls=NativeStartupLoading.StageCalls("map CPU worker"),next=NativeMenuState.Modes[(Array.IndexOf(NativeMenuState.Modes,mode)+1)%6];
    foreach(var step in ResponsiveClick(next,"restart-mode-change"))yield return step;
    ResponsiveCheck(gameplay.ResponsiveBankIdentity==bank&&preparedBuilds==builds,"GAME OVER restart preserves resident art banks");
    if(NativeStartupLoading.Trace&&responsiveResult.gameOverReady)ResponsiveCheck(NativeStartupLoading.StageCalls("map CPU worker")==calls,"mode change reuses already prepared GAME OVER map");
   }
   if(responsiveResult.fault=="preparation")ResponsiveCheck(NativeResponsiveStartFaults.PreparationInjected==1&&responsiveMaxPreparationRetries>0,"injected preparation exception recovered through bounded retry");
   if(responsiveResult.fault=="preparation-persistent")ResponsiveCheck(NativeResponsiveStartFaults.PreparationInjected>=3&&responsiveMaxPreparationRetries==2,"persistent preparation failure recovered after explicit retry");
   if(responsiveResult.fault=="readback-error")ResponsiveCheck(NativeResponsiveStartFaults.ReadbackErrorsInjected==1&&NativeGpuCompletion.RecoveredReadbacks>responsiveRecoveryStart,"injected readback error recovered before release");
   if(responsiveResult.fault=="readback-stall")ResponsiveCheck(NativeResponsiveStartFaults.ReadbackStallsInjected==1&&NativeGpuCompletion.TimedOutReadbacks>responsiveTimeoutStart,"indefinitely stalled readback recovered by production timeout");
   if(responsiveResult.fault=="readback-delay")ResponsiveCheck(NativeResponsiveStartFaults.DelayedReadbacks==1&&NativeResponsiveStartFaults.ReadbackPolls>0,"delayed result polling completed without losing readiness");
   if(NativeResponsiveStartFaults.Flag("--responsive-images"))foreach(var step in ResponsiveReturn())yield return step;
   var worst=responsiveFrames.OrderByDescending(f=>f.gapMs).First();
   if(!responsiveResult.functional)ResponsiveCheck(worst.gapMs<=responsiveResult.gapBudgetMs,"all visible-menu, handoff and gameplay frame gaps within "+responsiveResult.gapBudgetMs+" ms; largest "+worst.gapMs+" in "+worst.phase);
   ResponsiveCheck(!responsiveFrames.Any(f=>f.menuVisible&&!f.recordsVisible&&f.pending&&f.menuRenderFrame<f.frame-1),"pending caption never stops rendering while work continues");
   if(NativeResponsiveStartFaults.Flag("--responsive-images")){
    // Readback and PNG encoding are explicitly outside the measured frames.
    responsiveLastFrame=0;ResponsiveVerifyCaption(mode);renderer.Render(State,Now);ResponsiveMenuRendered(Now);
   }
  }
  void ResponsiveVerifyCaption(int mode){
   var bright=renderer.ResponsiveCaptionPixels(mode,false,false);SaveFrame("responsive-caption-bright",renderer.Target);
   var dim=renderer.ResponsiveCaptionPixels(mode,true,false);SaveFrame("responsive-caption-dim",renderer.Target);
   var final=renderer.ResponsiveCaptionPixels(mode,true,true);SaveFrame("responsive-caption-complete",renderer.Target);
   int changed=0,max=0,finalChanged=0;
   for(int i=0;i<bright.Length;i++){
    int delta=Math.Max(Math.Abs(bright[i].r-dim[i].r),Math.Max(Math.Abs(bright[i].g-dim[i].g),Math.Abs(bright[i].b-dim[i].b)));
    if(delta>8)changed++;max=Math.Max(max,delta);if(!bright[i].Equals(final[i]))finalChanged++;
   }
   ResponsiveCheck(changed>20&&max>32,"actual GPU caption pixels dim during confirmation");
   ResponsiveCheck(finalChanged==0,"completed caption pixels exactly match fully visible caption");responsiveResult.pixelChecks=2;
  }
 }

 public sealed partial class NativeGameplayStudy {
  internal int ResponsiveRenderedFrames=>frames;
  internal double ResponsiveGameClock=>time;
  internal int ResponsiveBankIdentity=>bank==null?0:bank.GetHashCode();
  internal void ResponsiveSetRecordScore(){world.Player.Score=54320;world.Player.ExactScore=54320;}
  internal int ResponsiveLevel=>world.Level;
  internal bool ResponsiveLevelWaiting=>levelGateWaiting;
  internal int ResponsiveLevelRetries=>levelGateRetries;
  internal int ResponsiveLevelSceneHits=>nextSceneHits;
  internal double ResponsiveRealClock=>realClock;
  internal double ResponsiveLevelPulseElapsed=>levelGateExtraTime;
  internal double ResponsiveLevelAlpha=>ResponsiveLevelStatusAlpha??world.StatusAlpha;
  internal double ResponsiveLevelExpectedHoldTime=>world.TransitionAt+NativeGameplayWorld.ClearDuration-.001;
  internal double ResponsiveLevelReleaseTime=>levelGateReleaseTime;
  internal double ResponsiveLevelStarted=>world.LevelStarted;
  internal bool ResponsivePreparedNextScene=>nextScene?.ready==true;
  internal object ResponsivePreparedNextMap=>nextMaze;
  internal string ResponsiveLevelFreezeProof=>MenuFullState+"|worldTime="+world.Time+"|blinks="+string.Join(";",actors.OrderBy(a=>a.Key).Select(a=>a.Key+":"+ScalarClock(a.Value.blink)));
  internal void ResponsiveBeginLevelGate(){levelGateTestNotBefore=double.PositiveInfinity;world.Snakes.Clear();world.CheckLevelComplete();}
  internal void ResponsiveReleaseLevelDelay(){levelGateTestNotBefore=0;}
  internal void ResponsiveInjectLevelFailure(bool terminal){if(terminal){levelGateRetries=2;levelGateTestNotBefore=0;}nextSceneFailed=true;}
  internal bool ResponsiveRosterValid {
   get{
    if(world==null||world.PlayerCount!=(world.Mode==4?3:world.Mode==0||world.Mode==1?1:2))return false;
    for(int i=0;i<world.PlayerCount;i++){
     var player=world.GetPlayer(i);bool ai=world.Mode==0||world.Mode==3&&i==1||world.Mode==4&&i==2;
     if(player.IsAI!=ai||!actors.TryGetValue(player.Id,out var actor)||actor.art.Palette!=(ai?"ai":i==0?"p1":"p2"))return false;
    }
    return true;
   }
  }
 }

 public sealed partial class NativeMenuRenderer {
  internal Color32[] ResponsiveCaptionPixels(int mode,bool pending,bool complete){
   var state=new NativeMenuState{Quality=Manifest.quality,Focus=Array.IndexOf(NativeMenuState.Modes,mode),LastMode=mode,
    Pending=pending,PendingAt=0,WaitForPreparation=true,PendingFinishAt=complete?150:double.PositiveInfinity};
   Render(state,150);var layer=layers["label-"+mode];var frame=MenuFrame;double scale=Target.height/frame.Height;
   int x=Mathf.FloorToInt((float)((frame.Original.x+layer.x*576.0/1024)*scale));
   int y=Mathf.FloorToInt((float)(Target.height-(frame.Original.y+(layer.y+layer.h)*432.0/768)*scale));
   int w=Math.Min(Target.width-x,Mathf.CeilToInt((float)(layer.w*576.0/1024*scale)));
   int h=Math.Min(Target.height-y,Mathf.CeilToInt((float)(layer.h*432.0/768*scale)));
   var previous=RenderTexture.active;var pixels=new Texture2D(w,h,TextureFormat.RGBA32,false);
   try{RenderTexture.active=Target;pixels.ReadPixels(new Rect(x,y,w,h),0,0,false);pixels.Apply();return pixels.GetPixels32();}
   finally{RenderTexture.active=previous;UnityEngine.Object.Destroy(pixels);}
  }
 }
}

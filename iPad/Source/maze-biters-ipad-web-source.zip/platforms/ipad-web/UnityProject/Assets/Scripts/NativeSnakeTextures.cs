using System;using System.Collections.Generic;using System.IO;using UnityEngine;
namespace MazeBiters.NativeStudy {
 // Immutable authored textures are shared, never the mutable meshes or surfaces.
 // A split inherits its parent's palette, so both lit/emission sets are already
 // resident. Last-owner disposal frees the asset; no session-long orphan cache.
 public static partial class NativeSnakeTextures {
  sealed class Entry {public string key;public Texture2D texture;public long bytes;public readonly List<Lease> leases=new List<Lease>();}
  static readonly Dictionary<string,Entry> entries=new Dictionary<string,Entry>();
  public static long ResidentBytes{get;private set;}
  public static int DecodeCount{get;private set;}
  public sealed class Lease:IDisposable {
   Entry entry;
   private Lease(Entry entry){this.entry=entry;entry.leases.Add(this);}
   public Texture2D Texture=>entry?.texture;
   // The first surviving lease owns the accounting, avoiding double-counting
   // shared textures in existing renderer memory reports.
   public long CountedBytes=>entry!=null&&entry.leases[0]==this?entry.bytes:0;
   public void Dispose(){if(entry==null)return;var old=entry;entry=null;old.leases.Remove(this);if(old.leases.Count!=0)return;entries.Remove(old.key);ResidentBytes-=old.bytes;UnityEngine.Object.Destroy(old.texture);}
   public static Lease Acquire(string name,bool premultiply){
    string key=name+(premultiply?":pm":":raw");
    if(!entries.TryGetValue(key,out var entry)){
     var texture=new Texture2D(2,2,TextureFormat.RGBA32,false,false){filterMode=FilterMode.Bilinear,wrapMode=TextureWrapMode.Clamp,name=name};
     try {
      if(!texture.LoadImage(File.ReadAllBytes(Path.Combine(WebFiles.Root,"Reference/"+name+".png"))))throw new IOException("Cannot decode "+name);
      if(premultiply){var pixels=texture.GetPixels32();for(int i=0;i<pixels.Length;i++){var c=pixels[i];c.r=(byte)Math.Round(c.r*c.a/255.0);c.g=(byte)Math.Round(c.g*c.a/255.0);c.b=(byte)Math.Round(c.b*c.a/255.0);pixels[i]=c;}texture.SetPixels32(pixels);}
      texture.Apply(false,true);
     }catch{UnityEngine.Object.Destroy(texture);throw;}
     entry=new Entry{key=key,texture=texture,bytes=(long)texture.width*texture.height*4};entries.Add(key,entry);ResidentBytes+=entry.bytes;DecodeCount++;
    }
    return new Lease(entry);
   }
  }
 }
}

using System;using System.IO;using System.Collections.Generic;using UnityEngine;
namespace MazeBiters.NativeStudy {
 public sealed class NativeMenuValidation:MonoBehaviour {
  public static NativeMenuState StateFor(MenuCase c,string quality){
   int first=Array.IndexOf(NativeMenuState.Keys,string.IsNullOrEmpty(c.previous)?c.focus:c.previous);
   var s=new NativeMenuState{Quality=quality,Difficulty=c.difficulty,Speed=c.speed,Music=c.music,Focus=first,LastMode=c.mode};
   s.Advance(string.IsNullOrEmpty(c.previous)?c.time:c.change);if(!string.IsNullOrEmpty(c.previous))s.SetFocus(Array.IndexOf(NativeMenuState.Keys,c.focus),c.change);
   s.Pending=c.pending;s.PendingAt=c.at;s.Active=c.active;s.ActiveAt=c.at;s.Pulsing=c.pulse;s.PulseAt=c.at;if(c.shots!=null)s.Shots.AddRange(c.shots);return s;
  }
  public static int Numeric(){int checks=0;void Check(bool ok,string message){checks++;if(!ok)throw new Exception("Menu: "+message);}
   foreach(string q in new[]{"hd","4k"}){var spec=JsonUtility.FromJson<MenuManifest>(File.ReadAllText(Path.Combine(WebFiles.Root,"Reference/menu/"+q+".json")));
    foreach(var c in spec.cases){var s=StateFor(c,q);s.Advance(c.time);Check(Math.Abs(s.Alpha(c.pulse??c.active??"",c.time)-c.pulseAlpha)<1e-9,c.name+" pulse");Check(Math.Abs(s.FocusAlpha-c.focusAlpha)<1e-9,c.name+" focus");}}
   var state=new NativeMenuState();Check(state.Move(3,10)&&state.Focus==3,"spatial right");Check(state.Move(1,20)&&state.Focus==4,"spatial down");Check(state.Move(2,30)&&state.Focus==1,"spatial left");Check(state.Move(0,40)&&state.Focus==0,"spatial up");
   state.Advance(500);state.SetFocus(3,500);state.Advance(550);double before=state.OldAlpha;state.SetFocus(0,550);Check(Math.Abs(state.FocusAlpha-before)<1e-12,"interrupted focus remains continuous");state.Advance(750);Check(state.FocusAlpha==1&&state.OldAlpha==0,"focus finishes");
   for(int i=6;i<8;i++){state.SetFocus(i,1000+i*10);Check(state.Activate(1000+i*10)=="SnakeSELECT&Appear@"&&!state.Pending,"unported button does not start another mode");}
   foreach(int setting in new[]{8,9,11}){state.SetFocus(setting,2000+setting);Check(state.Activate(2000+setting)=="Tick","setting tick");}
   for(int i=0;i<100;i++){state.SetFocus(9,3000+i);state.Activate(3000+i);}Check(state.Shots.Count==32,"bounded score salvo");
   state.SetFocus(0,4000);Check(state.Activate(4000)=="SnakeSELECT&Appear@"&&state.Pending,"SOLO confirmation");Check(!state.StartReady(4899.999)&&state.StartReady(4900),"three pulses / 900ms");Check(state.Activate(4100)==null&&!state.SetFocus(11,4100),"pending input locked");
   foreach(double speed in NativeMenuState.ScoreMultipliers)foreach(double difficulty in NativeMazeGenerator.Difficulties){var world=new NativeGameplayWorld(new[]{"###","#.#","###"},()=>.5);world.SessionEnabled=true;world.Difficulty=difficulty;world.ScoreSpeed=speed;world.Award(25);Check(Math.Abs(world.Player.ExactScore-25*speed*difficulty)<1e-10,"fractional score multiplier");Check(world.Player.Score==(int)(Math.Floor((25*speed*difficulty+1e-9)/5)*5),"arcade score rounding");}
   var coop=new NativeMenuState();coop.SetFocus(1,100);Check(coop.Activate(100)=="SnakeSELECT&Appear@"&&coop.Pending&&coop.SelectedMode==5,"CO-OP confirmed");Check(!coop.StartReady(999)&&coop.StartReady(1000),"CO-OP original three pulses");
   foreach(double readyAt in new[]{0,100,899,900,901,1049,1199,1200,1201,9951}){
    var loading=new NativeMenuState{WaitForPreparation=true};loading.Activate(100);
    loading.SignalPrepared(100+readyAt,false);Check(!loading.StartReady(20000),"loading never releases unfinished scene");
    Check(Math.Abs(loading.Alpha("mode:1",1450)-.15)<1e-9,"waiting caption keeps blinking past 900ms");
    loading.SignalPrepared(100+readyAt,true);double finish=100+Math.Max(900,Math.Ceiling(readyAt/300)*300);
    Check(loading.PendingFinishAt==finish&&!loading.StartReady(finish-.001)&&loading.StartReady(finish),"readiness rounds up to complete blink cycle");
    Check(loading.Alpha("mode:1",finish)==1,"last caption frame fully visible");
    loading.SignalPrepared(finish+100,true);Check(loading.PendingFinishAt==finish,"ready deadline never drifts");
   }
   var point=NativeMenu.ToLogical(new Vector3(112,724,0),new Rect(100,100,1024,768),968);Check((point-new Vector2(12,144)).sqrMagnitude<1e-8,"letterboxed pointer mapping");return checks;
  }
  [Serializable] public sealed class CaseResult {public string name;public double meanChannelError,percentPixelsOverEight;public int maxChannelError;}
  [Serializable] public sealed class Result {public bool passed;public string quality,note;public int cases,numericChecks;public long texturesBytes,targetBytes,workingSetBytes,peakWorkingSetBytes;public CaseResult[] images;}
  void Start(){string quality="hd",report=null;var args=Environment.GetCommandLineArgs();for(int i=0;i<args.Length;i++){if(args[i]=="--quality")quality=args[++i];if(args[i]=="--report")report=args[++i];}
   Application.runInBackground=true;QualitySettings.anisotropicFiltering=AnisotropicFiltering.Disable;Directory.CreateDirectory(Path.GetDirectoryName(report));
   var results=new List<CaseResult>();var result=new Result{quality=quality,passed=true,numericChecks=Numeric(),note="Native GPU menu against frozen browser frames. Original assets, timing and settings. Screen blending/Canvas shadow kernels can differ by small channel values; no claim of bit-exact cross-API rendering. Muted functional tests are separate from listening and foreground performance."};
   using(var menu=new NativeMenuRenderer(quality)){
    var actual=new Texture2D(menu.Target.width,menu.Target.height,TextureFormat.RGBA32,false);var expected=new Texture2D(2,2,TextureFormat.RGBA32,false);var old=RenderTexture.active;
    foreach(var c in menu.Manifest.cases){menu.Render(StateFor(c,quality),c.time);RenderTexture.active=menu.Target;actual.ReadPixels(new Rect(0,0,menu.Target.width,menu.Target.height),0,0);actual.Apply();expected.LoadImage(File.ReadAllBytes(Path.Combine(WebFiles.Root,"Reference/menu",c.image)));var a=actual.GetPixels32();var b=expected.GetPixels32();long sum=0;int bad=0,max=0;
     for(int i=0;i<a.Length;i++){int r=Math.Abs(a[i].r-b[i].r),g=Math.Abs(a[i].g-b[i].g),bl=Math.Abs(a[i].b-b[i].b);sum+=r+g+bl;int error=Math.Max(r,Math.Max(g,bl));max=Math.Max(max,error);if(error>8)bad++;}
     var item=new CaseResult{name=c.name,meanChannelError=sum/(a.Length*3.0),maxChannelError=max,percentPixelsOverEight=bad*100.0/a.Length};results.Add(item);result.passed&=item.meanChannelError<.7&&item.percentPixelsOverEight<.25;
     File.WriteAllBytes(Path.Combine(Path.GetDirectoryName(report),quality+"-"+c.name+".png"),actual.EncodeToPNG());
    }
    result.texturesBytes=menu.TextureBytes;result.targetBytes=(long)menu.Target.width*menu.Target.height*4;RenderTexture.active=old;Destroy(actual);Destroy(expected);
   }
   NativeMemory.TryRead(out result.workingSetBytes,out result.peakWorkingSetBytes,out _);result.cases=results.Count;result.images=results.ToArray();File.WriteAllText(report,JsonUtility.ToJson(result,true));Application.Quit(result.passed?0:2);
  }
 }
}

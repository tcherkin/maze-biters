using System;using System.Collections;using System.Collections.Generic;using System.IO;using System.Linq;using UnityEngine;
namespace MazeBiters.NativeStudy {
 public sealed partial class NativeGameplayStudy {
  bool comboProbe;
  [Serializable] sealed class ComboFrame {public double time,delay,strength;public int x;public bool active;}
  [Serializable] sealed class ComboProbeReport {public bool passed;public string quality,note;public int activationSounds,acceptedSounds,renderFrames;public bool firstSnakeUnboosted,secondActivates,thirdContinues,emptyBreaks,noAttackPower,decayFinishes;public ComboFrame[] samples;}
  // Opt-in render/audio smoke fixture. Normal play never creates these snakes.
  IEnumerator ProbeCombo(){
   Reset(9);time=world.Time=realClock=world.RealTime=2000;
   world.SessionEnabled=true;world.LifecycleEnabled=false;
   if(sessionAudio==null){sessionAudio=new GameObject("Combo probe audio").AddComponent<NativeSessionAudio>();sessionAudio.Initialize(true);}
   sessionAudio.ResetBus();var p=world.Player;p.Cell=p.From=p.Previous=new Vector2Int(2,1);p.Dir=p.Next=Vector2Int.right;p.Waiting=false;p.LastMove=time;
   var route=new List<Vector2Int>{p.Cell};var sentinel=new Vector2Int(27,9);
   bool FindRoute(){if(route.Count==29)return true;foreach(var d in new[]{Vector2Int.right,Vector2Int.up,Vector2Int.left,Vector2Int.down}){var next=route[route.Count-1]+d;if(!world.Floor(next)||route.Contains(next)||next==sentinel)continue;route.Add(next);if(FindRoute())return true;route.RemoveAt(route.Count-1);}return false;}
   if(!FindRoute())throw new InvalidOperationException("Combo fixture route unavailable");
   foreach(var range in new[]{new[]{1,5},new[]{6,16},new[]{17,26}}){
    var body=Enumerable.Range(range[0],range[1]-range[0]+1).Reverse().Select(i=>route[i]).ToArray();
    AddSnake(world.AddSnake(body,body[0]-body[1],range[0]%5));
   }
   AddSnake(world.AddSnake(new[]{new Vector2Int(27,9)},Vector2Int.right,4));
   var result=new ComboProbeReport{quality=quality,firstSnakeUnboosted=true,noAttackPower=true};var samples=new List<ComboFrame>();
   string folder=Path.ChangeExtension(report,null);Directory.CreateDirectory(folder);double stoppedAt=0,peak=0;int step=0;
   world.Event=e=>{if(e.Kind=="sound"&&e.Sound=="snakeSTART@")result.activationSounds++;OnEvent(e);};
   for(int frame=0;frame<540;frame++){
    time=world.Time=realClock=world.RealTime=2000+frame*1000.0/60;
    if(step<28&&time-p.LastMove>world.PlayerDelay){
     p.Next=route[step+1]-p.Cell;world.AdvancePlayer();p.LastMove=time;step++;
     if(p.Cell!=route[step])throw new InvalidOperationException("Combo fixture did not advance");
     if(step<=5)result.firstSnakeUnboosted&=!world.ComboActive&&world.ComboStrength==0;
     if(step==6)result.secondActivates=world.ComboActive;
     if(step==17)result.thirdContinues=world.ComboActive&&result.activationSounds==1;
     if(step==27){result.emptyBreaks=!world.ComboActive;stoppedAt=time;}
     samples.Add(new ComboFrame{time=time,x=step,delay=world.PlayerDelay,strength=world.ComboStrength,active=world.ComboActive});
    }
    result.noAttackPower&=!world.Power&&!world.CombatPower&&!world.PlayerProtected(p,time)&&!p.PowerBright;
    peak=Math.Max(peak,world.ComboStrength);Render();result.renderFrames++;
    if(step==10&&!File.Exists(Path.Combine(folder,"combo.png")))Capture(Path.Combine(folder,"combo.png"));
    if(stoppedAt>0&&time-stoppedAt>1600){result.decayFinishes=world.ComboStrength==0&&Math.Abs(world.PlayerDelay-95)<1e-9;Capture(Path.Combine(folder,"after.png"));break;}
    yield return null;
   }
   result.acceptedSounds=sessionAudio.Accepted;
   result.passed=result.firstSnakeUnboosted&&result.secondActivates&&result.thirdContinues&&result.emptyBreaks&&result.noAttackPower&&result.decayFinishes&&result.activationSounds==1&&peak>.9&&result.acceptedSounds>0&&!p.Dead;
   result.samples=samples.ToArray();result.note="Three contiguous stationary snakes in a real passage, normal AdvancePlayer contacts, existing mouth/intake/glow rendering and muted live audio bus. Functional test, not performance benchmark or physical iPad test.";
   File.WriteAllText(report,JsonUtility.ToJson(result,true));Application.Quit(result.passed?0:2);
  }
 }
}

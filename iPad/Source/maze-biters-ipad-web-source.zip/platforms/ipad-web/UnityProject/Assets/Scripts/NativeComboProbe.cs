using System;using System.Collections;using System.Collections.Generic;using System.IO;using System.Linq;using UnityEngine;
namespace MazeBiters.NativeStudy {
 public sealed partial class NativeGameplayStudy {
  bool comboProbe;
  [Serializable] sealed class ComboFrame {public double time,delay,strength,multiplier;public int x;public bool active;}
  [Serializable] sealed class ComboProbeReport {public bool passed;public string quality,note;public int activationSounds,acceptedSounds,renderFrames,hudChecks;public long hudSteadyAllocatedBytes;public bool firstSnakeUnboosted,secondActivates,thirdContinues,fourthContinues,emptyBreaks,noAttackPower,decayFinishes,stackedSpeed;public ComboFrame[] samples;}
  // Opt-in render/audio smoke fixture. Normal play never creates these snakes.
  IEnumerator ProbeCombo(){
   Reset(9);time=world.Time=realClock=world.RealTime=2000;
   world.SessionEnabled=true;world.LifecycleEnabled=false;
   if(sessionAudio==null){sessionAudio=new GameObject("Combo probe audio").AddComponent<NativeSessionAudio>();sessionAudio.Initialize(true);}
   sessionAudio.ResetBus();var p=world.Player;p.Cell=p.From=p.Previous=new Vector2Int(2,1);p.Dir=p.Next=Vector2Int.right;p.Waiting=false;p.LastMove=time;
   world.SetMode(4);p.Waiting=false;
   for(int slot=1;slot<3;slot++){var other=world.GetPlayer(slot);other.Cell=other.From=other.Previous=new Vector2Int(2+slot,1);other.Waiting=true;AddActor(other,true,other.Palette);for(int lineage=0;lineage<slot+1;lineage++)other.Combo.Bite(100+lineage,time);}
   var route=new List<Vector2Int>{p.Cell};var sentinel=new Vector2Int(27,9);
   bool FindRoute(){if(route.Count==29)return true;foreach(var d in new[]{Vector2Int.right,Vector2Int.up,Vector2Int.left,Vector2Int.down}){var next=route[route.Count-1]+d;if(!world.Floor(next)||route.Contains(next)||next==sentinel)continue;route.Add(next);if(FindRoute())return true;route.RemoveAt(route.Count-1);}return false;}
   if(!FindRoute())throw new InvalidOperationException("Combo fixture route unavailable");
   var displayCells=new List<Vector2Int>();for(int y=1;y<world.Height-1&&displayCells.Count<2;y++)for(int x=1;x<world.Width-1&&displayCells.Count<2;x++){var c=new Vector2Int(x,y);if(world.Floor(c)&&!route.Contains(c)&&c!=sentinel)displayCells.Add(c);}
   for(int slot=1;slot<3;slot++){var other=world.GetPlayer(slot);other.Cell=other.From=other.Previous=displayCells[slot-1];}
   foreach(var range in new[]{new[]{1,5},new[]{6,13},new[]{14,20},new[]{21,26}}){
    var body=Enumerable.Range(range[0],range[1]-range[0]+1).Reverse().Select(i=>route[i]).ToArray();
    AddSnake(world.AddSnake(body,body[0]-body[1],range[0]%5));
   }
   AddSnake(world.AddSnake(new[]{new Vector2Int(27,9)},Vector2Int.right,4));
   var result=new ComboProbeReport{quality=quality,firstSnakeUnboosted=true,noAttackPower=true};var samples=new List<ComboFrame>();
   string folder=Path.ChangeExtension(report,null);Directory.CreateDirectory(folder);double stoppedAt=0,peak=0;int step=0;
   int checkedStep=-1;double sweepStart=0;
   void CheckHud(bool ok,string message){result.hudChecks++;if(!ok)throw new InvalidOperationException("Combo HUD fixture: "+message);}
   world.Event=e=>{if(e.Kind=="sound"&&e.Sound=="snakeSTART@")result.activationSounds++;OnEvent(e);};
   for(int frame=0;frame<540;frame++){
    time=world.Time=realClock=world.RealTime=2000+frame*1000.0/60;
    if(step<28&&time-p.LastMove>world.PlayerDelay){
     p.Next=route[step+1]-p.Cell;world.AdvancePlayer();p.LastMove=time;step++;
     if(p.Cell!=route[step])throw new InvalidOperationException("Combo fixture did not advance");
     if(step<=5)result.firstSnakeUnboosted&=!world.ComboActive&&world.ComboStrength==0;
     if(step==6)result.secondActivates=world.ComboActive&&p.Combo.ScoreMultiplier==2;
     if(step==14)result.thirdContinues=world.ComboActive&&p.Combo.ScoreMultiplier==4&&result.activationSounds==2;
     if(step==21)result.fourthContinues=world.ComboActive&&p.Combo.ScoreMultiplier==8&&result.activationSounds==3;
     if(step==27){result.emptyBreaks=!world.ComboActive;stoppedAt=time;}
     samples.Add(new ComboFrame{time=time,x=step,delay=world.PlayerDelay,strength=world.ComboStrength,multiplier=p.Combo.ScoreMultiplier,active=world.ComboActive});
    }
    result.noAttackPower&=!world.Power&&!world.CombatPower&&!world.PlayerProtected(p,time)&&!p.PowerBright;
    peak=Math.Max(peak,world.ComboStrength);Render();result.renderFrames++;
    if(step!=checkedStep){
     checkedStep=step;
     if(step<6)CheckHud(!hud.ComboShown(0),"first snake has no label");
     if(step==6||step==14||step==21){
      string expected=step==6?"COMBO X2":step==14?"COMBO X4":"COMBO X8";
      CheckHud(hud.ComboLabel(0)==expected&&hud.ComboLabel(1)=="COMBO X2"&&hud.ComboLabel(2)=="COMBO X4","three independent labels");
      if(step==6)sweepStart=hud.ComboSweepStartedAt(0);else CheckHud(hud.ComboSweepStartedAt(0)==sweepStart,"upgrade preserves continuous sweep");
      CheckHud(hud.ComboPulseStartedAt(0)==realClock,"upgrade renews pulse");
      CheckHud(hud.ComboRect(0).xMax<hud.ComboRect(1).x&&hud.ComboRect(1).xMax<hud.ComboRect(2).x,"participant labels do not overlap");
      int meshUpdates=hud.MeshUpdates;long bytes=GC.GetAllocatedBytesForCurrentThread();
      for(int i=0;i<100;i++)hud.Render(world,realClock,quality);
      long allocated=GC.GetAllocatedBytesForCurrentThread()-bytes;result.hudSteadyAllocatedBytes+=allocated;
      CheckHud(hud.MeshUpdates==meshUpdates&&allocated==0,"unchanged combo HUD retains geometry without managed allocation");
     }
     if(step==27)CheckHud(!hud.ComboShown(0)&&world.ComboStrength>0,"label ends while speed fades");
    }
    if(step==10&&!File.Exists(Path.Combine(folder,"combo-x2.png")))Capture(Path.Combine(folder,"combo-x2.png"));
    if(step==17&&!File.Exists(Path.Combine(folder,"combo-x4.png")))Capture(Path.Combine(folder,"combo-x4.png"));
    if(step==23&&!File.Exists(Path.Combine(folder,"combo-x8.png")))Capture(Path.Combine(folder,"combo-x8.png"));
    if(stoppedAt>0&&time-stoppedAt>1600){result.decayFinishes=world.ComboStrength==0&&Math.Abs(world.PlayerDelay-95)<1e-9;Capture(Path.Combine(folder,"after.png"));break;}
    yield return null;
   }
   result.acceptedSounds=sessionAudio.Accepted;
   result.passed=result.firstSnakeUnboosted&&result.secondActivates&&result.thirdContinues&&result.fourthContinues&&result.emptyBreaks&&result.noAttackPower&&result.decayFinishes&&result.activationSounds==3&&peak>.9&&result.acceptedSounds>0&&!p.Dead;
   // Hold a prepared fourth-snake state to inspect independently matured speed
   // envelopes. Numeric audit separately exercises real fruit contacts.
   p.Combo.Reset();for(int lineage=1;lineage<=4;lineage++)p.Combo.Bite(200+lineage,time);
   world.Event=OnEvent;world.ActivatePower();time+=1100;world.Time=time;realClock+=1100;world.RealTime=realClock;Render();
   result.stackedSpeed=Math.Abs(world.PlayerDelay-23.75)<1e-9;Capture(Path.Combine(folder,"combo-power.png"));
   result.passed&=result.stackedSpeed;
   result.samples=samples.ToArray();result.note="Four contiguous stationary snakes in a real passage, normal AdvancePlayer contacts, existing mouth/intake/glow rendering and muted live audio bus. Other two HUD rows are explicitly seeded presentation fixtures. Separate final staged power overlap verifies 4x speed. Functional test, not performance benchmark or physical iPad test.";
   File.WriteAllText(report,JsonUtility.ToJson(result,true));Application.Quit(result.passed?0:2);
  }
 }
}

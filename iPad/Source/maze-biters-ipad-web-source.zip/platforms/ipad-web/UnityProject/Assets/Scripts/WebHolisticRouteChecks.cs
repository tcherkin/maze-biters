#if UNITY_EDITOR
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Runtime.InteropServices;
using UnityEngine;
namespace MazeBiters.NativeStudy {
 [Serializable]public sealed class HolisticRouteBench {public string variant;public int round,frames;public double elapsedMs,checksum;}
 [Serializable]public sealed class HolisticRendererReport {
  public bool passed;public string error;
  public string scope="Web-copy CPU-only exact route-source/cell/boundary vectors and inclusive part endpoints. No raster, GPU or physical-device performance claim.";
  public int routeMaps,routeSamples,routeVectorComponents,routeFailures,partSamples,partFailures;
  public List<HolisticRouteBench> routes=new List<HolisticRouteBench>();
 }
 public sealed partial class NativeMazeArtwork {
  [StructLayout(LayoutKind.Explicit)]internal struct HolisticFloatBits {
   [FieldOffset(0)]internal float value;[FieldOffset(0)]internal int bits;
  }
  internal static bool HolisticSame(float a,float b)=>new HolisticFloatBits{value=a}.bits==new HolisticFloatBits{value=b}.bits;
  internal static bool HolisticSame(Vector4 a,Vector4 b)=>HolisticSame(a.x,b.x)&&HolisticSame(a.y,b.y)&&HolisticSame(a.z,b.z)&&HolisticSame(a.w,b.w);
  internal static void HolisticRendererMode(string mode){NativeHolisticTuning.RouteSearch=mode=="search"||mode=="all";NativeHolisticTuning.RouteSelect=mode=="select"||mode=="all";}
  public static HolisticRendererReport ValidateWebHolisticRoutes(){
   bool search=NativeHolisticTuning.RouteSearch,select=NativeHolisticTuning.RouteSelect;var report=new HolisticRendererReport();
   try{
    foreach(int level in new[]{1,25,50,91,100}){var maze=NativeCampaignComposition.Generate((uint)(811+level),level,NativeMazeGenerator.Difficulties[2]);NativeWallLightRoutes.HolisticAudit(maze.geometry,report);report.routeMaps++;}
    var source=NativeCampaignComposition.Generate(902,100,NativeMazeGenerator.Difficulties[2]);NativeWallLightRoutes.HolisticBenchmark(source.geometry,report);report.passed=report.routeFailures==0&&report.partFailures==0&&report.routeMaps==5;
   }catch(Exception error){report.error=error.ToString();report.passed=false;}
   finally{NativeHolisticTuning.RouteSearch=search;NativeHolisticTuning.RouteSelect=select;}
   return report;
  }
 }
 internal sealed partial class NativeWallLightRoutes {
  static float Adjacent(float value,bool greater){if(value==0)return greater?float.Epsilon:-float.Epsilon;var bits=new NativeMazeArtwork.HolisticFloatBits{value=value};bits.bits+=(value>0)==greater?1:-1;return bits.value;}
  void HolisticPartAudit(HolisticRendererReport report){
   foreach(var route in routes){var samples=new List<float>{-1,0,route.Length,route.Length+1,float.NaN};foreach(var part in route.Parts)foreach(float d in new[]{part.Start,part.Start+part.Length}){samples.Add(Adjacent(d,false));samples.Add(d);samples.Add(Adjacent(d,true));}
    foreach(float d in samples){NativeHolisticTuning.RouteSearch=false;var before=route.At(d);NativeHolisticTuning.RouteSearch=true;var after=route.At(d);report.partSamples++;if(!NativeMazeArtwork.HolisticSame(before.x,after.x)||!NativeMazeArtwork.HolisticSame(before.y,after.y))report.partFailures++;}
   }
  }
  static bool Same(Vector4[] a,Vector4[] b,HolisticRendererReport report){bool okay=true;for(int i=0;i<a.Length;i++){report.routeVectorComponents+=4;if(!NativeMazeArtwork.HolisticSame(a[i],b[i])){report.routeFailures++;okay=false;}}return okay;}
  internal static void HolisticAudit(string[] geometry,HolisticRendererReport report){
   var fixture=NativeMazeArtwork.InspectWallLightRoutes(geometry);fixture.HolisticPartAudit(report);
   var times=new List<double>{-1,0,1,11.2,12.5,25,86400};for(int f=0;f<1200;f++)times.Add(f/120.0);
   for(int cycle=0;cycle<4;cycle++)for(int stream=0;stream<32;stream++){int original=stream%16;double offset=(original%4)*12.5/4+((original/4)%2)*12.5/8+(original/8)*12.5/16+(stream/16)*12.5/32,t=cycle*12.5-offset;if(t>=0){times.Add(t-1e-10);times.Add(t);times.Add(t+1e-10);}}
   foreach(string mode in new[]{"search","select","all"}){
    var before=NativeMazeArtwork.InspectWallLightRoutes(geometry);var after=NativeMazeArtwork.InspectWallLightRoutes(geometry);int sample=0;
    foreach(int streams in new[]{32,4,8,16,32,8,4,32})foreach(double t in times){
     bool force=(sample++%37)==0;NativeMazeArtwork.HolisticRendererMode("reference");var a=before.Evaluate(t,force,streams);
     NativeMazeArtwork.HolisticRendererMode(mode);var b=after.Evaluate(t,force,streams);
     report.routeSamples++;Same(a,b,report);Same(before.SourceCells,after.SourceCells,report);Same(before.StreamBounds,after.StreamBounds,report);
    }
   }
   if(report.partFailures!=0||report.routeFailures!=0)throw new InvalidOperationException("Holistic route vectors or inclusive part boundaries changed");
  }
  internal static void HolisticBenchmark(string[] geometry,HolisticRendererReport report){
   foreach(string mode in new[]{"reference","search","select","all"})for(int round=0;round<3;round++){
    NativeMazeArtwork.HolisticRendererMode(mode);var routes=NativeMazeArtwork.InspectWallLightRoutes(geometry);for(int f=0;f<500;f++)routes.Evaluate(f/120.0);
    const int count=10000;double sum=0;var watch=Stopwatch.StartNew();for(int f=0;f<count;f++){var value=routes.Evaluate((f+500)/120.0);sum+=value[f%96].x;}
    report.routes.Add(new HolisticRouteBench{variant=mode,round=round,frames=count,elapsedMs=watch.Elapsed.TotalMilliseconds,checksum=sum});
   }
  }
 }
}

#endif

using System;using System.IO;using UnityEngine;
namespace MazeBiters.NativeStudy {
 [Serializable]class NeonCases{public NeonCase[] cases;}[Serializable]class NeonCase{public NeonPoint[] points;}[Serializable]class NeonPoint{public double x,y,opacity;public int palette;}
 public static class NeonValidation {
  [Serializable]class EyeClocks{public EyeClock[] clocks;}[Serializable]class EyeClock{public uint seed;public EyeSample[] samples;}[Serializable]class EyeSample{public double time,attention,level;public int events;}
  public static int EyeTests(){var fixtures=JsonUtility.FromJson<EyeClocks>(File.ReadAllText(Path.Combine(WebFiles.Root,"Reference/neon-eye-clocks.json")));int count=0;foreach(var f in fixtures.clocks){var clock=new NativeAggressionGlint(f.seed);foreach(var s in f.samples){clock.SetAggression(s.attention,s.time);double level=clock.Sample(s.time);if(Math.Abs(level-s.level)>1e-9||clock.Events!=s.events)throw new Exception("Eye cadence mismatch at "+s.time);count++;}}return count;}
  public static bool Run(string quality,string[] grid,string output){var root=Path.Combine(WebFiles.Root,"Reference");var spec=JsonUtility.FromJson<NeonCases>(File.ReadAllText(Path.Combine(root,"neon-points.json")));long total=0;int worst=0,bad=0,pixels=0;
   using(var field=new NativeLightField(grid)){
    var outerTarget=RenderTexture.active;var actual=new Texture2D(576,400,TextureFormat.RGBA32,false);var atlas=new Texture2D(1152,400*spec.cases.Length,TextureFormat.RGBA32,false);
    var receive=new Material(Shader.Find("MazeBiters/NeonProject"));receive.SetTexture("_Receiver",field.Receiver);receive.SetFloat("_Mode",3);var walls=new RenderTexture(576,400,0,RenderTextureFormat.ARGB32);walls.Create();
    for(int k=0;k<spec.cases.Length;k++){field.Begin();foreach(var p in spec.cases[k].points)field.Point(p.x,p.y,p.palette,p.opacity*.25);field.Render();Graphics.Blit(field.Walls,walls,receive);var reference=File.ReadAllBytes(Path.Combine(root,"neon-field-"+k+".bin"));
     for(int channel=0;channel<2;channel++){var previous=RenderTexture.active;RenderTexture.active=channel==0?field.Floor:walls;actual.ReadPixels(new Rect(0,0,576,400),0,0);actual.Apply();RenderTexture.active=previous;var a=actual.GetPixels32();atlas.SetPixels32(channel*576,(spec.cases.Length-1-k)*400,576,400,a);
      for(int y=0;y<400;y++)for(int x=0;x<576;x++){var v=a[y*576+x];int at=(channel*576*400+(399-y)*576+x)*4;int r=Math.Abs(v.r-reference[at]),g=Math.Abs(v.g-reference[at+1]),bl=Math.Abs(v.b-reference[at+2]),alpha=Math.Abs(v.a-reference[at+3]),e=Math.Max(Math.Max(r,g),Math.Max(bl,alpha));total+=r+g+bl+alpha;worst=Math.Max(worst,e);if(e>2)bad++;pixels++;}
     }
    }
    atlas.Apply();var report=new AnimationCheck{quality=quality,samples=spec.cases.Length*2,pixels=pixels,maxChannelError=worst,meanChannelError=(double)total/(pixels*4),fractionPixelsBeyondTwo=(double)bad/pixels,passed=worst<=2,strictTwoBytePassed=worst<=2,note="Original GPU light fields vs D3D11, all walkable cells, five colours, straight/corner/junction/end-cap blockers; original world resolution independent of HD/4K. Does not certify complete final composition."};File.WriteAllText(output,JsonUtility.ToJson(report,true));File.WriteAllBytes(Path.ChangeExtension(output,".png"),atlas.EncodeToPNG());RenderTexture.active=outerTarget;walls.Release();foreach(var o in new UnityEngine.Object[]{actual,atlas,receive,walls})UnityEngine.Object.Destroy(o);Debug.Log("NEON_PARITY "+JsonUtility.ToJson(report));return report.passed;
   }
  }
 }
}

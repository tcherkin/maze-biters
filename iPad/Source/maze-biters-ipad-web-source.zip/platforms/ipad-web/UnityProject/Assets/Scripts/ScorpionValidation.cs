using System;
using System.IO;
using UnityEngine;
namespace MazeBiters.NativeStudy {
 [Serializable]public class ScorpionOracle {public ScorpionCase[] cases;}
 [Serializable]public class ScorpionCase {public Vector2Int oldHead,oldTail,oldDir,head,tail,dir;public string kind;public ScorpionSample[] samples;public NativeScorpionMotion Motion()=>new NativeScorpionMotion(oldHead,oldTail,oldDir,head,tail,dir,1000,1000);}
 [Serializable]public class ScorpionSample {public double ms,x,y,angle,curvature,frontAngle,rearAngle;public int frame;public ScorpionPoint[] points;}
 [Serializable]public class ScorpionPoint {public double s,x,y,angle,tx,ty;}
 [Serializable]class GhostOracle {public GhostCase[] ghosts;}
 [Serializable]class GhostCase {public int index;public bool tail;public double visualStart,duration,endAt;public GhostSample[] samples;}
 [Serializable]class GhostSample {public double time,x,y,scale;public int frame;}
 public static class ScorpionValidation {
  public static int Run(){var oracle=JsonUtility.FromJson<ScorpionOracle>(File.ReadAllText(Path.Combine(WebFiles.Root,"Reference/scorpion-motion-reference.json")));int checks=0;void Equal(double a,double b){checks++;if(Math.Abs(a-b)>1e-9)throw new Exception("Scorpion trajectory mismatch "+a+" / "+b);}
   foreach(var c in oracle.cases){var motion=c.Motion();if(motion.kind!=c.kind)throw new Exception("Scorpion turn kind");foreach(var s in c.samples){var p=motion.Sample(1000+s.ms);Equal(p.x,s.x);Equal(p.y,s.y);Equal(p.angle,s.angle);Equal(p.curvature,s.curvature);Equal(p.frontAngle,s.frontAngle);Equal(p.rearAngle,s.rearAngle);Equal(p.frame,s.frame);foreach(var point in s.points){var q=p.Sample(point.s);Equal(q.x,point.x);Equal(q.y,point.y);Equal(q.angle,point.angle);Equal(q.tx,point.tx);Equal(q.ty,point.ty);}}}
   var ghosts=JsonUtility.FromJson<GhostOracle>(File.ReadAllText(Path.Combine(WebFiles.Root,"Reference/scorpion-ghost-reference.json")));foreach(var g in ghosts.ghosts){var player=new NativePlayer{Cell=new Vector2Int(5,8),From=new Vector2Int(5,8),Dir=Vector2Int.right};var motion=new NativeScorpionGhost(oracle.cases[g.index].Motion(),player,1070,g.tail);Equal(motion.start,g.visualStart);Equal(motion.duration,g.duration);Equal(motion.end,g.endAt);foreach(var s in g.samples){var p=motion.Sample(s.time);Equal(p.targetX,s.x);Equal(p.targetY,s.y);Equal(p.scale,s.scale);Equal(p.frame,s.frame);}}
   var grid=new[]{"#######","#.....#","#######"};var world=new NativeGameplayWorld(grid,()=>.4);world.Player.Cell=new Vector2Int(1,1);var scorpion=world.PlaceScorpion(new Vector2Int(5,1),Vector2Int.right);world.Time+=218;world.MoveScorpion();if(scorpion.Cell!=new Vector2Int(4,1)||scorpion.Tail!=new Vector2Int(5,1)||scorpion.Motion.kind!="reverse")throw new Exception("Dead end reversal");world.Player.Cell=scorpion.Tail;world.EatScorpion();if(world.Scorpion!=null||world.Player.Score!=150)throw new Exception("Scorpion ownership/score");return checks+2;
  }
 }
}

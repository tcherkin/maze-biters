using System;using System.IO;using UnityEngine;using MazeBiters.NativeStudy;
namespace MazeBiters.NativeStudy {
public static class NativeLevelAtmosphereValidation {
 [Serializable]sealed class Result {public bool passed;public int generatedMazes,minimumRoutes=99999,samples;public double generationMs;public string revision="20261108-sixteen-wall-lights";}
 public static void Run(){
  var result=new Result();var watch=System.Diagnostics.Stopwatch.StartNew();
  void Check(bool ok,string text){if(!ok)throw new InvalidOperationException("Level atmosphere: "+text);result.samples++;}
  Check(NativeLevelAtmosphere.Pulse(0)==1&&Math.Abs(NativeLevelAtmosphere.Pulse(1.5)-.5)<1e-6&&NativeLevelAtmosphere.Pulse(3)==0&&NativeLevelAtmosphere.Pulse(6)==1,"approved 3 + 3 second endpoints");
  double t=1.25;Check(NativeLevelAtmosphere.Advance(t,100,true)==t,"pause freezes visual clock");Check(Math.Abs(NativeLevelAtmosphere.Advance(t,100,false)-1.35)<1e-9,"active real time advances independently of game speed");
  Check(NativeWallLightRoutes.StreamCount==16,"sixteen travelling lights");
  foreach(uint seed in new uint[]{0,34,991})foreach(double difficulty in NativeMazeGenerator.Difficulties)foreach(int level in new[]{1,2,5,10,25,100,130}){
   var generated=new NativeMazeGenerator(seed,difficulty).Generate(level);var routes=NativeMazeArtwork.InspectWallLightRoutes(generated.geometry);result.generatedMazes++;result.minimumRoutes=Math.Min(result.minimumRoutes,routes.Count);
   Check(routes.Count>0,"interior routes in generated maze "+seed+"/"+difficulty+"/"+level);
   for(int sample=0;sample<45;sample++){
    var lights=routes.Evaluate(sample*.37);Check(lights.Length==48&&routes.SourceCells.Length==48&&routes.StreamBounds.Length==16,"three samples and one bound per sixteen streams");
    long evaluations=routes.Evaluations;routes.Evaluate(sample*.37);Check(routes.Evaluations==evaluations,"unchanged route clock cached");
    for(int j=0;j<lights.Length;j++){
     var light=lights[j];var c=routes.SourceCells[j];var b=routes.StreamBounds[j/3];
     Check(c.x==Mathf.Floor(light.x/16)+Mathf.Floor(light.y/16)*36&&c.y==light.w%1024-1&&c.z==Mathf.Floor(light.w/1024)-1,"predecoded topology matches shader");
     Check(light.z==0||(light.x-11.2f>=b.x&&light.y-11.2f>=b.y&&light.x+11.2f<=b.z&&light.y+11.2f<=b.w),"bounds never clip source kernel");
    }
    foreach(var light in lights)Check(!float.IsNaN(light.x)&&!float.IsNaN(light.y)&&light.x>=0&&light.x<576&&light.y>=0&&light.y<400&&light.z>=0&&light.z<=1,"finite bounded light source");
   }
   // Switching counts at the same clock must clear every disabled kernel and
   // leave each original light's path, topology and bounds exactly unchanged.
   foreach(double clock in new[]{.473,3.713,12.501,28.937}){
    var sixteen=(Vector4[])routes.Evaluate(clock).Clone();
    var cells=(Vector4[])routes.SourceCells.Clone();var bounds=(Vector4[])routes.StreamBounds.Clone();
    foreach(int count in new[]{8,4}){
     long previous=routes.Evaluations;var reduced=routes.Evaluate(clock,false,count);
     Check(routes.Evaluations==previous+1,"light-count change invalidates route cache");
     for(int j=0;j<count*3;j++)Check(sixteen[j]==reduced[j]&&cells[j]==routes.SourceCells[j],"original "+count+" source and topology unchanged");
     for(int j=count*3;j<48;j++)Check(reduced[j]==Vector4.zero&&routes.SourceCells[j]==Vector4.zero,"disabled light and topology cleared");
     for(int j=0;j<count;j++)Check(bounds[j]==routes.StreamBounds[j],"original "+count+" kernel bounds unchanged");
     for(int j=count;j<16;j++){var b=routes.StreamBounds[j];Check(b.x>b.z&&b.y>b.w,"disabled kernel bounds reject all fragments");}
     previous=routes.Evaluations;routes.Evaluate(clock,false,count);Check(routes.Evaluations==previous,"reduced-light comparison caches same clock");
     var restored=routes.Evaluate(clock);Check(routes.Evaluations==previous+1,"sixteen-light restore invalidates cache");
     for(int j=0;j<48;j++)Check(restored[j]==sixteen[j]&&routes.SourceCells[j]==cells[j],"sixteen sources and topology restored exactly");
     for(int j=0;j<16;j++)Check(routes.StreamBounds[j]==bounds[j],"sixteen kernel bounds restored exactly");
    }
   }
  }
  result.generationMs=watch.Elapsed.TotalMilliseconds;result.passed=true;
  var directory=Path.GetFullPath(Path.Combine(Application.dataPath,"../../Results/level-atmosphere"));Directory.CreateDirectory(directory);File.WriteAllText(Path.Combine(directory,"logic.json"),JsonUtility.ToJson(result,true));Debug.Log("LEVEL_ATMOSPHERE_AUDIT "+result.generatedMazes+" mazes, "+result.samples+" checks");
 }
}

}

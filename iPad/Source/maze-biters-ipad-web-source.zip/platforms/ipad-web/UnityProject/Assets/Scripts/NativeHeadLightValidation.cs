using System;
namespace MazeBiters.NativeStudy {
 public static class NativeHeadLightValidation {
  // Independent reconstruction of the angle from the two actual sprite banks
  // and their transition weight, rather than the clock's unwrapped angle.
  public static double SpriteAngle(TurnPose pose,double tilt){
   int step=(pose.to-pose.from+4)%4;if(step==3)step=-1;
   return (pose.from+step*pose.mix)*Math.PI/2+tilt*Math.PI/180;
  }
  public static double Error(double a,double b)=>Math.Abs(Math.Atan2(Math.Sin(a-b),Math.Cos(a-b)));
  public static int Run(){
   int checks=0;
   void Check(TurnPose pose,double tilt){
    checks++;if(Error(NativeDusk.HeadAngle(pose,tilt),SpriteAngle(pose,tilt))>1e-10)
     throw new Exception("Head/flashlight sprite angle mismatch");
   }
   foreach(int side in new[]{0,2})for(int from=0;from<4;from++)for(int to=0;to<4;to++){
    var clock=new NativeTurnClock(true,side);clock.Request(from,to,100);
    for(int ms=0;ms<=120;ms++)foreach(double tilt in new[]{-30.0,0,30})Check(clock.Sample(100+ms),tilt);
   }
   foreach(int side in new[]{0,2})foreach(int interval in new[]{1,7,23,45,70,89}){
    var clock=new NativeTurnClock(true,side);int from=side;double time=100;
    foreach(int to in new[]{3,1,3,1,0,2,3,1,2,0,3,1}){
     clock.Request(from,to,time);
     for(int dt=0;dt<=interval;dt++)Check(clock.Sample(time+dt),dt%3*30-30);
     time+=interval;from=to;
    }
   }
   foreach(int dir in new[]{0,1,2,3})Check(new NativeTurnClock(true,dir).Sample(0,dir),0);
   return checks;
  }
 }
}


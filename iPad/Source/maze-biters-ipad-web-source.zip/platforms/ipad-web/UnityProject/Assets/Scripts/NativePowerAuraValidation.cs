#if UNITY_EDITOR
using System;
using UnityEngine;
namespace MazeBiters.NativeStudy {
 public static class NativePowerAuraValidation {
  static bool Near(double a,double b)=>Math.Abs(a-b)<1e-6;
  static bool Equal(Color a,Color b)=>Near(a.r,b.r)&&Near(a.g,b.g)&&Near(a.b,b.b)&&Near(a.a,b.a);
  static NativeGameplayWorld World(){var w=new NativeGameplayWorld(new[]{"#####","#...#","#...#","#...#","#####"},()=>.5){Time=1000,Assist=false};w.SetMode(4);return w;}
  public static int Run(){
   int checks=0;void Check(bool ok,string name){checks++;if(!ok)throw new InvalidOperationException("POWER AURA: "+name);}
   foreach(int palette in new[]{0,1,2}){
    var top=NativePowerAura.Top(palette);var bottom=NativePowerAura.Bottom(palette);
    Check(!Equal(top,bottom),"distinct upper/lower hues for palette "+palette);
    Check(Equal(NativePowerAura.Sample(palette,1),top)&&Equal(NativePowerAura.Sample(palette,0),bottom),"upper/lower sample orientation "+palette);
    Check(Equal(NativePowerAura.Sample(palette,2),top)&&Equal(NativePowerAura.Sample(palette,-1),bottom),"bounded gradient endpoints "+palette);
    foreach(float upper in new[]{0,.25f,.5f,.75f,1}){
     Check(Equal(NativePowerAura.ColorAt(palette,upper,0),Color.white),"default white "+palette+" / "+upper);
     Check(Equal(NativePowerAura.ColorAt(palette,upper,1),NativePowerAura.Sample(palette,upper)),"fully colored plateau "+palette+" / "+upper);
     Check(Equal(NativePowerAura.ColorAt(palette,upper,1,true),Color.white),"death does not retain power tint "+palette+" / "+upper);
    }
    var w=World();var p=w.Player;w.ActivatePower();double start=w.Time;
    foreach(double age in new[]{0.0,250.0,500.0,750.0,1000.0,4000.0,4750.0,5500.0,6250.0,6999.999,7000.0}){
     w.Time=start+age;double expected=age<1000?1-Math.Pow(1-age/1000,2):age<=4000?1:age>=7000?0:1-Math.Pow(1-(7000-age)/3000,2);
     Check(Near(w.PowerStrength,expected)&&Near(NativePowerAura.Blend(w.PowerStrength),expected),"actual fruit clock drives color, age="+age+" / palette="+palette);
     var c=NativePowerAura.ColorAt(palette,.7f,w.PowerStrength);
     Check(float.IsFinite(c.r)&&float.IsFinite(c.g)&&float.IsFinite(c.b)&&c.r>=0&&c.g>=0&&c.b>=0&&c.r<=1&&c.g<=1&&c.b<=1,"finite bounded color on actual clock");
     if(age==0||age==7000)Check(Equal(c,Color.white),"both fruit endpoints are exactly white");
    }
    w.Time=start+5500;var warning=NativePowerAura.ColorAt(palette,.7f,w.PowerStrength);p.PowerBright=false;
    Check(Equal(warning,NativePowerAura.ColorAt(palette,.7f,w.PowerStrength)),"warning sprite flash does not flicker the aura hue");p.PowerBright=true;
    double prior=w.PowerStrength;var priorColor=NativePowerAura.ColorAt(palette,.7f,prior);w.ActivatePower();
    Check(Near(w.PowerStrength,prior)&&Equal(NativePowerAura.ColorAt(palette,.7f,w.PowerStrength),priorColor),"fruit refresh during fade retains exact starting color");
    w.Time+=500;Check(w.PowerStrength>prior&&Near(NativePowerAura.Blend(w.PowerStrength),w.PowerStrength),"refresh smoothly recovers saturation");
    double paused=w.Time,blend=NativePowerAura.Blend(w.PowerStrength);for(int frame=0;frame<20;frame++)w.RealTime+=16.6667;
    Check(w.Time==paused&&Near(NativePowerAura.Blend(w.PowerStrength),blend),"pause holds color envelope");
   }
   {
    var w=World();w.Player.Combo.Bite(1,w.Time);w.Player.Combo.Bite(2,w.Time);w.Time+=1000;
    Check(w.ComboActive&&w.ComboStrength==1&&!w.Power&&NativePowerAura.Blend(w.PowerStrength)==0,"combo-only speed never colors the aura");
    w.Player.ShieldUntil=w.Time+3000;w.Player.ShieldBright=true;
    Check(Equal(NativePowerAura.ColorAt(w.Player.Palette,.5f,w.PowerStrength),Color.white),"spawn shield alone retains the default white aura");
    Check(NativePowerAura.Blend(1,true)==0&&NativePowerAura.Blend(-1)==0&&NativePowerAura.Blend(2)==1&&NativePowerAura.Blend(double.NaN)==0,"blend handles death and bounds safely");
    var expected=new[]{0,1,2};for(int slot=0;slot<3;slot++){var p=w.GetPlayer(slot);Check(p.Palette==expected[slot],"three-participant art mapping "+slot);}
    // Palette ownership remains correct if roles use different art later.
    for(int slot=0;slot<3;slot++){var p=w.GetPlayer(slot);p.Palette=(slot+1)%3;using(w.ForPlayer(p)){w.ActivatePower();w.Time+=1000;Check(Equal(NativePowerAura.ColorAt(p.Palette,1,w.PowerStrength),NativePowerAura.Top((slot+1)%3)),"color follows art palette rather than slot or AI flag "+slot);}}
   }
   return checks;
  }
 }
}
#endif

using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.CompilerServices;
using UnityEngine;

namespace MazeBiters.NativeStudy {
 // Approved campaign composition: keep the original seeded corridor fabric.
 // Change its solid-core composition only by small, validated symmetric link
 // exchanges. A visual core is the renderer's exact 2x2-solid Block predicate.
 public static class CoreCompositionStudy {
  public static readonly string[] Modes={"original","central","side","dispersed","corners","automatic"};
  static readonly string[] Bag={"central","side","dispersed","corners"};
  static readonly ConditionalWeakTable<SessionLevel,CoreCompositionReport> reports=new ConditionalWeakTable<SessionLevel,CoreCompositionReport>();
  public static string ProfileForLevel(uint seed,int level){
   string previous=null;string[] bag=null;int cycleAt=Math.Max(0,level-1)/Bag.Length;
   for(int cycle=0;cycle<=cycleAt;cycle++){
    bag=(string[])Bag.Clone();var rng=NativeMazeGenerator.Rng(seed^unchecked((uint)(cycle+1)*0xD1B54A35u)^0x6C8E9CF5u);
    for(int i=bag.Length-1;i>0;i--){int j=(int)Math.Floor(rng()*(i+1));string item=bag[i];bag[i]=bag[j];bag[j]=item;}
    if(bag[0]==previous){string item=bag[0];bag[0]=bag[1];bag[1]=item;}previous=bag[bag.Length-1];
   }
   return bag[Math.Max(0,level-1)%Bag.Length];
  }
  public static SessionLevel Generate(uint seed,int level,double difficulty,string profile="automatic",string family="automatic"){
   var watch=System.Diagnostics.Stopwatch.StartNew();
   profile=Modes.Contains(profile)?profile:"automatic";string resolved=profile=="automatic"?ProfileForLevel(seed,level):profile;
   if(family==null||family=="automatic")family=HybridMazeStudy.FamilyForLevel(seed,level);
   if(!HybridMazeStudy.Families.Contains(family))throw new ArgumentException("Unknown hybrid family: "+family);
   var generator=new NativeMazeGenerator(seed,difficulty);var result=generator.BuildHybrid(level,family,out var hybrid);
   var report=new CoreCompositionReport{seed=seed,level=level,difficulty=difficulty,requested=profile,actual=resolved,profile=resolved,family=family};
   generator.ComposeCores(result,hybrid,report);
   HybridMazeStudy.RegisterCompositionResult(result,hybrid);watch.Stop();report.generationMilliseconds=watch.Elapsed.TotalMilliseconds;reports.Add(result,report);return result;
  }
  public static CoreCompositionReport Report(SessionLevel level)=>level!=null&&reports.TryGetValue(level,out var report)?report:null;
 }
 [Serializable] public sealed class CoreCompositionReport {
  public uint seed;public int level;public double difficulty;
  public string requested,actual,profile,family,reason,fingerprint;
  public bool accepted,fallback,passed,witnessMeasured,detourRejected;
  public int changedCells,openedCells,closedCells,transactions,candidateTests,attemptedChangedCells;
  public int coreCount,coreArea,centralArea,largestArea,offCentralArea,interiorArea,targetArea;
  public int beforeCoreCount,beforeCoreArea,beforeCentralArea,beforeLargestArea,beforeOffCentralArea,beforeTargetArea;
  public int witnessCount,witnessRetained,baselineDetour,finalDetour;
  public double generationMilliseconds,compositionMilliseconds,centralFraction,beforeCentralFraction;
  public int detourPairs,retainedDetourPairs,criticalDetourPairs,retainedCriticalDetourPairs;
  public double pairedDetourRatio,pairedTailRatio,proposedPairedDetourRatio,proposedPairedTailRatio,proposedMaximumRatio,proposedPairRetention,proposedCriticalRetention;
  public string[] checks;
 }
 public sealed partial class NativeMazeGenerator {
  sealed class CoreArea {
   public int count,area,central,largest,offCentral,interior,target;
   public List<Vector2Int[]> components=new List<Vector2Int[]>();
  }
  sealed class CoreLink {
   public Vector2Int[] cells;public Vector2Int from,to;
   public int rank;public uint tie;public string key;
  }
  sealed class CoreWitness {public Vector2Int first,second;public int distance,direct;}
  sealed class CoreDetourSnapshot {
   public List<CoreWitness> pairs=new List<CoreWitness>();
   public Dictionary<int,int[]> distances=new Dictionary<int,int[]>();
   public int maximum;
  }
  int CoreDegree(Vector2Int p)=>D.Count(d=>At(p+d)=='.');
  Vector2Int[] CoreOrbit(IEnumerable<Vector2Int> cells)=>HybridTransforms(cells).SelectMany(a=>a).Distinct().OrderBy(p=>p.y*W+p.x).ToArray();
  Vector2Int[] CoreAnchors(string profile){
   // Seeded variation chooses positions, never a pre-drawn room. Anchor copies
   // are scored equally; the resulting geometry still follows its own family.
   uint key=HybridHash(Seed+"/"+stage+"/"+profile);int dx=(int)(key%3),dy=(int)((key>>4)%3);
   var a=profile=="side"?P(8+dx,10+dy):profile=="corners"?P(8+dx,6+dy):P(9+dx,7+dy);
   var result=new List<Vector2Int>{a,P(W-1-a.x,a.y),P(a.x,H-1-a.y),Mirror(a.x,a.y)};
   if(profile=="dispersed"){var b=P(12-(int)((key>>8)%3),12);result.Add(b);result.Add(P(W-1-b.x,b.y));}
   return result.Distinct().ToArray();
  }
  CoreArea CoreMeasure(string profile,Vector2Int[] anchors){
   var stats=new CoreArea();var cells=new HashSet<Vector2Int>();
   for(int y=0;y<H-1;y++)for(int x=0;x<W-1;x++)if(At(x,y)=='#'&&At(x+1,y)=='#'&&At(x,y+1)=='#'&&At(x+1,y+1)=='#')cells.Add(P(x,y));
   var unseen=new HashSet<Vector2Int>(cells);
   foreach(var first in cells){
    if(!unseen.Remove(first))continue;var component=new List<Vector2Int>{first};
    for(int i=0;i<component.Count;i++)foreach(var d in D){var next=component[i]+d;if(unseen.Remove(next))component.Add(next);}
    stats.components.Add(component.ToArray());stats.largest=Math.Max(stats.largest,component.Count);
    if(!component.Any(p=>p.x==0||p.x==W-2||p.y==0||p.y==H-2))stats.interior+=component.Count;
   }
   stats.count=stats.components.Count;stats.area=cells.Count;
   foreach(var p in cells){int cx=p.x+1,cy=p.y+1;bool central=cx>=12&&cx<24;if(central)stats.central++;else stats.offCentral++;
    // Target area excludes the outer boundary and the original central seam.
    if(!central&&p.x>0&&p.x<W-2&&p.y>0&&p.y<H-2&&anchors.Any(a=>Math.Abs(cx-a.x)+Math.Abs(cy-a.y)<=5))stats.target++;
   }
   return stats;
  }
  double CoreScore(CoreArea s,string profile){
   if(profile=="dispersed")return s.offCentral*4+s.target*3-s.central*.8+Math.Min(s.count,14)*2-Math.Max(0,s.largest-8)*1.1;
   return s.offCentral*4+s.target*4-s.central*1.1-Math.Max(0,s.largest-18)*.2;
  }
  List<CoreLink> CoreOpenings(Vector2Int[] anchors,int iteration){
   var list=new List<CoreLink>();var seen=new HashSet<string>();
   for(int y=2;y<H-2;y++)for(int x=12;x<24;x++)foreach(var d in new[]{P(1,0),P(0,1)}){
    if(At(x,y)!='#'||At(P(x,y)-d)!='.')continue;var line=new List<Vector2Int>();var cell=P(x,y);
    while(Inside(cell)&&At(cell)=='#'&&line.Count<22){line.Add(cell);cell+=d;}
    if(At(cell)!='.'||line.Count==0||line.Any(p=>p.x<12||p.x>=24))continue;
    var orbit=CoreOrbit(line);if(orbit.Any(p=>Near(p,3)||hybridFixedWalls.Contains(p)))continue;
    string id=string.Join(",",orbit.Select(p=>p.y*W+p.x));if(!seen.Add(id))continue;
    int affected=0;foreach(var p in orbit)for(int yy=-1;yy<=0;yy++)for(int xx=-1;xx<=0;xx++)if(At(p.x+xx,p.y+yy)=='#'&&At(p.x+xx+1,p.y+yy)=='#'&&At(p.x+xx,p.y+yy+1)=='#'&&At(p.x+xx+1,p.y+yy+1)=='#')affected++;
    if(affected==0)continue;
    list.Add(new CoreLink{cells=orbit,from=P(x,y)-d,to=cell,rank=affected*5-orbit.Length,tie=HybridHash(Seed+"/"+stage+"/open/"+iteration+"/"+id),key=id});
   }
   return list.OrderByDescending(a=>a.rank).ThenBy(a=>a.tie).Take(18).ToList();
  }
  List<CoreLink> CoreClosures(Vector2Int[] anchors,int iteration){
   var list=new List<CoreLink>();var seen=new HashSet<string>();
   void Consider(Vector2Int from,Vector2Int to,IEnumerable<Vector2Int> line){
    var orbit=CoreOrbit(line);if(orbit.Length==0||orbit.Length>20||orbit.Any(p=>Near(p,5)||hybridFixedFloor.Contains(p)||hybridFixedWalls.Contains(p)))return;
    if(orbit.Any(p=>p.x>=12&&p.x<24))return;
    string id=string.Join(",",orbit.Select(p=>p.y*W+p.x));if(!seen.Add(id))return;
    if(HybridTransforms(new[]{from,to}).Any(a=>a.Any(orbit.Contains)))return;
    int distance=orbit.Sum(p=>anchors.Min(a=>Math.Abs(p.x-a.x)+Math.Abs(p.y-a.y)));
    list.Add(new CoreLink{cells=orbit,from=from,to=to,rank=180-distance*3-orbit.Length,tie=HybridHash(Seed+"/"+stage+"/close/"+iteration+"/"+id),key=id});
   }
   for(int y=2;y<H-2;y++)for(int x=3;x<W-3;x++){
    var first=P(x,y);if(At(first)!='.'||CoreDegree(first)<3)continue;
    foreach(var axis in new[]{P(1,0),P(0,1)})if(At(first-axis)=='.'&&At(first+axis)=='.')Consider(first-axis,first+axis,new[]{first});
    foreach(var d in D){var line=new List<Vector2Int>();var previous=first;var cell=first+d;
     while(Inside(cell)&&At(cell)=='.'&&CoreDegree(cell)==2&&line.Count<=6){line.Add(cell);var next=D.Select(a=>cell+a).First(a=>a!=previous&&At(a)=='.');previous=cell;cell=next;}
     if(line.Count>0&&line.Count<=6&&cell!=first&&At(cell)=='.'&&CoreDegree(cell)>=3)Consider(first,cell,line);
    }
   }
   return list.OrderByDescending(a=>a.rank).ThenBy(a=>a.tie).Take(30).ToList();
  }
  int[] CoreDistances(Vector2Int from){
   var result=Enumerable.Repeat(-1,W*H).ToArray();var queue=new Vector2Int[W*H];int read=0,count=1;queue[0]=from;result[from.y*W+from.x]=0;
   while(read<count){var at=queue[read++];foreach(var d in D){var next=at+d;if(At(next)!='.')continue;int id=next.y*W+next.x;if(result[id]>=0)continue;result[id]=result[at.y*W+at.x]+1;queue[count++]=next;}}return result;
  }
  CoreDetourSnapshot CoreDetours(){
   var result=new CoreDetourSnapshot();
   // Match the independent graph meter: every playable endpoint, including
   // perimeter corridors and blind ends, aligned spans 2..6 across a wall.
   for(int y=1;y<H-1;y++)for(int x=1;x<W-1;x++){
    var first=P(x,y);if(At(first)!='.')continue;int[] distances=null;
    foreach(var axis in new[]{P(1,0),P(0,1)})for(int span=2;span<=6;span++){
     var second=first+P(axis.x*span,axis.y*span);if(At(second)!='.')continue;
     bool separated=false;for(int step=1;step<span;step++)if(At(first+P(axis.x*step,axis.y*step))!='.')separated=true;if(!separated)continue;
     if(distances==null){distances=CoreDistances(first);result.distances[first.y*W+first.x]=distances;}
     int length=distances[second.y*W+second.x];if(length<0)continue;
     result.pairs.Add(new CoreWitness{first=first,second=second,distance=length,direct=span});result.maximum=Math.Max(result.maximum,length-span);
    }
   }return result;
  }
  List<CoreWitness> CoreWitnesses(CoreDetourSnapshot reference){
   // Spread witnesses across the graph, rather than taking twelve copies of
   // the same separation. The first witness always includes the actual global
   // maximum; the final whole-map gate below checks the complete distribution.
   var selected=new List<CoreWitness>();foreach(var witness in reference.pairs.Where(a=>a.distance-a.direct>=8).OrderByDescending(a=>a.distance-a.direct)){
    if(selected.Any(a=>Math.Abs(a.first.x-witness.first.x)+Math.Abs(a.first.y-witness.first.y)<4))continue;
    selected.Add(witness);if(selected.Count>=12)break;
   }return selected;
  }
  bool CoreFinalDetours(CoreDetourSnapshot baseline,CoreDetourSnapshot final,CoreCompositionReport report){
   var ordered=baseline.pairs.OrderByDescending(a=>a.distance-a.direct).ToArray();int criticalCount=Math.Max(1,(ordered.Length+9)/10);
   int retained=0,criticalRetained=0;double beforeSum=0,afterSum=0,beforeTail=0,afterTail=0;
   for(int i=0;i<ordered.Length;i++){
    var pair=ordered[i];if(At(pair.first)!='.'||At(pair.second)!='.')continue;
    int id=pair.first.y*W+pair.first.x;if(!final.distances.TryGetValue(id,out var distances)){distances=CoreDistances(pair.first);final.distances[id]=distances;}
    int actual=distances[pair.second.y*W+pair.second.x];if(actual<0)continue;
    int before=pair.distance-pair.direct,after=actual-pair.direct;retained++;beforeSum+=before;afterSum+=after;
    if(i<criticalCount){criticalRetained++;beforeTail+=before;afterTail+=after;}
   }
   report.detourPairs=ordered.Length;report.retainedDetourPairs=retained;report.criticalDetourPairs=Math.Min(ordered.Length,criticalCount);report.retainedCriticalDetourPairs=criticalRetained;
   report.proposedPairedDetourRatio=beforeSum>0?afterSum/beforeSum:1;report.proposedPairedTailRatio=beforeTail>0?afterTail/beforeTail:1;
   report.proposedMaximumRatio=baseline.maximum>0?(double)final.maximum/baseline.maximum:1;
   report.proposedPairRetention=ordered.Length>0?(double)retained/ordered.Length:1;
   report.proposedCriticalRetention=report.criticalDetourPairs>0?(double)criticalRetained/report.criticalDetourPairs:1;
   // The whole composition is conservative: a nice arrangement cannot buy its
   // appearance by erasing existing long journeys or their critical endpoints.
   return report.proposedMaximumRatio>=.90&&report.proposedPairedDetourRatio>=.85&&report.proposedPairedTailRatio>=.85&&report.proposedPairRetention>=.80&&report.proposedCriticalRetention>=.80;
  }
  int CoreRetained(List<CoreWitness> witnesses,out int maximum){
   int retained=0;maximum=0;foreach(var witness in witnesses){if(At(witness.first)!='.'||At(witness.second)!='.')continue;int length=CoreDistances(witness.first)[witness.second.y*W+witness.second.x];int gain=length-witness.direct;maximum=Math.Max(maximum,gain);
    // A local redistribution may choose a different route, but it cannot turn
    // the established long journeys into two-step bypasses.
    if(gain>=Math.Min(witness.distance-witness.direct,Math.Max(8,(int)Math.Ceiling((witness.distance-witness.direct)*.65))))retained++;
   }return retained;
  }
  bool CoreValid(IEnumerable<Vector2Int> closed,List<CoreWitness> witnesses,int baselineDetour,out int retained,out int finalDetour){
   retained=finalDetour=0;
   if(closed.SelectMany(p=>D.Select(d=>p+d)).Where(p=>At(p)=='.').Any(p=>CoreDegree(p)<2))return false;
   if(hybridFixedFloor.Any(p=>At(p)!='.')||hybridFixedWalls.Any(p=>At(p)!='#'))return false;
   if(!HybridAccept()||HybridSolidRectangle()>64||HybridDeepWalls()>24||Starts().Any(s=>FindStartChoice(P(s.x,s.y))<0))return false;
   if(hybridFamily=="crystal"&&hybridGrowth>=20&&HybridOrbitablePoints()<4)return false;
   retained=CoreRetained(witnesses,out finalDetour);
   return witnesses.Count==0||retained>=(witnesses.Count*2+2)/3&&finalDetour>=Math.Ceiling(baselineDetour*.90);
  }
  public void ComposeCores(SessionLevel result,HybridMazeReport hybrid,CoreCompositionReport report){
   var watch=System.Diagnostics.Stopwatch.StartNew();var before=Snapshot();var anchors=CoreAnchors(report.profile);var baseline=CoreMeasure(report.profile,anchors);
   report.beforeCoreArea=baseline.area;report.beforeCoreCount=baseline.count;report.beforeCentralArea=baseline.central;report.beforeLargestArea=baseline.largest;report.beforeOffCentralArea=baseline.offCentral;report.beforeTargetArea=baseline.target;report.beforeCentralFraction=baseline.area>0?(double)baseline.central/baseline.area:0;
   report.witnessMeasured=report.profile!="original"&&report.profile!="central";
   var detours=report.witnessMeasured?CoreDetours():new CoreDetourSnapshot();var witnesses=CoreWitnesses(detours);report.witnessCount=witnesses.Count;report.baselineDetour=detours.maximum;
   if(report.profile!="original"&&report.profile!="central"){
    // Six bounded exchanges at most; no restart search and no room template.
    // Early levels retain their strict zero-open-window caps from HybridAccept.
    int budget=stage<=5?40:64;
    for(int run=0;run<6;run++){
     var previous=Snapshot();var previousStats=CoreMeasure(report.profile,anchors);double bestScore=CoreScore(previousStats,report.profile);char[][] best=null;int bestOpened=0,bestClosed=0;
     var openings=CoreOpenings(anchors,run);var closures=CoreClosures(anchors,run);
     // A closure alone is legitimate if it makes a useful side structure;
     // paired openings additionally dissolve the original central strip.
     openings.Add(new CoreLink{cells=new Vector2Int[0],key="no-opening"});
     foreach(var opening in openings){
      foreach(var closing in closures){
       report.candidateTests++;if(report.openedCells+report.closedCells+opening.cells.Length+closing.cells.Length>budget)continue;
       foreach(var p in opening.cells)g[p.y][p.x]='.';foreach(var p in closing.cells)g[p.y][p.x]='#';
       var stats=CoreMeasure(report.profile,anchors);double score=CoreScore(stats,report.profile);
       bool area=stats.area>=Math.Max(8,(int)Math.Ceiling(baseline.area*.60))&&stats.area<=baseline.area+28;
       bool improved=stats.target>previousStats.target||stats.offCentral>previousStats.offCentral;
       if(area&&improved&&score>bestScore+.1&&CoreValid(closing.cells,witnesses,report.baselineDetour,out _,out _)){
        best=Snapshot();bestScore=score;bestOpened=opening.cells.Length;bestClosed=closing.cells.Length;
       }
       g=previous.Select(row=>(char[])row.Clone()).ToArray();
      }
     }
     if(best==null)break;g=best;report.transactions++;report.openedCells+=bestOpened;report.closedCells+=bestClosed;
    }
   }
   report.attemptedChangedCells=0;for(int y=0;y<H;y++)for(int x=0;x<W;x++)if(before[y][x]!=g[y][x])report.attemptedChangedCells++;
   CoreDetourSnapshot finalDetours=detours;
   if(report.witnessMeasured&&report.attemptedChangedCells>0){
    finalDetours=CoreDetours();if(!CoreFinalDetours(detours,finalDetours,report)){
     g=before;report.detourRejected=true;report.openedCells=report.closedCells=report.transactions=0;finalDetours=detours;
    }
   }
   report.pairedDetourRatio=report.detourRejected?1:report.proposedPairedDetourRatio;report.pairedTailRatio=report.detourRejected?1:report.proposedPairedTailRatio;
   if(!report.witnessMeasured||report.attemptedChangedCells==0){report.pairedDetourRatio=report.pairedTailRatio=1;}
   var final=CoreMeasure(report.profile,anchors);report.changedCells=report.detourRejected?0:report.attemptedChangedCells;
   report.accepted=report.changedCells>0;report.fallback=!report.accepted&&report.profile!="original"&&report.profile!="central";
   report.actual=report.fallback?"original":report.profile;report.reason=report.detourRejected?"Original retained: proposed composition failed full-board paired long-detour distribution gate":report.fallback?"No bounded symmetric exchange satisfied all geometry and detour gates":"Original campaign fabric retained; complete local symmetry orbits only";
   report.coreArea=final.area;report.coreCount=final.count;report.centralArea=final.central;report.largestArea=final.largest;report.offCentralArea=final.offCentral;report.interiorArea=final.interior;report.targetArea=final.target;report.centralFraction=final.area>0?(double)final.central/final.area:0;
   report.witnessRetained=CoreRetained(witnesses,out _);report.finalDetour=finalDetours.maximum;
   report.passed=HybridAccept()&&hybridFixedFloor.All(p=>At(p)=='.')&&hybridFixedWalls.All(p=>At(p)=='#')&&Starts().All(s=>FindStartChoice(P(s.x,s.y))>=0);
   if(report.changedCells>0){
    result.geometry=g.Select(row=>new string(row)).ToArray();hybrid.floorCells=result.geometry.Sum(row=>row.Count(c=>c=='.'));hybrid.openTwoByTwo=HybridRooms(2);hybrid.openThreeByThree=HybridRooms(3);hybrid.maxSolidRectangle=HybridSolidRectangle();hybrid.deepWallCells=HybridDeepWalls();hybrid.deadEnds=HybridDeadEnds();hybrid.pointCells=HybridOrbitablePoints();hybrid.infillOpenings+=report.openedCells;
    hybrid.source="Original campaign fabric with bounded "+report.profile+" core-composition link exchanges";
   }
   report.fingerprint=HybridHash(string.Join("\n",result.geometry)).ToString("x8");report.checks=new[]{"Exact original family symmetry","Connected floor and original narrow early-level caps","All three native starts retain useful escape choice within six steps","Protected diagonal corridors retain separate external return paths",report.witnessMeasured?"Full-board aligned spans2..6: final maximum >=90%; same retained endpoints mean/tail >=85%; >=80% of critical pairs retained":"Unchanged control: long-detour geometry is bit-identical to original", "Core areas measured with renderer's exact 2x2-solid Block predicate"};
   watch.Stop();report.compositionMilliseconds=watch.Elapsed.TotalMilliseconds;
  }
 }
}

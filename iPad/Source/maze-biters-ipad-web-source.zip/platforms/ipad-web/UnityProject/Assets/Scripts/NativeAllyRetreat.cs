using System;using System.Collections.Generic;using System.Linq;using UnityEngine;
namespace MazeBiters.NativeStudy {
 public sealed partial class NativeAllyBrain {
  bool RetreatSafe(NativePlayer p,Vector2Int c,double t,AllyRetreat state=null){
   if(!w.Floor(c)||w.SolidEgg(c)||!SafeRoute(p,c,t))return false;
   if(state!=null&&state.avoid.TryGetValue(c,out var until)&&until>t)return false;
   if(w.Occupied(c)||w.HunterAt(c))return false;
   if(!Combat(p,t)&&(w.Snakes.Any(s=>s.Head+s.Dir==c)||w.Hunters.Any(h=>h.Cell+h.Dir==c)))return false;return true;
  }
  sealed class RetreatNode {public Vector2Int cell;public Vector2Int? dir;public int turns,steps,distance;public bool dead;}
  Vector2Int? RetreatWaypoint(NativePlayer p,AllyRetreat state,double t){
   foreach(var c in state.avoid.Keys.ToArray())if(state.avoid[c]<=t)state.avoid.Remove(c);
   var visited=new HashSet<Vector2Int>{p.Cell};var q=new List<RetreatNode>{new RetreatNode{cell=p.Cell}};RetreatNode best=null;
   bool Better(RetreatNode c,RetreatNode b){if(b==null)return true;int min=Math.Max(4,state.turnGoal+1);bool cm=c.turns>=state.turnGoal&&c.steps>=min,bm=b.turns>=state.turnGoal&&b.steps>=min;
    if(cm!=bm)return cm;if(cm)return c.steps!=b.steps?c.steps<b.steps:c.distance>b.distance;
    if(c.turns!=b.turns)return c.turns>b.turns;if(c.dead!=b.dead)return c.dead;if(c.steps!=b.steps)return c.steps>b.steps;return c.distance>b.distance;}
   for(int i=0;i<q.Count;i++){var n=q[i];if(n.steps>0){n.dead=dirs.Count(d=>RetreatSafe(p,n.cell+d,t,state))<=1;n.distance=state.blocked.HasValue?Man(n.cell,state.blocked.Value):n.steps;if(Better(n,best))best=n;}
    foreach(var d in dirs){var c=n.cell+d;if(!RetreatSafe(p,c,t,state)||!visited.Add(c))continue;q.Add(new RetreatNode{cell=c,dir=d,turns=n.turns+(n.dir.HasValue&&n.dir!=d?1:0),steps=n.steps+1});}}
   return best==null?null:(Vector2Int?)best.cell;
  }
  bool BeginRetreat(NativePlayer p,AllyObjective o,Vector2Int? blocked,double t,string reason){
   var a=S(p);var state=new AllyRetreat{snake=o?.snake??a.locked,kind=o?.kind??o?.type??"route",originalTarget=o==null?null:(Vector2Int?)o.target,blocked=blocked,reason=reason,turnGoal=!w.UseLegacyAi&&w.AiDifficulty>=4?3:3+(int)(w.Random()*3),started=t,observed=p.Cell};
   state.visited.Add(p.Cell);if(blocked.HasValue)state.avoid[blocked.Value]=t+9000;state.waypoint=RetreatWaypoint(p,state,t);if(!state.waypoint.HasValue)return false;a.retreat=state;a.recent.Clear();a.detourUntil=0;return true;
  }
  sealed class Step {public Vector2Int d,c;public double collision,danger,distance,score,threat;public bool safe,cul,reverse,forward,unreachable,lethal;public double reversePenalty,revisit,straight;public int exits,visits;public double tie;}
  bool FollowRetreat(NativePlayer p,double t,List<Vector2Int> options){
   var state=S(p).retreat;if(state==null)return false;if(state.snake!=null&&!w.Snakes.Contains(state.snake)){ClearRetreat(p);return false;}
   if(p.Cell!=state.observed){state.steps++;if(state.lastDir.HasValue&&state.lastDir!=p.Dir)state.turns++;state.lastDir=p.Dir;state.observed=p.Cell;state.visited.Add(p.Cell);}
   if(state.steps>0&&p.Cell==state.waypoint||t-state.started>22000){ClearRetreat(p);return false;}
   bool Rebuild(Vector2Int? c){if(c.HasValue)state.avoid[c.Value]=t+6500;state.waypoint=RetreatWaypoint(p,state,t);return state.waypoint.HasValue;}
   if(!state.waypoint.HasValue||!RetreatSafe(p,state.waypoint.Value,t,state))if(!Rebuild(state.waypoint)){ClearRetreat(p);return false;}
   short[] Make()=>BuildField(state.waypoint.Value,(c,g)=>c==g||c==p.Cell||RetreatSafe(p,c,t,state));
   var field=Make();bool route=field[w.Index(p.Cell)]>=0;if(!route&&Rebuild(state.waypoint)){field=Make();route=field[w.Index(p.Cell)]>=0;}
   var measured=options.Select(d=>new Step{d=d,c=p.Cell+d,collision=Collision(p,d,p.Cell+d,t),danger=Danger(p,d,p.Cell+d,t),distance=route?field[w.Index(p.Cell+d)]:-1,safe=RetreatSafe(p,p.Cell+d,t,state)}).ToList();
   var safe=measured.Where(s=>s.safe&&s.collision<100000&&s.danger<105).ToList();var candidates=safe.Where(s=>s.distance>=0).ToList();
   if(safe.Count>0&&candidates.Count==0&&Rebuild(state.waypoint)){field=Make();foreach(var s in safe)s.distance=field[w.Index(s.c)];candidates=safe.Where(s=>s.distance>=0).ToList();}
   if(candidates.Count==0)candidates=safe.Count>0?safe:measured;
   var choice=candidates.OrderBy(s=>(s.collision>=100000?100000000:0)+(s.distance<0?400000:0)+(s.distance<0?0:s.distance*10000)+s.danger*60+s.collision+(state.visited.Contains(s.c)?3500:0)+(state.lastDir.HasValue&&s.d==-state.lastDir.Value?2200:0)).FirstOrDefault();
   if(choice==null)return false;Choose(p,choice.d,t);Thought(p,"blocked-retreat",state.waypoint??Vector2Int.zero,choice.danger,choice.distance);return true;
  }
 }
}


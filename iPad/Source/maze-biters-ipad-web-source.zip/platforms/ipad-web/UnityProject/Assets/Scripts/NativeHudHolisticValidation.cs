#if UNITY_EDITOR
using System;
using UnityEngine;
namespace MazeBiters.NativeStudy {
 public sealed partial class NativeHud {
  [Serializable] sealed class StateRow {public bool visible;public string texture;public Vector3[] vertices;public Vector2[] uv;public int[] triangles;public float opacity,contact,beamOn,beamX;}
  [Serializable] sealed class State {public StateRow[] rows,combos;}
  static StateRow Snapshot(Row row)=>new StateRow{visible=row.go.activeSelf,texture=row.material.mainTexture?row.material.mainTexture.name:"",vertices=row.mesh.vertices,uv=row.mesh.uv,triangles=row.mesh.triangles,opacity=row.material.GetFloat("_Opacity"),contact=row.material.GetFloat("_OcclusionOpacity"),beamOn=row.material.GetFloat("_BeamOn"),beamX=row.material.GetFloat("_BeamX")};
  // Reads actual retained meshes and material values, independently of caches.
  // This editor-only allocation is never part of a measured or player frame.
  public string HolisticState(){var state=new State{rows=new StateRow[rows.Length],combos=new StateRow[comboRows.Length]};for(int i=0;i<rows.Length;i++)state.rows[i]=Snapshot(rows[i]);for(int i=0;i<comboRows.Length;i++)state.combos[i]=Snapshot(comboRows[i]);return JsonUtility.ToJson(state);}
  public void HolisticContacts(NativeFrame frame,double time,bool touching){BeginContacts(frame,288,200,1);if(touching)Obstacle(0,-2,200,32);EndContacts(time);}
  public void HolisticDispose(){
   void Drop(UnityEngine.Object value){if(value)UnityEngine.Object.DestroyImmediate(value);}
   foreach(var row in rows){Drop(row.go);Drop(row.mesh);Drop(row.material);}foreach(var row in comboRows){Drop(row.go);Drop(row.mesh);Drop(row.material);}
   Drop(root);Drop(starMesh);Drop(backgroundPaint);Drop(skyPaint);Drop(aiFont);Drop(font);Drop(stars);Drop(beam);
  }
 }
}
#endif

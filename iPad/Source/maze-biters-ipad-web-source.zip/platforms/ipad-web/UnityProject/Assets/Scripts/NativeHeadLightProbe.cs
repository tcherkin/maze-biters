using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using UnityEngine;
namespace MazeBiters.NativeStudy {
 public sealed partial class NativeGameplayStudy {
  bool headLightProbe;
  [Serializable] sealed class HeadLightResult {
   public bool passed=true;public string quality,note;public int numericChecks,frames,checks,maskCases,maxMaskError;
   public string[] failures;
  }
  IEnumerator ProbeHeadLight(){
   var result=new HeadLightResult{quality=quality,numericChecks=NativeHeadLightValidation.Run()};
   var failures=new List<string>();
   void Check(bool ok,string label){result.checks++;if(!ok){result.passed=false;failures.Add(label);}}
   Reset(9);yield return DrainProbePreparation();
   var p=world.Player;var actor=actors[1];p.Cell=p.From=p.Previous=new Vector2Int(18,12);p.Tilt=0;
   var pivot=((GameObject)ClockField(dusk,"beamPivot")).transform;
   void Draw(string label){
    cameraFrame=-1;Render();result.frames++;
    var pose=actor.turn.Sample(time,Bank(p.Dir));
    double expected=NativeHeadLightValidation.SpriteAngle(pose,p.Tilt);
    Check(NativeHeadLightValidation.Error(dusk.Angle,expected)<1e-10,label+" exact shared angle");
    var direction=pivot.right;double rendered=Math.Atan2(-direction.y,direction.x);
    Check(NativeHeadLightValidation.Error(rendered,expected)<1e-5,label+" GPU beam orientation");
    var pos=p.Visual(time);var center=new Vector3((pos.x+.5f)*16,-(pos.y+.5f)*16,0);
    Check(Vector3.Distance(pivot.position,center)<1e-5,label+" moving origin");
   }
   for(int palette=0;palette<3;palette++){
    p.Palette=palette;actor.art.Palette=new[]{"p1","p2","ai"}[palette];
    for(int from=0;from<4;from++)for(int to=0;to<4;to++){
     if(from==to)continue;actor.turn=new NativeTurnClock(true,from);p.Dir=NativeLevelStudy.Directions[to];actor.turn.Request(from,to,2000);
     foreach(int ms in new[]{0,15,30,45,60,75,90}){
      time=2000+ms;Draw(palette+":"+from+"->"+to+" @"+ms);
      if(palette==0&&from==0&&to==1&&ms==45)Capture(Path.ChangeExtension(report,null)+"-diagonal.png");
      yield return null;
     }
    }
   }
   foreach(int side in new[]{0,2}){
    actor.turn=new NativeTurnClock(true,side);actor.turn.Request(side,3,3000);int from=3;
    for(int turn=0;turn<8;turn++){
     int to=from==3?1:3;double at=4000+turn*27;actor.turn.Request(from,to,at);p.Dir=NativeLevelStudy.Directions[to];
     for(int ms=0;ms<=27;ms+=9){time=at+ms;Draw("rapid vertical / side "+side);yield return null;}
     from=to;
    }
   }
   // Include the sprite's outer tilt and interpolated position, then hold the
   // exact same pose across a pause with real frames still passing.
   actor.turn=new NativeTurnClock(true);actor.turn.Request(0,1,5000);p.Dir=Vector2Int.down;
   p.From=new Vector2Int(18,11);p.Cell=new Vector2Int(18,12);p.MoveStarted=5000;p.MoveDuration=95;
   foreach(double tilt in new[]{-30.0,-12,0,12,30}){time=5045;p.Tilt=tilt;Draw("tilt "+tilt);yield return null;}
   paused=true;double frozen=dusk.Angle;
   for(int i=0;i<5;i++){Draw("paused");Check(dusk.Angle==frozen,"paused angle unchanged");yield return null;}
   paused=false;p.Tilt=0;p.From=p.Cell;

   // Pixel-level gate: same original light textures/compositing at diagonals,
   // including boosted power and death. Only the input angle is new.
   var oldTarget=RenderTexture.active;var pixels=new Texture2D(576,400,TextureFormat.RGBA32,false);
   Color32[] ReadMask(){RenderTexture.active=dusk.mask;pixels.ReadPixels(new Rect(0,0,576,400),0,0);pixels.Apply();return pixels.GetPixels32();}
   try{
    foreach(double a in new[]{0.0,.25,.5,1.5,2.5,3.75})foreach(int state in new[]{0,1,2}){
     var pose=new TurnPose{angle=a};double power=state==1?1:0,life=state==2?.4:1;bool dead=state==2;
     dusk.RenderHeadPose(p.Visual(time),pose,12,power,dead,life);var actual=ReadMask();
     double radians=a*Math.PI/2+12*Math.PI/180;
     dusk.Render(p.Visual(time),new Vector2((float)Math.Cos(radians),(float)Math.Sin(radians)),0,false,true,power,dead,life);var expected=ReadMask();
     int max=0;for(int i=0;i<actual.Length;i++)max=Math.Max(max,Math.Max(Math.Max(Math.Abs(actual[i].r-expected[i].r),Math.Abs(actual[i].g-expected[i].g)),Math.Max(Math.Abs(actual[i].b-expected[i].b),Math.Abs(actual[i].a-expected[i].a))));
     result.maskCases++;result.maxMaskError=Math.Max(result.maxMaskError,max);Check(max<=1,"unchanged light mask "+a+" / "+state);
    }
   }finally{RenderTexture.active=oldTarget;Destroy(pixels);}
   Draw("restore live pose after reference masks");
   string clocks=SceneClockState();scenePreparationPending=true;PrepareSceneGpu();
   Check(SceneClockState()==clocks,"hidden GPU preparation preserves head and light clocks");Draw("after GPU preparation");
   string originalQuality=quality;quality=quality=="hd"?"4k":"hd";SetQuality();yield return DrainProbePreparation();Draw("quality switch");
   quality=originalQuality;SetQuality();yield return DrainProbePreparation();Draw("quality return");
   result.failures=failures.ToArray();result.note="Live gameplay renderer: all three player palettes, all turns, rapid reversals, outer tilt, moving origin, pause, prewarm and quality switches. Original GPU light-mask parity includes diagonal, power and death states. Functional tests, not performance measurements.";
   Directory.CreateDirectory(Path.GetDirectoryName(report));File.WriteAllText(report,JsonUtility.ToJson(result,true));Application.Quit(result.passed?0:2);
  }
 }
}


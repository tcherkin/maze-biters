using System;
using UnityEngine;
namespace MazeBiters.NativeStudy {
 // Exact-work reuse only. No changes to AI choices, samples, effect quality or clocks.
 public static class IpadPopulationOptimization {
  static readonly string[] args=Environment.GetCommandLineArgs();
  public static bool Enabled=Array.IndexOf(args,"--population-reference")<0;
  public static long GeometryCalls,GeometryHits;
 }
 public sealed partial class NativeSnake {
  readonly Vector3[] populationBodyVertices=new Vector3[4],populationHeadVertices=new Vector3[4];
  readonly Vector2[] populationBodyUV=new Vector2[4],populationHeadUV=new Vector2[4];
  SnakePose populationLastPose;bool populationPoseValid;double populationLastProgress;bool populationLastTail;
  bool ReusePopulationGeometry(SnakePose p,bool tailOnly){
   IpadPopulationOptimization.GeometryCalls++;
   var a=populationLastPose;
   bool same=populationPoseValid&&a!=null&&populationLastTail==tailOnly&&ReferenceEquals(a.rail,p.rail)&&populationLastProgress==p.rail.Progress&&
    a.head==p.head&&a.length==p.length&&a.compression==p.compression&&a.phase==p.phase&&a.frontMaterial==p.frontMaterial&&a.materialSign==p.materialSign&&a.soloAmount==p.soloAmount&&a.transitionOffset==p.transitionOffset&&a.solo==p.solo&&Nullable.Equals(a.rigidRear,p.rigidRear)&&
    a.paintScale==p.paintScale&&a.paintAngle==p.paintAngle&&a.paintX==p.paintX&&a.paintY==p.paintY&&a.paintPivotX==p.paintPivotX&&a.paintPivotY==p.paintPivotY&&a.mouthOverride==p.mouthOverride&&a.birthProgress==p.birthProgress&&a.bendDx==p.bendDx&&a.bendDy==p.bendDy&&a.bendSpan==p.bendSpan&&a.rearBirth==p.rearBirth&&a.consumed==p.consumed;
   // Snapshot scalar values as some diagnostic/presentation callers reuse a
   // mutable pose. The curve identity and its progress are separate keys.
   if(a==null)a=populationLastPose=new SnakePose();
   a.rail=p.rail;a.head=p.head;a.length=p.length;a.compression=p.compression;a.phase=p.phase;a.frontMaterial=p.frontMaterial;a.materialSign=p.materialSign;a.soloAmount=p.soloAmount;a.transitionOffset=p.transitionOffset;a.solo=p.solo;a.rigidRear=p.rigidRear;a.paintScale=p.paintScale;a.paintAngle=p.paintAngle;a.paintX=p.paintX;a.paintY=p.paintY;a.paintPivotX=p.paintPivotX;a.paintPivotY=p.paintPivotY;a.mouthOverride=p.mouthOverride;a.birthProgress=p.birthProgress;a.bendDx=p.bendDx;a.bendDy=p.bendDy;a.bendSpan=p.bendSpan;a.rearBirth=p.rearBirth;a.consumed=p.consumed;
   populationPoseValid=true;populationLastProgress=p.rail.Progress;populationLastTail=tailOnly;
   if(same)IpadPopulationOptimization.GeometryHits++;
   return same;
  }
 }
 public sealed partial class NativeGameplayStudy {
  Snake[] populationVisible=Array.Empty<Snake>();NativeHunterNeon[] populationHunters=Array.Empty<NativeHunterNeon>();
  Snake[] PopulationVisibleSnakes(){
   int count=snakes.Count+ghosts.Count;if(populationVisible.Length!=count)populationVisible=new Snake[count];
   int i=0;foreach(var snake in snakes.Values)populationVisible[i++]=snake;foreach(var snake in ghosts)populationVisible[i++]=snake;
   if(drawn.Length!=count){drawn=new NativeSnake[count];poses=new SnakePose[count];palettes=new int[count];identities=new int[count];aggression=new double[count];}
   return populationVisible;
  }
  NativeHunterNeon[] PopulationHunterLayers(){
   if(populationHunters.Length!=world.Hunters.Count)populationHunters=new NativeHunterNeon[world.Hunters.Count];
   for(int i=0;i<populationHunters.Length;i++)populationHunters[i]=actors[world.Hunters[i].Id].neon;
   return populationHunters;
  }
 }
}

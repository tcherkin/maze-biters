using System;
using UnityEngine;
namespace MazeBiters.NativeStudy {
 // Approved gameplay atmosphere. Its real-time clock is visual only and never
 // consumes gameplay RNG, changes AI, or advances during hidden preparation.
 internal static class NativeLevelAtmosphere {
  internal const double HalfCycleSeconds=3;
  internal static readonly bool Legacy=Array.IndexOf(Environment.GetCommandLineArgs(),"--legacy-level-atmosphere")>=0;
  internal static float Pulse(double seconds)=>(float)(.5+.5*Math.Cos((seconds%6)*Math.PI/3));
  internal static double Advance(double seconds,double elapsedMilliseconds,bool paused)=>paused?seconds:seconds+Math.Max(0,Math.Min(250,elapsedMilliseconds))*.001;
  internal static Texture2D MakeDepthField(){
   const int w=144,h=100;var p=new byte[w*h];
   for(int y=0;y<h;y++)for(int x=0;x<w;x++){
    float px=(x+.5f)*4,py=400-(y+.5f)*4;
    float v=.5f+.24f*Mathf.Sin(px*.012f+py*.005f+.4f)*Mathf.Sin(py*.018f-.5f)+.20f*Mathf.Cos(px*.019f-py*.011f+.7f);
    p[y*w+x]=(byte)Mathf.Clamp(Mathf.RoundToInt(v*255),0,255);
   }
   var texture=new Texture2D(w,h,TextureFormat.R8,false,true){name="Level atmosphere depth",filterMode=FilterMode.Bilinear,wrapMode=TextureWrapMode.Clamp};
   texture.LoadRawTextureData(p);texture.Apply(false,true);return texture;
  }
 }
 public sealed partial class NativeGameplayStudy {
  double levelAtmosphereSeconds;
  Texture2D levelAtmosphereDepth;
  NativeMazeArtwork boundAtmosphereArt;
  NativeWallLightRoutes boundWallLightRoutes;
  static readonly Vector4[] NoWallLights=new Vector4[12];
  void BindLevelAtmosphere(NativeMazeArtwork artwork,bool active){
   boundAtmosphereArt=active?artwork:null;
   // The route graph is cached with its immutable maze. Rebinding a warmed
   // next scene restores the old graph rather than rebuilding either one.
   boundWallLightRoutes=active&&!NativeLevelAtmosphere.Legacy?artwork?.WallLightRoutes:null;
   if(active&&!NativeLevelAtmosphere.Legacy&&!levelAtmosphereDepth)levelAtmosphereDepth=NativeLevelAtmosphere.MakeDepthField();
  }
  void UpdateLevelAtmosphere(){
   bool active=NativeGlassPresentation.Enabled&&!NativeLevelAtmosphere.Legacy&&boundAtmosphereArt!=null;
   float strength=active?1:0;
   Shader.SetGlobalFloat("_MysticMix",active?NativeLevelAtmosphere.Pulse(levelAtmosphereSeconds):0);
   Shader.SetGlobalFloat("_MysticDepth",strength);
   Shader.SetGlobalFloat("_MysticTravel",active&&boundWallLightRoutes?.Count>0?1:0);
   Shader.SetGlobalFloat("_MysticLightMix",strength);
   Shader.SetGlobalFloat("_MysticStarTime",(float)levelAtmosphereSeconds);
   Shader.SetGlobalFloat("_MysticStarStrength",strength);
   Shader.SetGlobalTexture("_MysticDepthTex",levelAtmosphereDepth?levelAtmosphereDepth:Texture2D.grayTexture);
   // Use the original simulation clock for wall travel, as in the approved
   // experiment; the six-second ambient cycle and stars use active real time.
   Shader.SetGlobalVectorArray("_MysticSources",active&&boundWallLightRoutes!=null?boundWallLightRoutes.Evaluate(time*.001):NoWallLights);
  }
  void DisposeLevelAtmosphere(){Destroy(levelAtmosphereDepth);levelAtmosphereDepth=null;boundAtmosphereArt=null;boundWallLightRoutes=null;}
 }
}

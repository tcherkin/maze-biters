using System;
using UnityEngine;
namespace MazeBiters.NativeStudy {
 // Approved gameplay atmosphere. Its real-time clock is visual only and never
 // consumes gameplay RNG, changes AI, or advances during hidden preparation.
 internal static class NativeLevelAtmosphere {
  internal const double HalfCycleSeconds=3;
  internal static readonly bool Legacy=Array.IndexOf(Environment.GetCommandLineArgs(),"--legacy-level-atmosphere")>=0;
  // Same-binary reference is only for deterministic visual/performance checks.
  internal static bool Reference {get;private set;}
  internal static void SetReference(bool value){Reference=value;if(value)Shader.EnableKeyword("MB_ATMOSPHERE_REFERENCE");else Shader.DisableKeyword("MB_ATMOSPHERE_REFERENCE");}
  internal static float Pulse(double seconds)=>(float)(.5+.5*Math.Cos((seconds%6)*Math.PI/3));
  internal static double Advance(double seconds,double elapsedMilliseconds,bool paused)=>paused?seconds:seconds+Math.Max(0,Math.Min(250,elapsedMilliseconds))*.001;
  internal static Texture2D MakeDepthField(){
   const int w=144,h=100;var p=new byte[w*h];
   for(int y=0;y<h;y++)for(int x=0;x<w;x++){
    float px=(x+.5f)*4,py=400-(y+.5f)*4;
    float v=.5f+.24f*Mathf.Sin(px*.012f+py*.005f+.4f)*Mathf.Sin(py*.018f-.5f)+.20f*Mathf.Cos(px*.019f-py*.011f+.7f);
    p[y*w+x]=(byte)Mathf.Clamp(Mathf.RoundToInt(v*255),0,255);
   }
   var texture=new Texture2D(w,h,TextureFormat.R8,false,true){name="Level atmosphere depth",filterMode=FilterMode.Bilinear,wrapMode=TextureWrapMode.Clamp};
   texture.LoadRawTextureData(p);texture.Apply(false,true);return texture;
  }
 }
 public sealed partial class NativeGameplayStudy {
  double levelAtmosphereSeconds;
  Texture2D levelAtmosphereDepth;
  NativeMazeArtwork boundAtmosphereArt;
  NativeWallLightRoutes boundWallLightRoutes;
  static readonly Vector4[] NoWallLights=new Vector4[12];
  static readonly Vector4[] NoLightBounds=new Vector4[4];
  static NativeGameplayStudy atmosphereOwner;
  static readonly int MixId=Shader.PropertyToID("_MysticMix"),DepthId=Shader.PropertyToID("_MysticDepth"),TravelId=Shader.PropertyToID("_MysticTravel"),LightMixId=Shader.PropertyToID("_MysticLightMix"),StarTimeId=Shader.PropertyToID("_MysticStarTime"),StarStrengthId=Shader.PropertyToID("_MysticStarStrength"),DepthTextureId=Shader.PropertyToID("_MysticDepthTex"),SourcesId=Shader.PropertyToID("_MysticSources"),CellsId=Shader.PropertyToID("_MysticSourceCells"),BoundsId=Shader.PropertyToID("_MysticStreamBounds");
  bool atmosphereSubmitted,submittedActive;
  double submittedAtmosphereSeconds,submittedTravelTime;
  long atmosphereUploads,atmosphereSkipped;
  void BindLevelAtmosphere(NativeMazeArtwork artwork,bool active){
   // A hidden next-scene render temporarily owns the global bindings. Always
   // invalidate on bind, including restoration of the visible scene.
   atmosphereSubmitted=false;
   boundAtmosphereArt=active?artwork:null;
   // The route graph is cached with its immutable maze. Rebinding a warmed
   // next scene restores the old graph rather than rebuilding either one.
   boundWallLightRoutes=active&&!NativeLevelAtmosphere.Legacy?artwork?.WallLightRoutes:null;
   if(active&&!NativeLevelAtmosphere.Legacy&&!levelAtmosphereDepth)levelAtmosphereDepth=NativeLevelAtmosphere.MakeDepthField();
  }
  void UpdateLevelAtmosphere(){
   bool active=NativeGlassPresentation.Enabled&&!NativeLevelAtmosphere.Legacy&&boundAtmosphereArt!=null;
   if(NativeLevelAtmosphere.Reference){UpdateLevelAtmosphereReference(active);atmosphereSubmitted=false;atmosphereUploads++;return;}
   bool all=!atmosphereSubmitted||atmosphereOwner!=this||submittedActive!=active;
   bool visual=all||submittedAtmosphereSeconds!=levelAtmosphereSeconds;
   bool travel=all||submittedTravelTime!=time;
   if(!visual&&!travel){atmosphereSkipped++;return;}
   if(all){
    Shader.SetGlobalFloat(DepthId,active?1:0);Shader.SetGlobalFloat(LightMixId,active?1:0);
    Shader.SetGlobalFloat(TravelId,active&&boundWallLightRoutes?.Count>0?1:0);
    Shader.SetGlobalFloat(StarStrengthId,active?1:0);
    Shader.SetGlobalTexture(DepthTextureId,levelAtmosphereDepth?levelAtmosphereDepth:Texture2D.grayTexture);
   }
   if(visual){Shader.SetGlobalFloat(MixId,active?NativeLevelAtmosphere.Pulse(levelAtmosphereSeconds):0);Shader.SetGlobalFloat(StarTimeId,(float)levelAtmosphereSeconds);}
   if(travel){
    var routes=active?boundWallLightRoutes:null;
    Shader.SetGlobalVectorArray(SourcesId,routes!=null?routes.Evaluate(time*.001):NoWallLights);
    Shader.SetGlobalVectorArray(CellsId,routes!=null?routes.SourceCells:NoWallLights);
    Shader.SetGlobalVectorArray(BoundsId,routes!=null?routes.StreamBounds:NoLightBounds);
   }
   atmosphereOwner=this;atmosphereSubmitted=true;submittedActive=active;
   submittedAtmosphereSeconds=levelAtmosphereSeconds;submittedTravelTime=time;atmosphereUploads++;
  }
  void UpdateLevelAtmosphereReference(bool active){
   float strength=active?1:0;
   Shader.SetGlobalFloat("_MysticMix",active?NativeLevelAtmosphere.Pulse(levelAtmosphereSeconds):0);
   Shader.SetGlobalFloat("_MysticDepth",strength);
   Shader.SetGlobalFloat("_MysticTravel",active&&boundWallLightRoutes?.Count>0?1:0);
   Shader.SetGlobalFloat("_MysticLightMix",strength);
   Shader.SetGlobalFloat("_MysticStarTime",(float)levelAtmosphereSeconds);
   Shader.SetGlobalFloat("_MysticStarStrength",strength);
   Shader.SetGlobalTexture("_MysticDepthTex",levelAtmosphereDepth?levelAtmosphereDepth:Texture2D.grayTexture);
   // Use the original simulation clock for wall travel, as in the approved
   // experiment; the six-second ambient cycle and stars use active real time.
   Shader.SetGlobalVectorArray("_MysticSources",active&&boundWallLightRoutes!=null?boundWallLightRoutes.Evaluate(time*.001,true):NoWallLights);
  }
  void DisposeLevelAtmosphere(){if(ReferenceEquals(atmosphereOwner,this))atmosphereOwner=null;atmosphereSubmitted=false;Destroy(levelAtmosphereDepth);levelAtmosphereDepth=null;boundAtmosphereArt=null;boundWallLightRoutes=null;}
 }
}

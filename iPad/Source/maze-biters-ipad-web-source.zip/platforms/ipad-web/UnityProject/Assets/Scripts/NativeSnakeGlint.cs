using System;
using UnityEngine;
namespace MazeBiters.NativeStudy {
 // Presentation only: one clock arbitrates aggression and recognition. It
 // never consults the brain or consumes the world's gameplay random stream.
 public sealed class NativeSnakeGlint {
  public const double MinimumSpacing=1600;
  uint random;double attention,start=double.NegativeInfinity,duration=980,next=double.PositiveInfinity,span,jitter;
  double noticeAt=double.PositiveInfinity,last=double.NegativeInfinity;bool active,observed;
  Vector2Int previousHead,previousDirection;
  bool sightKnown,sight;string[] sightGrid;int sightRevision,sightAlive;
  Vector2Int sightHead,sightDirection,sightP0,sightP1,sightP2;
  public int Events{get;private set;}public int RecognitionEvents{get;private set;}
  public double LastStart=>start;public double NoticeAt=>noticeAt;
  public NativeSnakeGlint Copy()=>(NativeSnakeGlint)MemberwiseClone();
  public NativeSnakeGlint(uint seed){random=seed^0x9e3779b9u;jitter=Random();}
  double Random(){random=unchecked(random*1664525+1013904223);return random/4294967296.0;}
  static double Clamp(double v)=>Math.Max(0,Math.Min(1,v));
  static double Smooth(double v){v=Clamp(v);return v*v*(3-2*v);}
  double Gap(){
   double lo=6000,hi=12000,a;
   if(attention>.7){a=(attention-.7)/.3;lo=4000-1500*a;hi=6000-2000*a;}
   else if(attention>.45){a=(attention-.45)/.25;lo=5000-1000*a;hi=8000-2000*a;}
   else if(attention>.2){a=(attention-.2)/.25;lo=6000-1000*a;hi=12000-4000*a;}
   return Math.Max(MinimumSpacing,(lo+(hi-lo)*jitter)/(1.5+.5*attention));
  }
  void Schedule(double now){jitter=Random();span=Gap();next=active?now+span:double.PositiveInfinity;}
  public void SetAggression(double value,double now){
   value=Clamp(value);bool was=active;active=was?value>.08:value>=.12;
   if(value==attention&&was==active)return;
   double remaining=double.IsInfinity(next)||span<=0?1:Clamp((next-now)/span);attention=value;
   if(!active){next=double.PositiveInfinity;return;}
   if(!was){span=Gap();next=Math.Max(start+MinimumSpacing,now+500+Random()*1300);}
   else {span=Gap();next=Math.Max(start+MinimumSpacing,now+remaining*span);}
  }
  void Begin(double now,bool recognition){start=now;duration=900+Random()*160;Events++;if(recognition)RecognitionEvents++;noticeAt=double.PositiveInfinity;Schedule(now);}
  public double Sample(double now){
   if(now<last){start=double.NegativeInfinity;noticeAt=double.PositiveInfinity;observed=false;sightKnown=false;Schedule(now);}
   last=now;
   if(!double.IsPositiveInfinity(noticeAt)){
    // A notice reserves the next pulse. A periodic pulse cannot steal its
    // 1–2 second response window or produce a second flash on top of it.
    if(now>=noticeAt){if(now-noticeAt>1150){noticeAt=double.PositiveInfinity;Schedule(now);}else Begin(now,true);}
   }else if(active&&now>=next){if(now-next>1150)Schedule(now);else if(now>=start+MinimumSpacing)Begin(now,false);}
   double t=(now-start)/duration;if(t<=0||t>=1)return 0;
   return t<.24?Smooth(t/.24):t<.38?1:1-Smooth((t-.38)/.62);
  }
  public void Observe(NativeGameplayWorld world,NativeGameplaySnake snake,double now){
   if(world==null||snake==null||snake.Body.Count==0){noticeAt=double.PositiveInfinity;observed=false;return;}
   bool turned=observed&&snake.Head!=previousHead&&snake.Dir!=previousDirection;
   previousHead=snake.Head;previousDirection=snake.Dir;observed=true;
   if(snake.Reversing){noticeAt=double.PositiveInfinity;return;}
   if(!turned&&double.IsPositiveInfinity(noticeAt))return;
   bool visible=Visible(world,snake);
   if(turned){noticeAt=visible?Math.Max(now+1000+Random()*1000,start+MinimumSpacing):double.PositiveInfinity;}
   else if(!visible)noticeAt=double.PositiveInfinity;
  }
  bool Visible(NativeGameplayWorld w,NativeGameplaySnake s){
   int alive=0;Vector2Int a=default,b=default,c=default;
   for(int i=0;i<w.PlayerCount;i++){var p=w.GetPlayer(i);if(!p.Dead&&!p.Eliminated&&p.Lives>0)alive|=1<<i;if(i==0)a=p.Cell;else if(i==1)b=p.Cell;else c=p.Cell;}
   if(sightKnown&&ReferenceEquals(sightGrid,w.Grid)&&sightRevision==w.ObstacleRevision&&sightAlive==alive&&sightHead==s.Head&&sightDirection==s.Dir&&sightP0==a&&sightP1==b&&sightP2==c)return sight;
   sightKnown=true;sightGrid=w.Grid;sightRevision=w.ObstacleRevision;sightAlive=alive;sightHead=s.Head;sightDirection=s.Dir;sightP0=a;sightP1=b;sightP2=c;sight=false;
   for(int i=0;i<w.PlayerCount;i++)if((alive&(1<<i))!=0&&InForwardTunnel(w,s.Head,s.Dir,w.GetPlayer(i).Cell)){sight=true;break;}
   return sight;
  }
  internal static bool InForwardTunnel(NativeGameplayWorld w,Vector2Int head,Vector2Int direction,Vector2Int player){
   if(Math.Abs(direction.x)+Math.Abs(direction.y)!=1)return false;
   var d=player-head;int distance=d.x*direction.x+d.y*direction.y;
   if(distance<=0||d.x*direction.y-d.y*direction.x!=0)return false;
   for(var p=head+direction;p!=player;p+=direction)if(!w.Floor(p)||w.SolidEgg(p))return false;
   return w.Floor(player);
  }
 }
}

using System;
using System.Collections.Generic;
using UnityEngine;
namespace MazeBiters.NativeStudy {
 [Serializable] public struct RailPoint {public double x,y,tx,ty,angle,curve;}
 public sealed class SnakeRail:SnakeCurve {
  public struct Piece {public bool arc;public double x,y,tx,ty,start,length,radius,angle,sign;}
  public readonly List<Piece> Pieces=new List<Piece>();public readonly double[] CellDistances;double total;public override double Total=>total;
  public SnakeRail(Vector2Int[] cells,Vector2Int? direction=null){
   if(cells.Length<1)throw new ArgumentException("Rail needs a cell");CellDistances=new double[cells.Length];var v=new List<Vector2>();foreach(var c in cells)v.Add(new Vector2((c.x+.5f)*36,(c.y+.5f)*36));
   var first=v.Count>1?(v[1]-v[0]).normalized:(Vector2)(direction??Vector2Int.right);var last=v.Count>1?(v[v.Count-1]-v[v.Count-2]).normalized:first;
   v.Insert(0,v[0]-first*72);v.Add(v[v.Count-1]+last*72);var previous=v[0];
   for(int i=1;i<v.Count-1;i++){
    var a=v[i-1];var b=v[i];var c=v[i+1];double before=(b-a).magnitude,after=(c-b).magnitude,ix=(b.x-a.x)/before,iy=(b.y-a.y)/before,ox=(c.x-b.x)/after,oy=(c.y-b.y)/after;
    double cross=ix*oy-iy*ox,dot=ix*ox+iy*oy;
    if(Math.Abs(cross)<.5||Math.Abs(dot)>1e-6){Line(previous.x,previous.y,b.x,b.y);CellDistances[i-1]=Total;previous=b;continue;}
    double radius=Math.Min(18,Math.Min(before/2,after/2)),sign=Math.Sign(cross),ex=b.x-ix*radius,ey=b.y-iy*radius,cx=ex+ox*radius,cy=ey+oy*radius;
    Line(previous.x,previous.y,ex,ey);double len=radius*Math.PI/2;CellDistances[i-1]=Total+len/2;
    Pieces.Add(new Piece{arc=true,x=cx,y=cy,radius=radius,sign=sign,angle=Math.Atan2(ey-cy,ex-cx),start=Total,length=len});total+=len;previous=new Vector2((float)(b.x+ox*radius),(float)(b.y+oy*radius));
   }Line(previous.x,previous.y,v[v.Count-1].x,v[v.Count-1].y);
  }
  void Line(double ax,double ay,double bx,double by){double dx=bx-ax,dy=by-ay,len=Math.Sqrt(dx*dx+dy*dy);if(len<1e-8)return;Pieces.Add(new Piece{x=ax,y=ay,tx=dx/len,ty=dy/len,start=Total,length=len});total+=len;}
  int Index(double s){int lo=0,hi=Pieces.Count-1;while(lo<hi){int mid=(lo+hi)>>1;if(s<Pieces[mid].start+Pieces[mid].length)hi=mid;else lo=mid+1;}return lo;}
  public override RailPoint SampleForRender(double s){var p=Pieces[Index(s)];double local=s-p.start;if(!p.arc)return new RailPoint{x=p.x+p.tx*local,y=p.y+p.ty*local,tx=p.tx,ty=p.ty};double angle=p.angle+p.sign*local/p.radius,c=Math.Cos(angle),n=Math.Sin(angle);return new RailPoint{x=p.x+p.radius*c,y=p.y+p.radius*n,tx=-p.sign*n,ty=p.sign*c,curve=p.sign/p.radius};}
  public override RailPoint Sample(double s){var p=Pieces[Index(s)];double local=s-p.start;RailPoint q;
   if(!p.arc)q=new RailPoint{x=p.x+p.tx*local,y=p.y+p.ty*local,tx=p.tx,ty=p.ty};
   else{double angle=p.angle+p.sign*local/p.radius;q=new RailPoint{x=p.x+p.radius*Math.Cos(angle),y=p.y+p.radius*Math.Sin(angle),tx=-p.sign*Math.Sin(angle),ty=p.sign*Math.Cos(angle),curve=p.sign/p.radius};}
   q.angle=Math.Atan2(q.ty,q.tx);return q;
  }
  public override bool TryVisibilityBounds(double begin,double end,out VisibilityBounds bounds){if(begin>end){double swap=begin;begin=end;end=swap;}var a=SampleForRender(begin);var b=SampleForRender(end);bounds=VisibilityBounds.Point(a.x,a.y);bounds.Add(b.x,b.y);for(int i=Index(begin);i<=Index(end);i++){var p=Pieces[i];if(p.arc){bounds.Add(p.x-p.radius,p.y-p.radius);bounds.Add(p.x+p.radius,p.y+p.radius);}else{double low=Math.Max(begin,p.start),high=Math.Min(end,p.start+p.length);if(high>=low){bounds.Add(p.x+p.tx*(low-p.start),p.y+p.ty*(low-p.start));bounds.Add(p.x+p.tx*(high-p.start),p.y+p.ty*(high-p.start));}}}return true;}
  public override double RibbonSpan(double s,double maximum,int direction=1){var p=Pieces[Index(s+direction*1e-7)];double remaining=direction>0?p.start+p.length-s:s-p.start;return remaining<=1e-7?Math.Min(maximum,1.6):Math.Min(maximum,Math.Min(remaining,p.arc?1.6:double.PositiveInfinity));}
  public double Project(double x,double y,double preferred=0){double best=double.PositiveInfinity,result=0;foreach(var p in Pieces){double local;if(!p.arc)local=Math.Max(0,Math.Min(p.length,(x-p.x)*p.tx+(y-p.y)*p.ty));else{double turn=Wrap(Math.Atan2(y-p.y,x-p.x)-p.angle)*p.sign;local=Math.Max(0,Math.Min(p.length,turn*p.radius));}var q=Sample(p.start+local);double error=(q.x-x)*(q.x-x)+(q.y-y)*(q.y-y);if(error<best-1e-10||Math.Abs(error-best)<=1e-10&&Math.Abs(p.start+local-preferred)<Math.Abs(result-preferred)){best=error;result=p.start+local;}}return result;}
 }
 public struct SnakePulse {public double progress,compression,phase;}
 public static class SnakeMotion {
  public const double Cell=36,Diameter=57.0/160*Cell,Tail=35*Diameter/16,Head=215.5*Diameter/76;
  static double Glide(double phase,double start,double end){if(phase<=start)return 0;if(phase>=end)return 1;double u=(phase-start)/(end-start),r=.2;if(u>=r&&u<=1-r)return (u-r/2)/(1-r);double q=u<r?u:1-u,result=.5*(q-r/Math.PI*Math.Sin(Math.PI*q/r))/(1-r);return u<r?result:1-result;}
  public static SnakePulse Pulse(double phase,double length,bool backwards){double u=AnimationClock.Clamp(phase),p=backwards?1-u:u,head=Glide(p,.45,1),gather=Glide(p,0,.5),body=Math.Max(0,length-Head-Tail),capacity=Math.Min(16,Math.Min(Math.Max(0,body-4),Math.Min(body*.3,.6*Cell*Math.PI/4))),advance=.4*p+.6*head;
   return new SnakePulse{progress=backwards?1-advance:advance,compression=capacity*(gather-head),phase=p};}
  public static double TailWidth(double fraction){double u=AnimationClock.Clamp(fraction);return u*(1+u*u*(4+u*(-7+3*u)));}
  public static int Mouth(double phase)=>AnimationClock.Frame(1-Math.Pow(Math.Sin(Math.PI*(phase%1)),4),96);
 }
 public sealed class SnakePose {
  public SnakeCurve rail;public double head,length,compression,phase,frontMaterial,materialSign=1,soloAmount,transitionOffset;public bool solo;public RailPoint? rigidRear;public double Rear=>head-SnakeMotion.Head;public double Tip=>head-length+compression;
  public double paintScale=1,paintAngle,paintX,paintY,paintPivotX,paintPivotY;public int mouthOverride=-1;
  public double birthProgress=1,bendDx,bendDy,bendSpan;public bool rearBirth,consumed;
 }
}

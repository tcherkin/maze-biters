using System;
using System.Collections.Generic;
using System.Linq;
using UnityEngine;
namespace MazeBiters.NativeStudy {
 public class NativeCreature {
  public readonly double[] PersonalThreat=new double[3];public int HoldPlayerId,ReleasedPlayerId;public int Id;public Vector2Int Cell,Dir=Vector2Int.right;public double LastMove,Anger,Threat,Aggression,Intelligence;public NativeBrainState Brain;public Vector2Int? VisualTarget,HeldDirection;
  public Vector2Int? HoldCell,ReleasedCell;public double HoldStamp,ReleasedStamp;
 }
 public sealed class NativePlayer:NativeCreature {
  public bool IsAI;public NativeAllyState Ai;
  public double Contribution,LifeSpotlight=double.NegativeInfinity,ScoreSpotlight=double.NegativeInfinity;public double DeathAt,RespawnAt,ShieldFlashAt,ExactScore;public int NextLifeScore=5000,ExtraLives;public bool HideDeath,Eliminated,ShieldBright;public double PowerStarted,RampAt,RampDuration,RampFrom,PowerUntil,WarningAt,FlashAt,ShieldUntil;public bool PowerBright;public Vector2Int From,Previous,Next=Vector2Int.right;public double MoveStarted=-1e6,MoveDuration=95,BiteAt=-1e6,BiteEnd=-1e6,Tilt,TiltAt;public bool Waiting=true,Dead,PointerMomentum;public int Score,Lives=3,Palette;public Vector2Int? Pointer,Alternate;public Vector2? GamepadTilt;
  public readonly Dictionary<string,(Vector2Int dir,int order)> Keys=new Dictionary<string,(Vector2Int,int)>();public int KeySerial;public List<Vector2Int> Ricochet;public int RicochetIndex;
  public Vector2 Visual(double t)=>Dead?(Vector2)Cell:Vector2.Lerp(From,Cell,(float)AnimationClock.Clamp((t-MoveStarted)/Math.Max(1,MoveDuration)));
 }
 public sealed class NativeHunter:NativeCreature {public Vector2Int From;public double MoveStarted=-1e6,MoveDuration=95,NextCutAt,BiteAt=-1e6,BiteEnd=-1e6;public bool MotherAlive=true;public int Palette;public int RevengePlayerId,RevengeRevision;public double RevengeAt=-1e6;}
 public sealed class NativeGameplaySnake:NativeCreature {
  public readonly Dictionary<int,double> HunterThreat=new Dictionary<int,double>();
  public List<Vector2Int> Body=new List<Vector2Int>(),Trail=new List<Vector2Int>(),GuideHistory=new List<Vector2Int>();public readonly List<Vector2Int> Skipped=new List<Vector2Int>();
  public int Palette,ReverseSteps,GuideFailures,BlockedAttempts;public bool Reversing,Recovery;public double Temperament=.5,TurnBias=.5,AngerPeak,AngerFloor,LastAnger,LastMemory;
  public Vector2Int? Guide,GuideDir,BlockedDir,OldRoute,Pending,ReturnAvoid,BlockedJunction;public string PreparedKey;public bool PreparedTake;
  public Vector2Int Head=>Body[0];public Vector2Int Tail=>Body[Body.Count-1];
 }
 public sealed class NativeWorldEvent {
  public NativePlayer Player,Victim;public Vector2Int Cell;public NativeScorpion Scorpion;
  public string Kind,Sound;public bool GlobalSound;public NativeGameplaySnake Snake;public NativeHunter Hunter;public List<NativeGameplaySnake> Created;public Vector2Int[] OldBody;public int Index;public double Time,Duration;public bool WasReversing;public Vector2Int OldDirection;
 }
 // Native gameplay translation of the frozen stable CELL-contact engine.
 // Solo, two-human modes and SOLO VS AI share the original contact/lifecycle rules.
 public sealed partial class NativeGameplayWorld {
  public static readonly Vector2Int[] Dirs={Vector2Int.right,Vector2Int.left,Vector2Int.up,Vector2Int.down}; // +Y is DOWN in game coordinates.
  public string[] Grid;public int Width=>Grid[0].Length;public int Height=>Grid.Length;public int Level=1,ObstacleRevision;public double Difficulty=1,Time=1000,LevelStarted=1000;public bool Assist=true;public bool UseLegacyAi; // Only frozen historical validation opts into the previous brain.
  public readonly List<NativeGameplaySnake> Snakes=new List<NativeGameplaySnake>();public readonly List<NativeHunter> Hunters=new List<NativeHunter>();public readonly HashSet<Vector2Int> SolidEggs=new HashSet<Vector2Int>();public readonly NativeMazeBrain Brain;
  public int AiDifficulty=2;public readonly NativeAllyBrain Ally;
  public Func<double> Random;public Action<NativeWorldEvent> Event;int nextId=10;
  public NativeGameplayWorld(string[] grid,Func<double> random){Grid=grid;Random=random;Brain=new NativeMazeBrain(this);Ally=new NativeAllyBrain(this);}
  public int Index(Vector2Int p)=>p.y*Width+p.x;public bool Floor(Vector2Int p)=>p.x>=0&&p.y>=0&&p.x<Width&&p.y<Height&&Grid[p.y][p.x]!='#';public bool SolidEgg(Vector2Int p)=>SolidEggs.Contains(p)||Eggs.Any(e=>e.Cell==p&&Time-e.Born>=10000&&!EggCovered(e));public NativePlayer PlayerAt(Vector2Int p){for(int i=0;i<PlayerCount;i++){var player=GetPlayer(i);if(!player.Dead&&player.Lives>0&&player.Cell==p)return player;}return null;}
  public bool Occupied(Vector2Int p,NativeGameplaySnake except=null)=>Snakes.Any(s=>s!=except&&s.Body.Contains(p));public bool HunterAt(Vector2Int p,NativeHunter except=null)=>Hunters.Any(h=>h!=except&&h.Cell==p);
  public bool CanEnter(Vector2Int p,NativeGameplaySnake s,bool ignoreTail=true,bool allowHunter=false){int n=s.Body.Count-(ignoreTail?1:0);return Floor(p)&&!SolidEgg(p)&&!Occupied(p,s)&&!s.Body.Take(n).Contains(p)&&(!HunterAt(p)||allowHunter&&CreatureFeuds)&&!ScorpionAt(p)&&!Repels(p);}
  public NativeGameplaySnake AddSnake(IEnumerable<Vector2Int> body,Vector2Int dir,int palette){var s=new NativeGameplaySnake{Id=nextId++,Body=body.ToList(),Dir=dir,Palette=palette,Temperament=Random(),TurnBias=Random()};s.Cell=s.Head;Snakes.Add(s);return s;}
  void Emit(string kind,NativeGameplaySnake s,Vector2Int[] old=null,int index=-1,List<NativeGameplaySnake> created=null,double duration=218,bool reversing=false){SessionEffect(kind=="split"&&index==0?"head":kind,Player.Cell);Event?.Invoke(new NativeWorldEvent{Player=Player,Kind=kind,Snake=s,OldBody=old,Index=index,Created=created,Time=Time,Duration=duration,WasReversing=reversing});}
  public static BrainProfile Profile(NativeGameplaySnake s)=>new BrainProfile{kind="snake",baseline=.08+s.Temperament*.15,injury=Math.Min(.34,s.Anger*.065),stateBoost=(s.Body.Count<=4&&s.Body.Count>1?.24:0)+(s.Body.Count==1?.48:0)};
  public void Press(string key,Vector2Int d){var p=Player;if(p.IsAI)return;p.Pointer=null;p.PointerMomentum=false;if(!p.Keys.ContainsKey(key)){var held=Held();p.Keys[key]=(d,++p.KeySerial);var different=held.FindAll(x=>x!=d);p.Alternate=different.Count>0?different[0]:d;}p.Next=d;p.Waiting=false;}
  public void Release(string key){if(!Player.Keys.Remove(key))return;var held=Held();if(held.Count<2)Player.Alternate=held.Count>0?(Vector2Int?)held[0]:null;}
  public void ClearKeys(){Player.Keys.Clear();Player.Alternate=null;Player.GamepadTilt=null;}
  public List<Vector2Int> Held(){var list=new List<Vector2Int>();foreach(var item in Player.Keys.Values.OrderByDescending(x=>x.order)){if(!list.Contains(item.dir))list.Add(item.dir);if(list.Count==2)break;}return list;}
  public void Navigate(Vector2Int cell){if(Player.IsAI)return;Player.Pointer=Brain.Nearest(cell);Player.PointerMomentum=false;Player.Waiting=false;}
  public Vector2Int? KeyboardStep(){var held=Held();if(held.Count==0)return null;if(held.Count==1)return held[0];var a=held[0];var b=held[1];if(a.x!=0&&b.x!=0||a.y!=0&&b.y!=0)return a;var preferred=Player.Alternate==a?b:a;var alternative=preferred==a?b:a;foreach(var d in new[]{preferred,alternative})if(PlayerCellOpen(Player,Player.Cell+d)){Player.Alternate=d;return d;}return preferred;}
  public static double TiltTarget(Vector2Int direction,double x,double y){if(Math.Sqrt(x*x+y*y)<.16)return 0;bool horizontal=direction.x!=0;double forward=horizontal?x*direction.x:y*direction.y,secondary=horizontal?y:x;if(Math.Abs(secondary)<.08)return 0;return (horizontal?Math.Sign(secondary)*Math.Sign(direction.x):Math.Sign(secondary))*30*Math.Min(1,Math.Atan2(Math.Abs(secondary),Math.Max(0,forward))/(Math.PI/2));}
  public void UpdateTilt(double realTime){Vector2 axis=Vector2.zero;if(Player.IsAI){if(!Player.Dead)axis=Ally.VisualVector(Player);}else{var held=Held();if(held.Count>0){axis=held[0];if(held.Count>1&&axis.x*held[1].x==0&&axis.y*held[1].y==0)axis+=(Vector2)held[1];}if(Player.GamepadTilt.HasValue&&!Player.Dead)axis=Player.GamepadTilt.Value;}double target=TiltTarget(Player.Dir,axis.x,axis.y),elapsed=Math.Max(0,Math.Min(34,realTime-(Player.TiltAt==0?realTime:Player.TiltAt))),delta=target-Player.Tilt;Player.Tilt+=Math.Sign(delta)*Math.Min(Math.Abs(delta),60*elapsed/1000);Player.TiltAt=realTime;}
  bool Eligible=>Assist&&!Player.IsAI&&!Player.Dead&&Player.Lives>0&&!PlayerProtected(Player,Time);
  public bool Hazard(Vector2Int d){if(d==Vector2Int.zero||PlayerProtected(Player,Time))return false;var next=Player.Cell+d;if(HunterAt(next))return true;return Snakes.Any(s=>s.Head==next&&(s.Body.Count==1?d==-s.Dir:d!=s.Dir));}
  void StopRicochet(){Player.Pointer=null;Player.PointerMomentum=false;Player.Ricochet=null;Player.Waiting=true;}
  Vector2Int? BeginRicochet(Vector2Int forward){var p=Player;p.Pointer=null;p.PointerMomentum=false;var path=new List<Vector2Int>();for(var c=p.Cell-forward;path.Count<Width*Height&&PlayerCellOpen(p,c);c-=forward)path.Add(c);if(path.Count==0){StopRicochet();return null;}p.Ricochet=path;p.RicochetIndex=0;p.Waiting=false;return path[0];}
  Vector2Int? RetreatDirection(){var p=Player;if(p.Ricochet==null||p.RicochetIndex>=p.Ricochet.Count)return null;var d=p.Ricochet[p.RicochetIndex]-p.Cell;return Math.Abs(d.x)+Math.Abs(d.y)==1?(Vector2Int?)d:null;}
  Vector2Int? SafeTurn(Vector2Int? retreat){var p=Player;if(p.Ricochet==null||p.RicochetIndex<1||!retreat.HasValue)return null;var candidates=Held();if(p.Pointer.HasValue){var d=Brain.RouteStep(p,p.Pointer.Value);if(d.HasValue)candidates.Add(d.Value);}foreach(var d in candidates)if(d!=retreat.Value&&d!=-retreat.Value&&PlayerCellOpen(p,p.Cell+d)&&!Hazard(d))return d;return null;}
  public void AdvancePlayer(){var p=Player;if(p.Dead)return;var retreat=RetreatDirection();var safe=SafeTurn(retreat);var keyboard=p.Ricochet==null&&!p.IsAI?KeyboardStep():null;
   if(p.Ricochet!=null){if(!retreat.HasValue){StopRicochet();return;}if(safe.HasValue){p.Ricochet=null;p.Next=safe.Value;}else p.Next=retreat.Value;p.Waiting=false;}
   else if(keyboard.HasValue){p.Pointer=null;p.PointerMomentum=false;p.Next=keyboard.Value;p.Waiting=false;}
   else if(p.Pointer.HasValue){if(p.Cell==p.Pointer.Value){p.Pointer=null;p.PointerMomentum=true;p.Next=p.Dir;}else{var d=Brain.RouteStep(p,p.Pointer.Value);if(d.HasValue)p.Next=d.Value;else{p.Pointer=null;p.PointerMomentum=true;p.Next=p.Dir;}}p.Waiting=false;}
   else if(p.PointerMomentum){p.Next=p.Dir;p.Waiting=false;}if(p.Waiting)return;
   bool open=PlayerCellOpen(p,p.Cell+p.Next);var incoming=p.Dir;var travel=open?p.Next:p.Dir;
   if(Eligible&&p.Ricochet==null&&Hazard(travel)){var cell=BeginRicochet(incoming);if(!cell.HasValue)return;var d=cell.Value-p.Cell;if(Hazard(d)){StopRicochet();return;}p.Next=p.Dir=d;}else if(open)p.Dir=p.Next;
   Event?.Invoke(new NativeWorldEvent{Player=p,Kind="playerTurn",Time=Time,OldDirection=incoming});var next=p.Cell+p.Dir;
   if(PlayerCellOpen(p,next)){p.Previous=p.From=p.Cell;p.Cell=next;p.MoveStarted=Time;p.MoveDuration=PlayerDelay;ResolvePlayerContact(p);if(p.Dead)return;CheckContact();if(p.Dead)return;if(p.Ricochet!=null){if(p.RicochetIndex<p.Ricochet.Count&&p.Cell==p.Ricochet[p.RicochetIndex])p.RicochetIndex++;if(p.RicochetIndex>=p.Ricochet.Count)StopRicochet();}else if(p.Pointer==p.Cell){p.Pointer=null;p.PointerMomentum=true;p.Waiting=false;}}
   else if(p.Ricochet!=null)StopRicochet();
  }
  bool HoldActive(NativeCreature threat){if(!threat.HoldCell.HasValue)return false;var held=PlayerById(threat.HoldPlayerId)??Player;using(ForPlayer(held)){if(Eligible&&Player.Cell==threat.HoldCell&&Player.LastMove==threat.HoldStamp)return true;threat.ReleasedCell=threat.HoldCell;threat.ReleasedStamp=Player.LastMove;threat.ReleasedPlayerId=Player.Id;threat.HoldCell=null;return false;}}
  bool Yield(NativeCreature threat,Vector2Int from,NativePlayer target){if(target==null)return false;using(ForPlayer(target))return YieldCurrent(threat,from);} bool YieldCurrent(NativeCreature threat,Vector2Int from){if(!Eligible||Math.Abs(from.x-Player.Cell.x)+Math.Abs(from.y-Player.Cell.y)!=1)return false;if((!Multiplayer||threat.ReleasedPlayerId==Player.Id)&&threat.ReleasedCell==Player.Cell&&threat.ReleasedStamp==Player.LastMove){threat.ReleasedCell=null;return false;}threat.ReleasedCell=null;threat.HoldPlayerId=Player.Id;threat.HoldCell=Player.Cell;threat.HoldStamp=Player.LastMove;return true;}
  public void Tick(double t){Time=t;if(SessionTick())return;if(LifecycleEnabled)RefreshEggTopology();TickPlayers(t);if(Transition)return;int count=Snakes.Count;for(int i=0;i<count;i++){if(i>=Snakes.Count)continue;var s=Snakes[i];double delay=s.Reversing?436:218;if(t-s.LastMove<=delay||HoldActive(s))continue;Memory(s);var old=s.Body.ToArray();bool reversing=s.Reversing;if(!SnakeStep(s))continue;if(Snakes.Contains(s))Emit("snakeMove",s,old,duration:s.Recovery||s.Body.Count==1&&reversing&&!s.Reversing?218:delay,reversing:reversing);s.Recovery=false;s.LastMove=t;if(Transition)return;if(Snakes.Contains(s))PrepareJunction(s);}if(LifecycleEnabled&&Scorpion==null&&t>=ScorpionSpawnAt)SpawnScorpion();MoveScorpion();if(LifecycleEnabled){ReleaseDrops();UpdateEggs();}MoveHunters();}
  List<Vector2Int> Forward(NativeGameplaySnake s)=>Dirs.Where(d=>d!=-s.Dir&&CanEnter(s.Head+d,s,allowHunter:true)).ToList();
  Vector2Int Choose(NativeGameplaySnake s,List<Vector2Int> options){if(s.HeldDirection.HasValue){var d=s.HeldDirection.Value;s.HeldDirection=null;if(options.Contains(d))return d;}return Brain.Choose(s,s.Head,options,Profile(s));}
  bool Advance(NativeGameplaySnake s,Vector2Int d){if(PlayerAt(s.Head+d)!=null&&Yield(s,s.Head,PlayerAt(s.Head+d))){s.HeldDirection=d;return false;}s.Dir=d;s.Body.Insert(0,s.Head+d);s.Body.RemoveAt(s.Body.Count-1);TouchHunterHead(s);return true;}
  void Resume(NativeGameplaySnake s,Vector2Int d){s.PreparedKey=null;s.Reversing=false;s.Guide=null;s.Pending=d;s.Recovery=true;}
  void BeginRetreat(NativeGameplaySnake s){s.Pending=null;s.Recovery=false;s.PreparedKey=null;if(s.Body.Count<2){s.Reversing=false;s.Guide=null;return;}s.Reversing=true;s.ReverseSteps=0;s.OldRoute=null;s.Skipped.Clear();s.BlockedDir=s.Dir;s.Guide=s.Tail;s.GuideDir=s.Tail-s.Body[s.Body.Count-2];s.GuideHistory=new List<Vector2Int>{s.Tail};s.GuideFailures=0;}
  bool TailOpen(Vector2Int p,NativeGameplaySnake s,HashSet<Vector2Int> blocked)=>Floor(p)&&!blocked.Contains(p)&&!Occupied(p,s)&&!HunterAt(p)&&!SolidEgg(p)&&!ScorpionAt(p)&&!Repels(p);
  public double TailScore(NativeGameplaySnake s,Vector2Int option){var g=s.Guide.Value;var next=g+option;var blocked=new HashSet<Vector2Int>(s.Body);blocked.Add(g);blocked.Remove(next);var recent=new Dictionary<Vector2Int,int>();foreach(var c in s.GuideHistory){recent.TryGetValue(c,out int n);recent[c]=n+1;}var visited=new Dictionary<Vector2Int,int>{{next,0}};var queue=new List<Vector2Int>{next};int maxDepth=0,junctions=0,touches=recent.TryGetValue(next,out int first)?first:0;for(int read=0;read<queue.Count&&read<192;read++){var c=queue[read];int depth=visited[c],exits=0;maxDepth=Math.Max(maxDepth,depth);foreach(var d in Dirs){var n=c+d;if(!TailOpen(n,s,blocked))continue;exits++;if(visited.ContainsKey(n))continue;visited[n]=depth+1;touches+=recent.TryGetValue(n,out int value)?value:0;queue.Add(n);}if(exits>=3)junctions++;}int runway=Math.Min(28,Math.Max(6,s.Body.Count+2));return Math.Min(visited.Count,runway*4)*1.6+Math.Min(maxDepth,runway)*3+(maxDepth>=runway?36:0)+Math.Min(junctions,5)*5-touches*22+(option==s.GuideDir?3:Math.Min(16,s.ReverseSteps*.8)+Math.Min(18,s.GuideFailures*6)+(s.TurnBias==0?.5:s.TurnBias)*2);}
  bool Retreat(NativeGameplaySnake s){if(!s.Guide.HasValue||s.Body.Count<2)return false;if(s.Guide!=s.Tail){s.Guide=s.Tail;s.GuideDir=s.Tail-s.Body[s.Body.Count-2];s.GuideHistory=new List<Vector2Int>{s.Tail};}var g=s.Guide.Value;var options=Dirs.Where(d=>d!=-s.GuideDir.Value&&CanEnter(g+d,s)).ToList();if(options.Count==0){s.GuideFailures++;return false;}var chosen=options[0];if(options.Count>1){double best=double.NegativeInfinity;foreach(var option in options){double score=TailScore(s,option);bool high=(s.TurnBias==0?.5:s.TurnBias)>=.5;if(score>best+1e-9||Math.Abs(score-best)<=1e-9&&(high?Array.IndexOf(Dirs,option)>Array.IndexOf(Dirs,chosen):Array.IndexOf(Dirs,option)<Array.IndexOf(Dirs,chosen))){best=score;chosen=option;}}}var next=g+chosen;if(PlayerAt(next)!=null)return false;var old=s.Head;s.Body.Add(next);s.Body.RemoveAt(0);s.OldRoute=old-s.Head;s.Dir=s.Head-s.Body[1];s.Guide=next;s.GuideDir=chosen;s.GuideHistory.Add(next);if(s.GuideHistory.Count>64)s.GuideHistory.RemoveAt(0);s.GuideFailures=0;s.ReverseSteps++;return true;}
  public sealed class Junction {public List<Vector2Int> open,branches;public Vector2Int old,key;public bool eligible,returning;public string decision;}
  public Junction GetJunction(NativeGameplaySnake s){var h=s.Head;var neck=s.Body[1];var open=Dirs.Where(d=>d!=neck-h&&CanEnter(h+d,s,allowHunter:true)).ToList();var old=s.OldRoute??s.Dir;var branches=open.Where(d=>d!=old).ToList();bool returning=s.ReturnAvoid==h;return new Junction{open=open,branches=branches,old=old,key=h,returning=returning,eligible=s.ReverseSteps>=1&&branches.Count>0&&!s.Skipped.Contains(h)&&!returning,decision=h.x+","+h.y+"|"+neck.x+","+neck.y+"|"+s.Tail.x+","+s.Tail.y+"|"+s.ReverseSteps+"|"+string.Join(";",branches.Select(d=>d.x+","+d.y))};}
  public void PrepareJunction(NativeGameplaySnake s){if(!s.Reversing||s.Body.Count<2){s.PreparedKey=null;return;}var j=GetJunction(s);if(!j.eligible){s.PreparedKey=null;return;}if(s.PreparedKey!=j.decision){s.PreparedKey=j.decision;s.PreparedTake=Random()<.75;}}
  public bool SnakeStep(NativeGameplaySnake s){if(s.Body.Count==0)return true;if(s.Body.Count==1)return SoloStep(s);
   if(!s.Reversing&&s.Pending.HasValue){var d=s.Pending.Value;s.Pending=null;if(s.Head+d!=s.Body[1]&&CanEnter(s.Head+d,s,allowHunter:true)){if(!Advance(s,d))return false;}else{var options=Forward(s);if(options.Count>0){if(!Advance(s,Choose(s,options)))return false;}else BeginRetreat(s);}}
   else if(s.Reversing){var j=GetJunction(s);bool take=j.eligible&&(s.PreparedKey==j.decision?s.PreparedTake:Random()<.75);s.PreparedKey=null;if(s.ReverseSteps>=1&&j.branches.Count>0&&!take){if(!s.Skipped.Contains(j.key)){s.Skipped.Add(j.key);if(s.Skipped.Count>16)s.Skipped.RemoveAt(0);}if(j.returning)s.ReturnAvoid=null;}if(take){Resume(s,Choose(s,j.branches));s.ReturnAvoid=j.key;s.OldRoute=null;s.BlockedDir=null;}
    else if(!Retreat(s)){if(s.BlockedJunction==j.key)s.BlockedAttempts++;else{s.BlockedJunction=j.key;s.BlockedAttempts=1;}var old=j.open.Where(d=>d==j.old).ToList();double chance=s.BlockedAttempts>=3?1:s.BlockedAttempts==2?.90:.75;bool takeNew=j.branches.Count>0&&(old.Count==0||Random()<chance);var pool=takeNew?j.branches:old.Count>0?old:j.open;if(pool.Count>0){Resume(s,Choose(s,pool));if(takeNew)s.ReturnAvoid=j.key;s.OldRoute=null;s.BlockedDir=null;}}
   }else{var options=Forward(s);if(options.Count>0){if(!Advance(s,Choose(s,options)))return false;}else BeginRetreat(s);}s.Cell=s.Head;TouchHead(s);return true;
  }
  static void TrailPush(NativeGameplaySnake s,Vector2Int cell){s.Trail.Add(cell);if(s.Trail.Count>80)s.Trail.RemoveAt(0);}
  bool SoloStep(NativeGameplaySnake s){var h=s.Head;if(s.Reversing){Vector2Int? recorded=s.Trail.Count>0?(Vector2Int?)s.Trail[s.Trail.Count-1]:null;if(recorded.HasValue){var d=recorded.Value-h;if(Math.Abs(d.x)+Math.Abs(d.y)!=1||d.x*s.Dir.x+d.y*s.Dir.y==1){s.Trail.Clear();recorded=null;}}var open=Dirs.Where(d=>CanEnter(h+d,s)).ToList();var backwards=open.Where(d=>d!=s.Dir&&PlayerAt(h+d)==null).ToList();Vector2Int? continuation=backwards.Contains(-s.Dir)?(Vector2Int?)(-s.Dir):backwards.Where(d=>d.x*s.Dir.x+d.y*s.Dir.y==0).Select(d=>(Vector2Int?)d).FirstOrDefault();var previous=recorded??(continuation.HasValue?(Vector2Int?)(h+continuation.Value):null);var retreat=previous.HasValue?(Vector2Int?)(previous.Value-h):null;var branches=open.Where(d=>d!=s.BlockedDir&&d!=retreat&&d.x*s.Dir.x+d.y*s.Dir.y==0&&PlayerAt(h+d)==null).ToList();
    if(s.ReverseSteps>=1&&open.Count>=3&&branches.Count>0&&Random()<.75){var d=Choose(s,branches);s.Reversing=false;s.BlockedDir=null;s.ReverseSteps=0;s.Dir=d;TrailPush(s,h);s.Body[0]=h+d;}
    else if(previous.HasValue&&PlayerAt(previous.Value)==null&&CanEnter(previous.Value,s)){if(recorded.HasValue)s.Trail.RemoveAt(s.Trail.Count-1);s.Dir=h-previous.Value;s.Body[0]=previous.Value;s.ReverseSteps++;}
    else if(CanEnter(h+s.Dir,s)&&PlayerAt(h+s.Dir)==null){s.Reversing=false;s.BlockedDir=null;s.ReverseSteps=0;TrailPush(s,h);s.Body[0]=h+s.Dir;}
    else if(continuation.HasValue){s.Trail.Clear();s.Dir=-continuation.Value;s.Body[0]=h+continuation.Value;s.ReverseSteps++;}
   }else{var options=Forward(s);if(options.Count>0){var d=Choose(s,options);if(PlayerAt(h+d)!=null&&Yield(s,h,PlayerAt(h+d))){s.HeldDirection=d;return false;}TrailPush(s,h);s.Dir=d;s.Body[0]=h+d;}else if(s.Trail.Count>0||CanEnter(h-s.Dir,s)){s.Reversing=true;s.BlockedDir=s.Dir;s.ReverseSteps=0;}}
   s.Cell=s.Head;if(!s.Reversing&&s.Head!=h)TouchHunterHead(s);TouchHead(s,s.Reversing&&s.Head!=h);return true;
  }
  void Memory(NativeGameplaySnake s){if(CreatureFeuds){MemoryCurrent(s);return;}if(s.LastAnger==0||Time-s.LastAnger<20000+(s.Temperament==0?.5:s.Temperament)*10000)return;double elapsed=Time-(s.LastMemory==0?Time:s.LastMemory);if(s.Anger>s.AngerFloor)s.Anger=Math.Max(s.AngerFloor,s.Anger-.000055*elapsed);s.Threat=Math.Max(0,s.Threat-.000035*elapsed);if(Multiplayer)for(int i=0;i<PlayerCount;i++)s.PersonalThreat[i]=Math.Max(0,s.PersonalThreat[i]-.000035*elapsed);s.LastMemory=Time;}
  void Anger(NativeGameplaySnake s,int amount){if(CreatureFeuds){MemoryCurrent(s);s.LastMemory=Time;}s.Anger+=amount;s.AngerPeak=Math.Max(s.AngerPeak,s.Anger);s.AngerFloor=Math.Max(s.AngerFloor,s.AngerPeak*.5);s.LastAnger=Time;s.Threat+=amount;Provoke(s,amount,amount==1);}
  public static List<(List<Vector2Int> body,Vector2Int dir)> Fragments(NativeGameplaySnake s,int index){var result=new List<(List<Vector2Int>,Vector2Int)>();if(index>0)result.Add((s.Body.Take(index).ToList(),s.Dir));var back=s.Body.Skip(index+1).Reverse().ToList();if(back.Count>0)result.Add((back,back[0]-(back.Count>1?back[1]:s.Body[index])));return result;}
  void CheckContact(){for(int i=Snakes.Count-1;i>=0;i--){int index=Snakes[i].Body.IndexOf(Player.Cell);if(index>=0){Eat(Snakes[i],index);break;}}CollectFruit();if(ScorpionAt(Player.Cell))EatScorpion();var hunter=Hunters.FirstOrDefault(h=>h.Cell==Player.Cell);if(hunter!=null){if(CombatPower)EatHunter(hunter);else if(!PlayerProtected(Player,Time))LoseLife();}}
  public void Eat(NativeGameplaySnake s,int index){if(Player.Dead||!CreatureBitesAllowed(Player,Time)||!Snakes.Contains(s)||index<0||index>=s.Body.Count)return;var old=s.Body.ToArray();if(index==0&&CombatPower){PowerEatHead(s);return;}if(index==0){var move=Player.Cell-Player.Previous;bool safe=s.Body.Count==1?move!=-s.Dir:move==s.Dir;if(!safe){LoseLife();return;}Snakes.Remove(s);Emit("head",s,old,index);Award(125);Ally.Completed(Player,s);if(Multiplayer)Player.Contribution+=.75;}
   else if(index==s.Body.Count-1){var removed=s.Tail;s.Body.RemoveAt(index);if(s.Body.Count==1&&Math.Abs(removed.x-s.Head.x)+Math.Abs(removed.y-s.Head.y)==1&&(s.Trail.Count==0||s.Trail[s.Trail.Count-1]!=removed))TrailPush(s,removed);if(s.Reversing){s.Guide=s.Body.Count>1?(Vector2Int?)s.Tail:null;if(s.Body.Count>1)s.GuideDir=s.Tail-s.Body[s.Body.Count-2];}Anger(s,1);Emit("tail",s,old,index);Award(25);if(Player.IsAI)Ally.TailBite(Player,s);}
   else{var created=new List<NativeGameplaySnake>();foreach(var f in Fragments(s,index)){var child=new NativeGameplaySnake{Id=nextId++,Body=f.body,Dir=f.dir,Palette=s.Palette,Temperament=s.Temperament,TurnBias=Random(),Anger=s.Anger,AngerPeak=s.AngerPeak,AngerFloor=s.AngerFloor,LastAnger=s.LastAnger,LastMemory=s.LastMemory,Threat=s.Threat,LastMove=0};Array.Copy(s.PersonalThreat,child.PersonalThreat,s.PersonalThreat.Length);CopyHunterThreat(s,child);child.Cell=child.Head;Anger(child,2);created.Add(child);}if(Multiplayer)Player.Contribution+=2;int si=Snakes.IndexOf(s);Snakes.RemoveAt(si);Snakes.InsertRange(si,created);Emit("split",s,old,index,created);Award(10);Ally.Split(Player,s,created);}Player.BiteAt=Time+Math.Min(33.25,Player.MoveDuration*.35);Player.BiteEnd=Player.BiteAt+(index==0?140:95);CheckLevelComplete();
  }
  void LoseLife(){if(SessionEnabled){SessionDeath();return;}if(Player.Dead)return;Player.Dead=true;Player.Lives--;Player.PowerUntil=0;Player.PowerBright=false;Event?.Invoke(new NativeWorldEvent{Player=Player,Kind="death",Time=Time});}
  void MoveHunters(){
   foreach(var h in Hunters.ToArray()){
    if(!Hunters.Contains(h)||Time-h.LastMove<95||HoldActive(h))continue;
    var old=h.Cell;var oldDir=h.Dir;bool Open(Vector2Int n)=>HunterCanEnter(h,n);
    var options=Dirs.Where(d=>d!=-h.Dir&&Open(h.Cell+d)).ToList();
    // Preserve forward travel: reverse only at a blocked head/body (ricochet)
    // or a dead end, never merely because a future route looks risky.
    if(options.Count==0)options=Dirs.Where(d=>Open(h.Cell+d)).ToList();
    if(options.Count>0){
     var held=h.HeldDirection;h.HeldDirection=null;
     bool takeHeld=held.HasValue&&(CreatureFeuds?options.Contains(held.Value)&&Brain.HunterStepDanger(h,h.Cell+held.Value)<500:Open(h.Cell+held.Value));
     // An incidental body crossing does not require aggressive intent, even
     // on PICNIC: keep the current route and cut. Only seeking a new victim
     // is governed by the difficulty/intent cooldown.
     bool crossAhead=CreatureFeuds&&options.Contains(h.Dir)&&HunterCutAt(h,h.Cell+h.Dir,out _,out _);
     h.Dir=takeHeld?held.Value:crossAhead?h.Dir:Brain.Choose(h,h.Cell,options,new BrainProfile{kind="hunter",baseline=h.MotherAlive?.22:.57,injury=Math.Min(.18,h.Anger*.16)});
     if(PlayerAt(h.Cell+h.Dir)!=null&&Yield(h,h.Cell,PlayerAt(h.Cell+h.Dir))){h.HeldDirection=h.Dir;Event?.Invoke(new NativeWorldEvent{Kind="hunterTurn",Hunter=h,Time=Time,OldDirection=oldDir});continue;}
     h.Cell+=h.Dir;
    }
    h.LastMove=Time;h.From=old;h.MoveStarted=Time;h.MoveDuration=95;
    if(CreatureFeuds&&h.Cell!=old){
     if(Occupied(h.Cell)&&!TryHunterCut(h,h.Cell))h.Cell=old;
    }
    var victim=PlayerAt(h.Cell);if(victim!=null)using(ForPlayer(victim)){if(PlayerProtected(Player,Time)){h.Cell=old;h.Dir=-h.Dir;}else LoseLife();}
    Event?.Invoke(new NativeWorldEvent{Kind="hunterTurn",Hunter=h,Time=Time,OldDirection=oldDir});
   }
  }
 }
}

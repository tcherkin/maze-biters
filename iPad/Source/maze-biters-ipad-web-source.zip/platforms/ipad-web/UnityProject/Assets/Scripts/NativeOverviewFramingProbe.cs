using System;using System.IO;using System.Linq;using System.Collections;using System.Collections.Generic;using UnityEngine;
namespace MazeBiters.NativeStudy {
 public sealed partial class NativeGameplayStudy {
  [Serializable] sealed class OverviewFrame {public string scene,variant,image;public double sourceZoom,zoom,x,y,topSky,bottomSky,leftSky,rightSky;public bool playersVisible;}
  [Serializable] sealed class OverviewResult {public bool passed;public string quality,note;public int width,height,numericChecks;public string[] checks;public OverviewFrame[] images;}
  IEnumerator ProbeOverviewFraming(){
   var checks=new List<string>();var images=new List<OverviewFrame>();
   void Check(bool b,string name){if(!b)throw new Exception("Overview GPU probe: "+name);checks.Add(name);}
   Directory.CreateDirectory(Path.GetDirectoryName(report));NativeDisplay.TestAspect=16f/9;fixedCamera=true;sessionSmoke=true;
   Reset(12);yield return DrainProbePreparation();Check(world.PlayerCount==2||world.PlayerCount==3,"multiplayer roster available");
   var result=new OverviewResult{quality=quality,numericChecks=NativeOverviewFramingValidation.Run()};
   void Place(params Vector2Int[] cells){for(int i=0;i<world.PlayerCount;i++){var p=world.GetPlayer(i);p.Cell=p.From=p.Previous=world.Brain.Nearest(i<cells.Length?cells[i]:(cells[0]+cells[cells.Length-1])/2);p.LastMove=time-1000;p.Waiting=true;p.ShieldUntil=0;p.Dir=p.Next=i==0?Vector2Int.down:Vector2Int.up;actors[p.Id].turn.Reset();}}
   void Settle(bool overview){gameplayCamera.Reset(realClock);for(int i=0;i<1000;i++){realClock+=16;gameplayCamera.UpdateRoster(world,overview,realClock,time);}}
   void Draw(){preparationLightFrame=true;Render();}
   OverviewFrame Measure(string scene,bool legacy){var f=DisplayFrame;var b=f.ProjectBoard(cameraViewX,cameraViewY,cameraViewZoom);bool visible=true;
    for(int i=0;i<world.PlayerCount;i++){var p=world.GetPlayer(i).Visual(time);double px=b.x+(p.x+.5)*16*cameraViewZoom,py=b.y+(p.y+.5)*16*cameraViewZoom,r=12*cameraViewZoom;visible&=px-r>=-.001&&px+r<=f.Width+.001&&py-r>=-.001&&py+r<=f.Height+.001;}
    return new OverviewFrame{scene=scene,variant=legacy?"before":"after",image=scene+"-"+(legacy?"before":"after")+".png",sourceZoom=gameplayCamera.Zoom,zoom=cameraViewZoom,x=cameraViewX,y=cameraViewY,topSky=Math.Max(0,b.y),bottomSky=Math.Max(0,f.Height-b.yMax),leftSky=Math.Max(0,b.x),rightSky=Math.Max(0,f.Width-b.xMax),playersVisible=visible};
   }
   void Pair(string name){string state=MenuFullState,clock=ScalarClock(gameplayCamera);Color32[] before=null;
    foreach(bool legacy in new[]{true,false}){NativeOverviewFraming.ComparisonLegacy=legacy;Draw();Draw();var frame=Measure(name,legacy);images.Add(frame);Check(frame.playersVisible,name+" / "+frame.variant+" keeps every silhouette visible");Capture(Path.Combine(Path.GetDirectoryName(report),frame.image));
     if(gameplayCamera.Zoom==2){var texture=DisplayRead(target);var pixels=texture.GetPixels32();if(legacy)before=pixels;else Check(before.SequenceEqual(pixels),name+" / existing close view is pixel-identical");Destroy(texture);}
    }
    Check(MenuFullState==state&&ScalarClock(gameplayCamera)==clock,name+" / world, RNG and original camera clocks unchanged");
   }
   Place(new Vector2Int(1,1),new Vector2Int(34,23));Settle(true);Pair("overview");
   Check(images.Last().topSky<.001&&images.Last().bottomSky<.001,"full overview touches top and bottom");yield return null;
   Settle(false);Pair("opposite");Check(gameplayCamera.Zoom==1&&images.Last().topSky<.001&&images.Last().bottomSky<.001,"opposite top/bottom players keep height-filling overview");yield return null;
   Place(new Vector2Int(1,1),new Vector2Int(18,1));Settle(false);Pair("top-medium");yield return null;
   Place(new Vector2Int(1,23),new Vector2Int(18,23));Settle(false);Pair("bottom-medium");yield return null;
   Place(new Vector2Int(1,1),new Vector2Int(5,1));Settle(false);Pair("top-close");yield return null;
   Place(new Vector2Int(1,23),new Vector2Int(5,23));Settle(false);Pair("bottom-close");yield return null;
   Place(new Vector2Int(17,11),new Vector2Int(19,13));Settle(false);Pair("centre");yield return null;
   // Follow the real roster easing during a continuous separation and reunion,
   // checking both the final projection and inverse pointer at every step.
   NativeOverviewFraming.ComparisonLegacy=false;gameplayCamera.Reset(realClock);double previous=1.08,maxDelta=0;
   for(int i=0;i<1440;i++){
    int row=1+(int)Math.Round(22*(i<720?i/720.0:(1440-i)/720.0));Place(new Vector2Int(1,1),new Vector2Int(1,row));realClock+=1000.0/120;
    gameplayCamera.UpdateRoster(world,false,realClock,time);ApplyGameplayCamera();maxDelta=Math.Max(maxDelta,Math.Abs(cameraViewZoom-previous));previous=cameraViewZoom;
    var f=DisplayFrame;var b=f.ProjectBoard(cameraViewX,cameraViewY,cameraViewZoom);
    var point=new Vector2(f.Width/2,f.Height/2);f.WorldPoint(point,cameraViewX,cameraViewY,cameraViewZoom,out double wx,out double wy);
    var v=camera.WorldToViewportPoint(new Vector3((float)wx,(float)-wy,0));if(Math.Abs(v.x-.5)>.00001||Math.Abs(v.y-.5)>.00001)throw new Exception("Fitted projection/pointer mismatch");
    if(i%180==0){Draw();yield return null;}
   }
   Check(maxDelta<.018,"roster separation/reunion has continuous scale (max "+maxDelta.ToString("F5")+")");
   // Same logical crop and native image density in both render qualities.
   result.width=target.width;result.height=target.height;Check(target.width==(quality=="4k"?3840:1920)&&target.height==(quality=="4k"?2160:1080),"native widescreen output");
   Check(bank.Size==(quality=="4k"?160:80),"original separate HD/4K sprites");
   result.passed=true;result.checks=checks.ToArray();result.images=images.ToArray();result.note="Frozen generated level with staged participant positions. Before/after differ only by presentation framing; original solver, world state, animations and effects retained. No performance claim. The continuous-separation test checks camera projection, not FPS.";
   File.WriteAllText(report,JsonUtility.ToJson(result,true));Application.Quit();
  }
 }
}

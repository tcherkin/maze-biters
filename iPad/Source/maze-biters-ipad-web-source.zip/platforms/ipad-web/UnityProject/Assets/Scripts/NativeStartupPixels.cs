using System;
using System.IO;
using Unity.Collections;
namespace MazeBiters.NativeStudy {
 // In-memory, lossless RGBA word matches for the short-lived boot cache only.
 // No quantization/predictor, native texture format or live-level cache change.
 // Incompressible chunks are stored raw, with at most one byte overhead.
 public static class NativeStartupPixels {
  internal static byte[] Pack(uint[] source,int count,uint[] work){
   int used=Encode(source,count,work,new int[65536],out bool raw);var result=new byte[1+used*4];result[0]=raw?(byte)0:(byte)1;
   Buffer.BlockCopy(raw?source:work,0,result,1,result.Length-1);return result;
  }
  internal static int Encode(uint[] source,int count,uint[] work,int[] table,out bool raw){
   Array.Clear(table,0,table.Length);
   int used=0,literal=0,p=0;
   void Literals(int end){int n=end-literal;if(n==0)return;work[used++]=(uint)n;Array.Copy(source,literal,work,used,n);used+=n;}
   while(p+3<count){
    uint hash=unchecked(source[p]*2654435761u^source[p+1]*2246822519u^source[p+2]*3266489917u);int slot=(int)(hash>>16),prior=table[slot]-1;table[slot]=p+1;
    if(prior<0||source[prior]!=source[p]||source[prior+1]!=source[p+1]||source[prior+2]!=source[p+2]||source[prior+3]!=source[p+3]){p++;continue;}
    int end=p+4;while(end<count&&source[prior+end-p]==source[end])end++;
    Literals(p);work[used++]=unchecked((uint)-(end-p));work[used++]=(uint)(p-prior);literal=p=end;
   }
   Literals(count);raw=used>=count;return raw?count:used;
  }
  internal static void UnpackNative(NativeArray<uint> block,bool raw,uint[] target,int count){
   if(!block.IsCreated||count<0||count>target.Length)throw new InvalidDataException("Invalid native startup pixel block");
   if(raw){if(block.Length!=count)throw new InvalidDataException("Raw native startup pixel size");NativeArray<uint>.Copy(block,0,target,0,count);return;}
   int input=0,output=0;
   while(input<block.Length){int n=unchecked((int)block[input++]);
    if(n==0||n==int.MinValue||Math.Abs((long)n)>count-output)throw new InvalidDataException("Native startup pixel run length");
    int words=Math.Abs(n);
    if(n>0){if(words>block.Length-input)throw new InvalidDataException("Truncated native startup pixels");NativeArray<uint>.Copy(block,input,target,output,words);input+=words;}
    else{if(input==block.Length)throw new InvalidDataException("Truncated native startup match");uint distance=block[input++];if(distance==0||distance>output)throw new InvalidDataException("Native startup match offset");for(int end=output+words,j=output;j<end;j++)target[j]=target[j-(int)distance];}
    output+=words;
   }
   if(output!=count)throw new InvalidDataException("Incomplete native startup pixels");
  }
  internal static void Unpack(byte[] block,byte[] target,int count){
   if(count<0||count>target.Length||(count&3)!=0)throw new InvalidDataException("Invalid startup pixel size");
   var words=new uint[count/4];UnpackWords(block,words,words.Length);Buffer.BlockCopy(words,0,target,0,count);
  }
  internal static void UnpackWords(byte[] block,uint[] target,int count){
   if(block==null||block.Length<1||count<0||count>target.Length)throw new InvalidDataException("Invalid startup pixel block");
   if(block[0]==0){if(block.Length!=count*4+1)throw new InvalidDataException("Raw startup pixel size");Buffer.BlockCopy(block,1,target,0,count*4);return;}
   if(block[0]!=1||(block.Length-1)%4!=0)throw new InvalidDataException("Startup pixel encoding");
   int input=1,output=0;
   while(input<block.Length){int n=BitConverter.ToInt32(block,input);input+=4;
    if(n==0||n==int.MinValue||Math.Abs((long)n)>count-output)throw new InvalidDataException("Startup pixel run length");
    int words=Math.Abs(n),bytes=words*4;
    if(n>0){if(bytes>block.Length-input)throw new InvalidDataException("Truncated startup pixels");Buffer.BlockCopy(block,input,target,output*4,bytes);input+=bytes;}
    else{if(block.Length-input<4)throw new InvalidDataException("Truncated startup match");
     uint distance=BitConverter.ToUInt32(block,input);input+=4;if(distance==0||distance>output)throw new InvalidDataException("Startup match offset");int end=output+words;
     for(int j=output;j<end;j++)target[j]=target[j-(int)distance];
    }
    output+=words;
   }
   if(output!=count)throw new InvalidDataException("Incomplete startup pixels");
  }
  public static int Validate(){
   var random=new Random(5817);int checks=0;
   foreach(int length in new[]{0,1,2,3,4,7,128,257,4096,368640})for(int pattern=0;pattern<7;pattern++){
    var source=new uint[length];for(int i=0;i<length;i++)source[i]=pattern==0?0:pattern==1?uint.MaxValue:pattern==2?(uint)(i%2):pattern==3?(uint)(i/3):pattern==4?(uint)(i/127):pattern==5?(uint)random.Next():i%31<27?0:(uint)random.Next();
    var packed=Pack(source,length,new uint[length+1]);var actual=new byte[length*4];Unpack(packed,actual,actual.Length);
    var expected=new byte[actual.Length];Buffer.BlockCopy(source,0,expected,0,expected.Length);
    if(packed.Length>actual.Length+1)throw new Exception("Startup cache expansion");
    for(int i=0;i<actual.Length;i++)if(actual[i]!=expected[i])throw new Exception("Startup cache pixel mismatch");checks++;
    var work=new uint[length+1];int used=Encode(source,length,work,new int[65536],out bool raw);
    using(var native=new NativeArray<uint>(used,Allocator.Temp)){NativeArray<uint>.Copy(raw?source:work,0,native,0,used);var roundTrip=new uint[length];UnpackNative(native,raw,roundTrip,length);for(int i=0;i<length;i++)if(roundTrip[i]!=source[i])throw new Exception("Native startup pixel mismatch");checks++;}
   }
   foreach(var invalid in new[]{new byte[0],new byte[]{2},new byte[]{0},new byte[]{1,0,0,0,0},new byte[]{1,255,255,255,255}}){try{Unpack(invalid,new byte[4],4);throw new Exception("Corrupt startup block accepted");}catch(InvalidDataException){checks++;}}
   return checks;
  }
 }
}

using System;using UnityEngine;
namespace MazeBiters.NativeStudy {
 public static class NativeWideWorldValidation {
  public static int Run(){int checks=0;void Check(bool ok,string label){checks++;if(!ok)throw new Exception("Wide world: "+label);}
   var wide=new NativeFrame(16f/9);var outView=wide.ProjectBoard(288,200,1);
   Check(Math.Abs(outView.x-96)<.001&&Math.Abs(wide.Width-outView.xMax-96)<.001,"zoom-out has symmetric sky");
   var centre=wide.ProjectBoard(288,200,2);Check(centre.x<0&&centre.xMax>wide.Width,"zoom-in fills whole width");
   var left=wide.ProjectBoard(144,200,2);var right=wide.ProjectBoard(432,200,2);
   Check(Math.Abs(left.x-96)<.001&&left.xMax>wide.Width,"left edge retains only left sky");
   Check(right.x<0&&Math.Abs(wide.Width-right.xMax-96)<.001,"right edge retains only right sky");
   float previous=96;for(int i=0;i<=200;i++){float space=Math.Max(0,wide.ProjectBoard(288,200,1+i/200.0).x);Check(space<=previous+.001&&previous-space<=1.441,"continuous shrinking border");previous=space;}
   Check(wide.PointerCell(new Vector2(20,230),288,200,2,out _),"newly revealed side area is navigable");
   Check(!wide.PointerCell(new Vector2(20,230),144,200,2,out _),"exposed left sky is not navigable");
   Check(!wide.PointerCell(new Vector2(748,230),432,200,2,out _),"exposed right sky is not navigable");
   Check(!wide.PointerCell(new Vector2(384,16),288,200,2,out _),"HUD is never a movement target");
   Check(Math.Abs(NativeFrame.EdgeY(100,2)-90)<.000001&&Math.Abs(NativeFrame.EdgeY(300,2)-310)<.000001,"20 screen-unit sky gutters at vertical edges");
   Check(NativeFrame.EdgeY(200,2)==200&&NativeFrame.EdgeY(200,1)==200,"centre and full overview unchanged");
   Check(wide.KeepVisibleY(100,90,2,185)==97,"top gutter yields to opposite participant");
   Check(wide.KeepVisibleY(300,310,2,215)==303,"bottom gutter yields to opposite participant");
   Check(wide.KeepVisibleY(100,90,2,24)==90,"unobstructed top breathing room retained");
   Check(wide.KeepVisibleY(100,90,2,380)==90,"off-screen actor cannot jerk presentation camera");
   double lastSafe=wide.KeepVisibleY(100,90,2,175);for(int i=1;i<=5000;i++){double safe=wide.KeepVisibleY(100,90,2,175+i*.01);Check(Math.Abs(safe-lastSafe)<.011,"participant silhouette crossing frame cannot snap decorative offset");lastSafe=safe;}
   foreach(double z in new[]{1.01,1.25,1.5,2})foreach(double cy in new[]{200/z,200,400-200/z})for(int py=0;py<=400;py++){
    double half=200/z,desired=NativeFrame.EdgeY(cy,z),safe=wide.KeepVisibleY(cy,desired,z,py);
    Check(safe>=Math.Min(cy,desired)-.00001&&safe<=Math.Max(cy,desired)+.00001,"roster safety cannot overshoot original framing");
    if(py-12>=cy-half&&py+12<=cy+half)Check(py-12>=safe-half-.00001&&py+12<=safe+half+.00001,"visible player silhouette remains inside frame");
   }
   double lastY=NativeFrame.EdgeY(100,2);for(int i=1;i<=2000;i++){double y=NativeFrame.EdgeY(100+i*.1,2);Check(y>=lastY&&y-lastY<.15,"continuous vertical edge easing");lastY=y;}
   var drift=wide.SkyOffset(388,250)-wide.SkyOffset(288,200);Check(Math.Abs(drift.x-16)<.0001&&Math.Abs(drift.y-8)<.0001,"distant sky has 16 percent pan, independent of zoom");
   var overlay=new NativeFrame(16f/9,true);
   var upper=overlay.ProjectBoard(288,overlay.CameraY(100,2),2);var lower=overlay.ProjectBoard(288,overlay.CameraY(300,2),2);
   Check(Math.Abs(upper.y-52)<.00001&&Math.Abs(overlay.Height-lower.yMax-52)<.00001,"matching 52-unit sky at top and bottom");
   Check(Math.Abs(overlay.Board.y-16)<.00001&&Math.Abs(overlay.Height-overlay.Board.yMax-16)<.00001,"whole maze centred at overview");
   Check(overlay.ProjectBoard(288,200,2).y<0&&overlay.ProjectBoard(288,200,2).yMax>overlay.Height,"centre zoom covers full screen behind HUD");
   Check(overlay.PointerCell(new Vector2(384,16),288,200,2,out var underHud)&&underHud==new Vector2Int(18,6),"newly visible world under HUD remains navigable");
   Check(!overlay.PointerCell(new Vector2(384,40),288,overlay.CameraY(100,2),2,out _),"sky under HUD is not navigable");
   double previousOverlay=overlay.CameraY(100,2);
   for(int i=1;i<=2000;i++){double cy=100+i*.1,next=overlay.CameraY(cy,2);Check(next>=previousOverlay&&next-previousOverlay<.19,"overlay edge easing is continuous");Check(Math.Abs(next+overlay.CameraY(400-cy,2)-400)<.00001,"overlay edge easing is vertically symmetric");previousOverlay=next;}
   foreach(double z in new[]{1.01,1.25,1.5,2})foreach(double cy in new[]{200/z,200,400-200/z})for(int py=0;py<=400;py++){
    double half=overlay.Height/2/z,desired=overlay.CameraY(cy,z),safe=overlay.KeepVisibleY(cy,desired,z,py);
    if(py-12>=cy-half&&py+12<=cy+half)Check(py-12>=safe-half-.00001&&py+12<=safe+half+.00001,"overlay view keeps visible player silhouettes");
    Check(Math.Abs(safe+overlay.KeepVisibleY(400-cy,overlay.CameraY(400-cy,z),z,400-py)-400)<.00001,"player-safe space is symmetric at either end");
   }
   foreach(bool overlayHud in new[]{false,true})foreach(float aspect in new[]{4f/3,16f/9,16f/10,21f/9,9f/16})foreach(double z in new[]{1,1.25,1.68,2})foreach(double cx in new[]{288/z,288,576-288/z}){
    var f=new NativeFrame(aspect,overlayHud);double cy=200;var b=f.ProjectBoard(cx,cy,z);
    for(int y=0;y<25;y++)for(int x=0;x<36;x++){
     var p=new Vector2((float)(b.x+(x+.5)*16*z),(float)(b.y+(y+.5)*16*z));
     bool visible=p.x>=0&&p.x<f.Width&&p.y>=f.TopInset&&p.y<f.Height;bool hit=f.PointerCell(p,cx,cy,z,out var c);
     Check(hit==visible&&(!hit||c==new Vector2Int(x,y)),"projection / pointer uses same full frustum");
    }
   }
   return checks;
  }
 }
}


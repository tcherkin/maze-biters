using System;using UnityEngine;
namespace MazeBiters.NativeStudy {
 public static class NativeHudContactValidation {
  public static int Run(){
   int count=0;void Check(bool value,string label){count++;if(!value)throw new Exception("HUD contact easing: "+label);}
   foreach(double dt in new[]{1000.0/30,1000.0/60,1000.0/120,1000.0/144}){
    double alpha=1,velocity=0;
    for(int i=0;i<Math.Round(1200/dt);i++){double next=NativeHud.FadeContact(alpha,ref velocity,true,dt);Check(next<=alpha&&next>=NativeHud.ContactOpacity,"bounded gradual fade");alpha=next;}
    Check(alpha==NativeHud.ContactOpacity&&velocity==0,"settles exactly at 25 percent");
    for(int i=0;i<Math.Round(1800/dt);i++){double next=NativeHud.FadeContact(alpha,ref velocity,false,dt);Check(next>=alpha&&next<=1,"bounded gradual recovery");alpha=next;}
    Check(alpha==1&&velocity==0,"settles exactly opaque");
   }
   double a=1,b=1,va=0,vb=0;
   a=NativeHud.FadeContact(a,ref va,true,16);Check(a>.98&&a<1,"soft onset without instant dimming");
   for(int i=1;i<6;i++)a=NativeHud.FadeContact(a,ref va,true,16);for(int i=0;i<12;i++)b=NativeHud.FadeContact(b,ref vb,true,8);
   Check(Math.Abs(a-b)<1e-12&&Math.Abs(va-vb)<1e-12,"frame-rate independent opacity and velocity");
   Check(a>.65&&a<.8,"still visibly transitioning after 96ms");
   for(int i=6;i<22;i++)a=NativeHud.FadeContact(a,ref va,true,16);
   Check(a<.29&&a>.25,"main fade completes in about 350ms");
   double before=a,velocityBefore=va;
   double unchanged=NativeHud.FadeContact(a,ref va,false,0);
   Check(unchanged==a&&va==velocityBefore,"retarget preserves both value and velocity");
   a=NativeHud.FadeContact(a,ref va,false,16);
   Check(Math.Abs(a-before)<.03,"retarget has no visible step");
   for(int i=0;i<2000;i++){a=NativeHud.FadeContact(a,ref va,i%29<15,8);Check(a>=.25&&a<=1&&double.IsFinite(va),"rapid contact changes remain bounded");}
   a=.25;va=0;for(int i=0;i<34;i++)a=NativeHud.FadeContact(a,ref va,false,16);
   Check(a>.96&&a<1,"main recovery completes in about 550ms");
   double v1=0,v2=0;
   Check(NativeHud.FadeContact(1,ref v1,true,10000)==NativeHud.FadeContact(1,ref v2,true,50)&&v1==v2,"stalled frame capped");
   return count;
  }
 }
}

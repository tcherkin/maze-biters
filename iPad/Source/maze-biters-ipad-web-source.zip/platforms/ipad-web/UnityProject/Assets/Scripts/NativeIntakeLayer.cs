using System;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Rendering;
namespace MazeBiters.NativeStudy {
 // Same fixed 160x160 world-aligned scratch as live-snake.js, independent of output resolution.
 public sealed class NativeIntakeLayer:IDisposable {
  readonly Camera camera;readonly Mesh quad;readonly CommandBuffer cmd=new CommandBuffer();readonly RenderTexture aperture,rotated,paint,emission;
  readonly Material maskPaint;Material erase;public readonly Material Display,Emission;readonly MeshRenderer visible;
  readonly Dictionary<string,(NativeSnake lit,NativeSnake glow)> tails=new Dictionary<string,(NativeSnake,NativeSnake)>();
  readonly List<(NativeSnake lit,NativeSnake glow)> active=new List<(NativeSnake,NativeSnake)>();public Matrix4x4 Transform;public bool Active{get;private set;}
  static RenderTexture Surface(){var t=new RenderTexture(160,160,0,RenderTextureFormat.ARGB32){filterMode=FilterMode.Bilinear,wrapMode=TextureWrapMode.Clamp};t.Create();return t;}
  public NativeIntakeLayer(Mesh quad){this.quad=quad;aperture=Surface();rotated=Surface();paint=Surface();emission=Surface();maskPaint=new Material(Shader.Find("MazeBiters/PremultipliedImage")){mainTexture=aperture};Display=new Material(Shader.Find("MazeBiters/IntakeComposite")){mainTexture=paint};Display.SetTexture("_MaskTex",rotated);Emission=new Material(Display){mainTexture=emission};erase=new Material(Shader.Find("MazeBiters/EraseIntake")){mainTexture=paint};erase.SetTexture("_MaskTex",rotated);
   camera=new GameObject("Mouth intake scratch").AddComponent<Camera>();camera.enabled=false;camera.orthographic=true;camera.orthographicSize=8;camera.aspect=1;camera.transform.position=new Vector3(8,-8,-10);camera.cullingMask=0;
   var go=new GameObject("Tail between the lips");go.AddComponent<MeshFilter>().sharedMesh=quad;visible=go.AddComponent<MeshRenderer>();visible.sharedMaterial=Display;visible.sortingOrder=11;visible.enabled=false;
  }
  public void Begin(){active.Clear();Active=false;visible.enabled=false;}
  public void Add(string palette,SnakePose pose){if(pose.solo||pose.soloAmount>=1||active.Count>=8)return;string key=palette+":"+active.Count;if(!tails.TryGetValue(key,out var pair)){pair=(new NativeSnake(palette,"lit",null,true),null);pair.glow=new NativeSnake(palette,"emission",pair.lit,true);tails.Add(key,pair);}pair.lit.Prepare(pose,true);pair.glow.Prepare(pose,true);active.Add(pair);}
  // Readback exists ONLY for the explicit test runner, never in interactive play.
  public int Probe(){if(!Active)return 0;var old=RenderTexture.active;Color32[] Read(RenderTexture rt){RenderTexture.active=rt;var tex=new Texture2D(160,160,TextureFormat.RGBA32,false);tex.ReadPixels(new Rect(0,0,160,160),0,0);tex.Apply();var result=tex.GetPixels32();UnityEngine.Object.Destroy(tex);return result;}var a=Read(paint);var b=Read(rotated);RenderTexture.active=old;int n=0;for(int i=0;i<a.Length;i++)if(a[i].a*b[i].a>255)n++;return n;}
  public void Render(NativeTurnBank bank,NativeTurnActor actor,TurnPose pose,int mouth,NativePlayer player,double t){if(active.Count==0||player.Dead||player.Dir.y<0)return;
   bank.RenderIntake(actor,pose,mouth,aperture);var p=player.Visual(t);float x=(p.x+.5f)*16,y=-(p.y+.5f)*16;camera.transform.position=new Vector3(x,y,-10);Transform=Matrix4x4.TRS(new Vector3(x-8,y+8,-1),Quaternion.identity,new Vector3(16,16,1));visible.transform.position=new Vector3(x-8,y+8,-1);visible.transform.localScale=new Vector3(16,16,1);
   var q=Quaternion.Euler(0,0,(float)-player.Tilt);var mask=Matrix4x4.TRS(new Vector3(x,y,0)-q*new Vector3(8,-8,0),q,new Vector3(16,16,1));
   cmd.Clear();cmd.SetRenderTarget(rotated);cmd.ClearRenderTarget(false,true,Color.clear);cmd.SetViewProjectionMatrices(camera.worldToCameraMatrix,camera.projectionMatrix);cmd.DrawMesh(quad,mask,maskPaint);Graphics.ExecuteCommandBuffer(cmd);
   void Capture(RenderTexture target,bool glow){camera.targetTexture=target;cmd.Clear();cmd.SetRenderTarget(target);cmd.ClearRenderTarget(false,true,Color.clear);cmd.SetViewProjectionMatrices(camera.worldToCameraMatrix,camera.projectionMatrix);foreach(var a in active)(glow?a.glow:a.lit).Submit(cmd,1,camera);Graphics.ExecuteCommandBuffer(cmd);}
   Capture(paint,false);Capture(emission,true);Active=true;visible.enabled=true;
  }
  public void EraseForeground(CommandBuffer c){if(Active)c.DrawMesh(quad,Transform,erase);} public void Submit(CommandBuffer c,bool glow=false){if(Active)c.DrawMesh(quad,Transform,glow?Emission:Display);}
  public void Dispose(){foreach(var p in tails.Values){p.lit.Dispose();p.glow.Dispose();}cmd.Dispose();if(camera){camera.targetTexture=null;UnityEngine.Object.Destroy(camera.gameObject);}if(visible)UnityEngine.Object.Destroy(visible.gameObject);foreach(var rt in new[]{aperture,rotated,paint,emission}){if(RenderTexture.active==rt)RenderTexture.active=null;rt.Release();UnityEngine.Object.Destroy(rt);}UnityEngine.Object.Destroy(erase);UnityEngine.Object.Destroy(maskPaint);UnityEngine.Object.Destroy(Display);UnityEngine.Object.Destroy(Emission);}
 }
}

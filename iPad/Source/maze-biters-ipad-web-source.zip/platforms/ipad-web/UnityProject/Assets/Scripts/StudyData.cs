using System;
namespace MazeBiters.NativeStudy {
 [Serializable] public class ArtManifest { public int schema; public ArtProfile[] profiles; }
 [Serializable] public class ArtProfile { public string quality; public ArtSet[] sets; }
 [Serializable] public class ArtSet { public string key,family,palette,light,direction; public int size; public string @base; public Patch mouth; public Patch[] blink; }
 [Serializable] public class Patch { public string file; public int x,y,width,height,stride,cellWidth,columns,frames,guard; public bool mirrorX; }
 [Serializable] public class LevelData { public int schema,seed,columns,rows,tile; public string sourceVersion; public string[] geometry; public double playerStepMs,snakeStepMs,turnMs; public PlayerStart[] players; }
 [Serializable] public class PlayerStart { public int id,x,y,dx,dy; }
}

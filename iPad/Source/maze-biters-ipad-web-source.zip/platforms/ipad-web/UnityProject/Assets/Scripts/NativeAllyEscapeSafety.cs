using System;
using UnityEngine;
namespace MazeBiters.NativeStudy {
 public sealed partial class NativeAllyBrain {
  readonly NativeAllyEscapeTopology escapeGeometry=new NativeAllyEscapeTopology();
  readonly NativePlayer escapeDefender=new NativePlayer();

  bool DeeperEscapeTarget(NativePlayer p,Vector2Int c){
   if(!foresightReady||!Balance.Maximum||escapeGeometry.Depth(c)<=0)return false;
   return escapeGeometry.Gate(c)!=escapeGeometry.Gate(p.Cell)||escapeGeometry.Depth(c)>escapeGeometry.Depth(p.Cell);
  }
  bool ClosedEscapeStep(NativePlayer p,Vector2Int first){
   // Bridges between loops have a single entrance too, but provide onward
   // escape space. Only an inward step into a pruned branch is a blind tunnel.
   return escapeGeometry.IsDeeper(p.Cell,first);
  }
  bool Escaping(NativePlayer p){
   var a=S(p);if(a.directive?.type=="flee"||a.retreat!=null||a.thought=="blocked-retreat"||a.thoughtDanger>=105)return true;
   if(Combat(p,foresightTime))return false;
   // The prey being safely eaten is not a pursuer behind us. Other nearby
   // creatures still activate escape caution, using actual paths through walls.
   foreach(var snake in w.Snakes)if(snake!=a.locked&&!snake.Body.Contains(a.thoughtTarget)&&Distance(p.Cell,snake.Head)<=4)return true;
   foreach(var hunter in w.Hunters)if(Distance(p.Cell,hunter.Cell)<=4)return true;
   return false;
  }
  double ReturnDuration(NativePlayer p,int steps){
   double elapsed=0;
   // Both actor clocks already incorporate game speed. Preserve their original
   // timing; this is a relative interception forecast, not a real-time timer.
   for(int i=0;i<steps;i++)elapsed+=PredictPlayerDelay(p,foresightTime+elapsed,foresightTime);
   return elapsed;
  }
  double ConservativeGateArrival(NativePlayer p,Vector2Int first,double until,NativeCreature ignored,double acquired){
   double best=Inf;
   int GateDistance(Vector2Int cell){
    if(cell==p.Cell)return 0;int nearest=int.MaxValue;
    foreach(var d in dirs){int distance=escapeGeometry.Distance(p.Cell+d,cell);if(distance>=0)nearest=Math.Min(nearest,distance+1);}
    return nearest==int.MaxValue?-1:nearest;
   }
   double protection=Math.Max(Math.Max(p.PowerUntil,p.ShieldUntil)-foresightTime,acquired);
   void Creature(NativeCreature actor,Vector2Int cell,double period,double born=0){
    // An actor ahead inside this blind branch cannot independently seal its
    // gate without first meeting us. That contact is assessed by the ordinary
    // route forecast; do not count edible prey twice as an outside interceptor.
    if(ReferenceEquals(actor,ignored)&&actor!=null||!w.Floor(cell)||protection>until||escapeGeometry.Distance(first,cell)>=0)return;
    int distance=GateDistance(cell);if(distance<0)return;
    double arrival=born+Math.Max(0,distance-1)*period;
    best=Math.Min(best,Math.Max(arrival,protection));
   }
   foreach(var snake in w.Snakes)if(snake.Body.Count>0)Creature(snake,snake.Head,218);
   foreach(var hunter in w.Hunters)Creature(hunter,hunter.Cell,95);
   foreach(var egg in w.Eggs)if(!w.EggCovered(egg))Creature(null,egg.Cell,95,Math.Max(0,egg.Born+13000-foresightTime));
   escapeDefender.Dead=p.Dead;escapeDefender.Lives=p.Lives;escapeDefender.Score=p.Score;
   escapeDefender.ShieldUntil=p.ShieldUntil;escapeDefender.PowerUntil=Math.Max(p.PowerUntil,foresightTime+acquired);
   if(w.Competitive)foreach(var other in Others(p)){
    if(other.Dead||other.Lives<=0||ReferenceEquals(other,ignored)||!w.Floor(other.Cell))continue;
    int distance=GateDistance(other.Cell);if(distance<0)continue;
    // Bound each existing speed source independently: a powered rival can
    // sustain a combo at up to four times base speed. Contact permissions
    // still come exclusively from score, shield and genuine Power below.
    double rivalSpeed=NativeGameplayWorld.CombineMovementSpeed(other.PowerUntil>foresightTime?1:0,other.Combo.Active?1:other.Combo.StrengthAt(foresightTime));
    double arrival=Math.Max(0,distance-1)*95/rivalSpeed;
    if(arrival>until)continue;
    // Score, shield and power can change who eats whom at expiry. Keep the
    // original contact rules, including an already active rival shield.
    void ContactAt(double at){if(at>=arrival&&at<=until&&w.CanEatPlayer(other,escapeDefender,foresightTime+at))best=Math.Min(best,at);}
    ContactAt(arrival);ContactAt(until);ContactAt(acquired);
    ContactAt(other.PowerUntil-foresightTime);ContactAt(other.ShieldUntil-foresightTime);
    ContactAt(p.PowerUntil-foresightTime);ContactAt(p.ShieldUntil-foresightTime);
   }
   return best;
  }
 }
}

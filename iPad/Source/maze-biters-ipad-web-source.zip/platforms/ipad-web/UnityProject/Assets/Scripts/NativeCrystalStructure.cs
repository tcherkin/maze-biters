using System;
using System.Collections.Generic;
using UnityEngine;
namespace MazeBiters.NativeStudy {
 [Serializable]public sealed class CrystalStructureAudit {
  // Legacy graph counters remain serializable for reading older reports. The
  // orthogonal construction below does not claim to resolve every corner-art joint.
  public int components,boundaryAnchors,seamSegments,pairedAnchors,tJunctions,unresolvedAnchors,cornerAnchors,floatingEndpoints;
  public double maxAnchorErrorPixels;
  public bool orthogonalGrid;
  public int sourceJointSamples,boundarySegments,verticalDividers,horizontalDividers;
  public double gridPeriodX,gridPeriodY,gridPhaseX,gridPhaseY,sourceVerticalPeriod,perimeterInset,maxInternalTilt;
  // Curve dimensions use native texture pixels, like perimeterInset above.
  public int curveContours,curveProfileSamples;public double minCurveInset,maxCurveInset,curveJoinError,curveJunctionRadius;
  public bool curveConvex;public double curveMinRadius,curveMaxRadius,curveMinShift,curveMaxShift,curveFitMaxError,curveTangentError;
  public int curveSamplerSamples;public double curveSamplerMaxError;
 }
 public struct CrystalFacetSample {
  public double distance,nx,ny,u,v,straightDistance,perimeterClearance,circularPerimeterClearance;
  public bool roundedCorner,outsidePanelDomain,authoredCurve,curveJunction;
 }
 public sealed partial class NativeMazeArtwork {
  struct CorePoint {public double x,y;public CorePoint(double x,double y){this.x=x;this.y=y;}}
  sealed class CoreBoundary {public CorePoint a,b,n;public int component;public bool vertical;}
  sealed class CoreTerritory {public Component shape;}
  const int CoreCurveSamples=129;
  sealed class CoreCurve {public int mask,sx,sy;public double shift,radius;}
  sealed class CoreStructure {
   public readonly int[,] owner=new int[35,24];
   public readonly List<CoreTerritory> territories=new List<CoreTerritory>();
   public readonly List<CoreBoundary> boundaries=new List<CoreBoundary>();
   public readonly List<int>[] bins=new List<int>[35*24];
   public readonly CoreCurve[] curves=new CoreCurve[4];
   public double phaseX,phaseY,periodX,periodY;
  }
  struct CoreConstraint {public double d,nx,ny,coordinate,lo,hi;public bool finite;}
  CoreStructure coreStructure;
  public CrystalStructureAudit CoreStructureAudit{get;private set;}
  double CoreCurveAlpha(byte[] wall,int mask,double x,double y){
   double px=Math.Max(0,Math.Min(glassSize-1,x-.5)),py=Math.Max(0,Math.Min(glassSize-1,y-.5));int ix=(int)px,iy=(int)py,jx=Math.Min(glassSize-1,ix+1),jy=Math.Min(glassSize-1,iy+1);
   double fx=px-ix,fy=py-iy;
   byte A(int xx,int yy)=>wall[(yy*16*glassSize+mask*glassSize+xx)*4+3];
   return (A(ix,iy)*(1-fx)+A(jx,iy)*fx)*(1-fy)+(A(ix,jy)*(1-fx)+A(jx,jy)*fx)*fy;
  }
  void PrepareCoreCurves(byte[] wall){
   var masksForCurve=new[]{12,6,3,9};var sxForCurve=new[]{1,-1,-1,1};var syForCurve=new[]{-1,-1,1,1};
   var audit=CoreStructureAudit;audit.curveConvex=true;
   audit.minCurveInset=audit.curveMinRadius=audit.curveMinShift=double.PositiveInfinity;
   double inset=.28*glassSize;
   for(int k=0;k<4;k++){
    var curve=new CoreCurve{mask=masksForCurve[k],sx=sxForCurve[k],sy=syForCurve[k]};coreStructure.curves[k]=curve;
    var support=new double[CoreCurveSamples];
    for(int i=0;i<CoreCurveSamples;i++){
     double angle=i*Math.PI/(2*(CoreCurveSamples-1)),dx=curve.sx*Math.Cos(angle),dy=curve.sy*Math.Sin(angle),last=.10*glassSize;
     // Calibrate the clean body edge, not isolated faint alpha decoration. The
     // tile's own joint adds its usual narrow clearance after this contour.
     for(double r=.10*glassSize;r<=.42*glassSize;r+=.125)if(CoreCurveAlpha(wall,curve.mask,glassSize*.5+dx*r,glassSize*.5+dy*r)>=64)last=r;
     support[i]=last+.0625;
    }
    double Error(double shift){
     double sum=0,radius=inset+shift;
     // The far endpoints contain authored straight-segment microjoints. Fit
     // only the uninterrupted glass arc; straight tangency is exact by design.
     for(int i=8;i<=CoreCurveSamples-9;i++){
      double angle=i*Math.PI/(2*(CoreCurveSamples-1)),x=support[i]*Math.Cos(angle)+shift,y=support[i]*Math.Sin(angle)+shift;
      double residual=Math.Sqrt(x*x+y*y)-radius;sum+=residual*residual;
     }
     return sum;
    }
    double lo=.035*glassSize,hi=.24*glassSize;
    for(int iteration=0;iteration<44;iteration++){
     double left=(2*lo+hi)/3,right=(lo+2*hi)/3;
     if(Error(left)<Error(right))hi=right;else lo=left;
    }
    curve.shift=(lo+hi)*.5;curve.radius=inset+curve.shift;
    audit.curveMinRadius=Math.Min(audit.curveMinRadius,curve.radius);audit.curveMaxRadius=Math.Max(audit.curveMaxRadius,curve.radius);
    audit.curveMinShift=Math.Min(audit.curveMinShift,curve.shift);audit.curveMaxShift=Math.Max(audit.curveMaxShift,curve.shift);
    for(int i=0;i<CoreCurveSamples;i++){
     double angle=i*Math.PI/(2*(CoreCurveSamples-1)),cs=Math.Cos(angle),sn=Math.Sin(angle),d=curve.shift;
     double radial=-d*(cs+sn)+Math.Sqrt(curve.radius*curve.radius-d*d*(cs-sn)*(cs-sn));
     audit.minCurveInset=Math.Min(audit.minCurveInset,radial);audit.maxCurveInset=Math.Max(audit.maxCurveInset,radial);
     if(i>=8&&i<=CoreCurveSamples-9){double x=support[i]*cs+d,y=support[i]*sn+d;audit.curveFitMaxError=Math.Max(audit.curveFitMaxError,Math.Abs(Math.Sqrt(x*x+y*y)-curve.radius));}
    }
    // The real joins are (inset,-shift) and (-shift,inset), not the axes
    // through the raw grid vertex. Both normal and position are exact there.
    double tangentError=Math.Abs((inset+curve.shift)-curve.radius);
    audit.curveJoinError=Math.Max(audit.curveJoinError,tangentError);audit.curveTangentError=Math.Max(audit.curveTangentError,tangentError);
    audit.curveContours++;audit.curveProfileSamples+=CoreCurveSamples;
   }
  }
  bool AuthoredCoreCurve(CorePoint p,CorePoint vertex,out double clearance,out double nx,out double ny){
   clearance=nx=ny=0;
   int gx=(int)Math.Round(vertex.x/glassSize-.5),gy=(int)Math.Round(vertex.y/glassSize-.5);if(gx<0||gx>=36||gy<0||gy>=25)return false;
   CoreCurve curve=null;foreach(var candidate in coreStructure.curves)if(candidate!=null&&candidate.mask==masks[gx,gy]){curve=candidate;break;}
   if(curve==null)return false;
   double a=curve.sx*(p.x-vertex.x),b=curve.sy*(p.y-vertex.y),d=curve.shift;
   // A rounded wall begins before the raw corner's quadrant. Including these
   // two tangent extensions avoids the old straight/curve cavities and cusps.
   if(a< -d||b< -d||a*a+b*b>.45*.45*glassSize*glassSize)return false;
   double qx=a+d,qy=b+d,length=Math.Sqrt(qx*qx+qy*qy);if(length<.00001)return false;
   nx=curve.sx*qx/length;ny=curve.sy*qy/length;clearance=length-curve.radius;return true;
  }
  static double CoreDistance(CorePoint a,CorePoint b)=>Math.Sqrt((a.x-b.x)*(a.x-b.x)+(a.y-b.y)*(a.y-b.y));
  int CoreOwner(CorePoint p){int x=(int)Math.Floor(p.x/glassSize-.5),y=(int)Math.Floor(p.y/glassSize-.5);return x>=0&&x<35&&y>=0&&y<24?coreStructure.owner[x,y]:0;}
  static CorePoint CoreNearest(CorePoint p,CoreBoundary edge,out bool projected){
   double dx=edge.b.x-edge.a.x,dy=edge.b.y-edge.a.y,den=dx*dx+dy*dy;
   double t=den>0?((p.x-edge.a.x)*dx+(p.y-edge.a.y)*dy)/den:0;projected=t>=0&&t<=1;
   t=Math.Max(0,Math.Min(1,t));return new CorePoint(edge.a.x+dx*t,edge.a.y+dy*t);
  }
  // Read one real joint in a straight tile. Corner microjoints are deliberately
  // not promoted into panel divisions: their unequal phases made crooked strips.
  double MeasureCoreJoint(byte[] wall,int tile,bool horizontal,double centre){
   int scale=glassSize/80,begin=Math.Max(0,(int)Math.Floor((centre-.10)*glassSize)),end=Math.Min(glassSize-1,(int)Math.Ceiling((centre+.10)*glassSize));
   int run=-1,last=-1;double result=double.NaN,best=double.PositiveInfinity;
   void Finish(){if(run<0)return;double position=(run+last+1)*.5,error=Math.Abs(position-centre*glassSize);if(error<best){best=error;result=position;}run=last=-1;}
   for(int p=begin;p<=end;p++){
    double sum=0;int count=0,total=0;
    for(int band=0;band<2;band++)for(int q=(band==0?20:52)*scale;q<=(band==0?30:58)*scale;q++){
     total++;int x=horizontal?p:q,y=horizontal?q:p,at=(y*16*glassSize+tile*glassSize+x)*4;
     if(wall[at+3]>=220){sum+=Math.Max(wall[at],Math.Max(wall[at+1],wall[at+2]));count++;}
    }
    if(count>=total*.65&&sum/Math.Max(1,count)<=3){if(run<0)run=p;last=p;}else Finish();
   }
   Finish();if(double.IsNaN(result))throw new InvalidOperationException("No authored straight glass joint at tile"+tile+" /"+centre);
   CoreStructureAudit.sourceJointSamples++;return result;
  }
  void PrepareCrystalStructure(byte[] wall){
   coreStructure=new CoreStructure();CoreStructureAudit=new CrystalStructureAudit{orthogonalGrid=true,perimeterInset=.28*glassSize,curveJunctionRadius=.035*glassSize};
   PrepareCoreCurves(wall);
   double xJoint=MeasureCoreJoint(wall,10,true,.5),yJoint1=MeasureCoreJoint(wall,5,false,.25),yJoint2=MeasureCoreJoint(wall,5,false,.75);
   coreStructure.periodX=glassSize;coreStructure.periodY=glassSize*.5;
   coreStructure.phaseX=xJoint;coreStructure.phaseY=(yJoint1+yJoint2-coreStructure.periodY)*.5;
   var audit=CoreStructureAudit;audit.gridPeriodX=coreStructure.periodX;audit.gridPeriodY=coreStructure.periodY;audit.gridPhaseX=coreStructure.phaseX;audit.gridPhaseY=coreStructure.phaseY;audit.sourceVerticalPeriod=yJoint2-yJoint1;
   var components=Components();audit.components=components.Count;
   for(int c=0;c<components.Count;c++){coreStructure.territories.Add(new CoreTerritory{shape=components[c]});foreach(var p in components[c].cells)coreStructure.owner[p.x,p.y]=c+1;}
   void Edge(CorePoint a,CorePoint b,CorePoint n,int id,bool vertical){coreStructure.boundaries.Add(new CoreBoundary{a=a,b=b,n=n,component=id,vertical=vertical});}
   for(int c=0;c<components.Count;c++)foreach(var b in components[c].cells){
    double l=(b.x+.5)*glassSize,r=l+glassSize,t=(b.y+.5)*glassSize,bot=t+glassSize;int id=c+1;
    if(!Block(b.x,b.y-1))Edge(new CorePoint(l,t),new CorePoint(r,t),new CorePoint(0,1),id,false);
    if(!Block(b.x,b.y+1))Edge(new CorePoint(l,bot),new CorePoint(r,bot),new CorePoint(0,-1),id,false);
    if(!Block(b.x-1,b.y))Edge(new CorePoint(l,t),new CorePoint(l,bot),new CorePoint(1,0),id,true);
    if(!Block(b.x+1,b.y))Edge(new CorePoint(r,t),new CorePoint(r,bot),new CorePoint(-1,0),id,true);
   }
   audit.boundarySegments=coreStructure.boundaries.Count;
   // Distances are needed out to the inset plus the visible bevel. These bins
   // contain only true solid-component boundaries, never inset border strokes.
   double radius=.45*glassSize;
   for(int i=0;i<coreStructure.boundaries.Count;i++){
    var edge=coreStructure.boundaries[i];int x0=Math.Max(0,(int)Math.Floor((Math.Min(edge.a.x,edge.b.x)-radius)/glassSize-.5)),x1=Math.Min(34,(int)Math.Floor((Math.Max(edge.a.x,edge.b.x)+radius)/glassSize-.5)),y0=Math.Max(0,(int)Math.Floor((Math.Min(edge.a.y,edge.b.y)-radius)/glassSize-.5)),y1=Math.Min(23,(int)Math.Floor((Math.Max(edge.a.y,edge.b.y)+radius)/glassSize-.5));
    for(int y=y0;y<=y1;y++)for(int x=x0;x<=x1;x++)if(coreStructure.owner[x,y]==edge.component){int at=y*35+x;if(coreStructure.bins[at]==null)coreStructure.bins[at]=new List<int>();coreStructure.bins[at].Add(i);}
   }
   // Audit active canonical divider lines, not a purported corner-anchor graph.
   for(int c=0;c<components.Count;c++){
    var shape=components[c];double l=(shape.minX+.5)*glassSize,r=(shape.maxX+1.5)*glassSize,t=(shape.minY+.5)*glassSize,bot=(shape.maxY+1.5)*glassSize;
    for(int k=(int)Math.Ceiling((l-coreStructure.phaseX)/glassSize);coreStructure.phaseX+k*glassSize<r;k++)if(CoreGridActive(coreStructure.phaseX+k*glassSize,t,bot,c+1,true))audit.verticalDividers++;
    for(int k=(int)Math.Ceiling((t-coreStructure.phaseY)/coreStructure.periodY);coreStructure.phaseY+k*coreStructure.periodY<bot;k++)if(CoreGridActive(coreStructure.phaseY+k*coreStructure.periodY,l,r,c+1,false))audit.horizontalDividers++;
   }
   audit.seamSegments=audit.verticalDividers+audit.horizontalDividers;
   if(Array.IndexOf(Environment.GetCommandLineArgs(),"--crystal-core-probe")>=0||Array.IndexOf(Environment.GetCommandLineArgs(),"--ipad-crystal-probe")>=0)AuditCoreCurveSampler();
  }
  void AuditCoreCurveSampler(){
   var audit=CoreStructureAudit;double[] offsets={-1,0,1,3};
   for(int gy=0;gy<25;gy++)for(int gx=0;gx<36;gx++)foreach(var curve in coreStructure.curves){
    if(curve.mask!=masks[gx,gy])continue;
    var vertex=new CorePoint((gx+.5)*glassSize,(gy+.5)*glassSize);
    for(int i=0;i<=30;i++){
     double angle=i*Math.PI/60,cs=Math.Cos(angle),sn=Math.Sin(angle),nx=curve.sx*cs,ny=curve.sy*sn;
     var point=new CorePoint(vertex.x-curve.sx*curve.shift+curve.radius*nx,vertex.y-curve.sy*curve.shift+curve.radius*ny);
     foreach(double offset in offsets){
      var sample=new CorePoint(point.x+offset*nx,point.y+offset*ny);int component=CoreOwner(sample);if(component==0)continue;
      // Narrow unrelated solids may bring another real boundary closer than
      // this elbow. Those are not isolated witnesses of the selected arc.
      var bin=CoreBoundaryBin(sample);double nearest=double.PositiveInfinity;CoreBoundary closest=null;
      if(bin!=null)foreach(int index in bin){var edge=coreStructure.boundaries[index];if(edge.component!=component)continue;var q=CoreNearest(sample,edge,out _);double distance=CoreDistance(sample,q);if(distance<nearest){nearest=distance;closest=edge;}}
      if(closest==null||CoreDistance(closest.a,vertex)>.00001&&CoreDistance(closest.b,vertex)>.00001)continue;
      double actual=CorePerimeterClearance(sample,component,out _,out _,out _,out _,out _);
      audit.curveSamplerSamples++;audit.curveSamplerMaxError=Math.Max(audit.curveSamplerMaxError,Math.Abs(actual-offset));
     }
    }
   }
  }
  bool CoreGridActive(double fixedCoordinate,double start,double stop,int component,bool vertical){
   for(double along=start;along<=stop;along+=glassSize*.1){var p=vertical?new CorePoint(fixedCoordinate,along):new CorePoint(along,fixedCoordinate);if(CorePanelClearance(p,component)>.012*glassSize)return true;}return false;
  }
  List<int> CoreBoundaryBin(CorePoint p){int x=(int)Math.Floor(p.x/glassSize-.5),y=(int)Math.Floor(p.y/glassSize-.5);return x>=0&&x<35&&y>=0&&y<24?coreStructure.bins[y*35+x]:null;}
  double CorePanelClearance(CorePoint p,int component){
   if(CoreOwner(p)!=component)return -glassSize;
   return CorePerimeterClearance(p,component,out _,out _,out _,out _,out _);
  }
  double CorePerimeterClearance(CorePoint p,int component,out double nx,out double ny,out bool planar,out bool authored,out double circular){
   double distance=.45*glassSize;nx=ny=0;planar=true;authored=false;CoreBoundary nearestEdge=null;
   var bin=CoreBoundaryBin(p);if(bin!=null)foreach(int i in bin){
    var edge=coreStructure.boundaries[i];if(edge.component!=component)continue;var q=CoreNearest(p,edge,out bool projected);double d=CoreDistance(p,q);
    if(d>=distance)continue;distance=d;nearestEdge=edge;planar=projected;nx=d>.00001?(p.x-q.x)/d:edge.n.x;ny=d>.00001?(p.y-q.y)/d:edge.n.y;
   }
   circular=distance-.28*glassSize;
   // Either endpoint may own an actual rounded elbow even when projection
   // still lies on the adjoining raw straight edge. Its analytic arc extends
   // to the true tangent, then joins the unchanged planar inset with no cusp.
   if(nearestEdge!=null){
    if(AuthoredCoreCurve(p,nearestEdge.a,out double fitted,out double curveNx,out double curveNy)||AuthoredCoreCurve(p,nearestEdge.b,out fitted,out curveNx,out curveNy)){
     authored=true;planar=false;nx=curveNx;ny=curveNy;return fitted;
    }
   }
   return circular;
  }
  static CoreConstraint CoreGridConstraint(double p,double phase,double period,bool vertical){
   double low=phase+Math.Floor((p-phase)/period)*period,high=low+period;bool lower=p-low<=high-p;
   return new CoreConstraint{d=lower?p-low:high-p,nx=vertical?(lower?1:-1):0,ny=vertical?0:(lower?1:-1),coordinate=lower?low:high};
  }
  CrystalFacetSample CrystalFacetAt(int x,int y){
   var p=new CorePoint(x+.5,y+.5);int component=coreStructure==null?0:CoreOwner(p);
   if(component==0)return new CrystalFacetSample{distance=-glassSize,straightDistance=-glassSize,perimeterClearance=-glassSize,outsidePanelDomain=true,u=.5,v=.5};
   var shape=coreStructure.territories[component-1].shape;
   var sample=new CrystalFacetSample{u=(p.x-(shape.minX+.5)*glassSize)/((shape.maxX-shape.minX+1)*glassSize),v=(p.y-(shape.minY+.5)*glassSize)/((shape.maxY-shape.minY+1)*glassSize)};
   var vertical=CoreGridConstraint(p.x,coreStructure.phaseX,coreStructure.periodX,true);var horizontal=CoreGridConstraint(p.y,coreStructure.phaseY,coreStructure.periodY,false);
   double boundaryClearance=CorePerimeterClearance(p,component,out double boundaryNx,out double boundaryNy,out bool boundaryPlanar,out bool authoredCurve,out double circularClearance);
   var bin=CoreBoundaryBin(p);
   if(bin!=null)foreach(int i in bin){
    var edge=coreStructure.boundaries[i];var q=CoreNearest(p,edge,out bool projected);double distance=CoreDistance(p,q);
    if(!projected||(p.x-q.x)*edge.n.x+(p.y-q.y)*edge.n.y<0)continue;
    // The analytic elbow replaces both adjoining planar constraints through
    // its true tangent. Retaining either old infinite inset here would clip
    // the filled tile back into the former dark square cavity.
    if(authoredCurve&&(AuthoredCoreCurve(p,edge.a,out _,out _,out _)||AuthoredCoreCurve(p,edge.b,out _,out _,out _)))continue;
    double clearance=distance-.28*glassSize;
    if(edge.vertical&&clearance<vertical.d)vertical=new CoreConstraint{d=clearance,nx=edge.n.x,coordinate=edge.a.x+edge.n.x*.28*glassSize,lo=Math.Min(edge.a.y,edge.b.y),hi=Math.Max(edge.a.y,edge.b.y),finite=true};
    if(!edge.vertical&&clearance<horizontal.d)horizontal=new CoreConstraint{d=clearance,ny=edge.n.y,coordinate=edge.a.y+edge.n.y*.28*glassSize,lo=Math.Min(edge.a.x,edge.b.x),hi=Math.Max(edge.a.x,edge.b.x),finite=true};
   }
   sample.perimeterClearance=boundaryClearance;sample.circularPerimeterClearance=circularClearance;sample.authoredCurve=authoredCurve;sample.outsidePanelDomain=sample.perimeterClearance<=0;
   sample.distance=sample.perimeterClearance;sample.nx=boundaryNx;sample.ny=boundaryNy;
   if(vertical.d<sample.distance){sample.distance=vertical.d;sample.nx=vertical.nx;sample.ny=vertical.ny;}
   if(horizontal.d<sample.distance){sample.distance=horizontal.d;sample.nx=horizontal.nx;sample.ny=horizontal.ny;}
   sample.straightDistance=sample.distance;
   if(sample.outsidePanelDomain)return sample;
   double gap=.012*glassSize,radius=.035*glassSize;
   // A canonical row can meet a fitted curved wall at an acute angle. Leaving
   // that intersection sharp produces a small hook in the glass highlight.
   // Round only the local junction; the straight divider and wall domain stay put.
   if(authoredCurve&&boundaryClearance<gap+radius){
    // Preserve the approved perpendicular return, but fade its small recess
    // continuously at grazing angles. The former .98 cutoff switched the
    // recess abruptly; an unrestricted acute-angle fillet can eat a thin tile.
    double baseDistance=sample.distance,baseNx=sample.nx,baseNy=sample.ny;
    for(int axis=0;axis<2;axis++){
     var junction=axis==0?vertical:horizontal;if(junction.finite||junction.d>=gap+radius)continue;
     double dot=Math.Max(-1,Math.Min(1,boundaryNx*junction.nx+boundaryNy*junction.ny)),strength=1-dot*dot;
     double ja=gap+radius-boundaryClearance,jb=gap+radius-junction.d,jLength=Math.Sqrt(ja*ja+jb*jb);
     if(jLength<1e-10)continue;
     double recess=Math.Max(0,baseDistance-(gap+radius-jLength))*strength,jRounded=baseDistance-recess;
     if(jRounded>=sample.distance-.0001)continue;
     double dx=boundaryNx*ja+junction.nx*jb,dy=boundaryNy*ja+junction.ny*jb,normal=Math.Sqrt(dx*dx+dy*dy);
     if(normal<1e-10)continue;
     dx=baseNx+(dx/normal-baseNx)*strength;dy=baseNy+(dy/normal-baseNy)*strength;normal=Math.Sqrt(dx*dx+dy*dy);
     if(normal<1e-10)continue;
     sample.nx=dx/normal;sample.ny=dy/normal;sample.distance=jRounded;sample.roundedCorner=sample.curveJunction=true;
    }
    if(sample.curveJunction)return sample;
   }
   // Only the nearest two real perpendicular constraints can form a tile corner.
   // A curved re-entrant component boundary already has its own radial normal.
   if(vertical.d>=gap+radius||horizontal.d>=gap+radius)return sample;
   if(!boundaryPlanar&&sample.perimeterClearance<=Math.Min(vertical.d,horizontal.d)+.00001)return sample;
   var corner=new CorePoint(vertical.coordinate,horizontal.coordinate);
   if(vertical.finite&&(corner.y<vertical.lo-.00001||corner.y>vertical.hi+.00001)||horizontal.finite&&(corner.x<horizontal.lo-.00001||corner.x>horizontal.hi+.00001))return sample;
   if(CorePanelClearance(corner,component)<-.00001)return sample;
   double a=Math.Max(0,radius-(vertical.d-gap)),b=Math.Max(0,radius-(horizontal.d-gap)),length=Math.Sqrt(a*a+b*b);
   if(length<.00001)return sample;double rounded=gap+radius-length;if(rounded>=sample.distance-.0001)return sample;
   double nx=vertical.nx*a,ny=horizontal.ny*b,normalLength=Math.Sqrt(nx*nx+ny*ny);if(normalLength>.00001){sample.nx=nx/normalLength;sample.ny=ny/normalLength;}
   sample.distance=rounded;sample.roundedCorner=true;return sample;
  }
 }
}

#if UNITY_EDITOR
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Reflection;
using UnityEngine;

namespace MazeBiters.NativeStudy {
 [Serializable] public sealed class NativeAdaptiveAllyTrace {
  public string scenario,reason;public int mode,baseIndex,level,aiLives,aiScore,humanScore,comparatorId;
  public double seconds,effective,profile,target,baseline,rate,lastDeltaMs;public bool active,hasComparator,maximumPolicy;
 }
 [Serializable] public sealed class NativeAdaptiveAllyReport {
  public bool passed;public int assertions,failures,ticks,decisions,controlledScenarios;public double elapsedMs;
  public string scope;public List<NativeDifficultyCheck> checks=new List<NativeDifficultyCheck>();public List<NativeAdaptiveAllyTrace> traces=new List<NativeAdaptiveAllyTrace>();
 }
 // Controlled score/life schedules exercise the production Tick hook. Motion
 // is held only in clock fixtures, so RNG and incidental deaths cannot obscure
 // rate/lifecycle contracts. Separate fixtures execute real planning/contact.
 public static class NativeAdaptiveAllyValidation {
  sealed class Fixture {
   public NativeGameplayWorld w;public int aiSlot,draws;public double started;
   public NativePlayer Ai=>w.GetPlayer(aiSlot);
   public NativeAdaptiveAllySnapshot Sample=>w.AdaptiveAllySample(Ai.Id);
  }
  static readonly PropertyInfo BalanceProperty=typeof(NativeAllyBrain).GetProperty("Balance",BindingFlags.Instance|BindingFlags.NonPublic);
  static readonly PropertyInfo SkillProperty=typeof(NativeAllyBrain).GetProperty("BalancedSkill",BindingFlags.Instance|BindingFlags.NonPublic);
  static string[] Arena(){const int width=17,height=15;return Enumerable.Range(0,height).Select(y=>y==0||y==height-1?new string('#',width):"#"+new string('.',width-2)+"#").ToArray();}
  static Fixture World(int tier,int mode=3,int lives=3,bool legacy=false){
   var f=new Fixture{aiSlot=mode==4?2:mode==3?1:0,started=1000};
   f.w=new NativeGameplayWorld(Arena(),()=>{f.draws++;return .99;}){AiDifficulty=tier,Difficulty=NativeMazeGenerator.Difficulties[tier],Time=1000,RealTime=1000,LevelStarted=1000,SessionEnabled=true,Assist=false,UseLegacyAi=legacy};f.w.SetMode(mode);
   for(int i=0;i<f.w.PlayerCount;i++){var p=f.w.GetPlayer(i);p.Cell=p.From=p.Previous=new Vector2Int(3+i*4,7);p.Dir=p.Next=Vector2Int.right;p.Score=0;p.ExactScore=0;p.Waiting=true;p.LastMove=1e12;}
   f.Ai.Lives=lives;f.w.PlayerStart=f.Ai.Cell;f.w.StartDirection=Vector2Int.right;f.w.Ally.BeginLevel();f.w.Tick(f.w.Time);return f;
  }
  static void Score(NativePlayer p,int score){p.Score=score;p.ExactScore=score;}
  static void HoldMotion(Fixture f){for(int i=0;i<f.w.PlayerCount;i++)f.w.GetPlayer(i).LastMove=1e12;foreach(var s in f.w.Snakes)s.LastMove=1e12;f.w.LifecycleEnabled=false;f.w.Scorpion=null;f.w.Hunters.Clear();}
  static void Tick(NativeAdaptiveAllyReport r,Fixture f,double t){f.w.RealTime=t;f.w.Tick(t);r.ticks++;}
  static void Advance(NativeAdaptiveAllyReport r,Fixture f,double ms,int hz=60){double from=f.w.Time;int steps=Math.Max(1,(int)Math.Ceiling(ms*hz/1000));for(int i=1;i<=steps;i++)Tick(r,f,from+ms*i/steps);}
  static NativeDifficultyProfile Balance(Fixture f)=>(NativeDifficultyProfile)BalanceProperty.GetValue(f.w.Ally);
  static AllySkill Skill(Fixture f)=>(AllySkill)SkillProperty.GetValue(f.w.Ally);
  static bool Near(double a,double b,double tolerance=1e-7)=>Math.Abs(a-b)<=tolerance;
  static bool Finite(double v)=>!double.IsNaN(v)&&!double.IsInfinity(v);
  static void Check(NativeAdaptiveAllyReport r,bool pass,string name,string detail=""){r.assertions++;if(!pass)r.failures++;r.checks.Add(new NativeDifficultyCheck{name=name,passed=pass,detail=detail});}
  static void Group(NativeAdaptiveAllyReport r,string name,Action run){try{run();}catch(Exception e){Check(r,false,name+" completes",e.ToString());}}
  static string Detail(Fixture f){var s=f.Sample;return "effective="+s.EffectiveIntensity+", target="+s.TargetIntensity+", baseline="+s.BaselineIntensity+", rate="+s.RatePerSecond+", reason="+s.Reason;}
  static void Trace(NativeAdaptiveAllyReport r,Fixture f,string scenario){var s=f.Sample;r.traces.Add(new NativeAdaptiveAllyTrace{scenario=scenario,mode=f.w.Mode,baseIndex=f.w.AiDifficulty,level=f.w.Level,aiLives=f.Ai.Lives,aiScore=f.Ai.Score,humanScore=s.HumanScore,comparatorId=s.ComparatorId,seconds=(f.w.Time-f.started)/1000,effective=s.EffectiveIntensity,profile=s.ProfileIntensity,target=s.TargetIntensity,baseline=s.BaselineIntensity,rate=s.RatePerSecond,lastDeltaMs=s.LastDeltaMs,active=s.Active,hasComparator=s.HasComparator,maximumPolicy=s.MaximumPolicy,reason=s.Reason});}

  static void TargetsAndRates(NativeAdaptiveAllyReport r){
   for(int tier=0;tier<5;tier++)foreach(int mode in new[]{3,4})foreach(int lives in new[]{3,2,1}){
    var f=World(tier,mode,lives);string name="base="+tier+", mode="+mode+", lives="+lives;
    Check(r,f.Sample.Enabled&&Near(f.Sample.EffectiveIntensity,tier),"A new AI starts at the chosen tier: "+name,Detail(f));
    Score(f.w.GetPlayer(0),5);Advance(r,f,100);Check(r,Near(f.Sample.TargetIntensity,tier),"Five displayed points are inside the score deadband: "+name,Detail(f));
    Score(f.w.GetPlayer(0),10);double before=f.Sample.EffectiveIntensity;Advance(r,f,1000);double secondsPerTier=lives<=1?9:lives==2?15:22;
    Check(r,Near(f.Sample.TargetIntensity,4)&&Near(f.Sample.EffectiveIntensity,Math.Min(4,before+1/secondsPerTier)),"A human lead raises intent at the agreed life-dependent rate: "+name,Detail(f));
    Check(r,f.w.AiDifficulty==tier&&Near(f.w.Difficulty,NativeMazeGenerator.Difficulties[tier]),"Adaptation leaves the menu choice and world difficulty intact: "+name);
    Score(f.w.GetPlayer(0),0);before=f.Sample.EffectiveIntensity;Advance(r,f,1000);
    Check(r,Near(f.Sample.EffectiveIntensity,Math.Max(tier,before-1/secondsPerTier)),"Catching up reduces the boost at the same rate: "+name,Detail(f));
   }
   foreach(int lives in new[]{3,2,1}){var f=World(0,3,lives);Score(f.w.GetPlayer(0),1000);Advance(r,f,9000);double expected=9.0/(lives==3?22:lives==2?15:9);Check(r,Near(f.Sample.EffectiveIntensity,expected),"Nine seconds of deficit has exact bounded catch-up, lives="+lives,Detail(f));}
   {var f=World(2);Score(f.w.GetPlayer(0),1000);double before=f.Sample.EffectiveIntensity;Tick(r,f,f.w.Time);Check(r,Near(f.Sample.EffectiveIntensity,before),"Duplicate Tick time cannot advance adaptation");Tick(r,f,f.w.Time+10000);Check(r,f.Sample.EffectiveIntensity-before<=.25/22+1e-8,"A long frame cannot apply a hidden multi-second difficulty jump",Detail(f));}
  }

  static void BrutalRelaxation(NativeAdaptiveAllyReport r){
   foreach(int mode in new[]{3,4})foreach(int lives in new[]{3,2,1}){
    var f=World(4,mode,lives);double cap=lives==3?1:lives==2?.65:.35,secondsPerTier=lives==3?22:lives==2?30:45;
    Score(f.Ai,1000);Advance(r,f,1000);Check(r,Near(f.Sample.TargetIntensity,4-cap)&&Near(f.Sample.EffectiveIntensity,4-1/secondsPerTier),"A substantial BRUTAL lead eases cautiously, mode="+mode+", lives="+lives,Detail(f));
    Advance(r,f,30000);Check(r,Near(f.Sample.EffectiveIntensity,4-cap),"BRUTAL relaxation respects its life-dependent floor, mode="+mode+", lives="+lives,Detail(f));
    Score(f.w.GetPlayer(0),1000);double before=f.Sample.EffectiveIntensity;Advance(r,f,1000);double restore=lives==3?22:lives==2?15:9;
    Check(r,Near(f.Sample.TargetIntensity,4)&&Near(f.Sample.EffectiveIntensity,Math.Min(4,before+1/restore)),"A fading lead restores BRUTAL at normal catch-up speed, mode="+mode+", lives="+lives,Detail(f));
   }
   foreach(int lead in new[]{0,149,150,375,600,1000}){var f=World(4);Score(f.Ai,lead);Advance(r,f,100);double u=Math.Max(0,Math.Min(1,(lead-150)/450.0));double expected=4-u*u*(3-2*u);Check(r,Near(f.Sample.TargetIntensity,expected),"Absolute lead thresholds form a smooth BRUTAL relaxation curve, lead="+lead,Detail(f));}
   foreach(int human in new[]{9800,9500,9000,8000}){var f=World(4);Score(f.Ai,10000);Score(f.w.GetPlayer(0),human);Advance(r,f,100);double u=Math.Max(0,Math.Min(1,((10000-human)-500)/1500.0));Check(r,Near(f.Sample.TargetIntensity,4-u*u*(3-2*u)),"Large scores use proportional lead thresholds, human="+human,Detail(f));}
   for(int tier=0;tier<4;tier++){var f=World(tier);Score(f.Ai,10000);Advance(r,f,1000);Check(r,Near(f.Sample.EffectiveIntensity,tier),"Leading lower-tier AI does not fall below its chosen baseline, base="+tier,Detail(f));}
  }

  static void ComparatorsAndScope(NativeAdaptiveAllyReport r){
   {var f=World(1,4);Score(f.Ai,100);Score(f.w.GetPlayer(0),80);Score(f.w.GetPlayer(1),90);Advance(r,f,100);Check(r,f.Sample.HasComparator&&f.Sample.HumanScore==90&&f.Sample.ComparatorId==2&&Near(f.Sample.TargetIntensity,1),"DUO compares with the strongest individual human rather than summing scores",Detail(f));
    Score(f.w.GetPlayer(0),200);Advance(r,f,100);Check(r,f.Sample.ComparatorId==1&&Near(f.Sample.TargetIntensity,4),"DUO follows a new human score leader",Detail(f));
    f.w.GetPlayer(0).Dead=true;f.w.GetPlayer(0).RespawnAt=1e12;Advance(r,f,100);Check(r,f.Sample.ComparatorId==1&&f.Sample.HumanScore==200,"A temporarily dead human remains the score comparator",Detail(f));
    f.w.GetPlayer(0).Lives=0;f.w.GetPlayer(0).Eliminated=true;Advance(r,f,100);Check(r,f.Sample.ComparatorId==2&&f.Sample.HumanScore==90,"An eliminated human is excluded while another human remains",Detail(f));
   }
   {var f=World(0);Score(f.w.GetPlayer(0),1000);Advance(r,f,11000);double acquired=f.Sample.EffectiveIntensity;f.w.GetPlayer(0).Dead=true;f.w.GetPlayer(0).Lives=0;f.w.GetPlayer(0).Eliminated=true;Advance(r,f,10000);
    Check(r,!f.Sample.HasComparator&&Near(f.Sample.EffectiveIntensity,acquired),"With no remaining human, acquired intelligence is retained without score-driven decay",Detail(f));
    Advance(r,f,90000);Check(r,f.Sample.EffectiveIntensity>=acquired&&f.Sample.EffectiveIntensity<=f.Sample.BaselineIntensity+.02,"Without humans, normal time progression may catch up without a new score boost",Detail(f));
   }
   foreach(int mode in new[]{0,1,2,5})foreach(int tier in new[]{0,2,4}){var f=World(tier,mode);Score(f.Ai,10000);Advance(r,f,1000);Check(r,!f.Sample.Enabled,"Adaptive score policy is disabled outside AI competitive modes, mode="+mode+", base="+tier);if(mode==0){f.w.Time=f.w.LevelStarted+180000;Check(r,Near(Balance(f).Intensity,NativeDifficulty.ForIndex(tier,f.w.Level,180000).Intensity),"AI ONLY keeps original same-level time progression, base="+tier);}}
   foreach(int mode in new[]{3,4}){var f=World(0,mode,legacy:true);Score(f.w.GetPlayer(0),5000);Advance(r,f,10000);Check(r,!f.Sample.Enabled,"Frozen legacy brain does not acquire adaptive policy, mode="+mode);}
  }

  static void ClocksAndPurity(NativeAdaptiveAllyReport r){
   foreach(int lives in new[]{3,2,1}){
    var endpoints=new List<double>();foreach(int hz in new[]{30,60,120}){var f=World(1,3,lives);Score(f.w.GetPlayer(0),2000);Advance(r,f,8000,hz);Score(f.w.GetPlayer(0),0);Advance(r,f,3000,hz);endpoints.Add(f.Sample.EffectiveIntensity);}
    Check(r,endpoints.All(x=>Near(x,endpoints[0])),"Equivalent gameplay elapsed time is independent of 30/60/120 Hz, lives="+lives,string.Join(", ",endpoints));
   }
   {var f=World(0);Score(f.w.GetPlayer(0),1000);Advance(r,f,1000);double intensity=f.Sample.EffectiveIntensity,updated=f.Sample.UpdatedAt;int random=f.draws;var balance=Balance(f);
    for(int i=0;i<100;i++){var sample=f.Sample;var profile=Balance(f);var skill=Skill(f);f.w.Ally.InspectForesight(f.Ai,f.w.Time,Vector2Int.right);}
    Check(r,Near(f.Sample.EffectiveIntensity,intensity)&&Near(f.Sample.UpdatedAt,updated)&&f.draws==random,"Repeated profile/forecast inspection cannot advance adaptation or consume RNG",Detail(f));
    Check(r,Near(balance.Intensity,f.Sample.ProfileIntensity)&&Math.Abs(f.Sample.ProfileIntensity-intensity)<=.25/22+.0001,"Planner sees the bounded sampled adaptive profile",Detail(f));
    double before=f.Sample.EffectiveIntensity;f.w.Ally.Plan(f.Ai,f.w.Time);r.decisions++;Check(r,Near(f.Sample.EffectiveIntensity,before),"A direct planner call does not integrate the score controller");
   }
   foreach(string phase in new[]{"death","transition","game-over","pending","menu","catalogue"}){var f=World(0);Score(f.w.GetPlayer(0),1000);Advance(r,f,1000);double before=f.Sample.EffectiveIntensity;
    if(phase=="death"){f.Ai.Dead=true;f.Ai.RespawnAt=1e12;}if(phase=="transition"){f.w.Transition=true;f.w.TransitionAt=f.w.Time+1e9;}if(phase=="game-over")f.w.GameOver=true;if(phase=="pending")f.w.GameOverPending=true;if(phase=="menu")f.w.SessionEnabled=false;if(phase=="catalogue")f.w.CatalogueFinished=true;
    Advance(r,f,2000);Check(r,Near(f.Sample.EffectiveIntensity,before),"Inactive phase freezes adaptation: "+phase,Detail(f));f.Ai.Dead=false;f.w.Transition=f.w.GameOver=f.w.GameOverPending=f.w.CatalogueFinished=false;f.w.SessionEnabled=true;Advance(r,f,100);
    Check(r,f.Sample.EffectiveIntensity-before<=.1/22+1e-8,"Returning from inactivity cannot integrate the skipped interval: "+phase,Detail(f));
   }
  }

  static void GameplayInvariants(NativeAdaptiveAllyReport r){
   var fields=typeof(NativeDifficultyProfile).GetFields(BindingFlags.Public|BindingFlags.Instance).Where(x=>x.FieldType==typeof(double)).ToArray();
   foreach(int tier in new[]{0,2,4}){var f=World(tier);f.w.ScoreSpeed=1.25;Score(f.w.GetPlayer(0),1000);Advance(r,f,4000);var ordinary=NativeDifficulty.For(f.w.Difficulty,f.w.Level,f.w.Time-f.w.LevelStarted);var world=f.w.DifficultyProfile;
    Check(r,fields.All(x=>Near((double)x.GetValue(world),(double)x.GetValue(ordinary))),"Score adaptation does not change the shared creature difficulty profile, base="+tier);
    double score=f.Ai.ExactScore;using(f.w.ForPlayer(f.Ai)){double delay=f.w.PlayerDelay;f.w.Award(100);Check(r,Near(f.w.PlayerDelay,delay)&&Near(delay,95),"Adaptive intelligence does not change movement speed, base="+tier);}
    Check(r,Near(f.Ai.ExactScore-score,100*NativeMazeGenerator.Difficulties[tier]*1.25),"Scoring retains the chosen difficulty/speed multipliers, base="+tier);
   }
  }

  static void Lifecycle(NativeAdaptiveAllyReport r){
   var generator=new NativeMazeGenerator(34,.5);var initial=generator.Generate(1);var f=new Fixture{aiSlot=1,started=1000};f.w=new NativeGameplayWorld(initial.geometry,()=>{f.draws++;return .99;}){AiDifficulty=0,Difficulty=.5,Time=1000,RealTime=1000,LevelStarted=1000,Assist=false};f.w.SetMode(3);f.w.StartSession(generator.Generate);f.w.Snakes.Clear();HoldMotion(f);Tick(r,f,f.w.Time);Score(f.w.GetPlayer(0),2000);Advance(r,f,22000);double acquired=f.Sample.EffectiveIntensity;var old=f.Ai;
   using(f.w.ForPlayer(old))f.w.SessionDeath();Advance(r,f,1000);Check(r,old.Dead&&old.Lives==2&&Near(f.Sample.EffectiveIntensity,acquired),"Actual SessionDeath freezes the acquired AI intensity",Detail(f));
   f.w.Snakes.Clear();f.w.Hunters.Clear();f.w.Eggs.Clear();f.w.Scorpion=null;Advance(r,f,1900);HoldMotion(f);
   Check(r,!ReferenceEquals(old,f.Ai)&&!f.Ai.Dead&&f.Ai.Lives==2&&f.Sample.EffectiveIntensity>=acquired&&f.Sample.EffectiveIntensity-acquired<.1,"Actual respawn replaces the actor but retains acquired intelligence",Detail(f));
   double prior=f.Sample.EffectiveIntensity;Advance(r,f,1000);Check(r,Near(f.Sample.EffectiveIntensity-prior,1.0/15),"The respawned AI catches up faster with two remaining lives",Detail(f));
   old=f.Ai;prior=f.Sample.EffectiveIntensity;f.w.AdvanceLevel();Check(r,f.w.Level==2&&!ReferenceEquals(old,f.Ai)&&Near(f.Sample.EffectiveIntensity,prior),"Real level installation retains effective intelligence across FreshPlayer and BeginLevel",Detail(f));
   HoldMotion(f);Tick(r,f,f.w.Time);var current=Balance(f);var expected=NativeDifficulty.ForIntensity(f.Sample.ProfileIntensity,2,0,0);Check(r,Near(current.Skill,expected.Skill),"The retained adaptive profile still receives the new level modifier",Detail(f));
   f.w.StartSession(generator.Generate);HoldMotion(f);Check(r,Near(f.Sample.EffectiveIntensity,0),"A new campaign resets adaptation to the chosen baseline",Detail(f));
   Tick(r,f,f.w.Time);Score(f.w.GetPlayer(0),2000);Advance(r,f,2000);f.w.SetMode(4);HoldMotion(f);Check(r,Near(f.w.AdaptiveAllySample(f.w.GetPlayer(2).Id).EffectiveIntensity,0),"Changing mode cannot carry another roster's adaptive state");
  }

  static void MaximumIntentAndSafety(NativeAdaptiveAllyReport r){
   var f=World(4);var p=f.Ai;var human=f.w.GetPlayer(0);human.Cell=new Vector2Int(5,5);Score(p,1000);Score(human,1000);p.LastMove=1e12;var meal=f.w.AddSnake(new[]{new Vector2Int(9,7),new Vector2Int(8,7)},Vector2Int.right,0);meal.LastMove=1e12;f.w.Ally.Plan(p,f.w.Time);r.decisions++;using(f.w.ForPlayer(p))f.w.AdvancePlayer();
   Check(r,p.Cell==new Vector2Int(8,7)&&meal.Body.Count==1&&p.Ai.bitten&&p.Ai.locked==meal,"Maximum-to-relaxed fixture starts from a genuine committed tail bite");human.Cell=new Vector2Int(6,7);Score(p,1000);
   // Establish real previous maximum intent, then hold a legal weaker human
   // hunt while the controller eases. This catches Infinity leaking forever.
   p.Ai.mealInitialized=p.Ai.mealActive=true;p.Ai.mealIntentUntil=double.PositiveInfinity;p.Ai.directive=new AllyDirective{type="hunt",target=human,threats=new List<NativePlayer>(),skill=Skill(f)};p.Ai.opponentHuntUntil=double.PositiveInfinity;p.Ai.assessmentAt=f.w.Time+100000;var oldSkill=p.Ai.directive.skill;
   Score(human,0);Advance(r,f,3000);f.w.Ally.Plan(p,f.w.Time);r.decisions++;
   Check(r,!Balance(f).Maximum&&Finite(p.Ai.mealIntentUntil)&&Finite(p.Ai.opponentHuntUntil),"Leaving Maximum bounds inherited infinite meal and opponent-hunt windows",Detail(f));
   Check(r,p.Ai.directive==null||p.Ai.directive.skill.error>oldSkill.error&&Near(p.Ai.directive.skill.error,Skill(f).error),"A held directive refreshes its skill when the effective profile relaxes",Detail(f));
   using(f.w.ForPlayer(p))f.w.AdvancePlayer();Check(r,!p.Dead&&!f.w.Snakes.Contains(meal)&&p.Cell==new Vector2Int(9,7),"Leaving Maximum preserves the real adjacent meal through its final head");
   foreach(int baseTier in new[]{0,4}){
    var g=World(baseTier);Score(g.w.GetPlayer(0),2000);Advance(r,g,2000);var ai=g.Ai;ai.Cell=ai.From=ai.Previous=new Vector2Int(7,7);ai.Dir=ai.Next=Vector2Int.right;ai.Waiting=false;g.w.GetPlayer(0).Cell=new Vector2Int(3,3);ai.ShieldUntil=g.w.Time+5000;
    var snake=g.w.AddSnake(new[]{new Vector2Int(9,7),new Vector2Int(8,7)},Vector2Int.right,0);g.w.Ally.Plan(ai,g.w.Time);r.decisions++;using(g.w.ForPlayer(ai))g.w.AdvancePlayer();
    Check(r,!ai.Dead&&snake.Body.Count==1&&ai.Cell==new Vector2Int(8,7),"Adapted AI still takes an ordinary safe shield-protected tail bite, base="+baseTier);
    g.w.Snakes.Clear();var danger=g.w.AddSnake(new[]{new Vector2Int(9,7),new Vector2Int(10,7),new Vector2Int(11,7)},Vector2Int.left,0);g.w.Ally.Plan(ai,g.w.Time+95);r.decisions++;using(g.w.ForPlayer(ai))g.w.AdvancePlayer();
    Check(r,!ai.Dead&&g.w.Snakes.Contains(danger)&&danger.Body.Count==3&&!g.w.CreatureAttackPower(ai,g.w.Time),"Adaptive intelligence never turns spawn shield into frontal attack power, base="+baseTier);
   }
  }

  static void MaximumHysteresis(NativeAdaptiveAllyReport r){
   var f=World(3);Score(f.w.GetPlayer(0),1000);Advance(r,f,22500);Check(r,f.Sample.MaximumPolicy&&Balance(f).Maximum,"Adaptive Maximum policy is entered only after reaching the upper endpoint",Detail(f));
   for(int repeat=0;repeat<4;repeat++){
    Score(f.w.GetPlayer(0),0);Advance(r,f,1000);Check(r,f.Sample.EffectiveIntensity<4&&f.Sample.EffectiveIntensity>3.9&&f.Sample.MaximumPolicy&&Balance(f).Maximum,"A small repeated score swing does not switch Maximum policy off, repeat="+repeat,Detail(f));
    Score(f.w.GetPlayer(0),1000);Advance(r,f,1000);Check(r,f.Sample.MaximumPolicy,"Recovering a small score swing keeps one stable Maximum policy, repeat="+repeat,Detail(f));
   }
   Score(f.w.GetPlayer(0),0);Advance(r,f,3000);Check(r,f.Sample.EffectiveIntensity<3.90&&!f.Sample.MaximumPolicy&&!Balance(f).Maximum,"A meaningful reduction eventually leaves Maximum instead of sticking forever",Detail(f));
   Check(r,!NativeDifficulty.ForIntensity(3.95,1).Maximum&&NativeDifficulty.ForIndex(4,1).Maximum,"Maximum hysteresis does not change ordinary non-adaptive profiles");
  }

  static void ControlledTraces(NativeAdaptiveAllyReport r){
   for(int tier=0;tier<5;tier++)foreach(int mode in new[]{3,4}){var f=World(tier,mode);r.controlledScenarios++;string name="base-"+tier+"-mode-"+mode;Trace(r,f,name);bool bounded=true,smooth=true;double previous=f.Sample.EffectiveIntensity;
    for(int second=0;second<140;second++){
     if(second<8){Score(f.Ai,0);Score(f.w.GetPlayer(0),0);}
     else if(second<30){Score(f.Ai,0);Score(f.w.GetPlayer(0),2000);}
     else if(second<52){Score(f.Ai,2000);Score(f.w.GetPlayer(0),2000);}
     else if(second<85){Score(f.Ai,2000);Score(f.w.GetPlayer(0),4000);f.Ai.Lives=second<70?2:1;}
     else if(second<115){Score(f.Ai,8000);Score(f.w.GetPlayer(0),4000);f.Ai.Lives=3;}
     else{Score(f.Ai,8000);Score(f.w.GetPlayer(0),8000);}
     Advance(r,f,1000);if(second%2==1)Trace(r,f,name);
     bounded&=Finite(f.Sample.EffectiveIntensity)&&f.Sample.EffectiveIntensity>=0&&f.Sample.EffectiveIntensity<=4;smooth&=Math.Abs(f.Sample.EffectiveIntensity-previous)<=1.0/9+1e-8;previous=f.Sample.EffectiveIntensity;
    }
    Check(r,bounded,"The complete score/lives schedule remains finite and bounded: "+name);Check(r,smooth,"The complete score/lives schedule has no abrupt tier jumps: "+name);
   }
  }
  public static NativeAdaptiveAllyReport Run(){var timer=Stopwatch.StartNew();var r=new NativeAdaptiveAllyReport{scope="Editor-only deterministic production-Tick policy, lifecycle and genuine contact checks for adaptive AI in SOLO VS AI and DUO VS AI. Controlled traces hold movement to isolate score/life timing; they are not autonomous play sessions or render/device benchmarks. Fixed chosen difficulty, creature difficulty, scoring, speed and native legacy behavior remain separate."};Group(r,"targets and rates",()=>TargetsAndRates(r));Group(r,"BRUTAL relaxation",()=>BrutalRelaxation(r));Group(r,"comparators and scope",()=>ComparatorsAndScope(r));Group(r,"clocks and inspection purity",()=>ClocksAndPurity(r));Group(r,"gameplay invariants",()=>GameplayInvariants(r));Group(r,"actual lifecycle",()=>Lifecycle(r));Group(r,"maximum intent and safety",()=>MaximumIntentAndSafety(r));Group(r,"Maximum hysteresis",()=>MaximumHysteresis(r));Group(r,"controlled schedules",()=>ControlledTraces(r));r.elapsedMs=timer.Elapsed.TotalMilliseconds;r.passed=r.failures==0;return r;}
 }
}
#endif

using System;using System.Collections;using System.Collections.Generic;using System.IO;using UnityEngine;
namespace MazeBiters.NativeStudy {
 public sealed partial class NativeGameplayStudy {
  [Serializable] sealed class PreparationCapture {public int level;public string state,image;}
  [Serializable] sealed class PreparationCaptures {public bool passed;public string quality,mode,note;public PreparationCapture[] captures;}
  // Separate from performance measurement: live runs use the real frame delta
  // for the original 65ms flashlight response. Compare a specified identical
  // beam pose here, without changing that response in ordinary gameplay.
  IEnumerator CapturePreparationScenes(){
   sessionSmoke=true;var captures=new List<PreparationCapture>();
   foreach(int n in new[]{1,10,50,100}){
    Reset(12);if(n!=1){world.Level=n-1;world.AdvanceLevel();}
    yield return DrainProbePreparation();
    dusk.Render(world.Player.Visual(time),world.Player.Dir,0,false,true);
    preparationLightFrame=true;Render();
    string name=Path.GetFileNameWithoutExtension(report)+"-level-"+n+".png";
    Capture(Path.Combine(Path.GetDirectoryName(report),name));
    captures.Add(new PreparationCapture{level=n,state=GenerationState(),image=name});yield return null;
   }
   File.WriteAllText(report,JsonUtility.ToJson(new PreparationCaptures{passed=true,quality=quality,mode=NativeMazeArtwork.LegacyPreparation?"before":"after",captures=captures.ToArray(),note="Full composite at identical level start and explicitly identical flashlight angle; all original animations/effects enabled. Separate from live performance captures, whose 65ms beam easing intentionally uses real frame intervals."},true));
   Application.Quit();
  }
 }
}

using UnityEngine;

namespace MazeBiters.NativeStudy {
 // Screen-space recognition only. The maze still receives cardinal held keys,
 // exactly as it does for keyboard/controller diagonals; no corner cutting.
 public static class IpadSwipeDirections {
  const float Sector=45f,Hysteresis=5f;
  static readonly Vector2Int[] Octants={Vector2Int.right,new Vector2Int(1,1),new Vector2Int(0,1),new Vector2Int(-1,1),Vector2Int.left,new Vector2Int(-1,-1),new Vector2Int(0,-1),new Vector2Int(1,-1)};
  static readonly Vector2Int[] Cardinal={Vector2Int.left,Vector2Int.right,new Vector2Int(0,-1),new Vector2Int(0,1)};
  static readonly string[] Keys={"ipad-drag-left","ipad-drag-right","ipad-drag-up","ipad-drag-down"};

  public static Vector2Int Choose(Vector2 screenDelta,Vector2Int previous){
   if(screenDelta.sqrMagnitude<.0001f)return previous;
   float angle=Mathf.Atan2(-screenDelta.y,screenDelta.x)*Mathf.Rad2Deg;
   if(previous!=Vector2Int.zero){
    float oldAngle=Mathf.Atan2(previous.y,previous.x)*Mathf.Rad2Deg;
    if(Mathf.Abs(Mathf.DeltaAngle(oldAngle,angle))<=Sector*.5f+Hysteresis)return previous;
   }
   int octant=(Mathf.FloorToInt(angle/Sector+.5f)%8+8)%8;
   return Octants[octant];
  }

  public static void Sync(NativeGameplayWorld world,NativePlayer player,Vector2Int direction){
   if(world==null||player==null||player.IsAI)return;
   int mask=(direction.x<0?1:direction.x>0?2:0)|(direction.y<0?4:direction.y>0?8:0);
   using(world.ForPlayer(player)){
    for(int i=0;i<4;i++)if((mask&(1<<i))==0)world.Release(Keys[i]);
    for(int i=0;i<4;i++)if((mask&(1<<i))!=0&&!player.Keys.ContainsKey(Keys[i]))world.Press(Keys[i],Cardinal[i]);
    // A diagonal becoming cardinal must not leave Next on its released axis.
    int newest=-1;foreach(var key in player.Keys.Values)if(key.order>newest){newest=key.order;player.Next=key.dir;}
   }
  }

  public static void Release(NativeGameplayWorld world,NativePlayer player){
   if(world==null||player==null)return;
   using(world.ForPlayer(player))for(int i=0;i<4;i++)world.Release(Keys[i]);
  }
 }
}

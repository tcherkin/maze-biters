using System;
using System.Collections.Generic;
using UnityEngine;
namespace MazeBiters.NativeStudy {
 public sealed partial class NativeGameplayWorld {
  public bool CreatureFeuds=>!UseLegacyAi;
  readonly List<int> feudMemoryKeys=new List<int>();

  public double HunterGrudge(NativeGameplaySnake snake,NativeHunter hunter){
   return CreatureFeuds&&snake!=null&&hunter!=null&&snake.HunterThreat.TryGetValue(hunter.Id,out double value)?value:0;
  }
  public bool HunterCanCut(NativeHunter hunter,NativeGameplaySnake snake,int index){
   if(!CreatureFeuds||hunter==null||snake==null||!Hunters.Contains(hunter)||!Snakes.Contains(snake)||index<=0||index>=snake.Body.Count-1)return false;
   var cell=snake.Body[index];
   return Floor(cell)&&!Occupied(cell,snake)&&!HunterAt(cell,hunter)&&!SolidEgg(cell)&&!ScorpionAt(cell)&&PlayerAt(cell)==null;
  }
  public bool HunterCutAt(NativeHunter hunter,Vector2Int cell,out NativeGameplaySnake snake,out int index){
   snake=null;index=-1;if(!CreatureFeuds)return false;
   for(int i=0;i<Snakes.Count;i++){var candidate=Snakes[i];int at=candidate.Body.IndexOf(cell);if(at<0)continue;if(!HunterCanCut(hunter,candidate,at))return false;snake=candidate;index=at;return true;}
   return false;
  }
  public bool HunterCanEnter(NativeHunter hunter,Vector2Int cell){
   if(!Floor(cell)||HunterAt(cell,hunter)||SolidEgg(cell)||ScorpionAt(cell)||Repels(cell))return false;
   if(!Occupied(cell))return true;if(!CreatureFeuds)return false;
   // Walking into a head ricochets as before. Predation is directional: the
   // snake must itself advance its head into the hunter.
   if(SnakeHeadAt(cell))return false;
   return HunterCutAt(hunter,cell,out _,out _);
  }
  bool SnakeHeadAt(Vector2Int cell){for(int i=0;i<Snakes.Count;i++)if(Snakes[i].Body.Count>0&&Snakes[i].Head==cell)return true;return false;}
  void CopyHunterThreat(NativeGameplaySnake source,NativeGameplaySnake child){if(!CreatureFeuds)return;foreach(var pair in source.HunterThreat)child.HunterThreat[pair.Key]=pair.Value;}
  void HunterInjury(NativeGameplaySnake snake,NativeHunter hunter){
   MemoryCurrent(snake);snake.Anger+=2;snake.AngerPeak=Math.Max(snake.AngerPeak,snake.Anger);snake.AngerFloor=Math.Max(snake.AngerFloor,snake.AngerPeak*.5);
   snake.LastAnger=snake.LastMemory=Time;snake.HunterThreat[hunter.Id]=HunterGrudge(snake,hunter)+2;
   // Threat and PersonalThreat identify the players. A hunter's injury must not
   // make a human/ally who did not touch this snake inherit the blame.
  }
  public bool TryHunterCut(NativeHunter hunter,Vector2Int cell){
   if(hunter==null||hunter.Cell!=cell||!HunterCutAt(hunter,cell,out var snake,out int index))return false;
   MemoryCurrent(snake);var old=snake.Body.ToArray();var children=new List<NativeGameplaySnake>(2);
   foreach(var part in Fragments(snake,index)){
    var child=new NativeGameplaySnake{Id=nextId++,Body=part.body,Dir=part.dir,Palette=snake.Palette,Temperament=snake.Temperament,TurnBias=Random(),Anger=snake.Anger,AngerPeak=snake.AngerPeak,AngerFloor=snake.AngerFloor,LastAnger=snake.LastAnger,LastMemory=snake.LastMemory,Threat=snake.Threat,LastMove=Time};
    Array.Copy(snake.PersonalThreat,child.PersonalThreat,snake.PersonalThreat.Length);CopyHunterThreat(snake,child);child.Cell=child.Head;HunterInjury(child,hunter);children.Add(child);
   }
   int slot=Snakes.IndexOf(snake);Snakes.RemoveAt(slot);Snakes.InsertRange(slot,children);ForgetExternallySplitSnake(snake);
   hunter.NextCutAt=Time+NativeCreatureFeudProfile.ForIntensity(DifficultyProfile.Intensity).CutCooldownMs;
   hunter.BiteAt=Time+Math.Min(33.25,hunter.MoveDuration*.35);hunter.BiteEnd=hunter.BiteAt+95;
   SessionEffect("hunterSplit",cell);
   Event?.Invoke(new NativeWorldEvent{Kind="hunterSplit",Hunter=hunter,Snake=snake,OldBody=old,Created=children,Index=index,Cell=cell,Time=Time,Duration=218});
   return true;
  }
  void ForgetExternallySplitSnake(NativeGameplaySnake snake){
   // Do not call Ally.Split/Completed: neither a meal nor a player action took
   // place. Only invalidate references to the object that was replaced.
   for(int i=0;i<PlayerCount;i++){
    var a=GetPlayer(i).Ai;if(a==null)continue;bool changed=false;
    if(a.locked==snake){a.locked=null;a.bitten=false;a.commitMode=null;a.targetKind=null;a.commitUntil=0;changed=true;}
    if(a.graded==snake){a.graded=null;a.gradedKind=null;a.snakeChoiceUntil=0;changed=true;}
    if(a.split!=null&&a.split.snake==snake){a.split=null;changed=true;}
    if(a.casualSnake==snake){a.casualSnake=null;a.casualBites=0;a.casualGap=false;a.casualBiteCell=a.casualFollowCell=a.casualDirection=Vector2Int.zero;changed=true;}
    if(a.retreat!=null&&a.retreat.snake==snake){a.retreat=null;a.detourUntil=0;a.blockedStep=null;changed=true;}
    if(a.queue.RemoveAll(s=>s==snake)>0)changed=true;if(a.cooldowns.Remove(snake))changed=true;
    if(changed){a.replan=true;a.previewGrid=null;}
   }
  }
  public bool SnakeEatHunter(NativeGameplaySnake snake,NativeHunter hunter){
   if(!CreatureFeuds||snake==null||hunter==null||snake.Body.Count==0||!Snakes.Contains(snake)||snake.Head!=hunter.Cell||!Hunters.Remove(hunter))return false;
   for(int i=0;i<Snakes.Count;i++)Snakes[i].HunterThreat.Remove(hunter.Id);
   SessionEffect("snakeHunterBite",hunter.Cell);
   Event?.Invoke(new NativeWorldEvent{Kind="snakeHunterBite",Snake=snake,Hunter=hunter,Cell=hunter.Cell,Time=Time,Duration=140});return true;
  }
  void TouchHunterHead(NativeGameplaySnake snake){
   if(!CreatureFeuds||snake.Body.Count==0)return;
   for(int i=Hunters.Count-1;i>=0;i--)if(Hunters[i].Cell==snake.Head)SnakeEatHunter(snake,Hunters[i]);
  }
  void MemoryCurrent(NativeGameplaySnake snake){
   if(!CreatureFeuds||snake.LastAnger==0)return;
   double graceEnd=snake.LastAnger+20000+(snake.Temperament==0?.5:snake.Temperament)*10000;if(Time<graceEnd)return;
   double elapsed=Math.Max(0,Time-Math.Max(graceEnd,snake.LastMemory));
   if(snake.Anger>snake.AngerFloor)snake.Anger=Math.Max(snake.AngerFloor,snake.Anger-.000055*elapsed);snake.Threat=Math.Max(0,snake.Threat-.000035*elapsed);
   for(int i=0;i<snake.PersonalThreat.Length;i++)snake.PersonalThreat[i]=Math.Max(0,snake.PersonalThreat[i]-.000035*elapsed);
   feudMemoryKeys.Clear();foreach(var pair in snake.HunterThreat)feudMemoryKeys.Add(pair.Key);
   for(int i=0;i<feudMemoryKeys.Count;i++){
    int id=feudMemoryKeys[i];double value=Math.Max(0,snake.HunterThreat[id]-.000035*elapsed);bool alive=false;for(int h=0;h<Hunters.Count;h++)if(Hunters[h].Id==id){alive=true;break;}
    if(value<=0||!alive)snake.HunterThreat.Remove(id);else snake.HunterThreat[id]=value;
   }
   snake.LastMemory=Time;
  }
 }
}

using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Reflection;
using UnityEngine;
namespace MazeBiters.NativeStudy {
 public sealed partial class NativeGameplayStudy {
  bool scenePreparationValidation;
  [Serializable] sealed class SceneValidationResult {
   public string quality;public bool passed=true;public int cases,stateChecks,images,changedPixels,maxChannelError;
   public string[] failures;public ScenePreparationSample[] preparation;
  }
  // Diagnostics only. Read private scalar clocks, never serialize GPU objects.
  static string ScalarClock(object value){
   if(value==null)return "null";
   return string.Join("|",value.GetType().GetFields(BindingFlags.Instance|BindingFlags.Public|BindingFlags.NonPublic)
    .Where(f=>f.FieldType.IsPrimitive).OrderBy(f=>f.Name)
    .Select(f=>f.Name+"="+Convert.ToString(f.GetValue(value),System.Globalization.CultureInfo.InvariantCulture)));
  }
  static object ClockField(object value,string field)=>value.GetType().GetField(field,BindingFlags.Instance|BindingFlags.NonPublic).GetValue(value);
  string SceneClockState(){
   var eye=ClockField(neon,"eyes");var live=(Dictionary<int,NativeSnakeGlint>)ClockField(eye,"live");var legacyLive=(Dictionary<int,NativeAggressionGlint>)ClockField(eye,"legacyLive");
   return random+"|"+time+"|"+realClock+"|"+world.Time+"|"+world.RealTime+"|"+events.Count+"|"+biteInitial+"|"+
    JsonUtility.ToJson(world.Player)+"|"+string.Join(";",world.Snakes.Select(JsonUtility.ToJson))+"|"+
    string.Join(";",world.Hunters.Select(JsonUtility.ToJson))+"|"+
    string.Join(";",actors.Select(p=>p.Key+":"+ScalarClock(p.Value.blink)+":"+ScalarClock(p.Value.turn)+":"+
     (p.Value.neon==null?"":ScalarClock(ClockField(p.Value.neon,"clock")))))+"|"+
    string.Join(";",snakes.Values.Concat(ghosts).Select(s=>s.model.Id+":"+ScalarClock(s.motion)))+"|"+
    ScalarClock(scorpionArt?.Clock)+"|"+string.Join(";",scorpionGhosts.Select(g=>ScalarClock(g.art.Clock)))+"|"+
    ClockField(dusk,"angle")+"|"+ClockField(dusk,"initialized")+"|"+ClockField(eye,"last")+"|"+
    string.Join(";",((NativeAggressionGlint[])ClockField(eye,"clocks")).Select(ScalarClock))+"|"+
    string.Join(";",live.OrderBy(p=>p.Key).Select(p=>p.Key+":"+ScalarClock(p.Value)))+"|"+
    string.Join(";",legacyLive.OrderBy(p=>p.Key).Select(p=>p.Key+":"+ScalarClock(p.Value)));
  }
  IEnumerator ValidateScenePreparation(){
   var result=new SceneValidationResult{quality=quality};var failures=new List<string>();
   void Assert(bool ok,string name){result.stateChecks++;if(!ok){result.passed=false;failures.Add(name);}}
   void WarmCheck(string name){
    string before=SceneClockState();var motions=snakes.Values.Concat(ghosts).Select(s=>s.motion).ToArray();
    scenePreparationPending=true;PrepareSceneGpu();
    Assert(SceneClockState()==before,name+" clocks/world/RNG");
    Assert(motions.SequenceEqual(snakes.Values.Concat(ghosts).Select(s=>s.motion)),name+" original motion ownership");
    Assert(!scenePreparationPending,name+" GPU queue completed");
   }
   // Crowd, splits, forward/backwards intake, sole head, scorpion reverse and
   // the real campaign. Before initial render AND amid advancing animations.
   foreach(int scene in new[]{0,1,2,3,4,5,8,12}){
    coldSceneControl=true;Reset(scene);yield return DrainProbePreparation();coldSceneControl=false;
    result.cases++;WarmCheck(scene+" first scene");
    for(int step=0;step<12;step++){
     time+=41;realClock+=41;world.RealTime=realClock;
     world.Tick(time);world.UpdateTilt(time);
     // Deterministic flashlight input; neither wall-clock time nor GPU test
     // readback latency is allowed to change the reference image.
     preparationLightFrame=true;Render();
     var expected=PreparationPixels(target);WarmCheck(scene+"/"+step);
     preparationLightFrame=true;Render();var actual=PreparationPixels(target);result.images++;
     int changed=0,max=0;
     for(int p=0;p<expected.Length;p++){
      if(!expected[p].Equals(actual[p]))changed++;
      max=Math.Max(max,Math.Max(Math.Max(Math.Abs(expected[p].r-actual[p].r),Math.Abs(expected[p].g-actual[p].g)),
       Math.Max(Math.Abs(expected[p].b-actual[p].b),Math.Abs(expected[p].a-actual[p].a))));
     }
     result.changedPixels+=changed;result.maxChannelError=Math.Max(result.maxChannelError,max);
     Assert(max==0,scene+"/"+step+" exact composite pixels");
     if(step==4||step==7){
      quality=quality=="hd"?"4k":"hd";SetQuality();
      string state=SceneClockState();yield return DrainProbePreparation();
      Assert(state==SceneClockState(),scene+"/"+step+" quality-switch clocks");
     }
     yield return null;
    }
   }
   // Ordinary Update gate, not just coroutine diagnostics.
   bool wasContact=contactProbe,wasSmoke=smoke;contactProbe=false;smoke=false;
   PrepareLevelResources();string gateState=SceneClockState();
   Assert(preparationFrames==2&&scenePreparationPending,"gate holds input");
   Assert(WaitForLevelPreparation()&&preparationFrames==1&&scenePreparationPending,"gate waits deferred destruction");
   Assert(WaitForLevelPreparation()&&preparationFrames==0&&!scenePreparationPending&&discardPreparationDelta,"gate completes GPU before release");
   Assert(gateState==SceneClockState(),"gate unchanged clocks");
   contactProbe=wasContact;smoke=wasSmoke;discardPreparationDelta=false;
   result.failures=failures.ToArray();result.preparation=scenePreparationSamples.ToArray();
   Directory.CreateDirectory(Path.GetDirectoryName(report));File.WriteAllText(report,JsonUtility.ToJson(result,true));
   Application.Quit(result.passed?0:2);
  }
 }
}

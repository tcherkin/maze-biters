using System;
using UnityEngine;
namespace MazeBiters.NativeStudy {
 // One owner of camera history; the original camera supplies targets only.
 public sealed class IpadCameraMotion {
  public const double SoloZoomResponse=1040,RevealDuration=3120,DeathDuration=1560;
  public int EmergencyCorrections{get;private set;}
  public int JoiningMask{get;private set;}
  public bool Revealing=>transition||pending;
  bool ready,transition,pending,lastPresentation;double stamp,eventStarted,duration,carry,offsetCap;float width,height;Rect lastSafe;double lastClose;
  Projection current,reference,offset,velocity;Rect? lastBounds;
  struct Projection {
   public double z,x,y,h;
   public static Projection operator +(Projection a,Projection b)=>new Projection{z=a.z+b.z,x=a.x+b.x,y=a.y+b.y,h=a.h+b.h};
   public static Projection operator -(Projection a,Projection b)=>new Projection{z=a.z-b.z,x=a.x-b.x,y=a.y-b.y,h=a.h-b.h};
   public static Projection operator *(Projection a,double k)=>new Projection{z=a.z*k,x=a.x*k,y=a.y*k,h=a.h*k};
  }
  static double Clamp(double x,double a,double b)=>Math.Max(a,Math.Min(b,x));
  static double Blend(double dt,double tau)=>1-Math.Exp(-dt/tau);
  static Projection Project(NativeFrame f,IpadView v)=>new Projection{z=v.zoom,x=f.Width/2-v.x*v.zoom,y=f.Height/2-v.y*v.zoom,h=v.header};
  static IpadView View(NativeFrame f,Projection p)=>new IpadView{zoom=p.z,x=(f.Width/2-p.x)/p.z,y=(f.Height/2-p.y)/p.z,header=p.h};
  static double Shape(double u)=>u*u*u*(10+u*(-15+6*u));
  public static double RevealProgress(double elapsed)=>Shape(Clamp(elapsed/RevealDuration,0,1));
  static double CarryShape(double u)=>u-6*u*u*u+8*u*u*u*u-3*u*u*u*u*u;
  // Retain only forward progress along the new screen-space path. Perpendicular
  // or away velocity would overshoot and make the camera recoil at the end.
  static double ForwardRate(Projection v,Projection d){
   double numerator=v.h*d.h,denominator=d.h*d.h;
   foreach(double x in cornersX)foreach(double y in cornersY){double dx=d.x+x*d.z,dy=d.y+y*d.z;numerator+=(v.x+x*v.z)*dx+(v.y+y*v.z)*dy;denominator+=dx*dx+dy*dy;}
   return denominator>1e-12?Math.Max(0,numerator/denominator):0;
  }
  static readonly double[] cornersX={0,576},cornersY={0,400};
  public void Reset(){ready=transition=pending=false;JoiningMask=0;EmergencyCorrections=0;velocity=default;}
  public void BeginReveal(double real,int playerId){if(!ready)return;JoiningMask|=1<<(playerId-1);Begin(real,RevealDuration);}
  public void BeginLoss(double real,int playerId){if(!ready)return;JoiningMask&=~(1<<(playerId-1));Begin(real,DeathDuration);}
  void Begin(double real,double ms){pending=true;transition=true;eventStarted=real;duration=ms;}
  static void Limit(ref double amount,double origin,double slope){if(slope< -1e-12)amount=Math.Max(0,Math.Min(amount,origin/-slope));}
  static bool Near(Projection a,Projection b)=>Math.Abs(a.z-b.z)<.00001&&Math.Abs(a.x-b.x)<.002&&Math.Abs(a.y-b.y)<.002&&Math.Abs(a.h-b.h)<.002;
  static double Clearance(NativeFrame f,Projection p,Rect b,Rect safe)=>Math.Min(Math.Min(p.x+(b.xMin-12)*p.z-safe.xMin,safe.xMax-p.x-(b.xMax+12)*p.z),Math.Min(p.y+(b.yMin-12)*p.z-Math.Max(safe.yMin,p.h),safe.yMax-p.y-(b.yMax+12)*p.z));
  IpadView Commit(NativeFrame f,Projection p,double dt){if(dt>0)velocity=(p-current)*(1/dt);current=p;return View(f,p);}
  public IpadView Sample(NativeFrame f,double x,double y,double zoom,double close,Rect safe,Rect? bounds,double real,double? targetX=null,double? targetY=null,Rect? retainedBounds=null,double? targetZoom=null,bool presentation=false){
   bool reset=!ready||real<stamp||width!=f.Width||height!=f.Height||lastSafe!=safe||lastClose!=close;
   if(reset){
    var initial=IpadFraming.Calculate(f,x,y,zoom,close,safe);if(bounds.HasValue)initial=IpadFraming.KeepPlayers(f,initial,bounds.Value,safe);
    ready=true;transition=pending=false;JoiningMask=0;stamp=real;width=f.Width;height=f.Height;lastSafe=safe;lastClose=close;lastPresentation=presentation;lastBounds=bounds;current=reference=Project(f,initial);velocity=default;return initial;
   }
   if(presentation!=lastPresentation){lastPresentation=presentation;Begin(real,DeathDuration);}
   if(real==stamp&&!pending)return View(f,current);
   double elapsed=Math.Max(0,real-stamp),dt=Math.Min(elapsed,50);stamp=real;
   var requiredBounds=JoiningMask!=0?retainedBounds:bounds;
   bool boundsMoving=lastBounds.HasValue&&requiredBounds.HasValue&&lastBounds.Value!=requiredBounds.Value;
   lastBounds=requiredBounds;
   // One composition, before following. Never return to independently lagging
   // PC Zoom or re-warp the sky after a roster transition finishes.
   var desired=IpadFraming.Calculate(f,targetX??x,targetY??y,targetZoom??zoom,close,safe);
   if(bounds.HasValue)desired=IpadFraming.KeepPlayers(f,desired,bounds.Value,safe);
   var target=Project(f,desired);
   if(pending){
    // Only the reference snaps; its entire jump is cancelled in the visible offset.
    reference=target;offset=current-reference;carry=Clamp(ForwardRate(velocity,reference-current)*duration,0,1);offsetCap=1;pending=false;
   }else{
    double tau=Math.Abs(target.z-reference.z)>.00001?(target.z<reference.z?290:1040):470;
    var required=JoiningMask!=0?retainedBounds:bounds;
    // A stationary edge is not an emergency: preserve the original SOLO pace.
    // Accelerate only when a moving silhouette consumes the available margin.
    if(boundsMoving&&required.HasValue){double c=Clearance(f,current,required.Value,safe);tau+=(100-tau)*IpadFraming.Smooth((64-c)/64);}
    reference=reference+(target-reference)*Blend(dt,tau);
    if(Near(reference,target))reference=target;
   }
   // The continuing reference is itself a valid complete-roster composition.
   if(bounds.HasValue){
    var protectedReference=Project(f,IpadFraming.KeepPlayers(f,View(f,reference),bounds.Value,safe));
    if(Math.Abs(protectedReference.z-reference.z)>.00001||Math.Abs(protectedReference.x-reference.x)>.001||Math.Abs(protectedReference.y-reference.y)>.001)EmergencyCorrections++;
    reference=protectedReference;
   }
   var result=reference;
   if(transition){
    double u=Clamp((real-eventStarted)/duration,0,1),progress=Shape(u)+carry*CarryShape(u),remaining=Math.Min(offsetCap,1-progress);
    var required=JoiningMask!=0?retainedBounds:bounds;
    if(required.HasValue){var b=required.Value;
     Limit(ref remaining,reference.x+(b.xMin-12)*reference.z-safe.xMin,offset.x+(b.xMin-12)*offset.z);
     Limit(ref remaining,safe.xMax-reference.x-(b.xMax+12)*reference.z,-offset.x-(b.xMax+12)*offset.z);
     Limit(ref remaining,reference.y+(b.yMin-12)*reference.z-safe.yMin,offset.y+(b.yMin-12)*offset.z);
     Limit(ref remaining,reference.y+(b.yMin-12)*reference.z-reference.h,offset.y+(b.yMin-12)*offset.z-offset.h);
     Limit(ref remaining,safe.yMax-reference.y-(b.yMax+12)*reference.z,-offset.y-(b.yMax+12)*offset.z);
    }
    // Allow legitimate overview letterboxing, but never reveal an oversized
    // patch of cosmos when a moving reference changes during the transition.
    var overview=Project(f,IpadFraming.Calculate(f,288,200,1,close,safe));
    double left=Math.Max(52,overview.x),right=Math.Max(52,f.Width-overview.x-576*overview.z);
    double top=Math.Max(52,overview.y),bottom=Math.Max(52,f.Height-overview.y-400*overview.z);
    Limit(ref remaining,left-reference.x,-offset.x);
    Limit(ref remaining,reference.x+576*reference.z-f.Width+right,offset.x+576*offset.z);
    Limit(ref remaining,top-reference.y,-offset.y);
    Limit(ref remaining,reference.y+400*reference.z-f.Height+bottom,offset.y+400*offset.z);
    offsetCap=remaining;result=reference+offset*remaining;
    if(u>=1){transition=false;JoiningMask=0;}
   }
   return Commit(f,result,elapsed);
  }
 }
}

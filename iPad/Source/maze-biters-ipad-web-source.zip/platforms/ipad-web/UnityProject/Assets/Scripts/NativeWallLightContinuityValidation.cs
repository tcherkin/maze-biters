#if UNITY_EDITOR
using System;
using System.Collections.Generic;
using UnityEngine;

namespace MazeBiters.NativeStudy {
 [Serializable]public sealed class WallLightContinuityReport {
  public bool passed,allocationCounterAvailable;
  public string scope="Actual native route evaluation: all32streams, cached/reference/seek parity, close lifecycle and wall-cell boundary samples, long clocks, pause-like repeated clocks and calibrated managed-allocation checks. Before/after route scheduling intentionally differs; no exact old-image, frame-rate or physical-device claim.";
  public int maps,checks,failures,temporalSamples,lifecycleSamples,cellBoundarySamples,legacyVisibleJumps,newVisibleJumps,midlifeRouteChanges,capRoutes;
  public long allocationCalibrationBytes,steadyAllocatedBytes;
  public float maxNewFrameDisplacement,maxLegacyFrameDisplacement,maxIntensityStep,maxLifecycleIntensityDelta,maxGateFieldDelta;
  public double elapsedMilliseconds;
  public List<string> issues=new List<string>();
 }
 public static class NativeWallLightContinuityValidation {
  public static WallLightContinuityReport Run(){
   var report=new WallLightContinuityReport();var clock=System.Diagnostics.Stopwatch.StartNew();bool oldSelect=NativeHolisticTuning.RouteSelect;
   try{
    foreach(uint seed in new uint[]{17,34})foreach(int level in new[]{1,35,100}){
     var map=NativeCampaignComposition.Generate(seed,level,1);var prepared=NativeMazeArtwork.InspectWallLightRoutes(map.geometry);
     prepared.AuditContinuity(report,seed+"/"+level);report.maps++;
    }
   }catch(Exception e){report.failures++;report.issues.Add(e.ToString());}
   finally{NativeHolisticTuning.RouteSelect=oldSelect;clock.Stop();report.elapsedMilliseconds=clock.Elapsed.TotalMilliseconds;}
   report.passed=report.failures==0;return report;
  }
 }
 internal sealed partial class NativeWallLightRoutes {
  static void ContinuityCheck(WallLightContinuityReport r,bool okay,string label){r.checks++;if(okay)return;r.failures++;if(r.issues.Count<60)r.issues.Add(label);}
  static bool Equal(Vector4 a,Vector4 b)=>a.x==b.x&&a.y==b.y&&a.z==b.z&&a.w==b.w;
  static float SourceKernel(Vector4 source,Vector2 world){
   int cell=Cell(world),own=Cell(new Vector2(source.x,source.y)),before=(int)(source.w%1024)-1,after=(int)(source.w/1024)-1;
   if(cell!=own&&cell!=before&&cell!=after)return 0;float x=(world.x-source.x)/11.2f,y=(world.y-source.y)/11.2f,a=Mathf.Clamp01(1-x*x-y*y);return a*a*a*source.z;
  }
  internal void AuditContinuity(WallLightContinuityReport r,string label){
   var smooth=new NativeWallLightRoutes(masks,false);var legacy=new NativeWallLightRoutes(masks,true);var reference=new NativeWallLightRoutes(masks,false);
   ContinuityCheck(r,smooth.Count>0,label+" has real interior routes");if(smooth.Count==0)return;
   var prior=new Vector4[StreamCount*3];var oldPrior=new Vector4[StreamCount*3];var previousRoutes=new int[StreamCount];
   var previousCycles=new long[StreamCount];float maximumSpeed=0;foreach(var route in smooth.routes){maximumSpeed=Mathf.Max(maximumSpeed,route.Length/TravelSeconds);if(route.Cap)r.capRoutes++;}
   foreach(double rate in new[]{.4,.6,.8,1,1.25,1.6}){
    NativeHolisticTuning.RouteSelect=true;Array.Copy(smooth.Evaluate(0),prior,prior.Length);Array.Copy(legacy.Evaluate(0),oldPrior,oldPrior.Length);
    for(int s=0;s<StreamCount;s++){previousRoutes[s]=smooth.selectedRoutes[s];SampleClock(0,s,out previousCycles[s],out _);}
    double dt=rate/120;int frames=(int)Math.Ceiling(SlotSeconds*3/dt);
    for(int frame=1;frame<=frames;frame++){
     double t=frame*dt;var current=smooth.Evaluate(t);var old=legacy.Evaluate(t);r.temporalSamples++;
     for(int s=0;s<StreamCount;s++){
      SampleClock(t,s,out long cycle,out _);
      if(cycle==previousCycles[s]&&smooth.selectedRoutes[s]!=previousRoutes[s])r.midlifeRouteChanges++;
      for(int trail=0;trail<3;trail++){
       int i=s*3+trail;var a=prior[i];var b=current[i];float jump=Vector2.Distance(new Vector2(a.x,a.y),new Vector2(b.x,b.y));
       if(a.z>.001f&&b.z>.001f){r.maxNewFrameDisplacement=Mathf.Max(r.maxNewFrameDisplacement,jump);if(jump>maximumSpeed*(float)dt+.003f)r.newVisibleJumps++;}
       r.maxIntensityStep=Mathf.Max(r.maxIntensityStep,Mathf.Abs(a.z-b.z));
       var oa=oldPrior[i];var ob=old[i];float oldJump=Vector2.Distance(new Vector2(oa.x,oa.y),new Vector2(ob.x,ob.y));
       if(oa.z>.001f&&ob.z>.001f){r.maxLegacyFrameDisplacement=Mathf.Max(r.maxLegacyFrameDisplacement,oldJump);if(oldJump>12)r.legacyVisibleJumps++;}
       prior[i]=b;oldPrior[i]=ob;
      }
      previousRoutes[s]=smooth.selectedRoutes[s];previousCycles[s]=cycle;
     }
    }
   }
   ContinuityCheck(r,r.newVisibleJumps==0,label+" no visible source teleport at any configured speed");
   ContinuityCheck(r,r.midlifeRouteChanges==0,label+" route selection changes only at its own birth");
   ContinuityCheck(r,r.maxIntensityStep<.06f,label+" smooth intensity steps at120Hz including EXTREME");
   // Close two-sided samples at every lifecycle boundary, on normal and very
   // long double clocks; a route jump is allowed only while strength is zero.
   foreach(double epoch in new[]{25.0,86400.0,1000000000.0})for(int s=0;s<StreamCount;s++){
    long cycle=(long)Math.Ceiling((epoch+StreamOffsetSeconds(s))/SlotSeconds);double birth=cycle*SlotSeconds-StreamOffsetSeconds(s);
    foreach(double phase in new[]{0.0,.7,9.3,9.55,9.6,9.9,10.05,12.5}){
     double t=birth+phase,epsilon=epoch>1e8?1e-5:1e-6;
     var a=smooth.Evaluate(t-epsilon);for(int k=0;k<3;k++)prior[k]=a[s*3+k];var b=smooth.Evaluate(t+epsilon);r.lifecycleSamples++;
     for(int k=0;k<3;k++){float delta=Mathf.Abs(prior[k].z-b[s*3+k].z);r.maxLifecycleIntensityDelta=Mathf.Max(r.maxLifecycleIntensityDelta,delta);ContinuityCheck(r,delta<.0001f,label+" lifecycle intensity is continuous");}
     if(phase==0||phase==12.5)for(int k=0;k<3;k++)ContinuityCheck(r,prior[k].z<1e-6f&&b[s*3+k].z<1e-6f,label+" both sides of respawn are dark");
    }
   }
   // Sweep actual rounded routes for cell transitions, then inspect all three
   // topology sample offsets around each crossing. This measures the existing
   // shader gate separately from source-position/amplitude continuity.
   for(int s=0;s<StreamCount;s++){
    const long cycle=2;double birth=cycle*SlotSeconds-StreamOffsetSeconds(s);smooth.Evaluate(birth+1);var route=smooth.routes[smooth.selectedRoutes[s]];
    int previous=Cell(route.At(0));float previousDistance=0;
    for(float distance=.5f;distance<=route.Length;distance+=.5f){int cell=Cell(route.At(distance));if(cell==previous){previousDistance=distance;continue;}
     float lo=previousDistance,hi=distance;for(int refine=0;refine<20;refine++){float mid=(lo+hi)*.5f;if(Cell(route.At(mid))==previous)lo=mid;else hi=mid;}
     float boundary=(lo+hi)*.5f;
     foreach(float shift in new[]{-8f,0,8f})for(int trail=0;trail<3;trail++){
      double phase=(boundary+shift+trail*4.2f)/route.Length*TravelSeconds;if(phase<=.001||phase>=TravelSeconds)continue;
      double t=birth+phase;var a=smooth.Evaluate(t-1e-6);for(int k=0;k<3;k++)prior[k]=a[s*3+k];var b=smooth.Evaluate(t+1e-6);r.cellBoundarySamples++;
      for(int k=0;k<3;k++)ContinuityCheck(r,Vector2.Distance(new Vector2(prior[k].x,prior[k].y),new Vector2(b[s*3+k].x,b[s*3+k].y))<.002f&&Mathf.Abs(prior[k].z-b[s*3+k].z)<.0001f,label+" rounded-cell source movement is continuous");
      var p=new Vector2(b[s*3+trail].x,b[s*3+trail].y);
      for(float y=Mathf.Floor(p.y-11.2f)+.5f;y<p.y+11.2f;y+=2)for(float x=Mathf.Floor(p.x-11.2f)+.5f;x<p.x+11.2f;x+=2){
       int cx=(int)(x/16),cy=(int)(y/16);if(x<0||y<0||cx>=36||cy>=25||masks[cx,cy]<0)continue;
       float before=0,after=0;var world=new Vector2(x,y);for(int k=0;k<3;k++){before+=SourceKernel(prior[k],world);after+=SourceKernel(b[s*3+k],world);}
       r.maxGateFieldDelta=Mathf.Max(r.maxGateFieldDelta,Mathf.Abs(after-before));
      }
     }
     previous=cell;previousDistance=distance;
    }
   }
   // Reference arithmetic, reduced counts, repeated/paused clocks, backward
   // seeks and restored32-stream fields must all return the same values.
   foreach(double t in new[]{37.123,0.0,12.5,1.0,86400.123,1000000000.25,5.0})foreach(int count in new[]{32,4,8,16,32}){
    NativeHolisticTuning.RouteSelect=false;var expected=reference.Evaluate(t,false,count);
    NativeHolisticTuning.RouteSelect=true;var actual=smooth.Evaluate(t,false,count);
    for(int i=0;i<actual.Length;i++)ContinuityCheck(r,Equal(expected[i],actual[i])&&Equal(reference.SourceCells[i],smooth.SourceCells[i]),label+" cached/reference/seek source equality");
    for(int i=0;i<StreamCount;i++)ContinuityCheck(r,Equal(reference.StreamBounds[i],smooth.StreamBounds[i]),label+" cached/reference/seek bound equality");
    long evaluations=smooth.Evaluations;var paused=smooth.Evaluate(t,false,count);ContinuityCheck(r,ReferenceEquals(actual,paused)&&smooth.Evaluations==evaluations,label+" paused same-clock evaluation is reused");
   }
   NativeHolisticTuning.RouteSelect=true;
   for(int i=0;i<200;i++)smooth.Evaluate(100+i/120.0);
   byte[] calibration=null;try{long start=GC.GetAllocatedBytesForCurrentThread();calibration=new byte[65536];r.allocationCalibrationBytes=GC.GetAllocatedBytesForCurrentThread()-start;r.allocationCounterAvailable=r.allocationCalibrationBytes>=65536;GC.KeepAlive(calibration);}catch(NotSupportedException){}
   if(r.allocationCounterAvailable){long start=GC.GetAllocatedBytesForCurrentThread();for(int i=0;i<3000;i++)smooth.Evaluate(200+i/120.0);long allocated=GC.GetAllocatedBytesForCurrentThread()-start;r.steadyAllocatedBytes+=allocated;ContinuityCheck(r,allocated==0,label+" route hot path allocates no managed bytes including births");}
  }
 }
}
#endif

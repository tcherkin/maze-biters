using System;
using System.Collections.Generic;
using System.Linq;
using UnityEngine;
namespace MazeBiters.NativeStudy {
 public sealed partial class NativeGameplayWorld {
  Vector2Int[][] preparedSafeOpening;
  internal Vector2Int[][] PrepareSafeOpeningLayout(){SpawnBaselineLevelSnakes();return Snakes.Select(s=>s.Body.ToArray()).ToArray();}
  public bool OpeningPlacementRecovered {get;private set;}
  public int OpeningPlacementSearch {get;private set;}
#if UNITY_EDITOR
  internal static bool ValidateOriginalOpeningSearch;
#endif
  // Only entered after the original four greedy layouts fail. Reconsider an
  // earlier placement instead of retrying the same impossible suffix. Preserve
  // all lengths, safe exits, palette/temperament assignments and RNG draw order.
  bool RecoverSafeOpening(NativeSpawnSafety safety,List<Vector2Int> floor,int[] lengths,uint[] salts,out List<List<Vector2Int>> result){
   result=null;
#if UNITY_EDITOR
   if(ValidateOriginalOpeningSearch)return false;
#endif
   // The loading worker proves a complete opening fits with all three starts
   // protected. Reuse that small CPU layout only if the live greedy order fails.
   // Match by length so identities, colours and temperament keep their slots.
   if(preparedSafeOpening!=null&&preparedSafeOpening.Length==lengths.Length){
    var remaining=new List<Vector2Int[]>(preparedSafeOpening);var matched=new List<List<Vector2Int>>();
    foreach(int length in lengths){int index=remaining.FindIndex(p=>p.Length==length);if(index<0)break;matched.Add(new List<Vector2Int>(remaining[index]));remaining.RemoveAt(index);}
    if(matched.Count==lengths.Length){result=matched;OpeningPlacementRecovered=true;return true;}
   }
   int count=lengths.Length,nodes=0;const int budget=180000;
   var order=Enumerable.Range(0,count).OrderByDescending(i=>lengths[i]).ThenBy(i=>i).ToArray();
   var blocked=new bool[Width*Height];var paths=new List<Vector2Int>[count];
   var headings=new Vector2Int[count][];var candidates=new Vector2Int[count][];
   for(int i=0;i<count;i++){
    headings[i]=Dirs.OrderBy(d=>SpawnRank(d,salts[i])).ToArray();
    var preferred=SpawnCells[i];
    candidates[i]=floor.OrderBy(c=>Math.Abs(c.x-preferred.x)+Math.Abs(c.y-preferred.y)).ThenBy(c=>SpawnRank(c,salts[i])).ToArray();
   }
   bool Free(Vector2Int c)=>Floor(c)&&!safety.Reserved(c)&&!blocked[Index(c)];
   bool Place(int depth){
    if(depth==count)return true;
    int slot=order[depth];var directions=headings[slot];
    foreach(var head in candidates[slot]){
     if(++nodes>budget)return false;if(!Free(head))continue;
     foreach(var dir in directions){
      var step=head+dir;var neck=head-dir;
      if(!Free(step)||!Free(neck)||safety.FacingRisk(head,dir))continue;
      var path=new List<Vector2Int>(lengths[slot]){head,neck};int local=0;
      blocked[Index(head)]=blocked[Index(neck)]=blocked[Index(step)]=true;
      bool Grow(Vector2Int previous){
       if(++nodes>budget||++local>800)return false;
       if(path.Count==lengths[slot]){paths[slot]=new List<Vector2Int>(path);return Place(depth+1);}
       var tail=path[path.Count-1];
       for(int turn=0;turn<5;turn++){
        var d=turn==0?previous:directions[turn-1];if(turn>0&&d==previous)continue;
        var c=tail+d;if(!Free(c))continue;
        blocked[Index(c)]=true;path.Add(c);
        if(Grow(d))return true;
        path.RemoveAt(path.Count-1);blocked[Index(c)]=false;
        if(nodes>budget)return false;
       }
       return false;
      }
      if(Grow(-dir))return true;
      blocked[Index(head)]=blocked[Index(neck)]=blocked[Index(step)]=false;
      paths[slot]=null;if(nodes>budget)return false;
     }
    }
    return false;
   }
   bool success=Place(0);OpeningPlacementSearch=nodes;OpeningPlacementRecovered=success;
   if(success)result=paths.ToList();return success;
  }
 }
}

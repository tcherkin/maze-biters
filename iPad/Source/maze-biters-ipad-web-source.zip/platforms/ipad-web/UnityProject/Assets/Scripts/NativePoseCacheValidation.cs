using System;using System.IO;using System.Collections;using UnityEngine;
namespace MazeBiters.NativeStudy {
 public sealed partial class NativeGameplayStudy {
  [Serializable] sealed class PoseCachePoseResult {public bool passed;public string quality;public int cases,maxError,recoveryChecks;public long channels;}
  IEnumerator ValidatePoseCachePoses(){bool restore=NativePoseCache.Enabled;var read=new Texture2D(bank.Size,bank.Size,TextureFormat.RGBA32,false);int cases=0,maxError=0,recoveryChecks=0;long channels=0;
   Color32[] Pixels(RenderTexture t){var previous=RenderTexture.active;RenderTexture.active=t;read.ReadPixels(new Rect(0,0,t.width,t.height),0,0,false);RenderTexture.active=previous;return read.GetPixels32();}
   void Equal(Color32[] a,Color32[] b){if(a.Length!=b.Length)throw new Exception("Pose dimensions");for(int i=0;i<a.Length;i++){int e=Math.Max(Math.Max(Math.Abs(a[i].r-b[i].r),Math.Abs(a[i].g-b[i].g)),Math.Max(Math.Abs(a[i].b-b[i].b),Math.Abs(a[i].a-b[i].a)));maxError=Math.Max(maxError,e);}channels+=(long)a.Length*4;}
   try {foreach(string family in new[]{"fantasy","dragon"})using(var actor=new NativeTurnActor(bank,family,family=="fantasy"?"p1":"h1"))using(var glow=family=="dragon"?new NativeHunterNeon(quad,bank.Size,771):null){
    foreach(string palette in family=="fantasy"?new[]{"p1","p2","ai"}:new[]{"h1","h3","h4"})foreach(bool bright in family=="fantasy"?new[]{false,true}:new[]{false}){
     actor.Palette=palette;actor.Bright=bright;
     for(int direction=0;direction<4;direction++)foreach(double mix in new[]{0,.25,.5,.75,1})foreach(int mouth in new[]{0,24,48}){
      var pose=new TurnPose{from=direction,to=(direction+1)%4,mix=mix};int blink=mouth/2;
      NativePoseCache.Enabled=true;bank.Render(actor,pose,mouth,blink);long version=actor.OutputRevision;bank.Render(actor,pose,mouth,blink);if(actor.OutputRevision!=version)throw new Exception("Identical pose not poseCached");
      var composed=Pixels(actor.Output);Color32[] lit=null,emission=null,mask=null;
      if(glow!=null){glow.Render(bank,actor,pose,mouth,blink,2000,.8,Matrix4x4.identity,0);glow.Render(bank,actor,pose,mouth,blink,2100,.8,Matrix4x4.identity,0);glow.Render(bank,actor,pose,mouth,blink,2100,.8,Matrix4x4.identity,0,true);lit=Pixels(glow.Lit);emission=Pixels(glow.Glow);mask=Pixels(glow.Mask);}
      NativePoseCache.Enabled=false;bank.Render(actor,pose,mouth,blink);Equal(composed,Pixels(actor.Output));if(glow!=null){glow.Render(bank,actor,pose,mouth,blink,2100,.8,Matrix4x4.identity,0,true);Equal(lit,Pixels(glow.Lit));Equal(emission,Pixels(glow.Glow));Equal(mask,Pixels(glow.Mask));}
      cases++;
     }
     yield return null;
    }
   }
   using(var actor=new NativeTurnActor(bank,"dragon","h1"))using(var glow=new NativeHunterNeon(quad,bank.Size,772)){
    var pose=new TurnPose{from=0,to=1,mix=.5};NativePoseCache.Enabled=true;
    bank.Render(actor,pose,24,12);var expected=Pixels(actor.Output);long revision=actor.OutputRevision;
    actor.Output.Release();bank.Render(actor,pose,24,12);if(actor.OutputRevision<=revision)throw new Exception("Lost pose output was reused");Equal(expected,Pixels(actor.Output));recoveryChecks++;
    glow.Render(bank,actor,pose,24,12,2100,.8,Matrix4x4.identity,0,true);var emission=Pixels(glow.Glow);var iris=Pixels(glow.Mask);
    glow.Glow.Release();glow.Render(bank,actor,pose,24,12,2100,.8,Matrix4x4.identity,0,true);Equal(emission,Pixels(glow.Glow));recoveryChecks++;
    glow.Mask.Release();glow.Render(bank,actor,pose,24,12,2100,.8,Matrix4x4.identity,0,true);Equal(iris,Pixels(glow.Mask));recoveryChecks++;
   }
   }finally{NativePoseCache.Enabled=restore;Destroy(read);}
   File.WriteAllText(Path.ChangeExtension(report,"poses.json"),JsonUtility.ToJson(new PoseCachePoseResult{passed=maxError==0,quality=quality,cases=cases,maxError=maxError,channels=channels,recoveryChecks=recoveryChecks},true));if(maxError!=0)throw new Exception("Pose cache changed pixels: "+maxError);
  }
 }
}

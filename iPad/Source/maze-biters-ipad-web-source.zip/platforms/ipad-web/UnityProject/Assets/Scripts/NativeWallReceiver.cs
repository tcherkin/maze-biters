using System;
using System.IO;
using UnityEngine;

namespace MazeBiters.NativeStudy {
 // Static native-art relief only. Soft illumination/blockers remain at their
 // original resolution; the thin wall contour is sampled at the final pixel.
 public sealed class NativeWallReceiver : IDisposable {
  public const int Width=2880,Height=2000;
  public const long Bytes=(long)Width*Height;
  public readonly Texture2D Texture;
  public long TextureBytes{get;private set;}
  public NativeWallReceiver(string prefix="",byte[] generated=null,int width=Width,int height=Height){
   if(width<=0||height<=0||(width!=Width||height!=Height)&&(width!=Width*2||height!=Height*2))throw new ArgumentOutOfRangeException("Native wall receiver dimensions");
   byte[] data;if(generated!=null)data=generated;else if(prefix.Length==0)data=File.ReadAllBytes(Path.Combine(WebFiles.Root,"Reference/neon-receiver-detail.bin"));else{using(var input=File.OpenRead(Path.Combine(WebFiles.Root,"Reference",prefix+"neon-receiver-detail.bin.gz")))using(var gz=new System.IO.Compression.GZipStream(input,System.IO.Compression.CompressionMode.Decompress))using(var output=new MemoryStream()){gz.CopyTo(output);data=output.ToArray();}}
   TextureBytes=(long)width*height;
   if(data.LongLength!=TextureBytes)throw new InvalidDataException("Invalid native wall receiver");
   if(!SystemInfo.SupportsTextureFormat(TextureFormat.R8))throw new NotSupportedException("R8 wall receiver unavailable");
   Texture=new Texture2D(width,height,TextureFormat.R8,false,true){name="Native wall relief",filterMode=FilterMode.Bilinear,wrapMode=TextureWrapMode.Clamp};
   Texture.LoadRawTextureData(data);Texture.Apply(false,true);
  }
  public void Dispose(){UnityEngine.Object.Destroy(Texture);}
 }
}

using System;
using System.IO;
using System.IO.Compression;
using Unity.Collections;
using UnityEngine;
using CompressionLevel=System.IO.Compression.CompressionLevel;
namespace MazeBiters.NativeStudy {
 public sealed partial class NativeMazeArtwork {
  // The control keeps the previous raw CPU staging; neither mode changes GPU
  // texture formats, dimensions, sampling, painter formulas or publication count.
  public static readonly bool CompactGlassCache=Array.IndexOf(Environment.GetCommandLineArgs(),"--legacy-glass-cache-memory")<0;
  const int GlassChunkPixels=W*128,GlassChunkBytes=GlassChunkPixels*4;
  byte[][] packedGlassMaze,packedGlassEmission;byte[] glassUnpackBuffer;
  struct StartupPixelBlock {public NativeArray<uint> data;public bool raw;}
  StartupPixelBlock[] runGlassMaze,runGlassEmission;uint[] glassRunUnpack;
  bool HasPackedGlass=>packedGlassMaze!=null||runGlassMaze!=null;
  public double GlassPackingMs{get;private set;}
  public long GlassRawStagingBytes=>IsGlass?9L*glassWidth*glassHeight+576L*400*4:0;
  public long GlassStagingBytes {
   get{long bytes=(Relief?.LongLength??0)+(pendingLow?.LongLength??0)*4;
    if(pixels.IsCreated)bytes+=4L*pixels.Length;if(glassEmissionPixels.IsCreated)bytes+=4L*glassEmissionPixels.Length;
    foreach(var blocks in new[]{packedGlassMaze,packedGlassEmission})if(blocks!=null)foreach(var b in blocks)bytes+=b?.LongLength??0;
    foreach(var blocks in new[]{runGlassMaze,runGlassEmission})if(blocks!=null)foreach(var b in blocks)if(b.data.IsCreated)bytes+=b.data.Length*4L;
    return bytes+(glassUnpackBuffer?.LongLength??0)+(glassRunUnpack?.LongLength??0)*4;
   }
  }
  internal void PackStartupStaging(){
#if UNITY_WEBGL && !UNITY_EDITOR
   if(WebWorkQueue.Capturing){WebWorkQueue.Defer(PackGlassWeb());return;}
#endif
   if(!IsGlass||!CompactGlassCache)return;
   var timer=System.Diagnostics.Stopwatch.StartNew();
   try{
    if(NativeBalancedLaunch.FastCache){runGlassMaze=PackStartupPixels(pixels);pixels.Dispose();runGlassEmission=PackStartupPixels(glassEmissionPixels);glassEmissionPixels.Dispose();}
    else PackGlassStaging(true);
   }catch{DisposeStaging();throw;}
   GlassPackingMs=timer.Elapsed.TotalMilliseconds;Profile.totalMs+=GlassPackingMs;
   NativeStartupLoading.AddMs("boot cache packing",GlassPackingMs);
  }
  StartupPixelBlock[] PackStartupPixels(NativeArray<Color32> source){
   var words=source.Reinterpret<uint>(4);var blocks=new StartupPixelBlock[(words.Length+GlassChunkPixels-1)/GlassChunkPixels];
   try{using(var scratch=new System.Threading.ThreadLocal<(uint[] input,uint[] work,int[] table)>(()=>(new uint[GlassChunkPixels],new uint[GlassChunkPixels+1],new int[65536])))
     System.Threading.Tasks.Parallel.For(0,blocks.Length,new System.Threading.Tasks.ParallelOptions{MaxDegreeOfParallelism=GlassPainterWorkers,CancellationToken=glassCancellation},i=>{
      int offset=i*GlassChunkPixels,count=Math.Min(GlassChunkPixels,words.Length-offset);var buffers=scratch.Value;
      NativeArray<uint>.Copy(words,offset,buffers.input,0,count);int used=NativeStartupPixels.Encode(buffers.input,count,buffers.work,buffers.table,out bool raw);
      blocks[i]=new StartupPixelBlock{data=new NativeArray<uint>(used,Allocator.Persistent,NativeArrayOptions.UninitializedMemory),raw=raw};
      NativeArray<uint>.Copy(raw?buffers.input:buffers.work,0,blocks[i].data,0,used);
     });
   }catch{DisposeStartupBlocks(blocks);throw;}
   return blocks;
  }
  static void DisposeStartupBlocks(StartupPixelBlock[] blocks){if(blocks!=null)for(int i=0;i<blocks.Length;i++){if(blocks[i].data.IsCreated)blocks[i].data.Dispose();blocks[i]=default;}}
  void DisposeStartupPixels(){DisposeStartupBlocks(runGlassMaze);DisposeStartupBlocks(runGlassEmission);runGlassMaze=runGlassEmission=null;}
  void PackGlassStaging(bool parallel=false){
   var buffer=parallel&&GlassPainterWorkers>1?null:new byte[GlassChunkBytes];
   packedGlassMaze=PackGlassPixels(pixels,buffer,parallel);pixels.Dispose();
   packedGlassEmission=PackGlassPixels(glassEmissionPixels,buffer,parallel);glassEmissionPixels.Dispose();
  }
  byte[][] PackGlassPixels(NativeArray<Color32> source,byte[] buffer,bool parallel=false){
   var bytes=source.Reinterpret<byte>(4);var blocks=new byte[(bytes.Length+GlassChunkBytes-1)/GlassChunkBytes][];
   void Pack(int i,byte[] staging){
    glassCancellation.ThrowIfCancellationRequested();
    int offset=i*GlassChunkBytes,count=Math.Min(GlassChunkBytes,bytes.Length-offset);NativeArray<byte>.Copy(bytes,offset,staging,0,count);
    using(var output=new MemoryStream()){
     using(var gzip=new GZipStream(output,CompressionLevel.Fastest,true))gzip.Write(staging,0,count);
     blocks[i]=output.ToArray();
    }
   }
   // Startup only: the same independent lossless chunks, bounded by the map
   // painter's worker count. Live-level preparation retains its original policy.
   if(parallel&&GlassPainterWorkers>1){
    using(var buffers=new System.Threading.ThreadLocal<byte[]>(()=>new byte[GlassChunkBytes]))
     System.Threading.Tasks.Parallel.For(0,blocks.Length,new System.Threading.Tasks.ParallelOptions{MaxDegreeOfParallelism=GlassPainterWorkers,CancellationToken=glassCancellation},i=>Pack(i,buffers.Value));
   }else for(int i=0;i<blocks.Length;i++)Pack(i,buffer);
   return blocks;
  }
  static void UnpackGlassBlock(byte[] block,byte[] buffer,int count){
   if(block==null)throw new InvalidDataException("Missing glass cache block");
   using(var input=new MemoryStream(block,false))using(var gzip=new GZipStream(input,CompressionMode.Decompress)){
    int offset=0;while(offset<count){int n=gzip.Read(buffer,offset,count-offset);if(n==0)throw new EndOfStreamException("Truncated glass cache block");offset+=n;}
    if(gzip.ReadByte()!=-1)throw new InvalidDataException("Oversized glass cache block");
   }
  }
  void CopyPackedGlassRows(Texture2D target){
   var blocks=target==glassPublishingMaze?packedGlassMaze:packedGlassEmission;
   int total=glassWidth*glassHeight,count=Math.Min(GlassChunkPixels,total-glassPublishOffset),index=glassPublishOffset/GlassChunkPixels;
   if(runGlassMaze!=null){
    var runs=target==glassPublishingMaze?runGlassMaze:runGlassEmission;
    if(glassRunUnpack==null)glassRunUnpack=new uint[GlassChunkPixels];
    NativeStartupPixels.UnpackNative(runs[index].data,runs[index].raw,glassRunUnpack,count);NativeArray<uint>.Copy(glassRunUnpack,0,target.GetRawTextureData<uint>(),glassPublishOffset,count);
    runs[index].data.Dispose();runs[index]=default;
   }else{
    if(glassUnpackBuffer==null)glassUnpackBuffer=new byte[GlassChunkBytes];
    UnpackGlassBlock(blocks[index],glassUnpackBuffer,count*4);NativeArray<byte>.Copy(glassUnpackBuffer,0,target.GetRawTextureData<byte>(),glassPublishOffset*4,count*4);
   }
   // No longer retain a compressed block after its original publication slice.
   if(blocks!=null)blocks[index]=null;glassPublishOffset+=count;
   if(glassPublishOffset==total){glassPublishOffset=0;glassPublishStage++;}
  }
  void WritePackedGlassValidation(string file,byte[][] blocks){
   var buffer=new byte[GlassChunkBytes];int total=glassWidth*glassHeight*4;
   using(var output=File.Create(file))using(var gzip=new GZipStream(output,CompressionLevel.Fastest))
    for(int i=0,offset=0;offset<total;i++,offset+=GlassChunkBytes){int count=Math.Min(GlassChunkBytes,total-offset);UnpackGlassBlock(blocks[i],buffer,count);gzip.Write(buffer,0,count);}
  }
  void WriteStartupGlassValidation(string file,StartupPixelBlock[] blocks){
   var words=new uint[GlassChunkPixels];var buffer=new byte[GlassChunkBytes];int total=glassWidth*glassHeight;
   using(var output=File.Create(file))using(var gzip=new GZipStream(output,CompressionLevel.Fastest))
    for(int i=0,offset=0;offset<total;i++,offset+=GlassChunkPixels){int count=Math.Min(GlassChunkPixels,total-offset);UnpackStartup(i,count);gzip.Write(buffer,0,count*4);}
   void UnpackStartup(int i,int count){NativeStartupPixels.UnpackNative(blocks[i].data,blocks[i].raw,words,count);Buffer.BlockCopy(words,0,buffer,0,count*4);}
  }
 }
}

using System;
namespace MazeBiters.NativeStudy {
 // Presentation only. The opacity is baked into the existing maze texture
 // during level preparation; no extra texture or per-frame CPU pixel work.
 public static class NativeTunnelSky {
  public const float Transparency=.40f;
  // Fixed sky radiance, independent of the local beam. Through the tunnel core
  // this is 20% of the outside sky (previously 8% in darkness, 40% in the beam).
  public const float StarVisibility=.50f;
  const int Tile=80;
  static readonly bool disabled=Array.IndexOf(Environment.GetCommandLineArgs(),"--opaque-tunnels")>=0;
  public static bool Enabled=>NativeDisplay.Enabled&&!disabled;
  static readonly byte[][] tiles=new byte[256][];
  static readonly object gate=new object();
  public static int WallMask(string[] grid,int x,int y){
   bool Solid(int px,int py)=>py<0||py>=grid.Length||px<0||px>=grid[py].Length||grid[py][px]=='#';
   return (Solid(x,y-1)?1:0)|(Solid(x+1,y)?2:0)|(Solid(x,y+1)?4:0)|(Solid(x-1,y)?8:0)|
    (Solid(x-1,y-1)?16:0)|(Solid(x+1,y-1)?32:0)|(Solid(x+1,y+1)?64:0)|(Solid(x-1,y+1)?128:0);
  }
  public static byte Alpha(int mask,double x,double y){
   double distance=16;
   if((mask&1)!=0)distance=Math.Min(distance,y);if((mask&2)!=0)distance=Math.Min(distance,16-x);
   if((mask&4)!=0)distance=Math.Min(distance,16-y);if((mask&8)!=0)distance=Math.Min(distance,x);
   if((mask&16)!=0)distance=Math.Min(distance,Math.Sqrt(x*x+y*y));
   if((mask&32)!=0)distance=Math.Min(distance,Math.Sqrt((16-x)*(16-x)+y*y));
   if((mask&64)!=0)distance=Math.Min(distance,Math.Sqrt((16-x)*(16-x)+(16-y)*(16-y)));
   if((mask&128)!=0)distance=Math.Min(distance,Math.Sqrt(x*x+(16-y)*(16-y)));
   double t=Math.Max(0,Math.Min(1,distance/1.5));return (byte)Math.Floor(255*(1-Transparency*t*t*(3-2*t))+.5);
  }
  // Lazy, immutable 80px tile patterns, shared safely by preparation workers.
  // Bounded at 1.56 MiB even if all possible corner masks are ever encountered.
  internal static byte[] TileAlpha(int mask){lock(gate){if(tiles[mask]!=null)return tiles[mask];var result=new byte[Tile*Tile];for(int y=0;y<Tile;y++)for(int x=0;x<Tile;x++)result[y*Tile+x]=Alpha(mask,(x+.5)/5,(y+.5)/5);return tiles[mask]=result;}}
  public static int Validate(){
   int count=0;void Check(bool valid,string label){count++;if(!valid)throw new Exception("Tunnel sky: "+label);}
   for(int mask=0;mask<256;mask++){
    var a=TileAlpha(mask);Check(ReferenceEquals(a,TileAlpha(mask)),"cached immutable alpha tile");
    for(int i=0;i<a.Length;i++)Check(a[i]>=153,"no more than 40 percent transmission");
    Check(Alpha(mask,8,8)==153,"uniform tunnel core");
    if((mask&1)!=0)Check(Alpha(mask,8,0)==255,"opaque top boundary");
    if((mask&2)!=0)Check(Alpha(mask,16,8)==255,"opaque right boundary");
    if((mask&4)!=0)Check(Alpha(mask,8,16)==255,"opaque bottom boundary");
    if((mask&8)!=0)Check(Alpha(mask,0,8)==255,"opaque left boundary");
   }
   for(int i=1;i<=150;i++)Check(Math.Abs(Alpha(8,i*.01,8)-Alpha(8,(i-1)*.01,8))<=2,"smooth edge opacity");
   Check(WallMask(new[]{"###","#.#","###"},1,1)==255,"all eight wall neighbours");
   Check(WallMask(new[]{"...","...","..."},1,1)==0,"open junction");
   return count;
  }
 }
}

using System;
using System.IO;
using System.IO.Compression;
using System.Collections;
using System.Collections.Generic;
using System.Runtime.InteropServices;
using UnityEngine;
using UnityEngine.Networking;

namespace MazeBiters.NativeStudy {
 public static class WebFiles {
#if UNITY_WEBGL && !UNITY_EDITOR
  public const bool IsWeb=true;
  public static string Root=>"/maze-biters-assets";
  public static bool Ready;
#else
  public const bool IsWeb=false;
  public static string Root=>Path.GetFullPath(Path.Combine(Application.dataPath,"../../SourceAssets"));
  public static bool Ready=true;
#endif
  public static string InitialQuality=>Application.absoluteURL.Contains("quality=4k")?"4k":"hd";
 }
 public sealed class WebBootstrap:MonoBehaviour {
  [Serializable] public sealed class Pack {public string file,stage,sha256;public long bytes,rawBytes;}
  [Serializable] public sealed class Manifest {public Pack[] packs;}
  [DllImport("__Internal")] static extern void MBWebStatus(string message,float progress,int phase);
  [DllImport("__Internal")] static extern void MBWebState(string json);
  [DllImport("__Internal")] static extern void MBWebSync();
  [DllImport("__Internal")] static extern int MBWebPaused();
  string error;bool loading,menuCreated;int completed;Manifest manifest;double lastState;
  public static void Status(string message,float progress=0,int phase=0){
#if UNITY_WEBGL && !UNITY_EDITOR
   MBWebStatus(message,progress,phase);
#endif
  }
  void Start(){DontDestroyOnLoad(gameObject);Application.targetFrameRate=60;StartCoroutine(Guard());}
  IEnumerator Guard(){
   loading=true;error=null;var steps=Load();
   try {while(true){bool more=false;try{more=steps.MoveNext();}catch(Exception e){error=e.Message;Debug.LogException(e);}if(error!=null||!more)break;yield return steps.Current;}}
   finally{(steps as IDisposable)?.Dispose();loading=false;}
   if(error!=null)Status("Зареждането беше прекъснато. Проверете връзката и опитайте отново.",0,-1);
  }
  IEnumerator Load(){
   var baseUrl=Application.streamingAssetsPath+"/WebPayload/";
   if(manifest==null){using(var r=UnityWebRequest.Get(baseUrl+"manifest.json")){r.timeout=90;yield return r.SendWebRequest();if(r.result!=UnityWebRequest.Result.Success)throw new IOException(r.error);manifest=JsonUtility.FromJson<Manifest>(r.downloadHandler.text);}}
   while(completed<manifest.packs.Length){
    if(!menuCreated&&manifest.packs[completed].stage!="menu"){
     foreach(var step in NativeMenuBoot.PrepareWeb())yield return null;
     new GameObject("Original title menu").AddComponent<NativeMenu>();menuCreated=true;yield return null;
    }
    var pack=manifest.packs[completed];int phase=pack.stage=="menu"?0:1;
    Status(phase==0?"Подготвяне на менюто…":"Зареждане на нивата и анимациите…",completed/(float)manifest.packs.Length,phase);
    byte[] data;
    using(var request=UnityWebRequest.Get(baseUrl+pack.file)){
     request.timeout=180;var operation=request.SendWebRequest();
     while(!operation.isDone){Status(phase==0?"Подготвяне на менюто…":"Зареждане на нивата и анимациите…",(completed+request.downloadProgress)/(float)manifest.packs.Length,phase);yield return null;}
     if(request.result!=UnityWebRequest.Result.Success)throw new IOException(pack.file+": "+request.error);
     data=request.downloadHandler.data;
    }
    using(var memory=new MemoryStream(data))using(var zip=new GZipStream(memory,CompressionMode.Decompress))using(var reader=new BinaryReader(zip)){
     var buffer=new byte[131072];
     while(true){int nameLength=reader.ReadInt32();if(nameLength==0)break;if(nameLength<0||nameLength>4096)throw new InvalidDataException("Asset package path");
      string name=System.Text.Encoding.UTF8.GetString(reader.ReadBytes(nameLength));string path=Path.GetFullPath(Path.Combine(WebFiles.Root,name));if(!path.StartsWith(WebFiles.Root+"/",StringComparison.Ordinal))throw new InvalidDataException("Asset package boundary");
      int remaining=reader.ReadInt32();if(remaining<0||remaining>134217728)throw new InvalidDataException("Asset package size");Directory.CreateDirectory(Path.GetDirectoryName(path));
      using(var output=File.Create(path))while(remaining>0){int count=reader.Read(buffer,0,Math.Min(remaining,buffer.Length));if(count<=0)throw new EndOfStreamException(name);output.Write(buffer,0,count);remaining-=count;yield return null;}
     }
    }
    data=null;completed++;
    if(!menuCreated&&pack.stage=="menu"&&(completed==manifest.packs.Length||manifest.packs[completed].stage!="menu")){
     foreach(var step in NativeMenuBoot.PrepareWeb())yield return null;
     new GameObject("Original title menu").AddComponent<NativeMenu>();menuCreated=true;yield return null;Status("Зареждане на нивата и анимациите…",completed/(float)manifest.packs.Length,1);
    }
   }
   NativeTurnBank.QueueCageSources();WebFiles.Ready=true;Status("",1,2);Debug.Log("WEB_ASSETS_READY");
  }
  public void Retry(){if(!loading)StartCoroutine(Guard());}
  public void Pause(){var menu=FindAnyObjectByType<NativeMenu>();if(menu)menu.WebPause();}
  public void Menu(){var menu=FindAnyObjectByType<NativeMenu>();if(menu)menu.WebReturn();}
  void Update(){
   if(Time.realtimeSinceStartupAsDouble-lastState<.5)return;lastState=Time.realtimeSinceStartupAsDouble;
   var menu=FindAnyObjectByType<NativeMenu>();
#if UNITY_WEBGL && !UNITY_EDITOR
   MBWebState(menu?menu.WebState():"{\"stage\":\"loading\"}");
#endif
  }
  public static void Sync(){
#if UNITY_WEBGL && !UNITY_EDITOR
   MBWebSync();
#endif
  }
 }
 public static partial class WebStateUtil {public static string Quote(string value)=>"\""+(value??"").Replace("\\","\\\\").Replace("\"","\\\"").Replace("\n"," ").Replace("\r"," ")+"\"";}
 public sealed partial class NativeMenu {
  public void WebPause(){if(gameplay)gameplay.WebPause();}
  public void WebReturn(){if(gameplay)ReturnToMenu();else if(State.Pending)State.CancelStart();}
  public string WebState()=>"{\"stage\":"+WebStateUtil.Quote(gameplay?"game":"menu")+",\"quality\":"+WebStateUtil.Quote(State.Quality)+",\"pending\":"+(State.Pending?"true":"false")+",\"ready\":"+(PreparedForSelection?"true":"false")+",\"mode\":"+State.SelectedMode+",\"error\":"+WebStateUtil.Quote(preparationError)+(gameplay?",\"game\":"+gameplay.WebState():"")+"}";
 }
 public sealed partial class NativeGameplayStudy {
  public void WebPause(){paused=!paused;}
  public string WebState()=>"{\"level\":"+(world?.Level??0)+",\"players\":"+(world==null?0:world.PlayerCount)+",\"time\":"+time.ToString(System.Globalization.CultureInfo.InvariantCulture)+"}";
 }
}

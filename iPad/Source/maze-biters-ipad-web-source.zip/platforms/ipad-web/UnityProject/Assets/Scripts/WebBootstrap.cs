using System;
using System.IO;
using System.IO.Compression;
using System.Collections;
using System.Collections.Generic;
using System.Runtime.InteropServices;
using UnityEngine;
using UnityEngine.Networking;

namespace MazeBiters.NativeStudy {
 public static class WebFiles {
#if UNITY_WEBGL && !UNITY_EDITOR
  public const bool IsWeb=true;
  public static string Root=>"/maze-biters-assets";
  public static bool Ready;
#else
  public const bool IsWeb=false;
  public static string Root=>Path.GetFullPath(Path.Combine(Application.dataPath,"../../SourceAssets"));
  public static bool Ready=true;
#endif
  public static uint? TestMazeSeed {get{
   if(!Application.absoluteURL.Contains("diagnostic=1"))return null;
   var match=System.Text.RegularExpressions.Regex.Match(Application.absoluteURL,@"[?&]mazeSeed=(\d+)(?:&|$)");
   return match.Success&&uint.TryParse(match.Groups[1].Value,out uint seed)?seed:(uint?)null;
  }}
  public static string InitialQuality=>Application.absoluteURL.Contains("quality=4k")?"4k":"hd";
 }
 public sealed class WebBootstrap:MonoBehaviour {
  [Serializable] public sealed class Pack {public string file,stage,sha256;public long bytes,rawBytes;public int fileCount;}
  [Serializable] public sealed class Manifest {public int version;public Pack[] packs;}
  [DllImport("__Internal")] static extern void MBWebStatus(string message,float progress,int phase);
  [DllImport("__Internal")] static extern void MBWebState(string json);
  [DllImport("__Internal")] static extern void MBWebSync();
  [DllImport("__Internal")] static extern int MBWebPaused();
  string error;bool loading,menuCreated;int completed,retries;Manifest manifest;double lastState;
  string RequestUrl(string root,string file)=>root+file+(retries>0?"?retry="+retries:"");
  public static void Status(string message,float progress=0,int phase=0){
#if UNITY_WEBGL && !UNITY_EDITOR
   MBWebStatus(message,progress,phase);
#endif
  }
  void Start(){DontDestroyOnLoad(gameObject);Application.targetFrameRate=60;StartCoroutine(Guard());}
  IEnumerator Guard(){
   loading=true;error=null;var steps=Load();
   try {while(true){bool more=false;try{more=steps.MoveNext();}catch(Exception e){error=e.Message;Debug.LogException(e);}if(error!=null||!more)break;yield return steps.Current;}}
   finally{(steps as IDisposable)?.Dispose();loading=false;}
   if(error!=null)Status("Зареждането беше прекъснато. Проверете връзката и опитайте отново.",0,-1);
  }
  IEnumerator Load(){
   var baseUrl=Application.streamingAssetsPath+"/WebPayload/";
   string manifestFile=WebFiles.IsWeb?"manifest-"+Application.buildGUID+".json":"manifest.json";
   if(manifest==null){using(var r=UnityWebRequest.Get(RequestUrl(baseUrl,manifestFile))){r.timeout=90;yield return r.SendWebRequest();if(r.result!=UnityWebRequest.Result.Success)throw new IOException(r.error);var candidate=JsonUtility.FromJson<Manifest>(r.downloadHandler.text);WebPayload.Validate(candidate);manifest=candidate;}}
   while(completed<manifest.packs.Length){
    if(!menuCreated&&manifest.packs[completed].stage!="menu"){
     foreach(var step in NativeMenuBoot.PrepareWeb())yield return null;
     new GameObject("Original title menu").AddComponent<NativeMenu>();menuCreated=true;yield return null;
    }
    var pack=manifest.packs[completed];int phase=pack.stage=="menu"?0:1;
    Status(phase==0?"Подготвяне на менюто…":"Зареждане на нивата и анимациите…",completed/(float)manifest.packs.Length,phase);
    byte[] data;
    using(var request=UnityWebRequest.Get(RequestUrl(baseUrl,pack.file))){
     request.timeout=180;var operation=request.SendWebRequest();
     while(!operation.isDone){Status(phase==0?"Подготвяне на менюто…":"Зареждане на нивата и анимациите…",(completed+request.downloadProgress)/(float)manifest.packs.Length,phase);yield return null;}
     if(request.result!=UnityWebRequest.Result.Success)throw new IOException(pack.file+": "+request.error);
     data=request.downloadHandler.data;
    }
    foreach(var step in WebPayload.Verify(pack,data))yield return null;
    foreach(var step in WebPayload.Unpack(pack,data,WebFiles.Root))yield return null;
    data=null;completed++;
    if(!menuCreated&&pack.stage=="menu"&&(completed==manifest.packs.Length||manifest.packs[completed].stage!="menu")){
     foreach(var step in NativeMenuBoot.PrepareWeb())yield return null;
     new GameObject("Original title menu").AddComponent<NativeMenu>();menuCreated=true;yield return null;Status("Зареждане на нивата и анимациите…",completed/(float)manifest.packs.Length,1);
    }
   }
   NativeTurnBank.QueueCageSources();WebFiles.Ready=true;Status("",1,2);Debug.Log("WEB_ASSETS_READY");
  }
  public void Retry(){if(!loading){retries++;StartCoroutine(Guard());}}
  public void Pause(){var menu=FindAnyObjectByType<NativeMenu>();if(menu)menu.WebPause();}
  public void Menu(){var menu=FindAnyObjectByType<NativeMenu>();if(menu)menu.WebReturn();}
  void Update(){
   if(Time.realtimeSinceStartupAsDouble-lastState<.5)return;lastState=Time.realtimeSinceStartupAsDouble;
   var menu=FindAnyObjectByType<NativeMenu>();
#if UNITY_WEBGL && !UNITY_EDITOR
   MBWebState(menu?menu.WebState():"{\"stage\":\"loading\"}");
#endif
  }
  public static void Sync(){
#if UNITY_WEBGL && !UNITY_EDITOR
   MBWebSync();
#endif
  }
 }
 public static partial class WebStateUtil {public static string Quote(string value)=>"\""+(value??"").Replace("\\","\\\\").Replace("\"","\\\"").Replace("\n"," ").Replace("\r"," ")+"\"";}
 public sealed partial class NativeMenu {
  public void WebPause(){if(gameplay)gameplay.WebPause();}
  public void WebReturn(){if(gameplay)ReturnToMenu();else if(records!=null)CloseRecords();else if(State.Pending)State.CancelStart();}
  public string WebState()=>"{\"speedBalance\":"+WebSpeedBalanceState()+",\"stage\":"+WebStateUtil.Quote(gameplay?"game":"menu")+",\"quality\":"+WebStateUtil.Quote(State.Quality)+",\"difficulty\":"+State.Difficulty+",\"intelligence\":\"20261105-adaptive-ally\",\"combo\":\"20261106-combo-cooldown\",\"camera\":\"20261031-exit-camera\",\"celebration\":\"20261031-clear-celebration\",\"notices\":\"20261031-message-panels\",\"menuArt\":\"20261101-glass-records\",\"pending\":"+(State.Pending?"true":"false")+",\"ready\":"+(PreparedForSelection?"true":"false")+",\"mode\":"+State.SelectedMode+",\"error\":"+WebStateUtil.Quote(preparationError)+",\"failure\":"+WebStateUtil.Quote(Application.absoluteURL.Contains("diagnostic=1")?preparationFailure:null)+(gameplay?",\"game\":"+gameplay.WebState():"")+"}";
 }
 public sealed partial class NativeGameplayStudy {
  public void WebPause(){paused=!paused;}
  string WebAiThought(){if(world!=null)for(int i=0;i<world.PlayerCount;i++){var p=world.GetPlayer(i);if(p.IsAI)return p.Ai?.thought??"";}return "";}
  string WebAdaptiveState(){
   if(world!=null)for(int i=0;i<world.PlayerCount;i++){var p=world.GetPlayer(i);if(!p.IsAI)continue;var a=world.AdaptiveAllySample(p.Id);var culture=System.Globalization.CultureInfo.InvariantCulture;
    return "{\"enabled\":"+(a.Enabled?"true":"false")+",\"base\":"+a.BaseIndex+",\"intensity\":"+a.EffectiveIntensity.ToString("F3",culture)+",\"target\":"+a.TargetIntensity.ToString("F3",culture)+",\"lives\":"+p.Lives+",\"aiScore\":"+p.Score+",\"humanScore\":"+a.HumanScore+",\"reason\":"+WebStateUtil.Quote(a.Reason)+"}";
   }return "null";
  }
  string WebPaletteState(){if(world==null)return "{}";return JsonUtility.ToJson(new WebPaletteSnapshot{revision="20261107-random-opening-colours",campaignSeed=world.SnakePaletteSeed,maze=currentGeneratedLevel?.theme??"",snakeColours=System.Linq.Enumerable.ToArray(System.Linq.Enumerable.Select(world.Snakes,s=>NativeSnakePalettes.Names[s.Palette])),allSnakeColours=NativeSnakePalettes.Names,mazePalettes=NativeMazeGenerator.Themes,comboActive=world.ComboActive,comboExponent=world.Player.Combo.MultiplierExponent,comboLabel=hud!=null&&hud.ComboShown(world.Player.Id-1)});}
  [Serializable] sealed class WebPaletteSnapshot{public string maze,revision;public uint campaignSeed;public string[] snakeColours,allSnakeColours,mazePalettes;public bool comboActive,comboLabel;public int comboExponent;}
  string WebGlintState(){
   if(world==null||neon==null||!Application.absoluteURL.Contains("diagnostic=1"))return "null";
   var snakes=new WebGlintSnake[world.Snakes.Count];
   for(int i=0;i<snakes.Length;i++){var s=world.Snakes[i];double started=neon.SnakeGlintStart(s.Id);snakes[i]=new WebGlintSnake{id=s.Id,aggression=s.Aggression,start=double.IsInfinity(started)?-1:started,recognitions=neon.SnakeRecognitionEvents(s.Id)};}
   return JsonUtility.ToJson(new WebGlintSnapshot{revision="20261107-snake-eye-signals",clock=CreaturePresentationTime/Math.Max(.01,MenuSpeed),iris=NativeEyeGlints.SnakeIrisStrength,fringe=NativeEyeGlints.SnakeFringeStrength,snakes=snakes});
  }
  [Serializable] sealed class WebGlintSnake{public int id,recognitions;public double aggression,start;}
  [Serializable] sealed class WebGlintSnapshot{public string revision;public double clock;public float iris,fringe;public WebGlintSnake[] snakes;}
  public string WebState()=>"{\"holistic\":"+WebHolisticState()+",\"integration\":"+WebIntegrationState()+",\"preparation\":"+WebPreparationState()+",\"speedBalance\":"+WebSpeedBalanceState()+",\"populationOptimization\":"+(IpadPopulationOptimization.Enabled?"true":"false")+",\"population\":"+PopulationState()+",\"orbit\":"+WebOrbitState()+",\"atmosphere\":"+WebAtmosphereState()+",\"fruits\":"+WebFruitState()+",\"glints\":"+WebGlintState()+",\"palettes\":"+WebPaletteState()+",\"level\":"+(world?.Level??0)+",\"players\":"+(world==null?0:world.PlayerCount)+",\"time\":"+time.ToString(System.Globalization.CultureInfo.InvariantCulture)+",\"paused\":"+(paused?"true":"false")+",\"pageHidden\":"+(WebLifecycle.Suspended?"true":"false")+",\"legacyBrain\":"+(world!=null&&world.UseLegacyAi?"true":"false")+",\"aiThought\":"+WebStateUtil.Quote(WebAiThought())+",\"adaptiveAI\":"+WebAdaptiveState()+"}";
 }
}

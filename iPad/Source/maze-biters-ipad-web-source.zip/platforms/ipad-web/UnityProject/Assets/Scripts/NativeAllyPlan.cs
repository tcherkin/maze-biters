using System;using System.Collections.Generic;using System.Linq;using UnityEngine;
namespace MazeBiters.NativeStudy {
 public sealed partial class NativeAllyBrain {
  public void Plan(NativePlayer p,double t){
   if(p==null||!p.IsAI||p.Dead)return;var a=S(p);Clean(p,t);CheckCasualMeal(p);p.Pointer=null;p.PointerMomentum=false;p.Ricochet=null;p.Waiting=false;
   var options=Legal(p,t);if(options.Count==0){if(!w.UseLegacyAi)p.Waiting=true;return;}bool oscillating=Remember(p,t);bool meal=MealIntent(p,t);var directive=Directive(p,t);AllyObjective escape=null;
   if(directive?.type=="flee"){ClearRetreat(p);escape=EscapeSnake(p,t,directive);if(escape==null&&FollowEscape(p,t,options,directive))return;}
   if((directive==null||directive.type=="recover-score")&&CasualBite(p,t,options))return;
   // Keep all immediate collision checks, but do not turn a casual stroll into
   // a food hunt just because a globally optimal objective can be found.
   if(!meal&&(directive==null||directive.type=="recover-score")&&options.Any(d=>Collision(p,d,p.Cell+d,t)<100000&&Danger(p,d,p.Cell+d,t)<105)){
    ClearRetreat(p);if(Roam(p,t,options))return;
   }
   if(directive==null&&FollowRetreat(p,t,options))return;
   var strategic=directive?.type=="flee"?escape:directive?.type=="hunt"?new AllyObjective{type="hunt-opponent",target=directive.target.Cell,score=-1000,player=directive.target,kind="player"}:Objective(p,t,!w.UseLegacyAi||w.Competitive?Skill:null);
   bool priority=strategic?.type=="tactical-fruit"&&strategic.priorityFruit;
   var immediate=priority||directive?.type=="hunt"||directive?.type=="flee"?null:Immediate(p,t,options);
   if((!w.UseLegacyAi||w.Competitive)&&!Power(p,t)&&immediate?.kind=="split"&&a.allowSplit!=true)immediate=null;
   var objective=directive?.type=="flee"||directive?.type=="hunt"||priority?strategic:immediate??strategic;
   if((directive==null||directive.type=="recover-score")&&objective==null&&Roam(p,t,options))return;
   if(objective?.type=="tactical-fruit"){bool changed=a.fruit!=objective.fruit;a.fruit=objective.fruit;if(objective.priorityFruit&&!a.bitten){a.locked=null;a.split=null;a.commitMode=null;a.targetKind=null;a.queue.Clear();if(changed)ClearRetreat(p);}}
   else if(a.fruit!=null&&!w.Fruits.Contains(a.fruit))a.fruit=null;
   var snake=objective?.snake;if(objective?.kind=="split"&&snake!=null&&snake.Body.Count>=3){if(a.split==null||a.split.snake!=snake||objective.immediate)a.split=new AllySplit{snake=snake,fraction=(double)objective.bodyIndex/Math.Max(1,snake.Body.Count-1),started=t};}
   if(snake!=null&&snake!=a.locked)Commit(p,snake,objective.type.Contains("split")?"split-target":"hunt",t);if(objective?.kind!=null)a.targetKind=objective.kind;
   var field=objective==null?null:ObjectiveField(objective);a.visited[p.Cell]=t;foreach(var c in a.visited.Keys.ToArray())if(t-a.visited[c]>5500)a.visited.Remove(c);
   Step ideal=null;bool detourNeeded=false,detourFound=false;
   if(field!=null&&objective!=null){ideal=dirs.Select(d=>new Step{d=d,c=p.Cell+d,distance=p.Cell.x+d.x<0||p.Cell.y+d.y<0||p.Cell.x+d.x>=w.Width||p.Cell.y+d.y>=w.Height?-1:field[w.Index(p.Cell+d)]}).Where(s=>s.distance>=0).OrderBy(s=>s.distance).FirstOrDefault();
    bool legal=ideal!=null&&options.Contains(ideal.d);double collision=ideal==null?0:Collision(p,ideal.d,ideal.c,t,objective),danger=ideal==null?0:Danger(p,ideal.d,ideal.c,t);
    detourNeeded=ideal!=null&&(!legal||collision>=100000||danger>=105);if(detourNeeded){a.detourUntil=t+1100;a.blockedStep=(ideal.c,t);}
    if(detourNeeded||a.detourUntil>t){var detour=DetourField(objective.target,p,t);if(detour[w.Index(p.Cell)]>=0){field=detour;detourFound=true;}}
   }
   bool missing=field!=null&&field[w.Index(p.Cell)]<0;var retreat=objective;
   if(retreat==null&&a.locked!=null&&w.Snakes.Contains(a.locked))retreat=new AllyObjective{type="blocked-hunt",target=a.locked.Tail,snake=a.locked,kind=a.locked.Body.Count>1?"tail":"head"};
   bool noBypass=detourNeeded&&!detourFound,loop=oscillating&&retreat!=null&&!retreat.immediate;
   if(retreat!=null&&(missing||noBypass||loop)){
    bool change=!Power(p,t)&&snake!=null&&!a.bitten&&!a.replan&&Alternative(p,t,snake);
    if(change){a.cooldowns[snake]=t+5500;if(a.locked==snake){a.locked=null;a.bitten=false;a.commitMode=null;}if(a.split?.snake==snake)a.split=null;a.targetKind=null;ClearRetreat(p);a.replan=true;try{Plan(p,t+.01);}finally{a.replan=false;}return;}
    Vector2Int? block=a.blockedStep.HasValue&&t-a.blockedStep.Value.time<5000?(Vector2Int?)a.blockedStep.Value.cell:ideal==null?(Vector2Int?)retreat.target:ideal.c;
    string reason=loop?"two-cell-loop":missing?"unreachable-route":"temporary-congestion";
    if(BeginRetreat(p,retreat,block,t,reason)&&FollowRetreat(p,t,options))return;
   }
   var measured=options.Select(d=>{var c=p.Cell+d;double collision=Collision(p,d,c,t,objective),danger=Danger(p,d,c,t),distance=field==null?0:field[w.Index(c)];a.visited.TryGetValue(c,out double recent);
    bool reversePenalty=objective==null&&a.locked!=null&&a.locked.Reversing&&Man(a.locked.Head,c)<Man(a.locked.Head,p.Cell);
    return new Step{d=d,c=c,collision=collision,danger=danger,distance=distance,unreachable=field!=null&&distance<0,lethal=collision>=100000,reversePenalty=reversePenalty?250000:0,cul=CulDeSac(p,c,objective),revisit=recent!=0?Math.Max(0,1-(t-recent)/5500):0,straight=d==p.Dir?-.2:0};
   }).ToList();
   bool safe=measured.Any(s=>!s.lethal&&s.danger<105),open=measured.Any(s=>!s.lethal&&s.danger<105&&!s.cul);var run=a.run??p.Dir;var forward=measured.FirstOrDefault(s=>s.d==run);
   bool continues=forward!=null&&!forward.lethal&&forward.danger<105&&!forward.unreachable&&!(open&&forward.cul);
   bool purposeful=objective?.immediate==true||objective?.type=="tactical-fruit"||objective?.type=="hunt-opponent";
   foreach(var s in measured)s.score=(s.lethal?1000000000.0:0)+(safe&&s.danger>=105?900000000:0)+(s.unreachable?500000000:0)+(open&&s.cul?300000000:0)+(continues&&!purposeful&&s.d==-run?(a.runLength<5?650000000:24000):0)+(s.distance<0?0:s.distance*10000)+s.danger*25+s.collision+s.reversePenalty+s.revisit+s.straight;
   var chosen=ImperfectStep(measured,measured.OrderBy(s=>s.score).First(),objective,open);Choose(p,chosen.d,t);Thought(p,objective?.type??"explore",objective?.target??chosen.c,Danger(p,chosen.d,chosen.c,t),chosen.score);
  }
  public void Commit(NativePlayer p,NativeGameplaySnake s,string mode="finish",double? time=null){if(p==null||!p.IsAI||s==null||!w.Snakes.Contains(s)||s.Body.Count==0)return;var a=S(p);if(!w.UseLegacyAi&&!a.mealActive)return;if(a.split!=null&&a.split.snake!=s)a.split=null;a.locked=s;a.commitMode=mode;a.bitten=mode=="finish"||mode=="finish-split";a.commitUntil=(time??w.Time)+(mode=="finish-split"?24000:18000);}
  public void TailBite(NativePlayer p,NativeGameplaySnake s){RecordCasualBite(p,s);if(p.IsAI&&!w.UseLegacyAi&&Balance.Intensity<=1){EndMeal(p,w.Time);return;}if(p.IsAI&&S(p).locked!=null&&S(p).locked!=s)return;if(p.IsAI)ClearRetreat(p);if(S(p).split?.snake==s)S(p).split=null;Commit(p,s);}
  void LockNext(NativePlayer p,double? t=null){if(!p.IsAI||S(p).locked!=null)return;var a=S(p);if(!w.UseLegacyAi&&(!a.mealActive||(t??w.Time)>=a.mealIntentUntil))return;a.queue.RemoveAll(s=>!w.Snakes.Contains(s));if(a.queue.Count>0){var s=a.queue[0];a.queue.RemoveAt(0);Commit(p,s,"finish-split",t);return;}var next=w.Snakes.OrderBy(s=>Distance(p.Cell,s.Tail)).FirstOrDefault();if(next!=null)Commit(p,next,"hunt",t);}
  public void Completed(NativePlayer p,NativeGameplaySnake s,NativeGameplaySnake replacement=null){if(!p.IsAI)return;ClearCasualMeal(p);if(!w.UseLegacyAi&&!Balance.Maximum){EndMeal(p,w.Time);return;}var a=S(p);if(a.locked!=null&&a.locked!=s)return;ClearRetreat(p);if(a.split?.snake==s)a.split=null;if(replacement!=null&&w.Snakes.Contains(replacement)){Commit(p,replacement);return;}if(a.locked==s){a.locked=null;a.bitten=false;a.commitMode=null;}a.queue.RemoveAll(x=>!w.Snakes.Contains(x));if(a.locked==null&&a.queue.Count>0){var next=a.queue[0];a.queue.RemoveAt(0);Commit(p,next,"finish-split");}LockNext(p);}
  public void Split(NativePlayer p,NativeGameplaySnake original,List<NativeGameplaySnake> created){if(!p.IsAI)return;ClearCasualMeal(p);if(!w.UseLegacyAi&&(Balance.Intensity<=1||!S(p).mealActive)){EndMeal(p,w.Time);return;}var a=S(p);if(a.locked!=null&&a.locked!=original)return;ClearRetreat(p);if(a.split?.snake==original)a.split=null;
   var viable=created.Where(s=>w.Snakes.Contains(s)&&s.Body.Count>0).OrderBy(s=>Distance(p.Cell,s.Tail)).ToList();var old=a.queue.Where(s=>w.Snakes.Contains(s)&&!viable.Contains(s)).ToList();a.locked=viable.FirstOrDefault();a.queue=viable.Skip(1).Concat(old).ToList();a.commitMode="finish-split";a.targetKind="tail";a.bitten=true;a.commitUntil=w.Time+24000;if(a.locked==null)LockNext(p);
  }
  public void BeginLevel(){bool any=false;for(int i=0;i<w.PlayerCount;i++)if(w.GetPlayer(i).IsAI)any=true;if(!any){atlas=null;atlasGrid=null;return;}ScanMaze(true);
   for(int i=0;i<w.PlayerCount;i++){var p=w.GetPlayer(i);if(!p.IsAI)continue;ClearCasualMeal(p);var a=S(p);a.locked=null;a.queue.Clear();a.split=null;a.commitMode=a.targetKind=null;a.bitten=false;a.detourUntil=0;a.visited.Clear();ClearRetreat(p);a.cooldowns.Clear();a.replan=false;a.fruit=null;a.observed=a.run=null;a.runLength=0;if(!w.UseLegacyAi)ResetDifficulty(p);LockNext(p,w.Time);}
  }
 }
}


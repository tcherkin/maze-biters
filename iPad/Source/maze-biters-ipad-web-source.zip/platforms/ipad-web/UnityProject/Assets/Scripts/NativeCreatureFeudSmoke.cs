using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using UnityEngine;
namespace MazeBiters.NativeStudy {
 public sealed partial class NativeGameplayStudy {
  // Explicit command-line fixture only. Fixed animation clocks do not require
  // foreground focus and are not used to claim frame rate or device performance.
  bool creatureFeudSmoke;
  [Serializable] sealed class CreatureFeudSmokeCase {
   public string kind;public int palette,worldSnakes,renderedSnakes,worldHunters,renderedHunters,audioAccepted;
   public bool passed,playerUnchanged,finite;public string[] sounds,images;
  }
  [Serializable] sealed class CreatureFeudSmokeReport {
   public string quality,graphics,error,note;public int width,height;public bool passed;
   public string[] checks;public CreatureFeudSmokeCase[] cases;
  }
  void FeudSmokeClock(double value){time=world.Time=realClock=world.RealTime=value;}
  void FeudSmokeClear(){
   draw.Clear();blooms.Reset();foreach(var visual in snakes.Values)visual.Dispose();snakes.Clear();world.Snakes.Clear();
   foreach(var ghost in ghosts)ghost.Dispose();ghosts.Clear();
   foreach(var hunter in world.Hunters)if(actors.TryGetValue(hunter.Id,out var actor)){actor.Dispose();actors.Remove(hunter.Id);}world.Hunters.Clear();
   world.Fruits.Clear();world.Eggs.Clear();world.PendingDrops.Clear();world.SolidEggs.Clear();world.Scorpion=null;
   scorpionArt?.Dispose();scorpionArt=null;pickups?.Dispose();pickups=null;
   world.SessionEnabled=true;world.LifecycleEnabled=false;world.Assist=false;world.UseLegacyAi=false;world.ScorpionSpawnAt=double.PositiveInfinity;
   world.Player.Waiting=true;world.Player.LastMove=time+100000;world.Player.ShieldUntil=world.Player.PowerUntil=0;
   intake.Begin();sessionAudio.ResetBus();
  }
  void FeudSmokeFrame(Vector2Int centre,IEnumerable<Vector2Int> occupied){
   var blocked=new HashSet<Vector2Int>(occupied);Vector2Int? player=null;int best=int.MaxValue;
   for(int y=1;y<world.Height-1;y++)for(int x=1;x<world.Width-1;x++){
    var cell=new Vector2Int(x,y);int distance=Math.Abs(x-centre.x)+Math.Abs(y-centre.y);
    if(distance>=2&&distance<best&&world.Floor(cell)&&!blocked.Contains(cell)){best=distance;player=cell;}
   }
   if(!player.HasValue)throw new InvalidOperationException("No legal observer cell for feud smoke");
   var p=world.Player;p.Cell=p.From=p.Previous=player.Value;p.Dir=p.Next=centre.x>=p.Cell.x?Vector2Int.right:Vector2Int.left;p.MoveStarted=time-1000;
   gameplayCamera.X=(centre.x+.5)*16;gameplayCamera.Y=(centre.y+.5)*16;gameplayCamera.Zoom=2;fixedCamera=true;
  }
  bool FeudSmokeFinite(){
   foreach(var visual in snakes.Values){var pose=visual.motion.Evaluate(time);var tip=pose.rail.Sample(pose.Tip);if(double.IsNaN(pose.length)||double.IsInfinity(pose.length)||pose.length<=0||double.IsNaN(tip.x)||double.IsNaN(tip.y)||double.IsInfinity(tip.x)||double.IsInfinity(tip.y))return false;}
   return true;
  }
  string FeudSmokePlayer()=>world.Player.Score+"|"+world.Player.ExactScore+"|"+world.Player.Contribution+"|"+world.Player.Lives+"|"+world.Player.Dead+"|"+world.Player.BiteAt+"|"+world.Player.BiteEnd+"|"+world.Player.PowerUntil;
  IEnumerator ProbeCreatureFeuds(){
   var result=new CreatureFeudSmokeReport{quality=quality,graphics=SystemInfo.graphicsDeviceName,
    note="Opt-in staged native iPad renderer smoke. Actual world Tick/contact events, approved glass/light chain, three enemy palettes, original cut and HeadEat audio routed through the muted live audio bus. Fixed clocks and PNG readbacks; no FPS, latency, acoustic or physical-iPad claim. No main-game defaults changed."};
   var checks=new List<string>();var cases=new List<CreatureFeudSmokeCase>();string folder=Path.ChangeExtension(Path.GetFullPath(report),null);Directory.CreateDirectory(folder);
   void Check(bool passed,string label){if(!passed)throw new InvalidOperationException(label);checks.Add(label);}
   string Shot(string name){string path=Path.Combine(folder,name+".png");Render();Capture(path);Check(new FileInfo(path).Length>1000,"saved "+name);return path;}
   IEnumerator Run(){
    NativeDisplay.TestAspect=IpadPresentation.Enabled?IpadPresentation.Aspect:16f/9;fixedCamera=true;
    if(sessionAudio==null){sessionAudio=new GameObject("Creature feud smoke audio").AddComponent<NativeSessionAudio>();sessionAudio.Initialize(true);}sessionAudio.Muted=true;
    for(int palette=0;palette<3;palette++){
     Reset(9);yield return DrainProbePreparation();FeudSmokeClock(2000+palette*3000);FeudSmokeClear();
     Check(NativeGlassPresentation.Enabled&&dusk.GlassLightingEnabled&&glassEmission,"approved glass and lighting active palette "+palette);
     var approach=palette==1?Vector2Int.down:Vector2Int.right;var body=ContactSnakePath(approach,3,true);var impact=body[3];
     var snake=world.AddSnake(body,body[0]-body[1],palette);snake.LastMove=time+100000;AddSnake(snake);
     var hunter=new NativeHunter{Id=8100+palette,Cell=impact-approach,From=impact-approach,Dir=approach,HeldDirection=approach,Palette=palette,LastMove=time};world.Hunters.Add(hunter);AddActor(hunter,false,palette);
     FeudSmokeFrame(impact,body.Concat(new[]{hunter.Cell}));var received=new List<NativeWorldEvent>();world.Event=e=>{received.Add(e);OnEvent(e);};
     for(int warm=0;warm<3;warm++){Render();yield return null;}
     var cut=new CreatureFeudSmokeCase{kind="hunter-split",palette=palette};cases.Add(cut);var images=new List<string>{Shot("palette-"+palette+"-before-cut")};string playerBefore=FeudSmokePlayer();int accepted=sessionAudio.Accepted;
     FeudSmokeClock(time+96);world.Tick(time);double cutAt=time;
     Check(received.Count(e=>e.Kind=="hunterSplit")==1&&world.Snakes.Count==2&&snakes.Count==2,"one actual cut creates two rendered fragments palette "+palette);
     Check(!snakes.ContainsKey(snake.Id)&&world.Snakes.Sum(s=>s.Body.Count)==6&&world.Snakes.All(s=>!s.Body.Contains(impact)),"impact gap and replaced original palette "+palette);
     Check(snakes.Values.All(s=>s.motion.IntakePlayer==null)&&ghosts.Count==0,"cut never attaches to a player mouth palette "+palette);
     for(int frame=1;frame<=24;frame++){FeudSmokeClock(cutAt+frame*1000.0/120);Render();Check(FeudSmokeFinite(),"finite split pose "+palette+"/"+frame);if(frame==8)images.Add(Shot("palette-"+palette+"-split"));yield return null;}
     images.Add(Shot("palette-"+palette+"-after-cut"));
     cut.sounds=received.Where(e=>e.Kind=="sound").Select(e=>e.Sound).ToArray();cut.audioAccepted=sessionAudio.Accepted-accepted;
     cut.playerUnchanged=FeudSmokePlayer()==playerBefore;cut.finite=FeudSmokeFinite();cut.worldSnakes=world.Snakes.Count;cut.renderedSnakes=snakes.Count;cut.worldHunters=world.Hunters.Count;cut.renderedHunters=actors.Count-1;cut.images=images.ToArray();
     cut.passed=cut.playerUnchanged&&cut.finite&&cut.worldHunters==1&&cut.renderedHunters==1&&cut.sounds.Length==1&&new[]{"Tie1","Tie2","Tie3","Tie5","TieEat"}.Contains(cut.sounds[0])&&cut.audioAccepted==1;
     Check(cut.passed,"cut audio accepted once and player untouched palette "+palette);

     FeudSmokeClock(time+400);FeudSmokeClear();received.Clear();
     // A genuine straight corridor from the loaded maze, with the hunter one
     // cell in front of the mouth. Held direction stages intent, not contact.
     var line=ContactSnakePath(Vector2Int.right,0,false);body=line.Take(3).ToArray();var travel=-Vector2Int.right;
     snake=world.AddSnake(body,travel,palette);snake.LastMove=time-219;snake.HeldDirection=travel;AddSnake(snake);
     hunter=new NativeHunter{Id=8200+palette,Cell=snake.Head+travel,From=snake.Head+travel,Dir=travel,Palette=palette,LastMove=time+100000};world.Hunters.Add(hunter);AddActor(hunter,false,palette);
     FeudSmokeFrame(hunter.Cell,body.Concat(new[]{hunter.Cell}));world.Event=e=>{received.Add(e);OnEvent(e);};
     for(int warm=0;warm<3;warm++){Render();yield return null;}
     var death=new CreatureFeudSmokeCase{kind="snake-eats-hunter",palette=palette};cases.Add(death);images=new List<string>{Shot("palette-"+palette+"-before-predation")};playerBefore=FeudSmokePlayer();accepted=sessionAudio.Accepted;
     world.Tick(time);double eatenAt=time;
     Check(received.Count(e=>e.Kind=="snakeHunterBite")==1&&!world.Hunters.Contains(hunter)&&!actors.ContainsKey(hunter.Id),"actual snake head contact removes enemy model and renderer palette "+palette);
     Check(world.Snakes.Count==1&&snakes.Count==1&&snake.Body.Count==3&&snakes[snake.Id].feudBiteEnd>time,"eating snake retains its body and animates mouth palette "+palette);
     for(int frame=1;frame<=36;frame++){FeudSmokeClock(eatenAt+frame*1000.0/120);Render();Check(FeudSmokeFinite(),"finite head-bite pose "+palette+"/"+frame);if(frame==8)images.Add(Shot("palette-"+palette+"-predation"));yield return null;}
     images.Add(Shot("palette-"+palette+"-after-predation"));
     death.sounds=received.Where(e=>e.Kind=="sound").Select(e=>e.Sound).ToArray();death.audioAccepted=sessionAudio.Accepted-accepted;
     death.playerUnchanged=FeudSmokePlayer()==playerBefore;death.finite=FeudSmokeFinite();death.worldSnakes=world.Snakes.Count;death.renderedSnakes=snakes.Count;death.worldHunters=world.Hunters.Count;death.renderedHunters=actors.Count-1;death.images=images.ToArray();
     death.passed=death.playerUnchanged&&death.finite&&death.worldHunters==0&&death.renderedHunters==0&&death.sounds.SequenceEqual(new[]{"HeadEat"})&&death.audioAccepted==1&&ghosts.Count==0;
     Check(death.passed,"HeadEat accepted once with no player rewards or mouth animation palette "+palette);
    }
    result.width=target.width;result.height=target.height;Check(cases.Count==6&&cases.All(c=>c.passed),"all six native rendering cases pass");
   }
   var stack=new Stack<IEnumerator>();stack.Push(Run());
   while(stack.Count>0){object value=null;bool more=false;try{more=stack.Peek().MoveNext();if(more)value=stack.Peek().Current;}catch(Exception e){result.error=e.ToString();Debug.LogError(e);break;}if(!more){stack.Pop();continue;}if(value is IEnumerator nested){stack.Push(nested);continue;}yield return value;}
   result.passed=string.IsNullOrEmpty(result.error)&&cases.Count==6&&cases.All(c=>c.passed);result.checks=checks.ToArray();result.cases=cases.ToArray();File.WriteAllText(report,JsonUtility.ToJson(result,true));Application.Quit(result.passed?0:2);
  }
 }
}

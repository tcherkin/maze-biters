using System;
using System.Linq;
using UnityEngine;
namespace MazeBiters.NativeStudy {
 public sealed class NativeScorpion:NativeCreature {public Vector2Int Tail;public double Born,NextFruit=double.PositiveInfinity,NextEgg=double.PositiveInfinity;public NativeScorpionMotion Motion;}
 public sealed partial class NativeGameplayWorld {
  public NativeScorpion Scorpion;
  public bool ScorpionAt(Vector2Int cell)=>Scorpion!=null&&(Scorpion.Cell==cell||Scorpion.Tail==cell);
  public NativeScorpion PlaceScorpion(Vector2Int head,Vector2Int direction){var s=Scorpion=new NativeScorpion{Id=500,Cell=head,Tail=head-direction,Dir=direction,LastMove=Time,Born=Time};s.Motion=new NativeScorpionMotion(s.Cell,s.Tail,s.Dir,s.Cell,s.Tail,s.Dir,Time,Time);return s;}
  public void MoveScorpion(){var s=Scorpion;if(s==null||Time-s.LastMove<218)return;var head=s.Cell;var tail=s.Tail;var old=s.Dir;
   bool Open(Vector2Int p)=>Floor(p)&&!Occupied(p)&&!HunterAt(p)&&PlayerAt(p)==null&&!SolidEgg(p);
   var options=Dirs.Where(d=>d!=-s.Dir&&Open(head+d)).ToList();if(options.Count==0)options=Dirs.Where(d=>Open(head+d)).ToList();
   if(options.Count>0){s.Dir=Brain.Choose(s,head,options,new BrainProfile{kind="scorpion",flee=true,baseline=.46+.40*(1-Math.Exp(-Math.Max(0,Level-1)/7.0)),listenBoost=.15});s.Cell=head+s.Dir;s.Tail=head;}
   s.LastMove=Time;s.Motion=new NativeScorpionMotion(head,tail,old,s.Cell,s.Tail,s.Dir,Time,s.Motion.origin);QueueScorpionDrops(tail,options.Count==0||s.Dir!=old);Event?.Invoke(new NativeWorldEvent{Kind="scorpionMove",Scorpion=s,Time=Time,OldDirection=old});
  }
  public void EatScorpion(){var s=Scorpion;if(s==null||Player.Dead||!CreatureBitesAllowed(Player,Time))return;SustainComboWithPickup();var actor=Player;bool tail=Player.Cell==s.Tail;SessionEffect("scorpionBite",Player.Cell);Event?.Invoke(new NativeWorldEvent{Player=Player,Kind="scorpionBite",Scorpion=s,Time=Time,Index=tail?1:0,OldBody=new[]{s.Cell,s.Tail}});Scorpion=null;ScorpionKilled=true;if(LifecycleEnabled)ScorpionSpawnAt=Time+ScorpionRespawnDelay();Award(150);if(Multiplayer)Player.Contribution+=3;
   if(UseLegacyAi){foreach(var h in Hunters){h.MotherAlive=false;h.Anger=Math.Max(h.Anger,.95);h.Threat+=3;Provoke(h,3,false);}}
   else NotifyHuntersScorpionEaten(actor);
  }
 }
}

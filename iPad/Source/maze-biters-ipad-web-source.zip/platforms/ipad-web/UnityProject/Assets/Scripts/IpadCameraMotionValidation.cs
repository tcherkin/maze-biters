using System;
using UnityEngine;
namespace MazeBiters.NativeStudy {
 public static class IpadCameraMotionValidation {
  public static int Run(){int checks=0;void Check(bool ok,string name){checks++;if(!ok)throw new Exception("iPad camera motion: "+name);}
   var f=new NativeFrame(4f/3,true);var safe=new Rect(0,0,f.Width,f.Height);double close=160.0*432/(16*2064);
   var m=new IpadCameraMotion();var p=new Rect(24,24,0,0);var a=m.Sample(f,288,200,1,close,safe,p,1000);Check(Math.Abs(a.y-184)<1e-6&&a.zoom==1,"overview starts exactly at original header");
   for(int i=1;i<90;i++)a=m.Sample(f,144,100,2,close,safe,p,1000+i*1000.0/120);
   var b=m.Sample(f,144,100,2,close,safe,p,1000+89*1000.0/120);Check(a.x==b.x&&a.y==b.y&&a.zoom==b.zoom,"same-clock renders do not advance motion");
   for(int i=90;i<2000;i++)a=m.Sample(f,144,100,2,close,safe,p,1000+i*1000.0/120);
   var board=f.ProjectBoard(a.x,a.y,a.zoom);Check(Math.Abs(board.x-52)<.001&&Math.Abs(board.y-52)<.001,"settled corner retains equal 52-unit sky");Check(Math.Abs(a.zoom-close)<1e-9,"stationary 160-pixel zoom retained");
   m.Reset();a=m.Sample(f,288,200,1,close,safe,p,1000);Check(a.zoom==1&&Math.Abs(a.y-184)<1e-9,"new session has no old camera momentum");
   foreach(int fps in new[]{30,60,120}){
    m.Reset();m.Sample(f,288,200,1,close,safe,null,0);
    // Ordinary SOLO follow now owns the original 1040 ms zoom response as well
    // as translation. Wait through its subpixel tail before asserting rest.
    for(int i=1;i<=fps*16;i++)a=m.Sample(f,144,100,2,close,safe,null,i*1000.0/fps);
    Check(Math.Abs(f.ProjectBoard(a.x,a.y,a.zoom).y-52)<.001,"frame-rate independent decorative settling "+fps);
   }
   // Changing rosters and an abrupt respawn may use the final safety guard,
   // but silhouettes must remain visible at every sample, including pauses.
   m.Reset();
   for(int i=0;i<1800;i++){
    double t=i/120.0,z=1+IpadFraming.Smooth((Math.Sin(t*.9)+1)/2),u=(Math.Sin(t*1.7)+1)/2;
    var bounds=Rect.MinMaxRect(24,(float)(24+160*u),552,(float)(210+166*u));
    a=m.Sample(f,288,200,z,close,safe,bounds,i*1000.0/120);board=f.ProjectBoard(a.x,a.y,a.zoom);
    Check(board.x+(bounds.xMin-12)*a.zoom>=-.002&&board.x+(bounds.xMax+12)*a.zoom<=f.Width+.002&&board.y+(bounds.yMin-12)*a.zoom>=a.header-.002&&board.y+(bounds.yMax+12)*a.zoom<=f.Height+.002,"roster safety "+i);
   }
   return checks;
  }
 }
}

using System;using System.IO;using UnityEngine;
namespace MazeBiters.NativeStudy {
 [Serializable]class NeonScene{public string quality;public int width,height,direction,mouth,blink;public double time,lightAngle;public Vector2 player;public SnakeImageCase[] snakes;}
 public static class NeonSceneCapture{
  public static void Save(string quality,string folder,int index,double clock,RenderTexture target,NativeSnakeStudy study,Vector2 position,int direction,int mouth,int blink,double lightAngle){
   Directory.CreateDirectory(folder);var scene=new NeonScene{quality=quality,width=target.width,height=target.height,time=clock,lightAngle=lightAngle,player=position,direction=direction,mouth=mouth,blink=blink,snakes=new SnakeImageCase[5]};
   for(int i=0;i<5;i++){var p=study.Poses[i];scene.snakes[i]=new SnakeImageCase{palette=study.Snakes[i].Palette,cells=study.Routes[i],head=p.head,length=p.length,compression=p.compression,phase=p.phase,frontMaterial=p.frontMaterial,solo=p.solo};}
   var previous=RenderTexture.active;RenderTexture.active=target;var t=new Texture2D(target.width,target.height,TextureFormat.RGBA32,false);t.ReadPixels(new Rect(0,0,target.width,target.height),0,0);t.Apply();RenderTexture.active=previous;
   string prefix=Path.Combine(folder,"neon-scene-"+quality+"-"+index);File.WriteAllBytes(prefix+".png",t.EncodeToPNG());File.WriteAllText(prefix+".json",JsonUtility.ToJson(scene,true));UnityEngine.Object.Destroy(t);
  }
 }
}

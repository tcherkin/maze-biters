using System;
using UnityEngine;
namespace MazeBiters.NativeStudy {
 // Emissive partners of the normal sprite's upper shell and lower mouth.
 // The caller supplies the actual art palette, independently of player ID/role.
 public static class NativePowerAura {
  public static Color Top(int palette){switch(palette){
   case 0:return new Color(1,.065f,.025f,1);
   case 1:return new Color(.055f,.35f,1,1);
   case 2:return new Color(1,.80f,.09f,1);
   default:throw new ArgumentOutOfRangeException(nameof(palette));
  }}
  public static Color Bottom(int palette){switch(palette){
   case 0:return new Color(.075f,1,.09f,1);
   case 1:return new Color(1,.06f,.73f,1);
   case 2:return new Color(.045f,.91f,1,1);
   default:throw new ArgumentOutOfRangeException(nameof(palette));
  }}
  public static Color Sample(int palette,float upperWeight)=>Color.Lerp(Bottom(palette),Top(palette),Mathf.Clamp01(upperWeight));
  // Share the authoritative fruit ramp. Combo and the warning sprite flash
  // never own this blend; dead players return to their existing death light.
  public static float Blend(double power,bool dead=false)=>dead||double.IsNaN(power)?0:(float)Math.Max(0,Math.Min(1,power));
  public static Color ColorAt(int palette,float upperWeight,double power,bool dead=false)=>Color.Lerp(Color.white,Sample(palette,upperWeight),Blend(power,dead));
 }
}

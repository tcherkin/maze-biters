#if UNITY_EDITOR
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using UnityEngine;
namespace MazeBiters.NativeStudy {
 [Serializable] public sealed class NativeSpawnShieldReport {
  public bool passed;public int assertions,failures;public double elapsedMs;
  public string scope="Actual iPad player contacts and AI planner: defensive spawn shield, genuine fruit power and unchanged competitive player priority. No rendering or device-performance claim.";
  public List<NativeDifficultyCheck> checks=new List<NativeDifficultyCheck>();
 }
 public static class NativeSpawnShieldValidation {
  static readonly Vector2Int Centre=new Vector2Int(7,7);
  static readonly Vector2Int[] Directions=NativeGameplayWorld.Dirs;
  static NativeGameplayWorld World(int mode=1,int tier=2){
   var rows=Enumerable.Range(0,15).Select(y=>y==0||y==14?new string('#',15):"#"+new string('.',13)+"#").ToArray();
   var w=new NativeGameplayWorld(rows,()=>.99){Time=1000,LevelStarted=1000,Assist=false,AiDifficulty=tier,Difficulty=NativeMazeGenerator.Difficulties[tier]};w.SetMode(mode);
   for(int i=0;i<w.PlayerCount;i++){var p=w.GetPlayer(i);p.Cell=p.From=p.Previous=Centre+new Vector2Int(0,i*3);p.Dir=p.Next=Vector2Int.right;p.Waiting=false;p.Score=0;p.ShieldUntil=5000;}
   return w;
  }
  static void Check(NativeSpawnShieldReport r,bool condition,string name){r.assertions++;if(!condition)r.failures++;r.checks.Add(new NativeDifficultyCheck{name=name,passed=condition});}
  static void Group(NativeSpawnShieldReport r,string name,Action body){try{body();}catch(Exception e){r.assertions++;r.failures++;r.checks.Add(new NativeDifficultyCheck{name=name,passed=false,detail=e.ToString()});}}
  static NativeGameplaySnake Add(NativeGameplayWorld w,Vector2Int head,Vector2Int dir,int length=4)=>w.AddSnake(Enumerable.Range(0,length).Select(i=>head-dir*i),dir,0);
  static void Position(NativePlayer p,Vector2Int c,Vector2Int d){p.Cell=p.From=p.Previous=c;p.Dir=p.Next=d;p.Waiting=false;}
  static void DirectCalls(NativeSpawnShieldReport r){
   foreach(int mode in new[]{0,1,3,4})foreach(var d in Directions)foreach(int at in new[]{0,1,3}){
    var w=World(mode);var p=w.GetPlayer(w.PlayerCount-1);using(w.ForPlayer(p)){
     var s=Add(w,Centre+d*2,d);Position(p,s.Body[at],d);p.Previous=p.Cell-d;
     w.Eat(s,at);Check(r,!p.Dead&&p.Score>0&&(at==3?s.Body.Count==3:!w.Snakes.Contains(s)),$"Ordinary direct meal remains legal during shield mode={mode}, direction={d}, index={at}");
    }
    w=World(mode);p=w.GetPlayer(w.PlayerCount-1);using(w.ForPlayer(p)){
     var s=Add(w,Centre,-d);Position(p,Centre,d);p.Previous=Centre-d;var before=s.Body.ToArray();int events=0;w.Event=_=>events++;
     w.Eat(s,0);w.PowerEatHead(s);Check(r,w.Snakes.Contains(s)&&before.SequenceEqual(s.Body)&&p.Score==0&&!p.Dead&&events==0,"Defensive shield protects but does not consume a frontal head through direct entry points");
     var h=new NativeHunter{Id=100,Cell=p.Cell};w.Hunters.Add(h);w.EatHunter(h);Check(r,w.Hunters.Contains(h)&&p.Score==0&&events==0,"Shield alone cannot invoke enemy-human consumption");
     var sc=w.PlaceScorpion(p.Cell,d);w.EatScorpion();Check(r,w.Scorpion==null&&!p.Dead&&p.Score>0,"Ordinarily edible scorpion remains edible during protection");
    }
   }
  }
  static void Contacts(NativeSpawnShieldReport r){
   foreach(var d in Directions)foreach(string creature in new[]{"tail","body","rear-head","safe-lone-head","head","lone-head","hunter","scorpion"}){
    var w=World();var p=w.Player;Position(p,Centre,d);var target=p.Cell+d;var perpendicular=new Vector2Int(-d.y,d.x);NativeGameplaySnake snake=null;
    if(creature=="tail")snake=Add(w,target+d*3,d);
    else if(creature=="body")snake=Add(w,target+perpendicular*2,perpendicular);
    else if(creature=="rear-head")snake=Add(w,target,d);
    else if(creature=="safe-lone-head")snake=Add(w,target,d,1);
    else if(creature=="head")snake=Add(w,target,-d);
    else if(creature=="lone-head")snake=Add(w,target,-d,1);
    else if(creature=="hunter")w.Hunters.Add(new NativeHunter{Id=100,Cell=target,From=target,Dir=-d,LastMove=w.Time});
    else w.PlaceScorpion(target,-d);
    int mass=w.Snakes.Sum(s=>s.Body.Count);bool blocked=creature=="head"||creature=="lone-head"||creature=="hunter";w.AdvancePlayer();
    Check(r,blocked?p.Cell==Centre&&!p.Dead&&p.Score==0&&w.Snakes.Sum(s=>s.Body.Count)==mass:p.Cell==target&&!p.Dead&&p.Score>0,$"Shield permits ordinary food but blocks frontal/hunter contact: {creature}, {d}");
    if(blocked){w.ActivatePower();w.AdvancePlayer();Check(r,p.Cell==target&&!p.Dead&&p.Score>0,$"Real fruit power permits offensive contact while shield remains: {creature}, {d}");}
   }
   foreach(var d in Directions){
    var w=World();Position(w.Player,Centre,d);var s=Add(w,Centre+d*4,d);w.Time=5000;w.AdvancePlayer();
    Check(r,s.Body.Count==3&&w.Player.Score==25&&w.Player.Cell==Centre+d,"Normal tail eating is unchanged at shield expiry: "+d);
    w=World();Position(w.Player,Centre,d);w.Fruits.Add(new NativeFruit{Cell=Centre+d,Kind=0});w.AdvancePlayer();
    Check(r,w.Fruits.Count==0&&w.Power&&w.CombatPower&&w.Player.ShieldUntil>w.Time,"A fruit remains collectible under shield and activates real power: "+d);
    w=World();Position(w.Player,Centre,d);s=Add(w,Centre+d,-d);w.SnakeStep(s);
    Check(r,!w.Player.Dead&&w.Player.Score==0&&w.Snakes.Contains(s)&&s.Head!=Centre,"Incoming snake is repelled without being consumed: "+d);
    w=World();Position(w.Player,Centre,d);var h=new NativeHunter{Id=100,Cell=Centre+d,From=Centre+d,Dir=-d,LastMove=0};w.Hunters.Add(h);w.Player.LastMove=w.Time+10000;w.Tick(w.Time+96);
    Check(r,!w.Player.Dead&&w.Hunters.Contains(h)&&h.Cell!=w.Player.Cell&&w.Player.Score==0,"Incoming hunter cannot overlap or die to the shield: "+d);
   }
  }
  static void Competitive(NativeSpawnShieldReport r){
   foreach(int mode in new[]{2,3,4})foreach(bool ahead in new[]{false,true}){
    var w=World(mode);var a=w.GetPlayer(0);var b=w.GetPlayer(1);Position(a,Centre,Vector2Int.right);Position(b,Centre+Vector2Int.right,Vector2Int.left);b.ShieldUntil=0;b.Score=ahead?9999:0;a.Score=ahead?0:9999;
    Check(r,w.CanEatPlayer(a,b)&&!w.CanEatPlayer(b,a),$"Competitive shield retains player priority mode={mode}, rival-leading={ahead}");
    w.AdvancePlayer();Check(r,b.Dead&&!a.Dead&&a.Cell==b.Cell&&a.Score==(ahead?1000:10999),"Competitive player consumption still resolves normally");
   }
   {var w=World(5);var a=w.Player;var b=w.GetPlayer(1);Position(a,Centre,Vector2Int.right);Position(b,Centre+Vector2Int.right,Vector2Int.left);b.ShieldUntil=0;w.AdvancePlayer();Check(r,!a.Dead&&!b.Dead&&a.Cell==Centre&&!w.CanEatPlayer(a,b),"CO-OP remains noncompetitive");}
  }
  static void Planner(NativeSpawnShieldReport r){
   foreach(int tier in new[]{0,1,2,3,4})foreach(int mode in new[]{0,3,4})foreach(var d in Directions){
    var w=World(mode,tier);var p=w.GetPlayer(w.PlayerCount-1);Position(p,Centre,d);for(int i=0;i<w.PlayerCount-1;i++){w.GetPlayer(i).Dead=true;w.GetPlayer(i).Lives=0;}var s=Add(w,Centre+d*4,d);w.Ally.BeginLevel();
    using(w.ForPlayer(p)){w.Ally.Plan(p,w.Time);Check(r,p.Next==d&&!p.Waiting,$"Shielded AI selects ordinary nearby food mode={mode}, tier={tier}, {d}");w.AdvancePlayer();Check(r,!p.Dead&&p.Score>0&&s.Body.Count==3,"Shielded AI eats a normal tail through the real movement path");}
   }
   {var w=World(0);var p=w.Player;var rows=w.Grid.Select(s=>s.ToCharArray()).ToArray();foreach(var d in Directions)rows[(Centre+d).y][(Centre+d).x]='#';rows[Centre.y][Centre.x+1]='.';w.Grid=rows.Select(s=>new string(s)).ToArray();Add(w,Centre+Vector2Int.right,Vector2Int.left,1);w.Ally.BeginLevel();w.Ally.Plan(p,w.Time);w.AdvancePlayer();Check(r,p.Waiting&&p.Cell==Centre&&!p.Dead&&p.Score==0,"An AI whose only exit is a hostile head waits without consuming it through shield");}
   {var w=World(0);w.UseLegacyAi=true;var p=w.Player;var s=Add(w,Centre,-Vector2Int.right,1);p.Previous=Centre-Vector2Int.right;w.Eat(s,0);Check(r,!w.Snakes.Contains(s)&&p.Score==125,"Frozen historical oracle explicitly retains its old shield rule");}
  }
  public static NativeSpawnShieldReport Run(){var timer=Stopwatch.StartNew();var r=new NativeSpawnShieldReport();Group(r,"direct entries",()=>DirectCalls(r));Group(r,"movement contacts",()=>Contacts(r));Group(r,"competitive exception",()=>Competitive(r));Group(r,"AI",()=>Planner(r));r.elapsedMs=timer.Elapsed.TotalMilliseconds;r.passed=r.failures==0;return r;}
 }
}
#endif

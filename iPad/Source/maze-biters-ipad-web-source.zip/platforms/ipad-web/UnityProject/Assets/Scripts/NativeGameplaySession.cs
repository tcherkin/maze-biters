using System;using System.IO;using System.Linq;using UnityEngine;
namespace MazeBiters.NativeStudy {
 public sealed partial class NativeGameplayStudy {
  NativeSessionPresentation sessionArt;NativeSessionAudio sessionAudio;bool sessionSmoke;double realClock=1000;bool sessionChecks=true;int sessionStartMusic;
  void SetMaze(string prefix){if(NativeGlassPresentation.Enabled){var source=prefix.Length==0?new SessionLevel{geometry=level.geometry,theme="green"}:currentGeneratedLevel;InstallMazeArt(new NativeMazeArtwork(source,world?.Level??1,glassQuality:quality));return;}sceneMazeArt=null;if(maze)Destroy(maze);maze=NativeLightField.Load(prefix+"maze.png");mazePaint.mainTexture=maze;}
  void RebuildSessionVisuals(){foreach(var step in RebuildSessionVisualsSteps()){} }
  System.Collections.Generic.IEnumerable<object> RebuildSessionVisualsSteps(){
   ResetGameplayCamera();
   if(TryInstallNextScene())yield break;
   if(responsiveLevelInstalling)throw new InvalidOperationException("Prepared next-level scene could not be adopted; refusing synchronous fallback");
   long visualMark=NativeStallTrace.Stamp();draw.Clear();intake.Begin();blooms.Reset();foreach(var s in snakes.Values)s.Dispose();snakes.Clear();foreach(var s in ghosts)s.Dispose();ghosts.Clear();foreach(var a in actors.Values)a.Dispose();actors.Clear();scorpionArt?.Dispose();scorpionArt=null;foreach(var g in scorpionGhosts)g.art.Dispose();scorpionGhosts.Clear();pickups?.Dispose();NativeStallTrace.Add("next-dispose",visualMark);visualMark=NativeStallTrace.Stamp();yield return "scene disposal";pickups=new NativePickups(quad,quality,menuPreparing&&NativeSmoothLoading.Enabled);if(menuPreparing&&NativeSmoothLoading.Enabled)foreach(var step in pickups.LoadSteps(quality))yield return "pickup art";yield return "pickup art";neon?.Dispose();NativeStallTrace.Add("next-pickups",visualMark);visualMark=NativeStallTrace.Stamp();
   foreach(var s in world.Snakes){AddSnake(s);yield return "snake art";}for(int pi=0;pi<world.PlayerCount;pi++){var player=world.GetPlayer(pi);AddActor(player,true,player.Palette);yield return "player art";}NativeStallTrace.Add("next-creatures",visualMark);visualMark=NativeStallTrace.Stamp();string prefix="levels/"+world.Level+"/";NativeMazeArtwork generated=null;if(catalogueControl&&!NativeGlassPresentation.Enabled)SetMaze(prefix);else{generated=TakeMenuInitialMaze()??TakePreparedMaze()??new NativeMazeArtwork(currentGeneratedLevel,world.Level,glassQuality:GlassQuality);InstallMazeArt(generated);}NativeStallTrace.Add("next-art",visualMark);yield return "maze art";visualMark=NativeStallTrace.Stamp();neon=new NativeNeon(world.Grid,quad,dusk,false,snakes.Values.Select(s=>s.art).ToArray(),true,true,true,prefix,generated,deferred:menuPreparing&&NativeSmoothLoading.Enabled);if(menuPreparing&&NativeSmoothLoading.Enabled){while(!neon.PrepareStep())yield return "neon scene construction";neon.SetVisible(true);}BindGlassPresentation(maze,glassEmission,neon);generated?.DisposeStaging();yield return "neon scene";NativeStallTrace.Add("next-neon",visualMark);visualMark=NativeStallTrace.Stamp();
   dusk.Render(world.Player.Cell,world.Player.Dir,0,false,true);biteInitial=.4;pendingCaptures.Clear();PrepareLevelResources();NativeStallTrace.Add("next-resource-preparation",visualMark);
  }
  void SessionEvent(NativeWorldEvent e){
   if(e.Kind=="sound"){if(e.Sound=="BonusLife@")hud?.BonusLife(realClock,e.Player?.Id??1);sessionAudio?.Play(e.Sound,e.Cell,e.GlobalSound,realClock);return;}
   if(e.Kind=="levelComplete"){QueueNextMaze();return;}if(e.Kind=="music"){sessionAudio?.SetTrack(world.MusicTrack,realClock);return;}
   if(e.Kind=="levelChanged"){hud?.BeginLevel(realClock);RebuildSessionVisuals();return;}
   if(e.Kind=="death"&&IpadPresentation.Enabled&&world.Multiplayer){ipadCameraMotion.BeginLoss(world.RealTime,world.Player.Id);if(ipadBalanceProbe)ipadBeforeBalance.BeginLoss(world.RealTime,world.Player.Id);}
   if(e.Kind=="respawn"){if(IpadPresentation.Enabled&&world.Multiplayer){ipadCameraMotion.BeginReveal(world.RealTime,world.Player.Id);if(ipadBalanceProbe)ipadBeforeBalance.BeginReveal(world.RealTime,world.Player.Id);if(ipadSoloPaceProbe)ipadFastRespawnReference.BeginReveal(world.RealTime,world.Player.Id);}actors[world.Player.Id].Dispose();actors.Remove(world.Player.Id);AddActor(world.Player,true,world.Player.Palette);biteInitial=.4;}
  }
  void BeginCampaign(){if(menuInitialMaze==null)ConfigureGeneration();world.Difficulty=NativeMazeGenerator.Difficulties[difficultyIndex];world.AiDifficulty=difficultyIndex;world.ScoreSpeed=MenuScoreSpeed;world.SetMode(menuPreparing?menuMode:MenuOwner?MenuOwner.State.SelectedMode:Environment.GetCommandLineArgs().Contains("--ai-only")?0:Environment.GetCommandLineArgs().Contains("--duo-ai")?4:Environment.GetCommandLineArgs().Contains("--solo-ai")?3:Environment.GetCommandLineArgs().Contains("--versus")?2:Environment.GetCommandLineArgs().Contains("--duo")?5:1);world.StartSession(LoadCampaignLevel);world.Event=OnEvent;if(!menuPreparing)RebuildSessionVisuals();if(sessionAudio==null){sessionAudio=new GameObject("Native original audio").AddComponent<NativeSessionAudio>();sessionAudio.Initialize(sessionSmoke);}if(!menuPreparing){sessionAudio.ResetBus();sessionAudio.SetTrack(world.MusicTrack,realClock);}}
  // Staged input/contacts ONLY in this automation; the interactive campaign uses
  // actual original spawning, collision rules and clocks.
  void SessionSmokeStep(){
   if(frames==1){sessionStartMusic=sessionAudio.MusicChanges;world.Player.Score=1235;world.Player.ExactScore=1235;world.SessionDeath();sessionChecks&=world.Player.Lives==2&&world.GameOverPending==false;}
   if(frames==50){sessionChecks&=world.DeathAlpha>0;Capture(Path.ChangeExtension(report,null)+"-death.png");}
   if(frames==300){world.Snakes.Clear();world.Hunters.Clear();world.Scorpion=null;world.Eggs.Add(new NativeEgg{Cell=world.PlayerStart,Born=time});}
   if(frames==360){sessionChecks&=world.Player.Dead&&world.Player.HideDeath;world.Eggs.Clear();}
   if(frames==370){sessionChecks&=!world.Player.Dead&&world.Player.Score==1235&&world.Player.ShieldUntil>time;Capture(Path.ChangeExtension(report,null)+"-respawn.png");}
   if(frames==400){quality=quality=="hd"?"4k":"hd";SetQuality();}
   if(frames==420){quality=quality=="hd"?"4k":"hd";SetQuality();world.Snakes.Clear();foreach(var oldVisual in snakes.Values)oldVisual.Dispose();snakes.Clear();var cell=world.Brain.Nearest(world.PlayerStart+Vector2Int.right);var s=world.AddSnake(new[]{cell},Vector2Int.right,0);AddSnake(s);world.Player.Previous=cell-Vector2Int.right;world.Player.Cell=world.Player.From=cell;world.Player.Dir=world.Player.Next=Vector2Int.right;world.ActivatePower();world.Eat(s,0);sessionChecks&=world.Transition&&world.RevealAt>time;}
   if(frames==480){Capture(Path.ChangeExtension(report,null)+"-complete.png");sessionChecks&=world.Transition;}
   if(frames==850){sessionChecks&=world.Level==2&&world.Snakes.Count==4&&world.Snakes.Any(s=>s.Palette==0)&&world.Player.Score==1860&&world.MusicTrack.Contains("orbit")&&sessionAudio.MusicChanges==sessionStartMusic+1;Capture(Path.ChangeExtension(report,null)+"-level2.png");world.Player.ShieldUntil=0;world.Player.Lives=1;world.SessionDeath();}
   if(frames==1210){sessionChecks&=world.GameOver&&world.Player.HideDeath&&world.Player.Lives==0;}
   if(frames==1280)Capture(Path.ChangeExtension(report,null)+"-gameover.png");
   if(frames==2000){sessionChecks&=world.GameOver&&world.MusicGain==0&&sessionAudio.Accepted>=4;var result=new SessionSmokeResult{passed=sessionChecks,quality=quality,frames=frames,level=world.Level,score=world.Player.Score,sounds=sessionAudio.Accepted,musicChanges=sessionAudio.MusicChanges,events=events.Distinct().ToArray(),note="Staged contacts and blockers; interactive campaign uses original rules. Muted automated audio; asset/event/mix tested, not a listening assessment. No performance claims."};File.WriteAllText(report,JsonUtility.ToJson(result,true));Application.Quit(sessionChecks?0:2);}
  }
 }
 [Serializable] sealed class SessionSmokeResult{public bool passed;public string quality,note;public int frames,level,score,sounds,musicChanges;public string[] events;}
}

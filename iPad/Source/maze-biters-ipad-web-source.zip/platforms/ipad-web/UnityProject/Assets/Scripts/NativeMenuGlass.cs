using System;
using UnityEngine;

namespace MazeBiters.NativeStudy {
 // Experimental presentation only: the original menu state, glyph layers and
 // hit areas remain authoritative, including confirmation and setting pulses.
 public sealed partial class NativeMenuRenderer {
  const float StudyBrightness=.55f,StudyMotion=1,StudyGlow=.6f;
  const int StudyPalette=3;
  const bool StudyOuterFrame=true,StudySoftFrame=true,StudyLetterAccent=true,StudyLetterContrast=true,StudyLetterFlow=true;
  MenuEffectTempo glassMenuTempo;double glassMenuLastTime=double.NaN;
  public double GlassMenuEffectMilliseconds=>glassMenuTempo?.Milliseconds??0;
  public double GlassMenuTempo=>glassMenuTempo?.Value??2.5;
  public long GlassMenuTextureBytes=>studyBackdrop?.TextureBytes??0;
  internal void CopyGlassMenuClockFrom(NativeMenuRenderer source){glassMenuTempo=source.glassMenuTempo?.Copy();glassMenuLastTime=source.glassMenuLastTime;}
  void AdvanceGlassMenuClock(NativeMenuState state,double t){
   if(glassMenuTempo==null||double.IsNaN(glassMenuLastTime)||t<glassMenuLastTime){glassMenuTempo=new MenuEffectTempo(2.5*state.Rate,Math.Max(0,t)*2.5*state.Rate);glassMenuLastTime=t;return;}
   glassMenuTempo.SetTarget(2.5*state.Rate);glassMenuTempo.Advance(Math.Max(0,t-glassMenuLastTime)*.001);glassMenuLastTime=t;
  }
  System.Collections.Generic.IEnumerable<object> PrepareGlassMenuSteps(){
   studyBackdrop=new GlassMenuBackdrop(Manifest.quality);foreach(var step in studyBackdrop.LoadSteps()){ThrowIfDisposed();yield return step;}TextureBytes+=studyBackdrop.TextureBytes;
   EnsureStudyGlass();var shader=Shader.Find("MazeBiters/MenuOuterFrame");if(!shader)throw new InvalidOperationException("Menu outer frame shader is missing");studyOuterFrame=new Material(shader){name="Retained champagne menu surround",hideFlags=HideFlags.HideAndDontSave};yield return "menu glass materials";
  }
  GlassMenuBackdrop studyBackdrop;
  Material studyPanel,studyChrome,studyOuterFrame;
  readonly MaterialPropertyBlock studyProperties=new MaterialPropertyBlock();
  const float StudyPanelPadding=14;
  static readonly int StudyDimensions=Shader.PropertyToID("_Dimensions"), StudyFocus=Shader.PropertyToID("_Focus"),
   StudyOpacity=Shader.PropertyToID("_Opacity"), StudyLight=Shader.PropertyToID("_Brightness"),
   StudyGlowId=Shader.PropertyToID("_Glow"), StudyTime=Shader.PropertyToID("_StudyTime"),
   StudyTex=Shader.PropertyToID("_MainTex"), StudyLogo=Shader.PropertyToID("_LogoRect"),
   StudyLayerSize=Shader.PropertyToID("_LayerSize"), StudyChampagne=Shader.PropertyToID("_Champagne");

  void EnsureStudyGlass(){
   if(studyBackdrop==null)throw new InvalidOperationException("Glass menu resources were not prepared");
   if(!studyPanel)studyPanel=new Material(Shader.Find("MazeBiters/MenuGlassPanel")){name="Study smoked menu glass"};
   if(!studyChrome)studyChrome=new Material(Shader.Find("MazeBiters/MenuGlassChrome")){name="Study original logo glazing"};
  }

  void DrawStudyBackground(double t){
   EnsureStudyGlass();
   var f=MenuFrame;var original=f.Original;const float scale=768f/432;
   var viewport=new Rect(-original.x*scale,-original.y*scale,f.Width*scale,f.Height*scale);
   studyBackdrop.Draw(draw,quad,viewport,t,glassMenuTempo.Milliseconds);
   for(int i=0;i<areas.Length;i++)DrawStudyPanel(i,0,1);
  }

  void DrawStudyFocus(NativeMenuState s,double t){
   // Use exactly the existing smooth handover. These layers add a light glaze
   // rather than obscuring the original label or replacing its blink timing.
   for(int i=0;i<areas.Length;i++){
    double a=i==s.Focus?s.FocusAlpha:i==s.OldFocus?s.OldAlpha:0;
    if(a>.001)DrawStudyPanel(i,1,(float)a);
   }
  }

  void DrawStudyPanel(int index,float focus,float opacity){
   var a=areas[index];if(a==null)return;
   // Original drawHighScoreButton face is inset from its hit rectangle; the
   // padded focus PNG is not the face size. Keep all twelve faces registered.
   var face=new Rect(a.x+1,a.y+1,a.w-2,a.h-4);
   float r=index<6?14:11,p=StudyPanelPadding;
   var bounds=new Rect(face.x-p,face.y-p,face.width+2*p,face.height+2*p);
   studyProperties.Clear();
   studyProperties.SetVector(StudyDimensions,new Vector4(face.width,face.height,p,r));
   studyProperties.SetFloat(StudyFocus,focus);
   studyProperties.SetFloat(StudyOpacity,Mathf.Clamp01(opacity));
   studyProperties.SetFloat(StudyLight,Mathf.Clamp01(StudyBrightness));
   studyProperties.SetFloat(StudyGlowId,Mathf.Clamp01(StudyGlow));
   studyProperties.SetFloat(StudyChampagne,StudyPalette==1||StudyPalette==3?1:0);
   draw.DrawMesh(quad,StudyTransform(bounds),studyPanel,0,0,studyProperties);
  }

  void DrawStudyChrome(double t){
   EnsureStudyGlass();
   string id=recordMenu?"menu-chrome":"chrome";var layer=layers[id];
   studyProperties.Clear();studyProperties.SetTexture(StudyTex,textures[id]);
   studyProperties.SetVector(StudyLayerSize,new Vector4(layer.w,layer.h,layer.x,layer.y));
   // Only the original logo lives here. The score above and every menu caption
   // below remain a pixel-identical sample of their existing chrome texture.
   studyProperties.SetVector(StudyLogo,new Vector4(176,60,664,98));
   studyProperties.SetFloat("_BAccent",StudyLetterAccent?1:0);
   studyProperties.SetFloat("_BContrast",StudyLetterContrast?1:0);
   studyProperties.SetFloat("_BFlow",StudyLetterFlow?1:0);
   studyProperties.SetFloat(StudyTime,(float)((t*.001*Math.Max(0,StudyMotion))%840));
   studyProperties.SetFloat(StudyGlowId,Mathf.Clamp01(StudyGlow));
   studyProperties.SetFloat(StudyOpacity,1);
   studyProperties.SetFloat(StudyChampagne,StudyPalette==1||StudyPalette==3?1:0);
   draw.DrawMesh(quad,StudyTransform(new Rect(layer.x,layer.y,layer.w,layer.h)),studyChrome,0,0,studyProperties);
  }

  void DrawStudyOuterFrame(){
   if(!StudyOuterFrame)return;
   if(!studyOuterFrame){
    var shader=Shader.Find("MazeBiters/MenuOuterFrame");
    if(!shader)throw new InvalidOperationException("Menu outer frame shader is missing");
    studyOuterFrame=new Material(shader){name="Retained champagne menu surround",hideFlags=HideFlags.HideAndDontSave};
   }
   // A stationary surround belongs to the menu, not to its breathing maze.
   // Preserve the original inset and round corners without moving hit areas.
   var f=MenuFrame;const float scale=768f/432;
   var viewport=new Rect(-f.Original.x*scale,-f.Original.y*scale,f.Width*scale,f.Height*scale);
   studyProperties.Clear();
   studyProperties.SetVector(StudyDimensions,new Vector4(viewport.width,viewport.height,8,22));
   studyProperties.SetFloat("_SoftFrame",StudySoftFrame?1:0);
   studyProperties.SetFloat(StudyGlowId,Mathf.Clamp01(StudyGlow));
   draw.DrawMesh(quad,StudyTransform(viewport),studyOuterFrame,0,0,studyProperties);
  }

  static Matrix4x4 StudyTransform(Rect r)=>Matrix4x4.TRS(new Vector3(r.x,-r.y,0),Quaternion.identity,new Vector3(r.width,r.height,1));
  void DisposeStudyGlass(){
   studyBackdrop?.Dispose();studyBackdrop=null;
   UnityEngine.Object.Destroy(studyPanel);UnityEngine.Object.Destroy(studyChrome);UnityEngine.Object.Destroy(studyOuterFrame);
   studyPanel=null;studyChrome=null;studyOuterFrame=null;
  }
 }
}

using System;
using System.Linq;
namespace MazeBiters.NativeStudy {
 public sealed partial class NativeGameplayStudy {
  // These events have no Player. Keep them outside the player intake path so
  // a distant cut cannot animate a human's mouth or pull particles toward it.
  bool CreatureFeudEvent(NativeWorldEvent e){
   if(e.Kind=="hunterSplit"){
    if(!snakes.TryGetValue(e.Snake.Id,out var visual))visual=AddSnake(e.Snake);
    if(actors.TryGetValue(e.Hunter.Id,out var cutter))
     cutter.biteInitial=AnimationClock.Mouth(e.Time-e.Hunter.MoveStarted,e.Hunter.MoveDuration,e.Hunter.From==e.Hunter.Cell?0:1);
    blooms.AddImpact(e.Cell,e.Snake.Palette,e.Time);
    var children=visual.motion.Split(e.Created.ToArray(),e.Index,e.OldBody.Length,e.Time,e.Hunter.BiteAt);
    snakes.Remove(e.Snake.Id);
    if(children.Length>0){
     RetainSplitVisual(visual,e.Created[0],children[0]);
     for(int i=1;i<children.Length;i++)AddSnake(e.Created[i],children[i]);
    }else visual.Dispose();
    return true;
   }
   if(e.Kind=="snakeHunterBite"){
    // The existing colour cloud covers the same removal used when a player
    // catches a hunter. Its texture/material pool is prepared before play.
    blooms.AddImpact(e.Cell,6+e.Hunter.Palette,e.Time);
    if(actors.TryGetValue(e.Hunter.Id,out var victim)){
     victim.Dispose();actors.Remove(e.Hunter.Id);
    }
    if(!snakes.TryGetValue(e.Snake.Id,out var eater))eater=AddSnake(e.Snake);
    eater.feudBiteAt=e.Time;eater.feudBiteEnd=e.Time+140;
    eater.feudBiteInitial=SnakeMotion.Mouth(eater.motion.Evaluate(e.Time).phase)/96.0;
    return true;
   }
   return false;
  }
  void RenderCreatureFeudBite(Snake visual,SnakePose pose){
   if(time<visual.feudBiteAt||time>=visual.feudBiteEnd+90)return;
   pose.mouthOverride=AnimationClock.Frame(AnimationClock.Bite(time,visual.feudBiteAt,visual.feudBiteEnd,visual.feudBiteInitial,SnakeMotion.Mouth(pose.phase)/96.0),96);
  }
 }
}

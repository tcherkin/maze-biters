using System;
using System.Collections;
using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;
using UnityEngine;

namespace MazeBiters.NativeStudy {
 // The Web player has no managed worker threads. Jobs run cooperatively on the
 // player loop; large painters register their scanline iterator during creation.
 public sealed class WebWorkQueue:MonoBehaviour {
  static WebWorkQueue owner;
  static List<IEnumerable<object>> captured;
  internal static bool Capturing=>captured!=null;
  internal static void Defer(IEnumerable<object> work){if(captured==null)throw new InvalidOperationException("No cooperative job owns this work");captured.Add(work);}
  static WebWorkQueue Owner {get{if(!owner){owner=new GameObject("Web cooperative preparation").AddComponent<WebWorkQueue>();DontDestroyOnLoad(owner.gameObject);}return owner;}}
  public static Task Run(Action action)=>Run(()=>{action();return true;});
  public static Task<T> Run<T>(Func<T> action)=>Run(action,CancellationToken.None);
  public static void Continue<T>(Task<T> task,Action<Task<T>> completed){
#if UNITY_WEBGL && !UNITY_EDITOR
   Owner.StartCoroutine(Complete(task,completed));
#else
   task.ContinueWith(completed,TaskScheduler.Default);
#endif
  }
  static IEnumerator Complete<T>(Task<T> task,Action<Task<T>> completed){while(!task.IsCompleted)yield return null;completed(task);}
  public static Task<T> Run<T>(Func<T> action,CancellationToken cancellation){
#if UNITY_WEBGL && !UNITY_EDITOR
   var result=new TaskCompletionSource<T>();Owner.StartCoroutine(Execute(action,cancellation,result));return result.Task;
#else
   return Task.Run(action,cancellation);
#endif
  }
  static IEnumerator Execute<T>(Func<T> action,CancellationToken token,TaskCompletionSource<T> result){
   yield return null;T value=default;Exception failure=null;var parts=new List<IEnumerable<object>>();
   try{token.ThrowIfCancellationRequested();captured=parts;value=action();}catch(Exception error){failure=error;}finally{captured=null;}
   for(int i=0;failure==null&&i<parts.Count;i++){
    IEnumerator<object> steps=null;
    try{steps=parts[i].GetEnumerator();}catch(Exception error){failure=error;}
    bool finished=false;
    while(!finished&&failure==null){
     var budget=System.Diagnostics.Stopwatch.StartNew();
     do{try{token.ThrowIfCancellationRequested();finished=!steps.MoveNext();}catch(Exception error){failure=error;}}
     while(!finished&&failure==null&&budget.Elapsed.TotalMilliseconds<2.5);
     if(!finished&&failure==null)yield return null;
    }
    try{steps?.Dispose();}catch(Exception error){if(failure==null)failure=error;}
   }
   if(failure is OperationCanceledException)result.TrySetCanceled();else if(failure!=null)result.TrySetException(failure);else result.TrySetResult(value);
  }
 }
}

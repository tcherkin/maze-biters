using System;
namespace MazeBiters.NativeStudy {
 // Screen framing only. The original camera's roster, motion and easing clocks
 // stay in board coordinates; stars, lighting and pointer use the final transform.
 public static class NativeOverviewFraming {
  static readonly bool legacyArgument=Array.IndexOf(Environment.GetCommandLineArgs(),"--legacy-camera-framing")>=0;
  internal static bool ComparisonLegacy;
  public static bool Legacy=>legacyArgument||ComparisonLegacy;
  static double Smooth(double t){t=Math.Max(0,Math.Min(1,t));return t*t*(3-2*t);}
  public static double Fit(NativeFrame frame)=>Math.Min(frame.Width/576.0,frame.Height/400.0);
  public static double Zoom(NativeFrame frame,double zoom){
   if(!frame.OverlayHud)return zoom;
   // Remove the obsolete 32-unit HUD reservation at overview (1.08 on wide
   // screens). Taper to the established 2x close view, without a scale switch.
   return zoom+Math.Max(0,Fit(frame)-1)*Math.Max(0,Math.Min(1,2-zoom));
  }
  public static double Y(NativeFrame frame,double y,double zoom,double viewZoom){
   if(!frame.OverlayHud||Fit(frame)<=1.000001)return frame.CameraY(y,zoom);
   if(zoom<=1)return y;
   double span=Math.Min(64/zoom,200-200/zoom);if(span<=0)return y;
   double top=Smooth(1-(y-200/zoom)/span),bottom=Smooth(1-(400-200/zoom-y)/span);
   // No vertical sky at overview. Grow the same top/bottom space only as the
   // camera closes in, reaching the existing 52-unit gap at an edge by 1.5x.
   double sky=52*Smooth((zoom-1)/.5),naturalGap=frame.Height/2-200*viewZoom/zoom;
   return y+(naturalGap-sky)/viewZoom*(top-bottom);
  }
 }
}

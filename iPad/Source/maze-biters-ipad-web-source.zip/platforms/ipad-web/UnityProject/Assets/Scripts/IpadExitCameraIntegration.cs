using System;
using UnityEngine;
namespace MazeBiters.NativeStudy {
 public sealed partial class NativeGameplayStudy {
  readonly IpadExitCamera ipadExitCamera=new IpadExitCamera();
  NativeGameplayWorld exitCameraWorld;double exitCameraAt,exitCameraElapsed;bool exitCameraGameOver,lastIpadViewValid;
  IpadView lastIpadView;int exitCameraPresentedFrame=-1;
  bool ExitCameraEnabled=>IpadPresentation.Enabled&&!fixedCamera&&!ipadLegacyCameraProbe&&!ipadRosterBeforeProbe;
  bool ExitCameraMatches=>ipadExitCamera.Active&&ReferenceEquals(exitCameraWorld,world)&&exitCameraGameOver==world.GameOver&&exitCameraAt==(world.GameOver?world.GameOverAt:world.TransitionAt);
  void ResetIpadExitCamera(){ipadExitCamera.Reset();exitCameraWorld=null;lastIpadViewValid=false;exitCameraPresentedFrame=-1;exitCameraElapsed=0;}
  void EnsureIpadExitCamera(){
   if(ExitCameraMatches)return;
   var f=DisplayFrame;var safe=IpadPresentation.SafeRect(f);
   var overview=IpadFraming.Calculate(f,288,200,1,IpadPresentation.CloseZoom(f),safe);
   ipadExitCamera.Begin(f,lastIpadViewValid?lastIpadView:overview,overview,world.GameOver?NativeGameplayWorld.GameOverDuration:NativeGameplayWorld.ClearDuration,world.GameOver?0:LevelGateCycle);
   exitCameraWorld=world;exitCameraGameOver=world.GameOver;exitCameraAt=world.GameOver?world.GameOverAt:world.TransitionAt;
   exitCameraElapsed=0;exitCameraPresentedFrame=-1;
  }
  void AdvanceIpadExitCamera(double elapsed){
   if(!ExitCameraEnabled||world==null||!(world.GameOver||world.Transition)||preparingScene||preparingNextScene)return;
   EnsureIpadExitCamera();exitCameraElapsed=Math.Max(exitCameraElapsed,elapsed);
   ipadExitCamera.Sample(exitCameraElapsed,world.GameOver||!ResponsiveLevelEligible||ResponsiveNextReady);
   if(!ipadExitCamera.Complete)exitCameraPresentedFrame=-1;
  }
  IpadView ApplyIpadExitCamera(IpadView live){
   if(world!=null&&(world.GameOver||world.Transition)){
    double elapsed=world.GameOver?realClock-world.GameOverAt:time-world.TransitionAt+(levelGateWaiting?levelGateExtraTime:0);
    AdvanceIpadExitCamera(elapsed);return ipadExitCamera.Current;
   }
   if(ipadExitCamera.Active){ipadExitCamera.Reset();exitCameraWorld=null;exitCameraPresentedFrame=-1;}
   lastIpadView=live;lastIpadViewValid=true;return live;
  }
  void MarkIpadExitCameraPresented(){
   if(ExitCameraEnabled&&!preparingScene&&!preparingNextScene&&world!=null&&(world.GameOver||world.Transition)&&ExitCameraMatches&&ipadExitCamera.Complete&&exitCameraPresentedFrame<0)
    exitCameraPresentedFrame=Time.frameCount;
  }
  bool IpadExitCameraCanLeave=>!ExitCameraEnabled||ExitCameraMatches&&ipadExitCamera.Complete&&exitCameraPresentedFrame>=0&&Time.frameCount>exitCameraPresentedFrame;
  bool GameOverPresentationFinished=>world.GameOver&&realClock-world.GameOverAt>=NativeGameplayWorld.GameOverDuration&&IpadExitCameraCanLeave;
 }
}

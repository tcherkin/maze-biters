using System;using System.Collections.Generic;using System.Linq;using UnityEngine;
namespace MazeBiters.NativeStudy {
 public sealed partial class NativeAllyBrain {
  int balancedIndex=-1,balancedLevel=-1;AllySkill balancedSkill;NativeDifficultyProfile balancedProfile;
  NativeDifficultyProfile Balance {get{RefreshBalance();return balancedProfile;}}
  AllySkill BalancedSkill {get{RefreshBalance();return balancedSkill;}}
  void RefreshBalance(){
   int index=Math.Max(0,Math.Min(4,w.AiDifficulty));if(balancedSkill!=null&&balancedIndex==index&&balancedLevel==w.Level)return;
   balancedIndex=index;balancedLevel=w.Level;balancedProfile=NativeDifficulty.ForIndex(index,w.Level);var b=balancedProfile;double s=b.Skill;bool best=index==4;
   balancedSkill=new AllySkill(best?Inf:b.Notice,3+s*10,1+Math.Floor(s*3),b.OpponentHuntChance,best?1:s*s,best?0:b.Error,b.DecisionMs,best?1:.2+s*.8,s<.3?4:s<.6?3:s<.9?2:1,best?1:.02+.98*s*s,best?Inf:7+Math.Floor(s*36),best?1:.15+s*.85,best?Inf:3+Math.Floor(s*20),Math.Floor(s*8),best?1:s*s,s*3);
  }
  void ForgetMeal(NativePlayer p){
   var a=S(p);a.locked=null;a.queue.Clear();a.split=null;a.commitMode=a.targetKind=null;a.bitten=false;a.fruit=null;a.graded=null;a.gradedKind=null;a.snakeChoiceUntil=0;a.allowSplit=null;ClearRetreat(p);
  }
  void EndMeal(NativePlayer p,double t){
   if(w.UseLegacyAi||w.AiDifficulty>=4)return;var a=S(p);a.mealInitialized=true;a.mealActive=false;a.mealIntentUntil=t+Balance.RoamWindowMs;ForgetMeal(p);
  }
  bool MealIntent(NativePlayer p,double t){
   if(w.UseLegacyAi)return true;var a=S(p);if(w.AiDifficulty>=4){a.mealInitialized=a.mealActive=true;a.mealIntentUntil=Inf;return true;}
   if(a.mealInitialized&&t<a.mealIntentUntil)return a.mealActive;
   // A meal is a bounded excursion. A failed interest roll is held throughout
   // the stroll, rather than retried at every tile until success is inevitable.
   if(a.mealInitialized&&a.mealActive){EndMeal(p,t);return false;}
   var b=Balance;a.mealInitialized=true;a.mealActive=w.Random()<b.MealChance;a.mealIntentUntil=t+(a.mealActive?b.MealWindowMs:b.RoamWindowMs);
   if(!a.mealActive)ForgetMeal(p);return a.mealActive;
  }
  void ResetDifficulty(NativePlayer p){
   var a=S(p);a.mealInitialized=a.mealActive=false;a.mealIntentUntil=a.opponentHuntUntil=a.opponentRestUntil=0;a.directive=null;a.assessmentAt=0;a.escapeTarget=null;a.escapeUntil=a.escapeTemperamentUntil=0;a.graded=null;a.gradedKind=null;a.snakeChoiceUntil=0;a.allowSplit=null;a.roamVisits.Clear();a.roamObserved=null;
  }
  AllyDirective BalancedDirective(NativePlayer p,double t){
   var a=S(p);if(!w.Competitive||!p.IsAI||p.Dead||p.Lives<=0){a.directive=null;return null;}
   var skill=Skill;var b=Balance;var others=Others(p).Where(o=>!o.Dead&&o.Lives>0).ToList();if(others.Count==0){a.directive=null;return null;}
   var threats=others.Where(o=>w.CanEatPlayer(o,p,t)).ToList();var prey=others.Where(o=>w.CanEatPlayer(p,o,t)).ToList();var prev=a.directive;
   // Contact resolution clears the directive after a successful bite. Remember
   // the completed hunt long enough to give the surviving humans a rest too.
   if(w.AiDifficulty<4&&prev?.type!="hunt"&&a.opponentHuntUntil>0){a.opponentHuntUntil=0;a.opponentRestUntil=Math.Max(a.opponentRestUntil,t+b.OpponentRestMs);}
   bool flip=prev?.type=="hunt"&&threats.Contains(prev.target);
   var measured=threats.Select(o=>(target:o,distance:OpponentDistance(p.Cell,o,skill.prediction))).OrderBy(x=>x.distance).ToList();
   // Survival can interrupt a held casual decision immediately.
   if(measured.Any(x=>x.distance<=skill.panic||flip&&x.target==prev.target&&x.distance<=skill.panic+1))return NewFlee(p,t,measured,skill,flip);
   double previousDistance=measured.Where(x=>x.target==prev?.target).Select(x=>x.distance).DefaultIfEmpty(Inf).First();
   bool valid=prev?.target!=null&&others.Contains(prev.target)&&(prev.type=="hunt"?prey.Contains(prev.target)&&OpponentDistance(p.Cell,prev.target,skill.prediction)<=skill.notice:prev.type=="flee"?threats.Contains(prev.target)&&previousDistance<=skill.panic+1:prev.type=="recover-score"&&threats.Contains(prev.target)&&previousDistance<=skill.notice);
   if(prev?.type=="hunt"){
    if(valid&&(w.AiDifficulty>=4||t<a.opponentHuntUntil))return prev;
    a.directive=null;a.opponentHuntUntil=0;a.opponentRestUntil=t+b.OpponentRestMs;a.assessmentAt=t+Math.Max(180,b.DecisionMs);valid=false;
   }
   if(t<a.assessmentAt){if(!valid)a.directive=null;return a.directive;}
   if(measured.Count>0&&measured[0].distance<=skill.notice){var d=new AllyDirective{type="recover-score",target=measured[0].target,threats=measured.Select(x=>x.target).ToList(),skill=skill};a.directive=d;a.assessmentAt=t+Math.Max(180,b.DecisionMs);a.escapeTarget=null;a.escapeUntil=0;return d;}
   a.directive=null;a.assessmentAt=t+Math.Max(180,b.DecisionMs);if(t<a.opponentRestUntil)return null;
   var candidates=prey.Select(o=>(target:o,distance:OpponentDistance(p.Cell,o,skill.prediction))).Where(x=>Finite(x.distance)&&x.distance<=skill.notice).OrderBy(x=>x.target.Score).ThenBy(x=>x.distance).ToList();
   if(candidates.Count==0)return null;
   if(b.OpponentHuntChance>=1||w.Random()<b.OpponentHuntChance){
    var chosen=candidates[0];if(skill.error>0&&candidates.Count>1&&w.Random()<skill.error)chosen=candidates[1];
    a.directive=new AllyDirective{type="hunt",target=chosen.target,threats=new List<NativePlayer>(),skill=skill};a.opponentHuntUntil=w.AiDifficulty>=4?Inf:t+b.OpponentHuntWindowMs;return a.directive;
   }
   a.opponentRestUntil=t+b.OpponentRestMs;return null;
  }
  Step ImperfectStep(List<Step> measured,Step best,AllyObjective objective,bool open){
   if(w.UseLegacyAi||w.AiDifficulty>=4||objective?.immediate==true)return best;double error=Balance.Error;if(error<=0)return best;
   var alternatives=measured.Where(s=>s!=best&&!s.lethal&&s.danger<105&&!s.unreachable&&(!open||!s.cul)&&s.distance<=best.distance+2).OrderBy(s=>s.score).Take(2).ToList();
   if(alternatives.Count==0||w.Random()>=error)return best;return alternatives[(int)(w.Random()*alternatives.Count)];
  }
 }
}

using System;using System.IO;using System.Linq;using UnityEngine;
namespace MazeBiters.NativeStudy {
 public static class MazeGeneratorValidation {
  [Serializable] public sealed class Selection {public double target,selectedRating;public MazeMetrics metrics;}
  [Serializable] public sealed class Case {public long seed;public double difficulty;public int level;public string[] geometry;public string theme;public MazePatterns patterns;public Selection selection;public SessionStart[] starts;}
  [Serializable] public sealed class Oracle {public Case[] cases;}
  public static int Run(){var oracle=JsonUtility.FromJson<Oracle>(File.ReadAllText(Path.Combine(WebFiles.Root,"Reference/generator-oracle.json")));int count=0;foreach(var e in oracle.cases){var generator=new NativeMazeGenerator((uint)e.seed,e.difficulty,legacyStartCorridors:true);var actual=generator.Generate(e.level);string label=$"seed={e.seed},difficulty={e.difficulty},level={e.level}";
   if(!actual.geometry.SequenceEqual(e.geometry))throw new Exception("Native maze geometry mismatch "+label+" first differing row "+Enumerable.Range(0,25).First(i=>actual.geometry[i]!=e.geometry[i]));
   if(actual.theme!=e.theme||JsonUtility.ToJson(generator.Patterns)!=JsonUtility.ToJson(e.patterns)||Math.Abs(generator.Target-e.selection.target)>1e-9||Math.Abs(generator.Metrics.rating-e.selection.selectedRating)>1e-9||generator.Metrics.floorCells!=e.selection.metrics.floorCells||generator.Metrics.junctions!=e.selection.metrics.junctions||generator.Metrics.deadEnds!=e.selection.metrics.deadEnds||generator.Metrics.openTwoByTwo!=e.selection.metrics.openTwoByTwo||Math.Abs(generator.Metrics.patternDifficulty-e.selection.metrics.patternDifficulty)>1e-9||actual.starts.Length!=e.starts.Length||actual.starts.Where((s,i)=>s.x!=e.starts[i].x||s.y!=e.starts[i].y||s.dir!=e.starts[i].dir).Any())throw new Exception("Native maze metadata mismatch "+label);
   count++;
  }return count;}
 }
}

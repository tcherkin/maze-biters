using System;
namespace MazeBiters.NativeStudy {
 public static partial class NativeHolisticTuning {
  public static bool CoreAngles=!Reference&&!HasArgument("--legacy-core-angles");
  public static bool RouteSearch=!Reference&&!HasArgument("--legacy-route-search");
  public static bool RouteSelect=!Reference&&!HasArgument("--legacy-route-select");
 }
}

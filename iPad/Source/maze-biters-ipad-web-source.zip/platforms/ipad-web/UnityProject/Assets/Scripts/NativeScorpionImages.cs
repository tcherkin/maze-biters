using System;
using System.IO;
using System.Collections.Generic;
using UnityEngine;
namespace MazeBiters.NativeStudy {
 // One immutable, finite source bank per gameplay study, reused by every
 // spawned scorpion/consumption ghost. Mutable targets and motion stay private.
 public sealed class NativeScorpionImages:IDisposable {
  internal readonly ScorpionAssets Assets;
  readonly Dictionary<string,Material> materials=new Dictionary<string,Material>();
  public long TextureBytes{get;private set;}
  public int Count=>materials.Count;
  public NativeScorpionImages(){
   Assets=JsonUtility.FromJson<ScorpionAssets>(File.ReadAllText(Path.Combine(WebFiles.Root,"Reference/scorpion-art.json")));
  }
  public Material Image(string file){
   if(materials.TryGetValue(file,out var found))return found;
   long stamp=NativeStallTrace.Stamp();
   var texture=NativeLightField.Load(file,true);
   var material=new Material(Shader.Find("MazeBiters/PremultipliedImage")){mainTexture=texture};
   materials.Add(file,material);TextureBytes+=(long)texture.width*texture.height*4;
   if(NativeStallTrace.Enabled)NativeStallTrace.Add("load-scorpion:"+file,stamp);
   return material;
  }
  public void Prepare(){foreach(var step in PrepareSteps()){} }
  public IEnumerable<object> PrepareSteps(){
   for(int frame=0;frame<Assets.frames.Length;frame++){
    var a=Assets.frames[frame];Image(a.whole);if(NativeSmoothLoading.Enabled)yield return null;Image(a.rear);if(NativeSmoothLoading.Enabled)yield return null;Image(a.front);if(NativeSmoothLoading.Enabled)yield return null;Image(a.body);if(NativeSmoothLoading.Enabled)yield return null;
    foreach(var leg in a.legs){Image(leg.file);if(NativeSmoothLoading.Enabled)yield return null;}
    Image("scorpion-eye-"+frame+".png");yield return null;
   }
  }
  public void Dispose(){
   foreach(var material in materials.Values){UnityEngine.Object.Destroy(material.mainTexture);UnityEngine.Object.Destroy(material);}
   materials.Clear();TextureBytes=0;
  }
 }
}

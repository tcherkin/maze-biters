using System;using System.IO;using System.Linq;using System.Collections;using System.Collections.Generic;using System.Diagnostics;using UnityEngine;using UnityEngine.Profiling;
namespace MazeBiters.NativeStudy {
 public sealed partial class NativeGameplayStudy {
  bool hudProbe,hudBenchmark;
  [Serializable] sealed class HudProbeResult {public bool passed;public string quality,note;public string[] checks;public long steadyAllocatedBytes,textureBytes;}
  IEnumerator ProbeHud(){
   var checks=new List<string>();void Check(bool ok,string s){if(!ok)throw new Exception("Live HUD: "+s);checks.Add(s);}
   sessionSmoke=true;Reset(12);yield return DrainProbePreparation();Render();
   Check(hud!=null&&hud.LevelAt==realClock,"initial level sweep");
   double levelStart=hud.LevelAt;int updates=hud.MeshUpdates;long allocated=GC.GetAllocatedBytesForCurrentThread();
   for(int i=0;i<1000;i++)hud.Render(world,realClock+i,quality);
   allocated=GC.GetAllocatedBytesForCurrentThread()-allocated;
   Check(hud.MeshUpdates==updates,"static numbers reuse meshes");Check(allocated==0,"no managed allocations in unchanged HUD");
   world.Player.Score=4990;world.Player.ExactScore=4990;world.Player.NextLifeScore=5000;world.Player.Lives=3;world.Player.ExtraLives=0;
   realClock+=1000;world.Award(25);Check(world.Player.Lives==4&&hud.LifeAt==realClock,"original bonus-life event starts sweep");
   Render();Capture(Path.ChangeExtension(report,null)+"-bonus.png");double lifeAt=hud.LifeAt;
   realClock+=NativeHud.LifeSweep+Math.PI*310;Render();
   Check(Math.Abs(NativeHud.LifeAlpha(hud.LifeAt,realClock)-.2)<1e-9,"bonus pulse reaches original minimum");
   Capture(Path.ChangeExtension(report,null)+"-pulse.png");
   world.Player.Lives=9;world.Player.ExactScore=9990;world.Player.Score=9990;world.Player.NextLifeScore=10000;world.Award(25);
   Check(hud.LifeAt==lifeAt&&world.Player.Lives==9,"life cap does not invent pulse");
   paused=true;double gameClock=time;realClock+=1000;Render();Check(time==gameClock&&hud.LevelAt==levelStart&&hud.LifeAt==lifeAt,"UI clock continues in pause without resetting cues");paused=false;
   scenePreparationPending=true;PrepareSceneGpu();Check(hud.LevelAt==levelStart&&hud.LifeAt==lifeAt,"GPU preflight preserves HUD clocks");
   string q=quality;quality=q=="hd"?"4k":"hd";SetQuality();yield return DrainProbePreparation();Render();Check(hud.LevelAt==levelStart&&hud.LifeAt==lifeAt,"quality switch preserves cues");quality=q;SetQuality();yield return DrainProbePreparation();Render();
   Color32[] Header(){
    var previous=RenderTexture.active;RenderTexture.active=target;int height=quality=="4k"?160:80;
    var image=new Texture2D(target.width,height,TextureFormat.RGBA32,false);image.ReadPixels(new Rect(0,target.height-height,target.width,height),0,0);image.Apply();var pixels=image.GetPixels32();Destroy(image);RenderTexture.active=previous;return pixels;
   }
   preparingScene=true;SetGameplayCameraView(288,200,1);Render();var header=Header();
   SetGameplayCameraView(120,90,2);Render();Check(header.SequenceEqual(Header()),"header remains pixel-fixed during pan and 2x zoom");preparingScene=false;ApplyGameplayCamera();
   Render();Capture(Path.ChangeExtension(report,null)+"-game.png");
   File.WriteAllText(report,JsonUtility.ToJson(new HudProbeResult{passed=true,quality=quality,checks=checks.ToArray(),steadyAllocatedBytes=allocated,textureBytes=hud.TextureBytes,note="Real native renderer/events: retained meshes, original bonus life/cap, pause, quality switch, prewarm and screen-space projection. Separate from timed runs."},true));Application.Quit();
  }
  [Serializable] struct HudBenchFrame {public double gapMs,submitMs,simulationMs,hudMs;public long allocated;public bool focused;}
  [Serializable] sealed class HudBenchResult {public string quality,mode,note,gpu,cpu;public bool passed;public int width,height;public double elapsed,cpuSeconds;public long workingSet,privateBytes,unityUsed,managed,hudTextureBytes;public HudBenchFrame[] frames;}
  IEnumerator BenchmarkHud(){
   sessionSmoke=true;Reset(0);yield return DrainProbePreparation();StallSession();world.EnableLifecycle();
   world.Scorpion.NextFruit=time+100000;world.Scorpion.NextEgg=time+100000;world.Player.ShieldUntil=time+100000;world.Player.Cell=world.Player.From=world.Player.Previous=new Vector2Int(2,1);
   var visits=new Dictionary<Vector2Int,int>();var samples=new HudBenchFrame[2400];
   for(int frame=0;frame<240;frame++){StallPilot(visits,true);time+=1000.0/120;realClock+=1000.0/120;world.RealTime=realClock;world.Tick(time);world.UpdateTilt(time);Render();yield return null;}
   GC.Collect();yield return null;
   using(var process=Process.GetCurrentProcess()){
    double cpuStart=process.TotalProcessorTime.TotalSeconds;long start=Stopwatch.GetTimestamp(),previous=0;
    for(int frame=0;frame<samples.Length;frame++){
     long at=Stopwatch.GetTimestamp(),bytes=GC.GetAllocatedBytesForCurrentThread();StallPilot(visits,true);
     time+=1000.0/120;realClock+=1000.0/120;world.RealTime=realClock;
     // Same fixture in both variants; stress UI cues without changing the world.
     if(frame%720==0)hud?.BeginLevel(realClock);if(frame%600==0)hud?.BonusLife(realClock);
     long tick=Stopwatch.GetTimestamp();world.Tick(time);world.UpdateTilt(time);double sim=NativeStallTrace.Ms(tick);
     measureHud=true;long render=Stopwatch.GetTimestamp();Render();double submit=NativeStallTrace.Ms(render);measureHud=false;
     samples[frame]=new HudBenchFrame{gapMs=previous==0?0:(at-previous)*1000.0/Stopwatch.Frequency,simulationMs=sim,submitMs=submit,hudMs=lastHudMs,allocated=GC.GetAllocatedBytesForCurrentThread()-bytes,focused=Application.isFocused};
     previous=at;yield return null;
    }
    double elapsed=NativeStallTrace.Ms(start)/1000,cpuSeconds=process.TotalProcessorTime.TotalSeconds-cpuStart;
    NativeMemory.TryRead(out long ws,out _,out long committed);
    File.WriteAllText(report,JsonUtility.ToJson(new HudBenchResult{passed=!world.Player.Dead,quality=quality,mode=legacyHud?"before":"after",width=target.width,height=target.height,elapsed=elapsed,cpuSeconds=cpuSeconds,workingSet=ws,privateBytes=committed,unityUsed=Profiler.GetTotalAllocatedMemoryLong(),managed=GC.GetTotalMemory(false),hudTextureBytes=hud?.TextureBytes??0,frames=samples,gpu=SystemInfo.graphicsDeviceName,cpu=SystemInfo.processorType,note="Same native build/seed/crowded live simulation; --legacy-hud restores former test UI and excludes HUD resources. 240 warmup + 2400 measured frames; 120Hz target, fixed simulation steps, real frame gaps/process CPU measured separately. SOLO level/life HUD cues repeatedly exercised; no screenshots/readbacks in timing. Working set/private memory are not VRAM."},true));
   }
   Application.Quit(world.Player.Dead?2:0);
  }
  bool measureHud;double lastHudMs;
  void RenderHud(){long stamp=measureHud?Stopwatch.GetTimestamp():0;hud?.Render(world,realClock,quality,!preparingScene&&!preparingNextScene&&!menuPreparing);UpdateHudClearance();if(measureHud)lastHudMs=NativeStallTrace.Ms(stamp);}
 }
}


using System;using System.IO;using System.Collections;using System.Collections.Generic;using UnityEngine;
namespace MazeBiters.NativeStudy {
 public sealed partial class NativeMenu {
  bool aiOnlyMenuTesting;
  IEnumerator AiOnlyMenuProbe(){
   var checks=new List<string>();void Check(bool ok,string label){if(!ok)throw new Exception("AI ONLY menu: "+label);checks.Add(label);}
   Directory.CreateDirectory(Path.GetDirectoryName(report));
   IEnumerator Ready(){double until=Time.realtimeSinceStartupAsDouble+120;while(!PreparedForSelection){if(preloadFailed||Time.realtimeSinceStartupAsDouble>until)throw new TimeoutException("AI ONLY preparation");yield return null;}}
   IEnumerator Playing(){double until=Time.realtimeSinceStartupAsDouble+120;while(!gameplay||!gameplay.MenuReady){if(Time.realtimeSinceStartupAsDouble>until)throw new TimeoutException("AI ONLY start");yield return null;}}
   yield return Ready();State.SetFocus(5,Now);yield return Ready();Check(preparedGame.PreparedMode==0&&preparedBuilds==1,"AI ONLY selected and prepared without reloading source banks");
   double click=Time.realtimeSinceStartupAsDouble;Choose();yield return Playing();double startMs=(Time.realtimeSinceStartupAsDouble-click)*1000;
   Check(gameplay.MenuOptionsValid&&gameplay.AiOnlyRosterValid&&gameplay.MenuRecord==null,"sixth menu button opens original AI ONLY with chosen settings");Check(InstantMenuStart?startMs<250:startMs>=890,"selected menu start policy");SaveFrame(State.Quality+"-ai-menu-start",gameplay.MenuTarget);
   var initial=gameplay.ObservedPlayerCell;int moves=0;for(int i=0;i<180;i++){yield return null;var c=gameplay.ObservedPlayerCell;if(c!=initial){moves++;initial=c;}}
   Check(moves>3,"AI begins automatically after menu release");gameplay.CoopLastLives();bool ready=false;double end=Time.realtimeSinceStartupAsDouble+60;
   while(gameplay){ready|=gameplay.RestartPrepared;if(Time.realtimeSinceStartupAsDouble>end)throw new TimeoutException("AI ONLY GAME OVER");yield return null;}
   while(changing)yield return null;Check(records==null,"AI score never opens record entry");yield return Ready();Check(ready&&State.SelectedMode==0&&State.Focus==5&&preparedGame.PreparedMode==0,"GAME OVER preloads AI ONLY and preserves menu selection");
   click=Time.realtimeSinceStartupAsDouble;Choose();yield return Playing();double restartMs=(Time.realtimeSinceStartupAsDouble-click)*1000;Check(gameplay.AiOnlyRosterValid&&preparedBuilds==1,"cached restart preserves one AI and reuses animation banks");
   ReturnToMenu();while(changing)yield return null;State.SetFocus(0,Now);yield return Ready();Choose();yield return Playing();Check(gameplay.HumanSoloRosterValid&&gameplay.MenuOptionsValid,"switch back to SOLO restores P1 and human input ownership");SaveFrame(State.Quality+"-human-solo-return",gameplay.MenuTarget);
   File.WriteAllText(report,JsonUtility.ToJson(new CoopMenuReport{passed=true,quality=State.Quality,checks=checks.ToArray(),clickToPlayMs=startMs,restartClickToPlayMs=restartMs,gameOverReady=ready,note="Real menu and cached GAME OVER restart; AI ONLY starts unassisted. Final death staged. Muted automation; no user scores/preferences written, no performance claims."},true));Application.Quit();
  }
 }
}

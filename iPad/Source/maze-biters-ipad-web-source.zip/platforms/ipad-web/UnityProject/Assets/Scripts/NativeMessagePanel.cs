using System;
using UnityEngine;
using UnityEngine.Rendering;
namespace MazeBiters.NativeStudy {
 // Shared procedural backdrop for gameplay, menu and future transient notices.
 // No generated textures, blur surfaces or per-frame allocations.
 public sealed class NativeMessagePanel:IDisposable {
  public readonly Material Paint;
  readonly MaterialPropertyBlock properties=new MaterialPropertyBlock();
  static readonly int SizeId=Shader.PropertyToID("_Size"),RadiusId=Shader.PropertyToID("_Radius"),FeatherId=Shader.PropertyToID("_Feather"),OpacityId=Shader.PropertyToID("_Opacity");
  public NativeMessagePanel(){Paint=new Material(Shader.Find("MazeBiters/MessagePanel")){name="Soft rounded notice"};}
  public void SetSize(Vector2 size,float scale=1){Paint.SetVector(SizeId,new Vector4(size.x,size.y,0,0));Paint.SetFloat(RadiusId,18*scale);Paint.SetFloat(FeatherId,12*scale);}
  public void Draw(CommandBuffer draw,Mesh quad,Rect rect,float scale=1,float opacity=1){
   if(opacity<=0||rect.width<=0||rect.height<=0)return;
   properties.Clear();properties.SetVector(SizeId,new Vector4(rect.width,rect.height,0,0));properties.SetFloat(RadiusId,18*scale);properties.SetFloat(FeatherId,12*scale);properties.SetFloat(OpacityId,opacity);
   draw.DrawMesh(quad,Matrix4x4.TRS(new Vector3(rect.x,-rect.y,0),Quaternion.identity,new Vector3(rect.width,rect.height,1)),Paint,0,0,properties);
  }
  public void DrawGUI(Rect rect,float scale=1,float opacity=1){if(Event.current.type!=EventType.Repaint||opacity<=0)return;SetSize(rect.size,scale);Paint.SetFloat(OpacityId,opacity);Graphics.DrawTexture(rect,Texture2D.whiteTexture,Paint);}
  public void Dispose(){UnityEngine.Object.Destroy(Paint);}
 }
}

using UnityEngine;
namespace MazeBiters.NativeStudy {
 public sealed partial class NativeMenuRenderer {
  Material frameStars;
  NativeFrame MenuFrame=>new NativeFrame((float)Target.width/Target.height);
  void EnsureDisplay(){if(!NativeDisplay.Stable)return;var size=NativeDisplay.Frame.Pixels(Manifest.quality);if(Target.width==size.x&&Target.height==size.y)return;
   camera.targetTexture=null;if(RenderTexture.active==Target)RenderTexture.active=null;Target.Release();UnityEngine.Object.Destroy(Target);
   Target=new RenderTexture(size.x,size.y,0,RenderTextureFormat.ARGB32){name="Responsive original menu",filterMode=FilterMode.Bilinear};Target.Create();camera.targetTexture=Target;camera.aspect=(float)size.x/size.y;camera.orthographicSize=MenuFrame.Height*768/432/2;
  }
  public Vector2 ToLogical(Vector3 mouse,Rect viewport,int screenHeight){var f=MenuFrame;var p=f.ToOriginal(f.Logical(mouse,viewport,screenHeight));return new Vector2(p.x*1024/576,p.y*768/432);}
  void DrawSurround(){var f=MenuFrame;var r=f.Original;if(r.x<.01f&&r.y<.01f)return;if(!frameStars)frameStars=new Material(Shader.Find("MazeBiters/FrameStars"));
   Panel(new Rect(0,0,r.x,f.Height));Panel(new Rect(r.xMax,0,f.Width-r.xMax,f.Height));
   Panel(new Rect(r.x,0,r.width,r.y));Panel(new Rect(r.x,r.yMax,r.width,f.Height-r.yMax));
  }
  void Panel(Rect p){if(p.width<.01f||p.height<.01f)return;var f=MenuFrame;float scale=768f/432;properties.Clear();properties.SetVector("_Rect",new Vector4(p.x,p.y,p.width,p.height));draw.DrawMesh(quad,Matrix4x4.TRS(new Vector3((p.x-f.Original.x)*scale,-(p.y-f.Original.y)*scale,0),Quaternion.identity,new Vector3(p.width*scale,p.height*scale,1)),frameStars,0,0,properties);}
 }
}


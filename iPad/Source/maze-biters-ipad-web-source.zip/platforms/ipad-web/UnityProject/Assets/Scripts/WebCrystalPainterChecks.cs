using System;
using System.IO;
using UnityEngine;
namespace MazeBiters.NativeStudy {
 [Serializable]public sealed class WebCrystalMaterialCase {
  public bool passed;public string theme,quality,error;
  public int setupSlices,faceSamples,rimSamples,gapSamples;
  public CrystalOuterMaterialAudit material;public CrystalStructureAudit structure;public CrystalCoreStressResult geometry;
 }
 public sealed partial class NativeMazeArtwork {
  public static WebWallLightRecordAudit ValidateWebWallLightRecords()=>WebWallLightRecords.ValidateEncoding();
  public static WebCrystalMaterialCase ValidateWebCrystalMaterial(SessionLevel source,string quality){
   var result=new WebCrystalMaterialCase{theme=source.theme,quality=quality};
   var art=new NativeMazeArtwork(source,Path.Combine(WebFiles.Root,"Reference/maze-brushes"));
   try{
    art.IsGlass=true;art.GlassQuality=quality;art.glassSize=quality=="4k"?160:80;art.glassWidth=36*art.glassSize;art.glassHeight=25*art.glassSize;art.Topology();
    string prefix=Path.Combine(WebFiles.Root,"Reference/glass-brushes",source.theme,quality);int count=16*art.glassSize*art.glassSize;
    var wall=GlassRead(Path.Combine(prefix,"wall.rgba.gz"),count*4);var light=GlassFloats(Path.Combine(prefix,"emission.f32.gz"),count*3);
    foreach(var step in art.WebPrepareCrystalMaterial(wall,light))result.setupSlices++;
    result.material=art.OuterCrystalMaterial;result.structure=art.CoreStructureAudit;result.geometry=art.InspectPreparedCrystalGeometry(wall);
    foreach(var territory in art.coreStructure.territories)foreach(var cell in territory.shape.cells){
     int left=(int)((cell.x+.5)*art.glassSize),top=(int)((cell.y+.5)*art.glassSize);
     for(int y=0;y<art.glassSize;y+=Math.Max(1,art.glassSize/16))for(int x=0;x<art.glassSize;x+=Math.Max(1,art.glassSize/16)){
      int px=left+x,py=top+y,tile=art.masks[px/art.glassSize,py/art.glassSize];
      if(tile>=0&&wall[((py%art.glassSize)*16*art.glassSize+tile*art.glassSize+px%art.glassSize)*4+3]!=0)continue;
      var rgb=new Color32(0,0,0,153);var emission=new Color32(0,0,0,255);if(!art.CrystalPixel(px,py,ref rgb,ref emission))continue;
      if(rgb.a==Byte(CoreGlassBodyOpacity*255))result.faceSamples++;if(rgb.a==255)result.rimSamples++;
      if(rgb.r==0&&rgb.g==0&&rgb.b==0&&rgb.a==64){if(emission.r!=0||emission.g!=0||emission.b!=0||emission.a!=0)throw new Exception("Emissive Web core joint");result.gapSamples++;}
     }
    }
    var m=result.material;var s=result.structure;
    result.passed=CrystalCoresEnabled&&result.setupSlices>700&&m!=null&&m.theme==source.theme&&m.quality==quality&&m.brightChannelSamples==0&&m.sourceSamples>0&&m.maxEmissionSurface<=.6200001
     &&s.orthogonalGrid&&s.curveContours==4&&s.curveProfileSamples==516&&s.curveConvex&&s.curveFitMaxError<1.25&&s.curveTangentError<1e-8
     &&result.geometry.passed&&result.faceSamples>0&&result.rimSamples>0&&result.gapSamples>0;
    if(!result.passed)throw new Exception("Cooperative Web core material calibration failed");
   }catch(Exception error){result.error=error.ToString();result.passed=false;}
   finally{art.FinishCrystalTileProbe();art.ReleaseGemCoreMaterialStaging();art.coreStructure=null;}
   return result;
  }
  // Independent semantic witnesses supplement the complete RGBA/receiver hash.
  // These helpers are called by editor validation only, never ordinary startup.
  string WebCrystalWitness(){
   if(!CrystalCoresEnabled||!crystalCores||CoreGlassBodyOpacity!=.90)throw new Exception("Web cores are not enabled by default");
   var shape=CoreStructureAudit;var material=OuterCrystalMaterial;
   if(shape==null||material==null||shape.components<=0||shape.curveContours!=4||shape.curveProfileSamples!=516||shape.sourceJointSamples!=3||!shape.orthogonalGrid||!shape.curveConvex||shape.curveFitMaxError>=1.25||shape.curveTangentError>=1e-8||material.brightChannelSamples!=0)throw new Exception("Web core calibration is missing or invalid");
   int faces=0,rims=0,gaps=0;int step=Math.Max(1,glassSize/8);
   for(int y=0;y<glassHeight;y+=step)for(int x=0;x<glassWidth;x+=step){
    if(!IsCrystalSample((x+.5)*16/glassSize,(y+.5)*16/glassSize))continue;
    int at=(glassHeight-1-y)*glassWidth+x;var pixel=pixels[at];var emission=glassEmissionPixels[at];
    if(pixel.a==Byte(255*CoreGlassBodyOpacity))faces++;
    if(pixel.a==255)rims++;
    if(pixel.a==64&&pixel.r==0&&pixel.g==0&&pixel.b==0){gaps++;if(emission.r!=0||emission.g!=0||emission.b!=0||emission.a!=0)throw new Exception("Emissive Web core joint");}
   }
   int coarseFaces=faces,coarseRims=rims,coarseGaps=gaps,refined=0;
   // A regular20-texel grid can alias a narrow native4K polished lip. Refine
   // missing optical categories at actual adjacent texels, with the unchanged
   // authored-wall exclusion; do not reduce any witness requirement.
   bool Missing()=>faces<10||rims<10||gaps<1;
   for(int y=0;y<glassHeight&&Missing();y++)for(int x=0;x<glassWidth&&Missing();x++){
    if(!IsCrystalSample((x+.5)*16/glassSize,(y+.5)*16/glassSize))continue;refined++;
    int at=(glassHeight-1-y)*glassWidth+x;var pixel=pixels[at];var emission=glassEmissionPixels[at];
    if(pixel.a==Byte(255*CoreGlassBodyOpacity)&&faces<10)faces++;
    if(pixel.a==255&&rims<10)rims++;
    if(pixel.a==64&&pixel.r==0&&pixel.g==0&&pixel.b==0){if(gaps<1)gaps++;if(emission.r!=0||emission.g!=0||emission.b!=0||emission.a!=0)throw new Exception("Emissive refined Web core joint");}
   }
   string counts=" faces="+faces+" rims="+rims+" gaps="+gaps+" coarseFaces="+coarseFaces+" coarseRims="+coarseRims+" coarseGaps="+coarseGaps+" refinedTexels="+refined;
   Debug.Log("WEB_CRYSTAL_WITNESS "+GlassQuality+counts);
   if(Missing())throw new Exception("Web native-texel body/rim/joint witness is incomplete:"+counts);
   return "cores=default-on bodyOpacity=.90 curves="+shape.curveContours+" curveProfileSamples="+shape.curveProfileSamples+counts+" material="+UnityEngine.JsonUtility.ToJson(material)+" structure="+UnityEngine.JsonUtility.ToJson(shape);
  }
  void CheckWebCrystalReleased(){
   if(pixels.IsCreated||glassEmissionPixels.IsCreated||coreStructure!=null||gemBevelTopRgb!=null||gemBevelTopLight!=null||gemBevelLowerRgb!=null||gemBevelLowerLight!=null)throw new Exception("Cancelled Web crystal preparation retained staging");
  }
 }
}

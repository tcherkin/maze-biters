#if UNITY_EDITOR
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using UnityEngine;

namespace MazeBiters.NativeStudy {
 // A lone head is a local snack under the same threat and collision rules as
 // other incidental food. These checks exercise actual contact and score.
 public static class NativeCasualHeadValidation {
  static readonly Vector2Int Right=Vector2Int.right,Up=new Vector2Int(0,-1),Down=new Vector2Int(0,1);
  static readonly Vector2Int[] Directions={Vector2Int.right,Vector2Int.left,new Vector2Int(0,-1),new Vector2Int(0,1)};
  static string[] Grid(){var rows=new char[17][];for(int y=0;y<17;y++){rows[y]=new string('#',17).ToCharArray();for(int x=1;x<16;x++)if(y>0&&y<16)rows[y][x]='.';}return rows.Select(row=>new string(row)).ToArray();}
  static NativeGameplayWorld World(int tier,int mode=0){
   var w=new NativeGameplayWorld(Grid(),()=>.99){AiDifficulty=tier,Difficulty=NativeMazeGenerator.Difficulties[tier],Time=1000,LevelStarted=1000,Assist=false,SessionEnabled=true};w.SetMode(mode);
   for(int i=0;i<w.PlayerCount;i++){var actor=w.GetPlayer(i);actor.Cell=actor.From=actor.Previous=new Vector2Int(2+i,2);actor.Dir=actor.Next=Right;actor.Score=0;actor.Waiting=false;}
   var p=Ai(w);p.Cell=p.From=p.Previous=new Vector2Int(8,8);p.Dir=p.Next=Right;p.Score=200;p.ExactScore=200;w.Ally.BeginLevel();p.Ai.mealInitialized=true;p.Ai.mealActive=false;p.Ai.mealIntentUntil=10000;p.Ai.allowSplit=false;return w;
  }
  static NativePlayer Ai(NativeGameplayWorld w)=>w.GetPlayer(w.PlayerCount-1);
  static Vector2Int Perp(Vector2Int d)=>new Vector2Int(-d.y,d.x);
  static NativeGameplaySnake Snake(NativeGameplayWorld w,IEnumerable<Vector2Int> cells,Vector2Int dir){var body=cells.ToList();var s=new NativeGameplaySnake{Id=10+w.Snakes.Count,Cell=body[0],Dir=dir,Body=body,Temperament=.5};w.Snakes.Add(s);return s;}
  static NativeGameplaySnake Head(NativeGameplayWorld w,Vector2Int at,Vector2Int dir)=>Snake(w,new[]{at},dir);
  static void Plan(NativeCasualBiteReport r,NativeGameplayWorld w){w.Ally.Plan(Ai(w),w.Time);r.decisions++;}
  static void Advance(NativeGameplayWorld w){using(w.ForPlayer(Ai(w)))w.AdvancePlayer();}
  static bool NoLock(NativePlayer p)=>p.Ai.locked==null&&p.Ai.split==null&&p.Ai.queue.Count==0&&!p.Ai.mealActive;
  static void Check(NativeCasualBiteReport r,bool passed,string name,string detail=""){r.assertions++;if(!passed)r.failures++;r.checks.Add(new NativeDifficultyCheck{name=name,passed=passed,detail=detail});}
  static void Group(NativeCasualBiteReport r,string name,Action body){try{body();}catch(Exception e){Check(r,false,name+" completed",e.ToString());}}
  static void SafeApproaches(NativeCasualBiteReport r){
   foreach(int tier in new[]{0,1})foreach(int mode in new[]{0,3})foreach(var move in Directions)foreach(int approach in new[]{0,1,2}){
    var w=World(tier,mode);var p=Ai(w);p.Dir=p.Next=approach==2?Perp(move):move;var s=Head(w,p.Cell+move,approach==1?Perp(move):move);string label="tier="+tier+", mode="+mode+", move="+move+", approach="+approach;
    Plan(r,w);Check(r,p.Next==move&&p.Ai.thought=="casual-head-bite"&&NoLock(p),"A fresh safe adjacent lone head is accepted during roaming: "+label,"next="+p.Next+", thought="+p.Ai.thought);Advance(w);
    Check(r,!p.Dead&&!w.Snakes.Contains(s)&&Math.Abs(p.ExactScore-(200+125*w.Difficulty*w.ScoreSpeed))<1e-9&&NoLock(p),"Safe head contact uses original eating and score, without a new hunt: "+label);
   }
  }
  static void FacingHeads(NativeCasualBiteReport r){
   foreach(int tier in new[]{0,1})foreach(var move in Directions)foreach(int protection in new[]{0,1,2}){
    var w=World(tier);var p=Ai(w);p.Dir=p.Next=move;var s=Head(w,p.Cell+move,-move);if(protection==1)p.ShieldUntil=5000;if(protection==2)p.PowerUntil=5000;Plan(r,w);
    string label="tier="+tier+", move="+move+", protection="+protection;
    Check(r,protection!=2?p.Next!=move:p.Next==move&&p.Ai.thought=="casual-head-bite","Head-on eating requires genuine power, not defensive spawn protection: "+label);Advance(w);
    Check(r,!p.Dead&&(protection!=2?w.Snakes.Contains(s)&&p.Score==200:!w.Snakes.Contains(s)&&Math.Abs(p.ExactScore-(200+125*w.Difficulty*w.ScoreSpeed))<1e-9),"Head-on contact preserves protection while only genuine power awards a bite: "+label);
   }
  }
  static void HazardsAndIntent(NativeCasualBiteReport r){
   foreach(int tier in new[]{0,1}){
    string label="tier="+tier;
    {var w=World(tier);var p=Ai(w);Head(w,p.Cell+Right,Right);Snake(w,new[]{p.Cell+Right+Up,p.Cell+Right+Up*2},Down);Plan(r,w);Check(r,p.Next!=Right,"An unrelated predicted snake mouth overrides incidental head appetite: "+label);}
    {var w=World(tier);var p=Ai(w);Head(w,p.Cell+Right,Right);w.Hunters.Add(new NativeHunter{Id=100,Cell=p.Cell+Right+Up,Dir=Down});Plan(r,w);Check(r,p.Next!=Right,"An approaching hunter overrides incidental head appetite: "+label);}
    {var w=World(tier);var p=Ai(w);Head(w,p.Cell+Right,Right);w.SolidEggs.Add(p.Cell+Right);w.ObstacleRevision++;Plan(r,w);Check(r,p.Next!=Right,"A solid egg blocks an otherwise edible head cell: "+label);}
    foreach(bool power in new[]{false,true}){
     var w=World(tier);var p=Ai(w);Head(w,p.Cell+Right,Right);w.PlaceScorpion(p.Cell+Right,Right);if(power)p.PowerUntil=5000;Plan(r,w);Check(r,p.Next!=Right,"A scorpion sharing the head cell keeps the existing incidental-food exclusion: "+label+", power="+power);
     w=World(tier);p=Ai(w);Head(w,p.Cell+Right,Right);Snake(w,new[]{p.Cell+Right+Down,p.Cell+Right},Down);if(power)p.PowerUntil=5000;Plan(r,w);Check(r,p.Next!=Right,"Overlapping snakes remain excluded even when protected: "+label+", power="+power);
    }
    {var w=World(tier);var p=Ai(w);Head(w,p.Cell-Right,Vector2Int.left);Plan(r,w);Check(r,p.Next==Right&&p.Ai.thought=="casual-roam"&&NoLock(p),"A safe head behind the AI does not cause a food-seeking reversal: "+label);}
    {var empty=World(tier);var distant=World(tier);var p=Ai(distant);Head(distant,new Vector2Int(13,3),Up);Plan(r,empty);Plan(r,distant);Check(r,p.Next==Ai(empty).Next&&p.Ai.thought=="casual-roam"&&NoLock(p),"A distant lone head does not redirect a held stroll: "+label);}
    {var w=World(tier,3);var p=Ai(w);var human=w.GetPlayer(0);human.Cell=human.From=human.Previous=p.Cell+Right;human.Score=0;Plan(r,w);Advance(w);Check(r,!human.Dead&&p.Cell!=human.Cell&&p.Ai.directive==null,"More incidental snake food does not add aggression against an edible human: "+label);}
    {var w=World(tier,3);var p=Ai(w);Head(w,p.Cell+Right,Right);var human=w.GetPlayer(0);human.Cell=human.From=human.Previous=p.Cell+Up;human.Dir=human.Next=Down;human.Score=500;Plan(r,w);Check(r,p.Ai.directive?.type=="flee"&&p.Next!=Right,"A dangerous human interrupts head appetite under the original flee rule: "+label);}
    {var w=World(tier);var p=Ai(w);Snake(w,new[]{p.Cell+Right,p.Cell+Right+Down},Up);Plan(r,w);Check(r,p.Next!=Right,"The new rule does not turn a full snake's unsafe side head into a snack: "+label);}
   }
  }
  static void Scope(NativeCasualBiteReport r){
   foreach(int tier in new[]{2,3,4}){var w=World(tier);var p=Ai(w);Head(w,p.Cell+Right,Right);Plan(r,w);Check(r,p.Ai.thought!="casual-head-bite"&&p.Ai.casualSnake==null,"MEDIUM and higher retain their existing head policy: tier="+tier);}
   {var w=World(0);var p=Ai(w);w.UseLegacyAi=true;Head(w,p.Cell+Right,Right);Plan(r,w);Check(r,p.Ai.thought!="casual-head-bite","Legacy brain does not use incidental-head policy");}
   {var w=World(0);var p=Ai(w);w.Time=w.LevelStarted+300000;Head(w,p.Cell+Right,Right);Plan(r,w);Check(r,p.Ai.thought!="casual-head-bite"&&p.Ai.mealActive,"Time escalation still selects its maximum-skill policy");}
  }
  public static NativeCasualBiteReport Run(){var watch=Stopwatch.StartNew();var r=new NativeCasualBiteReport{scope="Editor-only genuine planner and contact regressions for safe incidental lone heads in PICNIC/EASY. Tests all orientations, shield/power and existing hazard exclusions; no rendered/device performance or human balance claim."};Group(r,"safe approaches",()=>SafeApproaches(r));Group(r,"facing heads",()=>FacingHeads(r));Group(r,"hazards and intent",()=>HazardsAndIntent(r));Group(r,"scope",()=>Scope(r));r.elapsedMs=watch.Elapsed.TotalMilliseconds;r.passed=r.failures==0;return r;}
 }
}
#endif

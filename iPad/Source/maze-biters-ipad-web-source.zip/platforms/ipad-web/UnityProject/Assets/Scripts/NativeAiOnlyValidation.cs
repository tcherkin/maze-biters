using System;using UnityEngine;
namespace MazeBiters.NativeStudy {
 public static class NativeAiOnlyValidation {
  public static int Run(){
   int count=0;void Check(bool value,string message){count++;if(!value)throw new Exception("AI ONLY: "+message);}
   var menu=new NativeMenuState();menu.SetFocus(5,100);Check(menu.Activate(100)=="SnakeSELECT&Appear@"&&menu.SelectedMode==0&&menu.Pending,"sixth button starts mode zero");Check(!menu.StartReady(999)&&menu.StartReady(1000),"original 900ms confirmation");
   var gen=new NativeMazeGenerator(34,1);var w=new NativeGameplayWorld(gen.Generate(1).geometry,()=>.5);w.SetMode(0);w.StartSession(gen.Generate);var p=w.Player;
   Check(w.PlayerCount==1&&w.HasAI&&!w.Multiplayer&&!w.Competitive&&w.LeaderId==0,"one noncompetitive AI, no leader aura");
   Check(p.Id==1&&p.IsAI&&p.Palette==2&&!p.Waiting&&p.Lives==3&&p.ShieldUntil>w.Time,"AI palette, starts automatically with original lives/shield");
   var next=p.Next;w.Press("D",Vector2Int.right);w.Navigate(p.Cell+Vector2Int.right);NativeGamepadInput.Sync(w,0,new NativePadState{Id=101,Right=true},true);NativeGamepadInput.Sync(w,1,new NativePadState{Id=102,Down=true},true);
   Check(p.Next==next&&p.Keys.Count==0&&!p.Pointer.HasValue&&!p.GamepadTilt.HasValue,"keyboard, mouse and both pads cannot drive AI");Check(w.PointerPlayer(p.Cell,0,0)==null,"no pointer-controlled human");
   w.Award(150);p.ShieldUntil=0;w.SessionDeath();Check(p.Dead&&p.Lives==2&&!w.GameOverPending,"death consumes one original life");
   w.Snakes.Clear();w.Hunters.Clear();w.Scorpion=null;w.Eggs.Clear();w.Time=p.RespawnAt;w.SessionTick();p=w.Player;
   Check(!p.Dead&&p.IsAI&&p.Palette==2&&!p.Waiting&&p.Score==150&&p.ShieldUntil>w.Time,"respawn retains AI and score, no human input wait");
   var preview=w.PreviewNextLevel(gen.Generate(2),()=>.5,w.Time+3488);Check(preview.Mode==0&&preview.Player.IsAI&&!preview.Player.Waiting&&preview.Player.Palette==2,"prepared next scene retains AI identity");
   w.CheckLevelComplete();Check(w.Transition,"AI can clear a level");w.Time+=NativeGameplayWorld.ClearDuration;w.SessionTick();
   Check(w.Level==2&&w.Mode==0&&w.Player.Score==650&&w.Player.IsAI&&!w.Player.Waiting,"level two, original bonus and automatic movement");
   w.Player.Lives=1;w.SessionDeath();Check(w.GameOverPending,"last AI life schedules GAME OVER");w.Time=w.Player.RespawnAt;w.SessionTick();Check(w.GameOver&&w.Player.Eliminated,"GAME OVER after the skull animation");
   w.SetMode(1);Check(!w.Player.IsAI&&w.Player.Palette==0&&w.Player.Waiting&&!w.HasAI,"return to SOLO restores human ownership");
   return count;
  }
 }
}

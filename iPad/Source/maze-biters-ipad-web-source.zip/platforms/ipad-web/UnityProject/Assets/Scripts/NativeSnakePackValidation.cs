using System;using System.IO;using System.IO.Compression;using UnityEngine;
namespace MazeBiters.NativeStudy {
 public static class NativeSnakePackValidation {
  public static int Run(){int count=0;string root=Path.Combine(WebFiles.Root,"Reference");
   foreach(var palette in NativeGameplayStudy.Colors)foreach(var treatment in new[]{"lit","emission"})foreach(var part in new[]{"mouth","solo","material"}){
    string name="neon-"+palette+"-"+part+"-"+treatment;var image=new Texture2D(2,2,TextureFormat.RGBA32,false,false);
    try{if(!image.LoadImage(File.ReadAllBytes(Path.Combine(root,name+".png"))))throw new InvalidDataException(name);
     var pixels=image.GetPixels32();using(var file=File.OpenRead(Path.Combine(root,name+".native.gz")))using(var zip=new GZipStream(file,CompressionMode.Decompress))using(var r=new BinaryReader(zip)){
      if(r.ReadInt32()!=image.width||r.ReadInt32()!=image.height)throw new InvalidDataException(name+" dimensions");
      foreach(var p in pixels){bool pm=part!="material";byte red=pm?(byte)Math.Round(p.r*p.a/255.0):p.r,green=pm?(byte)Math.Round(p.g*p.a/255.0):p.g,blue=pm?(byte)Math.Round(p.b*p.a/255.0):p.b;
       if(r.ReadByte()!=red||r.ReadByte()!=green||r.ReadByte()!=blue||r.ReadByte()!=p.a)throw new InvalidDataException(name+" pixel mismatch");
      }if(r.Read()!=-1)throw new InvalidDataException(name+" excess pixels");
     }count++;
    }finally{UnityEngine.Object.DestroyImmediate(image);}
   }return count;
  }
 }
}

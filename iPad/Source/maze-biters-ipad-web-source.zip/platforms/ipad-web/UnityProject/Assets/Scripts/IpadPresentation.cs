using System;
using UnityEngine;
using Screen = UnityEngine.Device.Screen;

namespace MazeBiters.NativeStudy {
 // This file belongs only to the independent iPad project. Artwork and game
 // rules stay in the copied PC coordinate system; only presentation changes.
 public static class IpadPresentation {
  static readonly string[] args=Environment.GetCommandLineArgs();
  public static bool Suppress;
  public static bool Enabled=>!Suppress&&(Application.isPlaying||!Application.isEditor)&&Array.IndexOf(args,"--pc-framing")<0;
  public static bool Probe=>Array.IndexOf(args,"--ipad-probe")>=0;
  public static bool DefaultMenu=>Application.isEditor||Array.IndexOf(args,"--report")<0&&Array.IndexOf(args,"--gameplay")<0;
  public static string DefaultQuality=>WebFiles.IsWeb?WebFiles.InitialQuality:(Enabled?"4k":"hd");
  // Desktop preview is a native-size render fitted into a resizable window.
  // Device Simulator and iPad use the actual (possibly windowed) device surface.
  public static Vector2Int NativePixels=>WebFiles.IsWeb?new Vector2Int(2752,2064):Application.isEditor||Application.platform==RuntimePlatform.IPhonePlayer
   ?new Vector2Int(Math.Max(1,Screen.width),Math.Max(1,Screen.height)):new Vector2Int(2752,2064);
  public static float Aspect=>(float)NativePixels.x/NativePixels.y;
  public static Vector2Int Pixels(string quality){var p=NativePixels;return quality=="4k"?p:new Vector2Int(Math.Max(1,p.x/2),Math.Max(1,p.y/2));}
  public static double CloseZoom(NativeFrame f)=>Math.Max(1,Math.Min(2.6,160.0*f.Height/(16*NativePixels.y)));
  public static Rect SafeRect(NativeFrame f){
   if(Application.isEditor||Application.platform==RuntimePlatform.IPhonePlayer){var r=Screen.safeArea;return new Rect(r.x/Screen.width*f.Width,(Screen.height-r.yMax)/Screen.height*f.Height,r.width/Screen.width*f.Width,r.height/Screen.height*f.Height);}
   // Optional conservative insets are test scenarios, not claimed iPad hardware measurements.
   float top=Arg("--ipad-safe-top"),bottom=Arg("--ipad-safe-bottom");
   return new Rect(0,top*f.Height/2064,f.Width,f.Height-(top+bottom)*f.Height/2064);
  }
  static float Arg(string key){int i=Array.IndexOf(args,key);return i>=0&&i+1<args.Length&&float.TryParse(args[i+1],out float n)?Math.Max(0,n):0;}
 }

 public struct IpadView {public double x,y,zoom,header;}
 public static class IpadFraming {
  const double EdgeSky=52; // Equal screen-space breathing room on all four edges.
  public static double Smooth(double t){t=Math.Max(0,Math.Min(1,t));return t*t*(3-2*t);}
  public static IpadView Calculate(NativeFrame f,double x,double y,double sourceZoom,double closeZoom,Rect safe){
   double t=Smooth((sourceZoom-1)/.5),reserve=(32+safe.yMin)*(1-t);
   double fit=Math.Min(f.Width/576.0,(f.Height-32-safe.yMin)/400.0);
   double z=fit+(sourceZoom-1)*(closeZoom-fit);
   double dy=reserve/(2*z),cx=x,cy=y-dy;
   double spanX=Math.Min(64/sourceZoom,288-288/sourceZoom),spanY=Math.Min(64/sourceZoom,200-200/sourceZoom);
   if(spanX>0){double left=Smooth(1-(x-288/sourceZoom)/spanX),right=Smooth(1-(576-288/sourceZoom-x)/spanX);cx+=(f.Width/2-288*z/sourceZoom-EdgeSky*t)/z*(left-right);}
   if(spanY>0){double top=Smooth(1-(y-200/sourceZoom)/spanY),bottom=Smooth(1-(400-200/sourceZoom-y)/spanY);cy+=(f.Height/2-200*z/sourceZoom-reserve/2-EdgeSky*t)/z*(top-bottom);}
   return new IpadView{x=cx,y=cy,zoom=z,header=reserve};
  }
  // Only the camera is constrained. No entity position, tick, input, or animation changes.
  public static IpadView KeepPlayers(NativeFrame f,IpadView v,Rect bounds,Rect safe,double radius=12){
   double top=Math.Max(safe.yMin,v.header),bottom=safe.yMax,left=safe.xMin,right=safe.xMax;
   v.zoom=Math.Min(v.zoom,Math.Min((right-left)/(bounds.width+2*radius),(bottom-top)/(bounds.height+2*radius)));
   double minX=bounds.xMax+radius-(right-f.Width/2)/v.zoom,maxX=bounds.xMin-radius+(f.Width/2-left)/v.zoom;
   double minY=bounds.yMax+radius-(bottom-f.Height/2)/v.zoom,maxY=bounds.yMin-radius+(f.Height/2-top)/v.zoom;
   v.x=Math.Max(minX,Math.Min(maxX,v.x));v.y=Math.Max(minY,Math.Min(maxY,v.y));return v;
  }
 }
}

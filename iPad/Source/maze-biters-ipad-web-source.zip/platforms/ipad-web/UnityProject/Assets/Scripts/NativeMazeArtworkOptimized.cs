using System;
using System.Collections.Generic;
using System.IO;
using System.IO.Compression;
using System.Linq;
using Unity.Collections;
using UnityEngine;

namespace MazeBiters.NativeStudy {
 public sealed partial class NativeMazeArtwork {
  public static readonly bool LegacyPreparation=Array.IndexOf(Environment.GetCommandLineArgs(),"--legacy-maze-preparation")>=0;
  readonly bool fast;readonly string brushRoot;Color32[] pendingLow;bool flipped;public PreparationProfile Profile{get;private set;}
  NativeArray<Color32> colorRow;
  Texture2D publishingTexture;int publishingStage,publishingOffset;double publishingMs;
  internal int PublishStage=>IsGlass?glassPublishStage:publishingStage;
  [Serializable] public sealed class PreparationProfile {
   public bool optimized;public double backdropMs,topologyMs,floorsMs,territoryMs,wallsMs,uploadMs,reliefMs,totalMs;public int collections;
  }
  public static PreparationProfile LastProfile {get;private set;}

  NativeArray<Color32> ReadPacked(string name,int count){
   var data=new NativeArray<Color32>(count,Allocator.Persistent,NativeArrayOptions.UninitializedMemory);
   try{
    var bytes=data.Reinterpret<byte>(4);var buffer=new byte[32768];int offset=0;
    using(var file=File.OpenRead(Path.Combine(brushRoot,name.Replace(".png",".rgba.gz"))))
    using(var input=new GZipStream(file,CompressionMode.Decompress)){
     while(offset<bytes.Length){int n=input.Read(buffer,0,Math.Min(buffer.Length,bytes.Length-offset));if(n==0)throw new EndOfStreamException(name);NativeArray<byte>.Copy(buffer,0,bytes,offset,n);offset+=n;}
     if(input.ReadByte()!=-1)throw new InvalidDataException("Oversized maze brush "+name);
    }
    return data;
   }catch{data.Dispose();throw;}
  }
  Color32[] ReadBrush(string name,int count){if(!fast)return Read(name);using(var data=ReadPacked(name,count))return data.ToArray();}
  void FlipForUpload(){if(flipped)return;
   for(int y=0;y<H/2;y++){int a=y*W,b=(H-1-y)*W;NativeArray<Color32>.Copy(pixels,a,colorRow,0,W);NativeArray<Color32>.Copy(pixels,b,pixels,a,W);NativeArray<Color32>.Copy(colorRow,0,pixels,b,W);}
   flipped=true;
  }
  Texture2D UploadFast(){FlipForUpload();
   long stamp=NativeStallTrace.Stamp();
   var texture=new Texture2D(W,H,TextureFormat.RGBA32,false,false){name="Generated original maze",filterMode=FilterMode.Bilinear,wrapMode=TextureWrapMode.Clamp};
   NativeStallTrace.Add("prep-maze-create",stamp);stamp=NativeStallTrace.Stamp();texture.SetPixelData(pixels,0);NativeStallTrace.Add("prep-maze-copy",stamp);stamp=NativeStallTrace.Stamp();texture.Apply(false,true);NativeStallTrace.Add("prep-maze-apply",stamp);return texture;
  }
  // Called only on the main thread, after the worker has completed CPU work.
  public void Publish(){if(IsGlass){while(!PublishGlassStep()){}return;}if(Maze)return;var clock=System.Diagnostics.Stopwatch.StartNew();try{Maze=UploadFast();long stamp=NativeStallTrace.Stamp();LowReceiver=Texture(pendingLow,576,400,"Generated original low wall relief");NativeStallTrace.Add("prep-maze-receiver",stamp);}finally{long stamp=NativeStallTrace.Stamp();if(pixels.IsCreated)pixels.Dispose();pendingLow=null;NativeStallTrace.Add("prep-maze-release",stamp);}double ms=clock.Elapsed.TotalMilliseconds;Profile.uploadMs+=ms;Profile.totalMs+=ms;LastProfile=Profile;}
  // Main-thread cooperative publication. Never exposes a partly copied image.
  // The worker has already flipped the exact RGBA bytes. Each copy is at most
  // 128 rows (1.41 MiB); no resampling, compression, mipmaps or extra GPU target.
  public bool PublishStep(){
   if(IsGlass)return PublishGlassStep();
   if(Maze)return true;if(!flipped||!pixels.IsCreated)throw new InvalidOperationException("Deferred maze pixels unavailable");
   long stamp=NativeStallTrace.Stamp();var watch=System.Diagnostics.Stopwatch.StartNew();
   try{
    if(publishingStage==0){publishingTexture=new Texture2D(W,H,TextureFormat.RGBA32,false,false){name="Generated original maze",filterMode=FilterMode.Bilinear,wrapMode=TextureWrapMode.Clamp};publishingStage++;NativeStallTrace.Add("prep-maze-create",stamp);return false;}
    if(publishingStage==1){int count=Math.Min(W*128,pixels.Length-publishingOffset);var destination=publishingTexture.GetRawTextureData<Color32>();NativeArray<Color32>.Copy(pixels,publishingOffset,destination,publishingOffset,count);publishingOffset+=count;if(publishingOffset==pixels.Length)publishingStage++;NativeStallTrace.Add("prep-maze-copy",stamp);return false;}
    if(publishingStage==2){publishingTexture.Apply(false,true);publishingStage++;NativeStallTrace.Add("prep-maze-apply",stamp);return false;}
    if(publishingStage==3){LowReceiver=Texture(pendingLow,576,400,"Generated original low wall relief");pendingLow=null;publishingStage++;NativeStallTrace.Add("prep-maze-receiver",stamp);return false;}
    pixels.Dispose();Maze=publishingTexture;publishingTexture=null;NativeStallTrace.Add("prep-maze-release",stamp);return true;
   }finally{publishingMs+=watch.Elapsed.TotalMilliseconds;if(Maze){Profile.uploadMs+=publishingMs;Profile.totalMs+=publishingMs;LastProfile=Profile;}}
  }
  // CPU-only disposal is also safe on an abandoned worker. Published textures
  // are owned by the scene, or explicitly discarded on the main thread.
  public void DisposeStaging(){if(pixels.IsCreated)pixels.Dispose();if(colorRow.IsCreated)colorRow.Dispose();DisposeGlassStaging();pendingLow=null;Relief=null;}
  public void Discard(){DisposeStaging();DiscardGlass();if(publishingTexture)UnityEngine.Object.Destroy(publishingTexture);publishingTexture=null;if(Maze)UnityEngine.Object.Destroy(Maze);if(LowReceiver)UnityEngine.Object.Destroy(LowReceiver);}
  void SetRow(Color32 color){for(int x=0;x<W;x++)colorRow[x]=color;}
  void PaintSpan(int y,double left,double right,double alpha,Color32 color){
   int lo=Math.Max(0,(int)Math.Floor(left)),hi=Math.Min(W,(int)Math.Ceiling(right));
   if(alpha==1){
    int start=Math.Max(lo,(int)Math.Ceiling(left)),end=Math.Min(hi,(int)Math.Floor(right));
    if(end>start)NativeArray<Color32>.Copy(colorRow,0,pixels,y*W+start,end-start);
    if(lo<start)Blend(y*W+lo,color,Math.Min(lo+1,right)-Math.Max(lo,left));
    if(end<hi&&end>=start)Blend(y*W+end,color,Math.Min(end+1,right)-Math.Max(end,left));
   }else for(int x=lo;x<hi;x++)Blend(y*W+x,color,Math.Max(0,Math.Min(x+1,right)-Math.Max(x,left))*alpha);
  }
  // Each group contains rows with EXACTLY the same clip/coverage intervals.
  // Fractional boundary rows stay separate. The original 64 bands and the
  // per-pixel blend order are unchanged; only redundant geometry is removed.
  void TerritoryFast(Component c){
   var clip=c.cells.Select(p=>new Box((p.x+.5)*T-15,(p.y+.5)*T-15,(p.x+1.5)*T+15,(p.y+1.5)*T+15)).ToArray();
   var edges=new List<Box>();foreach(var p in c.cells){double l=(p.x+.5)*T-15,t=(p.y+.5)*T-15,r=(p.x+1.5)*T+15,b=(p.y+1.5)*T+15;if(!Block(p.x,p.y-1))edges.Add(new Box(l,t,r,t));if(!Block(p.x+1,p.y))edges.Add(new Box(r,t,r,b));if(!Block(p.x,p.y+1))edges.Add(new Box(l,b,r,b));if(!Block(p.x-1,p.y))edges.Add(new Box(l,t,l,b));}
   foreach(var b in clip)Rect(b,Hsl(hue,48,1.1));
   double radius=Math.Max(8,(c.depth-.5)*16+3)*5;
   int minY=Math.Max(0,(int)clip.Min(b=>b.t)),maxY=Math.Min(H,(int)clip.Max(b=>b.b));
   var strokes=new Box[edges.Count];var boundaries=new List<int>();var spans=new List<(double l,double r,double a)>();
   var events=new List<(double x,double alpha,int change)>();var active=new SortedDictionary<double,int>();
   var clips=new List<(double l,double r)>();var merged=new List<(double l,double r)>();
   void Boundary(double y){boundaries.Add(Math.Max(minY,Math.Min(maxY,(int)Math.Floor(y))));boundaries.Add(Math.Max(minY,Math.Min(maxY,(int)Math.Ceiling(y))));}
   for(int step=0;step<64;step++){
    double t=step/63.0,r=radius*(.995+(.02-.995)*t);var color=Hsl(hue,58+10*t,2.2+12.8*t);SetRow(color);
    boundaries.Clear();boundaries.Add(minY);boundaries.Add(maxY);
    foreach(var b in clip){Boundary(b.t);Boundary(b.b);}
    for(int i=0;i<edges.Count;i++){var b=edges[i];strokes[i]=new Box(b.l-r,b.t-r,b.r+r,b.b+r);Boundary(b.t-r);Boundary(b.b+r);}
    boundaries.Sort();
    for(int row=0;row<boundaries.Count-1;row++){
     int y=boundaries[row],endY=boundaries[row+1];if(y==endY)continue;
     clips.Clear();merged.Clear();events.Clear();spans.Clear();active.Clear();
     foreach(var k in clip)if(y>=k.t&&y<k.b)clips.Add((k.l,k.r));
     clips.Sort((a,b)=>a.l.CompareTo(b.l));
     foreach(var k in clips){if(merged.Count>0&&k.l<=merged[merged.Count-1].r){var prior=merged[merged.Count-1];merged[merged.Count-1]=(prior.l,Math.Max(prior.r,k.r));}else merged.Add(k);}
     foreach(var b in strokes){double a=Math.Max(0,Math.Min(y+1,b.b)-Math.Max(y,b.t));if(a<=0)continue;foreach(var k in merged){double x=Math.Max(k.l,b.l),end=Math.Min(k.r,b.r);if(end>x){events.Add((x,a,1));events.Add((end,a,-1));}}}
     if(events.Count==0)continue;
     events.Sort((a,b)=>a.x.CompareTo(b.x));double previous=events[0].x;
     foreach(var e in events){if(e.x>previous&&active.Count>0){double a=active.Last().Key;if(spans.Count>0&&spans[spans.Count-1].a==a&&spans[spans.Count-1].r==previous){var s=spans[spans.Count-1];spans[spans.Count-1]=(s.l,e.x,a);}else spans.Add((previous,e.x,a));}active.TryGetValue(e.alpha,out int count);count+=e.change;if(count==0)active.Remove(e.alpha);else active[e.alpha]=count;previous=e.x;}
     foreach(var s in spans)for(int line=y;line<endY;line++)PaintSpan(line,s.l,s.r,s.a,color);
    }
   }
  }
  void FillReceivers(Color32[] raw,Color32[] low,Color32[] small){
   var detail=new byte[raw.Length];for(int i=0;i<raw.Length;i++)detail[i]=Receiver(raw[i]);
   var preview=new Color32[low.Length];for(int i=0;i<low.Length;i++){byte a=Receiver(low[i]);preview[i]=new Color32(a,a,a,a);}
   for(int y=0;y<25;y++)for(int x=0;x<36;x++){int mask=masks[x,y];if(mask<0)continue;for(int dy=0;dy<T;dy++)Buffer.BlockCopy(detail,dy*1280+mask*T,Relief,(H-1-y*T-dy)*W+x*T,T);for(int dy=0;dy<16;dy++)Array.Copy(preview,dy*256+mask*16,small,(y*16+dy)*576+x*16,16);}
  }
 }
}

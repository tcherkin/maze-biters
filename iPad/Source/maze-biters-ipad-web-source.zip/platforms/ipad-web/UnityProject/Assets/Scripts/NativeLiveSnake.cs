using System;
using System.Collections.Generic;
using System.Linq;
using UnityEngine;
namespace MazeBiters.NativeStudy {
 // Native translation of live-snake.js. Logical cells never double as
 // interpolated render vertices: bites retire material on independent clocks.
 public sealed class NativeLiveSnake {
  public sealed class Birth {public double at,duration=95,from,to;public bool solo,rear;}
  public sealed class Part {public double at,duration=95,amount;public bool solo;}
  public sealed class Trim {public double to,baseLength,baseSolo,end;public Birth birth;public List<Part> parts=new List<Part>();}
  public SnakeCurve Path,Motion;public double FromHead,ToHead,Started,Duration=218,PhysicalLength,FrontMaterial,MaterialSign=1,TransitionCompression,TransitionAt,TransitionEnd;public double? HeldAt;
  public int Count;public bool Backwards;public Vector2Int[] Body;public List<Vector2Int> Route;public Birth birth;public Trim trim;
  public double IntakeUntil,IntakeAt;public NativePlayer IntakePlayer;
  public static double Smooth(double x)=>AnimationClock.Ease(x);
  static double Mix(double a,double b,double p)=>SnakeCurve.Mix(a,b,p);
  static bool Same(RailPoint a,RailPoint b)=>SnakeCurve.Hypot(a.x-b.x,a.y-b.y)<1e-5&&SnakeCurve.Hypot(a.tx-b.tx,a.ty-b.ty)<1e-6;
  public NativeLiveSnake(NativeGameplaySnake s,double t){Initialize(s.Body.ToArray(),s.Dir,s.Reversing,t);}
  NativeLiveSnake(){}
  public bool Stationary(double t)=>HeldAt.HasValue||Motion==null&&Math.Abs(ToHead-FromHead)<1e-8||t>=Started+Duration;
  void Initialize(Vector2Int[] body,Vector2Int direction,bool reverse,double t){Body=body;Route=body.Reverse().ToList();var p=new SnakeRail(Route.ToArray(),direction);Path=p;FromHead=ToHead=p.CellDistances[p.CellDistances.Length-1]+SnakeMotion.Head/2;double tail=body.Length==1?ToHead-SnakeMotion.Head:p.CellDistances[0]-(36-SnakeMotion.Head/2);PhysicalLength=ToHead-tail;Count=body.Length;Backwards=reverse;FrontMaterial=Count*36;Started=t;}
  public SnakePose Evaluate(double t){
   double phase=Motion==null&&Math.Abs(ToHead-FromHead)<1e-8?1:AnimationClock.Clamp(((HeldAt??t)-Started)/Math.Max(1,Duration));var pulse=SnakeMotion.Pulse(phase,Count*36,Backwards);Motion?.Update(pulse.progress);
   double length=Motion?.Total??PhysicalLength,solo=Count==1?1:0;
   if(birth!=null){double p=Smooth((t-birth.at)/birth.duration);length=Mix(birth.from,birth.to,p);solo=birth.solo?p:0;}
   if(trim!=null){double p=trim.birth!=null?Smooth((t-trim.birth.at)/trim.birth.duration):0;length=trim.birth!=null?Mix(trim.birth.from,trim.birth.to,p):trim.baseLength;solo=trim.birth!=null&&trim.birth.solo?p:trim.baseSolo;foreach(var part in trim.parts){double f=Smooth((t-part.at)/part.duration);length-=part.amount*f;if(part.solo)solo=Mix(solo,1,f);}}
   double remaining=TransitionCompression!=0?1-Smooth((t-TransitionAt)/Math.Max(1,TransitionEnd-TransitionAt)):1,offset=trim!=null||birth!=null?TransitionCompression*(1-pulse.progress)*remaining:0;length-=offset;
   if(Count>1&&trim==null&&birth==null)length=Math.Max(length,SnakeMotion.Head+SnakeMotion.Tail);
   pulse=SnakeMotion.Pulse(phase,length,Backwards);Motion?.SetCompression(pulse.compression);
   var result=new SnakePose{rail=Motion??Path,head=Motion?.Total??Mix(FromHead,ToHead,pulse.progress),length=length,solo=solo>=.999999,soloAmount=solo,compression=pulse.compression,phase=pulse.phase,frontMaterial=FrontMaterial,materialSign=MaterialSign,transitionOffset=offset,birthProgress=birth==null?1:Smooth((t-birth.at)/birth.duration),rearBirth=birth!=null&&birth.rear};
   if(IntakePlayer!=null&&!IntakePlayer.Dead&&t>=IntakeAt&&t<=IntakeUntil&&IntakePlayer.Dir.x!=0){var player=IntakePlayer.Visual(t);var tip=result.rail.Sample(result.Tip);double rotation=IntakePlayer.Tilt*Math.PI/180,co=Math.Cos(rotation),si=Math.Sin(rotation),cx=(player.x+.5)*36,cy=(player.y+.5)*36,x=(tip.x-cx)*co+(tip.y-cy)*si,y=-(tip.x-cx)*si+(tip.y-cy)*co,heading=rotation+(IntakePlayer.Dir.x<0?Math.PI:0),alignment=Math.Cos(tip.angle-heading),forward=IntakePlayer.Dir.x<0?-x:x,amount=Smooth((36*NativeMouthIntake.SideReach+1.5-forward)/6)*Smooth((forward+36*.15)/(36*.25))*Smooth((alignment-.92)/.08)*(1-Smooth(Math.Abs(y)/(36*.3))),span=Math.Min(SnakeMotion.Tail*(1-solo)*result.birthProgress,Math.Max(0,result.Rear-result.Tip));double drop=Math.Max(0,Math.Min(36*.16-y,Math.Min(3.2,span*.17)))*amount;result.bendDx=-si*drop;result.bendDy=co*drop;result.bendSpan=span;}
   return result;
  }
  public NativeLiveSnake Capture(){var c=(NativeLiveSnake)MemberwiseClone();c.Motion=Motion?.Clone();c.Body=(Vector2Int[])Body.Clone();c.Route=new List<Vector2Int>(Route);if(trim!=null)c.trim=new Trim{to=trim.to,baseLength=trim.baseLength,baseSolo=trim.baseSolo,end=trim.end,birth=trim.birth,parts=new List<Part>(trim.parts)};return c;}
  public void Record(NativeGameplaySnake s,Vector2Int[] old,double t,double duration){
   var previous=Evaluate(t);var priorRear=previous.rail.Sample(previous.Rear);if(Body.SequenceEqual(s.Body))return;
   var oldBody=old??Body;var cells=oldBody.Reverse().ToList();double pending=Math.Max(0,previous.length-(trim?.to??birth?.to??previous.length));int guard=3+(int)Math.Ceiling(pending/36);
   for(int start=Route.Count-cells.Count;start>=0;start--){bool match=true;for(int i=0;i<cells.Count;i++)if(cells[i]!=Route[start+i]){match=false;break;}if(!match)continue;if(s.Reversing)cells.AddRange(Route.Skip(start+cells.Count).Take(3));else cells.InsertRange(0,Route.Skip(Math.Max(0,start-guard)).Take(Math.Min(guard,start)));break;}
   if(s.Reversing){if(s.Tail!=cells[0])cells.Insert(0,s.Tail);}else if(s.Head!=cells[cells.Count-1])cells.Add(s.Head);
   if(!s.Reversing&&cells.Count>s.Body.Count+guard)cells.RemoveRange(0,cells.Count-s.Body.Count-guard);if(s.Reversing&&cells.Count>s.Body.Count+4)cells.RemoveRange(s.Body.Count+4,cells.Count-s.Body.Count-4);
   var path=new SnakeRail(cells.ToArray(),s.Dir);int bodyStart=s.Reversing?0:cells.Count-s.Body.Count;double targetHead=path.CellDistances[bodyStart+s.Body.Count-1]+SnakeMotion.Head/2,targetTail=s.Body.Count==1?targetHead-SnakeMotion.Head:path.CellDistances[bodyStart]-(36-SnakeMotion.Head/2);
   if(s.Body.Count==1){double angle=Math.Atan2(s.Dir.y,s.Dir.x);var target=new RailPoint{x=(s.Head.x+.5)*36-Math.Cos(angle)*SnakeMotion.Head/2,y=(s.Head.y+.5)*36-Math.Sin(angle)*SnakeMotion.Head/2,angle=angle};RailPoint? via=Count==1&&trim==null&&birth==null?(RailPoint?)new RailPoint{x=(oldBody[0].x+.5)*36,y=(oldBody[0].y+.5)*36}:null;Motion=new SnakeRigid(priorRear,target,SnakeMotion.Head,via);if((trim!=null||birth!=null)&&previous.Tip<previous.Rear-1e-7)Motion=new SnakeRetiringTail(Motion,previous.rail,previous.Rear);}
   else{
    SnakeCurve rail=null;int oldHeadIndex=s.Reversing?s.Body.Count:cells.Count-2;double preferred=path.CellDistances[Math.Min(oldHeadIndex,path.CellDistances.Length-1)]-SnakeMotion.Head/2,rear=path.Project(priorRear.x,priorRear.y,preferred);
    if(s.Reversing){double prefix=Motion?.Kind=="joined-prefix"&&Motion.Progress<1?Motion.PrefixLength:0,anchorDistance=Math.Max(previous.head,prefix)+36;var anchor=previous.rail.Sample(anchorDistance);double projected=path.Project(anchor.x,anchor.y,preferred+SnakeMotion.Head+anchorDistance-previous.head);if(Same(anchor,path.Sample(projected)))rear=projected-(anchorDistance-previous.Rear);}
    double fromHead=rear+SnakeMotion.Head,visibleLength=previous.head-previous.Tip,fromTail=fromHead-visibleLength;bool continuous=true;
    for(int i=0;i<=24&&continuous;i++){double offset=(previous.Rear-previous.Tip)*i/24;continuous=Same(previous.rail.Sample(previous.Tip+offset),path.Sample(fromTail+offset));}
    if(continuous&&(s.Reversing?targetHead<=fromHead+1e-7:targetHead>=fromHead-1e-7))rail=new SnakeRouteWindow(path,fromHead,visibleLength,targetHead,targetHead-targetTail);
    else if(s.Reversing&&oldBody.Length>1){var tail=oldBody[oldBody.Length-1];var next=oldBody[oldBody.Length-2];double jx=(tail.x+.5)*36+(next.x-tail.x)*18,jy=(tail.y+.5)*36+(next.y-tail.y)*18,join=path.Project(jx,jy,path.CellDistances[1]+18),fromJoin=previous.Rear+join-rear;
     if(Motion?.Kind=="joined-prefix"&&Motion.Progress<1&&fromJoin<Motion.PrefixLength){join+=Motion.PrefixLength-fromJoin;fromJoin=Motion.PrefixLength;}
     bool matches=fromJoin>previous.Tip&&join>targetTail&&!double.IsNaN(fromJoin);for(int i=0;i<=24&&matches;i++){double offset=Math.Max(0,previous.Rear-fromJoin)*i/24;matches=Same(previous.rail.Sample(fromJoin+offset),path.Sample(join+offset));}
     if(matches)rail=new SnakeJoinedPrefix(previous.rail,previous.Tip,fromJoin,previous.head,path,targetTail,join,targetHead,s.Body.Count==2?SnakeMotion.Tail:0);
    }
    Motion=rail??new SnakeMaterialCurve(previous.rail,previous.Tip,previous.head,path,targetTail,targetHead);
   }
   Path=path;FromHead=0;ToHead=targetHead;TransitionCompression=trim!=null||birth!=null?previous.compression+previous.transitionOffset:0;TransitionAt=t;TransitionEnd=Math.Max(trim?.end??double.NegativeInfinity,birth!=null?birth.at+birth.duration:double.NegativeInfinity);Started=t;Duration=Math.Max(1,duration);Backwards=s.Reversing;HeldAt=null;Count=s.Body.Count;Body=s.Body.ToArray();Route=cells;
   if(trim!=null&&t>=trim.end)trim=null;if(birth!=null&&t>=birth.at+birth.duration)birth=null;
  }
  public void BiteTail(NativeGameplaySnake s,int oldCount,double t,NativePlayer player,bool finishWithStep=false){
   var current=Evaluate(t);double surviving=trim?.to??birth?.to??current.length,at=t+Math.Min(33.25,Math.Max(0,player.MoveDuration*.35)),duration=finishWithStep?Math.Min(95,Math.Max(1,player.MoveDuration-(at-t))):95;Count=s.Body.Count;Body=s.Body.ToArray();double ratio=Math.Max(0,surviving-SnakeMotion.Head)/Math.Max(.01,oldCount*36-SnakeMotion.Head),to=Count==1?SnakeMotion.Head:Math.Max(SnakeMotion.Head,surviving-(oldCount-Count)*36*ratio);bool continuing=trim!=null&&t<trim.end;
   var next=new Trim{to=to,baseLength=continuing?trim.baseLength:current.length+current.transitionOffset,baseSolo=continuing?trim.baseSolo:current.soloAmount,birth=continuing?trim.birth:trim==null?birth:null,end=Math.Max(at+duration,continuing?trim.end:0),parts=continuing?new List<Part>(trim.parts):new List<Part>()};next.parts.Add(new Part{at=at,duration=duration,amount=surviving-to,solo=Count==1});trim=next;IntakeAt=t;IntakeUntil=at+duration+90;IntakePlayer=player;
  }
  public NativeLiveSnake[] Split(NativeGameplaySnake[] children,int index,int oldCount,double t,NativePlayer player){
   var before=Evaluate(t);var path=before.rail.Snapshot();double nose=(index+.5)*36,nominal=Math.Max(.01,before.length-SnakeMotion.Head-SnakeMotion.Tail),rate=(nominal-before.compression)/nominal,cut=nose<=SnakeMotion.Head?before.head-nose:nose>=before.length-SnakeMotion.Tail?before.Tip+before.length-nose:before.Rear-(nose-SnakeMotion.Head)*rate,at=t+Math.Min(33.25,Math.Max(0,player.MoveDuration*.35));var result=new List<NativeLiveSnake>();int child=0;
   for(int role=0;role<2;role++){int count=role==0?index:oldCount-index-1;if(count==0)continue;bool reverse=role==1;var s=children[child++];double head=reverse?path.Total-before.Tip:before.head;var state=new NativeLiveSnake{Path=reverse?new SnakeReverse(path):path,FromHead=head,ToHead=head,Started=t,Count=count,Body=s.Body.ToArray(),Route=reverse?Route.AsEnumerable().Reverse().ToList():new List<Vector2Int>(Route),FrontMaterial=reverse?FrontMaterial-MaterialSign*before.length:FrontMaterial,MaterialSign=reverse?-MaterialSign:MaterialSign,birth=new Birth{at=at,rear=reverse,from=reverse?cut-before.Tip:before.head-cut,to=count==1?SnakeMotion.Head:count*36,solo=count==1}};result.Add(state);}return result.ToArray();
  }
 }
}

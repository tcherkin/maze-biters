using System;using UnityEngine;using UnityEngine.Rendering;
namespace MazeBiters.NativeStudy {
 public sealed class NativeEyeGlints:IDisposable {
  readonly Texture2D texture;readonly Material paint;readonly MaterialPropertyBlock block=new MaterialPropertyBlock();readonly Mesh iris,fringe;readonly NativeAggressionGlint[] clocks=new NativeAggressionGlint[5];readonly System.Collections.Generic.Dictionary<int,NativeAggressionGlint> live=new System.Collections.Generic.Dictionary<int,NativeAggressionGlint>();double last=double.NegativeInfinity;
  public const long TextureBytes=64*80*4;
  internal Action PreserveClocks(){
   var saved=(NativeAggressionGlint[])clocks.Clone();
   var savedLive=new System.Collections.Generic.Dictionary<int,NativeAggressionGlint>(live);double savedLast=last;
   for(int i=0;i<clocks.Length;i++)clocks[i]=clocks[i]?.Copy();
   foreach(var pair in savedLive)live[pair.Key]=pair.Value.Copy();
   return ()=>{Array.Copy(saved,clocks,clocks.Length);live.Clear();foreach(var pair in savedLive)live.Add(pair.Key,pair.Value);last=savedLast;};
  }
  public NativeEyeGlints(){texture=NativeLightField.Load("neon-eyes.png",true);paint=new Material(Shader.Find("MazeBiters/NeonScreen")){mainTexture=texture};iris=Quad(49,17,20,13,0,0);fringe=Quad(39,7,40,33,0,32);}
  static Mesh Quad(float x,float y,float w,float h,float sx,float sy){var m=new Mesh();m.vertices=new[]{new Vector3(x*2,70-y*2),new Vector3((x+w)*2,70-y*2),new Vector3((x+w)*2,70-(y+h)*2),new Vector3(x*2,70-(y+h)*2)};m.uv=new[]{new Vector2(sx/64,1-sy/80),new Vector2((sx+w)/64,1-sy/80),new Vector2((sx+w)/64,1-(sy+h)/80),new Vector2(sx/64,1-(sy+h)/80)};m.triangles=new[]{0,1,2,0,2,3};return m;}
  public void Draw(CommandBuffer command,SnakePose[] poses,double time,int[] identities=null,double[] aggression=null){if(double.IsNegativeInfinity(last)||time<last){for(int i=0;i<5;i++){clocks[i]=new NativeAggressionGlint(unchecked((uint)(i+1)*0x9e3779b9u)^0x31e731e7u);clocks[i].SetAggression(new[]{0,.2,.45,.7,1}[i],time);}live.Clear();}last=time;
   for(int i=0;i<poses.Length;i++){var clock=identities==null?clocks[i]:null;if(identities!=null){if(!live.TryGetValue(identities[i],out clock))live[identities[i]]=clock=new NativeAggressionGlint(unchecked((uint)identities[i]*0x9e3779b9u)^0x31e731e7u);clock.SetAggression(aggression[i],time);}double level=clock.Sample(time);if(level<=0||poses[i].consumed)continue;var p=poses[i].rigidRear??poses[i].rail.Sample(poses[i].Rear);float scale=(float)(SnakeMotion.Diameter/76*16/36);var transform=Matrix4x4.TRS(new Vector3((float)(p.x*16/36),(float)(-p.y*16/36),0),Quaternion.Euler(0,0,(float)(-p.angle*180/Math.PI)),new Vector3(scale,scale,1));block.SetFloat("_Amount",(float)(level*.62));command.DrawMesh(fringe,transform,paint,0,0,block);block.SetFloat("_Amount",(float)(level*.98));command.DrawMesh(iris,transform,paint,0,0,block);}
  }
  public void Dispose(){foreach(var o in new UnityEngine.Object[]{texture,paint,iris,fringe})UnityEngine.Object.Destroy(o);}
 }
}

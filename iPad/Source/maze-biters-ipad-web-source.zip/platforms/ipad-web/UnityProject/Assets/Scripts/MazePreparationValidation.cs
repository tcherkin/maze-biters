using System;using System.Collections;using System.Collections.Generic;using System.IO;using UnityEngine;
namespace MazeBiters.NativeStudy {
 public sealed class MazePreparationValidation:MonoBehaviour {
  [Serializable] sealed class Case {public long seed;public int d,n;}
  [Serializable] sealed class Cases {public Case[] cases;}
  [Serializable] sealed class Check {public long seed;public int level,difficulty,pixelDifferences,lowDifferences,reliefDifferences;public NativeMazeArtwork.PreparationProfile before,after;}
  [Serializable] sealed class Report {public bool passed;public Check[] checks;public string note;}
  Texture2D Read(Texture texture){var rt=RenderTexture.GetTemporary(texture.width,texture.height,0,RenderTextureFormat.ARGB32);var prior=RenderTexture.active;try{Graphics.Blit(texture,rt);RenderTexture.active=rt;var read=new Texture2D(texture.width,texture.height,TextureFormat.RGBA32,false);read.ReadPixels(new Rect(0,0,texture.width,texture.height),0,0);read.Apply();return read;}finally{RenderTexture.active=prior;RenderTexture.ReleaseTemporary(rt);}}
  int Differences(Texture2D a,Texture2D b){var x=a.GetRawTextureData<byte>();var y=b.GetRawTextureData<byte>();if(x.Length!=y.Length)throw new InvalidDataException("Texture sizes differ");int n=0;for(int i=0;i<x.Length;i++)if(x[i]!=y[i])n++;return n;}
  Check Compare(Case c,string folder,int index){
   var level=new NativeMazeGenerator((uint)c.seed,NativeMazeGenerator.Difficulties[c.d]).Generate(c.n);
   var before=new NativeMazeArtwork(level,c.n,false);var oldProfile=NativeMazeArtwork.LastProfile;
   string source=Path.Combine(WebFiles.Root,"Reference/maze-brushes");var after=WebWorkQueue.Run(()=>new NativeMazeArtwork(level,c.n,true,true,source)).GetAwaiter().GetResult();after.Publish();var newProfile=NativeMazeArtwork.LastProfile;
   var a=Read(before.Maze);var b=Read(after.Maze);var lowA=Read(before.LowReceiver);var lowB=Read(after.LowReceiver);
   var check=new Check{seed=c.seed,level=c.n,difficulty=c.d,before=oldProfile,after=newProfile,pixelDifferences=Differences(a,b),lowDifferences=Differences(lowA,lowB)};
   for(int i=0;i<before.Relief.Length;i++)if(before.Relief[i]!=after.Relief[i])check.reliefDifferences++;
   if(index<6){File.WriteAllBytes(Path.Combine(folder,"before-"+index+".png"),a.EncodeToPNG());File.WriteAllBytes(Path.Combine(folder,"after-"+index+".png"),b.EncodeToPNG());}
   foreach(var t in new[]{a,b,lowA,lowB,before.Maze,after.Maze,before.LowReceiver,after.LowReceiver})Destroy(t);
   return check;
  }
  IEnumerator Start(){
   var args=Environment.GetCommandLineArgs();int at=Array.IndexOf(args,"--report");string folder=args[at+1];Directory.CreateDirectory(folder);
   var cases=new List<Case>(JsonUtility.FromJson<Cases>(File.ReadAllText(Path.Combine(WebFiles.Root,"Reference/generator-visual-cases.json"))).cases);
   cases.AddRange(new[]{new Case{seed=0,d=4,n=150},new Case{seed=7,d=3,n=100},new Case{seed=987,d=2,n=30},new Case{seed=4294967295,d=0,n=1},new Case{seed=1,d=1,n=50},new Case{seed=34,d=4,n=150}});
   var checks=new List<Check>();bool passed=true;
   for(int i=0;i<cases.Count;i++){
    Check check=null;try{check=Compare(cases[i],folder,i);}catch(Exception e){Debug.LogException(e);Application.Quit(2);yield break;}
    checks.Add(check);passed&=check.pixelDifferences==0&&check.lowDifferences==0&&check.reliefDifferences==0;
    Debug.Log("MAZE_PREPARATION_PARITY "+JsonUtility.ToJson(check));yield return null;yield return null;GC.Collect();
   }
   File.WriteAllText(Path.Combine(folder,"art-parity.json"),JsonUtility.ToJson(new Report{passed=passed,checks=checks.ToArray(),note="Exact all-channel GPU readback equality, including alpha, between prior generated painter and optimized painter. High and low wall relief exact. Twelve levels/seeds across all five difficulties; generation algorithm unchanged. Timings exclude GPU readback/PNG capture and are only a stage profile, not standalone gameplay benchmarks."},true));
   Application.Quit(passed?0:2);
  }
 }
}

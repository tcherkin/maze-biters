using System;using System.IO;using System.Collections;using System.Threading.Tasks;using UnityEngine;
namespace MazeBiters.NativeStudy {
 public sealed partial class NativeMenu {
  NativeHighScores scores;NativeRecordState records;NativeRecord finishedRecord;bool recordTesting,recordReadback,recordScreenPresented;
  void InitializeRecords(string[] args){recordTesting=Array.IndexOf(args,"--records-smoke")>=0;recordReadback=Array.IndexOf(args,"--records-readback")>=0;testing|=recordTesting;
   string file=Path.Combine(Application.persistentDataPath,"high-scores-v1.json");if(testing)file=Path.Combine(Path.GetDirectoryName(report),"isolated-"+State.Quality+"-scores.json");for(int i=0;i<args.Length;i++)if(args[i]=="--records-file")file=args[++i];scores=new NativeHighScores(file);
  }
  void OpenBoard(string id="",string status=""){padNavigation.Reset();recordScreenPresented=false;records=new NativeRecordState{Entered=Now,Highlight=id,Status=string.IsNullOrEmpty(status)?scores.Warning:status};int index=Array.FindIndex(scores.Entries,r=>r.id==id);records.Page=index<0?0:index/10;if(renderer.RecordsReady){renderer.RenderRecords(records,scores.Entries,Now);recordScreenPresented=true;}}
  void OpenEntry(NativeRecord candidate){padNavigation.Reset();recordScreenPresented=false;records=new NativeRecordState{Entry=true,Candidate=candidate,Entered=Now};Audio.SetMenuTrack(Now,true);if(renderer.RecordsReady){renderer.RenderRecords(records,scores.Entries,Now);recordScreenPresented=true;}}
  void CloseRecords(){if(records==null||records.Submitting)return;records=null;State.Pending=false;State.ComingUntil=-1;State.Active=State.Pulsing=null;State.Shots.Clear();renderer.SetLeaderIfChanged(scores.Entries.Length>0?scores.Entries[0]:null);Audio.SetMenuTrack(Now);TickSound("SnakeSELECT&Appear@");}
  void RecordAction(){if(records==null||records.Submitting)return;if(!records.Entry){if(records.Action==1)CloseRecords();else if(records.ChangePage(records.Action==0?-1:1,scores.Entries.Length))TickSound("Tick");return;}
   if(records.Row<5){if(records.Append(NativeRecordState.Keys[records.Row*8+records.Column].ToString(),Now))TickSound("Tick");}
   else if(records.Column==0){if(records.Delete(Now))TickSound("Tick");}else if(records.Column==1)SaveRecord();else CloseRecords();
  }
  void SaveRecord(){if(records==null||!records.Entry||records.Submitting)return;if(records.Draft.Length==0){records.Status="ENTER A NAME OR CHOOSE SKIP";records.Revision++;TickSound("Tick");return;}StartCoroutine(SaveRecordAsync(records));}
  IEnumerator SaveRecordAsync(NativeRecordState entry){entry.Submitting=true;entry.Status="SAVING";entry.Revision++;TickSound("SnakeSELECT&Appear@");
   NativeRecordFile prepared=null;string json=null,error=null,submittedId="";try{prepared=scores.Prepare(entry.Candidate,entry.Draft);foreach(var r in prepared.entries)if(!Array.Exists(scores.Entries,p=>p.id==r.id)){submittedId=r.id;break;}json=JsonUtility.ToJson(prepared,true);}catch(Exception e){error=e.Message;}
   if(error==null){
#if UNITY_WEBGL && !UNITY_EDITOR
    yield return null; // Present SAVING, then commit on the browser main thread.
    try{prepared=scores.PersistWebMerged(json);}catch(Exception){error="WRITE_FAILED";}
#else
    var task=WebWorkQueue.Run(()=>scores.Persist(json));while(!task.IsCompleted)yield return null;if(task.IsFaulted){_ = task.Exception;error="WRITE_FAILED";}
#endif
   }
   entry.Submitting=false;
   if(error!=null){entry.Status=error=="EMPTY_NAME"?"ENTER A NAME OR CHOOSE SKIP":error=="NOT_QUALIFIED"?"TOP 25 CHANGED - CHOOSE SKIP":"COULD NOT SAVE - TRY AGAIN";entry.Revision++;yield break;}
   // Nothing is published as saved until the native atomic file commit or the
   // synchronous browser storage write plus read-back has succeeded.
   bool retained=Array.Exists(prepared.entries,r=>r.id==submittedId);scores.Commit(prepared);OpenBoard(retained?submittedId:"",retained?"SAVED ON THIS DEVICE":"TOP 25 CHANGED");
  }
  void UpdateRecords(double t){if(!renderer.RecordsReady){if(!testing&&Application.isFocused&&(Input.GetKeyDown(KeyCode.Escape)||NativeGamepadInput.ReadSlot(0).Back))CloseRecords();renderer.Render(State,t);return;}if(!recordScreenPresented){records.Entered=t;recordScreenPresented=true;}if(!testing&&!records.Submitting&&Application.isFocused){if(Input.GetKeyDown(KeyCode.Escape)||NativeGamepadInput.ReadSlot(0).Back){CloseRecords();return;}
    Vector3 mouse=IpadPointer.Position;if((mouse-pointer).sqrMagnitude>.01||IpadPointer.Pressed){pointer=mouse;var p=MenuPointer(mouse);int hit=-1;
     if(records.Entry){if(new Rect(192,304,640,240).Contains(p)){records.Row=Mathf.FloorToInt((p.y-304)/48);records.Column=Mathf.FloorToInt((p.x-192)/80);hit=records.Row*8+records.Column;}else for(int i=0;i<3;i++)if(NativeRecordState.Area(2,i).Contains(p)){records.Row=5;records.Column=i;hit=40+i;}}
     else for(int i=0;i<3;i++)if(NativeRecordState.Area(3,i).Contains(p)){records.Action=i;hit=i;}if(hit>=0){records.Revision++;if(IpadPointer.Pressed){RecordAction();if(records==null)return;}}
    }
    var arrows=new[]{KeyCode.UpArrow,KeyCode.DownArrow,KeyCode.LeftArrow,KeyCode.RightArrow};for(int i=0;i<4;i++)if(Input.GetKeyDown(arrows[i])&&records.Move(i))TickSound("Tick");
    int direction=padNavigation.Move(NativeGamepadInput.ReadSlot(0),t);if(direction>=0&&records.Move(direction))TickSound("Tick");
    if(records.Entry){bool paste=(Input.GetKey(KeyCode.LeftControl)||Input.GetKey(KeyCode.RightControl)||Input.GetKey(KeyCode.LeftCommand)||Input.GetKey(KeyCode.RightCommand))&&Input.GetKeyDown(KeyCode.V);
     if(paste){records.Navigation=false;if(records.Append(GUIUtility.systemCopyBuffer,t))TickSound("Tick");}
     else {string typed=NativeHighScores.Sanitize(Input.inputString);if(typed.Length>0){records.Navigation=false;if(records.Append(typed,t))TickSound("Tick");}}
     if((Input.GetKeyDown(KeyCode.Backspace)||Input.GetKeyDown(KeyCode.Delete))&&records.Delete(t))TickSound("Tick");
     if(NativeDisplay.AcceptEnter)SaveRecord();else if(NativeGamepadInput.ReadSlot(0).Confirm||Input.GetKeyDown(KeyCode.Space)&&records.Navigation)RecordAction();
    }else if(NativeDisplay.AcceptEnter||Input.GetKeyDown(KeyCode.Space)||NativeGamepadInput.ReadSlot(0).Confirm)RecordAction();
   }
   if(records!=null){Audio.SyncMenu(t,-1);renderer.RenderRecords(records,scores.Entries,t);}
  }
  IEnumerator RecordSmoke(){Directory.CreateDirectory(Path.GetDirectoryName(report));string q=State.Quality;bool ok=true;yield return null;
   if(recordReadback){ok&=scores.Entries.Length==1&&scores.Entries[0].name=="FANTASY"&&scores.Entries[0].score==54320;State.SetFocus(6,Now);Choose();yield return null;ok&=records!=null&&!records.Entry&&Audio.Track=="neon-orbit-menu";SaveFrame(q+"-reloaded",renderer.Target);CloseRecords();yield return null;SaveFrame(q+"-leader-menu",renderer.Target);}
   else{ok&=scores.Entries.Length==0;State.SetFocus(6,Now);Choose();yield return null;ok&=records!=null&&!records.Entry&&Audio.Track=="neon-orbit-menu";SaveFrame(q+"-empty-interactive",renderer.Target);CloseRecords();
    State.SetFocus(0,Now);Choose();double begin=Time.realtimeSinceStartupAsDouble;while(!gameplay||!gameplay.MenuReady){if(Time.realtimeSinceStartupAsDouble-begin>180)throw new TimeoutException("Record SOLO preparation");yield return null;}
    gameplay.RecordSmokeFinish();while(changing||gameplay)yield return null;yield return null;ok&=records!=null&&records.Entry&&records.Candidate.score==54320&&records.Candidate.level==1&&Audio.Track=="neon-orbit-high-score";SaveFrame(q+"-gameover-entry",renderer.Target);
    SaveRecord();ok&=records.Status=="ENTER A NAME OR CHOOSE SKIP"&&scores.Entries.Length==0;records.SetDraft("FANTASY",Now);yield return null;SaveFrame(q+"-typed",renderer.Target);var goodStore=scores;string blocked=Path.Combine(Path.GetDirectoryName(report),"blocked-save");File.WriteAllText(blocked,"test-only obstacle");scores=new NativeHighScores(Path.Combine(blocked,"scores.json"));SaveRecord();while(records.Submitting)yield return null;ok&=records.Entry&&records.Draft=="FANTASY"&&records.Status=="COULD NOT SAVE - TRY AGAIN"&&scores.Entries.Length==0;scores=goodStore;int musicChanges=Audio.MusicChanges;SaveRecord();SaveRecord();while(records.Submitting)yield return null;yield return null;
    ok&=!records.Entry&&scores.Entries.Length==1&&records.Highlight==scores.Entries[0].id&&Audio.MusicChanges==musicChanges&&Audio.Track=="neon-orbit-high-score";SaveFrame(q+"-saved",renderer.Target);CloseRecords();yield return null;ok&=Audio.Track=="neon-orbit-menu";SaveFrame(q+"-leader-menu",renderer.Target);
    OpenEntry(new NativeRecord{score=1});CloseRecords();ok&=scores.Entries.Length==1;
   }
   NativeMemory.TryRead(out var ws,out var peak,out _);File.WriteAllText(report,JsonUtility.ToJson(new RecordSmokeResult{passed=ok,quality=q,readback=recordReadback,count=scores.Entries.Length,sounds=Audio.Accepted,workingSetBytes=ws,peakWorkingSetBytes=peak,file=scores.FilePath,note="Real SOLO session score capture, atomic save, no duplicate submit, skip, local reload in a separate process, and original music routing. Muted test; no listening or foreground FPS claim."},true));Application.Quit(ok?0:2);
  }
 }
 [Serializable] public sealed class RecordSmokeResult {public bool passed,readback;public string quality,file,note;public int count,sounds;public long workingSetBytes,peakWorkingSetBytes;}
 public sealed partial class NativeGameplayStudy {
  public NativeRecord MenuRecord {get{if(world==null||world.Mode==0)return null;int score=world.GetPlayer(0).Score;if(world.Multiplayer&&!world.GetPlayer(1).IsAI)score=Math.Max(score,world.GetPlayer(1).Score);var ids=new System.Collections.Generic.List<int>();for(int i=0;i<world.PlayerCount;i++)if(!world.GetPlayer(i).IsAI&&world.GetPlayer(i).Score==score)ids.Add(i+1);return new NativeRecord{score=Math.Max(0,score),level=Math.Max(1,world.Level),mode=world.Mode,modeLabel=world.Mode==4?"DUO VS AI":world.Mode==3?"SOLO VS AI":world.Competitive?"DUO VS":world.Cooperative?"DUO CO-OP":"SOLO",difficulty=new[]{"PICNIC","EASY","MEDIUM","HARD","BRUTAL"}[difficultyIndex],speed=new[]{"SNAIL","SLOW","MEDIUM","FAST","EXTREME"}[MenuOwner.State.Speed],multiplier=world.Difficulty*world.ScoreSpeed,playerIds=ids.ToArray()};}}
  public void RecordSmokeFinish(){world.Player.Score=54320;world.Player.ExactScore=54320;world.GameOver=true;world.GameOverAt=realClock-NativeGameplayWorld.GameOverDuration-1;}
 }
}

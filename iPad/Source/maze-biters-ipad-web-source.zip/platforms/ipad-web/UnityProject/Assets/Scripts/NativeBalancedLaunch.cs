using System;
namespace MazeBiters.NativeStudy {
 // Diagnostic control retains the previous instant/all-work-before-menu policy.
 public static class NativeBalancedLaunch {
  public static readonly bool Enabled=Array.IndexOf(Environment.GetCommandLineArgs(),"--legacy-balanced-start")<0;
  public static bool FastCache=>Enabled&&Array.IndexOf(Environment.GetCommandLineArgs(),"--legacy-startup-runs")<0;
  public static bool Distributed=>Enabled&&Array.IndexOf(Environment.GetCommandLineArgs(),"--cache-only-start")<0;
 }
}

#if UNITY_EDITOR
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using UnityEngine;

namespace MazeBiters.NativeStudy {
 [Serializable] public sealed class NativeAllyForesightCase {
  public string name, beforeDirection, afterDirection, reason;
  public double risk, interceptRisk, pocketRisk, exitArrivalMs, returnMs;
  public bool pocket, lethal;
  public int expanded;
 }
 [Serializable] public sealed class NativeAllyForesightReport {
  public bool passed;
  public int assertions, failures, decisions;
  public double elapsedMs;
  public string scope;
  public List<NativeDifficultyCheck> checks=new List<NativeDifficultyCheck>();
  public List<NativeAllyForesightCase> cases=new List<NativeAllyForesightCase>();
 }

 // These are deliberately small, legible boards. The dangerous and harmless
 // versions share geometry; the difference is a real enemy, its movement phase
 // or a real protection timer. Contact checks use the original world engine.
 public static class NativeAllyForesightValidation {
  static readonly Vector2Int Centre=new Vector2Int(8,8), Right=Vector2Int.right, Left=Vector2Int.left;
  static readonly Vector2Int Up=new Vector2Int(0,-1), Down=new Vector2Int(0,1);
  sealed class Fixture {
   public NativeGameplayWorld world;
   public NativePlayer ai;
   public int rotation, randomCalls;
   public Vector2Int target;
   public Vector2Int C(int x,int y)=>Centre+Rotate(new Vector2Int(x-8,y-8),rotation);
   public Vector2Int D(Vector2Int d)=>Rotate(d,rotation);
  }
  static Vector2Int Rotate(Vector2Int v,int turns){for(int i=0;i<turns;i++)v=new Vector2Int(-v.y,v.x);return v;}
  static HashSet<Vector2Int> Cells(){return new HashSet<Vector2Int>();}
  static void Line(HashSet<Vector2Int> cells,int ax,int ay,int bx,int by){var c=new Vector2Int(ax,ay);var end=new Vector2Int(bx,by);var step=new Vector2Int(Math.Sign(bx-ax),Math.Sign(by-ay));for(int guard=0;guard<40;guard++){cells.Add(c);if(c==end)return;c+=step;}throw new ArgumentException("Non-axis-aligned test line");}
  static void Room(HashSet<Vector2Int> cells,int left,int top,int right,int bottom){for(int y=top;y<=bottom;y++)for(int x=left;x<=right;x++)cells.Add(new Vector2Int(x,y));}
  static Fixture Make(HashSet<Vector2Int> cells,int tier=4,int rotation=0,int mode=0){
   var f=new Fixture{rotation=rotation};var rows=Enumerable.Range(0,17).Select(_=>new string('#',17).ToCharArray()).ToArray();
   foreach(var c in cells){var v=f.C(c.x,c.y);rows[v.y][v.x]='.';}
   var w=new NativeGameplayWorld(rows.Select(r=>new string(r)).ToArray(),()=>{f.randomCalls++;return .99;}){AiDifficulty=tier,Difficulty=NativeMazeGenerator.Difficulties[tier],Time=1000,LevelStarted=1000,Assist=false,SessionEnabled=false};
   w.SetMode(mode);f.world=w;f.ai=w.GetPlayer(w.PlayerCount-1);
   for(int i=0;i<w.PlayerCount;i++){var p=w.GetPlayer(i);p.Cell=p.From=p.Previous=f.C(2,8);p.Dir=p.Next=f.D(Right);if(p!=f.ai){p.Dead=true;p.Lives=0;}}
   f.ai.Cell=f.ai.From=f.ai.Previous=Centre;f.ai.Dir=f.ai.Next=f.D(Right);f.ai.Score=200;f.ai.ExactScore=200;f.ai.Waiting=false;f.ai.LastMove=w.Time-96;w.Ally.BeginLevel();return f;
  }
  static NativeGameplaySnake Snake(Fixture f,IEnumerable<Vector2Int> cells,Vector2Int direction){var body=cells.Select(c=>f.C(c.x,c.y)).ToList();var s=new NativeGameplaySnake{Id=10+f.world.Snakes.Count,Cell=body[0],Dir=f.D(direction),Body=body,Temperament=.5,LastMove=f.world.Time};f.world.Snakes.Add(s);return s;}
  static NativeGameplaySnake Head(Fixture f,int x,int y,Vector2Int direction)=>Snake(f,new[]{new Vector2Int(x,y)},direction);
  static NativeHunter Hunter(Fixture f,int x,int y,Vector2Int direction,double phase=95){var h=new NativeHunter{Id=100+f.world.Hunters.Count,Cell=f.C(x,y),From=f.C(x,y),Dir=f.D(direction),LastMove=f.world.Time-phase,MotherAlive=false};f.world.Hunters.Add(h);return h;}
  static Fixture Pocket(int rotation=0,bool threat=true,int tier=4,int mode=0){
   var cells=Cells();Line(cells,2,8,13,8);Line(cells,8,2,8,8);Room(cells,2,7,7,11);
   var f=Make(cells,tier,rotation,mode);f.target=f.C(13,8);Head(f,13,8,Right);if(threat)Hunter(f,8,3,Down);return f;
  }
  static void Check(NativeAllyForesightReport r,bool ok,string name,string detail=""){r.assertions++;if(!ok)r.failures++;r.checks.Add(new NativeDifficultyCheck{name=name,passed=ok,detail=detail});}
  static void Group(NativeAllyForesightReport r,string name,Action action){try{action();}catch(Exception ex){Check(r,false,name+" completes",ex.ToString());}}
  static void Plan(NativeAllyForesightReport r,Fixture f,bool previous=false){f.world.Ally.DisablePredictivePlanning=previous;using(f.world.ForPlayer(f.ai))f.world.Ally.Plan(f.ai,f.world.Time);r.decisions++;}
  static NativeAllyForesightSample Inspect(Fixture f,Vector2Int d,Vector2Int? target=null){using(f.world.ForPlayer(f.ai))return f.world.Ally.InspectForesight(f.ai,f.world.Time,d,target);}
  static void Advance(Fixture f){using(f.world.ForPlayer(f.ai))f.world.AdvancePlayer();f.world.Time+=95;}
  static string Choice(Fixture f)=>f.ai.Waiting?"wait":f.ai.Next.ToString();
  static string Detail(NativeAllyForesightSample s)=>"risk="+s.risk+", intercept="+s.interceptRisk+", pocket="+s.pocketRisk+", gate="+s.exitArrivalMs+", return="+s.returnMs+", reason="+s.reason;
  static void Record(NativeAllyForesightReport r,string name,Fixture before,Fixture after,NativeAllyForesightSample s){r.cases.Add(new NativeAllyForesightCase{name=name,beforeDirection=before==null?"":Choice(before),afterDirection=Choice(after),risk=s.risk,interceptRisk=s.interceptRisk,pocketRisk=s.pocketRisk,exitArrivalMs=s.exitArrivalMs,returnMs=s.returnMs,pocket=s.pocket,lethal=s.lethal,expanded=s.expanded,reason=s.reason});}

  static void DeadEndBait(NativeAllyForesightReport r){
   for(int rotation=0;rotation<4;rotation++)foreach(int mode in new[]{0,3,4}){
    var old=Pocket(rotation,true,4,mode);var f=Pocket(rotation,true,4,mode);var sample=Inspect(f,f.D(Right),f.target);Plan(r,old,true);Plan(r,f);string label="rotation="+rotation+", mode="+mode;
    Check(r,sample.pocket&&sample.pocketRisk>0,"Food does not disguise a one-exit trap: "+label,Detail(sample));
    Check(r,!f.ai.Waiting&&f.ai.Next!=f.D(Right),"BRUTAL refuses bait while a hunter can close the only exit: "+label,"before="+Choice(old)+", after="+Choice(f)+"; "+Detail(sample));
    Record(r,"dead-end-bait "+label,old,f,sample);
   }
  }
  static void SafeFood(NativeAllyForesightReport r){
   for(int rotation=0;rotation<4;rotation++){
    var f=Pocket(rotation,false);var s=Inspect(f,f.D(Right),f.target);Plan(r,f);
    Check(r,f.ai.Next==f.D(Right)&&!f.ai.Waiting&&s.pocketRisk==0,"A harmless cul-de-sac remains a valid meal: rotation="+rotation,Choice(f)+"; "+Detail(s));
    for(int step=0;step<5;step++){if(step>0)Plan(r,f);Advance(f);}
    Check(r,!f.ai.Dead&&f.world.Snakes.Count==0&&f.ai.Score==325,"Safe cul-de-sac food is actually eaten in five direct steps: rotation="+rotation,"cell="+f.ai.Cell+", score="+f.ai.Score);
    var cells=Cells();Line(cells,2,8,14,8);f=Make(cells,rotation:rotation);var snake=Snake(f,Enumerable.Range(9,4).Reverse().Select(x=>new Vector2Int(x,8)),Right);
    for(int step=0;step<4;step++){Plan(r,f);Advance(f);}
    Check(r,!f.ai.Dead&&!f.world.Snakes.Contains(snake)&&f.ai.Score==400,"Safe continuous eating still finishes body and head efficiently: rotation="+rotation,"cell="+f.ai.Cell+", score="+f.ai.Score+", left="+f.world.Snakes.Count);
    f=Make(cells,rotation:rotation);var head=Head(f,9,8,Right);Plan(r,f);Advance(f);
    Check(r,!f.ai.Dead&&!f.world.Snakes.Contains(head)&&f.ai.Score==325,"An eaten safe head is not retained as a future phantom threat: rotation="+rotation);
   }
  }
  static void WallAndEggSeparation(NativeAllyForesightReport r){
   for(int rotation=0;rotation<4;rotation++){
    var cells=Cells();Line(cells,2,8,13,8);Line(cells,2,5,13,5);Line(cells,2,5,2,8);var f=Make(cells,rotation:rotation);f.target=f.C(9,8);Head(f,9,8,Right);Hunter(f,9,5,Down);var s=Inspect(f,f.D(Right),f.target);Plan(r,f);Advance(f);
    Check(r,!f.ai.Dead&&f.ai.Score==325,"Nearby enemy across a wall does not prevent a safe adjacent meal: rotation="+rotation,Detail(s));
    f=Pocket(rotation,true);f.world.SolidEggs.Add(f.C(8,5));f.world.ObstacleRevision++;s=Inspect(f,f.D(Right),f.target);Plan(r,f);
    Check(r,s.pocketRisk==0&&f.ai.Next==f.D(Right),"A solid egg truly cuts the hunter's path to the gate: rotation="+rotation,Choice(f)+"; "+Detail(s));
    f.world.SolidEggs.Clear();f.world.ObstacleRevision++;s=Inspect(f,f.D(Right),f.target);
    Check(r,s.pocketRisk>0,"Removing a dynamic obstruction restores the gate threat immediately: rotation="+rotation,Detail(s));
   }
  }
  static void ProtectionExpiry(NativeAllyForesightReport r){
   for(int rotation=0;rotation<4;rotation++)foreach(bool shield in new[]{true,false}){
    var brief=Pocket(rotation,true);var lasting=Pocket(rotation,true);double t=brief.world.Time;if(shield){brief.ai.ShieldUntil=t+80;lasting.ai.ShieldUntil=t+2500;}else{brief.ai.PowerUntil=t+80;lasting.ai.PowerUntil=t+2500;}
    var a=Inspect(brief,brief.D(Right),brief.target);var b=Inspect(lasting,lasting.D(Right),lasting.target);Plan(r,brief);Plan(r,lasting);
    string label="rotation="+rotation+", protection="+(shield?"spawn":"power");
    Check(r,a.pocketRisk>b.pocketRisk,"Protection is evaluated at the future return, not only now: "+label,"brief: "+Detail(a)+"; lasting: "+Detail(b));
    Check(r,brief.ai.Next!=brief.D(Right)&&!brief.ai.Waiting,"An expiring shield/power does not excuse the bait trap: "+label,Choice(brief));
    Check(r,!lasting.ai.Waiting&&(shield?lasting.ai.Ai.locked==null&&lasting.ai.Ai.split==null:lasting.ai.Next==lasting.D(Right)),shield?"Lasting spawn protection stays defensive without planning a meal: "+label:"Enough genuine power preserves an efficient safe meal: "+label,Choice(lasting));
   }
  }
  static void EscapeFromInside(NativeAllyForesightReport r){
   for(int rotation=0;rotation<4;rotation++){
    var f=Pocket(rotation,true);f.ai.Cell=f.ai.From=f.ai.Previous=f.C(10,8);f.ai.Dir=f.ai.Next=f.D(Right);f.world.Hunters[0].Cell=f.world.Hunters[0].From=f.C(8,5);var s=Inspect(f,f.D(Right),f.target);Plan(r,f);
    Check(r,!f.ai.Waiting&&f.ai.Next==f.D(Left),"Already inside a dangerous pocket, the AI takes the remaining escape: rotation="+rotation,Choice(f)+"; "+Detail(s));
   }
  }
  static Fixture Crossing(int rotation=0,bool second=false){
   var cells=Cells();Line(cells,3,8,13,8);Line(cells,11,2,11,8);Line(cells,8,8,8,12);Line(cells,8,12,13,12);Line(cells,13,8,13,12);Line(cells,3,8,3,12);Line(cells,3,12,8,12);
   var f=Make(cells,rotation:rotation);f.target=f.C(13,8);Head(f,13,8,Right);Hunter(f,11,6,Down);if(second){Line(cells,11,12,11,14);f=Make(cells,rotation:rotation);f.target=f.C(13,8);Head(f,13,8,Right);Hunter(f,11,6,Down);Hunter(f,11,14,Up);}return f;
  }
  static void Interception(NativeAllyForesightReport r){
   for(int rotation=0;rotation<4;rotation++){
    var f=Crossing(rotation);var direct=Inspect(f,f.D(Right),f.target);var detour=Inspect(f,f.D(Down),f.target);Plan(r,f);
    Check(r,direct.interceptRisk>detour.interceptRisk,"An approaching hunter is recognized before entering the shared crossing: rotation="+rotation,"direct: "+Detail(direct)+"; detour: "+Detail(detour));
    Check(r,!f.ai.Waiting&&f.ai.Next!=f.D(Right),"The planner changes route before the distant crossing becomes local danger: rotation="+rotation,Choice(f));
    var both=Crossing(rotation,true);var lower=Inspect(both,both.D(Down),both.target);
    Check(r,lower.risk>=detour.risk,"A second approaching hunter cannot make the lower route appear safer: rotation="+rotation,"one: "+Detail(detour)+"; both: "+Detail(lower));
    Record(r,"crossing rotation="+rotation,null,f,direct);
   }
  }
  static void TimingAndHarmlessActors(NativeAllyForesightReport r){
   var cells=Cells();Room(cells,3,3,13,13);var due=Make(cells);var fresh=Make(cells);Head(due,12,8,Right);Head(fresh,12,8,Right);Hunter(due,9,7,Down,95);Hunter(fresh,9,7,Down,0);
   var a=Inspect(due,Right,due.C(12,8));var b=Inspect(fresh,Right,fresh.C(12,8));
   Check(r,a.interceptRisk>=b.interceptRisk,"An enemy due now is no safer than the same enemy that just moved","due: "+Detail(a)+"; fresh: "+Detail(b));
   var empty=Pocket(threat:false);var scorpion=Pocket(threat:false);scorpion.world.PlaceScorpion(scorpion.C(8,3),Down);a=Inspect(empty,Right,empty.target);b=Inspect(scorpion,Right,scorpion.target);
   Check(r,b.interceptRisk==a.interceptRisk&&b.pocketRisk==a.pocketRisk,"A scorpion is not invented as a lethal pursuer",Detail(b));
   var splitCells=Cells();Room(splitCells,4,4,12,12);var split=Make(splitCells);Snake(split,Enumerable.Range(6,5).Select(y=>new Vector2Int(9,y)),Up);split.world.Tick(split.world.Time);r.decisions++;
   Check(r,!split.ai.Dead&&split.ai.Score>200&&split.world.Snakes.Count==2,"A safe body split survives immediate movement of both new fragments","cell="+split.ai.Cell+", score="+split.ai.Score+", snakes="+split.world.Snakes.Count);
  }
  static void LockBait(Fixture f){var a=f.ai.Ai;a.locked=f.world.Snakes[0];a.bitten=true;a.mealInitialized=a.mealActive=true;a.mealIntentUntil=double.PositiveInfinity;a.commitUntil=f.world.Time+10000;a.commitMode="finish";a.allowSplit=true;}
  static NativeAllyThreatForecast Forecast(Fixture f){var forecast=new NativeAllyThreatForecast();forecast.Build(f.world,f.ai,f.world.Time,2400);return forecast;}
  static void SnakeAndHatchThreats(NativeAllyForesightReport r){
   for(int rotation=0;rotation<4;rotation++){
    var f=Pocket(rotation,false);var closing=Snake(f,new[]{new Vector2Int(8,5),new Vector2Int(8,4),new Vector2Int(8,3)},Down);closing.LastMove=f.world.Time-219;LockBait(f);
    var sample=Inspect(f,f.D(Right),f.target);double gate=Forecast(f).Arrival(f.ai.Cell);Plan(r,f);
    Check(r,sample.pocketRisk>0&&gate<sample.returnMs,"A forward snake can close the only exit before a committed meal returns: rotation="+rotation,"arrival="+gate+"; "+Detail(sample));
    Check(r,!f.ai.Waiting&&f.ai.Next!=f.D(Right),"Predictive survival can interrupt committed food when a different snake closes the exit: rotation="+rotation,Choice(f));
    Record(r,"snake-gate rotation="+rotation,null,f,sample);
    f=Pocket(rotation,false);
    // A hatch normally chooses a random heading. Seal the square behind it so
    // all four genuine initial headings have the same sole legal exit. Only
    // then may its earliest forecast be compared with an exact runtime ETA.
    var sealedCell=f.C(8,4);var sealedRow=f.world.Grid[sealedCell.y].ToCharArray();sealedRow[sealedCell.x]='#';f.world.Grid[sealedCell.y]=new string(sealedRow);f.world.ObstacleRevision++;f.world.Ally.ScanMaze(true);
    f.world.Eggs.Add(new NativeEgg{Cell=f.C(8,5),Born=f.world.Time-12900});f.world.LifecycleEnabled=true;
    sample=Inspect(f,f.D(Right),f.target);double before=Forecast(f).Arrival(f.ai.Cell);Plan(r,f);
    Check(r,sample.pocketRisk>0&&f.ai.Next!=f.D(Right),"An egg about to hatch can make an apparently empty escape gate unsafe: rotation="+rotation,Choice(f)+"; "+Detail(sample));
    f.world.Time+=100;f.world.UpdateEggs();var hatchedForecast=Forecast(f);double after=hatchedForecast.Arrival(f.ai.Cell);
    Check(r,f.world.Hunters.Count==1&&f.world.Eggs.Count==0&&Math.Abs(before-(100+after))<.001,"Forecast birth and first hunter move agree with actual egg hatching: rotation="+rotation,"before="+before+", after="+after+", hunters="+f.world.Hunters.Count);
    Check(r,f.world.Hunters.Count==1&&f.world.Hunters[0].LastMove==f.world.Time&&Math.Abs(hatchedForecast.Arrival(f.C(8,6))-95)<.001,"A newly hatched hunter waits its original 95 ms before the forced first step: rotation="+rotation,"arrival="+hatchedForecast.Arrival(f.C(8,6)));
    f=Pocket(rotation,false);f.world.Eggs.Add(new NativeEgg{Cell=f.C(8,5),Born=f.world.Time});sample=Inspect(f,f.D(Right),f.target);Plan(r,f);
    Check(r,sample.pocketRisk==0&&f.ai.Next==f.D(Right),"A fresh egg outside the prediction window does not invent an immediate pursuer: rotation="+rotation,Detail(sample));
    f=Pocket(rotation,false);f.world.Eggs.Add(new NativeEgg{Cell=f.C(8,5),Born=f.world.Time-12900});f.world.Fruits.Add(new NativeFruit{Cell=f.C(8,5),Kind=0});sample=Inspect(f,f.D(Right),f.target);
    Check(r,sample.pocketRisk==0,"A covered egg retains the real postponement rule: rotation="+rotation,Detail(sample));
   }
  }
  static NativePlayer Rival(Fixture f,int score=500){var p=f.world.GetPlayer(0);p.Dead=p.HideDeath=p.Eliminated=false;p.Lives=3;p.Score=score;p.ExactScore=score;p.Cell=p.From=p.Previous=f.C(8,3);p.Dir=p.Next=f.D(Down);p.LastMove=f.world.Time-95;return p;}
  static void RivalProtectionPriority(NativeAllyForesightReport r){
   for(int rotation=0;rotation<4;rotation++){
    var brief=Pocket(rotation,false,mode:3);var lasting=Pocket(rotation,false,mode:3);var enemy=Rival(brief);Rival(lasting);brief.ai.ShieldUntil=brief.world.Time+80;lasting.ai.ShieldUntil=lasting.world.Time+2500;
    var a=Inspect(brief,brief.D(Right),brief.target);var b=Inspect(lasting,lasting.D(Right),lasting.target);
    Check(r,a.pocketRisk>b.pocketRisk&&brief.world.CanEatPlayer(enemy,brief.ai,brief.world.Time+81),"Spawn protection expiry is evaluated against a stronger rival's future contact priority: rotation="+rotation,"brief: "+Detail(a)+"; lasting: "+Detail(b));
    var fruit=Pocket(rotation,false,mode:3);enemy=Rival(fruit);enemy.PowerUntil=fruit.world.Time+5000;enemy.RampAt=fruit.world.Time-10000;enemy.RampDuration=0;enemy.RampFrom=1;fruit.world.Fruits.Add(new NativeFruit{Cell=fruit.C(9,8),Kind=0});a=Inspect(fruit,fruit.D(Right),fruit.target);
    Check(r,a.pocketRisk>0,"Collecting fruit does not make the AI immune to a higher-score powered rival: rotation="+rotation,Detail(a));
    // Validate the premise through genuine fruit contact and the same score /
    // power priority used by the runtime, rather than a test-side rule copy.
    fruit.ai.Next=fruit.ai.Dir=fruit.D(Right);Advance(fruit);
    Check(r,fruit.world.Fruits.Count==0&&fruit.ai.PowerUntil>fruit.world.Time&&fruit.world.CanEatPlayer(enemy,fruit.ai,fruit.world.Time),"The original fruit/contact rules confirm the powered rival remains lethal: rotation="+rotation,"score="+fruit.ai.Score+", rival="+enemy.Score);
    var rescued=Pocket(rotation,false,mode:3);var weaker=Rival(rescued,100);weaker.PowerUntil=rescued.world.Time+5000;weaker.RampAt=rescued.world.Time-10000;weaker.RampDuration=0;weaker.RampFrom=1;rescued.world.Fruits.Add(new NativeFruit{Cell=rescued.C(9,8),Kind=0});var safeFruit=Inspect(rescued,rescued.D(Right),rescued.target);
    rescued.ai.Next=rescued.ai.Dir=rescued.D(Right);Advance(rescued);
    Check(r,safeFruit.pocketRisk==0&&!rescued.world.CanEatPlayer(weaker,rescued.ai,rescued.world.Time)&&rescued.world.CanEatPlayer(rescued.ai,weaker,rescued.world.Time),"Fruit can reverse priority against a weaker powered rival without inventing danger: rotation="+rotation,Detail(safeFruit));
    var expires=Pocket(rotation,false,mode:3);var persists=Pocket(rotation,false,mode:3);var weak=Rival(expires,100);var strong=Rival(persists,100);weak.PowerUntil=expires.world.Time+80;strong.PowerUntil=persists.world.Time+2500;
    a=Inspect(expires,expires.D(Right),expires.target);b=Inspect(persists,persists.D(Right),persists.target);
    Check(r,a.pocketRisk<b.pocketRisk,"A weaker rival whose power expires before intercepting is not dangerous forever: rotation="+rotation,"expires: "+Detail(a)+"; persists: "+Detail(b));
   }
  }
  static void SplitRearHead(NativeAllyForesightReport r){
   for(int rotation=0;rotation<4;rotation++){
    // The long rear half wraps behind the eater. Its new head has exactly one
    // forward exit: the player's previous square. Going straight back would
    // meet the newly born head on the same tick (new fragments LastMove=0).
    var body=new[]{new Vector2Int(12,8),new Vector2Int(11,8),new Vector2Int(10,8),new Vector2Int(10,9),new Vector2Int(9,9),new Vector2Int(9,8),new Vector2Int(9,7)};
    var cells=new HashSet<Vector2Int>(body);cells.Add(new Vector2Int(10,7));cells.Add(new Vector2Int(13,8));cells.Add(new Vector2Int(14,8));cells.Add(new Vector2Int(10,10));
    var f=Make(cells,rotation:rotation);f.ai.Cell=f.ai.From=f.ai.Previous=f.C(10,7);f.ai.Next=f.ai.Dir=f.D(Down);var original=Snake(f,body,Right);using(f.world.ForPlayer(f.ai))f.world.AdvancePlayer();
    var rear=f.world.Snakes.FirstOrDefault(s=>s.Head==f.C(9,7));var danger=Inspect(f,f.D(Up));
    Check(r,f.world.Snakes.Count==2&&!f.world.Snakes.Contains(original)&&rear!=null&&rear.LastMove==0&&rear.Dir==f.D(Up),"Real cutting produces the expected immediately active rear head: rotation="+rotation,"score="+f.ai.Score+", rear="+(rear==null?"missing":rear.Head+"/"+rear.Dir));
    Check(r,danger.interceptRisk>.55,"The new rear head is included before reversing into its forced next step: rotation="+rotation,Detail(danger));
    Plan(r,f);Check(r,!f.ai.Waiting&&f.ai.Next!=f.D(Up),"After the split the AI does not reverse into the newly created rear head: rotation="+rotation,Choice(f));
   }
  }
  static string State(Fixture f){var w=f.world;return string.Join("|",new[]{w.Time.ToString(),f.ai.Cell.ToString(),f.ai.Dir.ToString(),f.ai.Next.ToString(),f.ai.Score.ToString(),f.randomCalls.ToString(),string.Join(";",w.Snakes.Select(s=>s.Id+":"+s.LastMove+":"+s.Dir+":"+string.Join(",",s.Body))),string.Join(";",w.Hunters.Select(h=>h.Id+":"+h.Cell+":"+h.Dir+":"+h.LastMove))});}
  static void ScopeAndInspection(NativeAllyForesightReport r){
   for(int tier=0;tier<4;tier++)foreach(int mode in new[]{0,3,4}){
    var old=Pocket(tier:tier,mode:mode);var current=Pocket(tier:tier,mode:mode);current.world.Ally.MaximumOnlyPredictivePlanning=true;Plan(r,old,true);Plan(r,current);
    Check(r,Choice(old)==Choice(current)&&old.randomCalls==current.randomCalls&&old.ai.Ai.thought==current.ai.Ai.thought,"Frozen maximum-only reference preserves its former low-tier decision and random draws: tier="+tier+", mode="+mode,"old="+Choice(old)+", reference="+Choice(current));
   }
   for(int tier=0;tier<4;tier++){
    var f=Pocket(tier:tier);f.world.Time=f.world.LevelStarted+300000;foreach(var h in f.world.Hunters)h.LastMove=f.world.Time-95;foreach(var s in f.world.Snakes)s.LastMove=f.world.Time;var sample=Inspect(f,Right,f.target);Plan(r,f);
    Check(r,sample.pocketRisk>0&&f.ai.Next!=Right,"Time-escalated maximum skill receives the same foresight: original tier="+tier,Detail(sample));
   }
   var inspect=Pocket();string before=State(inspect);for(int i=0;i<12;i++)Inspect(inspect,Right,inspect.target);string after=State(inspect);
   Check(r,before==after,"Inspecting future routes does not advance enemies, consume randomness or alter gameplay");
   var legacy=Pocket();legacy.world.UseLegacyAi=true;var disabled=Pocket();disabled.world.UseLegacyAi=true;Plan(r,legacy);Plan(r,disabled,true);
   Check(r,Choice(legacy)==Choice(disabled)&&legacy.randomCalls==disabled.randomCalls,"Frozen legacy mode does not enter predictive planning");
  }
  public static NativeAllyForesightReport Run(){
   var watch=Stopwatch.StartNew();var r=new NativeAllyForesightReport{scope="Editor-only original iPad planner/contact scenarios. Checks maximum skill, bait and escape gates, wall/egg separation, route interception, real protection expiry, safe consumption, low-tier/random-draw compatibility. This does not measure rendered iPad performance or guarantee human-level optimal play."};
   Group(r,"dead-end bait",()=>DeadEndBait(r));Group(r,"safe eating",()=>SafeFood(r));Group(r,"wall and egg separation",()=>WallAndEggSeparation(r));Group(r,"protection expiry",()=>ProtectionExpiry(r));Group(r,"escape from inside",()=>EscapeFromInside(r));Group(r,"interception",()=>Interception(r));Group(r,"timing and harmless actors",()=>TimingAndHarmlessActors(r));Group(r,"snake and hatch threats",()=>SnakeAndHatchThreats(r));Group(r,"rival protection priority",()=>RivalProtectionPriority(r));Group(r,"split rear head",()=>SplitRearHead(r));Group(r,"scope and inspection",()=>ScopeAndInspection(r));r.elapsedMs=watch.Elapsed.TotalMilliseconds;r.passed=r.failures==0;return r;
  }
 }
}
#endif

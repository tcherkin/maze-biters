using System;using System.Collections.Generic;using System.IO;using UnityEngine;
namespace MazeBiters.NativeStudy {
 [Serializable] sealed class SessionSoundList {public SessionSoundEntry[] sounds;}
 [Serializable] sealed class SessionSoundEntry {public string name,id,sha256;}
 // Bounded SFX bus: original assets, voice groups, panning, gain and compressor
 // constants. Native resampling/envelope is not claimed PCM-identical to WebAudio.
 public sealed class NativeSessionAudio:MonoBehaviour {
  sealed class Clip {public float[] samples;public int channels,rate;}
  sealed class Voice {public Clip clip;public double position;public float pan;public int group,priority;public long order;public int webHandle;}
  NativeWebAudio webAudio;
  readonly object gate=new object();readonly List<Voice> voices=new List<Voice>(32);readonly Dictionary<string,Clip> clips=new Dictionary<string,Clip>();
  readonly double[] lastAt={-1e6,-1e6,-1e6,-1e6,-1e6,-1e6};
  static readonly int[] Limits={16,2,1,2,16,5},Gaps={0,32,60,38,0,0},Priorities={1,1,1,2,3,4};
  AudioSource bus,music;AudioClip silent,musicClip;int rate;long serial;float compressorGain=1;double musicAt;public bool Muted;public int Accepted,Rejected,MusicChanges;public double OutputEnergy;bool ready;
  public string Track=>musicClip?musicClip.name:null;
  public float MusicSetting=1;AudioClip menuClip,scoreClip;
  ResourceRequest scoreRequest;
  internal bool RecordTrackReady=>scoreClip;
  internal System.Collections.Generic.IEnumerable<object> PrepareRecordTrackSteps(){
   if(scoreClip)yield break;
   if(scoreRequest==null){
    var request=scoreRequest=Resources.LoadAsync<AudioClip>("SessionAudio/neon-orbit-high-score");
    request.completed+=_=>{if(!this&&request.asset)Resources.UnloadAsset(request.asset);};
   }
   double deadline=Time.realtimeSinceStartupAsDouble+60;
   while(!scoreRequest.isDone){if(Time.realtimeSinceStartupAsDouble>deadline)throw new TimeoutException("Record music preparation timed out");yield return "wait";}
   scoreClip=scoreRequest.asset as AudioClip;scoreRequest=null;
   if(!scoreClip)throw new IOException("Missing original high-score music");
  }
  public void SetMenuTrack(double realTime,bool records=false){string wanted=records?"neon-orbit-high-score":"neon-orbit-menu";if(Track==wanted)return;ResetBus();if(records&&!scoreClip)scoreClip=Resources.Load<AudioClip>("SessionAudio/"+wanted);if(!records&&!menuClip)menuClip=Resources.Load<AudioClip>("SessionAudio/"+wanted);musicClip=records?scoreClip:menuClip;if(!musicClip)throw new IOException("Missing original menu music "+wanted);music.clip=musicClip;musicAt=realTime;music.volume=0;music.Play();MusicChanges++;}
  public void SyncMenu(double realTime,double confirmAt){double gain=confirmAt>=0?1-NativeMenuState.Smooth((realTime-confirmAt)/900):NativeMenuState.Smooth((realTime-musicAt)/240);music.volume=Muted?0:(float)(.72*.40*MusicSetting*gain);}
  public static readonly bool LegacyMusicRetirement=Array.IndexOf(Environment.GetCommandLineArgs(),"--legacy-music-retirement")>=0;
  readonly NativeMusicResources musicResources=new NativeMusicResources();
  public int CachedMusicCount=>musicResources.Count;public long CachedMusicBytes=>musicResources.AssetBytes;public int PendingMusicCount=>musicResources.Pending;
  public int MusicUnloads;public double LastMusicStopMs,LastMusicRetireMs,LastMusicSourceMs,LastMusicPlayMs;
  internal AudioSource MusicSource=>music;internal double MusicStartedAt=>musicAt;
  static double MusicElapsed(long mark)=>mark==0?0:(System.Diagnostics.Stopwatch.GetTimestamp()-mark)*1000.0/System.Diagnostics.Stopwatch.Frequency;
  ResourceRequest preparedTrack;string preparedTrackName;Exception preparedTrackFailure;long preparedTrackStarted;
  public void PrepareTrack(string name){
   if(!LegacyMusicRetirement){if(preparedTrackName!=name){CancelPreparedTrack();preparedTrackName=name;}musicResources.Prepare(name);return;}
   if(preparedTrackName==name&&preparedTrack!=null){
    if(preparedTrackFailure==null)return;
    if(!preparedTrack.isDone){preparedTrackFailure=null;preparedTrackStarted=NativeMusicResources.PreparationStamp();return;}
   }
   CancelPreparedTrack();preparedTrackName=name;preparedTrackStarted=NativeMusicResources.PreparationStamp();
   try{
    var request=preparedTrack=Resources.LoadAsync<AudioClip>("SessionAudio/"+name);
    request.completed+=_=>{
     if(!ReferenceEquals(preparedTrack,request)){if(request.asset&&request.asset!=musicClip&&preparedTrackName!=name)Resources.UnloadAsset(request.asset);return;}
     if(!(request.asset as AudioClip))preparedTrackFailure=new IOException("Prepared music completed without an AudioClip: SessionAudio/"+name);
    };
   }catch(Exception error){preparedTrackFailure=new IOException("Could not prepare music "+name,error);throw preparedTrackFailure;}
  }
  public bool PreparedTrackReady{get{
   if(!LegacyMusicRetirement)return musicResources.Ready(preparedTrackName);
   if(preparedTrack==null){if(preparedTrackFailure!=null)throw preparedTrackFailure;return false;}
   if(preparedTrack.isDone){if(preparedTrack.asset as AudioClip){preparedTrackFailure=null;return true;}preparedTrackFailure=preparedTrackFailure??new IOException("Prepared music completed without an AudioClip: SessionAudio/"+preparedTrackName);}
   else if(preparedTrackFailure==null&&NativeMusicResources.PreparationTimedOut(preparedTrackStarted))preparedTrackFailure=new TimeoutException("Music preparation exceeded "+NativeMusicResources.PreparationTimeoutSeconds+" seconds: "+preparedTrackName);
   if(preparedTrackFailure!=null)throw preparedTrackFailure;return false;
  }}
  public void CancelPreparedTrack(){var old=preparedTrack;preparedTrack=null;preparedTrackName=null;preparedTrackFailure=null;preparedTrackStarted=0;if(old!=null&&old.isDone&&old.asset&&old.asset!=musicClip)Resources.UnloadAsset(old.asset);}
  public void Initialize(bool muted,bool start=true,bool prepare=true){
   Muted=muted;rate=AudioSettings.outputSampleRate;
   var manifest=JsonUtility.FromJson<SessionSoundList>(File.ReadAllText(Path.Combine(WebFiles.Root,"Reference/session-audio.json")));
#if UNITY_WEBGL && !UNITY_EDITOR
   webAudio=new NativeWebAudio();webAudio.Mute(Muted);
   foreach(var entry in manifest.sounds){
    if(!webAudio.Sounds.TryGetValue(entry.name,out var sound))throw new IOException("Missing original Web sound "+entry.name);
    clips.Add(entry.name,new Clip{samples=sound.samples,channels=sound.channels,rate=sound.rate});
   }
#else
   foreach(var entry in manifest.sounds){var src=Resources.Load<AudioClip>("SessionAudio/"+entry.id);if(!src)throw new IOException("Missing sound "+entry.id);src.LoadAudioData();var pcm=new float[src.samples*src.channels];if(!src.GetData(pcm,0))throw new IOException("Cannot decode "+entry.id);clips.Add(entry.name,new Clip{samples=pcm,channels=src.channels,rate=src.frequency});Resources.UnloadAsset(src);}
   bus=gameObject.AddComponent<AudioSource>();bus.playOnAwake=false;bus.loop=true;bus.spatialBlend=0;bus.bypassEffects=true;silent=AudioClip.Create("Native SFX bus",1024,2,rate,false);bus.clip=silent;
#endif
   var musicObject=new GameObject("Original level music");musicObject.transform.SetParent(transform,false);music=musicObject.AddComponent<AudioSource>();music.playOnAwake=false;music.loop=true;music.spatialBlend=0;music.bypassEffects=true;
   if(!FindAnyObjectByType<AudioListener>())new GameObject("Native audio listener").AddComponent<AudioListener>().transform.SetParent(transform,false);ready=true;
   if(webAudio==null){if(prepare)PrepareSilentBus();if(start)bus.Play();}
  }
  void PrepareSilentBus(){
   // Before the real callback starts: exercise the original SFX admission and
   // mixer with decoded PCM, then restore ALL initial bus state. No sound,
   // gameplay random source, music clock or persistent voice is involved.
   bool muted=Muted;Muted=true;var buffer=new float[1024];double clock=10000;
   try{foreach(string name in clips.Keys){Play(name,new Vector2Int(12,1),false,clock);MixForValidation(buffer,2);clock+=100;}}
   finally{lock(gate){voices.Clear();for(int i=0;i<lastAt.Length;i++)lastAt[i]=-1e6;
    serial=0;Accepted=Rejected=0;compressorGain=1;OutputEnergy=0;Muted=muted;}}
  }
  static int Group(string name)=>name.StartsWith("Tie",StringComparison.Ordinal)?0:name.StartsWith("EatFruit",StringComparison.Ordinal)?1:name=="Tick"?2:name=="EggKnock"?3:name=="HeadEat"?4:5;
  public void Play(string name,Vector2Int cell,bool global,double realTime){
   if(!clips.TryGetValue(name,out var clip))return;int group=Group(name),priority=Priorities[group];
   lock(gate){PruneWebVoices();if(realTime-lastAt[group]<Gaps[group]){Rejected++;return;}int count=0;foreach(var v in voices)if(v.group==group)count++;while(count>=Limits[group]){int i=voices.FindIndex(v=>v.group==group);RemoveVoice(i);count--;}
    if(voices.Count>=32){int i=voices.FindIndex(v=>v.priority<=priority);if(i<0){Rejected++;return;}RemoveVoice(i);}
    var voice=new Voice{clip=clip,group=group,priority=priority,order=serial++,pan=global?0:(float)(Math.Sin(Math.Max(-1,Math.Min(1,cell.x/35.0*2-1))*Math.PI/2)*.58)};
    if(webAudio!=null){webAudio.Mute(Muted);voice.webHandle=webAudio.Play(name,voice.pan);if(voice.webHandle<=0){Rejected++;return;}}
    voices.Add(voice);lastAt[group]=realTime;Accepted++;
   }
  }
  public void SetTrack(string name,double realTime){
   if(Track==name)return;
   long mark=NativeStallTrace.Stamp();music.Stop();music.clip=null;LastMusicStopMs=MusicElapsed(mark);NativeStallTrace.Add("music-stop",mark);
   mark=NativeStallTrace.Stamp();if(LegacyMusicRetirement&&musicClip&&musicClip!=menuClip&&musicClip!=scoreClip){Resources.UnloadAsset(musicClip);MusicUnloads++;}LastMusicRetireMs=MusicElapsed(mark);NativeStallTrace.Add("music-unload",mark);
   mark=NativeStallTrace.Stamp();
   if(LegacyMusicRetirement){
    musicClip=preparedTrackName==name&&PreparedTrackReady?preparedTrack.asset as AudioClip:Resources.Load<AudioClip>("SessionAudio/"+name);
    if(preparedTrackName==name&&PreparedTrackReady){preparedTrack=null;preparedTrackName=null;}else CancelPreparedTrack();
   }else{musicClip=musicResources.Get(name);preparedTrackName=null;}
   if(!musicClip)throw new IOException("Missing music "+name);LastMusicSourceMs=MusicElapsed(mark);NativeStallTrace.Add("music-source",mark);
   mark=NativeStallTrace.Stamp();music.clip=musicClip;musicAt=realTime;music.volume=0;music.Play();MusicChanges++;LastMusicPlayMs=MusicElapsed(mark);NativeStallTrace.Add("music-play",mark);
  }
  public void Sync(NativeGameplayWorld w,bool paused){if(!ready)return;if((w.CatalogueFinished||w.GameOver&&w.MusicGain<=0)&&music.isPlaying)music.Stop();music.volume=Muted?0:(float)(.72*.34*MusicSetting*w.MusicGain*NativeGameplayWorld.Smooth((w.RealTime-musicAt)/160));}
  void RemoveVoice(int index){webAudio?.Stop(voices[index].webHandle);voices.RemoveAt(index);}
  void PruneWebVoices(){if(webAudio!=null)for(int i=voices.Count-1;i>=0;i--)if(!webAudio.Playing(voices[i].webHandle))voices.RemoveAt(i);}
  void Update(){if(webAudio==null)return;webAudio.Mute(Muted);lock(gate)PruneWebVoices();}
  public void ResetBus(){lock(gate){for(int i=voices.Count-1;i>=0;i--)RemoveVoice(i);for(int i=0;i<lastAt.Length;i++)lastAt[i]=-1e6;}CancelPreparedTrack();if(music){music.Stop();music.clip=null;}if(musicClip&&musicClip!=menuClip&&musicClip!=scoreClip&&LegacyMusicRetirement){Resources.UnloadAsset(musicClip);MusicUnloads++;}musicClip=null;}
  public void BeginPreparedSession(){lock(gate){
   // Let the ORIGINAL selection cue finish over the immediate first frame.
   // Admission clocks move from menu realtime to the fresh gameplay clock.
   clips.TryGetValue("SnakeSELECT&Appear@",out var selection);for(int i=voices.Count-1;i>=0;i--)if(voices[i].clip!=selection)RemoveVoice(i);
   for(int i=0;i<lastAt.Length;i++)lastAt[i]=-1e6;
  }}
  public static float Compression(float amplitude){double db=20*Math.Log10(Math.Max(1e-10,amplitude)),over=db+10,reduction=over<=-6?0:over>=6?(1.0/3-1)*over:(1.0/3-1)*Math.Pow(over+6,2)/24;return (float)Math.Pow(10,reduction/20);}
  public void MixForValidation(float[] data,int channels)=>MixSamples(data,channels);public int Voices{get{lock(gate)return voices.Count;}}
#if !UNITY_WEBGL || UNITY_EDITOR
  void OnAudioFilterRead(float[] data,int channels)=>MixSamples(data,channels);
#endif
  void MixSamples(float[] data,int channels){if(!ready)return;lock(gate){
   Array.Clear(data,0,data.Length);for(int f=0;f<data.Length/channels;f++){
    float left=0,right=0;for(int i=voices.Count-1;i>=0;i--){var v=voices[i];var c=v.clip;int frames=c.samples.Length/c.channels,p=(int)v.position;if(p>=frames){voices.RemoveAt(i);continue;}int next=Math.Min(frames-1,p+1);float fraction=(float)(v.position-p),l=Mathf.Lerp(c.samples[p*c.channels],c.samples[next*c.channels],fraction),r=c.channels==1?l:Mathf.Lerp(c.samples[p*c.channels+1],c.samples[next*c.channels+1],fraction),pan=v.pan;
     if(Math.Abs(pan)<.01){left+=l;right+=r;}else if(c.channels==1){left+=l*Mathf.Cos((pan+1)*Mathf.PI/4);right+=r*Mathf.Sin((pan+1)*Mathf.PI/4);}else if(pan<=0){left+=l+r*Mathf.Cos((pan+1)*Mathf.PI/2);right+=r*Mathf.Sin((pan+1)*Mathf.PI/2);}else{left+=l*Mathf.Cos(pan*Mathf.PI/2);right+=r+l*Mathf.Sin(pan*Mathf.PI/2);}v.position+=(double)c.rate/rate;
    }
    left*=.72f;right*=.72f;float desired=Compression(Math.Max(Math.Abs(left),Math.Abs(right))),response=1-(float)Math.Exp(-1.0/(rate*(desired<compressorGain?.003:.16)));compressorGain+=(desired-compressorGain)*response;left*=compressorGain;right*=compressorGain;OutputEnergy+=(left*left+right*right)/rate;
    if(!Muted){if(channels==1)data[f]=(left+right)*.5f;else{data[f*channels]=left;data[f*channels+1]=right;}}
   }
  }}
  void OnDestroy(){ready=false;webAudio?.Dispose();webAudio=null;if(bus)bus.Stop();if(music){music.Stop();music.clip=null;}if(silent)Destroy(silent);CancelPreparedTrack();if(LegacyMusicRetirement&&musicClip&&musicClip!=menuClip&&musicClip!=scoreClip)Resources.UnloadAsset(musicClip);musicClip=null;musicResources.Dispose();if(menuClip)Resources.UnloadAsset(menuClip);if(scoreClip)Resources.UnloadAsset(scoreClip);}
 }
}

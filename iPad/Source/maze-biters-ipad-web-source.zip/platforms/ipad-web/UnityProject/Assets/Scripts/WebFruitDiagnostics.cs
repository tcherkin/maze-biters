using System;
using System.Linq;
using UnityEngine;
namespace MazeBiters.NativeStudy {
 public sealed partial class NativeGameplayStudy {
  // Read-only status for explicit diagnostic sessions; ordinary play allocates
  // no additional arrays and never changes RNG, pickups or the simulation.
  string WebFruitState(){
   if(world==null||!Application.absoluteURL.Contains("diagnostic=1"))return "null";
   return JsonUtility.ToJson(new WebFruitSnapshot{
    revision="20261107-ten-fruits",basePoints=NativeFruitCatalog.Points,names=NativeFruitCatalog.Names,
    textureBytes=pickups?.TextureBytes??0,
    visible=world.Fruits.Select(f=>new WebFruitItem{kind=f.Kind,x=f.Cell.x,y=f.Cell.y,born=f.Born}).ToArray(),
    rendered=pickups==null?new int[0]:pickups.Poses.Where(p=>!p.egg).Select(p=>p.frame).ToArray(),
    players=Enumerable.Range(0,world.PlayerCount).Select(i=>{var p=world.GetPlayer(i);return new WebFruitPlayer{id=p.Id,x=p.Cell.x,y=p.Cell.y,score=p.Score,powerUntil=p.PowerUntil,dead=p.Dead};}).ToArray()
   });
  }
  [Serializable] sealed class WebFruitSnapshot{public string revision;public int basePoints;public string[] names;public long textureBytes;public WebFruitItem[] visible;public int[] rendered;public WebFruitPlayer[] players;}
  [Serializable] sealed class WebFruitItem{public int kind,x,y;public double born;}
  [Serializable] sealed class WebFruitPlayer{public int id,x,y,score;public double powerUntil;public bool dead;}
 }
}

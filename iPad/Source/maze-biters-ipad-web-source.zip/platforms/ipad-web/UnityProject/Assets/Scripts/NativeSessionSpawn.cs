using System;using System.Collections.Generic;using System.Linq;using UnityEngine;
namespace MazeBiters.NativeStudy {
 public sealed partial class NativeGameplayWorld {
  // Exact translation of balancedSnakeLengths/Colors, makeSnake and the
  // spawn-time head safety search. Separate from fixture-only AddSnake().
  static readonly Vector2Int[] SpawnCells={new Vector2Int(26,3),new Vector2Int(4,20),new Vector2Int(26,20),new Vector2Int(5,4),new Vector2Int(4,11),new Vector2Int(27,12),new Vector2Int(28,12),new Vector2Int(14,11),new Vector2Int(17,12)};
  List<int> SpawnColors(int count){var opening=new List<int>{1,2,3,4};if(Level<=1){Shuffle(opening);return opening.Take(count).ToList();}if(count<=4){Shuffle(opening);var set=new List<int>{0};set.AddRange(opening.Take(count-1));Shuffle(set);return set;}var result=new List<int>();while(result.Count<count){var cycle=new List<int>{1,2,3,4,0};Shuffle(cycle);if(result.Count>0&&cycle[0]==result.Last()){int j=cycle.FindIndex(c=>c!=result.Last());int x=cycle[0];cycle[0]=cycle[j];cycle[j]=x;}result.AddRange(cycle);}return result.Take(count).ToList();}
  int[] SpawnField(Vector2Int start){var field=Enumerable.Repeat(-1,Width*Height).ToArray();if(!Floor(start))return field;var q=new List<Vector2Int>{start};field[Index(start)]=0;for(int i=0;i<q.Count;i++)foreach(var d in Dirs){var p=q[i]+d;if(!Floor(p)||field[Index(p)]>=0)continue;field[Index(p)]=field[Index(q[i])]+1;q.Add(p);}return field;}
  bool SpawnPointsAtPlayer(Vector2Int p,Vector2Int d,List<int[]> fields)=>fields.Any(f=>Floor(p)&&Floor(p+d)&&f[Index(p)]>=0&&f[Index(p)]<=14&&f[Index(p+d)]>=0&&f[Index(p+d)]<f[Index(p)]);
  NativeGameplaySnake BuildSpawn(Vector2Int start,int length,Vector2Int dir){
   var taken=new HashSet<Vector2Int>(Snakes.SelectMany(s=>s.Body));bool Free(Vector2Int c,HashSet<Vector2Int> own=null)=>Floor(c)&&!taken.Contains(c)&&(own==null||!own.Contains(c))&&PlayerAt(c)==null;
   var head=start;if(!Free(head)){bool found=false;for(int r=1;r<Math.Max(Width,Height)&&!found;r++)for(int y=-r;y<=r&&!found;y++)for(int x=-r;x<=r;x++){var c=start+new Vector2Int(x,y);if(Math.Abs(x)+Math.Abs(y)==r&&Free(c)){head=c;found=true;break;}}}
   var body=new List<Vector2Int>{head};var ownCells=new HashSet<Vector2Int>(body);var best=new List<Vector2Int>(body);int explored=0;
   bool Grow(Vector2Int previous){if(body.Count>best.Count)best=new List<Vector2Int>(body);if(body.Count>=length)return true;if(++explored>12000)return false;var tail=body.Last();var options=Dirs.Where(d=>Free(tail+d,ownCells)).Select(d=>(d,priority:(d==previous?0:1)+Random()*.2)).OrderBy(a=>a.priority).ToArray();foreach(var option in options){var c=tail+option.d;body.Add(c);ownCells.Add(c);if(Grow(option.d))return true;body.RemoveAt(body.Count-1);ownCells.Remove(c);}return false;}
   Grow(-dir);if(body.Count<length)body=best;return new NativeGameplaySnake{Id=nextId++,Body=body,Cell=body[0],Dir=body.Count>1?body[0]-body[1]:dir,Palette=1,Temperament=.2+Random()*.6,TurnBias=Random()};
  }
  // Frozen browser-oracle path, used only by explicit UseLegacyAi fixtures.
  void SpawnLevelSnakesLegacy(){
   int count=Math.Min(9,Math.Max(4,3+Math.Min(2,Math.Max(0,Level-1))+Math.Max(0,Level-3)/2)),average=Math.Max(7,16-count),spread=Math.Min(4,Math.Max(1,(Level+1)/2));
   var deltas=new List<int>();if(count%2==1)deltas.Add(0);for(int pair=0;deltas.Count<count;pair++){int n=1+pair%spread;deltas.Add(-n);deltas.Add(n);}Shuffle(deltas);var colors=SpawnColors(count);Snakes.Clear();
   var fields=new List<int[]>();for(int pi=0;pi<PlayerCount;pi++){var p=GetPlayer(pi);var start=StartCell(p);if(p.Lives>0){fields.Add(SpawnField(start));foreach(var d in Dirs)if(Floor(start+d))fields.Add(SpawnField(start+d));}}
   var reserved=new HashSet<Vector2Int>();
   for(int i=0;i<count;i++){
    var start=SpawnCells[i];var options=Dirs.Where(d=>Floor(start+d)).ToArray();int choice=(int)(Random()*options.Length);var preferred=options.Length>0?options[choice]:Vector2Int.right;NativeGameplaySnake candidate=null,fallback=null;
    for(int attempt=0;attempt<48;attempt++){
     var d=attempt==0||options.Length==0?preferred:options[attempt%options.Length];var s=BuildSpawn(start,average+deltas[i],d);if(s.Body.Any(c=>reserved.Contains(c)))continue;
     bool pointed=SpawnPointsAtPlayer(s.Head,s.Dir,fields),oriented=!pointed;
     if(pointed){if(s.Body.Count==1)s.Dir=-s.Dir;else{s.Body.Reverse();s.Dir=s.Head-s.Body[1];}s.Cell=s.Head;
      var exits=Dirs.Where(e=>Floor(s.Head+e)&&!reserved.Contains(s.Head+e)&&!Occupied(s.Head+e)&&!s.Body.Take(s.Body.Count-1).Contains(s.Head+e)&&PlayerAt(s.Head+e)==null&&!SpawnPointsAtPlayer(s.Head,e,fields)).OrderByDescending(e=>e==s.Dir).ToArray();
      if(exits.Length>0){s.Dir=exits[0];oriented=true;}
     }
     if(oriented){if(pointed)reserved.Add(s.Head+s.Dir);candidate=s;break;}fallback=s;
    }
    candidate=candidate??fallback??BuildSpawn(start,average+deltas[i],preferred);candidate.Palette=colors[i];Snakes.Add(candidate);
   }
   StartingSnakeMass=Math.Max(1,Snakes.Sum(s=>s.Body.Count));
  }
 }
}

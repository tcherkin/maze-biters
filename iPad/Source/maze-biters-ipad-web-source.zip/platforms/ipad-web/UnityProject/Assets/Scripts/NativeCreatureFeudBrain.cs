using System;
using UnityEngine;
namespace MazeBiters.NativeStudy {
 public sealed partial class NativeMazeBrain {
  readonly NativeCreature[] nearbyCreatures=new NativeCreature[8];
  readonly int[] nearbyCreatureDistance=new int[8];
  NativeGameplaySnake[] cutSnakeAt;
  int[] cutDistance,cutQueue,cutRoute;
  double[] cutRisk;
  NativeHunter FindHunter(int id){foreach(var h in world.Hunters)if(h.Id==id)return h;return null;}
  void ReadCreatureThreats(NativeCreature creature){
   if(!world.CreatureFeuds)return;int count=0;
   void Insert(NativeCreature other){int d=Math.Abs(other.Cell.x-creature.Cell.x)+Math.Abs(other.Cell.y-creature.Cell.y),slot=count;
    while(slot>0&&nearbyCreatureDistance[slot-1]>d)slot--;if(slot>=8)return;
    for(int j=Math.Min(count,7);j>slot;j--){nearbyCreatures[j]=nearbyCreatures[j-1];nearbyCreatureDistance[j]=nearbyCreatureDistance[j-1];}
    nearbyCreatures[slot]=other;nearbyCreatureDistance[slot]=d;count=Math.Min(8,count+1);
   }
   if(creature is NativeHunter){foreach(var s in world.Snakes)if(s.Body.Count>0)Insert(s);}
   else if(creature is NativeGameplaySnake){foreach(var h in world.Hunters)Insert(h);}
   for(int i=0;i<count;i++)threatFields[threatCount++]=Field(nearbyCreatures[i].Cell);
  }
  // The hunter knows observed mouths and their next movement deadline, not
  // future player input or the snake brain's random decisions.
  internal double HunterStepDanger(NativeHunter hunter,Vector2Int cell){
   if(!world.CreatureFeuds)return 0;double danger=0;
   foreach(var s in world.Snakes){if(s.Body.Count==0)continue;int distance=Math.Abs(cell.x-s.Head.x)+Math.Abs(cell.y-s.Head.y);
    if(distance==0)return 100000;
    if(distance==1&&!s.Reversing){double due=Math.Max(0,s.LastMove+218-world.Time);
     danger=Math.Max(danger,cell==s.Head+s.Dir?(due<=95?1200:220):(due<=95?180:45));
    }
   }return danger;
  }
  void EnsureCutWorkspace(){int n=world.Width*world.Height;if(cutDistance!=null&&cutDistance.Length==n)return;
   cutSnakeAt=new NativeGameplaySnake[n];cutDistance=new int[n];cutQueue=new int[n];cutRoute=new int[n];cutRisk=new double[n];
  }
  bool CutPathOpen(NativeHunter hunter,Vector2Int cell){
   if(!world.Floor(cell)||occupiedForDecision[world.Index(cell)])return false;
   var player=world.PlayerAt(cell);return player==null||!Powered(player);
  }
  bool CutHasExit(NativeHunter hunter,Vector2Int cell,Vector2Int approach){
   foreach(var d in NativeGameplayWorld.Dirs){var next=cell+d;if(next==approach)continue;
    if(CutPathOpen(hunter,next)&&HunterStepDanger(hunter,next)<500)return true;
   }return false;
  }
  bool TryMischief(NativeHunter hunter,NativeBrainState state,Vector2Int origin,bool frightened,out Vector2Int goal,out int[] route){
   goal=origin;route=null;
   if(!world.CreatureFeuds||frightened||world.Time<hunter.NextCutAt){state.mischiefSnakeId=0;state.mischiefUntil=0;return false;}
   var policy=NativeCreatureFeudProfile.ForIntensity(world.DifficultyProfile.Intensity);
   if(policy.Chance<=0){state.mischiefSnakeId=0;state.mischiefUntil=0;return false;}
   if(world.Time>=state.mischiefAt){state.mischiefAt=world.Time+policy.DecisionMs;
    state.mischiefUntil=Random()<policy.Chance?state.mischiefAt:0;
   }
   if(world.Time>=state.mischiefUntil){state.mischiefSnakeId=0;return false;}
   EnsureCutWorkspace();Array.Clear(cutSnakeAt,0,cutSnakeAt.Length);
   for(int i=0;i<cutDistance.Length;i++){cutDistance[i]=-1;cutRisk[i]=0;}
   // Index the geometry cheaply; expensive occupancy/contact checks are only
   // needed for a candidate actually reached inside this bounded route search.
   foreach(var snake in world.Snakes)for(int i=1;i<snake.Body.Count-1;i++)if(world.Floor(snake.Body[i])){
    int key=world.Index(snake.Body[i]);cutSnakeAt[key]=snake;
   }
   int read=0,write=1,start=world.Index(origin),limit=(int)Math.Ceiling(policy.Notice),bestKey=-1;
   double best=double.PositiveInfinity;cutQueue[0]=start;cutDistance[start]=0;
   // Routes stop at their first body crossing: a single planned strike must not
   // assume it can cut several snakes while its attack is cooling down.
   while(read<write&&read<512){int key=cutQueue[read++],depth=cutDistance[key];if(depth>=limit)continue;var cell=new Vector2Int(key%world.Width,key/world.Width);
    foreach(var d in NativeGameplayWorld.Dirs){var next=cell+d;if(!world.Floor(next))continue;int k=world.Index(next);
     double risk=Math.Max(cutRisk[key],HunterStepDanger(hunter,next));
     if(cutSnakeAt[k]!=null){if(risk>=500||!world.HunterCanCut(hunter,cutSnakeAt[k],cutSnakeAt[k].Body.IndexOf(next))||!CutHasExit(hunter,next,cell))continue;
      double score=depth+1+risk*.025+(cutSnakeAt[k].Id==state.mischiefSnakeId?-.75:0);
      if(score<best){best=score;bestKey=k;}continue;
     }
     if(cutDistance[k]>=0||!CutPathOpen(hunter,next)||risk>=500)continue;
     cutDistance[k]=depth+1;cutRisk[k]=risk;cutQueue[write++]=k;
    }
   }
   if(bestKey<0){state.mischiefSnakeId=0;return false;}
   goal=new Vector2Int(bestKey%world.Width,bestKey/world.Width);state.mischiefSnakeId=cutSnakeAt[bestKey].Id;
   for(int i=0;i<cutRoute.Length;i++)cutRoute[i]=-1;
   read=0;write=1;cutQueue[0]=bestKey;cutRoute[bestKey]=0;
   while(read<write){int key=cutQueue[read++];var cell=new Vector2Int(key%world.Width,key/world.Width);
    foreach(var d in NativeGameplayWorld.Dirs){var next=cell+d;if(!world.Floor(next))continue;int k=world.Index(next);
     if(cutRoute[k]>=0||!CutPathOpen(hunter,next)||HunterStepDanger(hunter,next)>=500)continue;
     cutRoute[k]=cutRoute[key]+1;cutQueue[write++]=k;
    }
   }
   if(cutRoute[start]<0){state.mischiefSnakeId=0;return false;}route=cutRoute;return true;
  }
 }
}

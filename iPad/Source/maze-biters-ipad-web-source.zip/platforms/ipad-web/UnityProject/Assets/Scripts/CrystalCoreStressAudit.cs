using System;
using System.Collections.Generic;
using UnityEngine;

namespace MazeBiters.NativeStudy {
 [Serializable] public sealed class CrystalCoreStressIssue {
  public string kind;public int x,y,nx,ny;public double jump,distance,nextDistance;
 }
 [Serializable] public sealed class CrystalCoreStressResult {
  public bool passed;public int tileSize,components,coreBlocks,naturalCorners,facetSamples,neighborPairs,perimeterSamplerSamples;
  public int nonFiniteErrors,normalErrors,containmentErrors,distanceJumpFailures,independentWitnessSamples;
  public double maxNormalError,maxFacetNeighborJump,maxRawFacetNeighborJump,maxPerimeterSamplerError;
  public CrystalCoreStressIssue worstNeighbor;
  public List<CrystalCoreStressIssue> issues=new List<CrystalCoreStressIssue>();
 }
 public sealed partial class NativeMazeArtwork {
  // Opt-in, geometry-only inspection. No texture, material, simulation clock,
  // gameplay RNG or graphics device is used by this diagnostic.
  public CrystalCoreStressResult CoreStress{get;private set;}
  public static CrystalCoreStressResult InspectCrystalGeometry(string[] geometry,int tileSize,byte[] wall){
   var painter=new NativeMazeArtwork(geometry){glassSize=tileSize,glassWidth=36*tileSize,glassHeight=25*tileSize};
   painter.Topology();painter.PrepareCrystalStructure(wall);
   var result=painter.InspectPreparedCrystalGeometry(wall);painter.coreStructure=null;return result;
  }
  public CrystalCoreStressResult InspectPreparedCrystalGeometry()=>InspectPreparedCrystalGeometry(null);
  public CrystalCoreStressResult InspectPreparedCrystalGeometry(byte[] wall){
   var result=new CrystalCoreStressResult{tileSize=glassSize,components=coreStructure.territories.Count};CoreStress=result;
   foreach(var territory in coreStructure.territories)result.coreBlocks+=territory.shape.cells.Count;
   if(CoreStructureAudit.curveSamplerSamples==0)AuditCoreCurveSampler();
   result.perimeterSamplerSamples=CoreStructureAudit.curveSamplerSamples;result.maxPerimeterSamplerError=CoreStructureAudit.curveSamplerMaxError;
   var seen=new HashSet<long>();
   bool Finite(double value)=>!double.IsNaN(value)&&!double.IsInfinity(value);
   void Issue(string kind,int x,int y,int nx=0,int ny=0,double jump=0,double distance=0,double next=0){
    if(result.issues.Count<24)result.issues.Add(new CrystalCoreStressIssue{kind=kind,x=x,y=y,nx=nx,ny=ny,jump=jump,distance=distance,nextDistance=next});
   }
   void Sample(int x,int y){
    if(x<1||y<1||x>=glassWidth-1||y>=glassHeight-1)return;
    if(!seen.Add(((long)y<<32)|(uint)x))return;
    int component=CoreOwner(new CorePoint(x+.5,y+.5));if(component==0)return;
    var value=CrystalFacetAt(x,y);result.facetSamples++;
    if(!Finite(value.distance)||!Finite(value.perimeterClearance)||!Finite(value.nx)||!Finite(value.ny)){
     result.nonFiniteErrors++;Issue("non-finite-facet",x,y);return;
    }
    if(value.distance<=.12*glassSize){
     double error=Math.Abs(Math.Sqrt(value.nx*value.nx+value.ny*value.ny)-1);result.maxNormalError=Math.Max(result.maxNormalError,error);
     if(error>1e-8){result.normalErrors++;Issue("non-unit-visible-bevel-normal",x,y);}
    }
    if(value.distance>value.perimeterClearance+1e-8||value.distance>value.straightDistance+1e-8
      ||value.outsidePanelDomain!=(value.perimeterClearance<=0)){
     result.containmentErrors++;Issue("facet-outside-signed-domain",x,y);
    }
    for(int axis=0;axis<2;axis++){
     int xx=x+(axis==0?1:0),yy=y+(axis==0?0:1);if(CoreOwner(new CorePoint(xx+.5,yy+.5))!=component)continue;
     var next=CrystalFacetAt(xx,yy);if(!Finite(next.distance))continue;
     // A genuine distance field is1-Lipschitz. Allow1.8 native texels to
     // exclude harmless non-distance bevel approximations while exposing a
     // hard branch jump large enough to produce an actual dark chip.
     double jump=Math.Abs(value.distance-next.distance);result.maxRawFacetNeighborJump=Math.Max(result.maxRawFacetNeighborJump,jump);
     if(!CrystalInterior(x,y,out _,out _)||!CrystalInterior(xx,yy,out _,out _))continue;
     if(wall!=null){
      int firstMask=masks[x/glassSize,y/glassSize],secondMask=masks[xx/glassSize,yy/glassSize];
      int alpha=firstMask<0?0:wall[((y%glassSize)*16*glassSize+firstMask*glassSize+x%glassSize)*4+3];
      int nextAlpha=secondMask<0?0:wall[((yy%glassSize)*16*glassSize+secondMask*glassSize+xx%glassSize)*4+3];
      if(alpha==255||nextAlpha==255)continue;
     }
     // The painter replaces every value below the gap threshold with the same
     // blackRGBA64. Beyond the bevel both values share the same planar face.
     if(value.distance<=.0085*glassSize&&next.distance<=.0085*glassSize
       ||value.distance>=.1*glassSize&&next.distance>=.1*glassSize)continue;
     result.neighborPairs++;
     if(jump>result.maxFacetNeighborJump){result.maxFacetNeighborJump=jump;result.worstNeighbor=new CrystalCoreStressIssue{kind="worst-render-relevant-neighbor",x=x,y=y,nx=xx,ny=yy,jump=jump,distance=value.distance,nextDistance=next.distance};}
     if(jump>1.800001){result.distanceJumpFailures++;Issue("adjacent-facet-distance-jump",x,y,xx,yy,jump,value.distance,next.distance);}
    }
   }
   void Point(double x,double y){int px=(int)Math.Round(x-.5),py=(int)Math.Round(y-.5);Sample(px,py);}
   // Sample narrow strips at every real exposed component edge, including
   // small necks and close successive bends, rather than traversing full maps.
   double[] stripDepths={.265,.28,.295,.32,.35,.38};
   foreach(var edge in coreStructure.boundaries)for(int along=0;along<=8;along++){
    double t=along/8.0,x=edge.a.x+(edge.b.x-edge.a.x)*t,y=edge.a.y+(edge.b.y-edge.a.y)*t;
    foreach(double depth in stripDepths)Point(x+edge.n.x*depth*glassSize,y+edge.n.y*depth*glassSize);
   }
   for(int gy=0;gy<25;gy++)for(int gx=0;gx<36;gx++){
    int count=(Block(gx-1,gy-1)?1:0)+(Block(gx,gy-1)?1:0)+(Block(gx-1,gy)?1:0)+(Block(gx,gy)?1:0);if(count!=3)continue;
    CoreCurve curve=null;foreach(var candidate in coreStructure.curves)if(candidate.mask==masks[gx,gy]){curve=candidate;break;}if(curve==null)continue;
    result.naturalCorners++;double cx=(gx+.5)*glassSize-curve.sx*curve.shift,cy=(gy+.5)*glassSize-curve.sy*curve.shift;
    // Dense angular sampling catches the near-parallel curve/grid meeting.
    // Insets span the actual gap, polished rim and visible bevel return.
    for(int angle=0;angle<=90;angle++){
     double radians=angle*Math.PI/180,nx=curve.sx*Math.Cos(radians),ny=curve.sy*Math.Sin(radians);
     for(double depth=-2;depth<=.09*glassSize+2;depth+=1){
      double x=cx+(curve.radius+depth)*nx,y=cy+(curve.radius+depth)*ny;Point(x,y);
      if(wall!=null&&angle%15==0&&(Math.Abs(depth)<.001||Math.Abs(depth-3)<.001)){
       int px=(int)Math.Round(x-.5),py=(int)Math.Round(y-.5);if(px<0||py<0||px>=glassWidth||py>=glassHeight||!CrystalInterior(px,py,out _,out _))continue;
       int mask=masks[px/glassSize,py/glassSize],alpha=mask<0?0:wall[((py%glassSize)*16*glassSize+mask*glassSize+px%glassSize)*4+3];if(alpha>0)continue;
       var facet=CrystalFacetAt(px,py);result.independentWitnessSamples++;
       if(facet.distance>.012*glassSize&&IndependentCoreClearance(px,py,wall)<-1e-9){result.containmentErrors++;Issue("independent-perimeter-witness",px,py);}
      }
     }
    }
   }
   result.passed=result.nonFiniteErrors==0&&result.normalErrors==0&&result.containmentErrors==0&&result.distanceJumpFailures==0&&result.maxPerimeterSamplerError<1e-6;
   return result;
  }
 }
}

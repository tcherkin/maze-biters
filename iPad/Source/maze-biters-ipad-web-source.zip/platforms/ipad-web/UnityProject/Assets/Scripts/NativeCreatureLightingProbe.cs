using System;using System.Collections;using System.Collections.Generic;using System.IO;using System.Linq;using System.Reflection;using UnityEngine;
namespace MazeBiters.NativeStudy {
 // Opt-in inspection of the actual gameplay composite, never run by normal play.
 public sealed partial class NativeGameplayStudy {
  bool creatureLightingProbe;
  [Serializable] sealed class FloorLightCheck {public string source;public int fieldPixels,visiblePixels,maximumChannelDifference;}
  [Serializable] sealed class CreatureLightingReport {public string quality,error,note;public bool passed;public int width,height,wallChangedPixels,wallMaximumDifference;public float wallStrength;public string[] checks;public FloorLightCheck[] floor;}
  Texture2D CreatureLightRead(RenderTexture source){var old=RenderTexture.active;RenderTexture.active=source;var image=new Texture2D(source.width,source.height,TextureFormat.RGBA32,false);image.ReadPixels(new Rect(0,0,source.width,source.height),0,0);image.Apply();RenderTexture.active=old;return image;}
  int CreatureLightDiff(Color32[] a,Color32[] b,out int maximum){int changed=0;maximum=0;for(int i=0;i<a.Length;i++){int d=Math.Max(Math.Abs(a[i].r-b[i].r),Math.Max(Math.Abs(a[i].g-b[i].g),Math.Abs(a[i].b-b[i].b)));if(d>0)changed++;maximum=Math.Max(maximum,d);}return changed;}
  IEnumerator ProbeCreatureLighting(){
   var result=new CreatureLightingReport{quality=quality,note="Actual generated glass gameplay level; fixed clocks. Only wall reflection strength changes from 1 to 3. Floor light is inspected per existing hunter palette, fruit kind and egg state, including its contribution to the final native-resolution image. No gameplay, aura, animation or other effect tuning."};
   var checks=new List<string>();var floorChecks=new List<FloorLightCheck>();string folder=Path.GetDirectoryName(report);Directory.CreateDirectory(folder);
   void Check(bool value,string label){if(!value)throw new Exception(label);checks.Add(label);}
   IEnumerator Run(){
    NativeDisplay.TestAspect=16f/9;sessionSmoke=true;fixedCamera=true;GlassScene(1,1);yield return DrainProbePreparation();GlassExtras();yield return DrainProbePreparation();preparationLightFrame=true;Render();
    Check(NativeGlassPresentation.Enabled&&dusk.GlassLightingEnabled&&glassEmission,"approved glass and hero aura active");
    var paints=(Material[])typeof(NativeNeon).GetField("overlaysPaint",BindingFlags.NonPublic|BindingFlags.Instance).GetValue(neon);
    Check(paints[1].GetFloat("_Amount")==3,"wall strength equals 300 percent from the experiment");
    Check(paints[0].GetFloat("_Amount")==.5f&&paints[2].GetFloat("_Amount")==.38f&&paints[3].GetFloat("_Amount")==.78f&&paints[4].GetFloat("_Amount")==1,"floor halo emission and eyes retain previous strengths");
    paints[1].SetFloat("_Amount",1);camera.Render();var before=CreatureLightRead(target);var oldPixels=before.GetPixels32();File.WriteAllBytes(Path.Combine(folder,"walls-100.png"),before.EncodeToPNG());Destroy(before);
    paints[1].SetFloat("_Amount",3);camera.Render();var after=CreatureLightRead(target);result.wallChangedPixels=CreatureLightDiff(oldPixels,after.GetPixels32(),out result.wallMaximumDifference);File.WriteAllBytes(Path.Combine(folder,"walls-300.png"),after.EncodeToPNG());Destroy(after);Check(result.wallChangedPixels>0,"300 percent changes actual wall pixels");
    yield return null;
    using(var isolated=new NativePickups(quad,quality)){
     for(int kind=0;kind<11;kind++){
      double eggBorn=world.Eggs[0].Born;if(kind>=7)world.Eggs[0].Born=time-new[]{1000,10000,11000,12000}[kind-7];
      preparationLightFrame=true;Render();isolated.Clear();NativeHunterNeon[] hunters=null;string name;
      if(kind<3){hunters=new[]{actors[world.Hunters[kind].Id].neon};name="enemy-"+kind;}
      else if(kind<7){isolated.Poses.Add(pickups.Poses.First(p=>!p.egg&&p.kind==kind-3));name="fruit-"+(kind-3);}
      else{isolated.Poses.Add(pickups.Poses.First(p=>p.egg));name="egg-state-"+(kind-7);}
      // Preserve the actual complete actor coverage and emitter ownership.
      // Isolate only the floor light field and run its normal projection pass.
      neon.Field.Begin();if(hunters!=null)foreach(var h in hunters)h.Light(neon.Field);isolated.Light(neon.Field);neon.Field.Render();
      var projection=(Material)typeof(NativeNeon).GetField("project",BindingFlags.NonPublic|BindingFlags.Instance).GetValue(neon);
      var floorTarget=(RenderTexture)typeof(NativeNeon).GetField("floorProjected",BindingFlags.NonPublic|BindingFlags.Instance).GetValue(neon);
      projection.SetFloat("_Mode",0);Graphics.Blit(neon.Field.Floor,floorTarget,projection);
      var field=CreatureLightRead(neon.Field.Floor);int fieldPixels=field.GetPixels32().Count(p=>p.r>0||p.g>0||p.b>0);Destroy(field);
      camera.Render();var lit=CreatureLightRead(target);var on=lit.GetPixels32();if(kind==0||kind==3||kind==7)File.WriteAllBytes(Path.Combine(folder,name+"-floor-on.png"),lit.EncodeToPNG());Destroy(lit);
      paints[0].SetFloat("_Amount",0);camera.Render();var unlit=CreatureLightRead(target);int count=CreatureLightDiff(on,unlit.GetPixels32(),out int maximum);if(kind==0||kind==3||kind==7)File.WriteAllBytes(Path.Combine(folder,name+"-floor-off.png"),unlit.EncodeToPNG());Destroy(unlit);paints[0].SetFloat("_Amount",.5f);
      floorChecks.Add(new FloorLightCheck{source=name,fieldPixels=fieldPixels,visiblePixels=count,maximumChannelDifference=maximum});
      Check(fieldPixels>0&&count>0,name+" already illuminates the floor in the final image");world.Eggs[0].Born=eggBorn;yield return null;
     }
    }
    preparationLightFrame=true;Render();Check(paints[1].GetFloat("_Amount")==3,"full scene restores with approved wall strength");
    result.width=target.width;result.height=target.height;result.wallStrength=paints[1].GetFloat("_Amount");Check(target.width==(quality=="4k"?3840:1920)&&target.height==(quality=="4k"?2160:1080),"native HD or 4K dimensions");
   }
   var stack=new Stack<IEnumerator>();stack.Push(Run());
   while(stack.Count>0){object next=null;bool more=false;try{more=stack.Peek().MoveNext();if(more)next=stack.Peek().Current;}catch(Exception e){result.error=e.ToString();Debug.LogError(e);break;}if(!more){stack.Pop();continue;}if(next is IEnumerator nested){stack.Push(nested);continue;}yield return next;}
   result.passed=result.error==null;result.checks=checks.ToArray();result.floor=floorChecks.ToArray();File.WriteAllText(report,JsonUtility.ToJson(result,true));Application.Quit(result.passed?0:2);
  }
 }
}

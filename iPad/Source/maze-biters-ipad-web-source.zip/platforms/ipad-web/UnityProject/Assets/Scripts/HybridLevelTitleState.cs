using System;
namespace MazeBiters.NativeStudy {
 public enum HybridLevelTitleMode {Hidden,Intro,Pause,Cleared}
 // Presentation time only. No scene generation, game RNG, movement or input.
 public sealed class HybridLevelTitleState {
  public const double FadeInMs=1500,HoldMs=250,FadeOutMs=1500,DurationMs=3250,SweepMs=2480;
  public const double ZoomInMs=1000,ZoomHoldMs=1250,ZoomOutMs=1000;
  public const int SweepPasses=2;
  public const double MinimumScale=.88;
  public static readonly double PauseCycleMs=Math.PI*2*310;
  public static double PauseOpacity(double elapsed)=>Smooth(elapsed/250)*(.5+.5*Math.Cos(2*Math.PI*Math.Max(0,elapsed-250)/PauseCycleMs));
  object worldIdentity,levelIdentity;
  double levelStamp=double.NaN,lastClock=double.NaN,modeAt;
  bool playing;
  public HybridLevelTitleMode Mode{get;private set;}
  public double Elapsed{get;private set;}
  public double Alpha{get;private set;}
  // Motion and transparency have separate envelopes: the lettering grows early,
  // but only becomes fully materialized briefly around the centre of the intro.
  public double Scale=>Mode==HybridLevelTitleMode.Intro?MinimumScale+(1-MinimumScale)*Envelope(Elapsed,ZoomInMs,ZoomHoldMs,ZoomOutMs):1;
  public bool Sweep=>Mode==HybridLevelTitleMode.Intro&&Elapsed<SweepMs&&Alpha>0;
  public void Freeze(double now){lastClock=now;playing=false;}
  static double Smooth(double t){t=Math.Max(0,Math.Min(1,t));return t*t*(3-2*t);}
  static double Envelope(double elapsed,double fadeIn,double hold,double fadeOut)=>elapsed<fadeIn?Smooth(elapsed/fadeIn):elapsed<fadeIn+hold?1:1-Smooth((elapsed-fadeIn-hold)/fadeOut);
  public void Tick(object world,object level,double levelAt,double now,bool ready,bool paused,bool transition,bool gameOver,bool revealed,double clearAlpha){
   bool fresh=ready&&(!ReferenceEquals(worldIdentity,world)||!ReferenceEquals(levelIdentity,level)||levelStamp!=levelAt);
   if(fresh){worldIdentity=world;levelIdentity=level;levelStamp=levelAt;Elapsed=0;lastClock=now;playing=false;}
   bool advancing=ready&&!paused&&!transition&&!gameOver;
   if(advancing&&playing&&!double.IsNaN(lastClock))Elapsed+=Math.Max(0,now-lastClock);
   lastClock=now;playing=advancing;
   var mode=!ready||gameOver?HybridLevelTitleMode.Hidden:paused?HybridLevelTitleMode.Pause:transition?(revealed?HybridLevelTitleMode.Cleared:HybridLevelTitleMode.Hidden):Elapsed<DurationMs?HybridLevelTitleMode.Intro:HybridLevelTitleMode.Hidden;
   if(mode!=Mode||fresh){Mode=mode;modeAt=now;}
   Alpha=Mode==HybridLevelTitleMode.Intro?Envelope(Elapsed,FadeInMs,HoldMs,FadeOutMs):
    Mode==HybridLevelTitleMode.Pause?PauseOpacity(now-modeAt):Mode==HybridLevelTitleMode.Cleared?Smooth((now-modeAt)/250)*Math.Max(0,Math.Min(1,clearAlpha)):0;
  }
 }
}

using System;
using UnityEngine;

namespace MazeBiters.NativeStudy {
 // Exercise the complete native-target -> tablet-view path. In particular,
 // raw Zoom/X/Y are still catching up when a roster transition finishes.
 public static class IpadCameraBalanceValidation {
  const double ScreenTolerance=.002,ZoomTolerance=.00001;
  static readonly string[] Channels={"zoom","header","player x","player y","left sky","top sky","right edge","bottom edge"};

  sealed class Rig {
   public readonly NativeFrame Frame=new NativeFrame(4f/3,true);
   public readonly Rect Safe;
   public readonly double Close=160.0*432/(16*2064);
   public readonly NativeGameplayWorld World;
   public readonly NativeGameplayCamera Source=new NativeGameplayCamera();
   public readonly IpadCameraMotion Motion=new IpadCameraMotion();
   public readonly Vector2Int Survivor;
   public IpadView View;

   public Rig(Vector2Int survivor,bool inset,bool solo=false){
    Survivor=survivor;
    Safe=inset?new Rect(8,12,Frame.Width-16,Frame.Height-22):new Rect(0,0,Frame.Width,Frame.Height);
    var grid=new string[25];for(int i=0;i<grid.Length;i++)grid[i]=new string('.',36);
    World=new NativeGameplayWorld(grid,()=>.5);World.SetMode(solo?1:4);
    Place(World.GetPlayer(0),survivor);
    if(!solo){Place(World.GetPlayer(1),new Vector2Int(1,1));Place(World.GetPlayer(2),new Vector2Int(34,23));}
    Source.Reset(0);Sample(0);
   }

   static void Place(NativePlayer player,Vector2Int cell){
    player.Cell=player.From=player.Previous=cell;player.MoveStarted=-1e6;
    player.Dead=player.Eliminated=player.HideDeath=false;
   }

   public void LoseOthers(double real){
    for(int i=1;i<World.PlayerCount;i++){var player=World.GetPlayer(i);player.Dead=true;Motion.BeginLoss(real,player.Id);}
   }

   public void RespawnFar(double real){
    var cell=new Vector2Int(Survivor.x<18?34:1,Survivor.y<12?23:1);
    Place(World.GetPlayer(1),cell);Motion.BeginReveal(real,World.GetPlayer(1).Id);
   }

   public IpadView Sample(double real,bool presentation=false,double? game=null){
    World.Time=game??real;World.RealTime=real;
    Source.UpdateRoster(World,presentation,real,World.Time);
    var bounds=IpadCameraRoster.Bounds(World,World.Time);
    var retained=IpadCameraRoster.Bounds(World,World.Time,excludeMask:Motion.JoiningMask);
    View=Motion.Sample(Frame,Source.X,Source.Y,Source.Zoom,Close,Safe,bounds,real,
     Source.TargetX,Source.TargetY,retained,Source.TargetZoom,presentation);
    return View;
   }

   public void MoveAlongRow(Vector2Int from,Vector2Int to,double started,double real){
    var player=World.GetPlayer(0);int count=Math.Abs(to.x-from.x),direction=Math.Sign(to.x-from.x);
    double elapsed=Math.Max(0,real-started);
    if(elapsed>=count*95){Place(player,to);return;}
    int step=(int)(elapsed/95);player.From=player.Previous=new Vector2Int(from.x+direction*step,from.y);
    player.Cell=new Vector2Int(player.From.x+direction,from.y);player.MoveStarted=started+step*95;player.MoveDuration=95;
   }

   public IpadView Destination(NativeGameplayCamera source=null){
    var camera=source??Source;
    var view=IpadFraming.Calculate(Frame,camera.TargetX,camera.TargetY,camera.TargetZoom,Close,Safe);
    var bounds=IpadCameraRoster.Bounds(World,World.Time);
    return bounds.HasValue?IpadFraming.KeepPlayers(Frame,view,bounds.Value,Safe):view;
   }

   public double[] Project(IpadView view){
    double left=Frame.Width/2-view.x*view.zoom,top=Frame.Height/2-view.y*view.zoom;
    var player=World.GetPlayer(0).Visual(World.Time);
    return new[]{view.zoom,view.header,left+(player.x+.5)*16*view.zoom,top+(player.y+.5)*16*view.zoom,
     left,top,left+576*view.zoom,top+400*view.zoom};
   }
  }

  static void Visible(Rig rig,IpadView view,Rect bounds,Action<bool,string> check,string label){
   double x=rig.Frame.Width/2-view.x*view.zoom,y=rig.Frame.Height/2-view.y*view.zoom;
   check(view.zoom>0&&double.IsFinite(view.x)&&double.IsFinite(view.y)&&double.IsFinite(view.zoom)&&double.IsFinite(view.header),label+" finite transform");
   check(x+(bounds.xMin-12)*view.zoom>=rig.Safe.xMin-ScreenTolerance&&
    x+(bounds.xMax+12)*view.zoom<=rig.Safe.xMax+ScreenTolerance&&
    y+(bounds.yMin-12)*view.zoom>=Math.Max(rig.Safe.yMin,view.header)-ScreenTolerance&&
    y+(bounds.yMax+12)*view.zoom<=rig.Safe.yMax+ScreenTolerance,label+" retained silhouettes visible");
  }

  static void SameProjection(double[] actual,double[] expected,Action<bool,string> check,string label){
   for(int c=0;c<actual.Length;c++)check(Math.Abs(actual[c]-expected[c])<=(c==0?ZoomTolerance:ScreenTolerance),
    label+" "+Channels[c]+" ("+actual[c]+" / "+expected[c]+")");
  }

  static void Toward(double[] current,double[] previous,double[] start,double[] end,Action<bool,string> check,string label){
   for(int c=0;c<current.Length;c++){
    double tolerance=c==0?ZoomTolerance:ScreenTolerance,direction=Math.Sign(end[c]-start[c]);
    check(current[c]>=Math.Min(start[c],end[c])-tolerance&&current[c]<=Math.Max(start[c],end[c])+tolerance,
     label+" "+Channels[c]+" stays between endpoints");
    check(direction==0?Math.Abs(current[c]-previous[c])<=tolerance:direction*(current[c]-previous[c])>=-tolerance,
     label+" "+Channels[c]+" never reverses");
   }
  }

  static void SoloStartup(Vector2Int cell,bool inset,int hz,Action<bool,string> check){
   var rig=new Rig(cell,inset,true);string name="bounded SOLO startup "+cell+" "+hz+" Hz"+(inset?" inset":"");
   var start=rig.Project(rig.View);var end=rig.Project(rig.Destination());var previous=start;double[] settled=null;
   check(rig.Source.Subjects==1&&rig.Source.TargetZoom==2&&!rig.Motion.Revealing,name+" normal follow starts without a roster event");
   for(int i=1;i<=hz*24;i++){
    double real=i*1000.0/hz;var view=rig.Sample(real);var projected=rig.Project(view);string sample=name+" at "+real;
    Visible(rig,view,IpadCameraRoster.Bounds(rig.World,real).Value,check,sample);
    Toward(projected,previous,start,end,check,sample);
    if(real<=8000){
     // Use the original native camera as a second oracle. Static edge bounds
     // must not select an emergency response and accelerate ordinary SOLO.
     double progress=(view.zoom-start[0])/(end[0]-start[0]),expected=1-Math.Exp(-real/1040);
     check(Math.Abs(progress-expected)<ZoomTolerance,sample+" normalized original 1040 ms zoom response");
     check(Math.Abs(progress-(rig.Source.Zoom-1))<ZoomTolerance,sample+" matches native SOLO zoom progress");
     var expectedProjection=new double[start.Length];
     for(int c=0;c<start.Length;c++)expectedProjection[c]=start[c]+(end[c]-start[c])*expected;
     SameProjection(projected,expectedProjection,check,sample+" coherent startup projection");
    }
    if(real>=16000){
     SameProjection(projected,end,check,sample+" settled original endpoint");
     if(settled==null)settled=projected;else SameProjection(projected,settled,check,sample+" eight-second stable endpoint");
    }
    previous=projected;
   }
  }

  static IpadView StationaryLoss(Vector2Int cell,bool inset,int hz,Action<bool,string> check){
   var rig=new Rig(cell,inset);string name="loss "+cell+" "+hz+" Hz"+(inset?" inset":"");
   var start=rig.Project(rig.View);
   check(rig.Source.Subjects==3&&Math.Abs(rig.Source.TargetZoom-1)<1e-12,name+" begins with full roster overview");
   rig.LoseOthers(0);rig.Sample(0);
   SameProjection(rig.Project(rig.View),start,check,name+" event has no coordinate step");
   check(rig.Source.Living==1&&rig.Source.Subjects==1&&rig.Source.TargetZoom==2,name+" native stationary survivor target");
   double px=(cell.x+.5)*16,py=(cell.y+.5)*16;
   check(rig.Source.TargetX==Math.Max(144,Math.Min(432,px))&&rig.Source.TargetY==Math.Max(100,Math.Min(300,py)),
    name+" uses clamped native centre");
   var destination=rig.Destination();var end=rig.Project(destination);var previous=start;
   var bounds=new Rect((float)px,(float)py,0,0);double[] settled=null;
   int frames=(int)Math.Ceiling((IpadCameraMotion.DeathDuration+8000)*hz/1000);
   for(int i=1;i<=frames;i++){
    double real=i*1000.0/hz;var view=rig.Sample(real);var projected=rig.Project(view);string sample=name+" at "+real;
    Toward(projected,previous,start,end,check,sample);Visible(rig,view,bounds,check,sample);
    if(real>=IpadCameraMotion.DeathDuration){
     check(!rig.Motion.Revealing,sample+" death has settled");
     SameProjection(projected,end,check,sample+" exact stationary endpoint");
     if(settled==null)settled=projected;else SameProjection(projected,settled,check,sample+" no endpoint rebound or sky drift");
    }
    previous=projected;
   }
   // Check decorative balance in projected space, where an apparently stable
   // centre can still expose extra sky if another zoom stage is moving.
   var board=rig.Frame.ProjectBoard(rig.View.x,rig.View.y,rig.View.zoom);
   if(cell.x==1)check(Math.Abs(board.x-52)<ScreenTolerance,name+" left sky is 52");
   if(cell.x==34)check(Math.Abs(rig.Frame.Width-board.xMax-52)<ScreenTolerance,name+" right sky is 52");
   if(cell.y==1)check(Math.Abs(board.y-52)<ScreenTolerance,name+" top sky is 52");
   if(cell.y==23)check(Math.Abs(rig.Frame.Height-board.yMax-52)<ScreenTolerance,name+" bottom sky is 52");
   return rig.View;
  }

  static IpadView InterruptedLoss(Vector2Int cell,bool inset,int hz,Action<bool,string> check){
   var rig=new Rig(cell,inset);string name="interrupted loss "+cell+" "+hz+" Hz"+(inset?" inset":"");
   rig.LoseOthers(0);
   for(int i=1;i<=hz/2;i++)rig.Sample(i*1000.0/hz);
   var before=rig.Project(rig.View);rig.RespawnFar(500);rig.Sample(500);
   SameProjection(rig.Project(rig.View),before,check,name+" respawn has no coordinate step");
   var retained=IpadCameraRoster.Bounds(rig.World,500,excludeMask:rig.Motion.JoiningMask);
   var active=IpadCameraRoster.Bounds(rig.World,500);
   check(rig.Source.Living==2&&rig.Source.Subjects==2&&rig.Motion.JoiningMask==(1<<1),name+" actual birth starts reveal");
   check(retained.HasValue&&active.HasValue&&retained.Value.width==0&&retained.Value.height==0&&
    (active.Value.width>0||active.Value.height>0),name+" retained bounds exclude distant joining actor");
   // A new destination may legitimately reverse the previous travel. It must
   // not teleport the transform when the first nonzero time sample arrives.
   var immediate=rig.Project(rig.Sample(500.01));
   for(int c=0;c<immediate.Length;c++)check(Math.Abs(immediate[c]-before[c])<(c==0?.0001:.05),
    name+" first advancing sample is continuous: "+Channels[c]);
   var end=rig.Project(rig.Destination());double[] settled=null;
   int frames=(int)Math.Ceiling((IpadCameraMotion.RevealDuration+8000)*hz/1000);
   for(int i=1;i<=frames;i++){
    double elapsed=i*1000.0/hz,real=500+elapsed;var view=rig.Sample(real);var projected=rig.Project(view);string sample=name+" at "+real;
    Visible(rig,view,retained.Value,check,sample);
    if(elapsed>=IpadCameraMotion.RevealDuration){
     check(!rig.Motion.Revealing&&rig.Motion.JoiningMask==0,sample+" reveal has settled");
     Visible(rig,view,active.Value,check,sample+" complete roster");
     SameProjection(projected,end,check,sample+" stationary roster endpoint");
     if(settled==null)settled=projected;else SameProjection(projected,settled,check,sample+" no later rebound or sky drift");
    }
   }
   return rig.View;
  }

  static void PauseDuringLoss(Vector2Int cell,bool inset,int hz,Action<bool,string> check){
   var rig=new Rig(cell,inset);string name="pause during loss "+cell+" "+hz+" Hz"+(inset?" inset":"");
   rig.LoseOthers(0);for(int i=1;i<=hz/2;i++)rig.Sample(i*1000.0/hz);
   var before=rig.Project(rig.View);rig.Sample(500,true,500);
   SameProjection(rig.Project(rig.View),before,check,name+" pausing has no coordinate step");
   check(rig.Source.Presentation&&rig.Source.Subjects==0&&rig.Source.TargetZoom==1,name+" native pause requests overview");
   double Phase(double started,bool paused){
    var first=rig.Project(rig.View);var end=rig.Project(rig.Destination());var previous=first;double[] settled=null;
    int frames=(int)Math.Ceiling((IpadCameraMotion.DeathDuration+8000)*hz/1000);
    for(int i=1;i<=frames;i++){
     double elapsed=i*1000.0/hz;var view=rig.Sample(started+elapsed,paused,paused?500:500+elapsed);
     var projected=rig.Project(view);string sample=name+(paused?" paused":" resumed")+" at "+elapsed;
     Toward(projected,previous,first,end,check,sample);
     Visible(rig,view,IpadCameraRoster.Bounds(rig.World,rig.World.Time).Value,check,sample);
     if(elapsed>=IpadCameraMotion.DeathDuration){
      check(!rig.Motion.Revealing,sample+" presentation transition finished");
      SameProjection(projected,end,check,sample+" exact stationary endpoint");
      if(settled==null)settled=projected;else SameProjection(projected,settled,check,sample+" no pause/resume rebound");
     }
     previous=projected;
    }
    return started+frames*1000.0/hz;
   }
   double resume=Phase(500,true);before=rig.Project(rig.View);rig.Sample(resume,false,500);
   SameProjection(rig.Project(rig.View),before,check,name+" resuming has no coordinate step");
   check(!rig.Source.Presentation&&rig.Source.Subjects==1&&rig.Source.TargetZoom==2,name+" native resume restores survivor target");
   Phase(resume,false);
  }

  static void StopAtEdge(bool reveal,bool mirror,bool inset,int hz,Action<bool,string> check){
   var from=new Vector2Int(reveal?(mirror?18:17):(mirror?26:9),mirror?23:1);
   var to=new Vector2Int(mirror?34:1,from.y);var rig=new Rig(from,inset);
   string name="edge stop during "+(reveal?"reveal":"loss")+" "+to+" "+hz+" Hz"+(inset?" inset":"");
   rig.LoseOthers(0);double started=0;
   if(reveal){for(int i=1;i<=hz*4;i++)rig.Sample(i*1000.0/hz);started=4000;rig.RespawnFar(started);}
   rig.Sample(started);
   // Consecutive original 95 ms moves reach the edge at 760/1520 ms,
   // approximately halfway through the death/reveal respectively.
   double stopped=started+Math.Abs(to.x-from.x)*95;
   bool actorStopped=false,nativeSettled=false;double stableAt=double.NaN,lastReal=started;double[] finish=null,stoppedFrom=null,previous=null,settled=null;
   int frames=(int)Math.Ceiling((stopped-started+24000)*hz/1000);
   for(int i=1;i<=frames;i++){
    double real=started+i*1000.0/hz;lastReal=real;rig.MoveAlongRow(from,to,started,real);
    var view=rig.Sample(real);var projected=rig.Project(view);string sample=name+" at "+real;
    var retained=IpadCameraRoster.Bounds(rig.World,real,excludeMask:rig.Motion.JoiningMask);
    Visible(rig,view,retained.Value,check,sample);
    check(projected[4]<=52+ScreenTolerance&&projected[5]<=52+ScreenTolerance&&
     rig.Frame.Width-projected[6]<=52+ScreenTolerance&&rig.Frame.Height-projected[7]<=52+ScreenTolerance,
     sample+" moving camera does not expose excess sky");
    if(real>=stopped){
     if(!actorStopped){
      // A fresh native camera sees the real stopped roster without residual
      // motion-speed history, providing its eventual stationary destination.
      var stationary=new NativeGameplayCamera();stationary.Reset(0);stationary.UpdateRoster(rig.World,false,0,real);
      finish=rig.Project(rig.Destination(stationary));stoppedFrom=previous=projected;actorStopped=true;
     }
     Toward(projected,previous,stoppedFrom,finish,check,sample+" after the survivor stops");previous=projected;
    }
    if(!nativeSettled&&real>=stopped&&rig.Source.MotionZoom==2){
     nativeSettled=true;SameProjection(rig.Project(rig.Destination()),finish,check,sample+" live native target reaches stationary oracle");
    }
    if(nativeSettled){
     if(double.IsNaN(stableAt)&&!rig.Motion.Revealing){
      bool reached=true;for(int c=0;c<projected.Length;c++)reached&=Math.Abs(projected[c]-finish[c])<1e-7;
      if(reached){stableAt=real;settled=projected;}
     }
     if(!double.IsNaN(stableAt)){
      SameProjection(projected,finish,check,sample+" final stationary endpoint");
      SameProjection(projected,settled,check,sample+" eight-second no recoil or sky drift");
      if(real-stableAt>=8000)break;
     }
    }
   }
   check(nativeSettled,name+" native motion-speed target eventually settles");
   check(!double.IsNaN(stableAt)&&lastReal-stableAt>=8000,name+" visible endpoint settles and remains fixed for eight seconds");
  }

  public static int Run(){
   int checks=0;void Check(bool ok,string label){checks++;if(!ok)throw new Exception("iPad camera balance: "+label);}
   var cells=new[]{new Vector2Int(17,12),new Vector2Int(1,12),new Vector2Int(34,12),new Vector2Int(17,1),
    new Vector2Int(17,23),new Vector2Int(1,1),new Vector2Int(34,1),new Vector2Int(1,23),new Vector2Int(34,23)};
   foreach(bool inset in new[]{false,true})foreach(var cell in cells){
    var at60=StationaryLoss(cell,inset,60,Check);var at120=StationaryLoss(cell,inset,120,Check);
    Check(Math.Abs(at60.x-at120.x)<ScreenTolerance&&Math.Abs(at60.y-at120.y)<ScreenTolerance&&Math.Abs(at60.zoom-at120.zoom)<ZoomTolerance,
     "death endpoint agrees at 60/120 Hz "+cell+" inset="+inset);
    at60=InterruptedLoss(cell,inset,60,Check);at120=InterruptedLoss(cell,inset,120,Check);
    Check(Math.Abs(at60.x-at120.x)<ScreenTolerance&&Math.Abs(at60.y-at120.y)<ScreenTolerance&&Math.Abs(at60.zoom-at120.zoom)<ZoomTolerance,
     "interrupted reveal endpoint agrees at 60/120 Hz "+cell+" inset="+inset);
   }
   foreach(bool inset in new[]{false,true})foreach(int hz in new[]{60,120})foreach(bool mirror in new[]{false,true}){
    PauseDuringLoss(new Vector2Int(mirror?34:1,mirror?23:1),inset,hz,Check);
    StopAtEdge(false,mirror,inset,hz,Check);StopAtEdge(true,mirror,inset,hz,Check);
   }
   foreach(bool inset in new[]{false,true})foreach(int hz in new[]{60,120})
    foreach(var cell in new[]{new Vector2Int(17,12),new Vector2Int(1,1),new Vector2Int(34,23)})SoloStartup(cell,inset,hz,Check);
   return checks;
  }
 }
}

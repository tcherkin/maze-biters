using System;using System.Linq;using System.IO;using System.Collections;using System.Collections.Generic;using UnityEngine;
namespace MazeBiters.NativeStudy {
 public sealed partial class NativeGameplayStudy {
  void StageVersusKnockout(int serial){
   var winner=world.GetPlayer(serial%2);var victim=world.GetPlayer(1-serial%2);
   if(winner.Dead||victim.Dead)throw new Exception("VS performance fixture: respawn not complete");
   Vector2Int cell=default;bool found=false;
   for(int y=1;y<world.Height-1&&!found;y++)for(int x=1;x<world.Width-2&&!found;x++){var c=new Vector2Int(x,y);bool Free(Vector2Int q)=>world.Floor(q)&&!world.SolidEgg(q)&&!world.Occupied(q)&&!world.HunterAt(q)&&!world.ScorpionAt(q);if(Free(c)&&Free(c+Vector2Int.right)){cell=c;found=true;}}
   if(!found)throw new Exception("No open VS performance encounter");
   winner.Cell=winner.From=winner.Previous=cell;victim.Cell=victim.From=victim.Previous=cell+Vector2Int.right;
   winner.Dir=winner.Next=Vector2Int.right;victim.Dir=victim.Next=Vector2Int.left;
   winner.Waiting=false;victim.Waiting=true;winner.ShieldUntil=time+1e6;victim.ShieldUntil=0;
   using(world.ForPlayer(winner))world.AdvancePlayer();winner.LastMove=time;victim.LastMove=time;
   if(!victim.Dead)throw new Exception("VS performance encounter did not resolve");
  }
  IEnumerator ProbeVersusContacts(List<string> checks){
   void Check(bool b,string n){if(!b)throw new Exception("Live VS: "+n);checks.Add(n);}
   foreach(int winnerId in Enumerable.Range(1,DuoAiMode?3:2))foreach(int victimId in Enumerable.Range(1,DuoAiMode?3:2).Where(id=>id!=winnerId))foreach(string rule in new[]{"score","power","shield"}){
    CoopFixture();world.SessionEnabled=true;yield return DrainProbePreparation();
    var winner=world.PlayerById(winnerId);var victim=world.PlayerById(victimId);
    winner.Cell=winner.From=winner.Previous=new Vector2Int(winnerId==1?3:4,1);winner.Dir=winner.Next=winnerId==1?Vector2Int.right:Vector2Int.left;
    victim.Cell=victim.From=victim.Previous=winner.Cell+winner.Dir;victim.Dir=victim.Next=-winner.Dir;
    winner.Waiting=false;victim.Waiting=true;winner.ShieldUntil=victim.ShieldUntil=0;
    winner.Score=rule=="score"?500:100;winner.ExactScore=winner.Score;victim.Score=rule=="score"?100:500;victim.ExactScore=victim.Score;
    if(rule=="power")using(world.ForPlayer(winner))world.ActivatePower();
    if(rule=="shield"){winner.ShieldUntil=time+4360;victim.PowerUntil=time+7000;}
    Render();int score=winner.Score;using(world.ForPlayer(winner))world.AdvancePlayer();
    Check(victim.Dead&&victim.Lives==2&&!winner.Dead&&winner.Score==score+1000,"P"+winnerId+" wins by "+rule);
    Check(winner.BiteEnd>time&&world.LeaderId==winnerId&&!world.GameOverPending,"P"+winnerId+" bite/leader/survivor "+rule);
    for(int f=0;f<55;f++){time+=1000.0/120;world.Time=time;realClock+=1000.0/120;world.RealTime=realClock;Render();if(f==8||f==35)Capture(Path.ChangeExtension(report,null)+"-vs-p"+winnerId+"-victim"+victimId+"-"+rule+"-"+f+".png");yield return null;}
   }
   CoopFixture();world.SessionEnabled=true;yield return DrainProbePreparation();
   var a=world.GetPlayer(0);var b=world.GetPlayer(1);a.Cell=a.From=a.Previous=new Vector2Int(3,1);b.Cell=b.From=b.Previous=new Vector2Int(4,1);a.Dir=a.Next=Vector2Int.right;b.Dir=b.Next=Vector2Int.left;a.Waiting=b.Waiting=false;
   using(world.ForPlayer(a))world.AdvancePlayer();using(world.ForPlayer(b))world.AdvancePlayer();
   Check(a.Cell.x==3&&b.Cell.x==4&&!a.Dead&&!b.Dead,"equal-score rivals block without overlap");
   a.ShieldUntil=b.ShieldUntil=time+100;using(world.ForPlayer(a))world.AdvancePlayer();Check(a.Cell.x==3&&!b.Dead,"both shields block");
   a.ShieldUntil=b.ShieldUntil=0;a.Score=100;b.Score=500;using(world.ForPlayer(a))world.AdvancePlayer();
   Check(a.Dead&&!b.Dead&&b.Score==1500,"weaker keyboard attacker loses to stationary defender");
   // Recreate generated roster afterwards: the main probe checks both actors'
   // remaining intake, all turns/blinks, respawn, next-level and GAME OVER.
  }
 }
}

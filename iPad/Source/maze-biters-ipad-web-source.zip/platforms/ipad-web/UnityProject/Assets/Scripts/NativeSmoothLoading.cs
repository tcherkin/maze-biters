using System;
namespace MazeBiters.NativeStudy {
 public static class NativeSmoothLoading {
  public static readonly bool Enabled=NativeBalancedLaunch.Distributed&&Array.IndexOf(Environment.GetCommandLineArgs(),"--legacy-smooth-loading")<0;
  public static readonly bool Profile=Array.IndexOf(Environment.GetCommandLineArgs(),"--smooth-loading-profile")>=0;
 }
}

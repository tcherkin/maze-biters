using System;
using System.Collections.Generic;
using System.Linq;
using UnityEngine;

namespace MazeBiters.NativeStudy {
 public sealed partial class NativeMazeGenerator {
  // A visible junction is not necessarily a useful escape. Both onward routes
  // must independently leave this neighbourhood, without returning up the stem,
  // and remain in the cyclic core. Two long blind branches are not an escape.
  // This also rejects little L-shaped spawn spurs and loops behind a single gate.
  public const int MaxStartChoiceDistance=6;
  public const int StartExitRadius=10;
  public const int MaxStartEditRadius=10;
  public int StartAccessOpenedWalls { get; private set; }

  static int StartDistance(Vector2Int a,Vector2Int b)=>Math.Abs(a.x-b.x)+Math.Abs(a.y-b.y);
  bool StartAnchor(Vector2Int p)=>(p.x==2||p.x==W-3)&&(p.y==2||p.y==H-3);
  bool StartWallCanOpen(Vector2Int p)=>Inside(p)&&At(p)=='#'&&!StartAnchor(p)&&!points.Contains(p)&&!diagonal.Contains(p);

  List<Vector2Int> StartWallCopies(Vector2Int p){
   var copies=Copies(p.x,p.y);
   // A late feature can make one mirrored position protected. In that case the
   // local safety opening wins, without damaging the feature on the other side.
   if(copies.Any(q=>At(q)=='#'&&!StartWallCanOpen(q)))return new List<Vector2Int>{p};
   return copies;
  }

  void EnsureStartAccess(){
   foreach(var start in Starts()){
    var origin=P(start.x,start.y);
    if(FindStartChoice(origin)>=0)continue;
    List<Vector2Int> openings=null;
    var outside=StartOutsideComponents(origin);
    // Normally one thin separator is enough. Only broaden the local search
    // when a longer solid feature prevents that; never alter the outer wall.
    foreach(int radius in new[]{6,8,StartExitRadius}){
     var plan=StartSharedExitRoutes(origin,radius,outside);
     if(plan!=null){openings=plan.Openings;break;}
    }
    if(openings==null)throw new InvalidOperationException("Unable to provide independent maze routes near start "+origin+" at level "+stage+".");
    foreach(var cell in openings)foreach(var copy in StartWallCopies(cell)){
     if(At(copy)!='#')continue;
     Open(copy);
     if(At(copy)=='.')StartAccessOpenedWalls++;
    }
    if(FindStartChoice(origin)<0)throw new InvalidOperationException("Maze start-access repair did not create independent escape routes at "+origin+".");
   }
  }

  int FindStartChoice(Vector2Int origin){
   var core=StartCyclicCore();
   var distance=Enumerable.Repeat(-1,W*H).ToArray();
   var parent=Enumerable.Repeat(-1,W*H).ToArray();
   var queue=new List<Vector2Int>{origin};int source=origin.y*W+origin.x;distance[source]=0;
   for(int read=0;read<queue.Count;read++){
    var cell=queue[read];int id=cell.y*W+cell.x,steps=distance[id];
    int exits=0;foreach(var direction in D)if(At(cell+direction)=='.')exits++;
    if(core[id]&&exits>=(steps==0?2:3)){
     var blocked=new bool[W*H];
     for(int previous=parent[id];previous>=0;previous=parent[previous])blocked[previous]=true;
     if(StartRoutes(cell,origin,blocked,0,core)!=null)return steps;
    }
    if(steps==MaxStartChoiceDistance)continue;
    foreach(var direction in D){
     var next=cell+direction;int nextId=next.y*W+next.x;
     if(!Inside(next)||At(next)!='.'||distance[nextId]>=0)continue;
     distance[nextId]=steps+1;parent[nextId]=id;queue.Add(next);
    }
   }
   return -1;
  }

  bool[] StartCyclicCore(){
   var core=new bool[W*H];var degree=new int[W*H];var queue=new Queue<Vector2Int>();
   for(int y=1;y<H-1;y++)for(int x=1;x<W-1;x++){
    var cell=P(x,y);int id=y*W+x;if(At(cell)!='.')continue;core[id]=true;
    foreach(var direction in D)if(At(cell+direction)=='.')degree[id]++;
    if(degree[id]<=1)queue.Enqueue(cell);
   }
   while(queue.Count>0){
    var cell=queue.Dequeue();int id=cell.y*W+cell.x;if(!core[id])continue;core[id]=false;
    foreach(var direction in D){var next=cell+direction;if(!Inside(next))continue;int nextId=next.y*W+next.x;if(core[nextId]&&--degree[nextId]==1)queue.Enqueue(next);}
   }
   return core;
  }

  int[] StartOutsideComponents(Vector2Int origin){
   var labels=Enumerable.Repeat(-1,W*H).ToArray();int component=0;var queue=new Queue<Vector2Int>();
   for(int y=1;y<H-1;y++)for(int x=1;x<W-1;x++){
    var cell=P(x,y);int id=y*W+x;
    if(At(cell)!='.'||StartDistance(cell,origin)<=StartExitRadius||labels[id]>=0)continue;
    labels[id]=component;queue.Enqueue(cell);
    while(queue.Count>0){
     var current=queue.Dequeue();
     foreach(var direction in D){
      var next=current+direction;if(!Inside(next)||At(next)!='.'||StartDistance(next,origin)<=StartExitRadius)continue;
      int nextId=next.y*W+next.x;if(labels[nextId]>=0)continue;labels[nextId]=component;queue.Enqueue(next);
     }
    }
    component++;
   }
   return labels;
  }

  StartRoutePlan StartSharedExitRoutes(Vector2Int origin,int radius,int[] outside){
   // Both new routes must meet again OUTSIDE the local region. That closes a
   // real bypass: two unrelated blind branches cannot pass by reaching radius10.
   var outletCounts=new SortedDictionary<int,int>();
   for(int y=Math.Max(1,origin.y-StartExitRadius);y<=Math.Min(H-2,origin.y+StartExitRadius);y++)
    for(int x=Math.Max(1,origin.x-StartExitRadius);x<=Math.Min(W-2,origin.x+StartExitRadius);x++){
     var cell=P(x,y);if(StartDistance(cell,origin)!=StartExitRadius)continue;
     if(At(cell)!='.'&&(radius<StartExitRadius||!StartWallCanOpen(cell)))continue;
     var touching=new HashSet<int>();
     foreach(var direction in D){var next=cell+direction;if(Inside(next)&&outside[next.y*W+next.x]>=0)touching.Add(outside[next.y*W+next.x]);}
     foreach(int label in touching){int count;outletCounts.TryGetValue(label,out count);outletCounts[label]=count+1;}
    }
   StartRoutePlan best=null;
   foreach(var item in outletCounts){
    if(item.Value<2)continue;
    var plan=StartRoutes(origin,origin,null,radius,null,outside,item.Key);
    if(plan!=null&&(best==null||plan.Cost<best.Cost))best=plan;
   }
   return best;
  }

  sealed class StartRoutePlan { public List<Vector2Int> Openings;public int Cost; }

  // Vertex-split min-cost flow, limited to at most 66 tiles around a corner and
  // exactly two augmentations. Floors cost only travel; any extra removed wall
  // costs much more than every possible path combined. No RNG is consumed.
  StartRoutePlan StartRoutes(Vector2Int source,Vector2Int origin,bool[] blocked,int carveRadius,bool[] core=null,int[] outside=null,int outsideLabel=-1){
   var ids=Enumerable.Repeat(-1,W*H).ToArray();var cells=new List<Vector2Int>();
   for(int y=Math.Max(1,origin.y-StartExitRadius);y<=Math.Min(H-2,origin.y+StartExitRadius);y++)
    for(int x=Math.Max(1,origin.x-StartExitRadius);x<=Math.Min(W-2,origin.x+StartExitRadius);x++){
     var cell=P(x,y);int distance=StartDistance(cell,origin),id=y*W+x;
     if(distance>StartExitRadius||(blocked!=null&&blocked[id]))continue;
     if(core!=null&&!core[id])continue;
     if(At(cell)!='.'&&(carveRadius==0||distance>carveRadius||!StartWallCanOpen(cell)))continue;
     ids[id]=cells.Count;cells.Add(cell);
    }
   int sourceId=ids[source.y*W+source.x];if(sourceId<0)return null;
   int sink=cells.Count*2;var graph=new StartFlowGraph(sink+1);var tileEdges=new StartFlowEdge[cells.Count];
   for(int i=0;i<cells.Count;i++){
    var cell=cells[i];bool wall=At(cell)=='#';int cost=0;
    if(wall){
     int copies=StartWallCopies(cell).Count(q=>At(q)=='#');
     cost=copies*100000+StartDistance(cell,origin)*20;
     // Prefer a clean connector over widening an existing passage into a room.
     for(int dy=-1;dy<=0;dy++)for(int dx=-1;dx<=0;dx++){
      int floors=0;for(int yy=0;yy<2;yy++)for(int xx=0;xx<2;xx++)if(At(cell.x+dx+xx,cell.y+dy+yy)=='.')floors++;
      if(floors==3)cost+=1000;
     }
    }
    tileEdges[i]=graph.Add(i*2,i*2+1,i==sourceId?2:1,cost);
    if(StartDistance(cell,origin)==StartExitRadius){
     bool outlet=outside==null&&!wall;
     if(outside!=null)foreach(var direction in D){var next=cell+direction;if(Inside(next)&&outside[next.y*W+next.x]==outsideLabel){outlet=true;break;}}
     if(outlet)graph.Add(i*2+1,sink,1,0);
    }
    foreach(var direction in D){
     var next=cell+direction;if(!Inside(next))continue;int nextId=ids[next.y*W+next.x];
     if(nextId>=0)graph.Add(i*2+1,nextId*2,2,1);
    }
   }
   int totalCost;if(!graph.SendTwo(sourceId*2,sink,out totalCost))return null;
   var result=new List<Vector2Int>();
   for(int i=0;i<cells.Count;i++)if(At(cells[i])=='#'&&tileEdges[i].Capacity==0)result.Add(cells[i]);
   return new StartRoutePlan{Openings=result,Cost=totalCost};
  }

  sealed class StartFlowEdge {
   public int To,Reverse,Capacity,Cost;
  }
  sealed class StartFlowGraph {
   readonly List<StartFlowEdge>[] edges;
   public StartFlowGraph(int count){edges=new List<StartFlowEdge>[count];for(int i=0;i<count;i++)edges[i]=new List<StartFlowEdge>();}
   public StartFlowEdge Add(int from,int to,int capacity,int cost){
    var edge=new StartFlowEdge{To=to,Reverse=edges[to].Count,Capacity=capacity,Cost=cost};
    var back=new StartFlowEdge{To=from,Reverse=edges[from].Count,Capacity=0,Cost=-cost};
    edges[from].Add(edge);edges[to].Add(back);return edge;
   }
   public bool SendTwo(int source,int sink,out int totalCost){
    int count=edges.Length;totalCost=0;
    for(int flow=0;flow<2;flow++){
     var distance=Enumerable.Repeat(int.MaxValue,count).ToArray();var previous=new int[count];var edgeIndex=new int[count];var queued=new bool[count];var queue=new Queue<int>();
     distance[source]=0;queue.Enqueue(source);queued[source]=true;
     while(queue.Count>0){
      int from=queue.Dequeue();queued[from]=false;
      for(int i=0;i<edges[from].Count;i++){
       var edge=edges[from][i];if(edge.Capacity==0||distance[edge.To]<=distance[from]+edge.Cost)continue;
       distance[edge.To]=distance[from]+edge.Cost;previous[edge.To]=from;edgeIndex[edge.To]=i;
       if(!queued[edge.To]){queue.Enqueue(edge.To);queued[edge.To]=true;}
      }
     }
     if(distance[sink]==int.MaxValue)return false;
     totalCost+=distance[sink];
     for(int to=sink;to!=source;to=previous[to]){var edge=edges[previous[to]][edgeIndex[to]];edge.Capacity--;edges[to][edge.Reverse].Capacity++;}
    }
    return true;
   }
  }

  // Uses the production pass for editor topology fixtures; real generation also
  // supplies its feature-protection sets and the selected symmetry style.
  public static string[] RepairStartAccessGeometry(string[] geometry){
   if(geometry==null||geometry.Length!=H||geometry.Any(row=>row==null||row.Length!=W))throw new ArgumentException("Start-access geometry must be 36 by 25.",nameof(geometry));
   var generator=new NativeMazeGenerator(0){g=geometry.Select(row=>row.ToCharArray()).ToArray(),style="asymmetric",stage=1};
   foreach(var start in Starts())if(generator.At(start.x,start.y)!='.')throw new ArgumentException("Every supported start must be open.",nameof(geometry));
   generator.EnsureStartAccess();return generator.g.Select(row=>new string(row)).ToArray();
  }
 }
}

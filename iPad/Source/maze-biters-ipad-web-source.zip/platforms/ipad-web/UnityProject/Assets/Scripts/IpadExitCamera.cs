using System;
namespace MazeBiters.NativeStudy {
 // A finite presentation shot, independent of player tracking and simulation.
 // The interpolation is affine on screen: both scale and translation share
 // one progress value, so recentering cannot overtake the zoom and recoil.
 public sealed class IpadExitCamera {
  public bool Active {get;private set;}
  public double Progress {get;private set;}
  public double EndElapsed {get;private set;}
  public bool Complete=>Active&&Progress>=1;
  NativeFrame frame;IpadView from,to;
  double duration,cycle,lastElapsed,rate,tailAt,tailProgress,tailTau,finishAt,finishProgress,finishSlope;
  bool waiting,finishing;
  static double Clamp(double x,double lo,double hi)=>Math.Max(lo,Math.Min(hi,x));
  public void Reset(){Active=waiting=finishing=false;Progress=rate=lastElapsed=0;EndElapsed=0;}
  public void Begin(NativeFrame frame,IpadView from,IpadView to,double duration,double cycle=0){
   Reset();this.frame=frame;this.from=from;this.to=to;this.duration=Math.Max(1,duration);this.cycle=Math.Max(0,cycle);
   EndElapsed=this.duration;rate=2/this.duration;Active=true;
  }
  void Wait(double at,double progress,double velocity){
   waiting=true;finishing=false;tailAt=at;tailProgress=progress;
   tailTau=Math.Max(1,(1-progress)/Math.Max(1e-12,velocity));EndElapsed=double.PositiveInfinity;
  }
  public IpadView Sample(double elapsed,bool ready=true){
   if(!Active)throw new InvalidOperationException("Begin the exit shot before sampling it");
   elapsed=Math.Max(lastElapsed,Math.Max(0,elapsed));
   // Reserve the last quarter of time only if preparation is still incomplete.
   // A rational tail keeps advancing without ever snapping to overview while
   // the real finish time is unknown. Ready-in-time shots retain their timing.
   if(!waiting&&!finishing&&!ready&&cycle>0&&elapsed>=duration*.75){
    if(lastElapsed>duration*.75)Wait(lastElapsed,Progress,rate);
    else Wait(duration*.75,.9375,.5/duration);
   }
   if(finishing&&!ready&&cycle>0)Wait(lastElapsed,Progress,rate);
   if(waiting){
    double t=Math.Max(0,elapsed-tailAt),r=1-tailProgress,k=1+t/tailTau;
    Progress=1-r/k;rate=r/(tailTau*k*k);
    if(ready){
     waiting=false;finishing=true;finishAt=elapsed;finishProgress=Progress;
     EndElapsed=duration-elapsed>=cycle*.5?duration:Math.Max(duration,Math.Ceiling((elapsed+cycle*.5)/cycle)*cycle);
     double span=Math.Max(1,EndElapsed-finishAt);
     finishSlope=Clamp(rate*span/Math.Max(1e-12,1-Progress),0,3);
    }
   }
   if(finishing){
    double span=Math.Max(1,EndElapsed-finishAt),u=Clamp((elapsed-finishAt)/span,0,1),m=finishSlope;
    double q=u*(m+u*(3-2*m+u*(m-2)));
    Progress=finishProgress+(1-finishProgress)*q;
    rate=(1-finishProgress)*(m+2*(3-2*m)*u+3*(m-2)*u*u)/span;
   }else if(!waiting){
    double u=Clamp(elapsed/duration,0,1);Progress=u*(2-u);rate=2*(1-u)/duration;
   }
   if(!waiting&&elapsed>=EndElapsed){Progress=1;rate=0;}
   lastElapsed=elapsed;
   return Current;
  }
  public IpadView Current {
   get{
    double p=Progress,z=from.zoom+(to.zoom-from.zoom)*p;
    double sx=(frame.Width/2-from.x*from.zoom)*(1-p)+(frame.Width/2-to.x*to.zoom)*p;
    double sy=(frame.Height/2-from.y*from.zoom)*(1-p)+(frame.Height/2-to.y*to.zoom)*p;
    return new IpadView{x=(frame.Width/2-sx)/z,y=(frame.Height/2-sy)/z,zoom=z,header=from.header+(to.header-from.header)*p};
   }
  }
 }
}

#if UNITY_EDITOR
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using UnityEngine;

namespace MazeBiters.NativeStudy {
 public static class NativeHunterIntentValidation {
  static readonly Vector2Int Right=Vector2Int.right,Left=Vector2Int.left,Down=new Vector2Int(0,1),Up=new Vector2Int(0,-1);
  sealed class Fixture {public NativeGameplayWorld w;public NativeHunter h;public NativeGameplaySnake snake;public readonly List<NativeWorldEvent> events=new List<NativeWorldEvent>();}
  static void Check(NativeCreatureFeudReport r,bool pass,string name,string detail=""){r.assertions++;if(!pass)r.failures++;r.checks.Add(new NativeDifficultyCheck{name=name,passed=pass,detail=detail});}
  static void Group(NativeCreatureFeudReport r,string name,Action action){try{action();}catch(Exception e){Check(r,false,name+" completes",e.ToString());}}
  static bool Near(double a,double b)=>Math.Abs(a-b)<1e-7;
  static string[] Grid(){var rows=new string[17];for(int y=0;y<17;y++)rows[y]=y==0||y==16?new string('#',17):"#"+new string('.',15)+"#";return rows;}
  static Fixture Make(int tier=2,int mode=1){
   var f=new Fixture();uint seed=3371;
   f.w=new NativeGameplayWorld(Grid(),()=>{unchecked{seed+=0x6D2B79F5;uint v=(seed^(seed>>15))*(1|seed);v^=v+(v^(v>>7))*(61|v);return (v^(v>>14))/4294967296.0;}}){Difficulty=NativeMazeGenerator.Difficulties[tier],AiDifficulty=tier,Time=1000,LevelStarted=1000,Assist=false,SessionEnabled=false,LifecycleEnabled=false};
   f.w.SetMode(mode);f.w.Event=e=>f.events.Add(e);
   for(int i=0;i<f.w.PlayerCount;i++){var p=f.w.GetPlayer(i);p.Cell=p.From=p.Previous=new Vector2Int(1,1+i);p.Waiting=true;p.LastMove=1e9;p.Score=120+i;p.ExactScore=p.Score;p.Contribution=7+i;p.Lives=3;p.PowerUntil=p.ShieldUntil=0;}
   return f;
  }
  static NativeHunter Hunter(Fixture f,Vector2Int cell,int id=100){var h=new NativeHunter{Id=id,Cell=cell,From=cell,Dir=Down,LastMove=f.w.Time,MotherAlive=true};f.w.Hunters.Add(h);return h;}
  static Fixture ChoiceFixture(int tier,double roll){
   var f=Make(tier);f.w.Player.Cell=f.w.Player.From=new Vector2Int(8,2);
   f.snake=f.w.AddSnake(Enumerable.Range(5,7).Select(x=>new Vector2Int(x,8)),Left,0);f.snake.LastMove=1e9;
   f.h=Hunter(f,new Vector2Int(8,5));f.w.Random=()=>roll;return f;
  }
  static Vector2Int Decide(NativeCreatureFeudReport r,Fixture f,NativeHunter hunter=null){r.decisions++;var h=hunter??f.h;return f.w.Brain.Choose(h,h.Cell,new List<Vector2Int>{Down,Left,Right},new BrainProfile{kind="hunter",baseline=.22});}
  static string Threat(NativeHunter h)=>h.MotherAlive+"|"+h.Anger+"|"+h.Threat+"|"+string.Join(",",h.PersonalThreat);
  static void Profiles(NativeCreatureFeudReport r){
   bool bounded=true,ordered=true,bias=true,holds=true;var previous=NativeCreatureFeudProfile.ForIntensity(0);
   for(int i=0;i<=400;i++){var p=NativeCreatureFeudProfile.ForIntensity(i/100.0);bounded&=p.Chance>=0&&p.Pursuit>=0&&p.Chance+p.Pursuit<=1;bias&=p.Chance>p.Pursuit;holds&=p.DecisionMs>=2000&&p.DecisionMs<=4000;ordered&=p.Chance>=previous.Chance&&p.Pursuit>=previous.Pursuit&&p.DecisionMs<=previous.DecisionMs;previous=p;}
   Check(r,bounded&&ordered,"Mischief and pursuit grow continuously across all five difficulties without exceeding a full probability budget");
   Check(r,bias&&holds,"Every interpolated difficulty slightly favors mischief and holds its intention for a 2–4 second decision interval");
   var picnic=NativeCreatureFeudProfile.ForIntensity(0);Check(r,picnic.Chance>0&&picnic.Pursuit>0&&picnic.Chance+picnic.Pursuit<.15,"PICNIC remains predominantly casual but neither incidental pursuit nor deliberate mischief is completely forbidden");
   for(int tier=0;tier<5;tier++){
    var start=NativeCreatureFeudProfile.ForIntensity(tier);var grace=NativeCreatureFeudProfile.ForIntensity(NativeDifficulty.ForIndex(tier,1,60000).Intensity);var late=NativeCreatureFeudProfile.ForIntensity(NativeDifficulty.ForIndex(tier,1,300000).Intensity);var max=NativeCreatureFeudProfile.ForIntensity(4);
    Check(r,Near(start.Chance,grace.Chance)&&Near(start.Pursuit,grace.Pursuit)&&Near(late.Chance,max.Chance)&&Near(late.Pursuit,max.Pursuit),"The existing first-minute grace and five-minute escalation apply to both intentions: tier="+tier);
   }
  }
  static void ChoicesAndHolds(NativeCreatureFeudReport r){
   const int samples=512;int previousActive=-1;
   for(int tier=0;tier<5;tier++){
    var counts=new Dictionary<string,int>{{"mischief",0},{"hunt",0},{"wander",0},{"evade",0}};var held=new Dictionary<string,Fixture>();
    for(int sample=0;sample<samples;sample++){
     var f=ChoiceFixture(tier,(sample+.5)/samples);Decide(r,f);string intent=f.h.Brain.intent;
     if(!counts.ContainsKey(intent??"null"))counts[intent??"null"]=0;counts[intent??"null"]++;
     if((intent=="mischief"||intent=="hunt"||intent=="wander")&&!held.ContainsKey(intent))held.Add(intent,f);
    }
    int active=counts["mischief"]+counts["hunt"];
    Check(r,counts["mischief"]>0&&counts["hunt"]>0&&counts["wander"]>0&&counts["evade"]==0,"All three ordinary intentions are reachable with a legal split and an unprotected player: tier="+tier,string.Join(", ",counts.Select(k=>k.Key+"="+k.Value)));
    Check(r,active>previousActive,"Matched decisions become more purposeful at each higher tier: tier="+tier,"Active="+active+"/"+samples);previousActive=active;
    foreach(var entry in held){var f=entry.Value;var state=f.h.Brain;double start=f.w.Time,until=state.intentUntil;string intent=state.intent;bool stable=true;
     f.w.Random=()=>.999999;
     foreach(double fraction in new[]{.05,.25,.5,.9,.999}){f.w.Time=start+(until-start)*fraction;Decide(r,f);stable&=state.intent==intent&&Near(state.intentUntil,until);}
     Check(r,until-start>=2000&&until-start<=4000&&stable,"An unchanged safe situation does not reroll or flicker its held "+entry.Key+" intention: tier="+tier,"Held "+(until-start).ToString("F0")+" ms");
     f.w.Time=until+1;Decide(r,f);Check(r,state.intentUntil>until,"The "+entry.Key+" decision is reconsidered after its gameplay deadline: tier="+tier);
    }
   }
  }
  static void NoFalseMischief(NativeCreatureFeudReport r){
   for(int tier=0;tier<5;tier++)foreach(int length in new[]{0,1,2}){
    var f=ChoiceFixture(tier,.001);f.w.Snakes.Clear();if(length>0)f.w.AddSnake(Enumerable.Range(7,length).Select(x=>new Vector2Int(x,8)),Left,0);
    Decide(r,f);Check(r,f.h.Brain.mischiefSnakeId==0&&f.h.Brain.intent!="hunt","An impossible interior split does not turn mischief into a forced player chase: tier="+tier+", length="+length);
   }
   for(int tier=0;tier<5;tier++){
    var f=ChoiceFixture(tier,.001);Decide(r,f);var h=f.h;var s=f.snake;var state=h.Brain;var before=s.Body.ToArray();int index=state.target.HasValue?s.Body.IndexOf(state.target.Value):-1;
    // VisualTarget is the selected cut, while generic hunt-plan state is allowed to remain empty.
    if(index<0&&h.VisualTarget.HasValue)index=s.Body.IndexOf(h.VisualTarget.Value);
    Check(r,state.mischiefSnakeId==s.Id&&index>0&&index<s.Body.Count-1,"A deliberate target is an interior segment that can actually create two snakes: tier="+tier);
    if(index<=0||index>=s.Body.Count-1)continue;
    var scores=Enumerable.Range(0,f.w.PlayerCount).Select(i=>f.w.GetPlayer(i).Score).ToArray();h.Cell=s.Body[index];bool cut=f.w.TryHunterCut(h,h.Cell);
    Check(r,cut&&f.w.Snakes.Count==2&&f.w.Snakes.All(child=>child.Body.Count>0)&&f.w.Snakes.Sum(child=>child.Body.Count)==before.Length-1&&Enumerable.Range(0,f.w.PlayerCount).All(i=>f.w.GetPlayer(i).Score==scores[i]),"A chosen mischief strike makes two fragments, only one passage gap and no player reward: tier="+tier);
   }
  }
  static void ScorpionConsumption(NativeCreatureFeudReport r){
   for(int mode=0;mode<=5;mode++)for(int slot=0;slot<(mode==4?3:mode==0||mode==1?1:2);slot++)foreach(bool tail in new[]{false,true}){
    var f=Make(2,mode);var actor=f.w.GetPlayer(slot);var h=Hunter(f,new Vector2Int(12,12));var second=Hunter(f,new Vector2Int(13,13),101);var unborn=new NativeEgg{Cell=new Vector2Int(10,10),Born=f.w.Time-12950};f.w.Eggs.Add(unborn);
    var removed=Hunter(f,new Vector2Int(14,14),102);f.w.Hunters.Remove(removed);string threat=Threat(h);var state=f.w.Brain.State(h);state.intent="mischief";state.intentUntil=f.w.Time+3000;state.target=new Vector2Int(8,8);state.planUntil=f.w.Time+3000;state.mischiefSnakeId=17;h.HeldDirection=Left;
    var score=Enumerable.Range(0,f.w.PlayerCount).Select(i=>f.w.GetPlayer(i).Score).ToArray();f.w.PlaceScorpion(new Vector2Int(8,8),Right);actor.Cell=actor.From=new Vector2Int(tail?7:8,7);actor.Dir=actor.Next=Down;actor.Waiting=false;
    using(f.w.ForPlayer(actor))f.w.AdvancePlayer();string label="mode="+mode+", actor="+actor.Id+", AI="+actor.IsAI+", tail="+tail;
    Check(r,f.w.Scorpion==null&&f.w.ScorpionKilled&&f.events.Count(e=>e.Kind=="scorpionBite"&&e.Player==actor&&e.Index==(tail?1:0))==1,"Real player movement consumes the scorpion with correct actor attribution: "+label);
    Check(r,new[]{h,second}.All(x=>x.RevengePlayerId==actor.Id&&x.RevengeRevision==1&&Near(x.RevengeAt,f.w.Time)&&Near(f.w.HunterRevenge(x),1))&&removed.RevengeRevision==0,"Only currently living hunters remember the actual human or AI eater: "+label);
    Check(r,Threat(h)==threat&&state.intent==null&&state.mischiefSnakeId==0&&state.target==null&&!h.HeldDirection.HasValue,"Revenge interrupts held plans without a permanent threat boost or movement: "+label);
    Check(r,f.w.Player.Id==1&&Enumerable.Range(0,f.w.PlayerCount).All(i=>i==slot||f.w.GetPlayer(i).Score==score[i]),"Scoped consumption restores the actor context and rewards no other player: "+label);
    f.w.Time+=100;f.w.UpdateEggs();var hatch=f.w.Hunters.FirstOrDefault(x=>x.Cell==unborn.Cell);
    Check(r,hatch!=null&&hatch.RevengePlayerId==0&&hatch.RevengeRevision==0&&Near(f.w.HunterRevenge(hatch),0)&&hatch.MotherAlive&&h.RevengePlayerId==actor.Id,"An already present egg hatches without knowledge of the earlier scorpion death: "+label);
    f.w.Time+=100;f.w.PlaceScorpion(new Vector2Int(8,11),Right);actor.Cell=actor.From=new Vector2Int(8,10);actor.Dir=actor.Next=Down;actor.Waiting=false;using(f.w.ForPlayer(actor))f.w.AdvancePlayer();
    Check(r,hatch!=null&&hatch.RevengeRevision==1&&hatch.RevengePlayerId==actor.Id&&h.RevengeRevision==2,"That hatchling can witness a later scorpion death normally: "+label);
   }
   var absent=Make();var observer=Hunter(absent,new Vector2Int(8,8));absent.w.EatScorpion();absent.w.PlaceScorpion(new Vector2Int(5,5),Right);absent.w.Player.Dead=true;absent.w.EatScorpion();
   Check(r,observer.RevengeRevision==0&&absent.w.Scorpion!=null,"A missing scorpion or dead player cannot manufacture a revenge event");
  }
  static void MemoryAndRetarget(NativeCreatureFeudReport r){
   var f=Make(0,4);var h=Hunter(f,new Vector2Int(8,8));h.Anger=.25;h.Threat=.5;h.PersonalThreat[0]=.2;string original=Threat(h);int rng=0;f.w.Random=()=>{rng++;return .5;};
   f.w.NotifyHuntersScorpionEaten(f.w.GetPlayer(2));double at=f.w.Time;bool monotone=true,bounded=true,pure=true;double previous=1;
   for(int elapsed=0;elapsed<=36000;elapsed+=100){f.w.Time=at+elapsed;double strength=f.w.HunterRevenge(h),again=f.w.HunterRevenge(h);bounded&=strength>=0&&strength<=1;monotone&=strength<=previous+1e-12;pure&=Near(strength,again)&&Near(h.RevengeAt,at)&&h.RevengeRevision==1&&rng==0;previous=strength;}
   f.w.Time=at+3000;double hold=f.w.HunterRevenge(h);f.w.Time=at+19000;double midpoint=f.w.HunterRevenge(h);f.w.Time=at+35000;double end=f.w.HunterRevenge(h);
   Check(r,bounded&&monotone&&pure&&Near(hold,1)&&Near(midpoint,.5)&&Near(end,0),"Personal revenge uses only gameplay time, holds briefly, fades smoothly to zero and never consumes random draws");
   Check(r,Threat(h)==original,"Expired revenge leaves no permanent MotherAlive, anger, global threat or personal-threat escalation");
   f.w.NotifyHuntersScorpionEaten(f.w.GetPlayer(1));Check(r,h.RevengePlayerId==2&&h.RevengeRevision==2&&Near(f.w.HunterRevenge(h),1),"A later scorpion death refreshes personal revenge toward the new actual eater");
   var legacy=Make();legacy.w.UseLegacyAi=true;var old=Hunter(legacy,new Vector2Int(8,8));legacy.w.PlaceScorpion(new Vector2Int(5,5),Right);legacy.w.Player.Cell=new Vector2Int(5,5);legacy.w.EatScorpion();
   Check(r,old.RevengeRevision==0&&Near(legacy.w.HunterRevenge(old),0)&&!old.MotherAlive&&old.Threat>=3,"Historical validation retains its original reaction without receiving the new policy");
  }
  static void RevengeChoices(NativeCreatureFeudReport r){
   const int samples=256;
   for(int tier=0;tier<5;tier++){
    int ordinaryHunt=0,revengeHunt=0,revengeMischief=0;
    for(int sample=0;sample<samples;sample++){
     double roll=(sample+.5)/samples;var normal=ChoiceFixture(tier,roll);Decide(r,normal);if(normal.h.Brain.intent=="hunt")ordinaryHunt++;
     var angry=ChoiceFixture(tier,roll);angry.w.NotifyHuntersScorpionEaten(angry.w.Player);Decide(r,angry);if(angry.h.Brain.intent=="hunt")revengeHunt++;if(angry.h.Brain.intent=="mischief")revengeMischief++;
    }
    Check(r,revengeHunt>samples*.75&&revengeHunt>ordinaryHunt&&revengeMischief<samples*.08,"A recent scorpion death promptly prioritizes revenge over mischief at every tier: tier="+tier,"ordinary hunt="+ordinaryHunt+", revenge hunt="+revengeHunt+", revenge mischief="+revengeMischief+" / "+samples);
   }
   foreach(bool ai in new[]{false,true})for(int slot=0;slot<3;slot++){
    var f=Make(0,4);f.h=Hunter(f,new Vector2Int(8,8));for(int i=0;i<3;i++)f.w.GetPlayer(i).Cell=new Vector2Int(8,6-i);var actor=f.w.GetPlayer(slot);actor.IsAI=ai;f.w.NotifyHuntersScorpionEaten(actor);f.w.Random=()=>.25;Decide(r,f);
    Check(r,f.h.Brain.intent=="hunt"&&f.h.Brain.targetPlayerId==actor.Id,"Revenge selects the actual offender regardless of human/AI slot or nearer innocent: slot="+slot+", AI="+ai);
    foreach(bool shield in new[]{false,true}){
     actor.Dead=!shield;actor.ShieldUntil=shield?f.w.Time+10000:0;f.w.Time+=10;Decide(r,f);
     Check(r,f.h.Brain.intent!="hunt"&&f.h.Brain.targetPlayerId!=actor.Id,"A dead or protected offender does not redirect full revenge toward an innocent player: slot="+slot+", AI="+ai+", shield="+shield);
    }
   }
  }
  static void IncidentalRevengeCrossing(NativeCreatureFeudReport r){
   for(int tier=0;tier<5;tier++){
    var f=Make(tier);f.w.Player.Cell=f.w.Player.From=new Vector2Int(4,7);var snake=f.w.AddSnake(Enumerable.Range(5,5).Select(x=>new Vector2Int(x,8)),Left,0);snake.LastMove=1e9;var h=Hunter(f,new Vector2Int(7,7));f.w.NotifyHuntersScorpionEaten(f.w.Player);f.w.Random=()=>.25;int score=f.w.Player.Score;
    f.w.Tick(f.w.Time+96);
    Check(r,h.Cell==new Vector2Int(7,8)&&h.Dir==Down&&f.w.Snakes.Count==2&&f.events.Count(e=>e.Kind=="hunterSplit")==1&&f.w.Player.Score==score,"Even an avenging hunter continues its incidental straight crossing without feeding or reversing: tier="+tier);
    var behind=Make(tier);behind.w.Player.Cell=behind.w.Player.From=new Vector2Int(3,8);var rear=behind.w.AddSnake(Enumerable.Range(5,7).Select(y=>new Vector2Int(7,y)),Up,0);rear.LastMove=1e9;var forward=Hunter(behind,new Vector2Int(8,8));forward.Dir=Right;behind.w.NotifyHuntersScorpionEaten(behind.w.Player);behind.w.Random=()=>.25;behind.w.Tick(behind.w.Time+96);
    Check(r,forward.Dir!=Left&&forward.Cell!=new Vector2Int(7,8)&&behind.events.All(e=>e.Kind!="hunterSplit"),"A wanted offender and a cuttable body behind the hunter cannot authorize a gratuitous reverse: tier="+tier);
   }
  }
  static void RevengeExpiryAndUnavailableTarget(NativeCreatureFeudReport r){
   var expires=ChoiceFixture(0,.076);var h=expires.h;var state=expires.w.Brain.State(h);state.phase=0;expires.w.NotifyHuntersScorpionEaten(expires.w.Player);double at=expires.w.Time;
   expires.w.Time=at+34000;Decide(r,expires);
   Check(r,state.intent=="hunt"&&Near(state.intentUntil,at+35000),"A late held revenge decision ends exactly at memory expiry instead of extending the reaction by another full intention");
   expires.w.Random=()=>.999;expires.w.Time=at+34999;Decide(r,expires);bool held=state.intent=="hunt";
   expires.w.Time=at+35000;Decide(r,expires);
   Check(r,held&&state.intent=="wander"&&state.intentUntil>expires.w.Time&&Near(h.Aggression,.025)&&!h.VisualTarget.HasValue,"The expiry boundary reconsiders the held hunt and restores ordinary PICNIC aggression without a stale visual goal");
   for(int tier=0;tier<5;tier++)foreach(bool disconnected in new[]{false,true}){
    var f=Make(tier,4);f.h=Hunter(f,new Vector2Int(8,8));f.w.GetPlayer(0).Cell=new Vector2Int(6,8);f.w.GetPlayer(1).Cell=new Vector2Int(7,5);var offender=f.w.GetPlayer(2);offender.Cell=new Vector2Int(11,8);f.w.Random=()=>.25;f.w.NotifyHuntersScorpionEaten(offender);Decide(r,f);bool wasOffender=f.h.Brain.intent=="hunt"&&f.h.Brain.targetPlayerId==offender.Id;
    if(disconnected){var rows=Grid().Select(row=>row.ToCharArray()).ToArray();for(int y=1;y<16;y++)rows[y][9]='#';f.w.Grid=rows.Select(row=>new string(row)).ToArray();}
    else f.w.SetMode(1);
    f.w.Random=()=>.8;f.w.Time+=50;Decide(r,f);
    Check(r,wasOffender&&f.h.Brain.targetPlayerId!=offender.Id&&f.h.Brain.intent!="hunt"&&f.h.Aggression<.6&&Near(f.w.HunterRevenge(f.h),1),"An "+(disconnected?"unreachable":"absent")+" offender invalidates the held route without transferring enhanced revenge to available innocents: tier="+tier);
   }
  }
  static void BehindOnlyCutPlan(NativeCreatureFeudReport r){
   for(int tier=0;tier<5;tier++){
    var f=Make(tier);var rows=Enumerable.Range(0,17).Select(_=>new string('#',17).ToCharArray()).ToArray();
    foreach(var c in new[]{new Vector2Int(8,8),new Vector2Int(9,8),new Vector2Int(8,7),new Vector2Int(7,8),new Vector2Int(5,8)})rows[c.y][c.x]='.';
    for(int y=6;y<=10;y++)rows[y][6]='.';f.w.Grid=rows.Select(row=>new string(row)).ToArray();f.w.Player.Dead=true;
    f.snake=f.w.AddSnake(Enumerable.Range(6,5).Select(y=>new Vector2Int(6,y)),Up,0);f.snake.LastMove=1e9;f.h=Hunter(f,new Vector2Int(8,8));f.h.Dir=Right;f.w.Random=()=>.001;
    r.decisions++;var direction=f.w.Brain.Choose(f.h,f.h.Cell,new List<Vector2Int>{Right,Up},new BrainProfile{kind="hunter",baseline=.22});
    Check(r,direction!=Left&&f.h.Brain.intent=="wander"&&f.h.Brain.mischiefSnakeId==0,"A split reachable only by the forbidden reverse direction is not advertised as a deliberate objective: tier="+tier);
    f.h.Brain.intent=null;f.h.Brain.hunterCutMissAt=0;r.decisions++;direction=f.w.Brain.Choose(f.h,f.h.Cell,new List<Vector2Int>{Left,Right,Up},new BrainProfile{kind="hunter",baseline=.22});
    Check(r,direction==Left&&f.h.Brain.intent=="mischief"&&f.h.Brain.mischiefSnakeId==f.snake.Id,"The same geometry becomes a valid interior split when its first direction is actually legal: tier="+tier);
   }
  }
  public static NativeCreatureFeudReport Run(){
   var watch=Stopwatch.StartNew();var r=new NativeCreatureFeudReport{scope="Deterministic native iPad hunter intention, scorpion-revenge, actor, hatch and contact checks. No rendered-device or subjective gameplay-balance claim."};
   Group(r,"probability policy and gameplay escalation",()=>Profiles(r));Group(r,"real choices and intention stability",()=>ChoicesAndHolds(r));Group(r,"meaningful split goals",()=>NoFalseMischief(r));Group(r,"real consumption and hatch isolation",()=>ScorpionConsumption(r));Group(r,"personal time memory and legacy",()=>MemoryAndRetarget(r));Group(r,"revenge choices and actor safety",()=>RevengeChoices(r));Group(r,"incidental crossing during revenge",()=>IncidentalRevengeCrossing(r));Group(r,"revenge expiry and unavailable offender",()=>RevengeExpiryAndUnavailableTarget(r));Group(r,"legal first step for deliberate splits",()=>BehindOnlyCutPlan(r));
   watch.Stop();r.elapsedMs=watch.Elapsed.TotalMilliseconds;r.passed=r.failures==0;return r;
  }
 }
}
#endif

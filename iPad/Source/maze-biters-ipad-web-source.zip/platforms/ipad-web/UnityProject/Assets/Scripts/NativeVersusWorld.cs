using UnityEngine;
namespace MazeBiters.NativeStudy {
 public sealed partial class NativeGameplayWorld {
  // Frozen browser game.js: playerWinsContactPriority / eatCompetingPlayer.
  // Re-evaluate live points and timers on EVERY contact, never cache the leader.
  public bool CanEatPlayer(NativePlayer attacker,NativePlayer defender,double? at=null){double t=at??Time;
   if(!Competitive||attacker==null||defender==null||attacker==defender||attacker.Dead||defender.Dead||attacker.Lives<=0||defender.Lives<=0)return false;
   if(defender.ShieldUntil>t)return false;
   if(attacker.ShieldUntil>t)return true;
   bool a=attacker.PowerUntil>t,b=defender.PowerUntil>t;
   return a!=b?a:attacker.Score>defender.Score;
  }
  public bool PlayerContactBlocks(NativePlayer mover,Vector2Int cell){
   var other=TeammateAt(mover,cell);
   return other!=null&&!CanEatPlayer(mover,other)&&!CanEatPlayer(other,mover);
  }
  // Keyboard may deliberately enter a stronger rival; pointer routing may not.
  public bool PlayerRouteSafe(NativePlayer mover,Vector2Int cell,double? at=null){
   var other=TeammateAt(mover,cell);return other==null||CanEatPlayer(mover,other,at);
  }
  public bool EatPlayer(NativePlayer winner,NativePlayer victim){
   if(!CanEatPlayer(winner,victim))return false;
   if(winner.Ai!=null)winner.Ai.directive=null;if(victim.Ai!=null)victim.Ai.directive=null;
   using(ForPlayer(winner)){
    CharacterBite(140);
    Event?.Invoke(new NativeWorldEvent{Player=winner,Victim=victim,Kind="playerBite",Cell=victim.Cell,Time=Time});
    Award(1000);
   }
   // Own death cue and full skull/respawn clock; NOT the snake-head sound.
   using(ForPlayer(victim))LoseLife();
   return true;
  }
  public bool ResolvePlayerContact(NativePlayer mover){
   var other=TeammateAt(mover,mover.Cell);
   return other!=null&&(EatPlayer(mover,other)||EatPlayer(other,mover));
  }
 }
}

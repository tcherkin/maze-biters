using System;using System.IO;using UnityEngine;
namespace MazeBiters.NativeStudy {
 [Serializable]class PowerLightCases {public PowerLightCase[] cases;}
 [Serializable]class PowerLightCase {public float x,y,dx,dy;public double power;}
 [Serializable]class LifecycleVisualReport {public string quality,note;public bool passed,brightTurns;public LifecycleLogicReport logic;public int lightSamples,lightPixels,maxAlphaError;public double meanAlphaError;}
 public sealed class LifecycleVisualValidation:MonoBehaviour {
  void Start(){
   string quality="hd",report=null;var args=Environment.GetCommandLineArgs();for(int i=0;i<args.Length;i++){if(args[i]=="--quality")quality=args[++i];if(args[i]=="--report")report=args[++i];}
   Application.runInBackground=true;QualitySettings.vSyncCount=0;QualitySettings.anisotropicFiltering=AnisotropicFiltering.Disable;Directory.CreateDirectory(Path.GetDirectoryName(report));
   var result=new LifecycleVisualReport{quality=quality,logic=LifecycleValidation.Run(),note="Original authored bright player packs: 120 mouth/blink/turn poses per quality. Powered DUSK alpha against original renderer: 16 power/direction samples. Functional parity, not a speed or full-game benchmark."};
   var quad=new Mesh();quad.vertices=new[]{new Vector3(0,0),new Vector3(1,0),new Vector3(1,-1),new Vector3(0,-1)};quad.uv=new[]{new Vector2(0,1),new Vector2(1,1),new Vector2(1,0),new Vector2(0,0)};quad.triangles=new[]{0,1,2,0,2,3};quad.RecalculateBounds();
   using(var art=new PackedArt(quality,true))result.brightTurns=AnimationValidation.Turns(quality,art,quad,Path.Combine(Path.GetDirectoryName(report),"bright-turns-"+quality+".json"),"power");
   var go=new GameObject("Power light validation");var camera=go.AddComponent<Camera>();camera.enabled=false;
   var root=Path.Combine(WebFiles.Root,"Reference");var specs=JsonUtility.FromJson<PowerLightCases>(File.ReadAllText(Path.Combine(root,"power-light.json")));
   var expected=new Texture2D(2,2,TextureFormat.RGBA32,false);expected.LoadImage(File.ReadAllBytes(Path.Combine(root,"power-light.png")));var b=expected.GetPixels32();
   var actual=new Texture2D(576,400,TextureFormat.RGBA32,false);var previous=RenderTexture.active;long total=0;
   using(var dusk=new NativeDusk(quad,camera)){for(int k=0;k<specs.cases.Length;k++){var p=specs.cases[k];dusk.Render(new Vector2(p.x,p.y),new Vector2(p.dx,p.dy),16,false,true,p.power);RenderTexture.active=dusk.mask;actual.ReadPixels(new Rect(0,0,576,400),0,0);actual.Apply();var a=actual.GetPixels32();
    for(int y=0;y<400;y++)for(int x=0;x<576;x++){int e=Math.Abs(a[y*576+x].a-b[((3-k/4)*400+y)*2304+(k%4)*576+x].a);total+=e;result.maxAlphaError=Math.Max(result.maxAlphaError,e);}
   }RenderTexture.active=previous;}
   result.lightSamples=specs.cases.Length;result.lightPixels=result.lightSamples*576*400;result.meanAlphaError=total/(double)result.lightPixels;result.passed=result.logic.passed&&result.brightTurns&&result.maxAlphaError<=2;
   File.WriteAllText(report,JsonUtility.ToJson(result,true));Destroy(expected);Destroy(actual);Destroy(go);Destroy(quad);Debug.Log("LIFECYCLE_VALIDATION "+result.passed);Application.Quit(result.passed?0:2);
  }
 }
}

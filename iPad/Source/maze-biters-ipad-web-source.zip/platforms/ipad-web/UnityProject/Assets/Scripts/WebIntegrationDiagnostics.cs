using System;
using UnityEngine;
namespace MazeBiters.NativeStudy {
 public sealed partial class NativeGameplayStudy {
  // Observation only, behind the existing diagnostics switch. Never creates a
  // map, samples gameplay RNG, changes clocks, or calls preparation/control.
  string WebIntegrationState(){
   if(world==null||!Application.absoluteURL.Contains("diagnostic=1"))return "null";
   var level=currentGeneratedLevel;var family=HybridMazeStudy.Report(level);var core=sceneMazeArt?.CoreStructureAudit;
   var starts=level?.starts;var points=new WebIntegrationStart[starts?.Length??0];
   for(int i=0;i<points.Length;i++)points[i]=new WebIntegrationStart{x=starts[i].x,y=starts[i].y,dx=starts[i].dir.x,dy=starts[i].dir.y};
   Vector3 center=hybridNameLabel!=null&&camera?camera.WorldToViewportPoint(hybridNameLabel.WorldCenter):Vector3.zero;
   return JsonUtility.ToJson(new WebIntegrationSnapshot{
    campaignEnabled=NativeCampaignComposition.Enabled,presentationReady=CampaignPresentationReady,
    family=family?.family??"",familyName=family?.familyName??"",symmetry=family?.symmetry??"",familyPassed=family?.passed??false,fallback=family?.fallback??false,
    name=HybridLevelNameCaption,theme=level?.theme??"",level=level?.level??0,seed=level?.paletteSeed??0,
    growthStage=family?.growthStage??0,openTwoByTwo=family?.openTwoByTwo??0,openThreeByThree=family?.openThreeByThree??0,diagonalRoutes=family?.diagonalRoutes.Count??0,
    starts=points,safeOpening=level?.safeOpening!=null&&level.safeOpening.Length>0,safeOpeningSnakes=level?.safeOpening?.Length??0,openingLayoutAttempt=level?.openingLayoutAttempt??0,
    titleMode=hybridTitleState.Mode.ToString(),titleElapsed=hybridTitleState.Elapsed,titleAlpha=hybridNameLabel?.Opacity??0,titleZoom=hybridNameLabel?.Zoom??0,
    titleSide=hybridNameLabel?.Side??0,titleMeshUpdates=hybridNameLabel?.MeshUpdates??0,titleVisible=hybridNameLabel?.Visible??false,titleViewX=center.x,titleViewY=center.y,levelRowSweep=hud?.HybridLevelSweepActive??false,pauseAlpha=(float)(sessionArt?.HybridPauseAlpha??0),
    coresEnabled=NativeMazeArtwork.CrystalCoresEnabled,coresReady=sceneMazeArt!=null&&sceneMazeArt.IsGlass&&core!=null&&sceneMazeArt.OuterCrystalMaterial!=null,
    bodyOpacity=NativeMazeArtwork.CoreGlassBodyOpacity,coreComponents=core?.components??0,orthogonalGrid=core?.orthogonalGrid??false,curveConvex=core?.curveConvex??false,
    curveFitMaxError=core?.curveFitMaxError??0,curveTangentError=core?.curveTangentError??0});
  }
  [Serializable]sealed class WebIntegrationStart {public int x,y,dx,dy;}
  [Serializable]sealed class WebIntegrationSnapshot {
   public string revision="20261116-holistic-optimization",family,familyName,symmetry,name,theme,titleMode;
   public bool campaignEnabled,presentationReady,familyPassed,fallback,safeOpening,titleVisible,levelRowSweep,coresEnabled,coresReady,orthogonalGrid,curveConvex;
   public uint seed;public int level,growthStage,openTwoByTwo,openThreeByThree,diagonalRoutes,safeOpeningSnakes,openingLayoutAttempt,titleMeshUpdates,coreComponents;
   public double titleElapsed,bodyOpacity,curveFitMaxError,curveTangentError;
   public float titleAlpha,titleZoom,titleSide,titleViewX,titleViewY,pauseAlpha;
   public WebIntegrationStart[] starts;
  }
 }
}

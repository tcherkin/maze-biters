using System;
using UnityEngine;
namespace MazeBiters.NativeStudy {
 public sealed class ScorpionPose {
  public double x,y,angle,curvature,frontAngle,rearAngle,frontOffset,rearOffset,scale=1,targetX,targetY;public int frame;
  public RailPoint Sample(double offset){double arc=Math.Max(rearOffset,Math.Min(frontOffset,offset)),a=rearAngle+curvature*(arc-rearOffset),middle=angle+curvature*arc/2,z=curvature*arc/2,z2=z*z,sinc=Math.Abs(z)<1e-4?1-z2/6+z2*z2/120:Math.Sin(z)/z,distance=arc*sinc,tx=Math.Cos(a),ty=Math.Sin(a),ext=offset-arc;return new RailPoint{x=x+distance*Math.Cos(middle)+ext*tx,y=y+distance*Math.Sin(middle)+ext*ty,angle=a,tx=tx,ty=ty};}
 }
 // Direct translation of live-scorpion.js. Logical cells never depend on this curve.
 public sealed class NativeScorpionMotion {
  const int N=512;static readonly double[] ix=new double[N+1],iy=new double[N+1];static readonly double quarter;
  public double started,duration,origin,fromX,fromY,toX,toY,fromAngle,delta,turnSign;public Vector2Int incoming;public string kind;
  public static double Ease(double u)=>AnimationClock.Ease(AnimationClock.Clamp(u));
  static double D(double u)=>30*u*u*(1-u)*(1-u);
  static NativeScorpionMotion(){for(int i=1;i<=N;i++){double a=(i-1.0)/N,b=(double)i/N,m=(a+b)/2,h=(b-a)/6;ix[i]=ix[i-1]+h*(Math.Cos(Math.PI/2*Ease(a))+4*Math.Cos(Math.PI/2*Ease(m))+Math.Cos(Math.PI/2*Ease(b)));iy[i]=iy[i-1]+h*(Math.Sin(Math.PI/2*Ease(a))+4*Math.Sin(Math.PI/2*Ease(m))+Math.Sin(Math.PI/2*Ease(b)));}quarter=(ix[N]+iy[N])/2;ix[N]=iy[N]=quarter;}
  static double Integral(double[] values,double u,bool sine){if(u<=0)return 0;if(u>=1)return quarter;double scaled=u*N;int i=(int)Math.Floor(scaled);double v=scaled-i,a=(double)i/N,b=(i+1.0)/N,h=1.0/N,ha=Math.PI/2*Ease(a),hb=Math.PI/2*Ease(b),c0=values[i],c1=(sine?Math.Sin(ha):Math.Cos(ha))*h,c2=(sine?Math.Cos(ha):-Math.Sin(ha))*Math.PI/2*D(a)*h*h/2,d1=(sine?Math.Sin(hb):Math.Cos(hb))*h,dd1=(sine?Math.Cos(hb):-Math.Sin(hb))*Math.PI/2*D(b)*h*h,change=values[i+1]-c0-c1-c2,velocity=d1-c1-2*c2,acc=dd1-2*c2,c3=10*change-4*velocity+acc/2,c4=-15*change+7*velocity-acc,c5=6*change-3*velocity+acc/2;return c0+v*(c1+v*(c2+v*(c3+v*(c4+v*c5))));}
  public NativeScorpionMotion(Vector2Int oldHead,Vector2Int oldTail,Vector2Int oldDir,Vector2Int head,Vector2Int tail,Vector2Int dir,double time,double gaitOrigin){
   started=time;origin=gaitOrigin;fromX=(oldHead.x+oldTail.x+1)*8;fromY=(oldHead.y+oldTail.y+1)*8;toX=(head.x+tail.x+1)*8;toY=(head.y+tail.y+1)*8;incoming=oldDir;double dot=oldDir.x*dir.x+oldDir.y*dir.y,cross=oldDir.x*dir.y-oldDir.y*dir.x;kind=head==oldHead&&tail==oldTail?"still":dot<-.5?"reverse":Math.Abs(cross)>.5?"quarter":"straight";delta=kind=="reverse"?Math.PI:kind=="quarter"?Math.Sign(cross)*Math.PI/2:0;turnSign=cross==0?1:Math.Sign(cross);duration=kind=="reverse"||kind=="quarter"?218:218*.55;fromAngle=Math.Atan2(oldDir.y,oldDir.x);
  }
  public ScorpionPose Sample(double t){double u=AnimationClock.Clamp((t-started)/duration),q=Ease(u);bool turning=kind=="reverse"||kind=="quarter";var p=new ScorpionPose{x=fromX+(toX-fromX)*(turning?q:u),y=fromY+(toY-fromY)*(turning?q:u)};
   if(kind=="quarter"){double length=8/quarter,x=length*Integral(ix,q,false),y=turnSign*length*Integral(iy,q,true);p.x=fromX+incoming.x*x-incoming.y*y;p.y=fromY+incoming.y*x+incoming.x*y;}
   double frontEnd=kind=="reverse"?.58:.8,rearStart=kind=="reverse"?.42:.2;p.frontAngle=fromAngle+delta*Ease(u/frontEnd);p.rearAngle=fromAngle+delta*Ease((u-rearStart)/(1-rearStart));p.frontOffset=kind=="reverse"?6.4:3.2;p.rearOffset=kind=="reverse"?-11.2:-3.2;p.curvature=(p.frontAngle-p.rearAngle)/(p.frontOffset-p.rearOffset);p.angle=p.rearAngle-p.curvature*p.rearOffset;p.frame=(int)Math.Floor(Math.Max(0,t-origin)/109+1e-10)&1;p.targetX=p.x;p.targetY=p.y;return p;
  }
 }
 public sealed class NativeScorpionGhost {
  public readonly NativeScorpionMotion motion;public readonly double start,duration,end;readonly NativePlayer player;readonly double radius,angle,a,b,angularRate,angularSecond;
  RailPoint Mouth(double t)=>NativeMouthIntake.Target(player.Visual(t),player.Dir,player.Tilt,16);
  public NativeScorpionGhost(NativeScorpionMotion motion,NativePlayer player,double t,bool tail){this.motion=motion;this.player=player;start=t+.35*Math.Max(1,player.MoveDuration);duration=(motion.kind=="quarter"||motion.kind=="reverse")&&t<motion.started+motion.duration?200:tail?220:140;end=start+duration;var p=motion.Sample(start);var m=Mouth(start);double dx=p.x-m.x,dy=p.y-m.y;radius=Math.Sqrt(dx*dx+dy*dy);angle=Math.Atan2(dy,dx);var l=motion.Sample(start-.1);var r=motion.Sample(start+.1);var ml=Mouth(start-.1);var mr=Mouth(start+.1);double vx=((r.x-mr.x)-(l.x-ml.x))/.2,vy=((r.y-mr.y)-(l.y-ml.y))/.2,ax=((r.x-mr.x)-2*dx+(l.x-ml.x))/.01,ay=((r.y-mr.y)-2*dy+(l.y-ml.y))/.01,squared=Math.Max(1e-12,radius*radius),radial=(dx*vx+dy*vy)/squared;a=Math.Min(-1e-9,radial);angularRate=(dx*vy-dy*vx)/squared;b=((vx*vx+vy*vy+dx*ax+dy*ay)/squared-2*radial*radial)/a;angularSecond=(dx*ay-dy*ax)/squared-2*radial*angularRate;}
  static double Expm1(double x){if(Math.Abs(x)>1e-5)return Math.Exp(x)-1;return x*(1+x*(.5+x*(1.0/6+x/24)));}
  public ScorpionPose Sample(double t){var p=motion.Sample(t);if(t<start)return p;double elapsed=Math.Max(0,Math.Min(duration,t-start)),remaining=t>=end?0:1-NativeScorpionMotion.Ease(elapsed/duration),log=Math.Abs(b)<1e-12?a*elapsed:a/b*Expm1(Math.Min(50,b*elapsed)),r=radius*Math.Exp(Math.Min(0,log))*remaining,turn=angle+Math.PI/3*Math.Tanh((angularRate*elapsed+.5*angularSecond*elapsed*elapsed)/(Math.PI/3));var m=Mouth(t);p.targetX=m.x+r*Math.Cos(turn);p.targetY=m.y+r*Math.Sin(turn);p.scale=remaining;return p;}
 }
}

using System;
using System.Collections;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using UnityEngine;
using UnityEngine.Profiling;
namespace MazeBiters.NativeStudy {
 public sealed partial class NativeGameplayStudy {
  bool consistencyProbe;
  [Serializable] struct ConsistencyFrame {
   public int cycle,index,gc0;public string phase,events;public bool focused,levelLoading;
   public double cpuMs,tickMs,renderMs,gapMs;public int lateLoads;
   public NativeStallTrace.Span[] slowStages;
  }
  [Serializable] sealed class ConsistencyMemory {
   public int cycle,objects,textures;public double uptime;public long managed,unityUsed,unityReserved,workingSet,privateBytes,snakeSources;
  }
  [Serializable] sealed class ConsistencyResult {
   public string quality,note;public bool passed;public double elapsedSeconds;
   public ConsistencyFrame[] frames;public ConsistencyMemory[] memory;public CreatureContactCheck[] contacts;
   public string[] checks;public PreparationSample[] preparation;public ScenePreparationSample[] scenePreparation;public bool scenePreparationEnabled;
  }
  // Capacity is allocated BEFORE the first memory checkpoint. Timed diagnostics
  // retain compact values, not an ever-growing graph of stage/string objects.
  readonly List<ConsistencyFrame> consistencyFrames=new List<ConsistencyFrame>();
  readonly List<ConsistencyMemory> consistencyMemory=new List<ConsistencyMemory>();
  readonly List<string> consistencyChecks=new List<string>();
  int consistencyCycle;
  void RecordConsistency(StallFrame f){
   consistencyFrames.Add(new ConsistencyFrame{cycle=consistencyCycle,index=f.index,events=f.events,phase=f.scenario,focused=f.focused,gc0=f.gc0,levelLoading=f.events.Contains("levelChanged"),
    cpuMs=f.cpuMs,tickMs=f.tickMs,renderMs=f.renderMs,gapMs=f.frameGapMs,
    slowStages=f.cpuMs>8?f.stages:null,
    lateLoads=f.stages.Count(s=>s.name.StartsWith("load-"))});
  }
  void ConsistencyAssert(bool condition,string name){
   if(!condition)throw new InvalidOperationException("Consistency check: "+name);
   consistencyChecks.Add(name);
  }
  void SampleConsistencyMemory(){
   // Identical level-one scene at every checkpoint, after deferred destruction
   // and a full GC OUTSIDE timing. OS/private memory is contextual, not VRAM.
   GC.Collect();using(var process=Process.GetCurrentProcess()){
    process.Refresh();
    consistencyMemory.Add(new ConsistencyMemory{cycle=consistencyCycle,uptime=Time.realtimeSinceStartupAsDouble,managed=GC.GetTotalMemory(false),
     unityUsed=Profiler.GetTotalAllocatedMemoryLong(),unityReserved=Profiler.GetTotalReservedMemoryLong(),
     workingSet=process.WorkingSet64>0?process.WorkingSet64:-1,privateBytes=process.PrivateMemorySize64>0?process.PrivateMemorySize64:-1,
     snakeSources=NativeSnakeTextures.ResidentBytes,objects=Resources.FindObjectsOfTypeAll<GameObject>().Length,
     textures=Resources.FindObjectsOfTypeAll<Texture>().Length});
   }
  }
  IEnumerator ConsistencyWalk(){
   Reset(0);yield return DrainProbePreparation();StallSession();world.EnableLifecycle();
   world.Scorpion.NextFruit=time+100000;world.Scorpion.NextEgg=time+100000;
   world.Player.Cell=world.Player.From=world.Player.Previous=new Vector2Int(2,1);
   world.Player.ShieldUntil=time+100000;
   var visits=new Dictionary<Vector2Int,int>();long previous=0;
   for(int frame=0;frame<2400;frame++){
    StallPilot(visits,true);long now=Stopwatch.GetTimestamp();
    MeasureStallFrame("crowded-walk","spawn",frame,previous);previous=now;yield return null;
   }
   ConsistencyAssert(!world.Player.Dead,"crowd alive "+consistencyCycle);
  }
  IEnumerator ConsistencySession(){
   Reset(12);yield return DrainProbePreparation();sessionAudio.Muted=true;world.Event=TraceWorldEvent;
   world.Player.Score=1235;world.Player.ExactScore=1235;world.SessionDeath();
   long previous=0;
   for(int frame=0;frame<950;frame++){
    // Controlled fixture only. The real death/respawn/transition clocks,
    // animation, rendering and event handlers are left untouched.
    if(frame==300){
     world.Snakes.Clear();foreach(var s in snakes.Values)s.Dispose();snakes.Clear();
     foreach(var h in actors.Where(x=>x.Key!=1).ToArray()){h.Value.Dispose();actors.Remove(h.Key);}
     world.Hunters.Clear();world.Scorpion=null;scorpionArt?.Dispose();scorpionArt=null;
     world.Eggs.Add(new NativeEgg{Cell=world.PlayerStart,Born=time});
    }
    if(frame==360){ConsistencyAssert(world.Player.Dead,"blocked respawn "+consistencyCycle);world.Eggs.Clear();}
    if(frame==380)ConsistencyAssert(!world.Player.Dead&&world.Player.Lives==2&&world.Player.Score==1235,"respawn "+consistencyCycle);
    if(frame==416){
     world.Snakes.Clear();foreach(var s in snakes.Values)s.Dispose();snakes.Clear();
     var cell=world.Brain.Nearest(world.PlayerStart+Vector2Int.right);
     var lastSnake=world.AddSnake(new[]{cell},Vector2Int.right,0);lastSnake.LastMove=time+1000;AddSnake(lastSnake);
     var p=world.Player;p.Cell=p.From=p.Previous=cell-Vector2Int.right;p.Dir=p.Next=Vector2Int.right;p.Waiting=true;
     // Fixture creation is not eating. Like the contact suite, show the living
     // creature first. Creating AND eating a never-rendered palette in one
     // frame after deleting the whole population measures an artificial PNG
     // reload, not the last-snake contact in actual play.
     Render();yield return DrainProbePreparation();previous=0;
    }
    if(frame==420){
     world.ActivatePower();world.Player.Waiting=false;world.Player.LastMove=time-world.PlayerDelay;
    }
    long now=Stopwatch.GetTimestamp();MeasureStallFrame("session-death-level","normal",frame,previous);previous=now;
    if(frame==420)ConsistencyAssert(world.Transition,"final head starts transition "+consistencyCycle);
    // Preparing a NEW level is a loading boundary, not an ordinary playable
    // frame. Keep its measured cost in the report, and drain disposal outside.
    if(preparationFrames>0||stallEvents.Contains("levelChanged")){yield return DrainProbePreparation();preparationFrames=0;discardPreparationDelta=false;previous=0;}
    yield return null;
   }
   ConsistencyAssert(world.Level==2&&world.Player.Score==1860&&events.Contains("respawn")&&events.Contains("levelChanged"),
    "level two original score/events "+consistencyCycle);
  }
  IEnumerator ProbeConsistency(){
   var wall=Stopwatch.StartNew();sessionSmoke=true;consistencyFrames.Capacity=14000;
   var args=Environment.GetCommandLineArgs();int at=Array.IndexOf(args,"--consistency-cycles");
   int cycles=at<0?4:Math.Max(1,Math.Min(4,int.Parse(args[at+1])));
   // Same-scene checkpoint before/after every cycle. The first checkpoint may
   // be lower because runtime pools grow once; compare the last three too.
   Reset(12);yield return DrainProbePreparation();Render();yield return DrainProbePreparation();yield return new WaitForSecondsRealtime(.3f);SampleConsistencyMemory();
   for(consistencyCycle=1;consistencyCycle<=cycles;consistencyCycle++){
    yield return ConsistencyWalk();
    Reset(9);yield return DrainProbePreparation();ContactProbeSession("normal");
    var body=ContactSnakePath(Vector2Int.right,3,true);
    var snake=world.AddSnake(body,body[0]-body[1],consistencyCycle%5);snake.LastMove=time;AddSnake(snake);
    yield return ContactWindow(new CreatureContactCheck{name="soak-split",mode="normal",expectedEvent="split",cut=3},
     body[3],Vector2Int.right,10,3,7);
    Reset(9);yield return DrainProbePreparation();ContactProbeSession("normal");
    ContactScorpionPose("reverse",Vector2Int.right,.5,out var cell,out var approach);
    yield return ContactWindow(new CreatureContactCheck{name="soak-scorpion",mode="normal",expectedEvent="scorpionBite",scorpionMotion="reverse"},
     cell,approach,150,1,1);
    yield return ConsistencySession();
    Reset(12);yield return DrainProbePreparation();Render();yield return DrainProbePreparation();yield return new WaitForSecondsRealtime(.3f);SampleConsistencyMemory();
   }
   NativeStallTrace.Enabled=false;
   var stable=consistencyMemory.Skip(2).ToArray();
   bool memoryStable=stable.Length<2||stable.Max(x=>x.unityUsed)-stable.Min(x=>x.unityUsed)<8*1024*1024&&
    stable.Max(x=>x.managed)-stable.Min(x=>x.managed)<4*1024*1024&&
    stable.Select(x=>x.textures).Distinct().Count()==1&&stable.Select(x=>x.objects).Distinct().Count()==1;
   var result=new ConsistencyResult{quality=quality,passed=creatureChecks.All(c=>c.passed)&&memoryStable,
    elapsedSeconds=wall.Elapsed.TotalSeconds,frames=consistencyFrames.ToArray(),memory=consistencyMemory.ToArray(),
    contacts=creatureChecks.ToArray(),checks=consistencyChecks.ToArray(),preparation=preparationSamples.ToArray(),scenePreparation=scenePreparationSamples.ToArray(),scenePreparationEnabled=!coldSceneControl,
    note="Four repeated cycles: 2400 full-crowd frames, snake split, scorpion U-turn bite, original death/blocked respawn/level-two progression, reset. Staged encounters only; original Tick/AI/visual algorithms. Compact preallocated diagnostics; no screenshots in timings. Fixed 120Hz simulation, actual player-loop gaps separate. LevelChanged frame includes level asset setup; not a gameplay-frame guarantee. Memory checkpoints use identical level-one scenes after deferred disposal/full GC outside measurement. Process working/private bytes are not VRAM. Steady last-three checkpoint tolerance: Unity used <8MiB, managed <4MiB, identical object/texture counts. Audio muted; inspect hardware output fallback."};
   Directory.CreateDirectory(Path.GetDirectoryName(report));File.WriteAllText(report,JsonUtility.ToJson(result,true));
   Application.Quit(result.passed?0:2);
  }
 }
}

using System;
namespace MazeBiters.NativeStudy {
 public static class NativeHumanTurnValidation {
  static double Wrap(double a)=>(a%4+4)%4;
  public static int Run(){int checks=0;
   void Check(bool ok,string name){checks++;if(!ok)throw new Exception("Human turn history: "+name);}
   void Near(double a,double b,string name)=>Check(Math.Abs(a-b)<1e-9,name+" "+a+" != "+b);
   // Stable vertical ping-pong must use ONE horizontal side in both directions,
   // even after a long wait; no dependence on flashlight floating-point residue.
   foreach(int side in new[]{0,2})foreach(int first in new[]{1,3}){
    var clock=new NativeTurnClock(true,side);clock.Request(side,first,0);int from=first;double time=1000;
    for(int turn=0;turn<20;turn++){
     int to=from==1?3:1;clock.Request(from,to,time);
     Near(Wrap(clock.Sample(time).angle),from,"start heading");
     Near(Wrap(clock.Sample(time+45).angle),side,"midpoint matches remembered side");
     for(int ms=0;ms<=90;ms++){
      var pose=clock.Sample(time+ms);double cos=Math.Cos(pose.angle*Math.PI/2);
      Check(side==0?cos>=-1e-12:cos<=1e-12,"correct half-circle");
      Check(pose.mix>=0&&pose.mix<=1,"valid sprite transition");
     }
     var end=clock.Sample(time+90);Check(end.done&&end.from==to&&end.to==to,"90ms final sprite");Near(Wrap(end.angle),to,"90ms final heading");
     Check(clock.LastHorizontal==side,"vertical cycle preserves memory");from=to;time+=turn%2==0?120:60000;
    }
   }
   // Arbitrary rapid up/down input must not snap the visible head or leave
   // the selected side, even when a previous 90ms animation is unfinished.
   foreach(int side in new[]{0,2})foreach(int first in new[]{1,3})foreach(int interval in new[]{1,7,23,45,70,89}){
    var clock=new NativeTurnClock(true,side);clock.Request(side,first,0);int from=first;double time=1000;
    for(int i=0;i<24;i++){
     int to=from==1?3:1;var before=clock.Sample(time);var start=clock.Request(from,to,time);Near(start.angle,before.angle,"interrupted position continuity");
     for(int dt=0;dt<=interval;dt++){var p=clock.Sample(time+dt);double c=Math.Cos(p.angle*Math.PI/2);Check(double.IsFinite(p.angle)&&p.mix>=0&&p.mix<=1,"finite interrupted pose");Check(side==0?c>=-1e-9:c<=1e-9,"interrupted selected half-circle");}
     from=to;time+=interval;
    }
    var end=clock.Sample(time+90);Check(end.done,"interrupted turn finishes");Near(Wrap(end.angle),from,"interrupted endpoint");
   }
   foreach(int side in new[]{0,2}){
    var clock=new NativeTurnClock(true,side);clock.Request(side,3,0);clock.Request(3,1,1000);
    int other=2-side;clock.Request(1,other,1200);clock.Request(other,3,1400);clock.Request(3,1,1600);
    Near(Wrap(clock.Sample(1645).angle),other,"new horizontal heading replaces memory");
    clock.Reset();Check(clock.LastHorizontal==0,"fresh life default right");clock.Request(2,3,2000);clock.Request(3,1,2200);Near(Wrap(clock.Sample(2245).angle),2,"initial left heading is observed");
   }
   // No changes to 90-degree turns, horizontal reversals or hunter clocks.
   foreach(int side in new[]{0,2})for(int a=0;a<4;a++)for(int b=0;b<4;b++){
    if(a%2==1&&b%2==1&&a!=b)continue;var human=new NativeTurnClock(true,side);var original=new NativeTurnClock();human.Request(a,b,100);original.Request(a,b,100);
    for(int ms=0;ms<=100;ms++){var p=human.Sample(100+ms);var q=original.Sample(100+ms);Near(p.angle,q.angle,"other turn angle");Near(p.mix,q.mix,"other turn mix");Check(p.from==q.from&&p.to==q.to&&p.done==q.done,"other turn sprites");}
   }
   return checks;
  }
 }
}

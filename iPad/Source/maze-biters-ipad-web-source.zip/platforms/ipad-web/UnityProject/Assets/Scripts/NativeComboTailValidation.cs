#if UNITY_EDITOR
using System;
using UnityEngine;
namespace MazeBiters.NativeStudy {
 public static partial class NativeComboValidation {
  static void TailContinuation(NativeComboReport r){
   foreach(int mode in new[]{0,1,2,3,4,5})foreach(double age in new[]{0.0,1.0,250.0,750.0,1499.999}){
    var f=Active(r,mode);var w=f.world;var p=w.Player;
    w.Snakes.RemoveAll(s=>s.Id!=10);Clock(w,w.Time+600);w.PauseComboFeeding();double until=p.Combo.CooldownUntil;
    Clock(w,until+age);double before=w.ComboStrength,expected=1-Math.Pow(age/1500,2),upgrade=p.Combo.LastUpgradeAt;int sounds=f.StartSounds;
    Check(r,w.ComboActive&&p.Combo.ScoreMultiplier==2&&Near(before,expected)&&Near(p.Combo.DecayOpacityAt(w.Time),expected),"Held multiplier and HUD follow full decay: mode="+mode+", age="+age);
    var copy=new NativeComboState();copy.CopyMotionFrom(p.Combo);
    Check(r,Near(copy.StrengthAt(w.Time),before)&&Near(copy.StrengthAfterBreakAt(w.Time,w.Time),before),"AI copy and pending-break forecast preserve the falling boost");
    int score=p.Score;Add(w,p.Cell+Vector2Int.right,Vector2Int.right,4);w.AdvancePlayer();r.movementSteps++;
    Check(r,w.ComboActive&&!p.Combo.CoolingDown&&p.Combo.ScoreMultiplier==2&&p.Score-score==50&&Near(w.ComboStrength,before)&&Near(p.Combo.DecayOpacityAt(w.Time),expected)&&p.Combo.LastUpgradeAt==upgrade&&f.StartSounds==sounds,"A tail bite during decay retains points/cue and resumes without speed jump: mode="+mode+", age="+age);
    double resumed=w.Time;Clock(w,resumed+250);
    Check(r,Near(w.ComboStrength,before+(1-before)*.75)&&Near(p.Combo.DecayOpacityAt(w.Time),expected+(1-expected)*.75),"Resumed boost rises smoothly from its exact residual strength");
    Clock(w,resumed+500);Check(r,Near(w.ComboStrength,1),"Continued meal reaches full x2 without a new multiplier");
    for(int n=0;n<3;n++)Step(r,w);score=p.Score;Add(w,p.Cell+Vector2Int.right,Vector2Int.right,1);Step(r,w);
    Check(r,p.Combo.ScoreMultiplier==4&&p.Score-score==500&&f.StartSounds==sounds+1,"Following uninterrupted snake upgrades from the retained tier");
    Step(r,w);double fresh=p.Combo.CooldownUntil;
    Check(r,Near(fresh,w.Time+1000),"Ending a resumed meal starts a fresh full grace");
    Clock(w,fresh+1499.999);Check(r,w.ComboActive&&p.Combo.ScoreMultiplier==4,"Tier survives the last positive boost instant");
    Clock(w,fresh+1500);Check(r,!w.ComboActive&&p.Combo.SnakeCount==0&&p.Combo.ScoreMultiplier==1&&w.ComboStrength==0,"At zero boost, multiplier and old lineages expire together");
   }
   foreach(string pickup in new[]{"fruit","scorpion"})foreach(double age in new[]{1.0,750.0,1499.0}){
    var f=Active(r);var w=f.world;var p=w.Player;w.Snakes.RemoveAll(s=>s.Id!=10);Clock(w,w.Time+600);w.PauseComboFeeding();Clock(w,p.Combo.CooldownUntil+age);
    double before=w.ComboStrength;int score=p.Score,sounds=f.StartSounds;
    if(pickup=="fruit")w.Fruits.Add(new NativeFruit{Cell=p.Cell+Vector2Int.right,Kind=0});else w.PlaceScorpion(p.Cell+Vector2Int.right*2,Vector2Int.right);
    w.AdvancePlayer();r.movementSteps++;
    Check(r,w.ComboActive&&p.Combo.ScoreMultiplier==2&&Near(w.ComboStrength,before)&&Near(p.Combo.DecayOpacityAt(w.Time),before)&&Near(p.Combo.CooldownUntil,w.Time+1000)&&p.Score-score==(pickup=="fruit"?NativeFruitCatalog.Points:150),"Pickup during decay refreshes grace without jumping combo speed or multiplying pickup points: "+pickup+", age="+age);
    Check(r,f.StartSounds==sounds+(pickup=="fruit"?1:0),"Pickup renewal never replays the combo upgrade sound");
    Clock(w,w.Time+500);Check(r,Near(w.ComboStrength,1),"Pickup renewal recovers full boost smoothly");
   }
   {
    var f=Active(r);var w=f.world;w.Snakes.RemoveAll(s=>s.Id!=10);Clock(w,w.Time+600);w.PauseComboFeeding();Clock(w,w.Player.Combo.CooldownUntil+750);
    var p=w.Player;double strength=w.ComboStrength,deadline=p.Combo.CooldownUntil;
    for(int n=0;n<100;n++){w.RealTime+=100;w.UpdateCombos();}
    Check(r,w.ComboActive&&Near(w.ComboStrength,strength)&&p.Combo.CooldownUntil==deadline,"Pause freezes both fading HUD envelope and active multiplier");
    w.BreakCombo();Check(r,!w.ComboActive&&p.Combo.ScoreMultiplier==1&&Near(w.ComboStrength,strength),"Explicit disqualifying break still ends scoring immediately without a speed discontinuity");
   }
  }
 }
}
#endif

using System;
using System.Collections.Generic;
using System.Linq;
using UnityEngine;
namespace MazeBiters.NativeStudy {
 // The frozen translation remains available to historical oracle checks.
 // Runtime intent and skill are graded independently from movement safety.
 public sealed class NativeAllyState {
  public NativeGameplaySnake locked,graded;public bool bitten,replan;public string commitMode,targetKind,gradedKind;
  public double commitUntil,detourUntil,snakeChoiceUntil,escapeTemperamentUntil,assessmentAt,escapeUntil,decisionAt;
  public bool? allowSplit;public bool escapeBite,escapeSplit;
  public bool mealInitialized,mealActive;public double mealIntentUntil,opponentHuntUntil,opponentRestUntil;
  public NativeGameplaySnake casualSnake;public int casualBites;public Vector2Int casualBiteCell,casualFollowCell,casualDirection;public bool casualGap;
  public NativeFruit fruit;public AllySplit split;public AllyRetreat retreat;public AllyDirective directive;
  public Vector2Int? observed,run,lastDirection,escapeTarget,roamObserved;public int runLength;
  public (Vector2Int cell,double time)? blockedStep;
  public List<NativeGameplaySnake> queue=new List<NativeGameplaySnake>();
  public List<(Vector2Int cell,double time)> recent=new List<(Vector2Int,double)>();
  public Dictionary<NativeGameplaySnake,double> cooldowns=new Dictionary<NativeGameplaySnake,double>();
  public Dictionary<Vector2Int,double> visited=new Dictionary<Vector2Int,double>();
  public Dictionary<Vector2Int,(int count,double time)> roamVisits=new Dictionary<Vector2Int,(int,double)>();
  internal string[] previewGrid;internal Vector2Int previewCell,previewDir,previewNext,previewTarget,previewVector;internal int previewRevision;internal bool previewHasTarget;
  public string thought;public Vector2Int thoughtTarget;public double thoughtScore,thoughtDanger;
  public double foresightRisk,foresightChosenRisk;public string foresightReason;public int foresightExpanded;
 }
 public sealed class AllySplit {public NativeGameplaySnake snake;public double fraction,started;}
 public sealed class AllyRetreat {
  public NativeGameplaySnake snake;public string kind,reason;public Vector2Int? originalTarget,blocked,waypoint,lastDir;
  public int turnGoal,steps,turns;public double started;public Vector2Int observed;
  public HashSet<Vector2Int> visited=new HashSet<Vector2Int>();
  public Dictionary<Vector2Int,double> avoid=new Dictionary<Vector2Int,double>();
 }
 public sealed class AllyObjective {
  public string type,kind;public Vector2Int target;public Vector2Int? dir;public double score;
  public NativeGameplaySnake snake;public NativeHunter hunter;public NativePlayer player;public NativeFruit fruit;
  public int bodyIndex;public bool immediate,committed,priorityFruit;
 }
 public sealed class AllySkill {
  public double notice,danger,panic,hunt,prediction,error,rethink,optimal,pool,split,horizon,escapeBite,range,detour,escapeSplit,slack;
  public AllySkill(params double[] v){notice=v[0];danger=v[1];panic=v[2];hunt=v[3];prediction=v[4];error=v[5];rethink=v[6];optimal=v[7];pool=v[8];split=v[9];horizon=v[10];escapeBite=v[11];range=v[12];detour=v[13];escapeSplit=v[14];slack=v[15];}
 }
 public sealed class AllyDirective {public string type;public NativePlayer target;public List<NativePlayer> threats;public AllySkill skill;public bool urgent,bite,split,flip;}
 public sealed partial class NativeAllyBrain {
  readonly NativeGameplayWorld w;short[][] atlas,preparedAtlas;string[] atlasGrid,preparedGrid;int[] bfsQueue;
  public void PrepareFrom(NativeAllyBrain source){preparedAtlas=source.atlas;preparedGrid=source.atlasGrid;}
  static readonly Vector2Int[] dirs=NativeGameplayWorld.Dirs;
  const double Inf=double.PositiveInfinity;
  static readonly AllySkill[] profiles={
   new AllySkill(5,3,1,.32,0,.38,1450,.35,4,.08,9,.30,4,0,.06,0),
   new AllySkill(8,5,2,.52,.12,.27,1000,.55,3,.24,13,.52,7,1,.24,0),
   new AllySkill(12,7,2,.68,.30,.16,650,.80,2,.55,18,.80,10,3,.55,1),
   new AllySkill(21,13,3,.92,.68,.05,260,.95,2,.88,28,1,16,5,.88,2),
   new AllySkill(Inf,Inf,4,1,1,0,0,1,1,1,Inf,1,Inf,8,1,3)};
  public NativeAllyBrain(NativeGameplayWorld world){w=world;}
  AllySkill Skill=>w.UseLegacyAi?profiles[Math.Max(0,Math.Min(4,w.AiDifficulty))]:BalancedSkill;
  static NativeAllyState S(NativePlayer p)=>p.Ai??(p.Ai=new NativeAllyState());
  static int Man(Vector2Int a,Vector2Int b)=>Math.Abs(a.x-b.x)+Math.Abs(a.y-b.y);
  static int Round(double x)=>(int)Math.Floor(x+.5);
  static bool Finite(double v)=>!double.IsInfinity(v)&&!double.IsNaN(v);
  bool Power(NativePlayer p,double t)=>p.PowerUntil>t;
  bool Combat(NativePlayer p,double t)=>w.PlayerProtected(p,t);
  bool AttackPower(NativePlayer p,double t)=>w.CreatureAttackPower(p,t);
  bool CanBite(NativePlayer p,double t)=>w.CreatureBitesAllowed(p,t);
  IEnumerable<NativePlayer> Others(NativePlayer p){for(int i=0;i<w.PlayerCount;i++){var o=w.GetPlayer(i);if(o!=p)yield return o;}}
  bool SafeRoute(NativePlayer p,Vector2Int c,double? t=null)=>w.PlayerRouteSafe(p,c,t);
  Vector2Int Nearest(double x,double y){
   var c=new Vector2Int(Mathf.Clamp(Round(x),0,w.Width-1),Mathf.Clamp(Round(y),0,w.Height-1));if(w.Floor(c))return c;
   for(int r=1;r<Math.Max(w.Width,w.Height);r++)for(int dy=-r;dy<=r;dy++)for(int dx=-r;dx<=r;dx++)if(Math.Abs(dx)+Math.Abs(dy)==r&&w.Floor(c+new Vector2Int(dx,dy)))return c+new Vector2Int(dx,dy);
   return new Vector2Int(1,1);
  }
  short[] BuildField(Vector2Int goal,Func<Vector2Int,Vector2Int,bool> pass){
   int n=w.Width*w.Height;var f=new short[n];for(int i=0;i<n;i++)f[i]=-1;if(bfsQueue==null||bfsQueue.Length!=n)bfsQueue=new int[n];
   int read=0,write=0,k=w.Index(goal);f[k]=0;bfsQueue[write++]=k;
   while(read<write){int cell=bfsQueue[read++];var c=new Vector2Int(cell%w.Width,cell/w.Width);foreach(var d in dirs){var next=c+d;if(!pass(next,goal))continue;int j=w.Index(next);if(f[j]>=0)continue;f[j]=(short)(f[cell]+1);bfsQueue[write++]=j;}}return f;
  }
  public void ScanMaze(bool force=false){
   if(!force&&atlas!=null&&ReferenceEquals(atlasGrid,w.Grid))return;
   if(preparedAtlas!=null&&ReferenceEquals(preparedGrid,w.Grid)){atlas=preparedAtlas;atlasGrid=preparedGrid;preparedAtlas=null;preparedGrid=null;return;}
   int n=w.Width*w.Height;atlas=new short[n][];atlasGrid=w.Grid;var neighbours=new int[n*4];for(int i=0;i<neighbours.Length;i++)neighbours[i]=-1;
   var floor=new List<int>();for(int y=0;y<w.Height;y++)for(int x=0;x<w.Width;x++){var c=new Vector2Int(x,y);if(!w.Floor(c))continue;int k=w.Index(c),slot=0;floor.Add(k);foreach(var d in dirs)if(w.Floor(c+d))neighbours[k*4+slot++]=w.Index(c+d);}
   var q=new int[n];foreach(int target in floor){var f=new short[n];for(int i=0;i<n;i++)f[i]=-1;int read=0,write=0;f[target]=0;q[write++]=target;
    while(read<write){int cell=q[read++];for(int s=0;s<4;s++){int j=neighbours[cell*4+s];if(j<0)break;if(f[j]>=0)continue;f[j]=(short)(f[cell]+1);q[write++]=j;}}atlas[target]=f;}
  }
  short[] Field(double x,double y){ScanMaze();return atlas[w.Index(Nearest(x,y))];}
  short[] Field(Vector2Int c)=>Field(c.x,c.y);
  double Distance(Vector2Int from,Vector2Int target){if(from.x<0||from.y<0||from.x>=w.Width||from.y>=w.Height)return Inf;int v=Field(target)[w.Index(from)];return v<0?Inf:v;}
  short[] ObjectiveField(AllyObjective o){var goal=Nearest(o.target.x,o.target.y);var occupied=o.snake==null?null:new HashSet<Vector2Int>(o.snake.Body);return BuildField(goal,(c,g)=>w.Floor(c)&&(c==g||occupied==null||!occupied.Contains(c)));}
  short[] DetourField(Vector2Int target,NativePlayer p,double t)=>BuildField(Nearest(target.x,target.y),(c,g)=>{
   if(!w.Floor(c))return false;if(c==g||c==p.Cell)return true;
   if(w.SolidEgg(c)||!SafeRoute(p,c,t)||w.Occupied(c)||w.CreatureContactBlocks(p,c,t))return false;
   if(!Combat(p,t)&&(w.HunterAt(c)||w.Hunters.Any(h=>h.Cell+h.Dir==c)||w.Snakes.Any(s=>s.Head+s.Dir==c)))return false;return true;
  });
  List<Vector2Int> Legal(NativePlayer p,double t)=>dirs.Where(d=>w.Floor(p.Cell+d)&&!w.SolidEgg(p.Cell+d)&&SafeRoute(p,p.Cell+d,t)&&!w.CreatureContactBlocks(p,p.Cell+d,t)).ToList();
  double Pressure(NativePlayer p,double t){if(Combat(p,t))return 0;double v=0;foreach(var s in w.Snakes){int d=Man(s.Head,p.Cell);v+=d<=2?2:d<=5?1:0;}foreach(var h in w.Hunters){int d=Man(h.Cell,p.Cell);v+=d<=2?2:d<=4?1:0;}return v;}
  bool CulDeSac(NativePlayer p,Vector2Int next,AllyObjective objective){
   var exits=new HashSet<Vector2Int>(dirs.Select(d=>p.Cell+d).Where(c=>w.Floor(c)&&c!=next));if(exits.Count==0)return false;
   var visited=new HashSet<Vector2Int>{p.Cell,next};var q=new List<Vector2Int>{next};for(int i=0;i<q.Count;i++){var c=q[i];if(objective!=null&&c==objective.target||exits.Contains(c))return false;foreach(var d in dirs){var n=c+d;if(w.Floor(n)&&visited.Add(n))q.Add(n);}}return true;
  }
  void Clean(NativePlayer p,double t){var a=S(p);foreach(var s in a.cooldowns.Keys.ToArray())if(a.cooldowns[s]<=t||!w.Snakes.Contains(s))a.cooldowns.Remove(s);}
  bool Cooling(NativePlayer p,NativeGameplaySnake s,double t)=>S(p).cooldowns.TryGetValue(s,out var until)&&until>t;
  bool Alternative(NativePlayer p,double t,NativeGameplaySnake excluded){Clean(p,t);foreach(var s in w.Snakes){if(s==excluded||Cooling(p,s,t)||s.Body.Count==0)continue;var o=new AllyObjective{target=s.Tail,snake=s,kind=s.Body.Count>1?"tail":"head"};if(ObjectiveField(o)[w.Index(p.Cell)]>=0&&DetourField(o.target,p,t)[w.Index(p.Cell)]>=0)return true;}return false;}
  double Collision(NativePlayer p,Vector2Int d,Vector2Int c,double t,AllyObjective o=null){
   bool powered=AttackPower(p,t);var other=w.TeammateAt(p,c);if(other!=null)return w.CanEatPlayer(p,other,t)&&(w.UseLegacyAi||o?.player==other)?-260:100000;
   if(w.CreatureContactBlocks(p,c,t))return 100000;
   var targetSnake=o?.snake??(o==null?S(p).locked:null);if(w.HunterAt(c))return powered?-180:100000;
   foreach(var s in w.Snakes){int i=s.Body.IndexOf(c);if(i<0)continue;if(s!=targetSnake||o==null||o.target!=c)return 100000;
    if(i==0){if(powered)return -170;bool safe=s.Body.Count==1?d!=-s.Dir:d==s.Dir;return safe?-125:100000;}
    if(i==s.Body.Count-1)return -150;return o.kind=="split"?-185:100000;
   }return 0;
  }
  bool Forecast(NativeGameplaySnake s,Vector2Int c){
   if(!w.Floor(c)||s.Body.Take(Math.Max(0,s.Body.Count-1)).Contains(c)||w.ScorpionAt(c)||w.HunterAt(c)||w.SolidEgg(c))return false;
   if(Man(s.Head,c)!=1)return false;var step=c-s.Head;if(!s.Reversing)return step!=-s.Dir;
   if(s.Body.Count==1)return s.Trail.Count==0||s.Trail[s.Trail.Count-1]!=c;return s.Body[1]!=c;
  }
  bool SnakeMovesAfterDeparture(NativePlayer p,NativeGameplaySnake snake,double t){
   if(w.UseLegacyAi||!PredictivePlanning||!foresightReady||foresightPlayer!=p||Math.Abs(foresightTime-t)>.0001)return false;
   // TickPlayers moves the AI first, then the same Tick advances due snakes.
   // Only a snake not due until after our next move can lose the immediate
   // mouth veto. Budget decaying power/combo and a scheduling margin; the
   // unchanged future search must still find an exit from the entered cell.
   double stay=Math.Max(PredictPlayerDelay(p,t,t),PredictPlayerDelay(p,t+95,t));
   return snake.LastMove+(snake.Reversing?436:218)-t>stay+24;
  }
  double MouthThreat(NativePlayer p,Vector2Int c,double t){if(Combat(p,t))return 0;double v=0;foreach(var s in w.Snakes){if(Man(c,s.Head)!=1||SnakeMovesAfterDeparture(p,s,t))continue;if(c-s.Head==s.Dir)v=Math.Max(v,260);else if(Forecast(s,c))v=Math.Max(v,165);}return v;}
  double Danger(NativePlayer p,Vector2Int d,Vector2Int c,double t){
   double danger=0;if(w.Competitive)foreach(var o in Others(p)){if(o.Dead||o.Lives<=0||!w.CanEatPlayer(o,p,t))continue;int n=Man(o.Cell,c);danger+=c==o.Cell+o.Dir?260:n==1?190:n==2?70:n==3?22:0;}
   if(Combat(p,t))return danger;danger+=MouthThreat(p,c,t);
   foreach(var s in w.Snakes){int n=Man(s.Head,c);danger+=SnakeMovesAfterDeparture(p,s,t)?(n==1?18:n==2?6:0):c==s.Head+s.Dir?90:n==1?54:n==2?13:0;}
   foreach(var h in w.Hunters){int n=Man(h.Cell,c);danger+=c==h.Cell+h.Dir?175:n==1?115:n==2?30:0;}return danger;
  }
  IEnumerable<int> Splits(NativeGameplaySnake s)=>Enumerable.Range(1,Math.Max(0,s.Body.Count-2)).OrderBy(i=>Math.Abs(i-(s.Body.Count-1)/2.0));
  void Thought(NativePlayer p,string kind,Vector2Int target,double danger=0,double score=0){var a=S(p);a.thought=kind;a.thoughtTarget=target;a.thoughtDanger=Round(danger);a.thoughtScore=score;}
  void Choose(NativePlayer p,Vector2Int d,double t){p.Next=d;S(p).lastDirection=d;S(p).decisionAt=t;}
  void ClearRetreat(NativePlayer p){var a=S(p);a.retreat=null;a.recent.Clear();a.blockedStep=null;}
  bool Remember(NativePlayer p,double t){var a=S(p);if(!a.observed.HasValue)a.observed=p.Cell;else if(a.observed!=p.Cell){var move=p.Cell-a.observed.Value;if(a.run==move)a.runLength++;else{a.run=move;a.runLength=1;}a.observed=p.Cell;}
   if(a.recent.Count==0||a.recent[a.recent.Count-1].cell!=p.Cell)a.recent.Add((p.Cell,t));if(a.recent.Count>8)a.recent.RemoveAt(0);int n=a.recent.Count;return n>=4&&a.recent[n-1].cell==a.recent[n-3].cell&&a.recent[n-2].cell==a.recent[n-4].cell;
  }
 }
}


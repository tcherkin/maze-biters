using System;
using System.IO;
using System.Collections;
using System.Text;
using System.Globalization;
using UnityEngine;
namespace MazeBiters.NativeStudy {
 public sealed partial class NativeGameplayStudy {
  [Serializable] sealed class IpadMotionResult{public bool passed;public int width,height,frames,checks,emergencyCorrections;public string note;}
  IEnumerator ProbeIpadCameraMotion(){
   int checks=0;void Check(bool ok,string name){checks++;if(!ok)throw new Exception("iPad rendered motion: "+name);}
   sessionSmoke=true;fixedCamera=false;Reset(12);yield return DrainProbePreparation();
   var p=world.GetPlayer(0);p.Cell=p.From=p.Previous=new Vector2Int(1,1);p.MoveStarted=-1e6;p.LastMove=1000;p.MoveDuration=95;p.ShieldUntil=0;p.Dir=p.Next=Vector2Int.down;
   actors[p.Id].turn.Reset();realClock=time=1000;ResetGameplayCamera();
   string dir=Path.GetDirectoryName(report);Directory.CreateDirectory(dir);var csv=new StringBuilder("frame,time,playerY,beforeY,beforeZoom,afterY,afterZoom,beforeScreenY,afterScreenY\n");
   int direction=1;double waitUntil=4000;
   for(int frame=0;frame<1440;frame++){
    realClock=1000+frame*1000.0/120;time=world.Time=1000+frame*1000.0/120*1.4;world.RealTime=realClock;
    if(realClock>=waitUntil&&time-p.LastMove>95){
     if(p.Cell.y==23&&direction>0||p.Cell.y==1&&direction<0){direction=-direction;waitUntil=realClock+650;var old=p.Dir;p.Dir=p.Next=direction>0?Vector2Int.down:Vector2Int.up;actors[p.Id].turn.Request(Bank(old),Bank(p.Dir),time);}
     else{p.From=p.Previous=p.Cell;p.Cell+=new Vector2Int(0,direction);p.MoveStarted=time;p.LastMove=time;}
    }
    var position=p.Visual(time);string state=MenuFullState;
    ipadLegacyCameraProbe=true;preparationLightFrame=true;Render();double beforeY=cameraViewY,beforeZ=cameraViewZoom;
    bool shot=frame==300||frame==550||frame==850||frame==1250;
    if(shot)Capture(Path.Combine(dir,"before-"+frame+".png"));
    ipadLegacyCameraProbe=false;preparationLightFrame=true;Render();
    Check(p.Visual(time)==position&&MenuFullState==state,"camera does not change the player/simulation");
    double py=(position.y+.5)*16,sy=DisplayFrame.Height/2+(py-cameraViewY)*cameraViewZoom;
    var actorCentre=actors[p.Id].renderer.transform.TransformPoint(new Vector3(.5f,-.5f,0));var projected=camera.WorldToViewportPoint(actorCentre);
    Check(Math.Abs((1-projected.y)*DisplayFrame.Height-sy)<.002,"rendered actor uses exactly the camera transform");
    Check(sy-12*cameraViewZoom>=-.002&&sy+12*cameraViewZoom<=DisplayFrame.Height+.002,"actor stays visible on long vertical route");
    if(shot)Capture(Path.Combine(dir,"after-"+frame+".png"));
    if(frame==800){var v=camera.transform.position;float size=camera.orthographicSize;string clock=ScalarClock(gameplayCamera);scenePreparationPending=true;PrepareSceneGpu();Check(camera.transform.position==v&&camera.orthographicSize==size&&ScalarClock(gameplayCamera)==clock,"GPU preflight preserves visible camera and clocks");}
    var values=new[]{(double)frame,realClock,py,beforeY,beforeZ,cameraViewY,cameraViewZoom,216+(py-beforeY)*beforeZ,sy};for(int i=0;i<values.Length;i++){if(i>0)csv.Append(',');csv.Append(values[i].ToString("R",CultureInfo.InvariantCulture));}csv.AppendLine();
    yield return null;
   }
   File.WriteAllText(Path.Combine(dir,"rendered-motion.csv"),csv.ToString());
   File.WriteAllText(report,JsonUtility.ToJson(new IpadMotionResult{passed=true,width=target.width,height=target.height,frames=1440,checks=checks,emergencyCorrections=ipadCameraMotion.EmergencyCorrections,note="Controlled long vertical route using original 95 ms player interpolation and real rendering. Before/after at identical simulation clocks. Checks actor projection, visibility, animation/state preservation and GPU preflight. Deterministic 120 Hz samples, not a device FPS benchmark."},true));Application.Quit();
  }
 }
}

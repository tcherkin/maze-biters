using System;
namespace MazeBiters.NativeStudy {
 // Forecast depth is independent of the desire to hunt. The existing graded
 // meal/aggression policy keeps the easy ally relaxed while its route sense
 // improves continuously with the shared, speed-scaled level-age intensity.
 public struct NativeAllyForesightProfile {
  public double HorizonMs,Steps,CombinedThreatWeight,OverrideRisk,MinimumGain,ObjectiveWeight,CorridorSteps;
  public int BeamWidth,ExpansionLimit,PocketCells;
  static readonly double[] horizon={450,700,1100,1750,2400},steps={2,3,5,7,10};
  static readonly double[] beam={3,5,8,12,16},expansions={96,160,256,384,512};
  static readonly double[] combined={0,.04,.08,.13,.18},risk={.80,.76,.69,.62,.55},gain={.24,.22,.19,.16,.14};
  static readonly double[] objective={.15,.30,.50,.75,1},pockets={12,20,32,48,64},corridor={1,1.5,2.5,3.5,4};
  static double Blend(double[] values,double x){int lo=(int)x,hi=Math.Min(4,lo+1);return values[lo]+(values[hi]-values[lo])*(x-lo);}
  static int Budget(double[] values,double x)=>(int)Math.Round(Blend(values,x),MidpointRounding.AwayFromZero);
  public static NativeAllyForesightProfile ForIntensity(double intensity){
   double x=double.IsNaN(intensity)?0:Math.Max(0,Math.Min(4,intensity));
   return new NativeAllyForesightProfile{HorizonMs=Blend(horizon,x),Steps=Blend(steps,x),
    BeamWidth=Budget(beam,x),ExpansionLimit=Budget(expansions,x),PocketCells=Budget(pockets,x),
    CombinedThreatWeight=Blend(combined,x),OverrideRisk=Blend(risk,x),MinimumGain=Blend(gain,x),
    ObjectiveWeight=Blend(objective,x),CorridorSteps=Blend(corridor,x)};
  }
 }
}

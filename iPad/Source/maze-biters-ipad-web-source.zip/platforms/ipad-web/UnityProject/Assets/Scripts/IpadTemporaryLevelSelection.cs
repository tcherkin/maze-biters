using System;
using UnityEngine;

namespace MazeBiters.NativeStudy {
 // Temporary keyboard tool. Menu number shortcuts retain their original job.
 public sealed class IpadLevelDigits {
  public string Text {get;private set;}="";
  double until;
  public void Clear(){Text="";until=0;}
  public int Digit(int digit,double now){
   if(digit<0||digit>9)return 0;
   if(now>until)Clear();Text+=(char)('0'+digit);until=now+1.2;
   return Text.Length==2?Confirm():0;
  }
  public int Confirm(){int n=Text=="00"?100:Text.Length==0?0:int.Parse(Text);Clear();return n;}
  public int Poll(double now)=>Text.Length>0&&now>=until?Confirm():0;
 }
 public sealed partial class NativeGameplayWorld {
  int testNextLevel;
  public bool TestLevelSelectionUsed {get;private set;}
  public int NextLevelNumber=>testNextLevel>0?testNextLevel:Level+1;
  public bool RequestTestLevel(int level){
   if(level<1||level>100||!SessionEnabled||Transition||GameOver||GameOverPending||CatalogueFinished)return false;
   testNextLevel=level;TestLevelSelectionUsed=true;BeginLevelTransition();return true;
  }
 }
 public sealed partial class NativeGameplayStudy {
  readonly IpadLevelDigits levelDigits=new IpadLevelDigits();
  NativeGameplayWorld levelDigitsWorld;
  bool TemporaryLevelAvailable=>Application.isFocused&&MenuOwner&&!HideForMenu&&!menuPreparing&&!preparingScene&&!restartPreparing&&scenario==12&&world!=null&&world.SessionEnabled&&!world.Transition&&!world.GameOver&&!world.GameOverPending&&!world.CatalogueFinished;
  bool UpdateTemporaryLevelSelection(){
   if(!ReferenceEquals(levelDigitsWorld,world)||!TemporaryLevelAvailable){levelDigits.Clear();levelDigitsWorld=world;if(!TemporaryLevelAvailable)return false;}
   if(levelDigits.Text.Length>0&&Input.GetKeyDown(KeyCode.Escape)){levelDigits.Clear();return true;}
   if(Input.GetKeyDown(KeyCode.Backspace)){levelDigits.Clear();return false;}
   int selected=0;
   for(int digit=0;digit<=9;digit++)if(Input.GetKeyDown((KeyCode)((int)KeyCode.Alpha0+digit))||Input.GetKeyDown((KeyCode)((int)KeyCode.Keypad0+digit))){selected=levelDigits.Digit(digit,Time.unscaledTimeAsDouble);break;}
   if(selected==0&&(Input.GetKeyDown(KeyCode.Return)||Input.GetKeyDown(KeyCode.KeypadEnter)))selected=levelDigits.Confirm();
   if(selected==0)selected=levelDigits.Poll(Time.unscaledTimeAsDouble);
   if(selected>0)SelectTestLevel(selected);
   return false;
  }
  internal bool SelectTestLevel(int level){
   if(!TemporaryLevelAvailable||level<1||level>100)return false;
   CancelNextMaze();paused=false;world.ClearAllKeys();ClearIpadTouchImmediately();
   return world.RequestTestLevel(level);
  }
  void DrawTemporaryLevelSelection(){
   if(!TemporaryLevelAvailable||levelDigits.Text.Length==0)return;
   var r=Viewport();var style=new GUIStyle(GUI.skin.box){fontSize=Mathf.Clamp((int)(r.height*.022f),14,36),alignment=TextAnchor.MiddleCenter};
   GUI.Box(new Rect(r.center.x-155,r.yMax-70,310,46),"LEVEL "+levelDigits.Text+"  ·  ENTER   /   00 = 100",style);
  }
  [Serializable] sealed class PopulationSnapshot {
   public string revision="20261108-snake-population",digits;
   public int requested,capacity,initial,count,mass,freeFloor,searchNodes,nextLevel;
   public bool testSession,transition;
  }
  public string PopulationState()=>world==null?"{}":JsonUtility.ToJson(new PopulationSnapshot{requested=world.RequestedStartingSnakes,capacity=world.StartingSnakeCapacity,initial=world.StartingSnakeCount,count=world.Snakes.Count,mass=world.StartingSnakeMass,freeFloor=world.SpawnableFloorCells,searchNodes=world.ExtraSpawnSearchNodes,nextLevel=world.NextLevelNumber,testSession=world.TestLevelSelectionUsed,transition=world.Transition,digits=levelDigits.Text});
 }
}

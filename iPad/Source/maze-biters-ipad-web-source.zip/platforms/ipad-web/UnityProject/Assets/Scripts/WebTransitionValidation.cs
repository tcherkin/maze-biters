#if UNITY_EDITOR
using System;
using System.IO;
using System.Linq;
using System.Collections.Generic;
using UnityEngine;
namespace MazeBiters.NativeStudy {
 public static class WebTransitionValidation {
  [Serializable] sealed class Case {public uint seed,rng;public int level,mode,difficulty,nodes;public double milliseconds;public string failure;}
  [Serializable] sealed class Report {public bool passed;public int cases,unchanged,recovered,rerolled,originalFailures,checks;public double maxRecoveryMs;public List<Case> recoveries=new List<Case>();public List<string> failures=new List<string>();}
  sealed class Tape {public uint state;public double Next(){unchecked{state+=0x6D2B79F5;uint v=(state^(state>>15))*(1|state);v^=v+(v^(v>>7))*(61|v);return (v^(v>>14))/4294967296.0;}}}
  static string Shape(NativeGameplayWorld w)=>string.Join(";",w.Snakes.Select(s=>s.Id+":"+s.Palette+":"+s.Temperament.ToString("R")+":"+s.TurnBias.ToString("R")+":"+string.Join("/",s.Body)));
  static NativeGameplayWorld Make(SessionLevel level,int mode,int difficulty,Tape tape){
   var w=new NativeGameplayWorld(level.geometry,tape.Next){Level=level.level,AiDifficulty=difficulty,Difficulty=NativeMazeGenerator.Difficulties[difficulty]};w.SetMode(mode);w.SetStarts(level);
   for(int i=0;i<w.PlayerCount;i++){var p=w.GetPlayer(i);p.Cell=p.From=p.Previous=new Vector2Int(level.starts[i].x,level.starts[i].y);p.Dir=p.Next=level.starts[i].dir;}
   return w;
  }
  [Serializable] sealed class DebugLayout {public string[] grid;public int[] reserved;public Vector2Int[] floor,heads;public int search;}
  public static void DebugCase(){
   var level=new NativeMazeGenerator(221749,1).Generate(2);var w=Make(level,2,2,new Tape{state=202456871});
   try{w.SpawnLevelSnakes();}catch(Exception e){Debug.Log(e.Message);}
   var safety=new NativeSpawnSafety(w);var floor=new List<Vector2Int>();var heads=new List<Vector2Int>();var reserved=new List<int>();
   for(int y=0;y<w.Height;y++)for(int x=0;x<w.Width;x++){var c=new Vector2Int(x,y);if(!w.Floor(c))continue;floor.Add(c);if(safety.Reserved(c))reserved.Add(w.Index(c));foreach(var d in NativeGameplayWorld.Dirs)if(!safety.FacingRisk(c,d))heads.Add(new Vector2Int(w.Index(c),Array.IndexOf(NativeGameplayWorld.Dirs,d)));}
   File.WriteAllText(Path.GetFullPath(Path.Combine(Application.dataPath,"../../Results/transition-recovery/debug-layout.json")),JsonUtility.ToJson(new DebugLayout{grid=level.geometry,floor=floor.ToArray(),heads=heads.ToArray(),reserved=reserved.ToArray(),search=w.OpeningPlacementSearch},true));
  }
  public static void Run(){
   var r=new Report();string output=Path.GetFullPath(Path.Combine(Application.dataPath,"../../Results/transition-recovery/placement-validation.json"));
   Directory.CreateDirectory(Path.GetDirectoryName(output));
   void Check(bool okay,string label){r.checks++;if(!okay)r.failures.Add(label);}
   try{
    for(uint index=0;index<360;index++){
     uint seed=index*7919+17;int level=index<240?2:new[]{1,3,7,13,33,100}[(index-240)%6];int difficulty=index<240?2:(int)(index%5);int mode=index<240?2:(int)(index%6);
     var levelData=new NativeMazeGenerator(seed,NativeMazeGenerator.Difficulties[difficulty]).Generate(level);
     uint rng=seed*913+34;var oldTape=new Tape{state=rng};var newTape=new Tape{state=rng};var old=Make(levelData,mode,difficulty,oldTape);
     string label="seed="+seed+" rng="+rng+" level="+level+" mode="+mode+" tier="+difficulty;bool failed=false;
     try{NativeGameplayWorld.ValidateOriginalOpeningSearch=true;old.SpawnLevelSnakes();}catch(InvalidOperationException e)when(e.Message.StartsWith("Cannot place a complete safe opening population")){failed=true;}finally{NativeGameplayWorld.ValidateOriginalOpeningSearch=false;}
     if(failed)r.originalFailures++;
     var timer=System.Diagnostics.Stopwatch.StartNew();var checkedLevel=WebPlayableMaze.Generate(seed,NativeMazeGenerator.Difficulties[difficulty],level);bool rerolled=!levelData.geometry.SequenceEqual(checkedLevel.geometry);if(rerolled)r.rerolled++;var current=Make(checkedLevel,mode,difficulty,newTape);
     Check(checkedLevel.theme==levelData.theme&&checkedLevel.paletteSeed==levelData.paletteSeed&&checkedLevel.level==level,label+" theme, colour cycle and number preserved");
     try{current.SpawnLevelSnakes();}catch(Exception e){r.failures.Add(label+" "+e.Message);continue;}timer.Stop();r.cases++;
     if(!failed&&!rerolled){Check(Shape(old)==Shape(current)&&oldTape.state==newTape.state,label+" ordinary layout and RNG unchanged");r.unchanged++;}
     else{
      r.recovered++;r.maxRecoveryMs=Math.Max(r.maxRecoveryMs,timer.Elapsed.TotalMilliseconds);r.recoveries.Add(new Case{seed=seed,rng=rng,level=level,mode=mode,difficulty=difficulty,nodes=current.OpeningPlacementSearch,milliseconds=timer.Elapsed.TotalMilliseconds});
      Check(current.OpeningPlacementRecovered||rerolled,label+" recovery exercised");
      var againTape=new Tape{state=rng};var again=Make(checkedLevel,mode,difficulty,againTape);again.SpawnLevelSnakes();Check(Shape(again)==Shape(current)&&againTape.state==newTape.state,label+" deterministic repeated preparation");
      var liveTape=new Tape{state=rng};var live=Make(checkedLevel,mode,difficulty,liveTape);live.Level=level-1;live.LevelLoader=_=>checkedLevel;live.SessionEnabled=live.Transition=true;live.TransitionAt=1000;
      // Reserve music before copying RNG, just as BeginLevelTransition does.
      live.ReserveMusic(level);liveTape.state=rng;var previewTape=new Tape{state=rng};
      var preview=live.PreviewNextLevel(checkedLevel,previewTape.Next,1000+NativeGameplayWorld.ClearDuration);
      live.Tick(1000+NativeGameplayWorld.ClearDuration);
      Check(Shape(live)==Shape(preview)&&live.Level==level&&!live.Transition,label+" recovered preview matches actual Tick installation");
     }
     int count=Math.Min(9,NativeGameplayWorld.DesiredStartingSnakes(level)),average=Math.Max(7,16-count),spread=Math.Min(4,Math.Max(1,(level+1)/2));var lengths=new List<int>();if(count%2==1)lengths.Add(average);for(int p=0;lengths.Count<count;p++){int n=1+p%spread;lengths.Add(average-n);lengths.Add(average+n);}
     Check(current.Snakes.Take(count).Select(s=>s.Body.Count).OrderBy(x=>x).SequenceEqual(lengths.OrderBy(x=>x)),label+" original count and lengths");
     var occupied=new HashSet<Vector2Int>();var safety=new NativeSpawnSafety(current);
     foreach(var s in current.Snakes){
      Check(!safety.FacingRisk(s.Head,s.Dir),label+" safe facing");
      for(int i=0;i<s.Body.Count;i++){var c=s.Body[i];Check(current.Floor(c)&&!safety.Reserved(c)&&occupied.Add(c),label+" floor, protected corridor, overlap");if(i>0){var d=c-s.Body[i-1];Check(Math.Abs(d.x)+Math.Abs(d.y)==1,label+" continuous body");}}
     }
     foreach(var s in current.Snakes)Check(!occupied.Contains(s.Head+s.Dir),label+" free first step");
     if(index%30==0){Debug.Log("WEB_TRANSITION_AUDIT cases="+r.cases+" recovered="+r.recovered+" failures="+r.failures.Count);File.WriteAllText(output,JsonUtility.ToJson(r,true));}
    }
    Check(r.originalFailures>0&&r.recovered>0,"suite reproduces and fixes the original placement failure");r.passed=r.failures.Count==0;
   }finally{NativeGameplayWorld.ValidateOriginalOpeningSearch=false;File.WriteAllText(output,JsonUtility.ToJson(r,true));}
   Debug.Log("WEB_TRANSITION_VALIDATION checks="+r.checks+" cases="+r.cases+" recovered="+r.recovered+" failures="+r.failures.Count);
   if(!r.passed)throw new Exception("Web transition validation failed: "+string.Join(" | ",r.failures.Take(8)));
  }
 }
}
#endif

using System;
using System.Collections.Generic;
using UnityEngine;
namespace MazeBiters.NativeStudy {
 public static class NativeLanternGlideValidation {
  [Serializable]public sealed class Row {public string scenario,operation;public int requested;public double time,brakeMs,started;public Vector2 vector,target,velocity,brakeEnd;public bool viaCenter;}
  [Serializable]public sealed class Evidence {public string revision="glide-clock-v2",retargetModel="bounded-c1-brake-v1";public double durationMs=240,maxBrakeMs=24,maxBrakeTravel=.03;public Row[] calls;}
  public static string Run(){
   CopyTests();
   var rows=new List<Row>();var follow=new NativeLanternGlide();
   void Equal(Vector2 a,Vector2 b,string message){if((a-b).sqrMagnitude>1e-10f)throw new Exception("Glide clock "+message+": "+a+" != "+b);}
   void EqualSpeed(Vector2 a,Vector2 b,string message){if((a-b).sqrMagnitude>1e-18f)throw new Exception("Glide velocity "+message+": "+a+" != "+b);}
   Vector2 Call(string scenario,string operation,double time,int requested){
    if(operation=="reset")follow.Reset(requested,time);else if(operation=="rebase")follow.RebaseTime(time);else follow.Sample(time,requested);
    var v=follow.Current;if(float.IsNaN(v.x)||float.IsNaN(v.y)||v.sqrMagnitude>1.00001f||float.IsNaN(follow.Velocity.x)||float.IsNaN(follow.Velocity.y)||follow.BrakeMs>24.000001||follow.BrakeMs<0)throw new Exception("Invalid flowing aura vector");
    rows.Add(new Row{scenario=scenario,operation=operation,time=time,requested=requested,vector=v,target=follow.Target,viaCenter=follow.ViaCenter,velocity=follow.Velocity,brakeMs=follow.BrakeMs,brakeEnd=follow.BrakeEnd,started=follow.Started});return v;
   }
   foreach(int from in new[]{0,1,2,3})foreach(int to in new[]{0,1,2,3})if(from!=to){
    string name="cardinal-"+from+"-"+to;Call(name,"reset",0,from);
    foreach(int t in new[]{0,30,60,90,120,180,240,360}){
     var v=Call(name,"sample",t,to);
     if(t==0)Equal(v,NativeLanternGlide.Cardinal(from),"initial continuity");
     if(t==120&&NativeLanternGlide.Wrap(to-from)==2)Equal(v,Vector2.zero,"180 centre");
     if(t==120&&NativeLanternGlide.Wrap(to-from)!=2)Equal(v,(NativeLanternGlide.Cardinal(from)+NativeLanternGlide.Cardinal(to))*.5f,"90 diagonal");
     if(t>=240)Equal(v,NativeLanternGlide.Cardinal(to),"settled endpoint");
    }
   }
   Call("interrupt","reset",0,0);Call("interrupt","sample",0,1);var before=Call("interrupt","sample",60,1);
   var speedBefore=follow.Velocity;Equal(Call("interrupt","sample",60,3),before,"same-time retarget continuity");EqualSpeed(follow.Velocity,speedBefore,"retarget velocity continuity");
   Equal(Call("interrupt","sample",60,3),before,"paused retarget");
   EqualSpeed(follow.Velocity,speedBefore,"same-time pause velocity");
   foreach(int t in new[]{90,120})Call("interrupt","sample",t,3);
   Equal(Call("interrupt","sample",180+follow.BrakeMs*.5,3),Vector2.zero,"interrupted180 centre after braking");
   foreach(int t in new[]{240,300})Call("interrupt","sample",t,3);
   Call("quarter-interrupt","reset",0,0);Call("quarter-interrupt","sample",0,1);before=Call("quarter-interrupt","sample",80,1);
   Equal(Call("quarter-interrupt","sample",80,2),before,"quarter retarget continuity");Call("quarter-interrupt","sample",200,2);Call("quarter-interrupt","sample",320,2);
   Call("pause-wrap-reset","reset",50,3);Call("pause-wrap-reset","sample",50,0);before=Call("pause-wrap-reset","sample",170,0);
   Equal(Call("pause-wrap-reset","sample",170,4),before,"equivalent cardinal and pause");
   Equal(Call("pause-wrap-reset","sample",10,-1),NativeLanternGlide.Cardinal(3),"backwards time resets");
   Call("pause-wrap-reset","reset",10,-4);Equal(Call("pause-wrap-reset","sample",10,8),Vector2.right,"modulo resets");
   Call("clock-origin","reset",0,0);Call("clock-origin","sample",0,1);before=Call("clock-origin","sample",60,1);
   speedBefore=follow.Velocity;Equal(Call("clock-origin","rebase",12060,1),before,"rebase preserves visible vector");EqualSpeed(follow.Velocity,speedBefore,"rebase preserves velocity");
   Equal(Call("clock-origin","sample",12060,1),before,"same-time sample after rebase");
   Equal(Call("clock-origin","sample",12120,1),new Vector2(.5f,.5f),"rebase preserves phase");
   Equal(Call("clock-origin","sample",12240,1),Vector2.up,"rebase preserves finish time");
   Call("clock-origin-retarget","reset",0,0);Call("clock-origin-retarget","sample",0,1);before=Call("clock-origin-retarget","sample",60,1);
   Call("clock-origin-retarget","rebase",12060,1);
   Equal(Call("clock-origin-retarget","sample",12060,3),before,"retarget after rebase preserves position");
   Equal(Call("clock-origin-retarget","sample",12180+follow.BrakeMs*.5,3),Vector2.zero,"rebased interrupted reversal visits centre");
   Equal(Call("clock-origin-retarget","sample",12300,3),Vector2.down,"rebased retarget finishes");
   foreach(double interruptAt in new[]{1d,30,120,220,239}){
    string name="c1-at-"+interruptAt;Call(name,"reset",0,0);Call(name,"sample",0,1);before=Call(name,"sample",interruptAt,1);speedBefore=follow.Velocity;
    Equal(Call(name,"sample",interruptAt,3),before,"early/late position continuity");EqualSpeed(follow.Velocity,speedBefore,"early/late velocity continuity");
    if((follow.BrakeEnd-before).magnitude>.030001)throw new Exception("Brake travel exceeded");
    double b=follow.BrakeMs;if(b>0){Call(name,"sample",interruptAt+b*.5,3);Call(name,"sample",interruptAt+b,3);Equal(follow.Velocity,Vector2.zero,"brake ending velocity");}
    Call(name,"sample",interruptAt+b+(240-b)*.5,3);Equal(follow.Current,Vector2.zero,"braked reversal centre");Call(name,"sample",interruptAt+240,3);
   }
   // Render rates cannot affect this analytic clock. Include command timestamps
   // explicitly so every replay receives identical input events, not late polls.
   var checkpoints=new Dictionary<double,Vector2>();
   foreach(int fps in new[]{30,60,120,240}){
    string name="rapid-fps-"+fps;Call(name,"reset",0,0);var times=new SortedSet<double>{0,20,60,80,120,140,160,200,240,300,380,460};
    for(int k=1;k<=Math.Ceiling(460d*fps/1000);k++)times.Add(Math.Min(460,k*1000d/fps));int priorTarget=0;
    foreach(double t in times){int next=t>=140?0:t>=60?3:1;
     if(next!=priorTarget){before=Call(name,"sample",t,priorTarget);speedBefore=follow.Velocity;Equal(Call(name,"sample",t,next),before,"rapid retarget position");EqualSpeed(follow.Velocity,speedBefore,"rapid retarget velocity");priorTarget=next;}else Call(name,"sample",t,next);
     if(t==20||t==80||t==120||t==160||t==200||t==240||t==300||t==380){if(checkpoints.TryGetValue(t,out var expected))Equal(follow.Current,expected,"render-rate independence");else checkpoints[t]=follow.Current;}
    }
   }
   return JsonUtility.ToJson(new Evidence{calls=rows.ToArray()},true);
  }
  public static int CopyTests(){
   var original=new NativeLanternGlide();original.Reset(0,0);original.Sample(0,1);original.Sample(60,1);original.Sample(60,3);original.Sample(62,3);
   var snapshot=original.Copy();var savedPosition=original.Current;var savedVelocity=original.Velocity;double savedStart=original.Started,savedBrake=original.BrakeMs;
   snapshot.Sample(140,0);snapshot.RebaseTime(12140);
   if(original.Current!=savedPosition||original.Velocity!=savedVelocity||original.Started!=savedStart||original.BrakeMs!=savedBrake)throw new Exception("Aura snapshot mutated original clock");
   var a=original.Copy();var b=original.Copy();a.Sample(150,3);b.Sample(150,3);
   if(a.Current!=b.Current||a.Velocity!=b.Velocity||a.BrakeMs!=b.BrakeMs)throw new Exception("Aura snapshots did not preserve exact independent state");
   original.Sample(300,3);if(a.Current==original.Current&&a.Velocity==original.Velocity)throw new Exception("Aura snapshot aliases advanced original");
   return 3;
  }
 }
}

using System;using System.Globalization;using UnityEngine;
namespace MazeBiters.NativeStudy {
 public sealed partial class NativeHud {
  internal const double ComboPulseDuration=620;
  internal const double ComboReadDuration=600,ComboFadeDuration=200;
  const float ComboFontSize=12,ComboScriptScale=.58f;
  readonly Row[] comboRows=new Row[3];
  readonly ComboVisual[] comboVisuals=new ComboVisual[3];
  readonly string[] comboLabels=new string[3];
  struct ComboVisual {
   internal NativeComboState source;internal int snakes,exponent;internal bool active;
   internal double stamp,sweepAt,pulseAt;
  }
  static int ComboBaseRow(int slot)=>slot==0?0:slot==1?4:6;
  float ParticipantTextWidth(int count)=>Math.Max(24,count==3?frameWidth/4-8:Math.Min(rows[2].left,rows[3].left)-8);
  void CreateComboRows(){for(int i=0;i<comboRows.Length;i++){comboRows[i]=new Row(root.transform);comboRows[i].go.name="HUD combo player "+(i+1);comboRows[i].go.SetActive(false);}}
  void SetComboQuality(){foreach(var row in comboRows){row.material.mainTexture=font;row.material.SetTexture("_Beam",beam);row.beamX=double.NaN;}}
  void HideComboRows(){foreach(var row in comboRows)if(row.go.activeSelf)row.go.SetActive(false);}
  void ResetComboHud(){Array.Clear(comboVisuals,0,comboVisuals.Length);HideComboRows();}
  internal static string ComboDisplayLabel(int exponent)=>exponent<=30?"COMBO X"+(1L<<Math.Max(0,exponent)).ToString(CultureInfo.InvariantCulture):"COMBO X2^"+exponent.ToString(CultureInfo.InvariantCulture);
  // One original LEVEL-style pass each 1240ms, continually right/left/right.
  // The modulo joins at the same endpoint; upgrades retain this phase.
  internal static double ComboBeamLeft(double start,double left,double right,double t,double density){
   double phase=Math.Max(0,t-start)%(LifeSweep*2),travel=phase<LifeSweep?1-phase/LifeSweep:(phase-LifeSweep)/LifeSweep;
   double x=left-72+travel*(right-72*.18-(left-72));return Math.Floor(x*density+.5)/density;
  }
  internal static double ComboPulseAlpha(double start,double t){
   double elapsed=t-start;if(!double.IsFinite(start)||elapsed<0||elapsed>=ComboPulseDuration)return 1;
   double wave=Math.Sin(Math.PI*elapsed/ComboPulseDuration);return 1-.30*wave*wave;
  }
  internal void NotifyCombo(NativePlayer player,double t){
   int slot=player.Id-1;if(slot<0||slot>=comboVisuals.Length||!player.Combo.Active||player.Combo.SnakeCount<2)return;
   var state=player.Combo;var visual=comboVisuals[slot];
   if(!visual.active||visual.source!=state||state.MultiplierExponent<=visual.exponent)visual.sweepAt=t;
   visual.active=true;visual.source=state;visual.snakes=state.SnakeCount;visual.exponent=state.MultiplierExponent;
   visual.stamp=state.LastUpgradeAt;visual.pulseAt=t;comboVisuals[slot]=visual;
  }
  void ComboText(int slot,int exponent,int count){
   var row=comboRows[slot];bool right=slot>0&&(count==2||slot==2);float anchor=right?frameWidth:slot==1?frameWidth/4:0;
   float available=Math.Max(24,(count==3?frameWidth/4:frameWidth/2)-8);
   if(row.value==exponent&&row.anchor==anchor&&row.rightAligned==right&&row.textWidthLimit==available)return;
   row.value=exponent;row.anchor=anchor;row.rightAligned=right;row.textWidthLimit=available;row.yPosition=32;MeshUpdates++;
   string label=ComboDisplayLabel(exponent),text=exponent<=30?label:"COMBO X2"+exponent.ToString(CultureInfo.InvariantCulture);comboLabels[slot]=label;row.prefix=text;
   bool scripted=exponent>30;float units=scripted?8+(text.Length-8)*ComboScriptScale:text.Length,size=Math.Min(ComboFontSize,available/units),width=units*size;
   float x=right?anchor-width:anchor;row.left=x;row.right=x+width;int n=0,m=0;
   for(int i=0;i<text.Length;i++){
    bool superscript=scripted&&i>=8;float glyph=superscript?size*ComboScriptScale:size,y=superscript?32:34;
    int c=Characters.IndexOf(text[i]);if(c>=0){float u=(float)c/Characters.Length,u2=(float)(c+1)/Characters.Length;
     row.vertices[n]=new Vector3(x,32-y,-3);row.vertices[n+1]=new Vector3(x+glyph,32-y,-3);row.vertices[n+2]=new Vector3(x+glyph,32-y-glyph,-3);row.vertices[n+3]=new Vector3(x,32-y-glyph,-3);
     row.uv[n]=new Vector2(u,1);row.uv[n+1]=new Vector2(u2,1);row.uv[n+2]=new Vector2(u2,0);row.uv[n+3]=new Vector2(u,0);
     row.triangles[m++]=n;row.triangles[m++]=n+1;row.triangles[m++]=n+2;row.triangles[m++]=n;row.triangles[m++]=n+2;row.triangles[m++]=n+3;n+=4;
    }x+=glyph;
   }
   row.mesh.Clear();row.mesh.SetVertices(row.vertices,0,n);row.mesh.SetUVs(0,row.uv,0,n);row.mesh.SetTriangles(row.triangles,0,m,0);row.mesh.RecalculateBounds();
  }
  void RenderCombos(NativeGameplayWorld world,double t,bool advanceClock){
   for(int slot=0;slot<comboRows.Length;slot++){
    var row=comboRows[slot];var visual=comboVisuals[slot];var p=slot<world.PlayerCount?world.GetPlayer(slot):null;var state=p?.Combo;
    bool eligible=p!=null&&!world.UseLegacyAi&&!p.Dead&&p.Lives>0;
    bool feeding=eligible&&state.ActiveAt(world.Time)&&state.SnakeCount>=2;
    double cueAge=t-visual.pulseAt;
    bool cue=eligible&&visual.active&&visual.source==state&&cueAge>=0&&cueAge<ComboReadDuration+ComboFadeDuration;
    bool visible=feeding||cue;
    if(!visible){if(row.go.activeSelf)row.go.SetActive(false);if(advanceClock)comboVisuals[slot]=default;continue;}
    if(feeding){
    bool newChain=!visual.active||visual.source!=state||state.MultiplierExponent<visual.exponent||state.MultiplierExponent==visual.exponent&&state.LastUpgradeAt!=visual.stamp;
    if(newChain){visual.sweepAt=t;visual.pulseAt=t;}
    else if(state.MultiplierExponent!=visual.exponent||state.LastUpgradeAt!=visual.stamp)visual.pulseAt=t;
    visual.active=true;visual.source=state;visual.snakes=state.SnakeCount;visual.exponent=state.MultiplierExponent;visual.stamp=state.LastUpgradeAt;
    }
    if(advanceClock)comboVisuals[slot]=visual;
    ComboText(slot,visual.exponent,world.PlayerCount);if(!row.go.activeSelf)row.go.SetActive(true);
    double x=ComboBeamLeft(visual.sweepAt,row.left,row.right,t,scale),opacity=ComboPulseAlpha(visual.pulseAt,t);
    if(!feeding){double u=Math.Max(0,Math.Min(1,(t-visual.pulseAt-ComboReadDuration)/ComboFadeDuration));opacity*=1-u*u*(3-2*u);}
    if(row.opacity!=opacity){row.opacity=opacity;row.material.SetFloat("_Opacity",(float)opacity);}if(!row.active){row.active=true;row.material.SetFloat("_BeamOn",1);}if(row.beamX!=x){row.beamX=x;row.material.SetFloat("_BeamX",(float)x);}
    // A row can appear while its score/lives pair is already faded. Apply the
    // current shared envelope immediately, before the next contact update.
    row.material.SetFloat(OcclusionOpacity,(float)contactAlpha[ComboBaseRow(slot)]);
   }
  }
  internal string ComboLabel(int slot)=>ComboShown(slot)?comboLabels[slot]:string.Empty;
  internal bool ComboShown(int slot)=>slot>=0&&slot<comboRows.Length&&comboRows[slot].go.activeSelf;
  internal double ComboSweepStartedAt(int slot)=>comboVisuals[slot].active?comboVisuals[slot].sweepAt:double.NegativeInfinity;
  internal double ComboPulseStartedAt(int slot)=>comboVisuals[slot].active?comboVisuals[slot].pulseAt:double.NegativeInfinity;
  internal Rect ComboRect(int slot){var row=comboRows[slot];return new Rect(row.left,row.yPosition,row.right-row.left,16);}
  internal double ComboContactAlpha(int slot)=>contactAlpha[ComboBaseRow(slot)];
  internal bool ComboContact(int slot)=>comboContacts[slot];
 }
}

using System;
using UnityEngine;
namespace MazeBiters.NativeStudy {
 public sealed partial class NativeGameplayWorld {
  // Read-only presentation access; never changes the original respawn rules.
  public Vector2Int IpadCameraSpawn(NativePlayer player)=>StartCell(player);
 }
 public static class IpadCameraRoster {
  static void Include(ref Rect? bounds,Vector2 v){
   if(!bounds.HasValue){bounds=new Rect(v.x,v.y,0,0);return;}
   var b=bounds.Value;bounds=Rect.MinMaxRect(Mathf.Min(b.xMin,v.x),Mathf.Min(b.yMin,v.y),Mathf.Max(b.xMax,v.x),Mathf.Max(b.yMax,v.y));
  }
  public static Rect? Bounds(NativeGameplayWorld world,double time,bool previous=false,int excludeMask=0){
   if(world==null||world.GameOver||world.Transition)return null;
   int living=0;for(int i=0;i<world.PlayerCount;i++){var p=world.GetPlayer(i);if(!p.Dead&&!p.Eliminated)living++;}
   Rect? b=null;for(int i=0;i<world.PlayerCount;i++){var p=world.GetPlayer(i);
    // Match the original PC subject selection: a skull must not pin a living
    // teammate's camera until its last blink and then release the zoom at once.
    if((excludeMask&(1<<(p.Id-1)))!=0||p.Eliminated||p.Dead&&(p.HideDeath||!previous&&living>0))continue;
    var v=p.Visual(time);Include(ref b,new Vector2((v.x+.5f)*16,(v.y+.5f)*16));
   }return b;
  }
  // Historical anticipation reference used only by before/after probes.
  public static Rect? Upcoming(NativeGameplayWorld world,double time,Rect? active){
   if(world==null||!world.Multiplayer||world.GameOver||world.Transition)return null;
   Rect? b=active;bool upcoming=false;
   for(int i=0;i<world.PlayerCount;i++){var p=world.GetPlayer(i);
    // Reserve the destination during the last part of the existing skull
    // animation. Keep it reserved if the original spawn is temporarily blocked.
    if(!p.Dead||p.Eliminated||p.Lives<=0||p.RespawnAt-time>1500)continue;
    var cell=world.IpadCameraSpawn(p);var destination=new Vector2((cell.x+.5f)*16,(cell.y+.5f)*16);
    var origin=active.HasValue?active.Value.center:destination;
    float weight=(float)IpadFraming.Smooth((1500-(p.RespawnAt-time))/400);
    Include(ref b,Vector2.Lerp(origin,destination,weight));upcoming=true;
   }return upcoming?b:null;
  }
 }
}

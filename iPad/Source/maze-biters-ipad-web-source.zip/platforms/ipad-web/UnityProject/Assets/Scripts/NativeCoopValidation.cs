using System;using System.IO;using System.Linq;using UnityEngine;using System.Collections.Generic;
namespace MazeBiters.NativeStudy {
 [Serializable] sealed class CoopTargetSample {public double time,until;public int id,draws;}
 [Serializable] sealed class CoopTargetCase {public int seed;public CoopTargetSample[] samples;}
 [Serializable] sealed class CoopDeathSnapshot {public int draws;public bool pending;public double until,anger;public double[] threats,hunterThreats;}
 [Serializable] sealed class CoopDeathCase {public int seed,id;public CoopDeathSnapshot first,second;}
 [Serializable] sealed class CoopOracle {public SessionSpawnTest[] spawns;public CoopTargetCase[] targets;public CoopDeathCase[] deaths;}
 public static class NativeCoopValidation {
  sealed class Tape{uint state;public int Draws;public Tape(int n){state=(uint)n;}public double Next(){Draws++;unchecked{state+=0x6D2B79F5;uint v=(state^(state>>15))*(1|state);v^=v+(v^(v>>7))*(61|v);return (v^(v>>14))/4294967296.0;}}}
  [Serializable] sealed class CameraPoint {public double x,y;public bool dead,eliminated,hideDeathSprite;}
  [Serializable] sealed class CameraCase {public CameraPoint p1,p2,p3;public double time,zoom,x,y,targetZoom;public bool presentation;public int subjects,living;}
  [Serializable] sealed class CameraCases {public CameraCase[] cases;}
  public static int Camera(bool duo=false){
   var data=JsonUtility.FromJson<CameraCases>(File.ReadAllText(Path.Combine(WebFiles.Root,"Reference/"+(duo?"duo-ai":"coop")+"-camera.json")));var w=new NativeGameplayWorld(NativeLevelCatalogue.Get(1).geometry,()=>.5);w.SetMode(duo?4:5);var c=new NativeGameplayCamera();c.Reset(0);int n=0;
   foreach(var s in data.cases){for(int i=0;i<w.PlayerCount;i++){var p=w.GetPlayer(i);var v=i==0?s.p1:i==1?s.p2:s.p3;p.From=new Vector2Int((int)Math.Floor(v.x),(int)v.y);p.Cell=new Vector2Int((int)Math.Ceiling(v.x),(int)v.y);p.MoveDuration=1;p.MoveStarted=s.time-(v.x-Math.Floor(v.x));p.Dead=v.dead;p.Eliminated=v.eliminated;p.HideDeath=v.hideDeathSprite;}c.UpdateRoster(w,s.presentation,s.time,s.time);
    void Near(double a,double b,string label){n++;if(Math.Abs(a-b)>1e-7)throw new Exception("Coop camera "+s.time+" "+label+" "+a+"/"+b);}
    Near(c.Zoom,s.zoom,"zoom");Near(c.X,s.x,"x");Near(c.Y,s.y,"y");Near(c.TargetZoom,s.targetZoom,"target");Near(c.Subjects,s.subjects,"subjects");Near(c.Living,s.living,"living");
   }return n;
  }
  public static int Run(){
   int checks=0;void Check(bool ok,string text){checks++;if(!ok)throw new Exception("CO-OP: "+text);}void Near(double a,double b,string text)=>Check(Math.Abs(a-b)<1e-7,text+" "+a+"/"+b);
   NativeGameplayWorld World(Tape rng,int n=1){var level=NativeLevelCatalogue.Get(n);var w=new NativeGameplayWorld(level.geometry,rng.Next){Level=n,SessionEnabled=true,LevelLoader=NativeLevelCatalogue.Get};w.SetMode(5);w.SetStarts(level);for(int i=0;i<2;i++){var p=w.GetPlayer(i);p.Cell=p.From=p.Previous=new Vector2Int(level.starts[i].x,level.starts[i].y);p.Dir=p.Next=level.starts[i].dir;}return w;}
   var oracle=JsonUtility.FromJson<CoopOracle>(File.ReadAllText(Path.Combine(WebFiles.Root,"Reference/coop-oracle.json")));
   foreach(var t in oracle.spawns){var rng=new Tape(t.seed);var w=World(rng,t.level);w.SpawnLevelSnakes();Check(rng.Draws==t.draws,"spawn draws "+t.level+"/"+t.seed+" "+rng.Draws+"/"+t.draws);Check(w.StartingSnakeMass==t.mass&&w.Snakes.Count==t.snakes.Length,"population");for(int i=0;i<t.snakes.Length;i++){var a=w.Snakes[i];var b=t.snakes[i];Check(a.Body.SequenceEqual(b.body)&&a.Dir==b.dir&&a.Palette==b.palette,"body/palette");Near(a.Temperament,b.temperament,"temperament");Near(a.TurnBias,b.turn,"turn");}}
   foreach(var t in oracle.targets){var rng=new Tape(t.seed);var w=World(rng);w.GetPlayer(0).Cell=new Vector2Int(3,1);w.GetPlayer(1).Cell=new Vector2Int(20,1);w.GetPlayer(0).Contribution=4;w.GetPlayer(1).Contribution=12;var e=new NativeCreature{Cell=new Vector2Int(10,1)};e.PersonalThreat[0]=2;e.PersonalThreat[1]=5;var state=new NativeBrainState();foreach(var sample in t.samples){var p=w.Brain.SelectTarget(e,state,sample.time);Check(p.Id==sample.id&&rng.Draws==sample.draws,"weighted target and held RNG");Near(state.targetPlayerUntil,sample.until,"target duration");}}
   foreach(var t in oracle.deaths){var rng=new Tape(t.seed);var w=World(rng);var s=new NativeGameplaySnake{Body=new List<Vector2Int>{new Vector2Int(5,1)},Anger=9,AngerPeak=12,AngerFloor=5};s.PersonalThreat[0]=8;s.PersonalThreat[1]=4;w.Snakes.Add(s);var h=new NativeHunter{Cell=new Vector2Int(7,1),Anger=1};h.PersonalThreat[0]=3;h.PersonalThreat[1]=6;w.Hunters.Add(h);w.GetPlayer(0).Lives=w.GetPlayer(1).Lives=1;
    void Verify(CoopDeathSnapshot b){Check(rng.Draws==b.draws&&w.GameOverPending==b.pending,"paired death game-over and RNG");Near(s.Anger,b.anger,"personal calming");for(int i=0;i<2;i++){Near(s.PersonalThreat[i],b.threats[i],"snake personal threat");Near(h.PersonalThreat[i],b.hunterThreats[i],"hunter personal threat");}}
    using(w.ForPlayer(w.PlayerById(t.id)))w.SessionDeath();Verify(t.first);w.Time=1200;using(w.ForPlayer(w.PlayerById(t.id==1?2:1)))w.SessionDeath();Verify(t.second);w.Time=t.second.until-1;w.SessionTick();Check(!w.GameOver,"last victim full skull");w.Time=t.second.until;w.SessionTick();Check(w.GameOver,"game over only after last skull");
   }
   {
    var w=World(new Tape(34));var a=w.GetPlayer(0);var b=w.GetPlayer(1);a.Cell=a.From=new Vector2Int(3,1);b.Cell=b.From=new Vector2Int(4,1);a.Dir=a.Next=Vector2Int.right;b.Dir=b.Next=Vector2Int.left;a.Waiting=b.Waiting=false;a.ShieldUntil=b.ShieldUntil=9999;a.Score=500;
    using(w.ForPlayer(a))w.AdvancePlayer();using(w.ForPlayer(b))w.AdvancePlayer();Check(a.Cell.x==3&&b.Cell.x==4&&!a.Dead&&!b.Dead,"no friendly bite, overlap or swap even with shield and score lead");
    using(w.ForPlayer(a))w.Press("a",Vector2Int.left);using(w.ForPlayer(b))w.Press("ArrowRight",Vector2Int.right);Check(a.Keys.Count==1&&b.Keys.Count==1,"independent input");w.ClearAllKeys();Check(a.Keys.Count==0&&b.Keys.Count==0,"focus loss clears both");
    w.Fruits.Add(new NativeFruit{Cell=b.Cell,Kind=0});using(w.ForPlayer(b))w.CollectFruit();Check(b.Score==50&&a.Score==500&&b.PowerUntil>w.Time&&a.PowerUntil==0,"fruit/score/power belong to consumer");
    a.ShieldUntil=b.ShieldUntil=0;a.Lives=b.Lives=3;using(w.ForPlayer(b))w.SessionDeath();Check(a.Lives==3&&b.Lives==2&&!w.GameOverPending,"survivor continues");w.Snakes.Clear();w.Hunters.Clear();var start=NativeLevelCatalogue.Get(1).starts[1];a.Cell=new Vector2Int(start.x,start.y);w.Time=b.RespawnAt;w.SessionTick();Check(w.GetPlayer(1).Dead&&w.GetPlayer(1).HideDeath,"teammate blocks respawn");a.Cell=new Vector2Int(2,1);w.Time++;w.SessionTick();b=w.GetPlayer(1);Check(!b.Dead&&b.Palette==1&&b.Score==50&&b.ShieldUntil>w.Time,"P2 original respawn and palette");Check(ReferenceEquals(w.Player,a),"actor scope restored");
    // Future scene is detached: no live scores, random draws or per-player state mutate.
    w.Player.Score=100;w.Player.ExactScore=100;using(w.ForPlayer(b)){w.Player.Score=200;w.Player.ExactScore=200;}
    var next=w.PreviewNextLevel(NativeLevelCatalogue.Get(2),new Tape(9).Next,5000);Check(next.PlayerCount==2&&next.GetPlayer(0).Score==600&&next.GetPlayer(1).Score==700&&a.Score==100&&b.Score==200,"two-player preview and bonuses isolated");
   }
   return checks;
  }
 }
}

using System;
using System.Linq;
using UnityEngine;
namespace MazeBiters.NativeStudy {
 public sealed partial class NativeGameplayStudy {
  // Explicit read-only diagnostic sessions only. No gameplay state is injected.
  string WebOrbitState(){
   if(world==null||!Application.absoluteURL.Contains("diagnostic=1"))return "null";
   var slots=new WebOrbitSlot[2];
   for(int i=0;i<slots.Length;i++){
    var pad=ipadOrbit?.Pads[i];var swipe=ipadSwipe?.Pads[i];var player=i<world.PlayerCount?world.GetPlayer(i):null;int mask=0;
    if(player!=null)foreach(var key in player.Keys.Values){if(key.dir.x<0)mask|=1;if(key.dir.x>0)mask|=2;if(key.dir.y<0)mask|=4;if(key.dir.y>0)mask|=8;}
    slots[i]=new WebOrbitSlot{slot=i,source=ipadOrbit!=null?ipadOrbit.SourceFor(i).ToString():(swipe!=null&&swipe.Held?"LegacySwipe":"External"),finger=pad?.FingerId??swipe?.FingerId??-1,held=pad?.Held??swipe?.Held??false,direction=pad?.Direction??-1,alpha=pad?.Alpha??0,
     centerX=pad?.Center.x??0,centerY=pad?.Center.y??0,offsetX=pad?.ThumbOffset.x??0,offsetY=pad?.ThumbOffset.y??0,radius=pad?.Radius??0,lightAngle=pad?.LightAngle??0,lightStrength=pad?.LightStrength??0,
     human=player!=null&&!player.IsAI,dead=player==null||player.Dead,keys=player==null?new string[0]:player.Keys.Keys.ToArray(),heldMask=mask,
     cellX=player?.Cell.x??-1,cellY=player?.Cell.y??-1,pointer=player!=null&&player.Pointer.HasValue};
   }
   return JsonUtility.ToJson(new WebOrbitSnapshot{slots=slots,width=UnityEngine.Device.Screen.width,height=UnityEngine.Device.Screen.height,touchStyle=IpadTouchSettings.Style.ToString(),enabled=OrbitControls,resourcesAllocated=ipadOrbitRenderer!=null,swipeFinger=ipadSwipe?.Pads[0].FingerId??-1,duoSwipe=ipadSwipe?.Duo??false});
  }
  [Serializable] sealed class WebOrbitSnapshot {public string revision="20261108-duo-swipe",palette="moonstone",touchStyle;public int directions=8,width,height,swipeFinger;public bool enabled,resourcesAllocated,duoSwipe;public WebOrbitSlot[] slots;}
  [Serializable] sealed class WebOrbitSlot {public int slot,finger,direction,heldMask,cellX,cellY;public bool held,human,dead,pointer;public string source;public string[] keys;public float alpha,centerX,centerY,offsetX,offsetY,radius,lightAngle,lightStrength;}
 }
}

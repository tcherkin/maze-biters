using System;
using System.Linq;
using UnityEngine;
namespace MazeBiters.NativeStudy {
 public sealed partial class NativeGameplayStudy {
  // Explicit read-only diagnostic sessions only. No gameplay state is injected.
  string WebOrbitState(){
   if(world==null||!Application.absoluteURL.Contains("diagnostic=1"))return "null";
   var slots=new WebOrbitSlot[2];
   for(int i=0;i<slots.Length;i++){
    var pad=ipadOrbit.Pads[i];var player=i<world.PlayerCount?world.GetPlayer(i):null;int mask=0;
    if(player!=null)foreach(var key in player.Keys.Values){if(key.dir.x<0)mask|=1;if(key.dir.x>0)mask|=2;if(key.dir.y<0)mask|=4;if(key.dir.y>0)mask|=8;}
    slots[i]=new WebOrbitSlot{slot=i,source=ipadOrbit.SourceFor(i).ToString(),finger=pad.FingerId,held=pad.Held,direction=pad.Direction,alpha=pad.Alpha,
     centerX=pad.Center.x,centerY=pad.Center.y,offsetX=pad.ThumbOffset.x,offsetY=pad.ThumbOffset.y,radius=pad.Radius,lightAngle=pad.LightAngle,lightStrength=pad.LightStrength,
     human=player!=null&&!player.IsAI,dead=player==null||player.Dead,keys=player==null?new string[0]:player.Keys.Keys.ToArray(),heldMask=mask,
     cellX=player?.Cell.x??-1,cellY=player?.Cell.y??-1,pointer=player!=null&&player.Pointer.HasValue};
   }
   return JsonUtility.ToJson(new WebOrbitSnapshot{slots=slots,width=UnityEngine.Device.Screen.width,height=UnityEngine.Device.Screen.height});
  }
  [Serializable] sealed class WebOrbitSnapshot {public string revision="20261108-orbit-touch",palette="moonstone";public int directions=8,width,height;public WebOrbitSlot[] slots;}
  [Serializable] sealed class WebOrbitSlot {public int slot,finger,direction,heldMask,cellX,cellY;public bool held,human,dead,pointer;public string source;public string[] keys;public float alpha,centerX,centerY,offsetX,offsetY,radius,lightAngle,lightStrength;}
 }
}

using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using UnityEngine;
namespace MazeBiters.NativeStudy {
 [Serializable] public sealed class AudioEventCase {public string name;public string[] sounds;public bool passed;}
 [Serializable] public sealed class AudioEventAudit {public bool passed;public AudioEventCase[] cases;public string[] covered;}
 [Serializable] public sealed class AudioClipAudit {public string name;public bool passed;public double energy,seconds;}
 [Serializable] public sealed class AudioFullAudit {public bool passed,overlap;public AudioEventAudit events;public AudioClipAudit[] clips;}
 // Diagnostics only. Expectations were checked against the frozen original
 // playSound/playRandomSound call sites, not inferred from the native mapping.
 public static class NativeAudioAudit {
  public static AudioEventAudit Events(){
   var cases=new List<AudioEventCase>();var covered=new HashSet<string>();
   void Run(string name,double random,Action<NativeGameplayWorld> act,params string[] expected){
    var w=new NativeGameplayWorld(NativeLevelCatalogue.Get(1).geometry,()=>random){SessionEnabled=true,Time=1000,RealTime=1000,PlayerStart=new Vector2Int(1,1)};
    w.Player.Cell=w.Player.From=w.Player.Previous=w.PlayerStart;
    // Keep isolated creature consumption from also completing the level.
    w.AddSnake(new[]{new Vector2Int(33,1)},Vector2Int.right,0);
    var heard=new List<string>();w.Event=e=>{if(e.Kind=="sound"){
     if(e.Time!=w.Time)throw new Exception("Audio event clock: "+name);
     bool global=e.Sound=="Congratulations"||e.Sound=="Game_Over";
     if(e.GlobalSound!=global)throw new Exception("Audio event spatial scope: "+name);
     heard.Add(e.Sound);covered.Add(e.Sound);
    }};
    act(w);bool ok=heard.SequenceEqual(expected);
    cases.Add(new AudioEventCase{name=name,sounds=heard.ToArray(),passed=ok});
    if(!ok)throw new Exception("AUDIO_EVENT_AUDIT "+name+": ["+string.Join(",",heard)+"] expected ["+string.Join(",",expected)+"]");
   }
   NativeGameplaySnake Snake(NativeGameplayWorld w,int size)=>w.AddSnake(Enumerable.Range(0,size).Select(i=>new Vector2Int(7-i,1)),Vector2Int.right,0);
   string[] body={"Tie1","Tie2","Tie3","Tie5","TieEat"};
   for(int i=0;i<body.Length;i++){
    double r=(i+.5)/body.Length;
    foreach(bool reverse in new[]{false,true})Run("tail-"+body[i]+(reverse?"-reverse":""),r,w=>{var s=Snake(w,4);s.Reversing=reverse;w.Player.Cell=s.Tail;w.Eat(s,3);},body[i]);
    Run("split-"+body[i],r,w=>{var s=Snake(w,5);w.Player.Cell=s.Body[2];w.Eat(s,2);},body[i]);
   }
   foreach(int size in new[]{1,4}){
    Run("head-safe-rear-"+size,.8,w=>{var s=Snake(w,size);w.Player.Cell=s.Head;w.Player.Previous=s.Head-Vector2Int.right;w.Eat(s,0);},"HeadEat");
    Run("head-power-"+size,.8,w=>{var s=Snake(w,size);w.Player.Cell=s.Head;w.ActivatePower();w.Eat(s,0);},"snakeSTART@","HeadEat");
    Run("head-spawn-defensive-"+size,.8,w=>{var s=Snake(w,size);w.Player.Cell=s.Head;w.Player.Previous=s.Head+Vector2Int.right;w.ActivateShield();w.Eat(s,0);if(!w.Snakes.Contains(s)||s.Body.Count!=size||w.Player.Score!=0)throw new Exception("Shield consumed frontal snake head");});
   }
   for(int palette=0;palette<3;palette++)foreach(bool power in new[]{false,true}){
    int colour=palette;Run("hunter-"+palette+(power?"-power":"-spawn"),.8,w=>{
     var h=new NativeHunter{Cell=w.Player.Cell,Palette=colour};w.Hunters.Add(h);if(power)w.ActivatePower();else w.ActivateShield();w.EatHunter(h);
     if(!power&&(!w.Hunters.Contains(h)||w.Player.Score!=0))throw new Exception("Shield consumed hunter");
    },power?new[]{"snakeSTART@","HeadEat"}:Array.Empty<string>());
   }
   Run("hunter-bonus-order",.8,w=>{var h=new NativeHunter{Cell=w.Player.Cell};w.Hunters.Add(h);w.Player.Score=4900;w.Player.ExactScore=4900;w.ActivatePower();w.EatHunter(h);},"snakeSTART@","HeadEat","BonusLife@");
   for(int fruit=0;fruit<4;fruit++)for(int variant=0;variant<3;variant++){
    int kind=fruit;Run("fruit-"+fruit+"-voice-"+(variant+1),(variant+.5)/3,w=>{w.Fruits.Add(new NativeFruit{Cell=w.Player.Cell,Kind=kind});w.CollectFruit();},"EatFruit"+(variant+1),"snakeSTART@");
   }
   foreach(bool tail in new[]{false,true})Run(tail?"scorpion-tail":"scorpion-claws",.8,w=>{var s=w.PlaceScorpion(new Vector2Int(7,1),Vector2Int.right);w.Player.Cell=tail?s.Tail:s.Cell;w.EatScorpion();},"ScorpioEat");
   Run("egg-drop-cracks-hatch",.8,w=>{
    w.PendingDrops.Add(new NativeDrop{Cell=new Vector2Int(9,1),Egg=true,Ready=w.Time});w.ReleaseDrops();
    foreach(double age in new[]{10000.0,11000,12000,13000}){w.Time=1000+age;w.UpdateEggs();}
   },"EggBorn","EggKnock","EggKnock","EggKnock","ManBorn");
   Run("covered-egg-is-silent",.8,w=>{w.Eggs.Add(new NativeEgg{Cell=w.Player.Cell,Born=w.Time-13000});w.UpdateEggs();});
   Run("fruit-drop-is-silent",.8,w=>{w.PendingDrops.Add(new NativeDrop{Cell=new Vector2Int(9,1),Ready=w.Time});w.ReleaseDrops();});
   Run("bonus-life",.8,w=>w.Award(5000),"BonusLife@");
   Run("life-cap-is-silent",.8,w=>{w.Player.Lives=9;w.Award(5000);});
   Run("death",.8,w=>w.SessionDeath(),"HeadDie");
   Run("death-with-oh-no",.1,w=>w.SessionDeath(),"HeadDie","Oh_No");
   Run("respawn-is-silent",.8,w=>{w.Player.Dead=true;w.Player.RespawnAt=w.Time;w.UpdateDeath();});
   Run("level-clear-once",.8,w=>{w.Snakes.Clear();w.CheckLevelComplete();w.CheckLevelComplete();},"Congratulations");
   Run("final-death-and-game-over",.8,w=>{w.Player.Lives=1;w.SessionDeath();w.Time=w.Player.RespawnAt;w.SessionTick();w.SessionTick();},"HeadDie","Game_Over");
   Run("power-warning",.8,w=>{w.ActivatePower();w.Time+=4000;w.UpdatePower();w.Time+=319;w.UpdatePower();w.Time++;w.UpdatePower();},"snakeSTART@","Tick","Tick");
   Run("rapid-tail-to-head",.1,w=>{var s=Snake(w,5);for(int i=0;i<4;i++){w.Player.Cell=s.Tail;w.Eat(s,s.Body.Count-1);w.Time+=48;}w.Player.Cell=s.Head;w.Player.Previous=s.Head-Vector2Int.right;w.Eat(s,0);},"Tie1","Tie1","Tie1","Tie1","HeadEat");
   return new AudioEventAudit{passed=true,cases=cases.ToArray(),covered=covered.OrderBy(s=>s,StringComparer.Ordinal).ToArray()};
  }
  public static AudioFullAudit Mixer(){
   var result=new AudioFullAudit{events=Events()};var go=new GameObject("Offline complete audio audit");var sound=go.AddComponent<NativeSessionAudio>();
   try{
    sound.Initialize(false,false); // Never start the AudioSource: silent offline PCM tests.
    var manifest=JsonUtility.FromJson<SessionSoundList>(File.ReadAllText(Path.Combine(Application.streamingAssetsPath,"Reference/session-audio.json")));
    var rows=new List<AudioClipAudit>();var buffer=new float[8192];
    foreach(var entry in manifest.sounds){
     sound.ResetBus();int accepted=sound.Accepted;sound.Play(entry.name,new Vector2Int(17,1),false,1000);
     var row=new AudioClipAudit{name=entry.name,passed=sound.Accepted==accepted+1&&sound.Voices==1};long frames=0;
     while(sound.Voices>0&&frames<AudioSettings.outputSampleRate*30L){
      sound.MixForValidation(buffer,2);frames+=buffer.Length/2;
      foreach(float sample in buffer){row.passed&=float.IsFinite(sample);row.energy+=(double)sample*sample;}
     }
     row.seconds=frames/(double)AudioSettings.outputSampleRate;row.passed&=row.energy>1e-8&&sound.Voices==0;rows.Add(row);
    }
    sound.ResetBus();int rejects=sound.Rejected;
    for(int i=0;i<16;i++)sound.Play("Tie1",default,true,2000);
    for(int i=0;i<16;i++)sound.Play("HeadEat",default,true,2000);
    int starts=sound.Accepted;bool overlap=sound.Voices==32;
    foreach(string cue in new[]{"ScorpioEat","BonusLife@","snakeSTART@","HeadDie","Game_Over"})sound.Play(cue,default,true,2000);
    overlap&=sound.Voices==32&&sound.Accepted==starts+5&&sound.Rejected==rejects;
    sound.MixForValidation(buffer,2);overlap&=buffer.Any(s=>Math.Abs(s)>0)&&buffer.All(float.IsFinite);
    result.clips=rows.ToArray();result.overlap=overlap;result.passed=result.events.passed&&overlap&&rows.All(r=>r.passed);
    return result;
   }finally{UnityEngine.Object.Destroy(go);}
  }
 }
}

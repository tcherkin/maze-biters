using System;
using System.Collections.Generic;
using UnityEngine;
namespace MazeBiters.NativeStudy {
 // Screen-fixed retained title; original glyphs and beam, no new texture or pass.
 public sealed class HybridLevelNameLabel:IDisposable {
  const string Characters="ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789?";
  readonly Mesh letters=new Mesh{name="Level title glyphs"};
  readonly Material paint=new Material(Shader.Find("MazeBiters/HudGlyph"));
  readonly GameObject label;
  Texture2D texture,beamTexture;string caption="";
  float width=-1,height=-1,centerY=-1,limit=-1,left,right,opacity=-1,glyphSize=-1,appliedZoom=-1;
  public string Caption=>caption;
  public bool Visible=>label&&label.activeSelf;
  public int MeshUpdates{get;private set;}
  public float Opacity=>opacity;
  public float Side{get;private set;}
  public float CenterY=>centerY;
  public float Zoom=>label.transform.localScale.x;
  public Vector3 WorldCenter=>label.transform.TransformPoint(letters.bounds.center);
  public float BeamX{get;private set;}
  public bool BeamActive{get;private set;}
  public HybridLevelNameLabel(Mesh quad,Transform parent){
   label=new GameObject("Level introduction and notice subtitle");label.transform.SetParent(parent,false);
   label.AddComponent<MeshFilter>().sharedMesh=letters;
   var renderer=label.AddComponent<MeshRenderer>();renderer.sharedMaterial=paint;renderer.sortingOrder=112;
   paint.SetFloat("_Opacity",1);paint.SetFloat("_PaletteTintOn",0);label.SetActive(false);
  }
  public void Render(string name,Texture2D font,Texture2D beam,NativeFrame frame,double alpha,float screenCenterY,float maxWidth,double elapsed,bool sweep,bool visible,float fontSize=12,double beamPixelScale=2.5,float titleScale=1,float peakOpacity=.95f){
   visible&=font!=null;name=name??"";
   if(texture!=font){texture=font;paint.mainTexture=font;}
   if(beamTexture!=beam){beamTexture=beam;paint.SetTexture("_Beam",beam);}
   bool rebuild=caption!=name||width!=frame.Width||height!=frame.Height||centerY!=screenCenterY||limit!=maxWidth||glyphSize!=fontSize;
   caption=name;centerY=screenCenterY;limit=maxWidth;glyphSize=fontSize;if(rebuild)Rebuild(frame);
   // Scale around the fixed screen centre without rebuilding vertices. Keep
   // mesh coordinates intact: the travelling beam uses those local positions.
   float zoom=Mathf.Clamp(titleScale,(float)HybridLevelTitleState.MinimumScale,1);
   if(appliedZoom!=zoom||rebuild){
    appliedZoom=zoom;label.transform.localScale=new Vector3(zoom,zoom,1);
    label.transform.localPosition=new Vector3(frame.Width*.5f*(1-zoom),(32-screenCenterY)*(1-zoom),0);
   }
   // The full transparency envelope attenuates both letters and their highlight.
   float value=visible?Mathf.Clamp01(peakOpacity)*Mathf.Clamp01((float)alpha):0;
   if(value!=opacity){opacity=value;paint.SetFloat("_OcclusionOpacity",value);}
   BeamActive=visible&&sweep&&beam;paint.SetFloat("_BeamOn",BeamActive?1:0);
   if(BeamActive){BeamX=(float)NativeHud.BeamLeft(0,HybridLevelTitleState.SweepMs,HybridLevelTitleState.SweepPasses,left,right,elapsed,beamPixelScale);paint.SetFloat("_BeamX",BeamX);}
   label.SetActive(visible&&value>0);
  }
  void Rebuild(NativeFrame frame){
   width=frame.Width;height=frame.Height;MeshUpdates++;
   Side=Mathf.Min(glyphSize,limit/Mathf.Max(1,caption.Length));
   left=(frame.Width-caption.Length*Side)*.5f;right=left+caption.Length*Side;
   float center=32-centerY;
   var vertices=new List<Vector3>();var uv=new List<Vector2>();var triangles=new List<int>();
   for(int i=0;i<caption.Length;i++){
    int glyph=Characters.IndexOf(caption[i]);if(glyph<0)continue;int n=vertices.Count;
    float x=left+i*Side,u=(float)glyph/Characters.Length,u2=(float)(glyph+1)/Characters.Length;
    vertices.AddRange(new[]{new Vector3(x,center+Side*.5f,-3),new Vector3(x+Side,center+Side*.5f,-3),new Vector3(x+Side,center-Side*.5f,-3),new Vector3(x,center-Side*.5f,-3)});
    uv.AddRange(new[]{new Vector2(u,1),new Vector2(u2,1),new Vector2(u2,0),new Vector2(u,0)});triangles.AddRange(new[]{n,n+1,n+2,n,n+2,n+3});
   }
   letters.Clear();letters.SetVertices(vertices);letters.SetUVs(0,uv);letters.SetTriangles(triangles,0);letters.RecalculateBounds();
  }
  public void Dispose(){UnityEngine.Object.Destroy(label);UnityEngine.Object.Destroy(letters);UnityEngine.Object.Destroy(paint);}
 }
 public sealed partial class NativeHud {
  static readonly bool HybridLevelTitleApp=NativeCampaignComposition.Enabled;
  bool SuppressHybridLevelSweep=>HybridLevelTitleApp&&NativeCampaignComposition.Enabled;
  internal bool HybridLevelSweepActive=>rows[2].active;
  internal Texture2D HybridNameFont=>font;
  internal Texture2D HybridNameBeam=>beam;
  internal double HybridNamePixelScale=>scale;
 }
 public sealed partial class NativeGameplayStudy {
  internal bool CampaignPresentationReady=>enabled&&world!=null&&!menuPreparing&&!HideForMenu&&!preparingScene&&!preparingNextScene&&preparationFrames==0&&!discardPreparationDelta&&target&&target.IsCreated()&&actors.Count>0&&neon!=null&&sceneMazeArt!=null;
  HybridLevelNameLabel hybridNameLabel;SessionLevel hybridNamedLevel;string hybridNameCaption;
  HybridLevelTitleState hybridTitleState=new HybridLevelTitleState();
  public string HybridLevelNameCaption=>hybridNameCaption??"";
  void RenderHybridLevelName(){
   if(!NativeCampaignComposition.Enabled||sessionArt==null||hud==null||currentGeneratedLevel==null)return;
   // GPU preflight may swap worlds. It must not adopt a future title identity.
   if(preparingScene||preparingNextScene||logicPreparationInstance){hybridTitleState.Freeze(realClock);return;}
   bool ready=NativeCampaignComposition.Enabled&&CampaignPresentationReady&&world.SessionEnabled;
   hybridTitleState.Tick(world,currentGeneratedLevel,hud.LevelAt,realClock,ready,paused,world.Transition,world.GameOver||world.GameOverPending,world.Time>=world.RevealAt,ResponsiveLevelStatusAlpha??world.StatusAlpha);
   if(hybridNameLabel==null)hybridNameLabel=new HybridLevelNameLabel(quad,sessionArt.ScreenRoot);
   if(ready&&!ReferenceEquals(hybridNamedLevel,currentGeneratedLevel)){hybridNamedLevel=currentGeneratedLevel;hybridNameCaption=HybridLevelNames.EnglishName(currentGeneratedLevel).ToUpperInvariant();}
   bool intro=hybridTitleState.Mode==HybridLevelTitleMode.Intro;
   float cy=intro?DisplayFrame.Height*.5f:DisplayFrame.Height*.5f-4+48;
   double alpha=hybridTitleState.Mode==HybridLevelTitleMode.Pause?sessionArt.HybridPauseAlpha:hybridTitleState.Alpha;
   hybridNameLabel.Render(hybridNameCaption,intro?sessionArt.LevelTitleFont:hud.HybridNameFont,hud.HybridNameBeam,DisplayFrame,alpha,cy,intro?DisplayFrame.Width-32:DisplayFrame.Width*.80f,hybridTitleState.Elapsed,hybridTitleState.Sweep,hybridTitleState.Mode!=HybridLevelTitleMode.Hidden,intro?24:12,hud.HybridNamePixelScale,(float)hybridTitleState.Scale,intro?1:.95f);
  }
  void DisposeHybridLevelName(){hybridNameLabel?.Dispose();hybridNameLabel=null;hybridNamedLevel=null;hybridTitleState=new HybridLevelTitleState();}
 }
}

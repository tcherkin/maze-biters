#if UNITY_EDITOR
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Reflection;
using UnityEngine;

namespace MazeBiters.NativeStudy {
 [Serializable] public sealed class NativeTimeDifficultySample {
  public int difficulty,level;
  public double ageMs,progress,intensity,skill,attack,mealChance,opponentHuntChance,timePressure;
  public int hunterLimit;
 }
 [Serializable] public sealed class NativeTimeDifficultyBrainSample {
  public int difficulty,samples,hunt,evade,away,toward,legal;
  public double ageMs;
 }
 [Serializable] public sealed class NativeTimeDifficultyReport {
  public bool passed;
  public int assertions,failures,decisions;
  public double elapsedMs;
  public string scope;
  public List<NativeDifficultyCheck> checks=new List<NativeDifficultyCheck>();
  public List<NativeTimeDifficultySample> profiles=new List<NativeTimeDifficultySample>();
  public List<NativeTimeDifficultyBrainSample> brains=new List<NativeTimeDifficultyBrainSample>();
 }

 // Editor-only contracts and genuine gameplay decisions. This suite is not a
 // device performance benchmark or a substitute for human balance playtesting.
 public static class NativeTimeDifficultyValidation {
  const int Samples=128;
  static readonly FieldInfo[] ProfileDoubles=typeof(NativeDifficultyProfile).GetFields(BindingFlags.Public|BindingFlags.Instance).Where(f=>f.FieldType==typeof(double)).ToArray();
  static string[] OpenGrid(int width=17,int height=15){var rows=new string[height];for(int y=0;y<height;y++)rows[y]=y==0||y==height-1?new string('#',width):"#"+new string('.',width-2)+"#";return rows;}
  static NativeGameplayWorld World(int difficulty=0,int seed=1,double age=0,int mode=1){
   var w=new NativeGameplayWorld(OpenGrid(),NativeMazeGenerator.Rng((uint)seed)){Difficulty=NativeMazeGenerator.Difficulties[difficulty],AiDifficulty=difficulty,Time=1000+age,LevelStarted=1000,Assist=false};w.SetMode(mode);
   for(int i=0;i<w.PlayerCount;i++){var p=w.GetPlayer(i);p.Cell=p.From=p.Previous=new Vector2Int(3+i*2,7);p.Dir=p.Next=Vector2Int.left;p.Waiting=true;}
   return w;
  }
  static void Check(NativeTimeDifficultyReport r,bool passed,string name,string detail=""){r.assertions++;if(!passed)r.failures++;r.checks.Add(new NativeDifficultyCheck{name=name,passed=passed,detail=detail});}
  static void Group(NativeTimeDifficultyReport r,string name,Action body){try{body();}catch(Exception e){Check(r,false,name+" completed",e.ToString());}}
  static bool Near(double a,double b,double epsilon=1e-9)=>Math.Abs(a-b)<=epsilon;
  static bool Finite(double x)=>!double.IsNaN(x)&&!double.IsInfinity(x);
  static double Value(FieldInfo f,NativeDifficultyProfile p)=>(double)f.GetValue(p);

  static void Profiles(NativeTimeDifficultyReport r){
   Check(r,NativeDifficulty.Progress(-1000)==0&&NativeDifficulty.Progress(0)==0&&NativeDifficulty.Progress(60000)==0,"The first sixty simulation seconds retain the selected difficulty");
   Check(r,NativeDifficulty.Progress(300000)==1&&NativeDifficulty.Progress(86400000)==1,"Escalation reaches its exact bounded endpoint at five simulation minutes");
   var ages=new[]{0.0,60000,120000,180000,240000,300000,600000};
   foreach(int level in new[]{1,5,100})foreach(int index in Enumerable.Range(0,5)){
    var initial=NativeDifficulty.ForIndex(index,level,0);var maximum=NativeDifficulty.ForIndex(4,level,0);
    foreach(double age in ages){
     var p=NativeDifficulty.ForIndex(index,level,age);var w=World(index,17,age);w.Level=level;
     r.profiles.Add(new NativeTimeDifficultySample{difficulty=index,level=level,ageMs=age,progress=p.TimeProgress,intensity=p.Intensity,skill=p.Skill,attack=p.Attack,mealChance=p.MealChance,opponentHuntChance=p.OpponentHuntChance,timePressure=w.TimePressure,hunterLimit=w.ActiveHunterLimit});
     Check(r,Near(p.TimeProgress,NativeDifficulty.Progress(age))&&p.Intensity>=index&&p.Intensity<=4,"Shared clock and bounded effective tier: tier="+index+", level="+level+", age="+age);
     Check(r,p.Maximum==(p.Intensity>=4),"Maximum policy agrees with effective tier: tier="+index+", level="+level+", age="+age);
     var viaMultiplier=NativeDifficulty.For(NativeMazeGenerator.Difficulties[index],level,age);
     Check(r,ProfileDoubles.All(f=>Finite(Value(f,p))&&Near(Value(f,p),Value(f,viaMultiplier))),"All profile values are finite and multiplier/index APIs agree: tier="+index+", level="+level+", age="+age);
     var worldProfile=w.DifficultyProfile;
     Check(r,ProfileDoubles.All(f=>Near(Value(f,p),Value(f,worldProfile))),"Live world reads its current level age: tier="+index+", level="+level+", age="+age);
     if(age<=60000)Check(r,ProfileDoubles.Where(f=>f.Name!="TimeProgress").All(f=>Near(Value(f,p),Value(f,initial))),"No gameplay profile changes during grace: tier="+index+", level="+level+", age="+age);
     if(age>=300000)Check(r,ProfileDoubles.Where(f=>f.Name!="TimeProgress").All(f=>Near(Value(f,p),Value(f,maximum))),"Every gameplay field reaches same-level BRUTAL: tier="+index+", level="+level+", age="+age);
    }
    double previous=index;bool monotonic=true,smooth=true;
    for(int age=0;age<=360000;age+=100){var p=NativeDifficulty.ForIndex(index,level,age);monotonic&=Finite(p.Intensity)&&p.Intensity+1e-12>=previous;smooth&=p.Intensity-previous<.01;previous=p.Intensity;}
    Check(r,monotonic,"Effective tier is monotonic: tier="+index+", level="+level);
    Check(r,smooth,"No sudden tier jump in a 100 ms sweep: tier="+index+", level="+level);
   }
   double middle=NativeDifficulty.ForIndex(0,1,180000).Intensity,late=NativeDifficulty.ForIndex(0,1,240000).Intensity;
   Check(r,middle>=1.5&&middle<=2.5&&late>=2.7&&late<=3.7,"PICNIC advances through the intended middle and late tiers","180 s intensity="+middle+"; 240 s intensity="+late);
  }

  static NativeTimeDifficultyBrainSample BrainMeasure(NativeTimeDifficultyReport r,int difficulty,double age){
   var sample=new NativeTimeDifficultyBrainSample{difficulty=difficulty,ageMs=age,samples=Samples};
   for(int seed=1;seed<=Samples;seed++){
    var w=World(difficulty,seed*7919,age);var s=new NativeGameplaySnake{Id=10,Cell=new Vector2Int(8,7),Dir=new Vector2Int(0,-1),Temperament=.5};
    for(int i=0;i<6;i++)s.Body.Add(s.Cell+new Vector2Int(0,i));w.Snakes.Add(s);
    var options=NativeGameplayWorld.Dirs.Where(d=>w.CanEnter(s.Head+d,s)).ToList();int before=w.Brain.Field(w.Player.Cell)[w.Index(s.Head)];
    var chosen=w.Brain.Choose(s,s.Head,options,NativeGameplayWorld.Profile(s));r.decisions++;
    if(options.Contains(chosen)&&w.CanEnter(s.Head+chosen,s))sample.legal++;
    int after=w.Brain.Field(w.Player.Cell)[w.Index(s.Head+chosen)];if(after<before)sample.toward++;else if(after>before)sample.away++;
    if(s.Brain?.intent=="hunt")sample.hunt++;if(s.Brain?.intent=="evade")sample.evade++;
   }
   r.brains.Add(sample);return sample;
  }
  static void Decisions(NativeTimeDifficultyReport r){
   var early=BrainMeasure(r,0,0);var grace=BrainMeasure(r,0,60000);var late=BrainMeasure(r,0,300000);var brutal=BrainMeasure(r,4,0);
   Check(r,early.hunt<=Samples*.12&&early.away>=Samples*.80,"Healthy PICNIC snakes mostly evade at level start",early.hunt+" hunts; "+early.away+" moves away of "+Samples);
   Check(r,early.hunt==grace.hunt&&early.away==grace.away,"Seeded real snake decisions remain unchanged through the grace period");
   Check(r,late.hunt>=Samples*.90&&late.toward>=Samples*.90,"PICNIC snakes actually engage after five minutes",late.hunt+" hunts; "+late.toward+" moves toward of "+Samples);
   Check(r,late.hunt==brutal.hunt&&late.toward==brutal.toward,"Five-minute PICNIC makes the same seeded choices as initial BRUTAL");
   Check(r,r.brains.All(s=>s.legal==s.samples),"All sampled snake decisions remain legal");
  }

  static void AllyCache(NativeTimeDifficultyReport r){
   var w=World(0,13,0,3);w.Random=()=>.99;w.SessionEnabled=true;var ai=w.GetPlayer(1);ai.Score=200;ai.Waiting=false;w.Ally.BeginLevel();
   // Competitive intelligence now advances only through active simulation.
   // Hold motion to isolate the elapsed-time profile, while retaining the real
   // Tick controller and a genuine weaker human for the endpoint hunt check.
   for(int i=0;i<w.PlayerCount;i++)w.GetPlayer(i).LastMove=1e12;w.Tick(w.Time);
   void AdvanceAge(double age){double end=w.LevelStarted+age;while(w.Time<end)w.Tick(Math.Min(end,w.Time+100));}
   var balance=typeof(NativeAllyBrain).GetProperty("Balance",BindingFlags.NonPublic|BindingFlags.Instance);
   var skill=typeof(NativeAllyBrain).GetProperty("BalancedSkill",BindingFlags.NonPublic|BindingFlags.Instance);
   Check(r,balance!=null&&skill!=null,"AI policy-cache observation is available");if(balance==null||skill==null)return;
   var first=(NativeDifficultyProfile)balance.GetValue(w.Ally);var firstSkill=(AllySkill)skill.GetValue(w.Ally);
   w.Ally.Plan(ai,w.Time);Check(r,!ai.Ai.mealActive&&ai.Ai.thought=="casual-roam","PICNIC AI initially accepts a casual stroll with the high random draw");
   AdvanceAge(180000);var middle=(NativeDifficultyProfile)balance.GetValue(w.Ally);var middleSkill=(AllySkill)skill.GetValue(w.Ally);
   Check(r,middle.Intensity>first.Intensity&&middleSkill.error<firstSkill.error&&middleSkill.rethink<firstSkill.rethink,"AI policy and routing skill refresh as the same level ages","initial="+first.Intensity+"; middle="+middle.Intensity);
   AdvanceAge(300000);var last=(NativeDifficultyProfile)balance.GetValue(w.Ally);w.Ally.Plan(ai,w.Time);
   Check(r,last.Maximum&&ai.Ai.mealActive&&double.IsPositiveInfinity(ai.Ai.mealIntentUntil),"Previously casual PICNIC AI becomes continuously purposeful at the endpoint");
   Check(r,ai.Ai.directive?.type=="hunt","Endpoint AI may engage an eligible weaker human regardless of a high random draw");
   w.LevelStarted=w.Time;w.Ally.BeginLevel();var reset=(NativeDifficultyProfile)balance.GetValue(w.Ally);var resetSkill=(AllySkill)skill.GetValue(w.Ally);
   Check(r,reset.TimeProgress==0&&Near(reset.Intensity,last.Intensity)&&Near(resetSkill.error,0),"Competitive AI resets level age while preserving acquired intelligence at the next level");
   AdvanceAge(1000);var eased=w.AdaptiveAllySample(ai.Id);Check(r,Near(eased.EffectiveIntensity,last.Intensity-1.0/22)&&Near(eased.TargetIntensity,0),"After the new-level reset, competitive intelligence returns gradually toward its selected baseline");
   var only=World(0,13,0,0);only.Ally.BeginLevel();var onlyFirst=(NativeDifficultyProfile)balance.GetValue(only.Ally);only.Time=only.LevelStarted+180000;var onlyMiddle=(NativeDifficultyProfile)balance.GetValue(only.Ally);
   Check(r,Near(onlyFirst.Intensity,0)&&Near(onlyMiddle.Intensity,NativeDifficulty.ForIndex(0,only.Level,180000).Intensity),"AI ONLY retains its original direct level-age profile without a human comparator");
   only.LevelStarted=only.Time;only.Ally.BeginLevel();var onlyReset=(NativeDifficultyProfile)balance.GetValue(only.Ally);Check(r,Near(onlyReset.Intensity,onlyFirst.Intensity)&&onlyReset.TimeProgress==0,"AI ONLY still resets its time-based profile at a new level");
  }

  static void SessionClocks(NativeTimeDifficultyReport r){
   var generator=new NativeMazeGenerator(107,NativeMazeGenerator.Difficulties[0]);var initial=generator.Generate(1);
   var w=new NativeGameplayWorld(initial.geometry,NativeMazeGenerator.Rng(71)){Difficulty=.5,AiDifficulty=0,Time=50000,LevelStarted=1000};w.SetMode(3);w.StartSession(generator.Generate);
   Check(r,w.LevelStarted==w.Time&&w.DifficultyProfile.TimeProgress==0,"A fresh campaign resets level age even on a reused clock");
   w.Time=w.LevelStarted+180000;double started=w.LevelStarted,progress=w.DifficultyProfile.TimeProgress;int deaths=0,respawns=0;w.Event=e=>{if(e.Kind=="death")deaths++;if(e.Kind=="respawn")respawns++;};
   w.SessionDeath();Check(r,w.LevelStarted==started&&Near(w.DifficultyProfile.TimeProgress,progress)&&deaths==1,"A death does not restart escalation");
   w.Snakes.Clear();w.Hunters.Clear();w.Eggs.Clear();w.Scorpion=null;w.Time+=NativeGameplayWorld.DeathDuration;w.UpdateDeath();
   Check(r,!w.GetPlayer(0).Dead&&respawns==1&&w.LevelStarted==started&&w.DifficultyProfile.TimeProgress>=progress,"Respawning retains accumulated level age");
   w.AdvanceLevel();Check(r,w.Level==2&&w.LevelStarted==w.Time&&w.DifficultyProfile.TimeProgress==0,"Normal next-level installation resets escalation");
   var beginning=NativeDifficulty.ForIndex(0,2,0);Check(r,Near(w.DifficultyProfile.Intensity,0)&&Near(w.DifficultyProfile.Skill,beginning.Skill),"Next level restores selected tier while retaining its normal level modifier");
   w.Time+=300000;double before=w.Player.ExactScore;w.ScoreSpeed=1;w.Award(200);Check(r,Near(w.Player.ExactScore-before,100),"Elapsed intelligence does not silently change the selected score multiplier");
  }

  static void SpeedClocks(NativeTimeDifficultyReport r){
   var expected=new[]{.6,.8,1.0,1.25,1.6};Check(r,NativeMenuState.Speeds.SequenceEqual(expected),"All five menu speed multipliers are included in the clock audit");
   var paused=World();var held=paused.DifficultyProfile;paused.RealTime+=86400000;
   Check(r,Near(paused.DifficultyProfile.TimeProgress,held.TimeProgress)&&Near(paused.DifficultyProfile.Intensity,held.Intensity),"Real/presentation time alone cannot age a paused or not-yet-started level");
   foreach(double speed in NativeMenuState.Speeds){
    // This is the live update loop's equation, without a rendered MonoBehaviour.
    // Quiet-world Tick checks isolate clock progression from deaths and levels.
    var w=World();w.Player.Waiting=true;double t=w.Time;
    for(int frame=0;frame<30000;frame++){
     t+=Math.Min(250,10)*speed;w.RealTime=1000+(frame+1)*10;w.Tick(t);
     if(frame==5999){double expectedAge=60000*speed;Check(r,Near(w.DifficultyProfile.TimeProgress,NativeDifficulty.Progress(expectedAge),1e-7),"After 60 real seconds the world uses scaled simulation age, speed="+speed);}
    }
    Check(r,Near(w.DifficultyProfile.TimeProgress,NativeDifficulty.Progress(300000*speed),1e-7),"Five real minutes map through game speed, speed="+speed);
    w.Time=w.LevelStarted+300000;Check(r,w.DifficultyProfile.Maximum,"All speeds converge at 300 simulation seconds, speed="+speed);
   }
  }

  static void SpawnCapacity(NativeTimeDifficultyReport r){
   foreach(double age in new[]{0.0,300000}){
    var w=World(0,91,age);w.LifecycleEnabled=true;int cap=w.ActiveHunterLimit;
    Check(r,cap==(age==0?6:10),"Hunter reservation limit grows from six to ten, age="+age);
    for(int i=0;i<cap-2;i++)w.Hunters.Add(new NativeHunter{Id=100+i,Cell=new Vector2Int(1+i,2),Dir=Vector2Int.right});
    w.Eggs.Add(new NativeEgg{Cell=new Vector2Int(10,4),Born=w.Time});
    w.PendingDrops.Add(new NativeDrop{Cell=new Vector2Int(11,4),Egg=true,Ready=w.Time+100});
    var s=w.PlaceScorpion(new Vector2Int(12,10),Vector2Int.right);s.NextEgg=s.NextFruit=w.Time;
    w.QueueScorpionDrops(new Vector2Int(12,4),true);
    Check(r,w.PendingDrops.Count(d=>d.Egg)==1&&w.PendingDrops.Count(d=>!d.Egg)==1,"Visible and pending eggs reserve hunter capacity without blocking fruit, age="+age);
    w.Time+=100;w.ReleaseDrops();
    Check(r,w.Eggs.Count==2&&w.Fruits.Count==1&&w.PendingDrops.Count==0,"Reserved eggs and normal fruit finish their drop, age="+age);
    int hatch=0;w.Event=e=>{if(e.Kind=="hatch")hatch++;};w.Time+=13000;w.UpdateEggs();
    Check(r,w.Eggs.Count==0&&w.Hunters.Count==cap&&hatch==2,"Reserved visible eggs hatch on schedule at the population cap, age="+age);
    w.Hunters.RemoveAt(0);s.NextEgg=w.Time;s.NextFruit=double.PositiveInfinity;
    w.QueueScorpionDrops(new Vector2Int(13,4),false);s.NextEgg=w.Time;w.QueueScorpionDrops(new Vector2Int(14,4),false);
    Check(r,w.Hunters.Count+w.Eggs.Count+w.PendingDrops.Count(d=>d.Egg)==cap&&w.PendingDrops.Count(d=>d.Egg)==1,"One released hunter slot admits only one pending egg, age="+age);
   }
   {
    var w=World();w.LifecycleEnabled=true;for(int i=0;i<6;i++)w.Hunters.Add(new NativeHunter{Id=100+i,Cell=new Vector2Int(1+i,2)});
    var s=w.PlaceScorpion(new Vector2Int(12,10),Vector2Int.right);s.NextFruit=double.PositiveInfinity;w.Time=w.LevelStarted+300000;
    for(int n=0;n<8;n++){s.NextEgg=w.Time;w.QueueScorpionDrops(new Vector2Int(2+n,4),false);}
    Check(r,w.PendingDrops.Count(d=>d.Egg)==4,"A mature level can fill four additional reserved hunter slots, never more");
   }
   foreach(int index in new[]{0,4})foreach(int level in new[]{1,100}){
    var w=World(index,37,3600000);w.Level=level;w.Random=()=>0;w.EnableLifecycle();
    Check(r,Finite(w.ScorpionSpawnAt)&&w.ScorpionSpawnAt-w.Time>=5000,"Scorpion scheduling preserves minimum interval under full late pressure: tier="+index+", level="+level);
    var s=w.PlaceScorpion(new Vector2Int(12,10),Vector2Int.right);w.ScheduleDrops(s);
    Check(r,Finite(s.NextEgg)&&s.NextEgg-w.Time>=8000,"First egg has a finite minimum preparation interval: tier="+index+", level="+level);
    s.NextEgg=w.Time;s.NextFruit=double.PositiveInfinity;w.QueueScorpionDrops(new Vector2Int(13,4),true);
    Check(r,Finite(s.NextEgg)&&s.NextEgg-w.Time>=12000,"Repeated egg drops retain minimum interval after every multiplier: tier="+index+", level="+level);
    w.EatScorpion();Check(r,w.Scorpion==null&&w.ScorpionSpawnAt-w.Time>=5000,"Eating a scorpion cannot create an immediate late-level respawn loop: tier="+index+", level="+level);
   }
  }
  public static NativeTimeDifficultyReport Run(){
   var watch=Stopwatch.StartNew();var r=new NativeTimeDifficultyReport{scope="Editor-only difficulty contracts; seeded real brain and session/lifecycle decisions. No rendering, no device performance measurement, and no claim of human win-rate balance. Speed tests integrate the live-loop clock equation into a quiet gameplay world."};
   Group(r,"profiles",()=>Profiles(r));Group(r,"snake decisions",()=>Decisions(r));Group(r,"AI age-aware cache",()=>AllyCache(r));Group(r,"session clocks",()=>SessionClocks(r));Group(r,"speed clocks",()=>SpeedClocks(r));Group(r,"spawn capacity",()=>SpawnCapacity(r));
   r.elapsedMs=watch.Elapsed.TotalMilliseconds;r.passed=r.failures==0;return r;
  }
 }
}
#endif

using System;using System.IO;using System.Collections.Generic;using UnityEngine;
namespace MazeBiters.NativeStudy {
 public sealed class NativeSessionPresentation:IDisposable {
  readonly Mesh quad;readonly NativeFrameBorder border;readonly GameObject skull,screenRoot,header;readonly Material skullPaint,headerPaint;public NativeStatusBanner StatusBanner{get;}readonly GameObject[] extraSkulls=new GameObject[2];readonly Material[] extraSkullPaint=new Material[2];public Material PlayerSkullMaterial(int slot)=>slot==0?skullPaint:extraSkullPaint[slot-1];public Matrix4x4 PlayerSkullTransform(int slot)=>slot==0?SkullTransform:extraSkulls[slot-1]?extraSkulls[slot-1].transform.localToWorldMatrix:Matrix4x4.identity;Texture2D skullTexture,font;string quality,clearCaption;int captionLevel=-1;
  public Transform ScreenRoot=>screenRoot.transform;
  internal void SetDistantSkyVisible(bool visible)=>border.SetBackgroundVisible(visible);
  public Material SkullMaterial=>skullPaint;public Matrix4x4 SkullTransform=>skull.transform.localToWorldMatrix;
  public NativeSessionPresentation(Mesh quad){this.quad=quad;Material Paint()=>new Material(Shader.Find("MazeBiters/SessionImage"));
   skullPaint=Paint();skull=Make("Original death skull",quad,skullPaint,10);
   skull.transform.localScale=new Vector3(16,16,1);
   screenRoot=new GameObject("Fixed gameplay overlays");StatusBanner=new NativeStatusBanner(quad,screenRoot.transform);
   headerPaint=Paint();headerPaint.SetColor("_Color",Color.black);header=Make("World clipping at HUD boundary",quad,headerPaint,100);header.transform.SetParent(screenRoot.transform,false);header.transform.localPosition=new Vector3(0,32,-3);header.transform.localScale=new Vector3(576,32,1);border=new NativeFrameBorder(quad,screenRoot.transform);
  }
  static GameObject Make(string name,Mesh mesh,Material paint,int order){var go=new GameObject(name);go.AddComponent<MeshFilter>().sharedMesh=mesh;var r=go.AddComponent<MeshRenderer>();r.sharedMaterial=paint;r.sortingOrder=order;return go;}
  public void SetCamera(double x,double y,double zoom)=>SetCamera(x,y,zoom,new NativeFrame(4f/3));
  public void SetCamera(double x,double y,double zoom,NativeFrame frame){screenRoot.transform.position=new Vector3((float)(x-frame.Width/2/zoom),(float)(-y+(frame.Height/2+frame.ViewOffsetY-32)/zoom),0);screenRoot.transform.localScale=new Vector3((float)(1/zoom),(float)(1/zoom),1);StatusBanner.Layout(frame);header.SetActive(!frame.OverlayHud);header.transform.localScale=new Vector3(frame.Width,32,1);border.Layout(frame,x,y,zoom);}
  public void SetQuality(string value){if(quality==value)return;quality=value;if(skullTexture)UnityEngine.Object.Destroy(skullTexture);if(font)UnityEngine.Object.Destroy(font);skullTexture=NativeLightField.Load("session-skull-"+value+".png");font=NativeLightField.Load("session-font-"+value+".png");font.filterMode=FilterMode.Point;skullPaint.mainTexture=skullTexture;foreach(var paint in extraSkullPaint)if(paint)paint.mainTexture=skullTexture;StatusBanner.SetFont(font);}
  public void Render(NativeGameplayWorld w,string quality,double? statusAlpha=null,bool paused=false){SetQuality(quality);float death=(float)(w.SessionEnabled?w.DeathAlpha:0);skull.SetActive(death>0);skullPaint.SetFloat("_Opacity",death);skull.transform.position=new Vector3(w.Player.Cell.x*16,-w.Player.Cell.y*16,-1);
   for(int i=0;i<2;i++){if(i+1>=w.PlayerCount){if(extraSkulls[i])extraSkulls[i].SetActive(false);continue;}if(!extraSkulls[i]){extraSkullPaint[i]=new Material(skullPaint);extraSkulls[i]=Make("Player "+(i+2)+" original death skull",quad,extraSkullPaint[i],10);extraSkulls[i].transform.localScale=new Vector3(16,16,1);}using(w.ForPlayer(w.GetPlayer(i+1))){float d=(float)(w.SessionEnabled?w.DeathAlpha:0);extraSkulls[i].SetActive(d>0);extraSkullPaint[i].SetFloat("_Opacity",d);extraSkulls[i].transform.position=new Vector3(w.Player.Cell.x*16,-w.Player.Cell.y*16,-1);}}
   bool show=w.SessionEnabled&&(paused||w.Transition||w.GameOver);float alpha=show?(paused?1:(float)(statusAlpha??w.StatusAlpha)):0;
   if(show&&!paused&&!w.GameOver&&captionLevel!=w.Level){captionLevel=w.Level;clearCaption="LEVEL "+w.Level+" CLEARED";}
   StatusBanner.Show(paused?"PAUSE":w.GameOver?"GAME OVER":show?clearCaption:StatusBanner.Caption,alpha,show&&(paused||w.GameOver||w.Time>=w.RevealAt));
  }
  public void Dispose(){StatusBanner.Dispose();border.Dispose();foreach(var go in extraSkulls)UnityEngine.Object.Destroy(go);foreach(var m in extraSkullPaint)UnityEngine.Object.Destroy(m);foreach(var go in new[]{skull,screenRoot})UnityEngine.Object.Destroy(go);foreach(var m in new[]{skullPaint,headerPaint})UnityEngine.Object.Destroy(m);UnityEngine.Object.Destroy(skullTexture);UnityEngine.Object.Destroy(font);}
 }
}

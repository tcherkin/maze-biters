using System;
namespace MazeBiters.NativeStudy {
 // Shared behavioural scale. Navigation competence and willingness to attack
 // are independent: a peaceful creature may still know how to escape.
 public struct NativeDifficultyProfile {
  public int Index;
  public double Skill,Attack,Revenge,EscapeSkill,MealChance,MealWindowMs,RoamWindowMs;
  public double OpponentHuntChance,OpponentHuntWindowMs,OpponentRestMs,Notice,DecisionMs,Error;
  public double MaxTimePressure,DepletionBoost;
  public double TimeProgress,Intensity;
  public bool? MaximumOverride;
  public bool Maximum=>MaximumOverride??(Intensity>=4);
 }
 public static class NativeDifficulty {
  static readonly double[] skill={.12,.32,.56,.80,.98}, growth={.08,.10,.12,.12,.02};
  static readonly double[] attack={.015,.10,.36,.68,.96},revenge={.075,.18,.30,.24,.04};
  static readonly double[] escape={.88,.90,.94,.98,1},meal={.12,.35,.68,.92,1};
  static readonly double[] mealWindow={2600,3800,6000,10000,20000},roamWindow={6500,4800,3000,1600,800};
  static readonly double[] hunt={.015,.08,.32,.72,1},huntWindow={1200,2000,3600,6000,12000},rest={10000,7500,4500,2000,0};
  static readonly double[] notice={5,8,12,21,1000},decision={2300,1700,1000,550,250},error={.22,.15,.08,.025,0};
  static readonly double[] pressure={1.15,1.35,1.65,2.05,2.6},depletion={.15,.30,.60,.90,1.25};
  public static int Index(double multiplier)=>Math.Max(0,Math.Min(4,(int)Math.Round((multiplier-.5)*4)));
  // Age is already in speed-scaled gameplay milliseconds. Loading and pause do
  // not advance it. Difficulty and level never shorten this common window.
  public static double Progress(double ageMs){
   if(ageMs<=60000)return 0;if(ageMs>=300000)return 1;
   return (Math.Exp(.5*(ageMs-60000)/240000)-1)/(Math.Exp(.5)-1);
  }
  static double Blend(double[] values,double intensity){int lo=(int)intensity,hi=Math.Min(4,lo+1);return values[lo]+(values[hi]-values[lo])*(intensity-lo);}
  public static NativeDifficultyProfile For(double multiplier,int level,double ageMs=0)=>ForIndex(Index(multiplier),level,ageMs);
  public static NativeDifficultyProfile ForIndex(int index,int level,double ageMs=0){
   int i=Math.Max(0,Math.Min(4,index));double time=Progress(ageMs),tier=i+(4-i)*time;
   return ForIntensity(tier,level,i,time);
  }
  public static NativeDifficultyProfile ForIntensity(double intensity,int level,int index=0,double timeProgress=0){
   int i=Math.Max(0,Math.Min(4,index));double tier=double.IsNaN(intensity)?i:Math.Max(0,Math.Min(4,intensity)),time=timeProgress;
   double progress=1-Math.Exp(-Math.Max(0,level-1)/40.0);
   // 1000 is the old unlimited-notice sentinel, not a distance to interpolate.
   double radius=tier>=4?1000:tier>=3?21+(48-21)*(tier-3):Blend(notice,tier);
   return new NativeDifficultyProfile{Index=i,TimeProgress=time,Intensity=tier,Skill=Math.Min(1,Blend(skill,tier)+Blend(growth,tier)*progress),
    Attack=Math.Min(1,Blend(attack,tier)*(1+.15*progress)),Revenge=Blend(revenge,tier),EscapeSkill=Math.Min(1,Blend(escape,tier)+.02*progress),
    MealChance=Math.Min(1,Blend(meal,tier)*(1+.15*progress)),MealWindowMs=Blend(mealWindow,tier),RoamWindowMs=Blend(roamWindow,tier),
    OpponentHuntChance=Math.Min(1,Blend(hunt,tier)*(1+.15*progress)),OpponentHuntWindowMs=Blend(huntWindow,tier),OpponentRestMs=Blend(rest,tier),
    Notice=radius+(tier>=4?0:2*progress),DecisionMs=Blend(decision,tier)*(1-.12*progress),Error=Blend(error,tier)*(1-.25*progress),
    MaxTimePressure=Blend(pressure,tier)+.1*progress,DepletionBoost=Blend(depletion,tier)};
  }
 }
}

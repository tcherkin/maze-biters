using System;
namespace MazeBiters.NativeStudy {
 // Shared behavioural scale. Navigation competence and willingness to attack
 // are independent: a peaceful creature may still know how to escape.
 public struct NativeDifficultyProfile {
  public int Index;
  public double Skill,Attack,Revenge,EscapeSkill,MealChance,MealWindowMs,RoamWindowMs;
  public double OpponentHuntChance,OpponentHuntWindowMs,OpponentRestMs,Notice,DecisionMs,Error;
  public double MaxTimePressure,DepletionBoost;
 }
 public static class NativeDifficulty {
  static readonly double[] skill={.12,.32,.56,.80,.98}, growth={.08,.10,.12,.12,.02};
  static readonly double[] attack={.015,.10,.36,.68,.96},revenge={.075,.18,.30,.24,.04};
  static readonly double[] escape={.88,.90,.94,.98,1},meal={.12,.35,.68,.92,1};
  static readonly double[] mealWindow={2600,3800,6000,10000,20000},roamWindow={6500,4800,3000,1600,800};
  static readonly double[] hunt={.015,.08,.32,.72,1},huntWindow={1200,2000,3600,6000,12000},rest={10000,7500,4500,2000,0};
  static readonly double[] notice={5,8,12,21,1000},decision={2300,1700,1000,550,250},error={.22,.15,.08,.025,0};
  static readonly double[] pressure={1.15,1.35,1.65,2.05,2.6},depletion={.15,.30,.60,.90,1.25};
  public static int Index(double multiplier)=>Math.Max(0,Math.Min(4,(int)Math.Round((multiplier-.5)*4)));
  public static NativeDifficultyProfile For(double multiplier,int level)=>ForIndex(Index(multiplier),level);
  public static NativeDifficultyProfile ForIndex(int index,int level){
   int i=Math.Max(0,Math.Min(4,index));
   double progress=1-Math.Exp(-Math.Max(0,level-1)/40.0);
   return new NativeDifficultyProfile{Index=i,Skill=Math.Min(1,skill[i]+growth[i]*progress),
    Attack=Math.Min(1,attack[i]*(1+.15*progress)),Revenge=revenge[i],EscapeSkill=Math.Min(1,escape[i]+.02*progress),
    MealChance=Math.Min(1,meal[i]*(1+.15*progress)),MealWindowMs=mealWindow[i],RoamWindowMs=roamWindow[i],
    OpponentHuntChance=Math.Min(1,hunt[i]*(1+.15*progress)),OpponentHuntWindowMs=huntWindow[i],OpponentRestMs=rest[i],
    Notice=notice[i]+(i==4?0:2*progress),DecisionMs=decision[i]*(1-.12*progress),Error=error[i]*(1-.25*progress),
    MaxTimePressure=pressure[i]+.1*progress,DepletionBoost=depletion[i]};
  }
 }
}

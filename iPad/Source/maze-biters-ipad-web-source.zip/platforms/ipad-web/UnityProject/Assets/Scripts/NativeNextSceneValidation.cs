using System;using System.Collections;using System.Collections.Generic;using System.IO;using UnityEngine;
namespace MazeBiters.NativeStudy {
 public sealed partial class NativeGameplayStudy {
  [Serializable] sealed class NextSceneValidationResult {public bool passed;public string quality;public string[] checks;}
  IEnumerator ValidateNextScene(){
   sessionSmoke=true;var checks=new List<string>();void Assert(bool ok,string label){if(!ok)throw new InvalidOperationException(label);checks.Add(label);}
   void Clear(){world.Snakes.Clear();foreach(var s in snakes.Values)s.Dispose();snakes.Clear();world.CheckLevelComplete();}
   IEnumerator Ready(int stage=99){for(int f=0;f<1200;f++){Render();if(nextScene!=null&&(stage==99?nextScene.ready:nextScene.stage>=stage))yield break;yield return null;}throw new TimeoutException("next scene readiness");}
   if(StagedNextScene){
    // Cancel every partially published image stage: no texture alias may
    // survive into a restarted world, and no unfinished image is exposed.
    for(int stage=1;stage<=4;stage++){
     Reset(12);yield return DrainProbePreparation();Clear();
     bool found=false;for(int f=0;f<1200;f++){Render();if(publishingMaze!=null&&publishingMaze.art.PublishStage==stage){found=true;break;}yield return null;}
     Assert(found&&nextMaze==null&&nextScene==null,"unpublished maze stage "+stage);
     Reset(12);yield return DrainProbePreparation();yield return null;
     Assert(publishingMaze==null&&nextMaze==null&&nextScene==null,"cancel partial maze stage "+stage);
    }
    Reset(12);yield return DrainProbePreparation();Clear();yield return Ready(3);Render();Render();
    Assert(nextScene.neon!=null&&nextScene.stage==3,"partially initialized neon scene");
    Reset(12);yield return DrainProbePreparation();Assert(nextScene==null&&publishingMaze==null,"cancel partial neon resources");
    Reset(12);yield return DrainProbePreparation();Clear();
    for(int f=0;publishingMaze==null&&f<1200;f++){Render();yield return null;}
    Assert(publishingMaze!=null&&nextMaze==null,"force commit during partial maze upload");
    time=world.Time=world.TransitionAt+NativeGameplayWorld.ClearDuration;world.AdvanceLevel();
    Assert(world.Level==2&&publishingMaze==null&&scenePreparationPending,"partial upload drains safely on deadline fallback");yield return DrainProbePreparation();
   }
   if(PhasedGpuSurfaces){
    Reset(12);yield return DrainProbePreparation();Clear();
    bool found=false;for(int f=0;f<1200;f++){Render();if(nextScene!=null&&nextScene.primedSnakes==1){found=true;break;}yield return null;}
    Assert(found&&nextScene.passes==0&&!nextScene.ready,"one actual snake surface primed before whole scene");
    var abandoned=nextScene;Reset(12);yield return DrainProbePreparation();
    Assert(nextScene==null&&abandoned.primeCommands==null,"cancel partial GPU surface preflight");
    Clear();yield return Ready();Assert(nextScene.primedSnakes==nextScene.preview.Snakes.Count&&nextScene.passes==2&&nextScene.primeCommands==null,"all surfaces and both complete scene passes before ready");
   }
   // Cancel during decompression, GPU construction and after full completion.
   // None of these resources may install into a restarted session.
   foreach(int stage in new[]{0,4,99}){
    Reset(12);yield return DrainProbePreparation();Clear();yield return Ready(stage);
    Reset(12);yield return DrainProbePreparation();yield return null;
    Assert(nextScene==null&&nextMaze==null&&publishingMaze==null&&nextMazeTask==null&&world.Level==1,"restart during stage "+stage);
   }
   Clear();yield return Ready();
   // Visible old scorpion and hunter exercise layer restoration, not just an
   // empty completed maze. Preparation must preserve every animation clock.
   world.PlaceScorpion(world.Brain.Nearest(new Vector2Int(18,3)),Vector2Int.right);scorpionArt=CreateScorpionArt();
   var h=new NativeHunter{Id=100,Cell=world.Brain.Nearest(new Vector2Int(13,3)),From=world.Brain.Nearest(new Vector2Int(13,3)),Dir=Vector2Int.left,Palette=1,LastMove=time};world.Hunters.Add(h);AddActor(h,false,1);
   preparationLightFrame=true;Render();string state=SceneClockState();WarmNextScene(nextScene);
   Assert(SceneClockState()==state,"preview preserves world, RNG, blink, glints and turn clocks");
   while(nextScene.gpuPending&&!nextScene.gpuDone)yield return null;
   string first=quality;quality=quality=="hd"?"4k":"hd";SetQuality();yield return DrainProbePreparation();yield return Ready();
   Assert(nextScene.quality==quality&&nextScene.ready,"quality change invalidates and rebuilds future GPU surfaces");
   quality=first;SetQuality();yield return DrainProbePreparation();yield return Ready();
   int hits=nextSceneHits;world.Player.Palette=2;time=world.Time=world.TransitionAt+NativeGameplayWorld.ClearDuration;world.AdvanceLevel();Render();
   Assert(world.Level==2&&nextSceneHits==hits+1&&actors[1].art.Palette=="ai"&&!scenePreparationPending,"ready adoption and late player palette change");
   // Forced early commit before the asynchronous cache is ready uses the old
   // gate, not a partially initialized scene or stale cached model.
   Reset(12);yield return DrainProbePreparation();Clear();PollNextMaze();
   time=world.Time=world.TransitionAt+NativeGameplayWorld.ClearDuration;world.AdvanceLevel();
   Assert(world.Level==2&&scenePreparationPending,"cold fallback retains GPU safety gate");yield return DrainProbePreparation();Render();
   Reset(12);yield return DrainProbePreparation();Assert(nextScene==null&&nextMaze==null,"final cache released");
   File.WriteAllText(report,JsonUtility.ToJson(new NextSceneValidationResult{passed=true,quality=quality,checks=checks.ToArray()},true));Application.Quit();
  }
 }
}

using System;using System.IO;using System.Threading.Tasks;using UnityEngine;
namespace MazeBiters.NativeStudy {
 public sealed partial class NativeGameplayStudy {
  sealed class PreparedMaze {public SessionLevel level;public NativeMazeArtwork art;public double workerMs;}
  static readonly bool StagedNextScene=Array.IndexOf(Environment.GetCommandLineArgs(),"--legacy-scene-optimizations")<0&&Array.IndexOf(Environment.GetCommandLineArgs(),"--legacy-next-scene-preparation")<0;
  static readonly bool EarlyMazePreparation=Array.IndexOf(Environment.GetCommandLineArgs(),"--late-maze-preparation")<0;
  Task<PreparedMaze> nextMazeTask;PreparedMaze nextMaze,publishingMaze;bool nextMazeQueued,nextMazeFailed;int nextMazeNumber;
  System.Threading.CancellationTokenSource nextMazeCancellation;
  int nextMazeHits,nextMazeWaits,nextMazeDiscarded;double nextMazeWorkerMs,nextMazePublishMs;
  void QueueNextMaze(){if(!catalogueControl&&!NativeMazeArtwork.LegacyPreparation&&!logicPreparationInstance&&!(nextMazeFailed&&nextMazeNumber==world?.Level+1)&&nextMazeTask==null&&nextMaze==null&&publishingMaze==null)nextMazeQueued=true;}
  void PollNextMaze(){
   // Prepare only deterministic maze/material data during play. The future
   // actors, audio, GPU uploads and RNG-sensitive preview still wait for CLEAR.
   // No main-thread texture creation or renderer changes occur during play.
   bool playing=EarlyMazePreparation&&world!=null&&world.SessionEnabled&&scenario==12&&!menuPreparing&&!preparingScene&&!world.Transition&&!world.GameOver&&!world.GameOverPending&&!world.CatalogueFinished;
   if(playing)QueueNextMaze();
   if(nextMazeQueued&&world!=null&&(playing||world.Transition&&world.Time>=world.RevealAt)){
    nextMazeQueued=false;uint seed=mazeSeed;double difficulty=world.Difficulty;int n=world.Level+1;
    nextMazeNumber=n;
    string source=Path.Combine(WebFiles.Root,"Reference/maze-brushes"),artQuality=GlassQuality;
    // Only immutable inputs cross the boundary. No live world, gameplay RNG,
    // Unity objects, animation clocks or event handlers run on this worker.
    nextMazeTask=NativeMazeWorker.Run(()=>{var timer=System.Diagnostics.Stopwatch.StartNew();var level=new NativeMazeGenerator(seed,difficulty).Generate(n);var art=new NativeMazeArtwork(level,n,true,true,source,glassQuality:artQuality);return new PreparedMaze{level=level,art=art,workerMs=timer.Elapsed.TotalMilliseconds};},out nextMazeCancellation);
   }
   if(world!=null&&(world.Transition&&world.Time>=world.RevealAt||restartPreparing))FinishNextMaze(false);
  }
  void FinishNextMaze(bool wait){
   if(publishingMaze==null&&(nextMazeTask==null||!wait&&!nextMazeTask.IsCompleted))return;
   try{
    if(publishingMaze==null){var pending=nextMazeTask;nextMazeTask=null;if(!pending.IsCompleted)nextMazeWaits++;try{publishingMaze=pending.GetAwaiter().GetResult();}finally{nextMazeCancellation?.Dispose();nextMazeCancellation=null;}nextMazePublishMs=0;}
    var timer=System.Diagnostics.Stopwatch.StartNew();bool ready;
    if(StagedNextScene&&(world.Transition&&!restartPreparing||NativeBalancedLaunch.Distributed&&restartPreparing)){do{ready=publishingMaze.art.PublishStep();}while(!ready&&(wait||NativeBalancedLaunch.Distributed&&restartPreparing&&timer.Elapsed.TotalMilliseconds<2));}
    else{publishingMaze.art.Publish();ready=true;}
    nextMazePublishMs+=timer.Elapsed.TotalMilliseconds;
    if(ready){nextMaze=publishingMaze;publishingMaze=null;nextMazeWorkerMs=nextMaze.workerMs;}
   }catch(Exception e){publishingMaze?.art.Discard();publishingMaze=null;nextMaze?.art.Discard();nextMaze=null;nextMazeFailed=true;Debug.LogWarning("Next maze preparation fell back to the normal loading gate: "+e.Message);}
  }
  NativeMazeArtwork TakePreparedMaze(){
   if(nextMaze==null||!ReferenceEquals(nextMaze.level,currentGeneratedLevel))return null;
   var art=nextMaze.art;nextMaze=null;nextMazeNumber=0;nextMazeHits++;return art;
  }
  void CancelNextMaze(){
   CancelNextScene();restartPreparing=false;nextMazeQueued=false;nextMazeNumber=0;nextMazeFailed=false;
   if(publishingMaze!=null){publishingMaze.art.Discard();publishingMaze=null;nextMazeDiscarded++;}
   if(nextMaze!=null){nextMaze.art.Discard();nextMaze=null;nextMazeDiscarded++;}
   if(nextMazeTask!=null){
    var pending=nextMazeTask;nextMazeTask=null;nextMazeDiscarded++;var cancellation=nextMazeCancellation;nextMazeCancellation=null;cancellation?.Cancel();
    // Restart/difficulty changes do not block on old work. Its CPU-only result
    // is disposed on completion and can never enter the new session.
    WebWorkQueue.Continue(pending,t=>{try{if(t.Status==TaskStatus.RanToCompletion)t.Result.art.DisposeStaging();else if(t.IsFaulted){var observed=t.Exception;}}finally{cancellation?.Dispose();}});
   }
  }
 }
}

using System;using System.Collections.Generic;using UnityEngine;
namespace MazeBiters.NativeStudy {
 // Original menu clock and spatial focus graph, independent of simulation time.
 public sealed class NativeMenuState {
  public static readonly string[] Keys={"mode:1","mode:5","mode:2","mode:3","mode:4","mode:0","highScores","howToPlay","difficulty","speed","quality","music"};
  public static readonly int[] Modes={1,5,2,3,4,0};
  public static readonly double[] Speeds={.6,.8,1,1.25,1.6},MusicGains={0,.25,.55,1};
  // up, down, left, right
  static readonly int[,] Graph={{-1,1,-1,3},{0,2,-1,4},{1,6,-1,5},{-1,4,0,-1},{3,5,1,-1},{4,7,2,-1},{2,8,-1,7},{5,10,6,-1},{6,-1,-1,9},{6,-1,8,10},{7,-1,9,11},{7,-1,10,-1}};
  public int SelectedMode=>LastMode>=0&&LastMode<=5?LastMode:1;
  public int Focus,LastMode=1,Difficulty=2,Speed=2,Music=3;public string Quality="hd";
  public int OldFocus=-1;public double FocusAlpha,OldAlpha,FocusStart,OldStart,Changed,Observed;
  public string Active,Pulsing;public double ActiveAt=-1e6,PulseAt=-1e6,PendingAt=-1e6,ComingUntil=-1e6;
  public bool Pending;public readonly List<double> Shots=new List<double>(32);
  public bool WaitForPreparation;public double PendingFinishAt=double.PositiveInfinity;
  public double Rate=>Speeds[Speed];public double ScoreFactor=>Rate*NativeMazeGenerator.Difficulties[Difficulty];
  public double MusicGain=>MusicGains[Music];
  public static double Smooth(double t){t=Math.Max(0,Math.Min(1,t));return t*t*(3-2*t);}
  public void Advance(double t){
   if(t<Observed||t-Observed>1000){FocusAlpha=FocusStart=1;OldAlpha=OldStart=0;OldFocus=-1;Changed=t;}
   else {double u=Smooth((t-Changed)/200);FocusAlpha=FocusStart+(1-FocusStart)*u;OldAlpha=OldStart*(1-u);if(u>=1)OldFocus=-1;}
   Observed=t;Shots.RemoveAll(at=>t-at>=620);if(Focus<6)LastMode=Modes[Focus];
  }
  public bool SetFocus(int next,double t){if(next<0||next>=12||Pending)return false;Advance(t);if(next==Focus)return false;
   if(next==OldFocus){int previous=Focus;FocusStart=OldAlpha;OldStart=FocusAlpha;OldFocus=previous;}
   else {if(OldAlpha<=FocusAlpha){OldFocus=Focus;OldStart=FocusAlpha;}else OldStart=OldAlpha;FocusStart=0;}
   Focus=next;FocusAlpha=FocusStart;OldAlpha=OldStart;Changed=Observed=t;if(next<6)LastMode=Modes[next];return true;
  }
  public bool Move(int direction,double t)=>SetFocus(Graph[Focus,direction],t);
  // Returns the original SFX cue, never a made-up confirmation sound.
  public string Activate(double t){if(Pending)return null;string key=Keys[Focus];Active=Pulsing=null;
   if(Focus>=8&&Focus!=10){Pulsing=key;PulseAt=t;
    if(Focus==8)Difficulty=(Difficulty+1)%5;if(Focus==9)Speed=(Speed+1)%5;if(Focus==11)Music=(Music+1)%4;
    if(Focus!=11){Shots.Add(t);if(Shots.Count>32)Shots.RemoveAt(0);}return "Tick";
   }
   Active=key;ActiveAt=t;if(Focus==10)Quality=Quality=="hd"?"4k":"hd";
   else if(Focus>=0&&Focus<6){LastMode=Modes[Focus];Pending=true;PendingAt=t;PendingFinishAt=double.PositiveInfinity;}else ComingUntil=t+2400;
   return "SnakeSELECT&Appear@";
  }
  public void CancelStart(){Pending=false;PendingFinishAt=double.PositiveInfinity;Active=null;}
  public void SignalPrepared(double t,bool ready){if(!Pending||!WaitForPreparation)return;if(!ready){PendingFinishAt=double.PositiveInfinity;return;}if(double.IsPositiveInfinity(PendingFinishAt))PendingFinishAt=PendingAt+Math.Max(900,Math.Ceiling(Math.Max(0,t-PendingAt)/300)*300);}
  public double Alpha(string key,double t){double elapsed=t-PulseAt;if(key==Pulsing&&elapsed>=0&&elapsed<420)return .45+.55*(.5+.5*Math.Cos(Math.PI*2*elapsed/420));elapsed=t-PendingAt;if(Pending&&key=="mode:"+SelectedMode&&elapsed>=0&&(WaitForPreparation?t<PendingFinishAt:elapsed<900))return .15+.85*(.5+.5*Math.Cos(Math.PI*2*(elapsed%300)/300));return 1;}
  public bool StartReady(double t)=>Pending&&(WaitForPreparation?t>=PendingFinishAt:t-PendingAt>=900);
 }
 [Serializable] public sealed class MenuLayer {public string id,file;public float x,y,w,h;public int width,height;}
 [Serializable] public sealed class MenuArea {public string id;public float x,y,w,h;}
 [Serializable] public sealed class MenuCase {public string name,image,focus,previous,active,pulse;public double time,change,at,pulseAlpha,focusAlpha;public int difficulty=2,speed=2,music=3,mode=1;public bool pending;public double[] shots;}
 [Serializable] public sealed class MenuManifest {public int width,height;public string quality;public float scale,highLeft,highRight;public MenuLayer[] entries;public MenuArea[] areas;public MenuCase[] cases;}
}

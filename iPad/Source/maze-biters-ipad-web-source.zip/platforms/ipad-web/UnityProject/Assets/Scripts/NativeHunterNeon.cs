using System;
using UnityEngine;
using UnityEngine.Rendering;
namespace MazeBiters.NativeStudy {
 // Final-pose processing, never touches approved mouth/blink/turn sources.
 // Fixed-size targets are reused; no runtime CPU texture readback/upload.
 public sealed class NativeHunterNeon:IDisposable {
  readonly Mesh quad;readonly Material processing,blur;public readonly Material Display,Emission,Eye;
  public readonly RenderTexture Lit,Glow,Mask;readonly RenderTexture soft,temporary;
  NativeTurnActor cachedActor,eyeActor;long cachedRevision=-1,eyeRevision=-1;NativeAggressionGlint clock;public Matrix4x4 Transform;public Vector2 Center;public int Palette;public double EyeLevel{get;private set;}bool culled;
  internal Action PreserveClock(){var saved=clock;double level=EyeLevel;clock=clock.Copy();return ()=>{clock=saved;EyeLevel=level;};}
  public bool ReadyForCulling=>cachedActor!=null&&Lit.IsCreated()&&Glow.IsCreated();
  public long TargetBytes=>5L*Lit.width*Lit.height*4;
  public NativeHunterNeon(Mesh quad,int size,int serial){
   this.quad=quad;clock=new NativeAggressionGlint(unchecked((uint)serial*0x9e3779b9u)^0x4b1d7301u);
   RenderTexture Make(){var rt=new RenderTexture(size,size,0,RenderTextureFormat.ARGB32){filterMode=FilterMode.Bilinear,wrapMode=TextureWrapMode.Clamp};rt.Create();return rt;}
   Lit=Make();Glow=Make();Mask=Make();soft=Make();temporary=Make();processing=new Material(Shader.Find("MazeBiters/CreatureNeon"));blur=new Material(Shader.Find("MazeBiters/NeonBlur"));
   Display=new Material(Shader.Find("MazeBiters/PremultipliedImage")){mainTexture=Lit};Emission=new Material(Display){mainTexture=Glow};
   Eye=new Material(Shader.Find("MazeBiters/HunterEye")){mainTexture=Mask};Eye.SetTexture("_Soft",soft);
  }
  public void Render(NativeTurnBank bank,NativeTurnActor actor,TurnPose pose,int mouth,int blink,double time,double aggression,Matrix4x4 transform,int palette,bool forceMask=false,bool skipVisual=false){
   culled=skipVisual;
   Transform=transform;var c=transform.MultiplyPoint3x4(new Vector3(.5f,-.5f,0));Center=new Vector2(c.x,-c.y);Palette=palette;
   if(culled){clock.SetAggression(aggression,time);EyeLevel=clock.Sample(time);return;}
   // Point sampling at the native pixel centres, as in creature-neon-material.js.
   NativePoseCache.NeonCalls++;bool reuse=NativePoseCache.Enabled&&cachedActor==actor&&cachedRevision==actor.OutputRevision&&Lit.IsCreated()&&Glow.IsCreated();if(reuse)NativePoseCache.NeonHits++;else {var old=actor.Output.filterMode;actor.Output.filterMode=FilterMode.Point;
   processing.SetFloat("_Emission",0);Graphics.Blit(actor.Output,Lit,processing);processing.SetFloat("_Emission",1);Graphics.Blit(actor.Output,Glow,processing);actor.Output.filterMode=old;cachedActor=actor;cachedRevision=actor.OutputRevision;}
   clock.SetAggression(aggression,time);EyeLevel=clock.Sample(time);
   if(EyeLevel>0||forceMask){NativePoseCache.EyeCalls++;bool same=NativePoseCache.Enabled&&!forceMask&&eyeActor==actor&&eyeRevision==actor.OutputRevision&&Mask.IsCreated()&&soft.IsCreated();if(same){NativePoseCache.EyeHits++;return;}eyeActor=actor;eyeRevision=actor.OutputRevision;
    bank.RenderHunterEyes(actor,pose,mouth,blink,Mask);
    // Same .09-cell shadow blur as the original eye layer, expressed in
    // native pixels. This does not modify the sharp authored iris mask.
    double variance=0;for(int i=0;i<6;i++)variance+=Math.Pow(.5,i*2);
    float step=(float)(.72/16/Math.Sqrt(variance));Graphics.Blit(Mask,soft);
    for(int axis=0;axis<2;axis++)for(int pass=0;pass<6;pass++){float s=step*(float)Math.Pow(.5,pass);blur.SetVector("_Step",axis==0?new Vector4(s,0,0,0):new Vector4(0,s,0,0));Graphics.Blit(pass%2==0?soft:temporary,pass%2==0?temporary:soft,blur);}
   }
  }
  public void Submit(CommandBuffer c,bool emission=false){if(!culled)c.DrawMesh(quad,Transform,emission?Emission:Display);}
  public void SubmitEyes(CommandBuffer c){if(culled||EyeLevel<=0)return;Eye.SetFloat("_Amount",(float)EyeLevel);c.DrawMesh(quad,Transform,Eye);}
  public void Light(NativeLightField field){
   // Production hunter geometry.length=.5 cell, with a constant sample point.
   // Preserve separate source-over stamps rather than collapsing their alpha.
   const double spacing=16.0*2/9,length=8;int count=(int)Math.Floor(length/spacing);double remainder=length-count*spacing;
   for(int i=0;i<=count;i++)field.Point(Center.x,Center.y,6+Palette,i==0?.5:i==count?.5+remainder/spacing*.5:1);
   if(remainder>0)field.Point(Center.x,Center.y,6+Palette,remainder/spacing*.5);
  }
  public void Dispose(){foreach(var rt in new[]{Lit,Glow,Mask,soft,temporary})if(rt){if(RenderTexture.active==rt)RenderTexture.active=null;rt.Release();UnityEngine.Object.Destroy(rt);}foreach(var m in new[]{processing,blur,Display,Emission,Eye})UnityEngine.Object.Destroy(m);}
 }
}

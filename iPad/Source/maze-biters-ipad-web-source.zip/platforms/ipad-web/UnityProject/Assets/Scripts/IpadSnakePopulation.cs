using System;
using System.Collections.Generic;
using System.Linq;
using UnityEngine;

namespace MazeBiters.NativeStudy {
 public sealed partial class NativeGameplayWorld {
  public int RequestedStartingSnakes {get;private set;}
  public int StartingSnakeCapacity {get;private set;}
  public int StartingSnakeCount {get;private set;}
  public int SpawnableFloorCells {get;private set;}
  public int ExtraSpawnSearchNodes {get;private set;}
  public static int DesiredStartingSnakes(int level)=>level<3?4:5+(level-3)/2;

  void SpawnSafeLevelSnakes(){
   // Keep the established opening population and its safe geometry unchanged.
   // Later levels add whole snakes only where both a body and runway fit.
   SpawnBaselineLevelSnakes();
   RequestedStartingSnakes=DesiredStartingSnakes(Level);
   StartingSnakeCapacity=StartingSnakeCount=Snakes.Count;
   SpawnableFloorCells=ExtraSpawnSearchNodes=0;
   if(RequestedStartingSnakes<=Snakes.Count)return;
   var safety=new NativeSpawnSafety(this);var floor=new List<Vector2Int>();
   for(int y=0;y<Height;y++)for(int x=0;x<Width;x++){var c=new Vector2Int(x,y);if(Floor(c)&&!safety.Reserved(c))floor.Add(c);}
   SpawnableFloorCells=floor.Count;
   var occupied=new HashSet<Vector2Int>(Snakes.SelectMany(s=>s.Body));
   var runway=new HashSet<Vector2Int>(Snakes.Select(s=>s.Head+s.Dir));
   // At least half of the usable, non-reserved floor stays empty. Reserve
   // eight cells per added snake (seven body cells and one clear first step).
   // This is a geometric limit, independent of frame rate or device speed.
   int extraBudget=Math.Max(0,(floor.Count/2-occupied.Count-runway.Count)/8);
   StartingSnakeCapacity=Snakes.Count+extraBudget;
   int target=Math.Min(RequestedStartingSnakes,StartingSnakeCapacity);
   while(Snakes.Count<target){
    uint salt=(uint)(Random()*uint.MaxValue);int nodes=0;
    var directions=Dirs.OrderBy(d=>SpawnRank(d,salt)).ToArray();
    List<Vector2Int> selected=null;
    bool Free(Vector2Int c)=>Floor(c)&&!safety.Reserved(c)&&!occupied.Contains(c)&&!runway.Contains(c);
    foreach(var head in floor.OrderBy(c=>SpawnRank(c,salt))){
     if(!Free(head))continue;
     foreach(var dir in directions){
      var step=head+dir;var neck=head-dir;
      if(!Free(step)||!Free(neck)||safety.FacingRisk(head,dir))continue;
      var path=new List<Vector2Int>{head,neck};var own=new HashSet<Vector2Int>(path);int local=0;
      bool Grow(Vector2Int previous){
       if(path.Count==7)return true;
       if(++local>120||++nodes>8000||++ExtraSpawnSearchNodes>40000)return false;
       var tail=path[path.Count-1];
       for(int turn=0;turn<5;turn++){
        var d=turn==0?previous:directions[turn-1];if(turn>0&&d==previous)continue;
        var c=tail+d;if(c==step||!Free(c)||!own.Add(c))continue;
        path.Add(c);if(Grow(d))return true;path.RemoveAt(path.Count-1);own.Remove(c);
       }
       return false;
      }
      if(Grow(-dir)){selected=path;break;}
      if(nodes>8000||ExtraSpawnSearchNodes>40000)break;
     }
     if(selected!=null||nodes>8000||ExtraSpawnSearchNodes>40000)break;
    }
    // Fragmented free space is not permission to shorten bodies, overlap
    // actors or weaken the player's protected route. Retain the safe layout.
    if(selected==null)break;
    var heading=selected[0]-selected[1];
    Snakes.Add(new NativeGameplaySnake{Id=nextId++,Body=selected,Cell=selected[0],Dir=heading,Pending=heading,Temperament=.2+Random()*.6,TurnBias=Random()});
    foreach(var c in selected)occupied.Add(c);runway.Add(selected[0]+heading);
   }
   if(Snakes.Count>9){var colors=SpawnColors(Snakes.Count);for(int i=0;i<Snakes.Count;i++)Snakes[i].Palette=colors[i];}
   StartingSnakeCount=Snakes.Count;StartingSnakeMass=Math.Max(1,Snakes.Sum(s=>s.Body.Count));
  }
 }
}

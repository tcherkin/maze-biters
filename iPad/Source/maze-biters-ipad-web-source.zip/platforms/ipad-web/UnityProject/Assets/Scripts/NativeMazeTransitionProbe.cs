using System;using System.Collections;using System.Collections.Generic;using System.Diagnostics;using System.IO;using System.Linq;using UnityEngine;
namespace MazeBiters.NativeStudy {
 public sealed partial class NativeGameplayStudy {
  [Serializable] sealed class MazeTransitionCheck {public int from,to,hits,waits,sceneHits,sceneFallbacks,packedUploads;public bool readyBeforeSwitch,sceneReady,passed;public double workerMs,publishMs,switchAndGpuGateMs,logicalClearMs,sceneReadyMs,largestPreparationStepMs;public long peakUnityUsed,peakSnakeSources,musicAssetBytes;public int musicCached,musicUnloads;public double musicStopMs,musicRetireMs,musicSourceMs,musicPlayMs,musicStartedAt;public string state,musicTrack;}
  [Serializable] sealed class MazeTransitionReport {public string quality,mode,note;public bool passed,cancelPassed;public MazeTransitionCheck[] transitions;public ConsistencyFrame[] frames;public ConsistencyMemory[] memory;}
  IEnumerator ProbeMazeTransitions(){
   bool capture=Array.IndexOf(Environment.GetCommandLineArgs(),"--capture-next-scene")>=0;bool focused=Array.IndexOf(Environment.GetCommandLineArgs(),"--require-focus")>=0;sessionSmoke=true;bool repeat=Array.IndexOf(Environment.GetCommandLineArgs(),"--repeat-music-transitions")>=0&&!capture;consistencyFrames.Capacity=repeat?4500:1800;var checks=new List<MazeTransitionCheck>();
   foreach(int n in (repeat?Enumerable.Range(0,3).SelectMany(_=>new[]{1,10,100}):new[]{1,10,100})){
    Reset(12);if(n!=1){world.Level=n-1;world.AdvanceLevel();}yield return DrainProbePreparation();world.Event=TraceWorldEvent;sessionAudio.Muted=true;
    world.Snakes.Clear();foreach(var s in snakes.Values)s.Dispose();snakes.Clear();world.Hunters.Clear();world.Scorpion=null;world.CheckLevelComplete();
    int hits=nextMazeHits,waits=nextMazeWaits,sceneHits=nextSceneHits,fallbacks=nextSceneFallbacks,uploads=NativeSnakeTextures.PackedUploads;nextSceneLargestStep=0;nextSceneReadyAt=0;double at=time;var check=new MazeTransitionCheck{from=n};long previous=0;
    for(int f=0;f<500;f++){
     while(focused&&!Application.isFocused){previous=0;yield return null;}
     bool ready=nextMaze!=null,sceneReady=nextScene?.ready==true;int oldLevel=world.Level;long now=Stopwatch.GetTimestamp();var timer=Stopwatch.StartNew();MeasureStallFrame("level-cleared-"+n,"normal",f,previous);previous=now;
     if(world.Level!=oldLevel){check.readyBeforeSwitch=ready;check.sceneReady=sceneReady;check.logicalClearMs=time-at;check.musicStopMs=sessionAudio.LastMusicStopMs;check.musicRetireMs=sessionAudio.LastMusicRetireMs;check.musicSourceMs=sessionAudio.LastMusicSourceMs;check.musicPlayMs=sessionAudio.LastMusicPlayMs;check.musicStartedAt=sessionAudio.MusicStartedAt;check.musicTrack=sessionAudio.Track;yield return DrainProbePreparation();timer.Stop();check.switchAndGpuGateMs=timer.Elapsed.TotalMilliseconds;previous=0;preparationFrames=0;discardPreparationDelta=false;}
     check.peakUnityUsed=Math.Max(check.peakUnityUsed,UnityEngine.Profiling.Profiler.GetTotalAllocatedMemoryLong());check.peakSnakeSources=Math.Max(check.peakSnakeSources,NativeSnakeTextures.ResidentBytes);if(capture&&(f==200||f==418||f==419||f==440)){dusk.Render(world.Player.Visual(time),world.Player.Dir,0,false,true);preparationLightFrame=true;Render();Capture(Path.ChangeExtension(report,null)+"-level-"+n+"-frame-"+f+".png");previous=0;}yield return null;
    }
    check.musicCached=sessionAudio.CachedMusicCount;check.musicAssetBytes=sessionAudio.CachedMusicBytes;check.musicUnloads=sessionAudio.MusicUnloads;check.sceneHits=nextSceneHits-sceneHits;check.sceneFallbacks=nextSceneFallbacks-fallbacks;check.packedUploads=NativeSnakeTextures.PackedUploads-uploads;check.sceneReadyMs=nextSceneReadyAt;check.largestPreparationStepMs=nextSceneLargestStep;check.to=world.Level;check.hits=nextMazeHits-hits;check.waits=nextMazeWaits-waits;check.workerMs=nextMazeWorkerMs;check.publishMs=nextMazePublishMs;check.state=GenerationState();
    check.passed=check.to==n+1&&check.logicalClearMs>=NativeGameplayWorld.ClearDuration&&check.logicalClearMs<NativeGameplayWorld.ClearDuration+1000.0/120+1e-6&&(NativeMazeArtwork.LegacyPreparation||check.readyBeforeSwitch&&check.hits==1&&check.waits==0);check.passed&=NoNextScene||NativeMazeArtwork.LegacyPreparation||check.sceneReady&&check.sceneHits==1&&check.sceneFallbacks==0;checks.Add(check);
    Reset(12);yield return DrainProbePreparation();SampleConsistencyMemory();
   }
   bool cancelPassed=true;
   if(!NativeMazeArtwork.LegacyPreparation){
    world.Snakes.Clear();world.CheckLevelComplete();PollNextMaze();var abandoned=nextMazeTask;Reset(12);yield return DrainProbePreparation();
    while(abandoned!=null&&!abandoned.IsCompleted)yield return null;
    yield return null;yield return null;cancelPassed=nextMaze==null&&nextMazeTask==null&&world.Level==1;
   }
   NativeStallTrace.Enabled=false;var result=new MazeTransitionReport{quality=quality,mode=NoNextScene||NativeMazeArtwork.LegacyPreparation||NativeSessionAudio.LegacyMusicRetirement?"before":"after",passed=cancelPassed&&checks.All(c=>c.passed),cancelPassed=cancelPassed,transitions=checks.ToArray(),frames=consistencyFrames.ToArray(),memory=consistencyMemory.ToArray(),note="Real CheckLevelComplete -> 3488ms original pulse/music schedule -> AdvanceLevel. Only removal of remaining snakes is staged. Next maze worker never advances simulation or gameplay RNG. 500 frames per transition, levels 1->2,10->11,100->101; --repeat-music-transitions repeats the sequence three times; switchAndGpuGateMs includes setup plus the two-frame GPU gate only if not already prepared; prepared scenes skip that gate. Full real clear-message frames include all staged uploads and GPU warming. Clear-message frames include asynchronous CPU work and main-thread texture publishing. Final state is compared before/after. Restart discards a pending worker without applying it."};Directory.CreateDirectory(Path.GetDirectoryName(report));File.WriteAllText(report,JsonUtility.ToJson(result,true));Application.Quit(result.passed?0:2);
  }
 }
}

using System;using System.Collections;using System.Collections.Generic;using System.IO;using System.Linq;using UnityEngine;using UnityEngine.Profiling;
namespace MazeBiters.NativeStudy {
 public sealed partial class NativeGameplayStudy {
  [Serializable] sealed class MusicSample {public int round,count;public string name,loadType,instance;public long assetBytes,unityUsed,workingSet,privateBytes;public double startedAt,stopMs,retireMs,sourceMs,playMs;public int samples,channels,frequency;}
  [Serializable] sealed class MusicValidationResult {public bool passed;public string quality,mode,note;public string[] checks;public MusicSample[] samples;public int liveMusicAfterOwnerDestroyed;public long initialUnityUsed;}
  IEnumerator ValidateMusicResources(){
   sessionSmoke=true;Reset(12);yield return DrainProbePreparation();sessionAudio.Muted=true;
   var checks=new List<string>();var samples=new List<MusicSample>();var ids=new Dictionary<string,string>();long initial=Profiler.GetTotalAllocatedMemoryLong();
   void Assert(bool ok,string label){if(!ok)throw new InvalidOperationException(label);checks.Add(label);}
   IEnumerator Ready(){for(int i=0;i<1200;i++){if(sessionAudio.PreparedTrackReady)yield break;yield return null;}throw new TimeoutException("music preparation");}
   int Live()=>Resources.FindObjectsOfTypeAll<AudioClip>().Count(c=>NativeMusicResources.IsTrack(c.name));
   var names=new List<string>();foreach(string style in new[]{"stillness","orbit"})for(int i=1;i<=9;i++)names.Add("neon-"+style+"-level-"+i);
   string state=GenerationState();uint rng=random;int changes=sessionAudio.MusicChanges;
   string cancelled=names.First(n=>n!=sessionAudio.Track);string playing=sessionAudio.Track;
   sessionAudio.PrepareTrack(cancelled);if(NativeSessionAudio.LegacyMusicRetirement)yield return Ready();sessionAudio.CancelPreparedTrack();Assert(!sessionAudio.PreparedTrackReady&&sessionAudio.Track==playing,"cancel detaches future track without touching current playback");
   sessionAudio.PrepareTrack(cancelled);yield return Ready();sessionAudio.CancelPreparedTrack();
   Assert(sessionAudio.MusicChanges==changes&&random==rng&&GenerationState()==state,"asynchronous preparation does not play music or change gameplay/RNG");
   for(int round=0;round<3;round++)foreach(string name in names){
    int countBefore=sessionAudio.CachedMusicCount;sessionAudio.PrepareTrack(name);yield return Ready();
    Assert(sessionAudio.MusicChanges==changes,"prepare is silent "+round+" "+name);
    double at=10000+samples.Count*1000;bool same=sessionAudio.Track==name;
    NativeStallTrace.Begin();sessionAudio.SetTrack(name,at);NativeStallTrace.End();if(!same)changes++;
    var source=sessionAudio.MusicSource;var clip=source.clip;
    Assert(clip&&clip.name==name&&clip.loadType==AudioClipLoadType.Streaming&&source.loop&&source.spatialBlend==0&&source.bypassEffects,"original streaming playback settings "+round+" "+name);
    Assert(sessionAudio.MusicChanges==changes&&(same||sessionAudio.MusicStartedAt==at&&source.volume==0&&source.timeSamples<4096),"unchanged start clock and zero-volume start "+round+" "+name);
    // Readback of the original volume envelope. Restore mute before yielding;
    // this is a numeric validation, not a listening assessment.
    foreach(double dt in new double[]{0,40,80,160,400}){
     world.RealTime=sessionAudio.MusicStartedAt+dt;sessionAudio.Muted=false;sessionAudio.Sync(world,false);
     float expected=(float)(.72*.34*world.MusicGain*NativeGameplayWorld.Smooth(dt/160));
     Assert(Math.Abs(source.volume-expected)<1e-6,"original fade "+round+" "+name+" "+dt);
    }
    sessionAudio.Muted=true;sessionAudio.Sync(world,false);Assert(source.volume==0,"mute preserved "+round+" "+name);
    if(!NativeSessionAudio.LegacyMusicRetirement){
     if(round==0)ids[name]=clip.GetEntityId().ToString();else Assert(ids[name]==clip.GetEntityId().ToString()&&sessionAudio.CachedMusicCount==18,"same retained clip on reuse "+round+" "+name);
     Assert(sessionAudio.CachedMusicCount<=18&&sessionAudio.MusicUnloads==0,"bounded library and no in-play unload "+round+" "+name);
    }
    NativeMemory.TryRead(out long working,out _,out long committed);samples.Add(new MusicSample{round=round,name=name,instance=clip.GetEntityId().ToString(),loadType=clip.loadType.ToString(),count=sessionAudio.CachedMusicCount,assetBytes=sessionAudio.CachedMusicBytes,unityUsed=Profiler.GetTotalAllocatedMemoryLong(),workingSet=working,privateBytes=committed,startedAt=sessionAudio.MusicStartedAt,stopMs=sessionAudio.LastMusicStopMs,retireMs=sessionAudio.LastMusicRetireMs,sourceMs=sessionAudio.LastMusicSourceMs,playMs=sessionAudio.LastMusicPlayMs,samples=clip.samples,channels=clip.channels,frequency=clip.frequency});
    for(int f=0;f<12;f++)yield return null;
   }
   int retained=sessionAudio.CachedMusicCount;sessionAudio.ResetBus();Assert(sessionAudio.Track==null&&sessionAudio.MusicSource.clip==null&&sessionAudio.Voices==0,"restart stops old playback and voices");
   Assert(NativeSessionAudio.LegacyMusicRetirement||retained==18&&sessionAudio.CachedMusicCount==18,"restart reuses the fixed catalogue without unload");
   sessionAudio.SetTrack(names[0],90000);Assert(sessionAudio.MusicStartedAt==90000&&sessionAudio.MusicSource.volume==0,"restart begins original track at its new clock");
   Assert(random==rng&&GenerationState()==state,"library cycling does not advance authoritative gameplay/RNG");
   if(!NativeSessionAudio.LegacyMusicRetirement){
    bool rejected=false;try{sessionAudio.PrepareTrack("not-a-catalogue-track");}catch(ArgumentException){rejected=true;}sessionAudio.CancelPreparedTrack();
    Assert(rejected&&sessionAudio.CachedMusicCount==18,"unknown tracks cannot grow the cache");
   }
   Destroy(sessionAudio.gameObject);sessionAudio=null;yield return null;yield return null;
   Assert(Live()==0,"audio owner destruction releases all retained tracks");
   var pending=new NativeMusicResources();pending.Prepare(names[0]);pending.Dispose();pending.Dispose();
   for(int f=0;f<120;f++)yield return null;
   Assert(pending.Count==0&&Live()==0,"destruction during asynchronous load releases late completion");
   File.WriteAllText(report,JsonUtility.ToJson(new MusicValidationResult{passed=true,quality=quality,mode=NativeSessionAudio.LegacyMusicRetirement?"before":"after",checks=checks.ToArray(),samples=samples.ToArray(),liveMusicAfterOwnerDestroyed=Live(),initialUnityUsed=initial,note="Three passes through all 18 original streaming tracks. Asset metadata/start/fade/mute/reuse/cancellation/reset/destruction checks; numeric muted validation, not a listening or PCM-output comparison. Unity per-asset bytes exclude some FMOD streaming pools: total Unity and process memory are recorded separately."},true));Application.Quit();
  }
 }
}

using System;
using System.Linq;
using UnityEngine;
using UnityEngine.Rendering;
namespace MazeBiters.NativeStudy {
 public sealed partial class NativeGameplayStudy {
  bool logicPreparationInstance,logicPrepared,coldLogicControl,resourcesDisposed;
  bool borrowedCoopArt;
  double logicPreparationMs;
  int logicPreparationCases;
  NativeGameplayStudy logicPreparationOwner;
  void ReleaseInterruptedLogicPreparation(){
   var warm=logicPreparationOwner;logicPreparationOwner=null;if(!warm)return;
   warm.DisposeGameplayResources();if(warm.camera)Destroy(warm.camera.gameObject);Destroy(warm.gameObject);
  }

  // Execute the ORIGINAL Tick -> OnEvent -> motion -> Render paths. This is
  // not a replay in the real world: the inactive component owns its RNG,
  // entities, clocks, effects and targets. Only immutable source banks are lent.
  void PrepareGameplayLogic(){foreach(var step in PrepareGameplayLogicSteps()){} }
  System.Collections.Generic.IEnumerable<object> PrepareGameplayLogicSteps(bool asynchronous=false){
   if(logicPrepared||logicPreparationInstance||coldLogicControl)yield break;
   long start=System.Diagnostics.Stopwatch.GetTimestamp();
   var owner=new GameObject("Temporary isolated gameplay preparation");
   owner.SetActive(false); // Start/Update/input/OnGUI must never run.
   var warm=owner.AddComponent<NativeGameplayStudy>();
   if(NativeMazeWorker.Enabled)logicPreparationOwner=warm;
   warm.logicPreparationInstance=true;warm.contactProbe=true;
   warm.level=level;warm.quality=quality;warm.bank=bank;warm.scorpionImages=scorpionImages;
   if(NativeBalancedLaunch.Distributed&&coopArt!=null){warm.coopArt=coopArt;warm.coopArtQuality=coopArtQuality;warm.borrowedCoopArt=true;}
   var active=RenderTexture.active;
   try{
    warm.quad=Instantiate(quad);
    warm.camera=new GameObject("Preparation-only camera").AddComponent<Camera>();
    warm.camera.enabled=false;warm.camera.cullingMask=0;
    warm.camera.orthographic=true;warm.camera.orthographicSize=216;warm.camera.aspect=4f/3;
    warm.camera.transform.position=new Vector3(288,-184,-10);
    warm.camera.clearFlags=CameraClearFlags.SolidColor;warm.camera.backgroundColor=Color.black;
    warm.target=new RenderTexture(32,24,0,RenderTextureFormat.ARGB32);warm.target.Create();
    warm.camera.targetTexture=warm.target;
    warm.draw=new CommandBuffer{name="Preparation-only original event drawing"};
    warm.camera.AddCommandBuffer(CameraEvent.BeforeForwardAlpha,warm.draw);
    warm.dusk=new NativeDusk(warm.quad,warm.camera);
    if(NativeBalancedLaunch.Distributed)yield return "logic lighting";
    warm.blooms=new NativeBiteBloom(warm.quad,NativeSmoothLoading.Enabled);if(NativeSmoothLoading.Enabled)foreach(var step in warm.blooms.LoadSteps())yield return "logic bite source";warm.intake=new NativeIntakeLayer(warm.quad);
    warm.sessionArt=new NativeSessionPresentation(warm.quad);warm.sessionArt.SetQuality(quality);
    if(NativeBalancedLaunch.Distributed)yield return "logic effects";
    warm.neon=new NativeNeon(level.geometry,warm.quad,warm.dusk,false,Array.Empty<NativeSnake>(),true,true,true,deferred:NativeSmoothLoading.Enabled);
    if(NativeSmoothLoading.Enabled){while(!warm.neon.PrepareStep())yield return "logic neon setup";warm.neon.SetVisible(true);}
    yield return "logic setup";
    // The fixture positions are chosen in the actual maze; no gameplay AI,
    // collision, timing or animation equations are replaced.
    foreach(string kind in new[]{"split-middle","split-neck","split-tail","tail","solo-front","head-front","hunter-spawn","hunter-power","scorpion-tail","scorpion-claws","rival-p1","rival-p2"}){
     foreach(var step in warm.PrepareLogicCaseSteps(kind))yield return step;
     logicPreparationCases++;yield return "logic "+kind;
    }
    foreach(var step in NativePreparation.DrainSteps(warm.target,asynchronous&&NativeSmoothLoading.Enabled))yield return step;
    logicPrepared=true;
   }finally{
    if(NativeSmoothLoading.Enabled)VisibilityPreparation.End();
    if(ReferenceEquals(logicPreparationOwner,warm))logicPreparationOwner=null;
    RenderTexture.active=active;
    warm.DisposeGameplayResources();
    if(warm.camera)Destroy(warm.camera.gameObject);
    Destroy(owner);
   }
   logicPreparationMs=(System.Diagnostics.Stopwatch.GetTimestamp()-start)*1000.0/System.Diagnostics.Stopwatch.Frequency;
  }

  System.Collections.Generic.IEnumerable<object> PrepareLogicCaseSteps(string kind){
   draw.Clear();intake.Begin();blooms.Reset();
   foreach(var s in snakes.Values)s.Dispose();snakes.Clear();
   foreach(var s in ghosts)s.Dispose();ghosts.Clear();
   foreach(var a in actors.Values)a.Dispose();actors.Clear();
   scorpionArt?.Dispose();scorpionArt=null;
   foreach(var g in scorpionGhosts)g.art.Dispose();scorpionGhosts.Clear();
   time=realClock=2000;random=34;events.Clear();
   world=new NativeGameplayWorld(level.geometry,Random){Time=time,RealTime=time,SessionEnabled=true};
   world.Event=OnEvent;world.LifecycleEnabled=false;
   var sentinel=world.AddSnake(new[]{new Vector2Int(27,9)},Vector2Int.right,4);
   sentinel.LastMove=time+100000;AddSnake(sentinel);
   var p=world.Player;Vector2Int cell,approach=Vector2Int.right;string expected;
   if(kind.StartsWith("rival")){
    world.SetMode(2);p=world.PlayerById(kind=="rival-p1"?1:2);var victim=world.PlayerById(p.Id==1?2:1);cell=new Vector2Int(4,1);victim.Cell=victim.From=victim.Previous=cell;victim.Dir=victim.Next=Vector2Int.left;AddActor(victim,true,victim.Palette);p.Score=100;expected="playerBite";
   }else if(kind.StartsWith("hunter")){
    cell=new Vector2Int(4,1);
    var h=new NativeHunter{Id=100,Palette=0,Cell=cell,From=cell,Dir=Vector2Int.left,LastMove=time+100000};
    world.Hunters.Add(h);AddActor(h,false,0);
    world.ActivatePower(); // Preparation warms an actual attack, never the defensive spawn shield.
    expected="hunterBite";
   }else if(kind.StartsWith("scorpion")){
    var s=world.PlaceScorpion(new Vector2Int(5,1),Vector2Int.right);
    bool tail=kind=="scorpion-tail";cell=tail?s.Tail:s.Cell;approach=tail?s.Dir:-s.Dir;
    scorpionArt=CreateScorpionArt();expected="scorpionBite";
   }else{
    bool split=kind.StartsWith("split");int cut=kind=="split-neck"?1:kind=="split-middle"?3:kind=="split-tail"?5:kind=="tail"?6:0;
    var body=ContactSnakePath(approach,cut,split);
    if(kind=="solo-front")body=new[]{body[0]};
    var s=world.AddSnake(body,body.Length==1?-approach:body[0]-body[1],0);
    s.LastMove=time;AddSnake(s);cell=body[cut];
    if(kind.Contains("front"))world.ActivatePower();
    expected=split||kind=="head-front"?"split":kind=="tail"?"tail":"head";
   }
   p.Cell=p.From=p.Previous=cell-approach;p.Dir=Vector2Int.up;p.Next=approach;
   p.Waiting=false;p.LastMove=time-world.PlayerDelay;
   AddActor(p,true,p.Palette);
   if(NativeBalancedLaunch.Distributed)yield return "logic "+kind+" actors";
   for(int frame=0;frame<48;frame++){
    time+=1000.0/120;realClock=time;world.RealTime=time;
    long tickStamp=NativeStallTrace.Stamp();world.Tick(time);world.UpdateTilt(time);NativeStallTrace.Add("logic "+kind+" tick",tickStamp);
    // Submit representative start/intermediate/end frames, not 48 redundant
    // full light passes. AI still executes every step, including new fragments.
    if(frame==0||frame==6||frame==18||frame==47){if(NativeSmoothLoading.Enabled){yield return "logic "+kind+" simulation";foreach(var step in RenderPreparationSteps())yield return step;}else Render();}
    if(NativeBalancedLaunch.Distributed&&frame%6==5)yield return "logic "+kind+" ticks";
   }
   if(!events.Contains(expected))throw new InvalidOperationException("Gameplay preparation missed "+kind);
  }
 }
}

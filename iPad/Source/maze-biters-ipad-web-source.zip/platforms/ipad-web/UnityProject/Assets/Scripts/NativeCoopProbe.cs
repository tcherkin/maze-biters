using System;using System.IO;using System.Linq;using System.Collections;using System.Collections.Generic;using System.Diagnostics;using UnityEngine;using UnityEngine.Profiling;
namespace MazeBiters.NativeStudy {
 public sealed partial class NativeGameplayStudy {
  bool coopProbe,coopBenchmark;
  [Serializable] sealed class CoopReport {public bool passed;public string quality,note;public string[] checks;public int hudPixels,hudMax,hudBeyondThree,intakePeak;}
  [Serializable] sealed class CoopHudCase {public int score,score2,score3,lives,lives2,lives3,level,snakes;public double time,life1,life2,life3,spot1,spot2,spot3,levelAt;public string image;}
  [Serializable] sealed class CoopHudCases {public CoopHudCase[] cases;}
  bool AiMode=>Environment.GetCommandLineArgs().Contains("--solo-ai");
  bool DuoAiMode=>Environment.GetCommandLineArgs().Contains("--duo-ai");
  bool AnyAiMode=>AiMode||DuoAiMode;
  int AiSlot=>DuoAiMode?2:1;
  void CoopFixture(){Reset(9);world.SetMode(DuoAiMode?4:AiMode?3:Environment.GetCommandLineArgs().Contains("--versus")?2:5);for(int i=1;i<world.PlayerCount;i++){var p=world.GetPlayer(i);p.Cell=p.From=p.Previous=new Vector2Int(30-i,1);p.Dir=p.Next=Vector2Int.left;p.LastMove=time+100000;AddActor(p,true,p.Palette);}world.LifecycleEnabled=true;world.ScorpionSpawnAt=double.PositiveInfinity;PrepareLevelResources();}
  IEnumerator ProbeCoop(){
   var checks=new List<string>();void Check(bool b,string name){if(!b)throw new Exception("Live multiplayer: "+name);checks.Add(name);}
   Directory.CreateDirectory(Path.GetDirectoryName(report));sessionSmoke=true;Reset(12);yield return DrainProbePreparation();Render();
   Check(world.Multiplayer&&actors.ContainsKey(2)&&world.GetPlayer(1).Palette==(AiMode?2:1),"generated two-player roster and original palette");Capture(Path.ChangeExtension(report,null)+"-start.png");
   if(AnyAiMode)Check(gameplayCamera.Subjects==world.PlayerCount,"original camera includes all humans and AI");if(DuoAiMode){Check(actors[3].art.Palette=="ai"&&world.GetPlayer(2).IsAI&&!world.GetPlayer(1).IsAI,"third AI identity and second human");Check(Enumerable.Range(0,keys.Length).All(i=>KeyboardPlayerSlot(i)==(i%3==0?1:0)),"arrows P2; WASD/IJKM P1; keyboard never controls AI");}
   // Actual same-palette turn/mouth/blink resources, independently clocked.
   double blink1=actors[1].blink.Sample(time);var p2=world.GetPlayer(1);using(world.ForPlayer(p2))world.ActivatePower();
   world.GetPlayer(0).ShieldUntil=0;time+=500;world.Time=time;realClock+=500;Render();
   Check(actors[2].art.Bright&&!actors[1].art.Bright,"power belongs to P2 only");
   Check(humanPoses[0].angle!=humanPoses[1].angle||world.GetPlayer(0).Dir==p2.Dir,"independent initial heading");
   Capture(Path.ChangeExtension(report,null)+"-lights.png");
   // Full dual header, original source images including leaders, both lives and sweeps.
   var cgo=new GameObject("COOP header parity camera");var hc=cgo.AddComponent<Camera>();hc.enabled=false;hc.cullingMask=1<<27;hc.orthographic=true;hc.orthographicSize=16;hc.aspect=18;hc.transform.position=new Vector3(288,16,-10);hc.clearFlags=CameraClearFlags.SolidColor;hc.backgroundColor=Color.black;hc.allowHDR=hc.allowMSAA=false;
   int width=quality=="4k"?2880:1440,height=quality=="4k"?160:80;var rt=new RenderTexture(width,height,0,RenderTextureFormat.ARGB32);rt.Create();hc.targetTexture=rt;
   var parent=new GameObject("COOP parity header");var ih=new NativeHud(quad,parent.transform);foreach(var t in parent.GetComponentsInChildren<Transform>())t.gameObject.layer=27;
   var actual=new Texture2D(width,height,TextureFormat.RGBA32,false);var expected=new Texture2D(2,2,TextureFormat.RGBA32,false);var save=RenderTexture.active;int hudMax=0,bad=0,pixels=0;
   var spec=JsonUtility.FromJson<CoopHudCases>(File.ReadAllText(Path.Combine(WebFiles.Root,"Reference/coop/"+quality+(DuoAiMode?"-duo-ai":AiMode?"-ai":"")+"-hud.json")));
   var hw=new NativeGameplayWorld(world.Grid,()=>.5);hw.SetMode(DuoAiMode?4:AiMode?3:5);
   foreach(var s in spec.cases){hw.GetPlayer(0).Score=s.score;hw.GetPlayer(1).Score=s.score2;hw.GetPlayer(0).Lives=s.lives;hw.GetPlayer(1).Lives=s.lives2;hw.GetPlayer(0).LifeSpotlight=s.life1;hw.GetPlayer(1).LifeSpotlight=s.life2;hw.GetPlayer(0).ScoreSpotlight=s.spot1;hw.GetPlayer(1).ScoreSpotlight=s.spot2;if(DuoAiMode){var ai=hw.GetPlayer(2);ai.Score=s.score3;ai.Lives=s.lives3;ai.LifeSpotlight=s.life3;ai.ScoreSpotlight=s.spot3;}hw.Level=s.level;hw.Snakes.Clear();for(int i=0;i<s.snakes;i++)hw.Snakes.Add(new NativeGameplaySnake());// Exercise the real cached SOLO -> multiplayer menu path with identical values.
    ih.RenderValues(s.score,s.lives,s.level,s.snakes,s.time,quality,s.levelAt,s.life1,s.spot1);ih.BeginLevel(s.levelAt,true);ih.Render(hw,s.time,quality);hc.Render();RenderTexture.active=rt;actual.ReadPixels(new Rect(0,0,width,height),0,0);actual.Apply();expected.LoadImage(File.ReadAllBytes(Path.Combine(WebFiles.Root,"Reference/coop/"+s.image)));var aa=actual.GetPixels32();var bb=expected.GetPixels32();for(int i=0;i<aa.Length;i++){int e=Math.Max(Math.Max(Math.Abs(aa[i].r-bb[i].r),Math.Abs(aa[i].g-bb[i].g)),Math.Max(Math.Abs(aa[i].b-bb[i].b),Math.Abs(aa[i].a-bb[i].a)));hudMax=Math.Max(hudMax,e);if(e>3)bad++;}pixels+=aa.Length;File.WriteAllBytes(Path.Combine(Path.GetDirectoryName(report),s.image),actual.EncodeToPNG());}
   RenderTexture.active=save;ih.Dispose();Destroy(parent);Destroy(cgo);rt.Release();Destroy(rt);Destroy(actual);Destroy(expected);Check(hudMax<=3,spec.cases.Length+" full HUD images match original within 3 channel bytes");
   yield return null;
   if(AnyAiMode){var start=world.GetPlayer(AiSlot).Cell;int moved=0;for(int f=0;f<600;f++){time+=1000.0/120;realClock+=1000.0/120;world.Tick(time);world.UpdateAllTilts(time);Render();var cell=world.GetPlayer(AiSlot).Cell;if(cell!=start){moved++;start=cell;}yield return null;}Check(moved>5&&world.GetPlayer(AiSlot).Ai!=null,"AI makes original decisions and travels without human input");Capture(Path.ChangeExtension(report,null)+"-autonomous.png");}
   if(world.Competitive)yield return ProbeVersusContacts(checks);
   int maxIntake=0;
   // Both humans use the unchanged cell advance/contact route, never direct visual-only eating.
   foreach(int id in Enumerable.Range(1,DuoAiMode?3:2))foreach(string kind in new[]{"tail","split","head","hunter","scorpion"}){
    CoopFixture();yield return DrainProbePreparation();var eater=world.PlayerById(id);var other=world.PlayerById(id==1?2:1);
    for(int i=0;i<world.PlayerCount;i++){var bystander=world.GetPlayer(i);if(bystander==eater)continue;bystander.Cell=bystander.From=new Vector2Int(30-i,1);bystander.LastMove=time+100000;bystander.BiteAt=bystander.BiteEnd=-100000;}eater.Cell=eater.From=eater.Previous=new Vector2Int(2,1);eater.Dir=eater.Next=Vector2Int.right;eater.Waiting=false;eater.ShieldUntil=0;eater.PowerUntil=0;if(kind=="head"||kind=="hunter")using(world.ForPlayer(eater))world.ActivatePower();
    if(kind=="tail"||kind=="split"){var s=world.AddSnake(Enumerable.Range(3,7).Reverse().Select(x=>new Vector2Int(x,1)),Vector2Int.right,1);s.LastMove=time;AddSnake(s);if(kind=="split"){eater.Cell=eater.From=eater.Previous=new Vector2Int(5,1);}}
    else if(kind=="head"){var s=world.AddSnake(new[]{new Vector2Int(3,1)},Vector2Int.left,3);AddSnake(s);}
    else if(kind=="hunter"){var h=new NativeHunter{Id=100,Palette=1,Cell=new Vector2Int(3,1),From=new Vector2Int(3,1),Dir=Vector2Int.left};world.Hunters.Add(h);AddActor(h,false,1);}
    else {world.PlaceScorpion(new Vector2Int(4,1),Vector2Int.right);scorpionArt=CreateScorpionArt();}
    Render();yield return DrainProbePreparation();using(world.ForPlayer(eater))world.AdvancePlayer();
    int wanted=kind=="tail"?25:kind=="split"?10:kind=="head"?125:kind=="hunter"?200:150;
    Check(eater.Score==wanted&&other.Score==0&&!eater.Dead,"P"+id+" "+kind+" owns score/contact");
    Check(other.BiteAt==-100000&&eater.BiteEnd>time,"P"+id+" "+kind+" owns bite clock");
    eater.LastMove=time;for(int f=0;f<60;f++){time+=1000.0/120;realClock+=1000.0/120;world.Tick(time);Render();int n=PlayerIntake(id).Probe();maxIntake=Math.Max(maxIntake,n);if(f==10){Capture(Path.ChangeExtension(report,null)+"-p"+id+"-"+kind+".png");}yield return null;}
   }
   Check(maxIntake>0,"mouth occlusion layer contains consumed tail");
   // All turn headings + reversals still render during biting and blinking.
   CoopFixture();yield return DrainProbePreparation();
   foreach(var d in NativeLevelStudy.Directions){foreach(int id in Enumerable.Range(1,DuoAiMode?3:2)){var p=world.PlayerById(id);actors[id].turn.Request(Bank(p.Dir),Bank(d),time);p.Dir=p.Next=d;}
    for(int f=0;f<14;f++){time+=1000.0/120;world.Time=time;realClock+=1000.0/120;Render();yield return null;}
   }Check(actors[1].art.Palette=="p1"&&actors[2].art.Palette==(AiMode?"ai":"p2"),"turn/bite/blink keep correct identities");
   string original=quality;quality=original=="hd"?"4k":"hd";SetQuality();yield return DrainProbePreparation();Render();Check(actors[2].art.Palette==(AiMode?"ai":"p2")&&actors[2].neon==null,"quality switch never turns P2 into hunter");if(DuoAiMode)Check(actors[3].art.Palette=="ai"&&actors[3].neon==null,"quality switch preserves third actor AI");quality=original;SetQuality();yield return DrainProbePreparation();Render();
   Reset(12);yield return DrainProbePreparation();var a=world.GetPlayer(0);var b=world.GetPlayer(1);a.Score=100;a.ExactScore=100;b.Score=200;b.ExactScore=200;
   using(world.ForPlayer(b))world.SessionDeath();time+=1000;world.Time=time;Render();Check(a.Lives==3&&b.Lives==2&&!world.GameOverPending,"P2 death leaves partner active");Capture(Path.ChangeExtension(report,null)+"-death.png");
   world.Snakes.Clear();world.Hunters.Clear();world.Scorpion=null;world.Eggs.Clear();time=b.RespawnAt;world.Time=time;world.SessionTick();Render();Check(!world.GetPlayer(1).Dead&&world.GetPlayer(1).Score==200,"P2 respawn keeps score and renderer");
   if(DuoAiMode){var ai=world.GetPlayer(2);using(world.ForPlayer(ai))world.SessionDeath();time+=1000;world.Time=time;Render();Check(ai.Dead&&ai.Lives==2&&sessionArt.PlayerSkullMaterial(2)!=null&&a.Lives==3,"AI independent skull and death");Capture(Path.ChangeExtension(report,null)+"-ai-death.png");
    var originalCell=a.Cell;var aiStart=NativeMazeGenerator.Starts()[2];a.Cell=a.From=new Vector2Int(aiStart.x,aiStart.y);time=ai.RespawnAt;world.Time=time;world.SessionTick();Check(world.GetPlayer(2).Dead,"human on AI start blocks respawn");
    a.Cell=a.From=originalCell;time++;world.Time=time;world.SessionTick();Render();Check(!world.GetPlayer(2).Dead&&world.GetPlayer(2).IsAI&&world.GetPlayer(2).Palette==2&&world.GetPlayer(2).ShieldUntil>time&&actors[3].art.Palette=="ai","AI respawn keeps identity and spawn protection");
   }
   // Next-level preview must preserve all identities even when activated by P2.
   using(world.ForPlayer(world.GetPlayer(1)))world.CheckLevelComplete();
   for(int f=0;f<750;f++){time+=1000.0/120;realClock+=1000.0/120;world.Time=time;world.RealTime=realClock;world.SessionTick();Render();if(scenePreparationPending)yield return DrainProbePreparation();yield return null;}
   Check(world.Level==2&&world.PlayerCount==(DuoAiMode?3:2)&&actors.ContainsKey(2)&&world.GetPlayer(0).Score==600&&world.GetPlayer(1).Score==700,"level transition prepares/installs both players and original bonuses");
   if(DuoAiMode)Check(world.GetPlayer(2).IsAI&&world.GetPlayer(2).Palette==2&&actors[3].art.Palette=="ai"&&world.GetPlayer(2).Score==500,"level transition retains third AI and bonus");
   Capture(Path.ChangeExtension(report,null)+"-level2.png");
   foreach(int id in Enumerable.Range(1,DuoAiMode?3:2))using(world.ForPlayer(world.PlayerById(id))){world.Player.Lives=1;world.SessionDeath();if(id<world.PlayerCount)Check(!world.GameOverPending,"surviving participant keeps game running");}
   Check(world.GameOverPending,"both eliminated schedule game over");world.Time=time+NativeGameplayWorld.DeathDuration;world.RealTime=realClock+NativeGameplayWorld.DeathDuration;world.SessionTick();Check(world.GameOver,"game over waits for final skull");
   File.WriteAllText(report,JsonUtility.ToJson(new CoopReport{passed=true,quality=quality,checks=checks.ToArray(),hudPixels=pixels,hudMax=hudMax,hudBeyondThree=bad,intakePeak=maxIntake,note="Generated multiplayer mode (CLI --duo-ai selects original mode 4; --solo-ai mode 3; --versus mode 2), all-participant cell contacts, independent power/score/death/respawn, turn/blink/mouth resources, intake masks, quality switches, next-scene install, last-player GAME OVER. Staged inputs/encounters; not timing. Browser source remains read-only."},true));Application.Quit();
  }
  [Serializable] struct CoopBenchFrame {public double gapMs,simulationMs,submitMs,allyMs;public long allocated;public bool focused;}
  [Serializable] sealed class CoopBenchReport {public bool passed;public string quality,mode,note,gpu,cpu;public int width,height,logicalProcessors,allyDecisions;public double elapsed,cpuSeconds,allyCpuMs;public long workingSet,peakWorkingSet,privateBytes,unityUsed,managed;public int[] scores,lives;public string[] allyEvents,allyThoughts;public CoopBenchFrame[] frames;public int startSnakes,endSnakes;public int[] knockoutFrames;}
  IEnumerator BenchmarkCoop(){
   bool contacts=Environment.GetCommandLineArgs().Contains("--vs-contact-benchmark"),natural=Environment.GetCommandLineArgs().Contains("--ai-natural");var knockouts=new List<int>();
   sessionSmoke=true;Reset(12);yield return DrainProbePreparation();
   world.LifecycleEnabled=true;world.ScorpionSpawnAt=time;world.SpawnScorpion();if(world.Scorpion!=null){world.Scorpion.NextFruit=time+100000;world.Scorpion.NextEgg=time+100000;}
   // Same generated campaign; bounded late-level fixtures keep all three hunter palettes and fruit effects active.
   for(int i=0;i<3;i++){var cell=world.Brain.Nearest(new Vector2Int(12+i*7,12));var h=new NativeHunter{Id=100+i,Cell=cell,From=cell,Dir=Vector2Int.right,Palette=i,LastMove=time};world.Hunters.Add(h);AddActor(h,false,i);}
   for(int i=0;i<4;i++)world.Fruits.Add(new NativeFruit{Cell=world.Brain.Nearest(new Vector2Int(8+i*6,6)),Kind=i,Born=time});
   for(int i=0;i<world.PlayerCount;i++){var p=world.GetPlayer(i);p.ShieldUntil=natural?time+3500:time+1e6;p.Waiting=false;if(natural)p.Lives=9;p.Score=p.ExactScore==0?25*(i+1):p.Score;p.ExactScore=p.Score;}
   if(contacts)for(int i=0;i<2;i++)world.GetPlayer(i).Lives=9;
   PrepareLevelResources();yield return DrainProbePreparation();
   var observedEvents=new Dictionary<string,int>();var observedThoughts=new HashSet<string>();var originalEvent=world.Event;world.Event=e=>{if(e.Player?.IsAI==true){observedEvents.TryGetValue(e.Kind,out int n);observedEvents[e.Kind]=n+1;}originalEvent?.Invoke(e);};
   var visits=new[]{new Dictionary<Vector2Int,int>(),new Dictionary<Vector2Int,int>()};var samples=new CoopBenchFrame[natural?7200:3600];world.MeasureAlly=true;
   void Pilot(){for(int i=0;i<world.PlayerCount;i++)if(!world.GetPlayer(i).IsAI)using(world.ForPlayer(world.GetPlayer(i)))StallPilot(visits[i],true);}
   void Step(){time+=1000.0/120;realClock+=1000.0/120;world.RealTime=realClock;world.Tick(time);world.UpdateAllTilts(time);sessionAudio?.Sync(world,false);}
   for(int f=0;f<360;f++){Pilot();Step();Render();yield return null;}GC.Collect();yield return null;int startSnakes=world.Snakes.Count;world.AllyCpuMs=0;world.AllyDecisions=0;observedEvents.Clear();
   using(var process=Process.GetCurrentProcess()){
    double cpuStart=process.TotalProcessorTime.TotalSeconds;long start=Stopwatch.GetTimestamp(),previous=0;
    for(int f=0;f<samples.Length;f++){long now=Stopwatch.GetTimestamp(),bytes=GC.GetAllocatedBytesForCurrentThread();Pilot();long tick=Stopwatch.GetTimestamp();if(contacts&&f>=120&&f<=3000&&(f-120)%480==0){StageVersusKnockout(knockouts.Count);knockouts.Add(f);}Step();double sim=NativeStallTrace.Ms(tick);if(AnyAiMode&&!string.IsNullOrEmpty(world.GetPlayer(AiSlot).Ai?.thought))observedThoughts.Add(world.GetPlayer(AiSlot).Ai.thought);long render=Stopwatch.GetTimestamp();Render();double submit=NativeStallTrace.Ms(render);samples[f]=new CoopBenchFrame{gapMs=previous==0?0:(now-previous)*1000.0/Stopwatch.Frequency,simulationMs=sim,submitMs=submit,allyMs=world.LastAllyMs,allocated=GC.GetAllocatedBytesForCurrentThread()-bytes,focused=Application.isFocused};previous=now;yield return null;}
    double elapsed=NativeStallTrace.Ms(start)/1000,used=process.TotalProcessorTime.TotalSeconds-cpuStart;NativeMemory.TryRead(out long ws,out long peak,out long committed);
    File.WriteAllText(report,JsonUtility.ToJson(new CoopBenchReport{passed=(!contacts||knockouts.Count==7)&&(natural?world.AllyDecisions>100:Enumerable.Range(0,world.PlayerCount).All(i=>!world.GetPlayer(i).Dead)),quality=quality,mode=world.Mode==4?(natural?"DUO VS AI natural":"DUO VS AI"):world.Mode==3?(natural?"SOLO VS AI natural":"SOLO VS AI"):contacts?"DUO VS contacts":world.Competitive?"DUO VS":world.Cooperative?"CO-OP":"SOLO",width=target.width,height=target.height,elapsed=elapsed,cpuSeconds=used,workingSet=ws,peakWorkingSet=peak,logicalProcessors=Environment.ProcessorCount,allyDecisions=world.AllyDecisions,allyCpuMs=world.AllyCpuMs,allyEvents=observedEvents.Select(k=>k.Key+":"+k.Value).ToArray(),allyThoughts=observedThoughts.ToArray(),scores=Enumerable.Range(0,world.PlayerCount).Select(i=>world.GetPlayer(i).Score).ToArray(),lives=Enumerable.Range(0,world.PlayerCount).Select(i=>world.GetPlayer(i).Lives).ToArray(),privateBytes=committed,unityUsed=Profiler.GetTotalAllocatedMemoryLong(),managed=GC.GetTotalMemory(false),frames=samples,knockoutFrames=knockouts.ToArray(),startSnakes=startSnakes,endSnakes=world.Snakes.Count,cpu=SystemInfo.processorType,gpu=SystemInfo.graphicsDeviceName,note="Same generated campaign/build/seed with 3 hunter palettes, scorpion and fruit. 360 warmup + 3600 measured 120Hz steps; real loop gaps and whole-process CPU separate. Diagnostic pilots control humans only; modes 3/4 run original AllyBrain. Long shields prevent early test termination in the comparison; --ai-natural instead runs 7200 measured steps with normal shield/power timings and 9 test lives, allowing actual AI eating/death. Optional --vs-contact-benchmark stages seven alternating keyboard knockouts, with original death/respawn and sound mixing; staging is included in frame CPU time. SOLO/CO-OP/VS costs are contextual, not an identical-camera optimization A/B. Native 4:3 render area in HD/4K output. Audio mixed but muted; no screenshots in timing; RAM not VRAM."},true));
   }
   Render();Capture(Path.ChangeExtension(report,null)+".png");Application.Quit();
  }
 }
}


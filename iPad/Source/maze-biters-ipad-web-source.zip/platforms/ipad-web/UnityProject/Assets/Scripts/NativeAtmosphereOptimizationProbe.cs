using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using UnityEngine;
using UnityEngine.Profiling;
using Stopwatch=System.Diagnostics.Stopwatch;
namespace MazeBiters.NativeStudy {
 public sealed partial class NativeGameplayStudy {
  bool AtmosphereOptimizationProbe=>Array.IndexOf(Environment.GetCommandLineArgs(),"--atmosphere-optimization-probe")>=0;
  [Serializable] sealed class AtmosphereImageCase {public string theme;public double seconds,zoom;public long pixels,changed;public int maximum;public double mean;}
  [Serializable] sealed class AtmosphereImageResult {public bool passed;public string quality;public AtmosphereImageCase[] cases;public long cacheChecks,skippedSubmissions;}
  readonly List<AtmosphereImageCase> atmosphereImages=new List<AtmosphereImageCase>();
  long atmosphereCacheChecks;
  void CompareAtmospherePixels(string theme){
   if(!AtmosphereOptimizationProbe)return;
   double saved=levelAtmosphereSeconds,x=cameraViewX,y=cameraViewY,z=cameraViewZoom;
   // Intermediate clocks expose flicker, cell boundaries and moving end caps.
   foreach(double clock in new[]{0,.473,1.5,2.913,3,4.151,6.389}){
    double zoom=clock==.473||clock==4.151?2.15:1;
    SetGameplayCameraView(zoom>1?176.37:288,zoom>1?121.29:200,zoom);
    levelAtmosphereSeconds=clock;
    NativeLevelAtmosphere.SetReference(true);preparationLightFrame=true;Render();var before=PreparationPixels(target);
    NativeLevelAtmosphere.SetReference(false);preparationLightFrame=true;Render();var after=PreparationPixels(target);
    var c=new AtmosphereImageCase{theme=theme,seconds=clock,zoom=zoom,pixels=after.Length};long sum=0;
    for(int i=0;i<after.Length;i++){
     int r=Math.Abs(before[i].r-after[i].r),g=Math.Abs(before[i].g-after[i].g),b=Math.Abs(before[i].b-after[i].b),a=Math.Abs(before[i].a-after[i].a);
     int maximum=Math.Max(Math.Max(r,g),Math.Max(b,a));if(maximum>0)c.changed++;c.maximum=Math.Max(c.maximum,maximum);sum+=r+g+b+a;
    }
    c.mean=sum/(after.Length*4.0);atmosphereImages.Add(c);
    // Rounding by at most one channel byte is tolerated only on rare pixels.
    GlassCheck(c.maximum<=1&&c.mean<.0002,"optimized atmosphere matches reference "+theme+" @ "+clock);
    long uploads=atmosphereUploads,evaluations=boundWallLightRoutes.Evaluations;
    for(int i=0;i<20;i++)UpdateLevelAtmosphere();
    GlassCheck(atmosphereUploads==uploads&&boundWallLightRoutes.Evaluations==evaluations,"same-time/paused atmosphere reuses uniforms and routes");atmosphereCacheChecks++;
   }
   levelAtmosphereSeconds=saved;SetGameplayCameraView(x,y,z);preparationLightFrame=true;Render();
   var result=new AtmosphereImageResult{passed=true,quality=quality,cases=atmosphereImages.ToArray(),cacheChecks=atmosphereCacheChecks,skippedSubmissions=atmosphereSkipped};
   File.WriteAllText(Path.Combine(Path.GetDirectoryName(report),"optimization-pixels.json"),JsonUtility.ToJson(result,true));
  }
  [Serializable] struct AtmosphereCostFrame {public double gapMs,submitMs,gpuMs,mainMs,renderMs;public bool gpuValid,focused;}
  [Serializable] sealed class AtmosphereCostRun {public bool reference;public int round,frames;public double cpuMs,elapsedMs;public long unityUsed,unityReserved,managed,workingSet,privateBytes,uploads,skipped;public int gc0,gc1,gc2;public AtmosphereCostFrame[] samples;}
  [Serializable] sealed class AtmosphereShaderBatch {public string layer;public bool reference;public int round,draws;public double millisecondsPerDraw;}
  [Serializable] sealed class AtmosphereCostResult {public bool passed,frameTimingEnabled;public string quality,cpu,gpu,note,error;public int width,height;public AtmosphereCostRun[] runs;public AtmosphereShaderBatch[] shaderBatches;}
  IEnumerator ProbeAtmosphereCost(){
   var result=new AtmosphereCostResult{quality=quality,cpu=SystemInfo.processorType,gpu=SystemInfo.graphicsDeviceName,frameTimingEnabled=FrameTimingManager.IsFeatureEnabled(),note="Same binary, exact same scene and deterministic animation clocks, alternating reference/optimized. Full render chain with all existing creature effects; fixed actor poses isolate rendering cost, not AI. GPU uses unique delayed FrameTiming samples if supported. CPU is whole-process work. Background native preview, not a device or user-input latency benchmark. No readbacks/screenshots/GC inside timed runs. RAM categories overlap; not VRAM."};
   var stack=new Stack<IEnumerator>();stack.Push(RunAtmosphereCost(result));
   while(stack.Count>0){object current=null;bool more=false;try{more=stack.Peek().MoveNext();if(more)current=stack.Peek().Current;}catch(Exception e){result.error=e.ToString();Debug.LogError(e);break;}if(!more){stack.Pop();continue;}if(current is IEnumerator child)stack.Push(child);else yield return current;}
   NativeLevelAtmosphere.SetReference(false);result.passed=string.IsNullOrEmpty(result.error);File.WriteAllText(report,JsonUtility.ToJson(result,true));Application.Quit(result.passed?0:2);
  }
  IEnumerator RunAtmosphereCost(AtmosphereCostResult result){
   sessionSmoke=true;fixedCamera=true;GlassScene(10,4);yield return DrainProbePreparation();GlassExtras();yield return DrainProbePreparation();if(sessionAudio!=null)sessionAudio.Muted=true;
   if(Array.IndexOf(Environment.GetCommandLineArgs(),"--atmosphere-batch-probe")>=0){yield return RunAtmosphereBatches(result);yield break;}
   // Keep this workload inside the existing level; all animation clocks are
   // replayed identically in each round, so both paths draw the same pixels.
   double baseTime=time;int count=720;var runs=new List<AtmosphereCostRun>();var gpuSample=new FrameTiming[1];
   QualitySettings.vSyncCount=0;Application.targetFrameRate=120;Application.runInBackground=true;
   void Draw(int frame){time=baseTime;levelAtmosphereSeconds=frame/120.0;double a=frame*.006;SetGameplayCameraView(288+90*Math.Sin(a),200+55*Math.Cos(a),1.25+.25*Math.Sin(a*.7));preparationLightFrame=true;Render();}
   for(int round=0;round<6;round++){
    bool reference=round%2==0;NativeLevelAtmosphere.SetReference(reference);
    for(int f=0;f<180;f++){Draw(f);FrameTimingManager.CaptureFrameTimings();yield return null;}
    var samples=new AtmosphereCostFrame[count];long uploads=atmosphereUploads,skipped=atmosphereSkipped;int g0=GC.CollectionCount(0),g1=GC.CollectionCount(1),g2=GC.CollectionCount(2);long started=Stopwatch.GetTimestamp(),previous=started;ulong lastGpu=0;
    double cpu;
    using(var process=System.Diagnostics.Process.GetCurrentProcess()){
     double cpuStart=process.TotalProcessorTime.TotalMilliseconds;
     for(int f=0;f<count;f++){
      long now=Stopwatch.GetTimestamp();Draw(f);var sample=new AtmosphereCostFrame{submitMs=NativeStallTrace.Ms(now),gapMs=f==0?0:(now-previous)*1000.0/Stopwatch.Frequency,focused=Application.isFocused};previous=now;
      FrameTimingManager.CaptureFrameTimings();if(FrameTimingManager.GetLatestTimings(1,gpuSample)>0&&gpuSample[0].frameStartTimestamp>lastGpu){var t=gpuSample[0];lastGpu=t.frameStartTimestamp;if(f>=8){sample.gpuValid=t.gpuFrameTime>0;sample.gpuMs=t.gpuFrameTime;sample.mainMs=t.cpuMainThreadFrameTime;sample.renderMs=t.cpuRenderThreadFrameTime;}}
      samples[f]=sample;yield return null;
     }
     cpu=process.TotalProcessorTime.TotalMilliseconds-cpuStart;
    }
    NativeMemory.TryRead(out long ws,out long peak,out long committed);
    runs.Add(new AtmosphereCostRun{reference=reference,round=round,frames=count,cpuMs=cpu,elapsedMs=NativeStallTrace.Ms(started),unityUsed=Profiler.GetTotalAllocatedMemoryLong(),unityReserved=Profiler.GetTotalReservedMemoryLong(),managed=GC.GetTotalMemory(false),workingSet=ws,privateBytes=committed,uploads=atmosphereUploads-uploads,skipped=atmosphereSkipped-skipped,gc0=GC.CollectionCount(0)-g0,gc1=GC.CollectionCount(1)-g1,gc2=GC.CollectionCount(2)-g2,samples=samples});
    Debug.Log("ATMOSPHERE_COST_ROUND "+quality+" "+round+" reference="+reference);
   }
   result.runs=runs.ToArray();result.width=target.width;result.height=target.height;
  }
  IEnumerator RunAtmosphereBatches(AtmosphereCostResult result){
   result.width=target.width;result.height=target.height;
   result.note="Isolated full-resolution shader throughput. Repeated 128 draws followed by a 1-pixel synchronous completion read; same textures/clock/pixels in both variants. Wall time includes CPU submission and GPU completion, NOT GPU timestamp duration, FPS or game input latency. ABBA order, three repetitions per layer; no shader/material creation in measurement. Temporary target exists only in this diagnostic, never gameplay.";
   var output=new RenderTexture(target.width,target.height,0,RenderTextureFormat.ARGB32){name="Atmosphere diagnostic throughput"};output.Create();
   var pixel=new Texture2D(1,1,TextureFormat.RGBA32,false,true);var sky=new Material(Shader.Find("MazeBiters/LuminousFrameStars"));sky.SetVector("_Rect",new Vector4(-67.13f,-41.79f,711.24f,533.43f));sky.SetVector("_Offset",new Vector4(3.17f,9.78f,0,0));
   var batches=new List<AtmosphereShaderBatch>();var previous=RenderTexture.active;
   void Complete(){RenderTexture.active=output;pixel.ReadPixels(new Rect(0,0,1,1),0,0,false);RenderTexture.active=previous;}
   try{
    levelAtmosphereSeconds=1.713;preparationLightFrame=true;Render();
    foreach(var layer in new[]{("stars",sky,(Texture)Texture2D.blackTexture),("floor",mazePaint,(Texture)maze),("wall-light",crystalPaint,(Texture)glassEmission)}){
     foreach(bool reference in new[]{true,false}){NativeLevelAtmosphere.SetReference(reference);UpdateLevelAtmosphere();for(int n=0;n<64;n++)Graphics.Blit(layer.Item3,output,layer.Item2);Complete();yield return null;}
     for(int round=0;round<12;round++){
      bool reference=round%4==0||round%4==3;NativeLevelAtmosphere.SetReference(reference);UpdateLevelAtmosphere();
      Graphics.Blit(layer.Item3,output,layer.Item2);Complete();long start=Stopwatch.GetTimestamp();
      for(int n=0;n<128;n++)Graphics.Blit(layer.Item3,output,layer.Item2);Complete();
      batches.Add(new AtmosphereShaderBatch{layer=layer.Item1,reference=reference,round=round,draws=128,millisecondsPerDraw=NativeStallTrace.Ms(start)/128});yield return null;
     }
     Debug.Log("ATMOSPHERE_SHADER_BATCH "+quality+" "+layer.Item1);
    }
   }finally{NativeLevelAtmosphere.SetReference(false);RenderTexture.active=previous;output.Release();Destroy(output);Destroy(pixel);Destroy(sky);}
   result.shaderBatches=batches.ToArray();
  }
 }
}

using System;
using UnityEngine;
namespace MazeBiters.NativeStudy {
 // Validate BEFORE painting/uploading a level. Some generated mazes reserve
 // almost every long corridor for safe player exits, leaving no legal space
 // for the original four full-length snakes. Repeating GPU preparation cannot
 // repair that geometry. Keep a viable campaign map; reroll only an unusable layout.
 // A retry retains the campaign seed's family and colour so both shuffled bags
 // and the level name remain coherent with their native iPad counterparts.
 public static class WebPlayableMaze {
  public static SessionLevel Generate(uint seed,double difficulty,int number){
   var original=NativeCampaignComposition.Generate(seed,number,difficulty);
   string family=HybridMazeStudy.Report(original)?.family??HybridMazeStudy.FamilyForLevel(seed,number);
   for(int attempt=0;attempt<16;attempt++){
    uint alternative=unchecked(seed+(uint)attempt*0x9e3779b9u);
    var level=attempt==0?original:NativeCampaignComposition.Generate(alternative,number,difficulty,family);
    level.paletteSeed=seed;level.theme=original.theme;level.openingLayoutAttempt=attempt;
    var w=new NativeGameplayWorld(level.geometry,NativeMazeGenerator.Rng(34)){Level=number,Difficulty=difficulty};
    w.SetMode(4);w.SetStarts(level);
    for(int i=0;i<w.PlayerCount;i++){var p=w.GetPlayer(i);var start=level.starts[i];p.Cell=p.From=p.Previous=new Vector2Int(start.x,start.y);p.Dir=p.Next=start.dir;}
    try{level.safeOpening=w.PrepareSafeOpeningLayout();return level;}
    catch(InvalidOperationException e)when(e.Message.StartsWith("Cannot place a complete safe opening population",StringComparison.Ordinal)){}
   }
   throw new InvalidOperationException("No safe complete opening found for level "+number+" after bounded maze preparation");
  }
 }
}

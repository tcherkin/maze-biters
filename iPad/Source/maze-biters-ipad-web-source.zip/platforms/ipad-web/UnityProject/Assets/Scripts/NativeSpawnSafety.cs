using System;
using System.Collections.Generic;
using System.Linq;
using UnityEngine;

namespace MazeBiters.NativeStudy {
 // Loading-only geometry policy. It deliberately ignores timers, old enemies,
 // eggs and shields so a cached next scene and its real start are identical.
 public sealed class NativeSpawnSafety {
  readonly NativeGameplayWorld world;
  readonly bool[] reserved;
  readonly byte[] facing;
  readonly List<int[]> fields=new List<int[]>();
  readonly NativeAllyEscapeTopology topology=new NativeAllyEscapeTopology();
  public NativeSpawnSafety(NativeGameplayWorld w){
   world=w;reserved=new bool[w.Width*w.Height];facing=new byte[reserved.Length*4];var floor=new bool[reserved.Length];
   for(int y=0;y<w.Height;y++)for(int x=0;x<w.Width;x++)floor[y*w.Width+x]=w.Floor(new Vector2Int(x,y));
   topology.Build(floor,w.Width,w.Height);
   for(int i=0;i<w.PlayerCount;i++){
    var p=w.GetPlayer(i);if(p.Lives<=0||p.Dead)continue;
    var start=p.Cell;fields.Add(Field(start));ReserveAround(start);
    // A side spur is not an escape: continue out of the whole hanging tree
    // until reaching the loop network (or the centre of a pure-tree maze).
    var c=start;int depth=topology.Depth(c);
    while(depth>0){
     Vector2Int next=c;
     foreach(var d in NativeGameplayWorld.Dirs)if(w.Floor(c+d)&&topology.Depth(c+d)==depth-1){next=c+d;break;}
     if(next==c)break;c=next;reserved[w.Index(c)]=true;depth--;
    }
    ReserveAround(c);
    // Starts in a degree-two passage also need room on either side to reach
    // a choice. No fixed 14-cell cut-off is used for these forced passages.
    if(topology.Depth(start)==0)foreach(var d in NativeGameplayWorld.Dirs){
     if(!w.Floor(start+d)||topology.Depth(start+d)>0)continue;
     var previous=start;var at=start+d;
     for(int n=0;n<reserved.Length;n++){
      reserved[w.Index(at)]=true;int choices=0;var next=at;
      foreach(var e in NativeGameplayWorld.Dirs)if(ContinuesPassage(at,at+e,previous)){choices++;next=at+e;}
      if(choices!=1||next==start){ReserveAround(at);break;}
      previous=at;at=next;
     }
    }
   }
  }
  void ReserveAround(Vector2Int c){if(!world.Floor(c))return;reserved[world.Index(c)]=true;foreach(var d in NativeGameplayWorld.Dirs)if(world.Floor(c+d))reserved[world.Index(c+d)]=true;}
  bool ContinuesPassage(Vector2Int from,Vector2Int to,Vector2Int previous)=>world.Floor(to)&&to!=previous&&!(topology.Depth(from)==0&&topology.Depth(to)>0);
  int[] Field(Vector2Int start){
   var result=Enumerable.Repeat(-1,reserved.Length).ToArray();if(!world.Floor(start))return result;
   var queue=new Queue<Vector2Int>();queue.Enqueue(start);result[world.Index(start)]=0;
   while(queue.Count>0){var c=queue.Dequeue();foreach(var d in NativeGameplayWorld.Dirs){var next=c+d;if(!world.Floor(next)||result[world.Index(next)]>=0)continue;result[world.Index(next)]=result[world.Index(c)]+1;queue.Enqueue(next);}}
   return result;
  }
  public bool Reserved(Vector2Int c)=>world.Floor(c)&&reserved[world.Index(c)];
  public bool FacingRisk(Vector2Int head,Vector2Int direction){
   int d=Array.IndexOf(NativeGameplayWorld.Dirs,direction);if(!world.Floor(head)||d<0)return true;
   int key=world.Index(head)*4+d;if(facing[key]==0)facing[key]=(byte)(ComputeFacingRisk(head,direction)?2:1);return facing[key]==2;
  }
  bool ComputeFacingRisk(Vector2Int head,Vector2Int direction){
   var at=head+direction;if(!world.Floor(head)||!world.Floor(at)||Reserved(at))return true;
   foreach(var field in fields){int here=field[world.Index(head)],next=field[world.Index(at)];if(here>=0&&here<=14&&next>=0&&next<here)return true;}
   var previous=head;
   for(int n=0;n<reserved.Length;n++){
    if(Reserved(at))return true;
    int choices=0;var next=at;
    foreach(var d in NativeGameplayWorld.Dirs)if(ContinuesPassage(at,at+d,previous)){choices++;next=at+d;}
    if(choices!=1||next==head)return false;previous=at;at=next;
   }
   return false;
  }
 }

 public sealed partial class NativeGameplayWorld {
  public void SpawnLevelSnakes(){if(UseLegacyAi){SpawnLevelSnakesLegacy();return;}SpawnSafeLevelSnakes();}
  void SpawnBaselineLevelSnakes(){
   int count=Math.Min(9,Math.Max(4,3+Math.Min(2,Math.Max(0,Level-1))+Math.Max(0,Level-3)/2)),average=Math.Max(7,16-count),spread=Math.Min(4,Math.Max(1,(Level+1)/2));
   var deltas=new List<int>();if(count%2==1)deltas.Add(0);for(int pair=0;deltas.Count<count;pair++){int n=1+pair%spread;deltas.Add(-n);deltas.Add(n);}Shuffle(deltas);var colors=SpawnColors(count);
   var safety=new NativeSpawnSafety(this);var floor=new List<Vector2Int>();for(int y=0;y<Height;y++)for(int x=0;x<Width;x++){var c=new Vector2Int(x,y);if(Floor(c)&&!safety.Reserved(c))floor.Add(c);}
   var salts=new uint[count];var temperament=new double[count];var bias=new double[count];
   for(int i=0;i<count;i++){salts[i]=(uint)(Random()*uint.MaxValue);temperament[i]=.2+Random()*.6;bias[i]=Random();}
   var occupied=new HashSet<Vector2Int>();var runway=new HashSet<Vector2Int>();var placed=new List<List<Vector2Int>>();
   // Ordinary maps finish on the first candidate. Restarts change only the
   // deterministic search order; never shorten a snake or accept an unsafe one.
   bool complete=false;
   for(int layout=0;layout<4&&!complete;layout++){
    occupied.Clear();runway.Clear();placed.Clear();
    for(int i=0;i<count;i++){
     var preferred=SpawnCells[i];uint salt=salts[i]+(uint)(layout*7919);int nodes=0;List<Vector2Int> selected=null;
     var directions=Dirs.OrderBy(d=>SpawnRank(d,salt)).ToArray();
     var heads=floor.OrderBy(c=>Math.Abs(c.x-preferred.x)+Math.Abs(c.y-preferred.y)+(layout==0?0:SpawnRank(c,salt)%13)).ThenBy(c=>SpawnRank(c,salt));
     foreach(var head in heads){
      if(occupied.Contains(head)||runway.Contains(head))continue;
      foreach(var dir in directions){
       var step=head+dir;var neck=head-dir;
       bool Free(Vector2Int c)=>Floor(c)&&!safety.Reserved(c)&&!occupied.Contains(c)&&!runway.Contains(c);
       if(!Free(step)||!Free(neck)||safety.FacingRisk(head,dir))continue;
       var path=new List<Vector2Int>{head,neck};var own=new HashSet<Vector2Int>(path);int local=0;
       bool Grow(Vector2Int previous){
        if(path.Count>=average+deltas[i])return true;
        if(++local>400||++nodes>60000)return false;
        var tail=path[path.Count-1];
        for(int turn=0;turn<5;turn++){
         var d=turn==0?previous:directions[turn-1];if(turn>0&&d==previous)continue;
         var c=tail+d;if(c==step||!Free(c)||!own.Add(c))continue;path.Add(c);
         if(Grow(d))return true;path.RemoveAt(path.Count-1);own.Remove(c);
        }
        return false;
       }
       if(Grow(-dir)){selected=path;break;}
       if(nodes>60000)break;
      }
      if(selected!=null||nodes>60000)break;
     }
     if(selected==null)break;
     placed.Add(selected);foreach(var c in selected)occupied.Add(c);runway.Add(selected[0]+selected[0]-selected[1]);
    }
    complete=placed.Count==count;
   }
   if(!complete)throw new InvalidOperationException("Cannot place a complete safe opening population for level "+Level+" mode "+Mode);
   Snakes.Clear();
   for(int i=0;i<count;i++){
    var body=placed[i];var dir=body[0]-body[1];
    Snakes.Add(new NativeGameplaySnake{Id=nextId++,Body=body,Cell=body[0],Dir=dir,Pending=dir,Palette=colors[i],Temperament=temperament[i],TurnBias=bias[i]});
   }
   StartingSnakeMass=Math.Max(1,Snakes.Sum(s=>s.Body.Count));
  }
  static uint SpawnRank(Vector2Int cell,uint salt){unchecked{uint n=(uint)(cell.x*73856093)^(uint)(cell.y*19349663)^salt;n^=n>>16;n*=0x7feb352d;n^=n>>15;return n;}}
 }
}

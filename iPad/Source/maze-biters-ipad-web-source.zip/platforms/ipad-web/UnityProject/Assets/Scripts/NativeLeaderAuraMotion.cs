using System;using UnityEngine;
namespace MazeBiters.NativeStudy {
 // Continuous version of the original two-wisp path. Reuse the brightest authored
 // stamp of each wisp from the existing atlas; move it, do not crossfade displaced
 // whole frames (which would create two pearl cores during each 72 ms interval).
 public static class NativeLeaderAuraMotion {
  public const double CycleMs=16*72;
  static double Wrap(double n)=>n-Math.Floor(n);
  public static double Phase(double time,int id)=>Wrap(time/CycleMs+id*5/16.0);
  static double ReferencePhase(int wisp)=>wisp==0?.5:0;
  static double Strength(double phase,int wisp){double sine=Math.Sin(Math.PI*Wrap(phase+wisp*.53));return .58*sine*sine;}
  public static Vector4 Geometry(double phase,int wisp){
   double life=Wrap(phase+wisp*.53),side=wisp==0?-1:1;
   double y=.5+side*(.16+.04*Math.Sin(phase*Math.PI*2+wisp*2.4));
   return new Vector4((float)(.295-life*.29),(float)(1-y),
    (float)(.10+(1-life)*.052),(float)(Strength(phase,wisp)/Strength(ReferencePhase(wisp),wisp)));
  }
  public static Vector4 Source(int wisp)=>Geometry(ReferencePhase(wisp),wisp);
  public static Vector4 SourceRect(int id,int wisp){int frame=wisp==0?8:0;return new Vector4(0,1-((id-1)*2+frame/8+1)/6f,1/8f,1/6f);}
  public static double Heading(TurnPose pose,double tilt)=>-pose.angle*90-tilt;
  public static int Validate(){
   int checks=0;void Check(bool ok,string name){if(!ok)throw new Exception("Leader aura motion: "+name);checks++;}
   void Near(double a,double b,string n,double epsilon=1e-6)=>Check(Math.Abs(a-b)<=epsilon,n);
   foreach(int id in new[]{1,2})for(int i=0;i<600;i++){
    double t=i*19.731,phase=Phase(t,id);Near(Phase(t+CycleMs,id),phase,"loop duration",1e-12);
    for(int w=0;w<2;w++){var v=Geometry(phase,w);double life=Wrap(phase+w*.53);
     Near(v.x,.295-life*.29,"authored x");Near(v.z,.10+(1-life)*.052,"authored size");
     Near(v.w*Strength(ReferencePhase(w),w),Strength(phase,w),"authored opacity");
     Check(v.w>=0&&v.w<=1.01&&v.y>.29&&v.y<.71,"bounded stamp");
    }
   }
   for(int w=0;w<2;w++){
    double crossing=Wrap(-w*.53);Check(Geometry(crossing,w).w<1e-12,"invisible reset");
    Check(Geometry(Wrap(crossing-1e-6),w).w<1e-9&&Geometry(Wrap(crossing+1e-6),w).w<1e-9,"smooth lifetime seam");
   }
   for(int from=0;from<4;from++)for(int to=0;to<4;to++){
    var clock=new NativeTurnClock(true,from);clock.Request(from,to,1000);
    for(int ms=0;ms<=90;ms++){var pose=clock.Sample(1000+ms);Near(Heading(pose,12),-90*pose.angle-12,"follows head during turn");}
   }
   Near(Phase(0,1),5/16.0,"P1 phase");Near(Phase(0,2),10/16.0,"P2 phase");
   return checks;
  }
 }
}


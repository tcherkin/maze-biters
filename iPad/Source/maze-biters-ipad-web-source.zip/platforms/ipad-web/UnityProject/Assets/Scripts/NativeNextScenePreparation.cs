using System;using System.Collections.Generic;using System.Linq;using UnityEngine;using UnityEngine.Rendering;
namespace MazeBiters.NativeStudy {
 public sealed partial class NativeGameplayStudy {
  static readonly bool NoNextScene=Array.IndexOf(Environment.GetCommandLineArgs(),"--no-next-scene")>=0;
  static readonly bool PhasedGpuSurfaces=Array.IndexOf(Environment.GetCommandLineArgs(),"--legacy-scene-optimizations")<0&&Array.IndexOf(Environment.GetCommandLineArgs(),"--legacy-gpu-surfaces")<0;
  sealed class PreparedScene {
   public NativeGameplayWorld preview;public string quality;public uint randomAtStart;
   public Dictionary<int,Actor> actors=new Dictionary<int,Actor>();public Dictionary<int,Snake> snakes=new Dictionary<int,Snake>();
   public NativeSnakeTextures.Prefetch sources;public NativePickups pickups;public NativeNeon neon;
   public int stage,index,passes;public bool ready,gpuPending,gpuDone,gpuError;public NativeGpuCompletion gpuCompletion;
   public int primedSnakes;public CommandBuffer primeCommands;
   public void ReleaseReadiness(){gpuCompletion?.Dispose();gpuCompletion=null;}
   public void Dispose(){ReleaseReadiness();primeCommands?.Dispose();primeCommands=null;neon?.Dispose(true);foreach(var s in snakes.Values)s.Dispose();foreach(var a in actors.Values){if(a.renderer)a.renderer.enabled=false;a.Dispose();}sources?.Dispose();}
  }
  PreparedScene nextScene;bool preparingNextScene,nextSceneFailed;int nextSceneHits,nextSceneFallbacks;double nextSceneReadyAt,nextSceneLargestStep;
  void CancelNextScene(){sessionAudio?.CancelPreparedTrack();nextScene?.Dispose();nextScene=null;nextSceneFailed=false;}
  void PollNextScene(){
   if(NoNextScene||logicPreparationInstance||preparingScene||nextSceneFailed||nextMaze==null||!(world.Transition||restartPreparing&&world.GameOver)||nextScene?.ready==true)return;
   long stamp=NativeStallTrace.Stamp();var watch=System.Diagnostics.Stopwatch.StartNew();
   try{
    if(nextScene==null){
     uint copied=restartPreparing?34:random;double CopyRandom(){unchecked{copied+=0x6D2B79F5;uint v=(copied^(copied>>15))*(1|copied);v^=v+(v^(v>>7))*(61|v);return (v^(v>>14))/4294967296.0;}}
     NativeGameplayWorld preview;
     if(restartPreparing){preview=new NativeGameplayWorld(nextMaze.level.geometry,CopyRandom){Difficulty=NativeMazeGenerator.Difficulties[restartDifficulty],AiDifficulty=restartDifficulty,ScoreSpeed=MenuSpeed,Time=1000,RealTime=1000};preview.SetMode(restartMode);preview.StartSession(_=>nextMaze.level);restartRandom=copied;}
     else preview=world.PreviewNextLevel(nextMaze.level,CopyRandom,world.TransitionAt+NativeGameplayWorld.ClearDuration);
     nextScene=new PreparedScene{quality=quality,randomAtStart=random,preview=preview,stage=StagedNextScene&&(!restartPreparing||NativeBalancedLaunch.Distributed)?-2:0};
     if(nextScene.stage==-2)return;
     long step=NativeStallTrace.Stamp();sessionAudio?.PrepareTrack(restartPreparing?preview.MusicTrack:world.ReserveMusic(world.Level+1));NativeStallTrace.Add("prep-music",step);step=NativeStallTrace.Stamp();nextScene.sources=new NativeSnakeTextures.Prefetch(nextScene.preview.Snakes.Select(s=>Colors[s.Palette]));NativeStallTrace.Add("prep-prefetch",step);return;
    }
    var plan=nextScene;
    if(plan.stage==-2){long step=NativeStallTrace.Stamp();sessionAudio?.PrepareTrack(restartPreparing?plan.preview.MusicTrack:world.ReserveMusic(world.Level+1));NativeStallTrace.Add("prep-music",step);plan.stage++;return;}
    if(plan.stage==-1){long step=NativeStallTrace.Stamp();plan.sources=new NativeSnakeTextures.Prefetch(plan.preview.Snakes.Select(s=>Colors[s.Palette]));NativeStallTrace.Add("prep-prefetch",step);plan.stage++;return;}
    if(plan.stage==0){long step=NativeStallTrace.Stamp();if(plan.sources.Step())plan.stage++;NativeStallTrace.Add("prep-source-upload",step);return;}
    if(plan.stage==1){
     if(plan.index<plan.preview.Snakes.Count){long step=NativeStallTrace.Stamp();var s=plan.preview.Snakes[plan.index++];plan.snakes.Add(s.Id,new Snake{model=s,motion=new NativeLiveSnake(s,plan.preview.Time),art=new NativeSnake(Colors[s.Palette],"lit")});NativeStallTrace.Add("prep-snake-art",step);return;}
     long playersStamp=NativeStallTrace.Stamp();
     int playerLimit=StagedNextScene&&(!restartPreparing||NativeBalancedLaunch.Distributed)?Math.Min(plan.actors.Count+1,plan.preview.PlayerCount):plan.preview.PlayerCount;
     for(int pi=plan.actors.Count;pi<playerLimit;pi++){var p=plan.preview.GetPlayer(pi);var a=new Actor{turn=new NativeTurnClock(true,Bank(p.Dir)),art=new NativeTurnActor(bank,"fantasy",new[]{"p1","p2","ai"}[p.Palette]),blink=new BlinkClock((uint)(p.Id*9721),plan.preview.Time+900)};
     a.aura.Reset(Bank(p.Dir),plan.preview.Time);a.renderer=Quad("Prepared next player",a.art.Display);a.renderer.sortingOrder=10;a.renderer.transform.localScale=new Vector3(16,16,1);a.renderer.enabled=false;plan.actors.Add(p.Id,a);}NativeStallTrace.Add("prep-player-art",playersStamp);if(plan.actors.Count==plan.preview.PlayerCount)plan.stage++;return;
    }
    if(plan.stage==2){plan.pickups=pickups;plan.stage++;return;} // Immutable pickup art is already resident; only the per-frame draw list changes.
    if(plan.stage==3){long step=NativeStallTrace.Stamp();bool staged=StagedNextScene&&(!restartPreparing||NativeBalancedLaunch.Distributed);
     if(plan.neon==null){plan.neon=new NativeNeon(plan.preview.Grid,quad,dusk,false,plan.snakes.Values.Select(s=>s.art).ToArray(),true,true,true,"levels/"+plan.preview.Level+"/",nextMaze.art,staged);plan.neon.SetVisible(false);if(staged){NativeStallTrace.Add("prep-neon",step);return;}}
     if(!staged||plan.neon.PrepareStep()){plan.sources.Dispose();plan.sources=null;plan.stage++;}NativeStallTrace.Add("prep-neon",step);return;}
    if(PhasedGpuSurfaces&&(!restartPreparing||NativeBalancedLaunch.Distributed)&&plan.passes==0&&plan.primedSnakes<plan.preview.Snakes.Count){
     long primeStamp=NativeStallTrace.Stamp();PrimeNextSnakeSurface(plan);NativeStallTrace.Add("prep-gpu-surface",primeStamp);return;
    }
    plan.primeCommands?.Dispose();plan.primeCommands=null;
    if(plan.gpuPending){if(!plan.gpuCompletion.Poll())return;plan.gpuDone=true;plan.ReleaseReadiness();plan.gpuPending=false;}if(plan.passes>=2){if(sessionAudio!=null&&!sessionAudio.PreparedTrackReady)return;plan.ready=true;nextSceneReadyAt=world.Time-world.TransitionAt;return;}WarmNextScene(plan);
    NativeStallTrace.Add("prep-gpu-warm",stamp);plan.passes++;
   }catch(Exception e){CancelNextScene();nextSceneFailed=true;Debug.LogWarning("Next scene preparation uses the safe loading gate: "+e);}
   finally{watch.Stop();nextSceneLargestStep=Math.Max(nextSceneLargestStep,watch.Elapsed.TotalMilliseconds);NativeStallTrace.Add("next-scene-step",stamp);}
  }
  // Prime one real lit/emission snake per frame before the complete scene.
  // Use the same camera/density/pose and retained surfaces as WarmNextScene;
  // no proxy resolution, replacement shader, simulation step or extra target.
  void PrimeNextSnakeSurface(PreparedScene plan){
   var active=RenderTexture.active;
   try{
    SetGameplayCameraView(288,200,1);
    var model=plan.preview.Snakes[plan.primedSnakes];var snake=plan.snakes[model.Id];var pose=snake.motion.Evaluate(plan.preview.Time);
    snake.art.Prepare(pose);snake.art.ReservedDensity=fixedCamera?0:(float)(target.height/DisplayFrame.Height*(IpadPresentation.Enabled?IpadPresentation.CloseZoom(DisplayFrame):2));
    var commands=plan.primeCommands??(plan.primeCommands=new CommandBuffer{name="Next scene one-snake preflight"});commands.Clear();commands.SetRenderTarget(target);commands.SetViewProjectionMatrices(camera.worldToCameraMatrix,camera.projectionMatrix);snake.art.Submit(commands,plan.primedSnakes+1,camera);Graphics.ExecuteCommandBuffer(commands);
    plan.neon.PrimeSnakeSurface(plan.primedSnakes,pose);plan.primedSnakes++;
   }finally{ApplyGameplayCamera();RenderTexture.active=active;}
  }
  // Warm the EXACT future scene using the existing full-size target. Restore
  // all old renderers/clocks before the enclosing Render redraws LEVEL CLEARED.
  // No extra 4K target, no update/tick, no random calls on the authoritative world.
  void WarmNextScene(PreparedScene plan){
   var oldWorld=world;var oldActors=actors;var oldSnakes=snakes;var oldGhosts=ghosts;var oldScorpions=scorpionGhosts;var oldScorpion=scorpionArt;var oldNeon=neon;var oldPickups=pickups;
   double oldTime=time,oldBite=biteInitial;bool oldPreparing=preparingScene,oldLight=preparationLightFrame;var active=RenderTexture.active;
   var restore=new List<Action>{dusk.PreserveClock(),plan.neon.PreserveClocks()};
   foreach(var a in oldActors.Values){bool enabled=a.renderer.enabled;a.renderer.enabled=false;restore.Add(()=>a.renderer.enabled=enabled);if(a.leader!=null){bool visible=a.leader.Visible;a.leader.Visible=false;restore.Add(()=>a.leader.Visible=visible);}}
   void Hide(NativeScorpionArt s){if(s==null)return;bool enabled=s.Visible;s.Visible=false;restore.Add(()=>s.Visible=enabled);}Hide(oldScorpion);foreach(var s in oldScorpions)Hide(s.art);
   foreach(var a in plan.actors.Values){var aura=a.aura;a.aura=aura.Copy();restore.Add(()=>a.aura=aura);var blink=a.blink;a.blink=blink.Copy();restore.Add(()=>a.blink=blink);}
   try{
    preparingNextScene=preparingScene=preparationLightFrame=true;oldNeon.SetVisible(false);
    world=plan.preview;time=world.Time;biteInitial=.4;actors=plan.actors;snakes=plan.snakes;ghosts=new List<Snake>();scorpionGhosts=new List<(NativeScorpionGhost,NativeScorpionArt)>();scorpionArt=null;neon=plan.neon;pickups=plan.pickups;
    SetGameplayCameraView(288,200,1);BindGlassPresentation(nextMaze.art.Maze,nextMaze.art.Emission,plan.neon,nextMaze.art);dusk.Render(world.Player.Cell,world.Player.Dir,0,false,true);
    Render();if(plan.passes==0&&world.Multiplayer)for(int pi=0;pi<world.PlayerCount;pi++){var p=world.GetPlayer(pi);actors[p.Id].leader.Warm(actors[p.Id].art,p,time);}
    long completionStamp=NativeStallTrace.Stamp();
    plan.gpuPending=true;plan.gpuDone=plan.gpuError=false;plan.gpuCompletion=new NativeGpuCompletion();
    NativeStallTrace.Add("prep-gpu-completion",completionStamp);
   }finally{
    foreach(var a in plan.actors.Values){a.renderer.enabled=false;if(a.leader!=null)a.leader.Visible=false;}plan.neon.SetVisible(false);
    world=oldWorld;time=oldTime;biteInitial=oldBite;actors=oldActors;snakes=oldSnakes;ghosts=oldGhosts;scorpionGhosts=oldScorpions;scorpionArt=oldScorpion;neon=oldNeon;pickups=oldPickups;BindGlassPresentation(maze,glassEmission,oldNeon,sceneMazeArt);UpdateLevelAtmosphere();
    for(int i=restore.Count-1;i>=0;i--)restore[i]();oldNeon.SetVisible(true);preparingNextScene=false;preparingScene=oldPreparing;preparationLightFrame=oldLight;ApplyGameplayCamera();RenderTexture.active=active;
   }
  }
  bool TryInstallNextScene(){
   var plan=nextScene;if(plan==null)return false;
   bool valid=plan.ready&&plan.quality==quality&&plan.preview.Level==world.Level&&plan.preview.Mode==world.Mode&&nextMaze!=null&&ReferenceEquals(nextMaze.level,currentGeneratedLevel)&&plan.snakes.Count==world.Snakes.Count;
   if(valid)foreach(var s in world.Snakes){if(!plan.snakes.TryGetValue(s.Id,out var v)||v.model.Palette!=s.Palette||v.model.Dir!=s.Dir||!v.model.Body.SequenceEqual(s.Body)){valid=false;break;}}
   if(!valid){nextSceneFallbacks++;CancelNextScene();return false;}
   long stamp=NativeStallTrace.Stamp();nextScene=null;
   draw.Clear();intake.Begin();blooms.Reset();foreach(var a in actors.Values){a.renderer.enabled=false;a.Dispose();}foreach(var s in snakes.Values)s.Dispose();foreach(var s in ghosts)s.Dispose();ghosts.Clear();if(scorpionArt!=null){scorpionArt.Visible=false;scorpionArt.Dispose();}scorpionArt=null;foreach(var s in scorpionGhosts){s.art.Visible=false;s.art.Dispose();}scorpionGhosts.Clear();if(!ReferenceEquals(pickups,plan.pickups))pickups?.Dispose();neon?.Dispose();
   actors=plan.actors;snakes=plan.snakes;pickups=plan.pickups;neon=plan.neon;
   foreach(var s in world.Snakes){var v=snakes[s.Id];v.model=s;v.motion=new NativeLiveSnake(s,time);}
   for(int pi=0;pi<world.PlayerCount;pi++){var p=world.GetPlayer(pi);var player=actors[p.Id];player.aura.Reset(Bank(p.Dir),time);player.art.Palette=new[]{"p1","p2","ai"}[p.Palette];player.blink=new BlinkClock((uint)(p.Id*9721),time+900);player.renderer.enabled=!p.Dead;}
   var generated=TakePreparedMaze();InstallMazeArt(generated);generated.DisposeStaging();neon.SetVisible(true);
   dusk.Render(world.Player.Cell,world.Player.Dir,0,false,true);biteInitial=.4;pendingCaptures.Clear();scenePreparationPending=false;preparationFrames=0;discardPreparationDelta=false;nextSceneHits++;
   NativeStallTrace.Add("next-ready-install",stamp);return true;
  }
 }
}

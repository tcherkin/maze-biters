using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using UnityEngine;
namespace MazeBiters.NativeStudy {
 // Timing is opt-in. Absolute milestones use Unity's clock; stage durations
 // use Stopwatch, including the original CPU map worker on another thread.
 public static class NativeStartupLoading {
  public static readonly bool Enabled=Array.IndexOf(Environment.GetCommandLineArgs(),"--legacy-startup-loading")<0;
  public static readonly bool Assets=Enabled&&Array.IndexOf(Environment.GetCommandLineArgs(),"--legacy-startup-assets")<0;
  public static readonly bool Trace=Array.IndexOf(Environment.GetCommandLineArgs(),"--startup-loading-probe")>=0;
  [Serializable] public sealed class Stage {public string name;public int calls;public double totalMs,maxMs;}
  [Serializable] public sealed class Milestone {public string name;public double ms;}
  [Serializable] sealed class Report {public bool optimized,focused;public string note;public double readyMs,cpuMs;public long working,peak,privateBytes,unityUsed,unityReserved,monoHeap;public Stage[] stages;public Milestone[] milestones;}
  static readonly object gate=new object();static readonly Dictionary<string,Stage> stages=new Dictionary<string,Stage>();static readonly List<Milestone> marks=new List<Milestone>();
  public static long Stamp()=>Trace?System.Diagnostics.Stopwatch.GetTimestamp():0;
  public static void Add(string name,long start){if(start==0)return;AddMs(name,(System.Diagnostics.Stopwatch.GetTimestamp()-start)*1000.0/System.Diagnostics.Stopwatch.Frequency);}
  public static void AddMs(string name,double ms){if(!Trace)return;lock(gate){if(!stages.TryGetValue(name,out var s))stages.Add(name,s=new Stage{name=name});s.calls++;s.totalMs+=ms;s.maxMs=Math.Max(s.maxMs,ms);}}
  public static int StageCalls(string name){lock(gate)return stages.TryGetValue(name,out var stage)?stage.calls:0;}
  public static void Mark(string name){if(Trace)lock(gate)marks.Add(new Milestone{name=name,ms=Time.realtimeSinceStartupAsDouble*1000});}
  static System.Threading.Tasks.Task ai;
  [RuntimeInitializeOnLoadMethod(RuntimeInitializeLoadType.BeforeSplashScreen)]static void BeforeSplash(){
#if UNITY_WEBGL && !UNITY_EDITOR
   return;
#endif
   Mark("before splash");NativeMenuBoot.Prepare();if(!NativeGameplayStudy.QueueBootMaze()||!Assets)return;
   string reference=Path.Combine(WebFiles.Root,"Reference");
   ai=WebWorkQueue.Run(()=>{long start=Stamp();NativeAllyValidation.Prepare(reference);Add("AI CPU worker",start);if(NativeSmoothLoading.Enabled)NativeLogicCpuPreparation.Run(reference);});
  }
  internal static System.Collections.Generic.IEnumerable<object> WaitForCpu(){
   if(ai==null)yield break;while(!ai.IsCompleted)yield return "wait";ai.GetAwaiter().GetResult();ai=null;Mark("AI CPU preparation adopted");
  }
  public static void Save(string path){if(!Trace)return;Mark("all modes ready");NativeMemory.TryRead(out var working,out var peak,out var committed);double cpu;using(var p=System.Diagnostics.Process.GetCurrentProcess())cpu=p.TotalProcessorTime.TotalMilliseconds;
   lock(gate)File.WriteAllText(Path.Combine(Path.GetDirectoryName(path),"startup.json"),JsonUtility.ToJson(new Report{optimized=Enabled,focused=Application.isFocused,readyMs=Time.realtimeSinceStartupAsDouble*1000,cpuMs=cpu,working=working,peak=peak,privateBytes=committed,unityUsed=UnityEngine.Profiling.Profiler.GetTotalAllocatedMemoryLong(),unityReserved=UnityEngine.Profiling.Profiler.GetTotalReservedMemoryLong(),monoHeap=UnityEngine.Profiling.Profiler.GetMonoHeapSizeLong(),stages=stages.Values.OrderByDescending(s=>s.totalMs).ToArray(),milestones=marks.ToArray(),note="Worker stages overlap main-thread stages; totals are not additive. CPU is whole-process time to readiness, not one-core percentage. Unity clock excludes process time before engine timing starts."},true));
  }
 }
}

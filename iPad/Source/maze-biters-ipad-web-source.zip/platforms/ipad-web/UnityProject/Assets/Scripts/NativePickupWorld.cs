using System;using System.Collections.Generic;using System.Linq;using UnityEngine;
namespace MazeBiters.NativeStudy {
 public sealed class NativeFruit {public Vector2Int Cell;public int Kind;public double Born;}
 public sealed class NativeEgg {public Vector2Int Cell;public double Born;public int CrackStage;}
 public sealed class NativeDrop {public Vector2Int Cell;public bool Egg;public int Kind;public double Ready;}
 public sealed partial class NativeGameplayWorld {
  public readonly List<NativeFruit> Fruits=new List<NativeFruit>();
  public readonly List<NativeEgg> Eggs=new List<NativeEgg>();
  public readonly List<NativeDrop> PendingDrops=new List<NativeDrop>();
  public bool LifecycleEnabled,ScorpionKilled;public double ScorpionSpawnAt=double.PositiveInfinity;public int StartingSnakeMass=1,HunterColorIndex;int nextHunter=1000,eggTopology;
  public bool Power=>Player.PowerUntil>Time;
  public bool CombatPower=>Power||Player.ShieldUntil>Time;
  public bool Repels(Vector2Int cell){var p=PlayerAt(cell);return p!=null&&(p.PowerUntil>Time||p.ShieldUntil>Time);}
  public double PowerStrength {
   get{var p=Player;if(!Power)return 0;double elapsed=Math.Max(0,Time-p.RampAt),duration=Math.Max(1,p.RampDuration==0?1000:p.RampDuration);
    if(elapsed<duration){double u=elapsed/duration;return p.RampFrom+(1-p.RampFrom)*(1-(1-u)*(1-u));}
    double left=Math.Max(0,p.PowerUntil-Time);if(left<3000){double u=left/3000;return 1-(1-u)*(1-u);}return 1;}
  }
  public double PlayerDelay=>95/(1+PowerStrength);
  public void ActivatePower(){var p=Player;bool powered=Power;double remaining=powered?p.PowerUntil-Time:0,strength=powered?PowerStrength:0;bool ramping=powered&&Time<p.RampAt+p.RampDuration;
   if(!powered){p.PowerStarted=p.RampAt=Time;p.RampDuration=1000;p.RampFrom=0;}
   else if(remaining<3000){p.RampAt=Time;p.RampDuration=1000;p.RampFrom=strength;}
   else if(!ramping){p.RampAt=Time;p.RampDuration=0;p.RampFrom=1;}
   p.PowerUntil=Time+7000;p.WarningAt=0;p.PowerBright=true;p.FlashAt=Time;
   // Original activatePowerMode plays this on every fruit, including refreshes.
   // The PCM is already prepared before gameplay; no resource load occurs here.
   Sound("snakeSTART@",p.Cell);
  }
  public void UpdatePower(){var p=Player;if(!Power){p.PowerStarted=p.RampAt=p.RampDuration=p.RampFrom=p.PowerUntil=p.WarningAt=0;p.PowerBright=false;return;}
   if(p.PowerUntil-Time>3000){p.WarningAt=0;p.PowerBright=true;p.FlashAt=Time;return;}
   if(p.WarningAt==0){p.WarningAt=p.FlashAt=Time;p.PowerBright=false;PickupEvent("powerWarning");return;}
   if(Time-p.FlashAt>=320){p.PowerBright=!p.PowerBright;p.FlashAt=Time;PickupEvent("powerWarning");}
  }
  void PickupEvent(string kind,Vector2Int cell=default,int index=0,NativeHunter hunter=null,double duration=0){SessionEffect(kind,cell);Event?.Invoke(new NativeWorldEvent{Player=Player,Kind=kind,Cell=cell,Index=index,Hunter=hunter,Time=Time,Duration=duration});}
  public void CharacterBite(double duration){Player.BiteAt=Time+.35*Math.Max(0,Player.MoveDuration);Player.BiteEnd=Player.BiteAt+duration;PickupEvent("characterBite",duration:duration);}
  public void CollectFruit(){for(int i=Fruits.Count-1;i>=0;i--){var f=Fruits[i];if(f.Cell!=Player.Cell)continue;CharacterBite(85);PickupEvent("fruit",f.Cell,f.Kind);Award(new[]{50,100,150,200}[Math.Max(0,Math.Min(3,f.Kind))]);if(Multiplayer)Player.Contribution+=.35;Fruits.RemoveAt(i);ActivatePower();}}
  public void EatHunter(NativeHunter h){if(!Hunters.Remove(h))return;CharacterBite(140);PickupEvent("hunterBite",h.Cell,h.Palette,h);Award(200);if(Multiplayer)Player.Contribution+=.5;}
  public void PowerEatHead(NativeGameplaySnake s){int si=Snakes.IndexOf(s);if(si<0||s.Body.Count==0)return;var old=s.Body.ToArray();var parts=Fragments(s,0);
   if(parts.Count==0){Snakes.RemoveAt(si);Emit("head",s,old,0);Ally.Completed(Player,s);}
   else {var f=parts[0];var child=new NativeGameplaySnake{Id=nextId++,Body=f.body,Dir=f.dir,Palette=s.Palette,Temperament=s.Temperament,TurnBias=Random(),Anger=s.Anger+2,AngerPeak=Math.Max(s.AngerPeak,s.Anger+2),AngerFloor=Math.Max(s.AngerFloor,(s.Anger+2)*.5),LastAnger=Time,LastMemory=s.LastMemory,Threat=s.Threat+2,LastMove=0};Array.Copy(s.PersonalThreat,child.PersonalThreat,s.PersonalThreat.Length);Provoke(child,2,false);child.Cell=child.Head;Snakes[si]=child;Ally.Completed(Player,s,child);Emit("split",s,old,0,new List<NativeGameplaySnake>{child});}
   Award(125);if(Multiplayer)Player.Contribution+=parts.Count==0?1:2; // Existing split/head presentation owns its visual clock.
   Player.BiteAt=Time+Math.Min(33.25,Player.MoveDuration*.35);Player.BiteEnd=Player.BiteAt+(parts.Count==0?140:95);CheckLevelComplete();
  }
  public bool EggCovered(NativeEgg e){for(int i=0;i<PlayerCount;i++)if(GetPlayer(i).Cell==e.Cell&&(!Multiplayer||!GetPlayer(i).HideDeath))return true;return Occupied(e.Cell)||ScorpionAt(e.Cell)||HunterAt(e.Cell)||Fruits.Any(f=>f.Cell==e.Cell);}
  public void RefreshEggTopology(){int hash=17;foreach(var e in Eggs)if(Time-e.Born>=10000&&!EggCovered(e))unchecked{hash=hash*31+Index(e.Cell);}if(hash!=eggTopology){eggTopology=hash;ObstacleRevision++;}}
  public void UpdateEggs(){for(int i=Eggs.Count-1;i>=0;i--){var e=Eggs[i];double age=Time-e.Born;if(age>=10000&&EggCovered(e)){e.Born=Time-9999;ObstacleRevision++;age=9999;}
   int stage=age>=12000?3:age>=11000?2:age>=10000?1:0;if(stage>e.CrackStage){for(int n=e.CrackStage;n<stage;n++)PickupEvent("eggCrack",e.Cell,n+1);e.CrackStage=stage;}
   if(age<13000)continue;var h=new NativeHunter{Id=nextHunter++,Cell=e.Cell,From=e.Cell,Dir=Dirs[(int)(Random()*Dirs.Length)],Palette=HunterColorIndex++%3,LastMove=Time,MoveStarted=Time,MoveDuration=95,MotherAlive=true,Anger=.45};Hunters.Add(h);Eggs.RemoveAt(i);ObstacleRevision++;PickupEvent("hatch",e.Cell,h.Palette,h);
  }RefreshEggTopology();}
  public double ScorpionRate=>1+Math.Min(9,Math.Max(0,Level-1))/9.0;
  public double TimePressure {get{if(!UseLegacyAi){var tuning=NativeDifficulty.For(Difficulty,Level);double ageNow=Math.Max(0,Time-LevelStarted);double ramp=Math.Max(0,Math.Min(1,(ageNow-60000)/180000));return 1+(tuning.MaxTimePressure-1)*ramp;}double age=Math.Max(0,Time-LevelStarted)*Difficulty,adjusted=1+(Math.Max(1,Level)-1)*Difficulty,p=Math.Max(0,Math.Min(1,(adjusted-10)/90)),calm=30000-25000*p,rise=15000-12000*p;if(age<=calm)return 1;double progress=Math.Max(0,Math.Min(1,(age-calm)/Math.Max(1,rise)));return progress<1?1+progress:2+(age-calm-rise)/(150000-90000*p);}}
  public double DepletionPressure=>1+Math.Max(0,Math.Min(1,1-Snakes.Sum(s=>s.Body.Count)/(double)Math.Max(1,StartingSnakeMass)))*(UseLegacyAi?1.25:NativeDifficulty.For(Difficulty,Level).DepletionBoost);
  public double ScorpionDelay(double low,double high)=>(low+Random()*(high-low))/ScorpionRate;
  public double PressureDelay(double low,double high)=>ScorpionDelay(low,high)/(TimePressure*DepletionPressure*Difficulty);
  public void EnableLifecycle(){LifecycleEnabled=true;StartingSnakeMass=Math.Max(1,Snakes.Sum(s=>s.Body.Count));ScorpionSpawnAt=Time+PressureDelay(15000,30000);if(Scorpion!=null)ScheduleDrops(Scorpion);}
  public void ScheduleDrops(NativeScorpion s){s.NextFruit=Time+ScorpionDelay(18000,30000);s.NextEgg=Time+PressureDelay(30000,60000);}
  bool SpawnClear(Vector2Int c)=>Floor(c)&&PlayerAt(c)==null&&!Occupied(c)&&!HunterAt(c)&&!Eggs.Any(e=>e.Cell==c)&&!Fruits.Any(f=>f.Cell==c);
  public void SpawnScorpion(){for(int n=0;n<500;n++){var cell=new Vector2Int(1+(int)(Random()*(Width-2)),1+(int)(Random()*(Height-2)));if(!SpawnClear(cell))continue;var options=Dirs.Where(d=>SpawnClear(cell-d)).ToArray();if(options.Length==0)continue;var direction=options[(int)(Random()*options.Length)];var s=PlaceScorpion(cell,direction);ScorpionKilled=false;ScheduleDrops(s);PickupEvent("scorpionSpawn",cell);return;}ScorpionSpawnAt=Time+1000;}
  public void QueueScorpionDrops(Vector2Int oldTail,bool snap){var s=Scorpion;if(!LifecycleEnabled||s==null)return;double ready=Time+(snap?0:218*.55);
   if(Time>=s.NextFruit){PendingDrops.Add(new NativeDrop{Cell=oldTail,Kind=(int)(Random()*4),Ready=ready});s.NextFruit=Time+ScorpionDelay(18000,30000);}
   if(Time>=s.NextEgg){PendingDrops.Add(new NativeDrop{Cell=oldTail,Egg=true,Ready=ready});s.NextEgg=Time+PressureDelay(30000,50000)*2;}
  }
  public void ReleaseDrops(){for(int i=PendingDrops.Count-1;i>=0;i--){var d=PendingDrops[i];if(Time<d.Ready)continue;if(!Eggs.Any(e=>e.Cell==d.Cell)&&!Fruits.Any(f=>f.Cell==d.Cell)){if(d.Egg){Eggs.Add(new NativeEgg{Cell=d.Cell,Born=Time});ObstacleRevision++;PickupEvent("eggDrop",d.Cell);}else{Fruits.Add(new NativeFruit{Cell=d.Cell,Kind=d.Kind,Born=Time});PickupEvent("fruitDrop",d.Cell,d.Kind);}}PendingDrops.RemoveAt(i);}}
 }
}

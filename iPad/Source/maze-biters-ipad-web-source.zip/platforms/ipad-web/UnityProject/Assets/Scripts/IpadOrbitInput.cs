using System;
using UnityEngine;

namespace MazeBiters.NativeStudy {
 public enum IpadOrbitSource { Keyboard, Gamepad, Touch, Pointer }
 public enum IpadTouchStyle { Orbit, LegacySwipe }

 // Presentation uses display pixels, with a bottom-up origin and down-positive
 // displacement/angles. The world continues to receive its original held keys.
 public sealed class IpadOrbitPad {
  public int FingerId=-1,Direction=-1;
  public Vector2 Center,ThumbOffset;
  public float Radius,Alpha,LightAngle,LightStrength;
  public bool Held;
  internal bool Seen,KeysOwned;
  internal int LightDirection=-1;
  internal float LightTarget,LightVelocity,Turn=1,LevelFrom,LevelTo,LevelTime=.15f;
 }

 public sealed class IpadOrbitInput {
  public const float ThumbRatio=(128f*.26f+120f*.52f)/2f/120f,Opacity=.64f;
  const float Step=Mathf.PI/4f;
  static readonly int[] DirectionMasks={2,10,8,9,1,5,4,6};
  static readonly Vector2Int[] Directions={Vector2Int.left,Vector2Int.right,new Vector2Int(0,-1),new Vector2Int(0,1)};
  static readonly string[,] Keys={{"ipad-orbit-0-left","ipad-orbit-0-right","ipad-orbit-0-up","ipad-orbit-0-down"},{"ipad-orbit-1-left","ipad-orbit-1-right","ipad-orbit-1-up","ipad-orbit-1-down"}};
  readonly IpadOrbitSource[] sources={IpadOrbitSource.Keyboard,IpadOrbitSource.Keyboard};
  public readonly IpadOrbitPad[] Pads={new IpadOrbitPad(),new IpadOrbitPad()};
  NativeGameplayWorld world;
  int width,height;
  bool active;
  public bool Duo {get;private set;}
  public bool HasHeldTouch=>Pads[0].Held||Pads[1].Held;
  public IpadOrbitSource SourceFor(int slot)=>slot>=0&&slot<2?sources[slot]:IpadOrbitSource.Keyboard;
  public static float DisplayScale(int width,int height)=>Mathf.Max(.65f,Mathf.Min(width/736f,height/552f));
  public static int MaskForDirection(int direction)=>direction>=0&&direction<8?DirectionMasks[direction]:0;
  public static float ThumbTravel(float radius)=>Mathf.Max(0,radius*(1-ThumbRatio)-Mathf.Max(5f*radius/60f,radius*.08f));
  NativePlayer Human(int slot)=>world!=null&&slot>=0&&slot<world.PlayerCount&&!world.GetPlayer(slot).IsAI?world.GetPlayer(slot):null;
  bool Eligible(int slot){var p=Human(slot);return active&&p!=null&&!p.Dead&&p.Lives>0&&!p.Eliminated;}
  public bool DeviceActive(int slot,IpadOrbitSource source)=>Eligible(slot)&&SourceFor(slot)==source;

  public void BeginFrame(NativeGameplayWorld next,int displayWidth,int displayHeight,bool enabled){
   if(!ReferenceEquals(world,next)){ClearImmediately();world=next;sources[0]=sources[1]=IpadOrbitSource.Keyboard;}
   if(width!=displayWidth||height!=displayHeight){ClearImmediately();width=displayWidth;height=displayHeight;}
   active=enabled&&world!=null&&!world.GameOver&&!world.Transition;
   Duo=Human(1)!=null;
   float radius=60f*DisplayScale(width,height);
   for(int slot=0;slot<2;slot++){var pad=Pads[slot];pad.Seen=false;pad.Radius=radius;if(!Eligible(slot))CancelSlot(slot);}
  }

  public void Touch(int fingerId,Vector2 position,TouchPhase phase){
   int slot=-1;
   for(int i=0;i<2;i++)if(Pads[i].FingerId==fingerId){slot=i;break;}
   if(phase==TouchPhase.Began){
    if(slot>=0)CancelSlot(slot);
    slot=Duo&&position.x>=width*.5f?1:0;
    if(!Eligible(slot)||Pads[slot].Held)return;
    var pad=Pads[slot];pad.FingerId=fingerId;pad.Center=position;pad.ThumbOffset=Vector2.zero;pad.Direction=-1;pad.Held=true;pad.Seen=true;
    sources[slot]=IpadOrbitSource.Touch;
    return;
   }
   if(slot<0)return;
   if(phase==TouchPhase.Ended||phase==TouchPhase.Canceled){CancelSlot(slot);return;}
   var p=Pads[slot];p.Seen=true;
   if(!Eligible(slot)||sources[slot]!=IpadOrbitSource.Touch){CancelSlot(slot);return;}
   var offset=new Vector2(position.x-p.Center.x,p.Center.y-position.y);
   float length=offset.magnitude,travel=ThumbTravel(p.Radius);
   p.ThumbOffset=length>travel?offset*(travel/length):offset;
   if(length<=(p.Direction<0?p.Radius*.18f:p.Radius*.12f)){p.Direction=-1;return;}
   float angle=Mathf.Atan2(offset.y,offset.x);
   int direction=((Mathf.FloorToInt((angle+Step*.5f)/Step)%8)+8)%8;
   if(p.Direction<0||Mathf.Abs(Wrap(angle-p.Direction*Step))>Step*.5f+5f*Mathf.Deg2Rad)p.Direction=direction;
  }

  public void EndFrame(float unscaledSeconds){
   for(int slot=0;slot<2;slot++){var p=Pads[slot];if(p.Held&&!p.Seen)CancelSlot(slot);SyncKeys(slot);}
   AdvanceVisual(unscaledSeconds);
  }
  public void ClaimExternal(int slot,IpadOrbitSource source){
   if(slot<0||slot>=2||source==IpadOrbitSource.Touch||!Eligible(slot))return;
   CancelSlot(slot);sources[slot]=source;
  }
  public void CancelAll(){for(int slot=0;slot<2;slot++)CancelSlot(slot);}
  // Disabled/cached scenes and suspended apps cannot finish a fade. Do not carry
  // the last cursor, highlight or spring velocity into their next visible frame.
  public void ClearImmediately(){
   CancelAll();
   for(int slot=0;slot<2;slot++){var p=Pads[slot];p.Center=p.ThumbOffset=Vector2.zero;
    p.Alpha=p.LightAngle=p.LightStrength=p.LightTarget=p.LightVelocity=p.LevelFrom=p.LevelTo=0;
    p.LightDirection=-1;p.Turn=1;p.LevelTime=.15f;
   }
  }
  void CancelSlot(int slot){var p=Pads[slot];p.Held=false;p.FingerId=-1;p.Direction=-1;p.Seen=false;ReleaseKeys(slot);}
  void ReleaseKeys(int slot){var pad=Pads[slot];if(!pad.KeysOwned)return;pad.KeysOwned=false;var player=world!=null&&slot<world.PlayerCount?world.GetPlayer(slot):null;if(player==null)return;using(world.ForPlayer(player))for(int i=0;i<4;i++)world.Release(Keys[slot,i]);}
  void SyncKeys(int slot){
   var p=Human(slot);if(p==null)return;
   int desired=DeviceActive(slot,IpadOrbitSource.Touch)&&Pads[slot].Held?MaskForDirection(Pads[slot].Direction):0;
   if(desired==0&&!Pads[slot].KeysOwned)return;
   using(world.ForPlayer(p)){
    for(int i=0;i<4;i++)if((desired&(1<<i))==0)world.Release(Keys[slot,i]);
    for(int i=0;i<4;i++)if((desired&(1<<i))!=0&&!p.Keys.ContainsKey(Keys[slot,i]))world.Press(Keys[slot,i],Directions[i]);
   }Pads[slot].KeysOwned=desired!=0;
  }

  static float Wrap(float angle)=>Mathf.Atan2(Mathf.Sin(angle),Mathf.Cos(angle));
  public void AdvanceVisual(float seconds){
   float dt=Mathf.Max(0,Mathf.Min(seconds,.05f));
   for(int i=0;i<2;i++){
    var p=Pads[i];p.Alpha=Mathf.MoveTowards(p.Alpha,p.Held?1:0,dt/(p.Held?.08f:.17f));
    bool lit=p.Direction>=0&&p.Held;
    int direction=lit?p.Direction:-1;
    if(direction!=p.LightDirection){
     if(lit){float delta=Wrap(direction*Step-p.LightAngle);if(Mathf.Abs(Mathf.Abs(delta)-Mathf.PI)<.0001f)delta=Mathf.PI*(Mathf.Abs(p.LightVelocity)>.01f?Mathf.Sign(p.LightVelocity):p.Turn);
      if(p.LightStrength<.001f){p.LightAngle=p.LightTarget=direction*Step;p.LightVelocity=0;}
      else{p.LightTarget=p.LightAngle+delta;if(Mathf.Abs(delta)>.001f)p.Turn=Mathf.Sign(delta);}
     }else{p.LightTarget=p.LightAngle;p.LightVelocity=0;}
     p.LightDirection=direction;
    }
    float to=lit?1:0;if(to!=p.LevelTo){p.LevelFrom=p.LightStrength;p.LevelTo=to;p.LevelTime=0;}
    p.LevelTime=Mathf.Min(.15f,p.LevelTime+dt);float t=p.LevelTime/.15f;p.LightStrength=Mathf.Lerp(p.LevelFrom,p.LevelTo,t*t*(3-2*t));
    float omega=1f/.055f,x=p.LightAngle-p.LightTarget,c=p.LightVelocity+omega*x,decay=Mathf.Exp(-omega*dt),next=(x+c*dt)*decay;
    p.LightAngle=p.LightTarget+next;p.LightVelocity=(p.LightVelocity-omega*c*dt)*decay;
    if(x*next<0||(Mathf.Abs(next)<.0015f&&Mathf.Abs(p.LightVelocity)<.025f)){p.LightAngle=p.LightTarget;p.LightVelocity=0;}
   }
  }
 }
}

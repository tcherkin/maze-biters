using System;using System.IO;using UnityEngine;
namespace MazeBiters.NativeStudy {
 [Serializable] public class BenchSnake {public double head,length,compression,phase,frontMaterial;}
 [Serializable] public class BenchFrame {public double time,lightAngle;public Vector2 player;public int palette,direction,mouth,blink;public TurnPose turn;public BenchSnake[] snakes;}
 [Serializable] public class BenchRoute {public Vector2Int[] cells;}
 [Serializable] public class BenchTrace {public string scope="Matched rendering only; poses shared, no AI/contacts/audio/HUD";public double stepMs=1000.0/120;public BenchRoute[] routes;public BenchFrame[] frames;}
 [Serializable] public class BenchResult {public string backend="Unity D3D11",quality,device,note,rendererMode;public RenderProfileResult profile;public int frames,width,height;public double elapsedMs,cpuProcessMs;public long workingSetBytes,privateCommittedBytes,peakWorkingSetBytes,managedBytes,textureBytes,targetBytes;public bool focused;public double[] frameMs,submitMs;}
 public static class SceneBenchmark {
  public static BenchTrace Export(NativeSnakeStudy study,string file){
   var trace=new BenchTrace{routes=new BenchRoute[5],frames=new BenchFrame[1440]};for(int i=0;i<5;i++)trace.routes[i]=new BenchRoute{cells=study.Routes[i]};
   var turn=new NativeTurnClock();var blink=new BlinkClock(0xB17E2026,900);int direction=0;double angle=0;
   var route=study.Routes[0];int span=Math.Min(24,route.Length-1);
   for(int k=0;k<trace.frames.Length;k++){
    double time=k*trace.stepMs,step=time/95;int whole=(int)step,cycle=whole%(span*2);int a=cycle<span?cycle:2*span-cycle,b=cycle<span?a+1:a-1;double phase=step-whole;
    var delta=route[b]-route[a];int next=Array.IndexOf(NativeLevelStudy.Directions,delta);if(next!=direction){turn.Request(direction,next,time);direction=next;}
    double desired=Math.Atan2(delta.y,delta.x);angle+=Math.Atan2(Math.Sin(desired-angle),Math.Cos(desired-angle))*(1-Math.Exp(-trace.stepMs/65));
    double walking=AnimationClock.Mouth(phase*95,95),biteAt=Math.Floor(time/1400)*1400+900;
    var f=new BenchFrame{time=time,player=Vector2.Lerp(route[a],route[b],(float)phase),direction=direction,turn=turn.Sample(time,direction),lightAngle=angle,palette=Math.Min(5,k/240),mouth=AnimationClock.Frame(AnimationClock.Bite(time,biteAt,biteAt+140,.34,walking),48),blink=AnimationClock.Frame(blink.Sample(time),24),snakes=new BenchSnake[5]};
    study.Update(time);for(int i=0;i<5;i++){var p=study.Poses[i];f.snakes[i]=new BenchSnake{head=p.head,length=p.length,compression=p.compression,phase=p.phase,frontMaterial=p.frontMaterial};}trace.frames[k]=f;
   }
   Directory.CreateDirectory(Path.GetDirectoryName(Path.GetFullPath(file)));File.WriteAllText(file,JsonUtility.ToJson(trace));return trace;
  }
 }
}

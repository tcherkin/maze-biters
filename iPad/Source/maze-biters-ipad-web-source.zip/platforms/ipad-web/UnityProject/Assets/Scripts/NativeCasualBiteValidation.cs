#if UNITY_EDITOR
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using UnityEngine;

namespace MazeBiters.NativeStudy {
 [Serializable] public sealed class NativeCasualBiteReport {
  public bool passed;public int assertions,failures,decisions;public double elapsedMs;public string scope;
  public List<NativeDifficultyCheck> checks=new List<NativeDifficultyCheck>();
 }
 // Local encounter regressions call the actual planner and contact rules.
 // They do not measure human win rate, rendering or physical iPad performance.
 public static class NativeCasualBiteValidation {
  static readonly Vector2Int Right=Vector2Int.right,Up=new Vector2Int(0,-1),Down=new Vector2Int(0,1);
  static string[] Grid(bool open=false,bool crossing=false){
   var rows=new char[11][];for(int y=0;y<11;y++){rows[y]=new string('#',15).ToCharArray();for(int x=1;x<14;x++)if(y>0&&y<10&&(open||y==5||crossing&&x==7))rows[y][x]='.';}return rows.Select(r=>new string(r)).ToArray();
  }
  static NativeGameplayWorld World(int difficulty,bool meal=false,bool open=false,bool crossing=false,int mode=0){
   var w=new NativeGameplayWorld(Grid(open,crossing),()=>.99){AiDifficulty=difficulty,Difficulty=NativeMazeGenerator.Difficulties[difficulty],Time=1000,LevelStarted=1000,Assist=false,SessionEnabled=true};w.SetMode(mode);
   for(int i=0;i<w.PlayerCount;i++){var actor=w.GetPlayer(i);actor.Cell=actor.From=actor.Previous=new Vector2Int(2+i,5);actor.Dir=actor.Next=Right;actor.Score=0;actor.Waiting=false;}
   var p=w.GetPlayer(w.PlayerCount-1);p.Cell=p.From=p.Previous=new Vector2Int(6,5);p.Dir=p.Next=Right;p.Score=200;p.ExactScore=200;
   w.Ally.BeginLevel();p.Ai.mealInitialized=true;p.Ai.mealActive=meal;p.Ai.mealIntentUntil=10000;p.Ai.allowSplit=false;return w;
  }
  static NativePlayer Ai(NativeGameplayWorld w)=>w.GetPlayer(w.PlayerCount-1);
  static NativeGameplaySnake AddSnake(NativeGameplayWorld w,IEnumerable<Vector2Int> cells,Vector2Int direction){var body=cells.ToList();var s=new NativeGameplaySnake{Id=10+w.Snakes.Count,Cell=body[0],Dir=direction,Body=body,Temperament=.5};w.Snakes.Add(s);return s;}
  static NativeGameplaySnake Tail(NativeGameplayWorld w)=>AddSnake(w,new[]{new Vector2Int(10,5),new Vector2Int(9,5),new Vector2Int(8,5),new Vector2Int(7,5)},Right);
  static NativeGameplaySnake Crossing(NativeGameplayWorld w)=>AddSnake(w,Enumerable.Range(2,7).Select(y=>new Vector2Int(7,y)),Up);
  static void Check(NativeCasualBiteReport r,bool passed,string name,string detail=""){r.assertions++;if(!passed)r.failures++;r.checks.Add(new NativeDifficultyCheck{name=name,passed=passed,detail=detail});}
  static void Group(NativeCasualBiteReport r,string name,Action body){try{body();}catch(Exception e){Check(r,false,name+" completed",e.ToString());}}
  static void Plan(NativeCasualBiteReport r,NativeGameplayWorld w){w.Ally.Plan(Ai(w),w.Time);r.decisions++;}
  static void Advance(NativeGameplayWorld w){using(w.ForPlayer(Ai(w)))w.AdvancePlayer();}
  static bool Awarded(NativeGameplayWorld w,double before,int raw){var p=Ai(w);double expected=before+raw*w.Difficulty*w.ScoreSpeed;return Math.Abs(p.ExactScore-expected)<1e-9&&p.Score==(int)(Math.Floor((expected+1e-9)/5)*5);}
  static void ImmediateEncounters(NativeCasualBiteReport r){
   foreach(int difficulty in new[]{0,1})foreach(bool meal in new[]{false,true}){
    string label="tier="+difficulty+", meal="+meal;
    {
     var w=World(difficulty,meal);var p=Ai(w);var s=Tail(w);int score=p.Score;Plan(r,w);
     Check(r,p.Next==Right,"A safe forward tail is accepted instead of a corridor reversal: "+label,"next="+p.Next+", thought="+p.Ai.thought);Advance(w);
     Check(r,!p.Dead&&p.Cell==new Vector2Int(7,5)&&Awarded(w,score,25)&&s.Body.Count==3,"Forward tail choice resolves through normal eating and score: "+label);
     Check(r,p.Ai.locked==null&&p.Ai.split==null&&p.Ai.queue.Count==0&&!p.Ai.mealActive,"A local tail bite does not start automatic snake cleanup: "+label);
    }
    {
     var w=World(difficulty,meal,crossing:true);var p=Ai(w);var s=Crossing(w);int score=p.Score,mass=s.Body.Count;Plan(r,w);
     Check(r,p.Next==Right,"A safe body crossing ignores the strategic split-interest veto: "+label,"next="+p.Next+", thought="+p.Ai.thought);Advance(w);
     Check(r,!p.Dead&&p.Cell==new Vector2Int(7,5)&&Awarded(w,score,10)&&!w.Snakes.Contains(s)&&w.Snakes.Count==2&&w.Snakes.Sum(x=>x.Body.Count)==mass-1,"Incidental split uses genuine fragment and scoring rules: "+label);
     Check(r,p.Ai.locked==null&&p.Ai.split==null&&p.Ai.queue.Count==0&&!p.Ai.mealActive,"An incidental split does not lock onto either fragment: "+label);
     p.Ai.allowSplit=true;p.Ai.mealActive=true;p.Ai.locked=w.Snakes[0];w.Ally.BeginLevel();
     Check(r,p.Ai.locked==null&&p.Ai.queue.Count==0&&!p.Ai.mealInitialized&&!p.Ai.allowSplit.HasValue,"A new level discards temporary meal and incidental-target state: "+label);
    }
   }
  }
  static void SideEncounter(NativeCasualBiteReport r){
   foreach(int difficulty in new[]{0,1}){
    var w=World(difficulty,open:true);var p=Ai(w);p.Dir=p.Next=Up;Tail(w);int score=p.Score;Plan(r,w);
    Check(r,p.Next==Right,"An adjacent safe side-tail remains a possible casual bite: tier="+difficulty,"next="+p.Next+", thought="+p.Ai.thought);Advance(w);
    Check(r,!p.Dead&&Awarded(w,score,25),"Side-tail decision reaches the ordinary bite rule: tier="+difficulty);
   }
  }
  static void SafetyAndIntent(NativeCasualBiteReport r){
   foreach(int difficulty in new[]{0,1}){
    {
     var w=World(difficulty,open:true);var p=Ai(w);var s=Tail(w);w.Hunters.Add(new NativeHunter{Id=100,Cell=new Vector2Int(7,4),Dir=Down});int score=p.Score;Plan(r,w);
     Check(r,p.Next!=Right,"A hunter about to enter the bite cell overrides casual appetite: tier="+difficulty);Advance(w);
     Check(r,!p.Dead&&p.Score==score&&s.Body.Count==4,"The dangerous tail remains untouched: tier="+difficulty);
    }
    {
     var w=World(difficulty,open:true);var p=Ai(w);AddSnake(w,new[]{new Vector2Int(7,5),new Vector2Int(8,5),new Vector2Int(9,5)},Vector2Int.left);Plan(r,w);int score=p.Score;
     Check(r,p.Next!=Right,"A facing snake head is never treated as a safe incidental body bite: tier="+difficulty);Advance(w);
     Check(r,!p.Dead&&p.Score==score,"Casual appetite preserves head-collision safety: tier="+difficulty);
    }
    {
     var w=World(difficulty,open:true);var p=Ai(w);Tail(w);AddSnake(w,new[]{new Vector2Int(7,4),new Vector2Int(7,3)},Down);Plan(r,w);
     Check(r,p.Next!=Right,"A forecast head step into the bite cell cancels incidental appetite: tier="+difficulty);Advance(w);
     Check(r,!p.Dead&&p.Score==200,"A forecast mouth threat does not cause a speculative bite: tier="+difficulty);
    }
    {
     var w=World(difficulty,open:true);var p=Ai(w);Tail(w);AddSnake(w,new[]{new Vector2Int(7,5),new Vector2Int(7,6),new Vector2Int(7,7)},Up);p.PowerUntil=5000;Plan(r,w);
     Check(r,p.Next!=Right,"Overlapping snakes cannot masquerade as one safe incidental tail even under power: tier="+difficulty);
    }
    {
     var w=World(difficulty);var p=Ai(w);AddSnake(w,new[]{new Vector2Int(2,5),new Vector2Int(3,5),new Vector2Int(4,5),new Vector2Int(5,5)},Vector2Int.left);Plan(r,w);
     Check(r,p.Next==Right,"A safe forward stroll does not reverse to chase food just passed: tier="+difficulty);
    }
    {
     var w=World(difficulty,crossing:true);var p=Ai(w);Crossing(w);w.SolidEggs.Add(new Vector2Int(7,5));w.ObstacleRevision++;Plan(r,w);
     Check(r,p.Next!=Right,"A solid egg blocks a seemingly edible crossing: tier="+difficulty);Advance(w);
     Check(r,!p.Dead&&p.Cell!=new Vector2Int(7,5),"Incidental biting cannot walk through a solid egg: tier="+difficulty);
    }
    {
     var w=World(difficulty,open:true,mode:3);var p=Ai(w);var human=w.GetPlayer(0);human.Cell=human.From=human.Previous=new Vector2Int(6,4);human.Dir=human.Next=Down;human.Score=500;Tail(w);Plan(r,w);
     Check(r,p.Ai.directive?.type=="flee"&&p.Next!=Right,"A genuine stronger-player threat keeps priority over a local snack: tier="+difficulty,"directive="+p.Ai.directive?.type+", next="+p.Next);
    }
    {
     var w=World(difficulty,open:true,mode:3);var p=Ai(w);var human=w.GetPlayer(0);human.Cell=human.From=human.Previous=new Vector2Int(7,5);human.Score=0;Plan(r,w);Advance(w);
     Check(r,!human.Dead&&p.Cell!=human.Cell&&p.Ai.directive==null,"Incidental snake appetite does not add aggression toward an edible human: tier="+difficulty);
    }
    {
     var w=World(difficulty,mode:3);var p=Ai(w);var human=w.GetPlayer(0);human.Cell=human.From=human.Previous=new Vector2Int(7,5);human.Score=500;
     var closed=Grid();for(int y=0;y<closed.Length;y++)closed[y]=new string('#',15);closed[5]="######..#######";w.Grid=closed;w.Ally.BeginLevel();p.Next=Right;Plan(r,w);Advance(w);
     Check(r,p.Waiting&&!p.Dead&&p.Cell==new Vector2Int(6,5),"No safe legal choice waits instead of applying a stale bite direction: tier="+difficulty);
     human.Dead=true;w.Time+=100;Plan(r,w);Advance(w);
     Check(r,!p.Waiting&&!p.Dead&&p.Cell==new Vector2Int(7,5),"A previously blocked AI resumes when the only safe exit opens: tier="+difficulty);
    }
    {
     var empty=World(difficulty,open:true);var distant=World(difficulty,open:true);var p=Ai(distant);AddSnake(distant,new[]{new Vector2Int(11,2),new Vector2Int(11,3),new Vector2Int(11,4)},Up);Plan(r,empty);Plan(r,distant);
     Check(r,p.Next==Ai(empty).Next&&p.Ai.locked==null&&!p.Ai.mealActive&&p.Ai.thought=="casual-roam","A distant snake does not redirect a held casual stroll: tier="+difficulty);
    }
   }
  }
  static void MediumCompatibility(NativeCasualBiteReport r){
   var w=World(2,crossing:true);var p=Ai(w);Crossing(w);Plan(r,w);
   Check(r,p.Next==Vector2Int.left&&p.Ai.thought=="casual-roam"&&!p.Ai.mealActive,"MEDIUM retains its existing held-roam decision in the reference crossing","next="+p.Next+", thought="+p.Ai.thought);
   var late=World(0,crossing:true);late.Time=late.LevelStarted+300000;var ai=Ai(late);Crossing(late);Plan(r,late);
   Check(r,late.DifficultyProfile.Maximum&&ai.Ai.mealActive&&double.IsPositiveInfinity(ai.Ai.mealIntentUntil),"The five-minute maximum still enables its existing full meal intent");
  }
  public static NativeCasualBiteReport Run(){var watch=Stopwatch.StartNew();var r=new NativeCasualBiteReport{scope="Editor-only planner/contact regressions for safe incidental PICNIC/EASY bites. Real Plan and AdvancePlayer methods; no rendered game, device performance or human balance claim."};Group(r,"local encounters",()=>ImmediateEncounters(r));Group(r,"side encounters",()=>SideEncounter(r));Group(r,"safety and held intent",()=>SafetyAndIntent(r));Group(r,"unchanged stronger profiles",()=>MediumCompatibility(r));r.elapsedMs=watch.Elapsed.TotalMilliseconds;r.passed=r.failures==0;return r;}
 }
}
#endif

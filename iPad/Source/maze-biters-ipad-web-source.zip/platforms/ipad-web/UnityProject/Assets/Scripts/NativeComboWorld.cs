using System;
using System.Collections.Generic;
namespace MazeBiters.NativeStudy {
 // Consecutive normal snake meals grant speed and snake-score bonuses only.
 // Never consult this state for protection or permission to consume a creature.
 public sealed class NativeComboState {
  readonly HashSet<int> lineages=new HashSet<int>();
  public bool Active {get;private set;}
  public int SnakeCount=>lineages.Count;
  int exponent;bool consecutiveSnakeMeal;
  public int MultiplierExponent=>Active?exponent:0;
  // The exact exponent remains available to the HUD beyond double's range.
  // Awards saturate safely at the existing signed-int score limit.
  public double ScoreMultiplier=>Math.Pow(2,Math.Min(1023,MultiplierExponent));
  public double LastBiteAt {get;private set;}=double.NegativeInfinity;
  public double LastUpgradeAt {get;private set;}=double.NegativeInfinity;
  double rampAt,rampFrom;
  internal bool StepBite,StepInProgress;
  // Simulation milliseconds: Medium is real time. The existing game-speed
  // clock scales this window once; fruit/combo multipliers never scale it.
  public const double RiseDuration=500,FallDuration=1500,CooldownDuration=1000;
  public double CooldownUntil {get;private set;}=double.PositiveInfinity;
  public bool CoolingDown=>Active&&!double.IsPositiveInfinity(CooldownUntil);
  public bool ActiveAt(double time)=>Active&&time<CooldownUntil;

  double RisingStrength(double time){double u=Math.Min(1,Math.Max(0,time-rampAt)/RiseDuration);return rampFrom+(1-rampFrom)*(1-(1-u)*(1-u));}
  public double StrengthAt(double time){
   if(Active){
    if(time<CooldownUntil)return RisingStrength(time);
    double cooldownDecay=Math.Min(1,Math.Max(0,time-CooldownUntil)/FallDuration);return RisingStrength(CooldownUntil)*(1-cooldownDecay*cooldownDecay);
   }
   double elapsed=Math.Max(0,time-rampAt);
   double down=Math.Min(1,elapsed/FallDuration);return rampFrom*(1-down*down);
  }
  // Forecast the same grace window and decay as live movement, without
  // mutating the player's real clock or renewing an already pending expiry.
  public double StrengthAfterBreakAt(double time,double breakAt){
   if(!Active)return StrengthAt(time);
   double ends=Math.Min(CooldownUntil,breakAt+CooldownDuration);
   if(time<ends)return RisingStrength(time);
   double u=Math.Max(0,Math.Min(1,(time-ends)/FallDuration));return RisingStrength(ends)*(1-u*u);
  }
  public void CopyMotionFrom(NativeComboState source){
   Active=source.Active;rampAt=source.rampAt;rampFrom=source.rampFrom;
   CooldownUntil=source.CooldownUntil;exponent=source.exponent;consecutiveSnakeMeal=false;
   LastBiteAt=source.LastBiteAt;LastUpgradeAt=source.LastUpgradeAt;StepBite=StepInProgress=false;lineages.Clear();
  }
  internal bool Bite(int lineage,double time){
   Advance(time);bool uninterrupted=consecutiveSnakeMeal;
   StepBite=true;consecutiveSnakeMeal=true;LastBiteAt=time;CooldownUntil=double.PositiveInfinity;bool added=lineages.Add(lineage);
   // A resumed meal inside the grace window retains its multiplier. Only a
   // distinct snake on an uninterrupted snake-feeding step upgrades it.
   if(!added||lineages.Count<2||!uninterrupted)return false;
   // New snakes renew the cue and score multiplier, not the smooth speed ramp.
   if(!Active){rampFrom=StrengthAt(time);rampAt=time;Active=true;}
   exponent++;LastUpgradeAt=time;return true;
  }
  public void Advance(double time){if(Active&&time>=CooldownUntil)Break(CooldownUntil);}
  internal void PauseFeeding(double time){
   Advance(time);consecutiveSnakeMeal=false;StepBite=false;
   if(!Active){Break(time);return;}
   if(!CoolingDown)CooldownUntil=time+CooldownDuration;
  }
  internal void SustainWithPickup(double time){
   // A pickup under a snake is part of that same feeding step, not a gap.
   if(StepInProgress&&StepBite&&consecutiveSnakeMeal)return;
   Advance(time);consecutiveSnakeMeal=false;
   if(!Active){Break(time);return;}
   // Refresh, do not accumulate seconds or manufacture a new score tier.
   StepBite=true;CooldownUntil=time+CooldownDuration;
  }
  internal void Break(double time){
   if(Active){rampFrom=StrengthAt(time);rampAt=time;Active=false;}
   exponent=0;consecutiveSnakeMeal=false;CooldownUntil=double.PositiveInfinity;
   lineages.Clear();LastBiteAt=LastUpgradeAt=double.NegativeInfinity;StepBite=false;
  }
  internal void Reset(){Active=false;exponent=0;consecutiveSnakeMeal=false;CooldownUntil=double.PositiveInfinity;rampAt=rampFrom=0;LastBiteAt=LastUpgradeAt=double.NegativeInfinity;lineages.Clear();StepBite=StepInProgress=false;}
 }

 public sealed partial class NativeGameplayWorld {
  public bool ComboActive=>!UseLegacyAi&&Player.Combo.ActiveAt(Time);
  public double ComboStrength=>UseLegacyAi?0:Player.Combo.StrengthAt(Time);
  public static double CombineMovementSpeed(double power,double combo)=>(1+power)*(1+combo);
  public double MovementSpeedMultiplier=>CombineMovementSpeed(PowerStrength,ComboStrength);
  public double MovementStrength=>MovementSpeedMultiplier-1;
  public void BreakCombo(){if(!UseLegacyAi)Player.Combo.Break(Time);}
  public void PauseComboFeeding(){if(!UseLegacyAi)Player.Combo.PauseFeeding(Time);}
  void SustainComboWithPickup(){if(!UseLegacyAi)Player.Combo.SustainWithPickup(Time);}
  public void UpdateCombos(){if(!UseLegacyAi)for(int i=0;i<PlayerCount;i++)GetPlayer(i).Combo.Advance(Time);}
  public void ResetCombo()=>Player.Combo.Reset();
  void ResetAllCombos(){for(int i=0;i<PlayerCount;i++)GetPlayer(i).Combo.Reset();}
  void BeginComboStep(){if(!UseLegacyAi){Player.Combo.Advance(Time);Player.Combo.StepBite=false;Player.Combo.StepInProgress=true;}}
  void EndComboStep(){if(UseLegacyAi)return;Player.Combo.StepInProgress=false;if(Player.Dead||Transition||GameOver||GameOverPending)ResetCombo();else if(!Player.Combo.StepBite)PauseComboFeeding();}
  internal static int ComboLineage(NativeGameplaySnake snake){if(snake.ComboLineageId==0)snake.ComboLineageId=snake.Id;return snake.ComboLineageId;}
  void RegisterComboBite(NativeGameplaySnake snake){
   if(UseLegacyAi||Player.Dead)return;
   // Passive arrivals and diagnostic direct-contact calls cannot create a
   // feeding chain. Only actual consecutive player movement steps qualify.
   if(!Player.Combo.StepInProgress){BreakCombo();return;}
   if(Player.Combo.Bite(ComboLineage(snake),Time)){
    // Publish the visual cue at the same instant as the award/sound. The final
    // head can clear the level (and reset Combo) before the next rendered frame.
    Event?.Invoke(new NativeWorldEvent{Player=Player,Kind="combo",Time=Time});
    Sound("snakeSTART@",Player.Cell);
   }
  }
 }
}

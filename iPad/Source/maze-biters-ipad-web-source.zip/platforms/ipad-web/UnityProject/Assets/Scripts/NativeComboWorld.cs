using System;
using System.Collections.Generic;
namespace MazeBiters.NativeStudy {
 // Consecutive normal snake meals grant speed and snake-score bonuses only.
 // Never consult this state for protection or permission to consume a creature.
 public sealed class NativeComboState {
  readonly HashSet<int> lineages=new HashSet<int>();
  public bool Active {get;private set;}
  public int SnakeCount=>lineages.Count;
  public int MultiplierExponent=>Active?Math.Max(0,lineages.Count-1):0;
  // The exact exponent remains available to the HUD beyond double's range.
  // Awards saturate safely at the existing signed-int score limit.
  public double ScoreMultiplier=>Math.Pow(2,Math.Min(1023,MultiplierExponent));
  public double LastBiteAt {get;private set;}=double.NegativeInfinity;
  public double LastUpgradeAt {get;private set;}=double.NegativeInfinity;
  double rampAt,rampFrom;
  internal bool StepBite,StepInProgress;
  public const double RiseDuration=500,FallDuration=1500;

  public double StrengthAt(double time){
   double elapsed=Math.Max(0,time-rampAt);
   if(Active){double u=Math.Min(1,elapsed/RiseDuration);return rampFrom+(1-rampFrom)*(1-(1-u)*(1-u));}
   double down=Math.Min(1,elapsed/FallDuration);return rampFrom*(1-down*down);
  }
  // Forecasts may assume the combo ends at the next non-food step instead of
  // treating its speed as permanent. Uses Power's curve at twice the pace.
  public double StrengthAfterBreakAt(double time,double breakAt){
   if(!Active||time<breakAt)return StrengthAt(time);
   double u=Math.Max(0,Math.Min(1,(time-breakAt)/FallDuration));return StrengthAt(breakAt)*(1-u*u);
  }
  public void CopyMotionFrom(NativeComboState source){
   Active=source.Active;rampAt=source.rampAt;rampFrom=source.rampFrom;
   LastBiteAt=source.LastBiteAt;LastUpgradeAt=source.LastUpgradeAt;StepBite=StepInProgress=false;lineages.Clear();
  }
  internal bool Bite(int lineage,double time){
   StepBite=true;LastBiteAt=time;bool added=lineages.Add(lineage);
   if(!added||lineages.Count<2)return false;
   // New snakes renew the cue and score multiplier, not the smooth speed ramp.
   if(!Active){rampFrom=StrengthAt(time);rampAt=time;Active=true;}
   LastUpgradeAt=time;return true;
  }
  internal void Break(double time){
   if(Active){rampFrom=StrengthAt(time);rampAt=time;Active=false;}
   lineages.Clear();LastBiteAt=LastUpgradeAt=double.NegativeInfinity;StepBite=false;
  }
  internal void Reset(){Active=false;rampAt=rampFrom=0;LastBiteAt=LastUpgradeAt=double.NegativeInfinity;lineages.Clear();StepBite=StepInProgress=false;}
 }

 public sealed partial class NativeGameplayWorld {
  public bool ComboActive=>!UseLegacyAi&&Player.Combo.Active;
  public double ComboStrength=>UseLegacyAi?0:Player.Combo.StrengthAt(Time);
  public static double CombineMovementSpeed(double power,double combo)=>(1+power)*(1+combo);
  public double MovementSpeedMultiplier=>CombineMovementSpeed(PowerStrength,ComboStrength);
  public double MovementStrength=>MovementSpeedMultiplier-1;
  public void BreakCombo(){if(!UseLegacyAi)Player.Combo.Break(Time);}
  public void ResetCombo()=>Player.Combo.Reset();
  void ResetAllCombos(){for(int i=0;i<PlayerCount;i++)GetPlayer(i).Combo.Reset();}
  void BeginComboStep(){if(!UseLegacyAi){Player.Combo.StepBite=false;Player.Combo.StepInProgress=true;}}
  void EndComboStep(){if(UseLegacyAi)return;Player.Combo.StepInProgress=false;if(Player.Dead||Transition||GameOver||GameOverPending)ResetCombo();else if(!Player.Combo.StepBite)BreakCombo();}
  internal static int ComboLineage(NativeGameplaySnake snake){if(snake.ComboLineageId==0)snake.ComboLineageId=snake.Id;return snake.ComboLineageId;}
  void RegisterComboBite(NativeGameplaySnake snake){
   if(UseLegacyAi||Player.Dead)return;
   // Passive arrivals and diagnostic direct-contact calls cannot create a
   // feeding chain. Only actual consecutive player movement steps qualify.
   if(!Player.Combo.StepInProgress){BreakCombo();return;}
   if(Player.Combo.Bite(ComboLineage(snake),Time))Sound("snakeSTART@",Player.Cell);
  }
 }
}

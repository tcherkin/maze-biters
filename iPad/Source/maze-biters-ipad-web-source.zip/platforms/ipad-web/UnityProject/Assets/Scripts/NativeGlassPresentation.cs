using System;
using UnityEngine;
namespace MazeBiters.NativeStudy {
 // Production gameplay opts in; frozen renderer/algorithm fixtures retain their
 // original presentation. The legacy switch is a diagnostic comparison only.
 public static class NativeGlassPresentation {
  public static bool Enabled {get;private set;}
  public static void EnableGameplay()=>Enabled=Array.IndexOf(Environment.GetCommandLineArgs(),"--legacy-glass-presentation")<0;
  public static string SkyShader=>Enabled?"MazeBiters/LuminousFrameStars":"MazeBiters/FrameStars";
  public static float Parallax=>Enabled?.15f:.16f;
 }
 public sealed partial class NativeGameplayStudy {
  NativeMazeArtwork sceneMazeArt;Texture2D glassEmission;Material crystalPaint;MeshRenderer crystalOverlay;string glassQuality;
  string GlassQuality=>NativeGlassPresentation.Enabled?quality:null;
  void InstallMazeArt(NativeMazeArtwork generated){
   if(maze&&maze!=generated.Maze)Destroy(maze);
   if(glassEmission&&glassEmission!=generated.Emission)Destroy(glassEmission);
   sceneMazeArt=generated;maze=generated.Maze;glassEmission=generated.Emission;glassQuality=generated.IsGlass?quality:null;
   BindGlassPresentation(maze,glassEmission,neon,generated);
  }
  void BindGlassPresentation(Texture2D image,Texture2D emission,NativeNeon lighting,NativeMazeArtwork artwork=null){
   bool active=NativeGlassPresentation.Enabled&&emission;
   BindLevelAtmosphere(artwork??sceneMazeArt,active);
   mazePaint.shader=Shader.Find(active?"MazeBiters/LuminousTunnelMaze":NativeTunnelSky.Enabled?"MazeBiters/TunnelMaze":"MazeBiters/ExactImage");
   mazePaint.mainTexture=image;
   if(dusk!=null){dusk.ConfigureGlassLighting(active,image);mazePaint.SetTexture("_Dusk",dusk.mask);}
   if(active){
    mazePaint.SetFloat("_OuterSkyBlend",1);mazePaint.SetFloat("_SkyVisibility",.9f);
    if(!crystalPaint){
     crystalPaint=new Material(Shader.Find("MazeBiters/FocusedCrystal"));crystalOverlay=Quad("Glass material revealed by player auras",crystalPaint);
     crystalOverlay.sortingOrder=20;crystalOverlay.transform.position=new Vector3(0,0,-2.05f);crystalOverlay.transform.localScale=new Vector3(576,400,1);
    }
    crystalPaint.mainTexture=emission;crystalPaint.SetTexture("_Dusk",dusk.mask);crystalPaint.SetTexture("_Actors",lighting?.ActorCoverage);
    crystalPaint.SetTexture("_MysticReceiver",lighting?.MysticWallReceiver);crystalPaint.SetFloat("_Amount",1);crystalPaint.SetFloat("_DistantEmission",.22f);crystalPaint.SetFloat("_NearEmission",.97f);
    crystalPaint.SetFloat("_RevealStart",.04f);crystalPaint.SetFloat("_RevealEnd",.65f);
   }
   if(crystalOverlay)crystalOverlay.enabled=active;
  }
  void RefreshGlassQuality(){
   if(!NativeGlassPresentation.Enabled||world==null||glassQuality==quality)return;
   CancelNextMaze();if(world.Transition)QueueNextMaze();
   var source=currentGeneratedLevel!=null&&ReferenceEquals(currentGeneratedLevel.geometry,world.Grid)?currentGeneratedLevel:new SessionLevel{geometry=world.Grid,theme=sceneMazeArt?.Theme??"green"};
   var generated=new NativeMazeArtwork(source,world.Level,glassQuality:quality);
   neon?.ReplaceMazeReceiver(generated);InstallMazeArt(generated);generated.DisposeStaging();
  }
  void DisposeGlassPresentation(){DisposeLevelAtmosphere();Destroy(glassEmission);Destroy(crystalPaint);if(crystalOverlay)Destroy(crystalOverlay.gameObject);glassEmission=null;sceneMazeArt=null;}
 }
}

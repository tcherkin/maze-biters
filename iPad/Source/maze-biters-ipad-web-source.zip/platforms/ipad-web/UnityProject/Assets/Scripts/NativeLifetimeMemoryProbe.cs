using System;using System.Collections.Generic;using System.IO;using UnityEngine;using UnityEngine.Profiling;
namespace MazeBiters.NativeStudy {
 // Opt-in, main-thread attribution, including loading frames outside gameplay.
 // No GC, working-set trimming, texture readbacks or resource retention.
 public sealed class NativeLifetimeMemoryProbe:MonoBehaviour {
  [Serializable] public sealed class Sample {public double ms;public long working,peak,privateBytes,used,reserved,monoHeap,monoUsed,graphics;}
  [Serializable] sealed class Result {public string note="OS lifetime peak includes all process activity. Unity graphics counter is not dedicated VRAM. Samples are main-thread only; no forced GC/readbacks by this probe.";public Sample[] samples;}
  readonly List<Sample> samples=new List<Sample>(2048);double previous=-1;long peak,reserved;string output;
  static NativeLifetimeMemoryProbe active;static int mainThread;
  internal static void MainThreadCheckpoint(){if(System.Threading.Thread.CurrentThread.ManagedThreadId==mainThread&&active)active.SampleNow();}
  [RuntimeInitializeOnLoadMethod(RuntimeInitializeLoadType.BeforeSceneLoad)] static void Install(){
   var args=Environment.GetCommandLineArgs();if(Array.IndexOf(args,"--lifetime-memory-probe")<0)return;
   int i=Array.IndexOf(args,"--report");if(i<0||i+1>=args.Length)throw new ArgumentException("Lifetime probe needs --report");
   var go=new GameObject("Optional lifetime memory attribution");DontDestroyOnLoad(go);var probe=go.AddComponent<NativeLifetimeMemoryProbe>();active=probe;mainThread=System.Threading.Thread.CurrentThread.ManagedThreadId;probe.output=Path.Combine(Path.GetDirectoryName(args[i+1]),"lifetime.json");probe.SampleNow();Application.quitting+=probe.Save;
  }
  void LateUpdate(){SampleNow();}
  void SampleNow(){
   NativeMemory.TryRead(out var working,out var lifePeak,out var committed);long currentReserved=Profiler.GetTotalReservedMemoryLong();double now=Time.realtimeSinceStartupAsDouble;
   if(now-previous<.1&&lifePeak<=peak+1048576&&currentReserved<=reserved)return;
   previous=now;peak=Math.Max(peak,lifePeak);reserved=Math.Max(reserved,currentReserved);
   if(samples.Count<8192)samples.Add(new Sample{ms=now*1000,working=working,peak=lifePeak,privateBytes=committed,used=Profiler.GetTotalAllocatedMemoryLong(),reserved=currentReserved,monoHeap=Profiler.GetMonoHeapSizeLong(),monoUsed=Profiler.GetMonoUsedSizeLong(),graphics=Profiler.GetAllocatedMemoryForGraphicsDriver()});
  }
  void Save(){SampleNow();Directory.CreateDirectory(Path.GetDirectoryName(output));File.WriteAllText(output,JsonUtility.ToJson(new Result{samples=samples.ToArray()},true));}
 }
}

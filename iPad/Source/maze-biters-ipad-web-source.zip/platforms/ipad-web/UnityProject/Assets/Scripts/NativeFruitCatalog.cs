using System;
using System.Collections.Generic;
using UnityEngine;
namespace MazeBiters.NativeStudy {
 public static class NativeFruitCatalog {
  public const int Count=10,Points=200;
  public static readonly string[] Names={"Apple","Pear","Strawberry","Watermelon","Cherries","Green grapes","Banana","Pumpkin","Pepper","Eggplant"};
  public static int Clamp(int kind)=>Math.Max(0,Math.Min(Count-1,kind));
  public static int LightSlot(int kind){kind=Clamp(kind);return kind<4?(kind==1?1:kind==3?0:9):14+kind-4;}
  // Frozen historical browser-oracle runs still verify their original rules.
  public static int Award(int kind,bool legacy)=>legacy?50*(Math.Max(0,Math.Min(3,kind))+1):Points;
 }
 // Per-level appearance bag. It never consumes movement/AI randomness. A drop
 // spends its original single appearance roll when queued, but only chooses
 // a type once its cell is free: blocked drops cannot silently exhaust a bag.
 public sealed class NativeFruitVariety {
  readonly int[] bag=new int[NativeFruitCatalog.Count],counts=new int[NativeFruitCatalog.Count],nearby=new int[NativeFruitCatalog.Count];
  int remaining,last=-1,level=int.MinValue;uint campaign,state;
  public void Reset(){remaining=0;last=-1;level=int.MinValue;}
  uint Next(){unchecked{state+=0x6D2B79F5;uint v=(state^(state>>15))*(1|state);v^=v+(v^(v>>7))*(61|v);return v^(v>>14);}}
  public int Select(int currentLevel,uint seed,double roll,Vector2Int cell,IReadOnlyList<NativeFruit> fruits){
   if(level!=currentLevel||campaign!=seed){Reset();level=currentLevel;campaign=seed;state=unchecked(seed^(uint)currentLevel*0x9e3779b9u^0x673ac92du);}
   state^=(uint)(Math.Max(0,Math.Min(.999999999,roll))*uint.MaxValue);
   if(remaining==0){for(int i=0;i<bag.Length;i++)bag[i]=i;for(int i=bag.Length-1;i>0;i--){int j=(int)(Next()%(uint)(i+1)),t=bag[i];bag[i]=bag[j];bag[j]=t;}remaining=bag.Length;}
   Array.Clear(counts,0,counts.Length);Array.Clear(nearby,0,nearby.Length);
   foreach(var f in fruits){int kind=NativeFruitCatalog.Clamp(f.Kind);counts[kind]++;int distance=Math.Abs(cell.x-f.Cell.x)+Math.Abs(cell.y-f.Cell.y);if(distance<=3)nearby[kind]+=4-distance;}
   int chosen=0,best=int.MaxValue;
   for(int i=0;i<remaining;i++){int kind=bag[i],penalty=nearby[kind]*100+counts[kind]*5+(kind==last?2:0);if(penalty<best){best=penalty;chosen=i;}}
   last=bag[chosen];for(int i=chosen;i<remaining-1;i++)bag[i]=bag[i+1];remaining--;return last;
  }
 }
}

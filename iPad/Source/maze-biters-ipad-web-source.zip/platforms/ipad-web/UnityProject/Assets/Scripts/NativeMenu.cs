using Screen = UnityEngine.Device.Screen;
using System;using System.IO;using System.Collections;using UnityEngine;using UnityEngine.SceneManagement;
namespace MazeBiters.NativeStudy {
 public sealed partial class NativeMenu:MonoBehaviour {
  public NativeMenuState State{get;private set;}public NativeSessionAudio Audio{get;private set;}
  NativeMenuRenderer renderer;NativeGameplayStudy gameplay;Scene menuScene,runScene;double entered;int openedFrame;readonly NativePadMenu padNavigation=new NativePadMenu();Vector3 pointer;bool changing,testing;string report;
  int confirmationPresentedFrame=-1;
  double Now=>(WebLifecycle.Realtime-entered)*1000;
  void Start(){
   NativeStartupLoading.Mark("menu Start");
   Application.runInBackground=true;QualitySettings.vSyncCount=0;Application.targetFrameRate=120;QualitySettings.anisotropicFiltering=AnisotropicFiltering.Disable;
   menuScene=gameObject.scene;State=new NativeMenuState{Quality=IpadPresentation.DefaultQuality,Music=Mathf.Clamp(PlayerPrefs.GetInt("OriginalMenuMusic",3),0,3),WaitForPreparation=NativeBalancedLaunch.Distributed};
   var args=Environment.GetCommandLineArgs();coopMenuTesting=Array.IndexOf(args,"--coop-menu-probe")>=0;startupTesting=Array.IndexOf(args,"--menu-start-probe")>=0;aiOnlyMenuTesting=Array.IndexOf(args,"--ai-only-menu-probe")>=0;testing=aiOnlyMenuTesting||coopMenuTesting||startupTesting||Array.IndexOf(args,"--menu-smoke")>=0;for(int i=0;i<args.Length;i++){if(args[i]=="--quality")State.Quality=args[++i];if(args[i]=="--report")report=args[++i];}
   instantMenuTesting=Array.IndexOf(args,"--instant-menu-probe")>=0;testing|=instantMenuTesting;
   balancedTesting=Array.IndexOf(args,"--balanced-start-probe")>=0;testing|=balancedTesting;
   ipadMenuTesting=Array.IndexOf(args,"--ipad-menu-probe")>=0;testing|=ipadMenuTesting;
   responsiveStartTesting=Array.IndexOf(args,"--responsive-start-probe")>=0;testing|=responsiveStartTesting;
   InitializeRecords(args);if(!NativeDisplay.Enabled&&!testing)Screen.SetResolution(1440,1080,FullScreenMode.Windowed);
   BeginEarlyMenuPreparation();
   long audioMark=NativeStartupLoading.Stamp();Audio=new GameObject("Persistent menu and session audio").AddComponent<NativeSessionAudio>();Audio.transform.SetParent(transform,false);Audio.Initialize(testing);NativeStartupLoading.Add("audio initialization",audioMark);NativeStartupLoading.Mark("audio ready");
   Open();if(responsiveStartTesting)StartCoroutine(ResponsiveStartProbe());else if(ipadMenuTesting)StartCoroutine(IpadMenuProbe());else if(balancedTesting)StartCoroutine(BalancedStartProbe());else if(instantMenuTesting)StartCoroutine(InstantMenuProbe());else if(aiOnlyMenuTesting)StartCoroutine(AiOnlyMenuProbe());else if(coopMenuTesting)StartCoroutine(CoopMenuProbe());else if(startupTesting)StartCoroutine(StartupProbe());else if(recordTesting)StartCoroutine(RecordSmoke());else if(testing)StartCoroutine(Smoke());
  }
  void Open(){openedFrame=Time.frameCount;padNavigation.Reset();entered=WebLifecycle.Realtime;long mark=NativeStartupLoading.Stamp();if(renderer==null)renderer=NativeMenuBoot.Take(State.Quality)??new NativeMenuRenderer(State.Quality);renderer.SetLeaderIfChanged(scores.Entries.Length>0?scores.Entries[0]:null);NativeStartupLoading.Add("menu art",mark);pointer=IpadPointer.Position;Audio.MusicSetting=(float)State.MusicGain;mark=NativeStartupLoading.Stamp();Audio.SetMenuTrack(0);NativeStartupLoading.Add("menu music",mark);renderer.Render(State,0);ResponsiveMenuRendered(0);NativeStartupLoading.Mark("menu displayed");preparationRetries=0;preparationError=null;QueueMenuArtwork();QueueMenuPreparation();}
  Rect Viewport()=>NativeDisplay.Fit((float)renderer.Target.width/renderer.Target.height);
  Vector2 MenuPointer(Vector3 mouse)=>renderer.ToLogical(mouse,Viewport(),Screen.height);
  public static Vector2 ToLogical(Vector3 mouse,Rect r,int screenHeight)=>new Vector2((mouse.x-r.x)*1024/r.width,(screenHeight-mouse.y-r.y)*768/r.height);
  void TickSound(string name){if(name!=null)Audio.Play(name,Vector2Int.zero,true,WebLifecycle.Realtime*1000);}
  void Choose(){if(State.Focus==6&&!State.Pending){TickSound("SnakeSELECT&Appear@");OpenBoard();return;}if(preparationError!=null){preparationRetries=0;preparationError=null;menuArtworkFailed=false;preloadFailed=true;}string cue=State.Activate(Now);TickSound(cue);Audio.MusicSetting=(float)State.MusicGain;if(!testing&&State.Focus==11){PlayerPrefs.SetInt("OriginalMenuMusic",State.Music);PlayerPrefs.Save();}QueueMenuArtwork();}
  void Update(){if(gameplay||changing||renderer==null||Time.frameCount<=openedFrame)return;double t=Now;QueueMenuArtwork();QueueMenuPreparation();if(!testing&&Application.isFocused&&State.Pending&&Input.GetKeyDown(KeyCode.Escape)){State.CancelStart();confirmationPresentedFrame=-1;}else if(!testing&&Application.isFocused&&NativeDisplay.ExitMenu(records!=null,State.Pending,Input.GetKeyDown(KeyCode.Escape))){Application.Quit();return;}if(NativeDisplay.AltEnter)return;if(records!=null){UpdateRecords(t);ResponsiveMenuRendered(t);return;}
   if(!testing&&!State.Pending&&Application.isFocused&&(!InstantMenuStart||SelectionAvailable)){
    Vector3 mouse=IpadPointer.Position;if((mouse-pointer).sqrMagnitude>.01||IpadPointer.Pressed){pointer=mouse;int hit=renderer.Hit(MenuPointer(mouse));if(hit>=0){State.SetFocus(hit,t);if(IpadPointer.Pressed)Choose();}}
    var arrows=new[]{KeyCode.UpArrow,KeyCode.DownArrow,KeyCode.LeftArrow,KeyCode.RightArrow};for(int i=0;i<4;i++)if(Input.GetKeyDown(arrows[i])&&State.Move(i,t))TickSound("Tick");
    for(int i=0;i<6;i++)if(Input.GetKeyDown(KeyCode.Alpha1+i)||Input.GetKeyDown(KeyCode.Keypad1+i)){State.SetFocus(i,t);Choose();}
    if(NativeDisplay.AcceptEnter||Input.GetKeyDown(KeyCode.Space)||NativeGamepadInput.ReadSlot(0).Confirm)Choose();
    // Separate gamepad input avoids treating WASD and both pads as one aggregate axis.
    int direction=padNavigation.Move(NativeGamepadInput.ReadSlot(0),t);if(direction>=0&&State.Move(direction,t))TickSound("Tick");
   }
   State.Advance(t);State.SignalPrepared(t,PreparedForSelection||ColdMenuStart);Audio.SyncMenu(t,State.Pending?State.PendingAt:-1);renderer.Render(State,t);ResponsiveMenuRendered(t);
   if(NativeBalancedLaunch.Distributed){
    // Present one completed, fully visible caption frame before leaving the menu.
    if(State.StartReady(t)){if(confirmationPresentedFrame<0)confirmationPresentedFrame=Time.frameCount;else if(Time.frameCount>confirmationPresentedFrame)StartRun();}else confirmationPresentedFrame=-1;
   }else if(InstantMenuStart?State.Pending:State.StartReady(t))StartRun();
  }
  void StartRun(){
   if(!ColdMenuStart){if(!InstallMenuPreparation())return;}
   else {
    Audio.ResetBus();runScene=SceneManager.CreateScene("Isolated SOLO session");SceneManager.SetActiveScene(runScene);
    gameplay=new GameObject("Original native SOLO").AddComponent<NativeGameplayStudy>();gameplay.MenuOwner=this;
   }
   // Retain one ready menu while playing: returning after GAME OVER must not
   // decode/re-upload its entire artwork before it can show the next blink.
  }
  public void ReturnToMenu(bool completed=false){if(changing||!gameplay)return;finishedRecord=completed?gameplay.MenuRecord:null;changing=true;StartCoroutine(Return());}
  IEnumerator Return(){
   State.Quality=gameplay.MenuQuality;gameplay.enabled=false;gameplay.HideForMenu=true;Audio.ResetBus();SceneManager.SetActiveScene(menuScene);
   if(ColdMenuStart){var unload=SceneManager.UnloadSceneAsync(runScene);yield return unload;}
   else {preparedGame=gameplay;preparedScene=runScene;preparedGame.HoldForMenu();}
   gameplay=null;
   int mode=State.SelectedMode;int d=State.Difficulty,s=State.Speed,m=State.Music;string q=State.Quality;State=new NativeMenuState{Focus=mode==0?5:mode==5?1:mode==2?2:mode==3?3:mode==4?4:0,LastMode=mode,Difficulty=d,Speed=s,Music=m,Quality=q,WaitForPreparation=NativeBalancedLaunch.Distributed};confirmationPresentedFrame=-1;Open();if(finishedRecord!=null&&scores.Qualifies(finishedRecord.score))OpenEntry(finishedRecord);finishedRecord=null;changing=false;
  }
  GUIStyle preparationLabel;NativeMessagePanel preparationNotice;
  void PreparationNotice(Rect textRect,string caption,Rect viewport){
   // Measure only the backdrop; retain the original wrapped text rectangle.
   float scale=viewport.height/432;var content=new GUIContent(caption);
   float width=Math.Min(textRect.width,preparationLabel.CalcSize(content).x),height=Math.Min(textRect.height,preparationLabel.CalcHeight(content,textRect.width));
   var bounds=Rect.MinMaxRect(Math.Max(viewport.x,textRect.center.x-width/2-16*scale),Math.Max(viewport.y,textRect.center.y-height/2-14*scale),Math.Min(viewport.xMax,textRect.center.x+width/2+16*scale),Math.Min(viewport.yMax,textRect.center.y+height/2+14*scale));
   if(preparationNotice==null)preparationNotice=new NativeMessagePanel();preparationNotice.DrawGUI(bounds,scale);
  }
  void OnGUI(){if(gameplay||renderer==null)return;var viewport=Viewport();GUI.DrawTexture(viewport,renderer.Target,ScaleMode.StretchToFill,false);
   if(preparationError!=null){if(preparationLabel==null)preparationLabel=new GUIStyle(GUI.skin.label){alignment=TextAnchor.MiddleCenter,wordWrap=true,normal={textColor=new Color(.58f,.91f,1)}};preparationLabel.fontSize=Mathf.RoundToInt(20*viewport.height/768);var textRect=new Rect(viewport.x+20,viewport.y+viewport.height*.9f,viewport.width-40,viewport.height*.08f);PreparationNotice(textRect,preparationError,viewport);GUI.Label(textRect,preparationError,preparationLabel);}
   if(InstantMenuStart&&!State.Pending&&!SelectionAvailable){
    var old=GUI.color;GUI.color=new Color(0,0,0,.84f);GUI.DrawTexture(viewport,Texture2D.whiteTexture);GUI.color=old;
    if(preparationLabel==null)preparationLabel=new GUIStyle(GUI.skin.label){alignment=TextAnchor.MiddleCenter,normal={textColor=new Color(.58f,.91f,1)},wordWrap=true};
    preparationLabel.fontSize=Mathf.RoundToInt(24*viewport.height/768);
    string caption=NativeBalancedLaunch.Distributed?"ПОДГОТВЯНЕ НА ИГРАТА…":"ПОДГОТВЯНЕ НА НИВОТО…\n\nСлед това всички режими започват веднага.";PreparationNotice(viewport,caption,viewport);GUI.Label(viewport,caption,preparationLabel);
   }
  }
  // Inactive prepared worlds may never receive OnDestroy. Release them while
  // their Unity owners are still valid, before scene teardown changes ordering.
  void OnApplicationQuit(){CancelMenuArtwork();CancelMenuPreparation();}
  void OnDestroy(){CancelMenuArtwork();CancelMenuPreparation();renderer?.Dispose();preparationNotice?.Dispose();}
  void SaveFrame(string name,RenderTexture target){var old=RenderTexture.active;RenderTexture.active=target;var image=new Texture2D(target.width,target.height,TextureFormat.RGBA32,false);image.ReadPixels(new Rect(0,0,target.width,target.height),0,0);image.Apply();File.WriteAllBytes(Path.Combine(Path.GetDirectoryName(report),name+".png"),image.EncodeToPNG());Destroy(image);RenderTexture.active=old;}
  IEnumerator Smoke(){
   Directory.CreateDirectory(Path.GetDirectoryName(report));string quality=State.Quality;yield return null;SaveFrame(quality+"-interactive-menu",renderer.Target);
   State.SetFocus(7,Now);Choose();yield return null;bool ok=!State.Pending&&gameplay==null&&State.ComingUntil>Now;SaveFrame(quality+"-coming-soon",renderer.Target);
   State.SetFocus(10,Now);Choose();ok&=State.Quality!=quality;yield return null;Choose();ok&=State.Quality==quality;
   State.Difficulty=4;State.Speed=NativeMenuState.Speeds.Length-1;State.Music=3;State.SetFocus(8,Now);Choose();State.SetFocus(9,Now);Choose();State.SetFocus(11,Now);Choose();ok&=State.Difficulty==0&&State.Speed==0&&State.Music==0&&Audio.MusicSetting==0;
   State.SetFocus(0,Now);Choose();double started=WebLifecycle.Realtime;yield return new WaitForSecondsRealtime(.4f);ok&=State.Pending&&(InstantMenuStart||gameplay==null);
   while(!gameplay||!gameplay.MenuReady){if(WebLifecycle.Realtime-started>180)throw new TimeoutException("Menu SOLO preparation");yield return null;}
   yield return null;ok&=gameplay.MenuOptionsValid&&Audio.Track!=null&&Audio.Track!="neon-orbit-menu";SaveFrame(quality+"-solo",gameplay.MenuTarget);
   ReturnToMenu();while(changing)yield return null;ok&=renderer!=null&&State.Quality==quality&&State.Difficulty==0&&State.Speed==0&&State.Music==0&&Audio.Track=="neon-orbit-menu";
   SaveFrame(quality+"-return",renderer.Target);NativeMemory.TryRead(out var ws,out var peak,out var committed);
   File.WriteAllText(report,JsonUtility.ToJson(new MenuSmokeResult{passed=ok,quality=quality,sounds=Audio.Accepted,workingSetBytes=ws,peakWorkingSetBytes=peak,note="Muted real menu -> SOLO -> menu lifecycle, native HD/4K toggle, settings and 900ms confirmation. No user prefs written; timing is functional, not a foreground FPS benchmark."},true));Application.Quit(ok?0:2);
  }
 }
 [Serializable] public sealed class MenuSmokeResult {public bool passed;public string quality,note;public int sounds;public long workingSetBytes,peakWorkingSetBytes;}
 public sealed partial class NativeGameplayStudy {
  public int MenuMode=>world?.Mode??1;public NativeMenu MenuOwner;public bool HideForMenu;public string MenuQuality=>quality;public RenderTexture MenuTarget=>target;
  public bool MenuReady=>world!=null&&preparationFrames==0&&!discardPreparationDelta;
  double MenuSpeed=>MenuOwner?MenuOwner.State.Rate:NativeMenuState.Speeds[2];
  double MenuScoreSpeed=>MenuOwner?MenuOwner.State.ScoreRate:1;
  public bool MenuOptionsValid=>MenuReady&&Math.Abs(world.Difficulty-NativeMazeGenerator.Difficulties[MenuOwner.State.Difficulty])<1e-10&&world.ScoreSpeed==MenuOwner.State.ScoreRate&&quality==MenuOwner.State.Quality&&bank.Quality==quality&&target.height==NativeDisplay.Frame.Pixels(quality).y&&sessionAudio==MenuOwner.Audio;
 }
}

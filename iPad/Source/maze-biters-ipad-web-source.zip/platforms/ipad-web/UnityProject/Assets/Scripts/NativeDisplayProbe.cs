using Screen = UnityEngine.Device.Screen;
using System;using System.IO;using System.Collections;using System.Collections.Generic;using UnityEngine;
namespace MazeBiters.NativeStudy {
 public sealed partial class NativeGameplayStudy {
  bool displayProbe;
  [Serializable] sealed class DisplayResult {public bool passed;public string quality,note;public string[] checks;public int numericChecks,nativeSpriteSize;public DisplayDiff[] images;public long workingSetBytes,peakWorkingSetBytes;public int desktopWidth,desktopHeight;}
  [Serializable] sealed class DisplayDiff {public string name;public int width,height,maxError;public double meanError,percentOverThree;}
  static Texture2D DisplayRead(RenderTexture rt){var old=RenderTexture.active;RenderTexture.active=rt;var t=new Texture2D(rt.width,rt.height,TextureFormat.RGBA32,false);t.ReadPixels(new Rect(0,0,rt.width,rt.height),0,0);t.Apply();RenderTexture.active=old;return t;}
  static DisplayDiff DisplayCompare(Texture2D original,Texture2D wide,string name,bool board){var a=original.GetPixels32();var b=wide.GetPixels32();int dx=(wide.width-original.width)/2,n=0,max=0,bad=0;long sum=0;int height=board?original.height*400/432:original.height;
   for(int y=0;y<height;y++)for(int x=0;x<original.width;x++){var p=a[y*original.width+x];var q=b[y*wide.width+x+dx];int r=Math.Abs(p.r-q.r),g=Math.Abs(p.g-q.g),bl=Math.Abs(p.b-q.b);int error=Math.Max(r,Math.Max(g,bl));max=Math.Max(max,error);sum+=r+g+bl;if(error>3)bad++;n++;}
   return new DisplayDiff{name=name,width=wide.width,height=wide.height,maxError=max,meanError=sum/(3.0*n),percentOverThree=bad*100.0/n};
  }
  IEnumerator ProbeDisplay(){
   if(Array.IndexOf(Environment.GetCommandLineArgs(),"--ipad-roster-probe")>=0){yield return ProbeIpadRosterCamera();yield break;}
   if(Array.IndexOf(Environment.GetCommandLineArgs(),"--ipad-motion-probe")>=0){yield return ProbeIpadCameraMotion();yield break;}
   if(IpadPresentation.Probe){yield return ProbeIpadFraming();yield break;}
   if(Array.IndexOf(Environment.GetCommandLineArgs(),"--hud-clearance-probe")>=0){yield return ProbeHudClearance();yield break;}
   // The legacy branch remains a reproducible reference for the previous framing.
   if(!NativeOverviewFraming.Legacy){yield return ProbeOverviewFraming();yield break;}
   var checks=new List<string>();var images=new List<DisplayDiff>();void Check(bool b,string text){if(!b)throw new Exception("Fullscreen probe: "+text);checks.Add(text);}
   var result=new DisplayResult{quality=quality,numericChecks=NativeDisplayValidation.Run()};Directory.CreateDirectory(Path.GetDirectoryName(report));
   NativeDisplay.TestAspect=4f/3;sessionSmoke=true;fixedCamera=true;Reset(12);yield return DrainProbePreparation();Render();NativePreparation.Drain(target);
   result.nativeSpriteSize=bank.Size;Check(bank.Size==(quality=="4k"?160:80)&&bank.Quality==quality,"separate original HD/4K animation bank");var originalBank=bank;var originalWorld=world;var originalPosition=world.Player.Cell;double originalTime=time;
   var baseline=DisplayRead(target);File.WriteAllBytes(Path.ChangeExtension(report,null)+"-original.png",baseline.EncodeToPNG());
   if(NativeTunnelSky.Enabled)CheckTunnelSky(checks);
   foreach(float aspect in new[]{16f/9,16f/10,21f/9}){
    NativeDisplay.TestAspect=aspect;Render();NativePreparation.Drain(target);var actual=DisplayRead(target);string name=aspect==16f/9?"wide":aspect==16f/10?"16-10":"ultrawide";File.WriteAllBytes(Path.ChangeExtension(report,null)+"-"+name+".png",actual.EncodeToPNG());
    var diff=DisplayCompare(baseline,actual,name,true);images.Add(diff);Check(diff.meanError<.08&&diff.percentOverThree<.15,"unchanged board pixels / "+name);
    Check(ReferenceEquals(originalBank,bank)&&ReferenceEquals(originalWorld,world)&&world.Player.Cell==originalPosition&&time==originalTime,"resize preserves art, world and clocks / "+name);
    var f=DisplayFrame;var vp=Viewport();var point=new Vector2(f.Board.x+40,f.Board.y+40);var mouse=new Vector2(vp.x+point.x/f.Width*vp.width,Screen.height-vp.y-point.y/f.Height*vp.height);
    Check(GameplayPointer(mouse,out var cell)&&cell==new Vector2Int(2,2),"wide mouse cell / "+name);
    Check(!GameplayPointer(new Vector2(vp.x+2,Screen.height/2),out _),"stars cannot move player / "+name);
    if(name=="wide"){var size=new NativeFrame(16f/9).Pixels(quality);Check(target.width==size.x&&target.height==size.y,"native HD/4K output");var pixels=actual.GetPixels32();int stars=0;for(int y=actual.height/4;y<actual.height/2;y++)for(int x=0;x<(actual.width-baseline.width)/2;x++){var p=pixels[y*actual.width+x];if(p.r>8||p.g>8||p.b>8)stars++;}Check(stars>50,"visible restrained side stars");}
    Destroy(actual);
   }
   // Same central picture while the unchanged original camera is zoomed and offset.
   foreach(double z in new[]{1.42,2.0}){
    gameplayCamera.Zoom=z;gameplayCamera.X=144;gameplayCamera.Y=100;NativeDisplay.TestAspect=4f/3;Render();var zoomSource=DisplayRead(target);
    NativeDisplay.TestAspect=16f/9;Render();var zoomWide=DisplayRead(target);var diff=DisplayCompare(zoomSource,zoomWide,"zoom-"+z,true);images.Add(diff);Check(diff.meanError<.08&&diff.percentOverThree<.15,"zoom keeps square pixels / "+z);
    var f=DisplayFrame;var vp=Viewport();double sx=288+(136-cameraViewX)*cameraViewZoom,sy=200+(104-cameraViewY)*cameraViewZoom;var point=new Vector2((float)sx+f.Board.x,(float)sy+f.Board.y);var mouse=new Vector2(vp.x+point.x/f.Width*vp.width,Screen.height-vp.y-point.y/f.Height*vp.height);Check(GameplayPointer(mouse,out var cell)&&cell==new Vector2Int(8,6),"zoomed pointer / "+z);
    Destroy(zoomSource);Destroy(zoomWide);
   }
   gameplayCamera.Reset(realClock);
   // Full-width camera: check actual edges, newly visible pixels, and click targets.
   NativeDisplay.TestAspect=16f/9;gameplayCamera.Zoom=2;gameplayCamera.X=288;gameplayCamera.Y=200;Render();
   var full=DisplayRead(target);File.WriteAllBytes(Path.ChangeExtension(report,null)+"-zoom-centre.png",full.EncodeToPNG());
   int lit=0;var fp=full.GetPixels32();int side=full.width/8;for(int py=full.height/4;py<full.height*3/4;py++)for(int px=0;px<side;px++){var p=fp[py*full.width+px];if(Math.Max(p.r,Math.Max(p.g,p.b))>12)lit++;}
   Check(lit>side*full.height*.015,"maze is drawn in the former fixed left border");
   float density=quality=="4k"?5:2.5f;int headerWorld=0,headerSamples=0;
   // Empty text columns isolate the maze from score glyphs in the top 32 units.
   for(int py=full.height-(int)(32*density);py<full.height;py++)for(int px=(int)(130*density);px<(int)(175*density);px++){var p=fp[py*full.width+px];if(Math.Max(p.r,Math.Max(p.g,p.b))>12)headerWorld++;headerSamples++;}
   Check(headerWorld>headerSamples*.02,"maze is visible behind the transparent score overlay");Destroy(full);
   var fr=DisplayFrame;var vr=Viewport();Vector2 Mouse(float lx,float ly)=>new Vector2(vr.x+lx/fr.Width*vr.width,Screen.height-vr.y-ly/fr.Height*vr.height);
   Check(GameplayPointer(Mouse(24,232),out _),"clicks navigate the newly exposed side of the maze");
   Check(GameplayPointer(Mouse(fr.Width/2,16),out _),"clicks can reach the world behind the score row");
   gameplayCamera.X=144;Render();Capture(Path.ChangeExtension(report,null)+"-zoom-left.png");Check(!GameplayPointer(Mouse(24,232),out _),"left sky stays outside navigation");
   gameplayCamera.X=432;Render();Capture(Path.ChangeExtension(report,null)+"-zoom-right.png");Check(!GameplayPointer(Mouse(fr.Width-24,232),out _),"right sky stays outside navigation");
   gameplayCamera.X=288;gameplayCamera.Y=100;Render();Capture(Path.ChangeExtension(report,null)+"-zoom-top.png");double upperSky=fr.ProjectBoard(cameraViewX,cameraViewY,cameraViewZoom).y;
   Check(!GameplayPointer(Mouse(fr.Width/2,40),out _)&&GameplayPointer(Mouse(fr.Width/2,60),out _)&&Math.Abs(upperSky-52)<.001,"top edge retains screenshot-sized sky including the HUD area");
   gameplayCamera.Y=300;Render();Capture(Path.ChangeExtension(report,null)+"-zoom-bottom.png");double lowerSky=fr.Height-fr.ProjectBoard(cameraViewX,cameraViewY,cameraViewZoom).yMax;
   Check(!GameplayPointer(Mouse(fr.Width/2,fr.Height-40),out _)&&GameplayPointer(Mouse(fr.Width/2,fr.Height-60),out _)&&Math.Abs(lowerSky-upperSky)<.001,"bottom sky matches the entire top gap");
   gameplayCamera.X=144;gameplayCamera.Y=100;Render();Capture(Path.ChangeExtension(report,null)+"-zoom-corner.png");
   // GPU parallax proof: at a constant side gap, 25 world units of camera pan
   // move the sky by only four logical pixels (10 HD / 20 4K output pixels).
   gameplayCamera.X=144;gameplayCamera.Y=180;Render();var skyA=DisplayRead(target);int hudUpdates=hud.MeshUpdates;
   gameplayCamera.Y=205;Render();var skyB=DisplayRead(target);int shift=quality=="4k"?20:10;var sa=skyA.GetPixels32();var sb=skyB.GetPixels32();long skyError=0;int skyPixels=0,changed=0;int limit=(int)(80*(quality=="4k"?5:2.5f));
   for(int py=skyA.height/3;py<skyA.height/2;py++)for(int px=4;px<limit;px++){var p=sa[(py-shift)*skyA.width+px];var q=sb[py*skyB.width+px];skyError+=Math.Abs(p.r-q.r)+Math.Abs(p.g-q.g)+Math.Abs(p.b-q.b);var old=sa[py*skyA.width+px];if(old.r!=q.r||old.g!=q.g||old.b!=q.b)changed++;skyPixels++;}
   Check(skyError/(3.0*skyPixels)<.1&&changed>30,"rendered stars pan at 16 percent without being zoomed");
   Destroy(skyA);Destroy(skyB);
   // At the top edge the same sky is revealed behind the fixed score glyphs.
   // Pan horizontally: 25 world units produce only four screen-space units.
   gameplayCamera.X=144;gameplayCamera.Y=100;Render();skyA=DisplayRead(target);sa=skyA.GetPixels32();
   gameplayCamera.X=169;Render();skyB=DisplayRead(target);sb=skyB.GetPixels32();
   long hudError=0;int hudPixels=0,hudChanged=0;
   for(int py=skyA.height-(int)(32*density);py<skyA.height;py++)for(int px=(int)(130*density);px<(int)(170*density);px++){var p=sa[py*skyA.width+px+shift];var q=sb[py*skyB.width+px];hudError+=Math.Abs(p.r-q.r)+Math.Abs(p.g-q.g)+Math.Abs(p.b-q.b);var old=sa[py*skyA.width+px];if(old.r!=q.r||old.g!=q.g||old.b!=q.b)hudChanged++;hudPixels++;}
   Check(hudError/(3.0*hudPixels)<.1&&hudChanged>0,"top-edge sky behind HUD follows the distant world sky");
   Check(hud.MeshUpdates==hudUpdates,"sky motion leaves score and label geometry fixed");Destroy(skyA);Destroy(skyB);
   var stateRoot=new GameObject("Parallax allocation probe");using(var borderProbe=new NativeFrameBorder(quad,stateRoot.transform)){borderProbe.Layout(fr,144,200,2);hud.SetSky(fr,144,200);long begin=GC.GetAllocatedBytesForCurrentThread();for(int i=0;i<1000;i++){borderProbe.Layout(fr,144,200+i*.01,2);hud.SetSky(fr,144,200+i*.01);}Check(GC.GetAllocatedBytesForCurrentThread()==begin,"world and HUD star motion have no per-frame managed allocation");}stateRoot.SetActive(false);Destroy(stateRoot);
   gameplayCamera.Reset(realClock);
   // Portrait/window resizing retains the entire original area; no aspect stretch.
   NativeDisplay.TestAspect=9f/16;Render();Check(DisplayFrame.Board.x>=-.01&&DisplayFrame.Board.y>=32,"narrow window fits original field");
   Capture(Path.ChangeExtension(report,null)+"-portrait.png");
   NativeDisplay.TestAspect=4f/3;Render();var back=DisplayRead(target);var restored=DisplayCompare(baseline,back,"restored",true);images.Add(restored);Check(restored.meanError<.08,"resize roundtrip");Destroy(back);Destroy(baseline);
   // Menu and records artwork remains its original shape and native resolution.
   using(var menu=new NativeMenuRenderer(quality)){
    var state=new NativeMenuState{Quality=quality};menu.Render(state,1000);var source=DisplayRead(menu.Target);
    NativeDisplay.TestAspect=16f/9;menu.Render(state,1000);var wide=DisplayRead(menu.Target);var diff=DisplayCompare(source,wide,"menu",false);images.Add(diff);Check(diff.meanError<.08&&diff.percentOverThree<.15,"unchanged menu pixels");File.WriteAllBytes(Path.ChangeExtension(report,null)+"-menu.png",wide.EncodeToPNG());Destroy(source);Destroy(wide);
    var f=NativeDisplay.Frame;var vp=new Rect(0,0,1920,1080);var logical=new Vector2(f.Original.x+200*576f/1024,f.Original.y+300*432f/768);var mapped=menu.ToLogical(new Vector3(logical.x/f.Width*1920,1080-logical.y/f.Height*1080),vp,1080);Check((mapped-new Vector2(200,300)).magnitude<.01,"menu pointer keeps original hit areas");
    menu.RenderRecords(new NativeRecordState(),Array.Empty<NativeRecord>(),1000);var records=DisplayRead(menu.Target);File.WriteAllBytes(Path.ChangeExtension(report,null)+"-records.png",records.EncodeToPNG());Destroy(records);
   }
   yield return null;
   // Exercise the same display transition that Alt+Enter requests, without synthetic keyboard input.
   NativeDisplay.TestAspect=null;NativeDisplay.Toggle();yield return new WaitForSecondsRealtime(.6f);Render();
   result.desktopWidth=Screen.mainWindowDisplayInfo.width;result.desktopHeight=Screen.mainWindowDisplayInfo.height;
   Check(Screen.fullScreenMode==FullScreenMode.FullScreenWindow&&Screen.width==result.desktopWidth&&Screen.height==result.desktopHeight,"borderless native monitor resolution");
   NativeDisplay.Toggle();yield return new WaitForSecondsRealtime(.6f);Render();Check(Screen.fullScreenMode==FullScreenMode.Windowed,"Alt+Enter path returns to window");
   Check(ReferenceEquals(originalBank,bank)&&ReferenceEquals(originalWorld,world)&&time==originalTime,"display switches do not restart/reload game");
   NativeMemory.TryRead(out result.workingSetBytes,out result.peakWorkingSetBytes,out _);result.images=images.ToArray();result.checks=checks.ToArray();result.passed=true;result.note="Functional standalone display checks. Original camera/grid/animations frozen for image comparison. Window switching exercises Alt+Enter's handler; physical keypress not simulated. Not a foreground performance measurement.";
   File.WriteAllText(report,JsonUtility.ToJson(result,true));Application.Quit();
  }
 }
}


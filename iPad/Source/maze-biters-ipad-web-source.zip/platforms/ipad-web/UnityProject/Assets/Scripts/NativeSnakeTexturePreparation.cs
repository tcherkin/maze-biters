using System;using System.Collections.Generic;using System.IO;using System.IO.Compression;using System.Linq;using System.Threading.Tasks;using Unity.Collections;using UnityEngine;
namespace MazeBiters.NativeStudy {
 public static partial class NativeSnakeTextures {
  public static int PackedUploads{get;private set;}
  // One pending decompression, one upload per frame. Pins transfer ownership to
  // the prepared renderers; cancellation leaves no global orphan texture cache.
  public sealed class Prefetch:IDisposable {
   sealed class Pixels:IDisposable {public string name;public bool pm;public int width,height;public NativeArray<byte> bytes;public void Dispose(){if(bytes.IsCreated)bytes.Dispose();}}
   readonly Queue<string> missing=new Queue<string>();readonly List<Lease> pins=new List<Lease>();readonly string root;Task<Pixels> pending;bool disposed;
   public Prefetch(IEnumerable<string> palettes){
    root=Path.Combine(WebFiles.Root,"Reference");
    foreach(var palette in palettes.Distinct())foreach(var treatment in new[]{"lit","emission"})foreach(var part in new[]{"mouth","solo","material"}){
     string name="neon-"+palette+"-"+part+"-"+treatment;bool pm=part!="material";
     if(entries.ContainsKey(name+(pm?":pm":":raw")))pins.Add(Lease.Acquire(name,pm));else missing.Enqueue(name);
    }
   }
   public bool Step(){
    if(disposed)throw new ObjectDisposedException(nameof(Prefetch));
    if(pending!=null){if(!pending.IsCompleted)return false;var task=pending;pending=null;using(var p=task.GetAwaiter().GetResult()){
     string key=p.name+(p.pm?":pm":":raw");
     if(!entries.ContainsKey(key)){
      var texture=new Texture2D(p.width,p.height,TextureFormat.RGBA32,false,false){filterMode=FilterMode.Bilinear,wrapMode=TextureWrapMode.Clamp,name=p.name};
      try{texture.SetPixelData(p.bytes,0);texture.Apply(false,true);}catch{UnityEngine.Object.Destroy(texture);throw;}
      var entry=new Entry{key=key,texture=texture,bytes=p.bytes.Length};entries.Add(key,entry);ResidentBytes+=entry.bytes;PackedUploads++;
     }
     pins.Add(Lease.Acquire(p.name,p.pm));
    }}
    if(missing.Count==0)return true;
    string name=missing.Dequeue(),path=Path.Combine(root,name+".native.gz");
    pending=WebWorkQueue.Run(()=>{
     using(var file=File.OpenRead(path))using(var zip=new GZipStream(file,CompressionMode.Decompress))using(var reader=new BinaryReader(zip)){
      int w=reader.ReadInt32(),h=reader.ReadInt32();if(w<=0||h<=0||w>32768||h>32768)throw new InvalidDataException(path);
      int count=checked(w*h*4);var raw=reader.ReadBytes(count);if(raw.Length!=count||reader.Read()!=-1)throw new InvalidDataException(path);
      return new Pixels{name=name,pm=!name.Contains("-material-"),width=w,height=h,bytes=new NativeArray<byte>(raw,Allocator.Persistent)};
     }
    });return false;
   }
   public void Dispose(){if(disposed)return;disposed=true;foreach(var p in pins)p.Dispose();pins.Clear();missing.Clear();if(pending!=null){var task=pending;pending=null;WebWorkQueue.Continue(task,t=>{if(t.Status==TaskStatus.RanToCompletion)t.Result.Dispose();else if(t.IsFaulted){var observed=t.Exception;}});}}
  }
 }
}

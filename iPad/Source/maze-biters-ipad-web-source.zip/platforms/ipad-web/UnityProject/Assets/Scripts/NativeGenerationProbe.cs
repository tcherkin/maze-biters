using System;using System.Collections;using System.Collections.Generic;using System.Diagnostics;using System.IO;using System.Linq;using UnityEngine;
namespace MazeBiters.NativeStudy {
 public sealed partial class NativeGameplayStudy {
  bool generationProbe;
  [Serializable] sealed class GenerationLoad {public int level;public double milliseconds;public string state;public NativeMazeArtwork.PreparationProfile painting;}
  [Serializable] sealed class GenerationResult {public string quality,mode,graphics,note;public bool passed;public GenerationLoad[] loads;public ConsistencyFrame[] frames;public ConsistencyMemory[] memory;}
  string GenerationState()=>world.Level+"|"+world.Player.Cell+"|"+world.Player.Dir+"|"+world.Player.Score+"|"+random+"|"+string.Join(";",world.Snakes.Select(s=>s.Palette+":"+s.Dir+":"+s.Reversing+":"+string.Join(",",s.Body.Select(p=>p.x+"/"+p.y))))+"|"+world.Hunters.Count+"|"+world.Fruits.Count+"|"+world.Eggs.Count;
  IEnumerator ProbeGeneration(){if(Array.IndexOf(Environment.GetCommandLineArgs(),"--early-cache-probe")>=0){yield return ProbeEarlyCache();yield break;}if(Array.IndexOf(Environment.GetCommandLineArgs(),"--validate-music-resources")>=0){yield return ValidateMusicResources();yield break;}if(Array.IndexOf(Environment.GetCommandLineArgs(),"--validate-next-scene")>=0){yield return ValidateNextScene();yield break;}if(Array.IndexOf(Environment.GetCommandLineArgs(),"--capture-preparation")>=0){yield return CapturePreparationScenes();yield break;}if(Array.IndexOf(Environment.GetCommandLineArgs(),"--transition-only")>=0){yield return ProbeMazeTransitions();yield break;}bool requireFocus=Array.IndexOf(Environment.GetCommandLineArgs(),"--require-focus")>=0;sessionSmoke=true;consistencyFrames.Capacity=12000;var loads=new List<GenerationLoad>();
   Reset(12);yield return DrainProbePreparation();SampleConsistencyMemory();
   for(int cycle=0;cycle<2;cycle++)foreach(int levelNumber in new[]{1,10,50,100}){
    var watch=Stopwatch.StartNew();Reset(12);if(levelNumber!=1){world.Level=levelNumber-1;world.AdvanceLevel();}yield return DrainProbePreparation();watch.Stop();var load=new GenerationLoad{level=levelNumber,milliseconds=watch.Elapsed.TotalMilliseconds,painting=NativeMazeArtwork.LastProfile};loads.Add(load);world.Event=TraceWorldEvent;sessionAudio.Muted=true;
    // Survive the diagnostic traversal without altering enemy AI, movement,
    // rendering or light clocks. The pilot avoids intentional contact.
    world.Player.ShieldUntil=time+100000;var visits=new Dictionary<Vector2Int,int>();long previous=0;consistencyCycle=cycle+1;
    for(int frame=0;frame<1200;frame++){while(requireFocus&&!Application.isFocused){previous=0;yield return null;}StallPilot(visits,true);long now=Stopwatch.GetTimestamp();MeasureStallFrame("generated-level-"+levelNumber,"spawn",frame,previous);previous=now;yield return null;}
    load.state=GenerationState();
    if(cycle==0){Capture(Path.Combine(Path.GetDirectoryName(report),Path.GetFileNameWithoutExtension(report)+"-level-"+levelNumber+".png"));yield return null;}
    Reset(12);yield return DrainProbePreparation();SampleConsistencyMemory();
   }
   NativeStallTrace.Enabled=false;var stable=consistencyMemory.Skip(1).ToArray();bool pass=stable.Select(m=>m.textures).Distinct().Count()==1&&stable.Select(m=>m.objects).Distinct().Count()==1&&stable.Skip(4).Max(m=>m.unityUsed)-stable.Take(4).Max(m=>m.unityUsed)<2*1024*1024&&stable.Skip(4).OrderBy(m=>m.unityUsed).ElementAt(1).unityUsed-stable.Take(4).OrderBy(m=>m.unityUsed).ElementAt(1).unityUsed<2*1024*1024;
   var result=new GenerationResult{quality=quality,mode=catalogueControl?"catalogue":NativeMazeArtwork.LegacyPreparation?"before":"after",graphics=SystemInfo.graphicsDeviceName,passed=pass,loads=loads.ToArray(),frames=consistencyFrames.ToArray(),memory=consistencyMemory.ToArray(),note="Same binary, seed 34, MEDIUM. Two traversals of levels 1/10/50/100, 1200 frames each, original Tick/AI/render/effects; diagnostic pilot with extended spawn shield avoids intentional contacts. 120Hz simulation; actual loop gaps and CPU submission measured separately. Loading includes reset + target-level creation + GPU preparation (not playable frames). Memory checkpoints always identical level 1 after destruction/full GC; repeated-cycle peak and median growth must each stay below 2 MiB, with stable object/texture counts. Downward allocator fluctuations are reported, not mistaken for growth. State strings compare exact enemy trajectories/RNG. Screenshots outside timings. Process memory is not VRAM."};Directory.CreateDirectory(Path.GetDirectoryName(report));File.WriteAllText(report,JsonUtility.ToJson(result,true));Application.Quit(pass?0:2);
  }
 }
}

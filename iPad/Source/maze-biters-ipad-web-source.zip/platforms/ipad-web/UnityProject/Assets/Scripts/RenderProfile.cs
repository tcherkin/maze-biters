using System;
using System.Collections.Generic;
using System.Diagnostics;
namespace MazeBiters.NativeStudy {
 public static class RendererTuning {public static bool Optimized=true;}
 [Serializable] public class RenderStage {public string name;public double meanMs,p95Ms;}
 [Serializable] public class RenderProfileResult {public RenderStage[] stages;public long mainThreadAllocatedBytes;public int gen0Collections,measuredFrames;public double cameraRendersPerFrame;public string note="Main-thread wall times, not GPU execution; allocation counter covers this thread during submission only.";}
 public static class RenderProfile {
  public static bool Enabled;static bool recording;static long allocatedStart,allocated;static int gen0,frames,cameras;static readonly Dictionary<string,List<double>> samples=new Dictionary<string,List<double>>();
  public static long Stamp()=>Enabled?Stopwatch.GetTimestamp():0;
  public static void Add(string name,long start){if(!recording)return;if(!samples.TryGetValue(name,out var list)){list=new List<double>(1440);samples.Add(name,list);}list.Add((Stopwatch.GetTimestamp()-start)*1000.0/Stopwatch.Frequency);}
  public static void Begin(bool measured){recording=Enabled&&measured;if(!recording)return;if(frames==0)gen0=GC.CollectionCount(0);allocatedStart=GC.GetAllocatedBytesForCurrentThread();}
  public static void Camera(){if(recording)cameras++;}
  public static void End(){if(!recording)return;allocated+=GC.GetAllocatedBytesForCurrentThread()-allocatedStart;frames++;recording=false;}
  public static RenderProfileResult Result(){var result=new RenderProfileResult{measuredFrames=frames,mainThreadAllocatedBytes=allocated>0?allocated:-1,gen0Collections=GC.CollectionCount(0)-gen0,cameraRendersPerFrame=frames>0?(double)cameras/frames:0};var stages=new List<RenderStage>();foreach(var pair in samples){var a=pair.Value.ToArray();Array.Sort(a);double sum=0;foreach(var x in a)sum+=x;stages.Add(new RenderStage{name=pair.Key,meanMs=sum/a.Length,p95Ms=a[(int)(a.Length*.95)]});}result.stages=stages.ToArray();return result;}
 }
}

using System;using System.Linq;using UnityEngine;
namespace MazeBiters.NativeStudy {
 public sealed partial class NativeGameplayStudy {
  bool LevelAtmosphereProbe=>Array.IndexOf(Environment.GetCommandLineArgs(),"--level-atmosphere-probe")>=0;
  void ValidateLevelAtmosphere(string label,bool images=false){
   if(!LevelAtmosphereProbe)return;
   GlassCheck(boundAtmosphereArt==sceneMazeArt&&boundWallLightRoutes==sceneMazeArt.WallLightRoutes&&boundWallLightRoutes.Count>0,label+" own cached light routes are bound");
   GlassCheck(levelAtmosphereDepth&&levelAtmosphereDepth.width==144&&levelAtmosphereDepth.height==100,label+" immutable 14.4 KB depth field");
   GlassCheck(crystalPaint.GetTexture("_MysticReceiver")==neon.MysticWallReceiver,label+" travelling light receiver matches this maze");
   GlassCheck(Shader.GetGlobalFloat("_MysticStarStrength")==1&&Shader.GetGlobalFloat("_MysticLightMix")==1,label+" vivid stars and travelling lights enabled");
   GlassCheck(Shader.IsKeywordEnabled("MB_SIXTEEN_WALL_LIGHTS")== (NativeLevelAtmosphere.ActiveStreams==16)&&Shader.IsKeywordEnabled("MB_EIGHT_WALL_LIGHTS")== (NativeLevelAtmosphere.ActiveStreams==8),label+" wall-light GPU variant matches active count");
   if(!images)return;
   string beforeLogic=SceneClockState(),beforeAuras=GlassAuraState();double saved=levelAtmosphereSeconds;
   levelAtmosphereSeconds=0;preparationLightFrame=true;Render();var dark=PreparationPixels(target);GlassCapture("atmosphere-dark");
   levelAtmosphereSeconds=3;preparationLightFrame=true;Render();var bright=PreparationPixels(target);GlassCapture("atmosphere-bright");
   int different=0;long brighter=0;for(int i=0;i<dark.Length;i++){int delta=bright[i].r+bright[i].g+bright[i].b-dark[i].r-dark[i].g-dark[i].b;if(Math.Abs(delta)>6)different++;brighter+=delta;}
   GlassCheck(different>target.width&&brighter>0,"bright phase visibly reveals the approved glass material");
   levelAtmosphereSeconds=6;preparationLightFrame=true;Render();var stars=PreparationPixels(target);int skyChanges=0;
   // Fixed overview includes exterior sky above the level, independently of
   // character animation and travelling wall highlights.
   for(int i=target.width*(target.height*24/25);i<stars.Length;i++)if(Math.Abs(stars[i].r-dark[i].r)+Math.Abs(stars[i].g-dark[i].g)+Math.Abs(stars[i].b-dark[i].b)>6)skyChanges++;
   GlassCheck(skyChanges>8,"individual sky stars change while the maze returns to the same phase");
   levelAtmosphereSeconds=0;preparationLightFrame=true;Render();var restored=PreparationPixels(target);
   GlassCheck(dark.SequenceEqual(restored),"same visual clock restores every pixel exactly");
   GlassCheck(SceneClockState()==beforeLogic&&GlassAuraState()==beforeAuras,"atmosphere does not advance gameplay RNG or actor animation clocks");
   levelAtmosphereSeconds=saved;preparationLightFrame=true;Render();
  }
 }
}

using System;using UnityEngine;using UnityEngine.Rendering;
namespace MazeBiters.NativeStudy {
 // Original 24-event pool, 82 ms impact, colour cloud and four mouth-bound motes.
 public sealed class NativeBiteBloom:IDisposable {
  sealed class Effect {public bool active;public double at;public Vector2Int cell,dir;public int serial,palette;public NativePlayer player;}
  readonly Effect[] pool=new Effect[24];readonly Texture2D[] textures=new Texture2D[25];readonly Material[] paint=new Material[25];readonly MaterialPropertyBlock block=new MaterialPropertyBlock();readonly Mesh quad;int cursor,serial;
  public NativeBiteBloom(Mesh quad,bool deferred=false){this.quad=quad;for(int i=0;i<pool.Length;i++)pool[i]=new Effect();if(!deferred)foreach(var step in LoadSteps()){} }
  public System.Collections.Generic.IEnumerable<object> LoadSteps(){for(int i=0;i<25;i++){string name=i==0?"flash":((i-1)/2>=9?"Player"+((i-1)/2-8):(i-1)/2>=6?new[]{"Hunter1","Hunter3","Hunter4"}[(i-1)/2-6]:(i-1)/2==5?"Scorpion":NativeGameplayStudy.Colors[(i-1)/2])+((i-1)%2==0?"-cloud":"-particle");textures[i]=NativeLightField.Load("bite-"+name+".png",true);paint[i]=new Material(Shader.Find("MazeBiters/PremultipliedImage")){mainTexture=textures[i]};yield return null;}}
  public void Reset(){foreach(var p in pool)p.active=false;cursor=serial=0;}
  public void Add(Vector2Int cell,int palette,NativePlayer p,double t){int selected=-1,oldest=cursor;double old=double.PositiveInfinity;for(int offset=0;offset<24;offset++){int i=(cursor+offset)%24;var e=pool[i];if(!e.active||t-e.at>=340){selected=i;break;}if(e.at<old){old=e.at;oldest=i;}}if(selected<0)selected=oldest;cursor=(selected+1)%24;var effect=pool[selected];effect.active=true;effect.cell=cell;effect.palette=palette;effect.player=p;effect.at=t;effect.serial=serial++;if(p==null){effect.dir=Vector2Int.zero;return;}var move=p.Cell-p.Previous;effect.dir=new Vector2Int(move.x!=0?move.x:move.y==0?(p.Dir.x==0?1:p.Dir.x):0,move.y!=0?move.y:move.x==0?p.Dir.y:0);}
  // Reuses the warmed impact/cloud pool, without motes aimed at a player.
  public void AddImpact(Vector2Int cell,int palette,double t)=>Add(cell,palette,null,t);
  void Image(CommandBuffer c,int index,double x,double y,double size,double opacity){block.SetFloat("_Opacity",(float)opacity);c.DrawMesh(quad,Matrix4x4.TRS(new Vector3((float)(x-size/2),(float)(-y+size/2),0),Quaternion.identity,new Vector3((float)size,(float)size,1)),paint[index],0,0,block);}
  public void Draw(CommandBuffer c,double t,bool preserve=false){foreach(var e in pool){double age=t-e.at;if(!e.active||age<0)continue;if(age>=340){if(!preserve){e.active=false;e.player=null;}continue;}double x=(e.cell.x+.5)*16,y=(e.cell.y+.5)*16;
    if(age>=18&&age<260){double p=(age-18)/242;Image(c,1+e.palette*2,x,y,16*(.72+.92*p),.62*4*p*(1-p));}
    if(age<82){double p=age/82;Image(c,0,x,y,16*(.58+.90*p),.96*(1-p)*(1-p));}
    if(age>=54&&e.player!=null){var v=e.player.Visual(t);double mx=(v.x+.5+e.player.Dir.x*.31)*16,my=(v.y+.5+e.player.Dir.y*.31)*16;for(int i=0;i<4;i++){double p=(age-54-i*15)/248;if(p<0||p>=1)continue;double side=new[]{-.22,.18,-.10,.26}[(i+e.serial)&3]*4*p*(1-p)*16;Image(c,2+e.palette*2,x+(mx-x)*p*p-e.dir.y*side,y+(my-y)*p*p+e.dir.x*side,16*(.22-.09*p),.86*Math.Min(1,p*6)*(1-p));}}
   }}
  public void Dispose(){foreach(var t in textures)UnityEngine.Object.Destroy(t);foreach(var m in paint)UnityEngine.Object.Destroy(m);}
 }
}

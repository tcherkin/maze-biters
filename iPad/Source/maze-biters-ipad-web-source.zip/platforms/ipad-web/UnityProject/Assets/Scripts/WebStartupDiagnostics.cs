using System;
using System.Collections.Generic;
using UnityEngine;

namespace MazeBiters.NativeStudy {
 // Opt-in observations only: a polling call never performs or advances loading.
 internal static class WebStartupDiagnostics {
  [Serializable] internal sealed class Stage {
   public string stage,pack;
   public long bytes;
   public double startedMs,elapsedMs;
   public int startFrame,frames,yields;
   public bool complete,focusedAtStart,focusedAtEnd;
  }
  [Serializable] sealed class Snapshot {
   public string revision="20261117-menu-bootstrap";
   public double elapsedMs;
   public int frames,frameRate,vSync;
   public bool focused,runInBackground;
   public Stage[] stages;
  }
  static bool enabled;
  static double began;
  static int firstFrame;
  static List<Stage> stages;
  internal static void Reset(){
   enabled=Application.absoluteURL.Contains("diagnostic=1");
   if(!enabled){stages=null;return;}
   began=Time.realtimeSinceStartupAsDouble;firstFrame=Time.frameCount;stages=new List<Stage>();
  }
  internal static int Begin(string stage,string pack=null,long bytes=0){
   if(!enabled)return -1;
   var row=new Stage{stage=stage,pack=pack,bytes=bytes,startedMs=(Time.realtimeSinceStartupAsDouble-began)*1000,startFrame=Time.frameCount,focusedAtStart=Application.isFocused};
   stages.Add(row);return stages.Count-1;
  }
  internal static void Yield(int index){if(enabled&&index>=0)stages[index].yields++;}
  internal static void End(int index,bool complete=true){
   if(!enabled||index<0)return;
   var row=stages[index];row.elapsedMs=(Time.realtimeSinceStartupAsDouble-began)*1000-row.startedMs;row.frames=Time.frameCount-row.startFrame;row.complete=complete;row.focusedAtEnd=Application.isFocused;
  }
  internal static void Mark(string stage){int index=Begin(stage);End(index);}
  internal static IEnumerable<object> Trace(string stage,string pack,long bytes,IEnumerable<object> steps){
   int index=Begin(stage,pack,bytes);bool complete=false;
   try{foreach(var step in steps){Yield(index);yield return step;}complete=true;}
   finally{End(index,complete);}
  }
  internal static string AppendTo(string state){
   if(!enabled||string.IsNullOrEmpty(state)||state[state.Length-1]!='}')return state;
   return state.Substring(0,state.Length-1)+",\"startup\":"+JsonUtility.ToJson(new Snapshot{elapsedMs=(Time.realtimeSinceStartupAsDouble-began)*1000,frames=Time.frameCount-firstFrame,frameRate=Application.targetFrameRate,vSync=QualitySettings.vSyncCount,focused=Application.isFocused,runInBackground=Application.runInBackground,stages=stages.ToArray()})+"}";
  }
 }
}

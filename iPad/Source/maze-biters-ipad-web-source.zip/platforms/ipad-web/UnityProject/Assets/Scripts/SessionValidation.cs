using System;using System.IO;using System.Linq;using UnityEngine;
namespace MazeBiters.NativeStudy {
 [Serializable] sealed class SessionMusicTest {public int seed,draws;public string[] tracks;}
 [Serializable] sealed class SessionOracle {public SessionSpawnTest[] spawns;public SessionDeathTest[] deaths;public SessionPulse[] pulses;public SessionMusicTest[] music;}
 [Serializable] sealed class SessionSpawnTest {public int level,seed,draws,mass;public SessionSpawnSnake[] snakes;}
 [Serializable] sealed class SessionSpawnSnake {public Vector2Int[] body;public Vector2Int dir;public int palette;public double temperament,turn;}
 [Serializable] sealed class SessionDeathTest {public int seed;public string blocker;public SessionDeathExpected death;public SessionDeathSample[] samples;}
 [Serializable] sealed class SessionDeathExpected {public int draws,lives;public double respawn;public string[] sounds;public SessionAnger snake,hunter;}
 [Serializable] sealed class SessionAnger {public double anger,angerPeak,angerFloor,lastAngerTime;public double[] threatByPlayer;}
 [Serializable] sealed class SessionDeathSample {public double time,shield,alpha;public bool dead,hidden,bright;}
 [Serializable] sealed class SessionPulse {public double time,alpha;public bool bright;}
 [Serializable] public sealed class SessionLogicResult {public bool passed=true;public int assertions,spawnCases,deathCases,pulseCases;public string note="Exact frozen JS functions and identical seeded RNG; original population, death/calming, blocked respawn, shield, completion timing. Additional bonus/music/level-state invariants. Single-player fixed catalogue, not full-game parity.";}
 public static class SessionValidation {
  sealed class Tape{uint state;public int Draws;public Tape(int seed){state=(uint)seed;}public double Next(){Draws++;unchecked{state+=0x6D2B79F5;uint v=(state^(state>>15))*(1|state);v^=v+(v^(v>>7))*(61|v);return (v^(v>>14))/4294967296.0;}}}
  public static SessionLogicResult Run(){
   var o=JsonUtility.FromJson<SessionOracle>(File.ReadAllText(Path.Combine(WebFiles.Root,"Reference/session-oracle.json")));var result=new SessionLogicResult();
   void Check(bool ok,string text){result.assertions++;if(!ok)throw new Exception("SESSION PARITY "+text);}
   void Near(double a,double b,string text)=>Check(Math.Abs(a-b)<1e-7,text+" "+a.ToString("R")+" != "+b.ToString("R"));
   NativeGameplayWorld World(Tape rng,int level=1){var w=new NativeGameplayWorld(NativeLevelCatalogue.Get(level).geometry,rng.Next){UseLegacyAi=true,Level=level,PlayerStart=new Vector2Int(1,1),SessionEnabled=true,LevelLoader=NativeLevelCatalogue.Get};w.Player.Cell=w.Player.From=w.PlayerStart;return w;}
   foreach(var test in o.spawns){var tape=new Tape(test.seed);var w=World(tape,test.level);w.SpawnLevelSnakes();Check(tape.Draws==test.draws,"spawn RNG "+test.level+"/"+test.seed+" "+tape.Draws+"/"+test.draws);Check(w.StartingSnakeMass==test.mass&&w.Snakes.Count==test.snakes.Length,"spawn population");for(int i=0;i<test.snakes.Length;i++){var a=w.Snakes[i];var b=test.snakes[i];Check(a.Body.SequenceEqual(b.body)&&a.Dir==b.dir&&a.Palette==b.palette,"spawn body/direction/palette "+test.level+"/"+i);Near(a.Temperament,b.temperament,"temperament");Near(a.TurnBias,b.turn,"turn bias");}result.spawnCases++;}
   foreach(var test in o.deaths){var tape=new Tape(test.seed);var w=World(tape);var s=new NativeGameplaySnake{Body=new System.Collections.Generic.List<Vector2Int>{new Vector2Int(5,1)},Threat=8,Anger=9,AngerPeak=12,AngerFloor=5};var h=new NativeHunter{Cell=new Vector2Int(7,1),Threat=3,Anger=.1};w.Snakes.Add(s);w.Hunters.Add(h);var sounds=new System.Collections.Generic.List<string>();w.Event=e=>{if(e.Kind=="sound")sounds.Add(e.Sound);};w.Player.Score=1235;w.SessionDeath();
    var d=test.death;Check(tape.Draws==d.draws&&sounds.SequenceEqual(d.sounds),"death RNG/sounds");Near(s.Threat,d.snake.threatByPlayer[0],"calm threat");Near(s.Anger,d.snake.anger,"calm anger");Near(s.AngerPeak,d.snake.angerPeak,"calm peak");Near(s.AngerFloor,d.snake.angerFloor,"calm floor");Near(h.Anger,d.hunter.anger,"hunter calm");Near(h.Threat,d.hunter.threatByPlayer[0],"hunter threat");Near(w.Player.RespawnAt,d.respawn,"death timing");Check(w.Player.Lives==d.lives,"death lives");
    w.Snakes.Clear();w.Hunters.Clear();switch(test.blocker){case "snake":w.Snakes.Add(new NativeGameplaySnake{Body=new System.Collections.Generic.List<Vector2Int>{w.PlayerStart}});break;case "hunter":w.Hunters.Add(new NativeHunter{Cell=w.PlayerStart});break;case "scorpion-head":w.PlaceScorpion(w.PlayerStart,Vector2Int.left);break;case "scorpion-tail":w.PlaceScorpion(w.PlayerStart+Vector2Int.right,Vector2Int.right);break;case "egg":w.Eggs.Add(new NativeEgg{Cell=w.PlayerStart});break;case "fruit":w.Fruits.Add(new NativeFruit{Cell=w.PlayerStart});break;}
    foreach(var sample in test.samples){w.Time=sample.time;if(w.Time==4100){w.Snakes.Clear();w.Hunters.Clear();w.Scorpion=null;w.Eggs.Clear();}w.SessionTick();Check(w.Player.Dead==sample.dead&&w.Player.HideDeath==sample.hidden&&w.Player.ShieldBright==sample.bright,test.blocker+" death/shield state @"+sample.time);Near(w.Player.ShieldUntil,sample.shield,"shield expiry");Near(NativeGameplayWorld.Pulse(w.Time-1000,872,3),sample.alpha,"death pulse");Check(w.Player.Score==1235,"score survives respawn");}result.deathCases++;
   }
   foreach(var p in o.pulses){var w=World(new Tape(1));w.Transition=true;w.TransitionAt=1000;w.Time=p.time;Near(w.StatusAlpha,p.alpha,"completion alpha");Check(w.CompletionBright==p.bright,"completion flash");result.pulseCases++;}
   {var w=World(new Tape(7));w.Player.Lives=8;w.Award(15000);Check(w.Player.Lives==9&&w.Player.NextLifeScore==25000,"bonus cap thresholds");w.Player.Lives=8;w.Award(25);Check(w.Player.Lives==8,"no life backlog");w.Snakes.Clear();w.Player.BiteEnd=1150;w.CheckLevelComplete();Check(w.Transition&&w.RevealAt==1150,"last swallow reveal");w.Time=4487;w.SessionTick();Check(w.Level==1,"no early next level");w.Time=4488;w.SessionTick();Check(w.Level==2&&w.Snakes.Count==4&&w.Player.Score==15525&&w.Player.Lives==8&&w.Player.Waiting,"next-level preserved state");Check(w.Player.Dir==new Vector2Int(0,1)&&w.Player.ShieldUntil==8848,"original spawn direction/shield");Check(w.Grid.SequenceEqual(NativeLevelCatalogue.Get(2).geometry),"original next maze");w.Player.Lives=1;w.SessionDeath();Check(w.GameOverPending,"final death pending");w.Time+=2834;w.RealTime=7000;w.SessionTick();Check(w.GameOver&&!w.GameOverPending&&w.Player.HideDeath,"game over after skull");w.RealTime+=NativeGameplayWorld.GameOverDuration;Near(w.MusicGain,0,"music ending");}
   for(int n=1;n<=100;n++){var l=NativeLevelCatalogue.Get(n);Check(l!=null&&l.geometry.Length==25&&l.geometry.All(row=>row.Length==36)&&l.geometry[1][1]!='#',"catalogue "+n);}Check(NativeLevelCatalogue.Get(101)==null,"catalogue bound");
   foreach(var m in o.music){var tape=new Tape(m.seed);var w=World(tape);for(int i=0;i<m.tracks.Length;i++){Check(w.ReserveMusic(i+1)==m.tracks[i],"original music sequence "+i);Check(w.ReserveMusic(i+1)==m.tracks[i],"reservation reused");}Check(tape.Draws==m.draws,"music RNG");}
   {var tape=new Tape(7);var w=World(tape);var sounds=new System.Collections.Generic.List<string>();w.Event=e=>{if(e.Kind=="sound")sounds.Add(e.Sound);};var snake=new NativeGameplaySnake{Body=new System.Collections.Generic.List<Vector2Int>{new Vector2Int(5,1),new Vector2Int(4,1),new Vector2Int(3,1)},Dir=Vector2Int.right};w.Snakes.Add(snake);w.ActivatePower();Check(sounds.SequenceEqual(new[]{"snakeSTART@"})&&tape.Draws==0,"power activation sound / no RNG");sounds.Clear();w.PowerEatHead(snake);Check(sounds.SequenceEqual(new[]{"HeadEat"})&&tape.Draws==1,"powered head sound, not body sound / RNG");}
   {
    var tape=new Tape(31);var w=World(tape);var sounds=new System.Collections.Generic.List<NativeWorldEvent>();w.Event=e=>{if(e.Kind=="sound")sounds.Add(e);};
    // Original checkWorldContact: fruit sound, optional bonus life, power cue.
    // Exercise all fruits, refreshing during acceleration/plateau/deceleration.
    double[] times={1000,1500,3000,8500};
    for(int kind=0;kind<4;kind++){
     w.Time=times[kind];sounds.Clear();int draws=tape.Draws;w.Fruits.Add(new NativeFruit{Cell=w.Player.Cell,Kind=kind});w.CollectFruit();
     Check(sounds.Count==2&&sounds[0].Sound.StartsWith("EatFruit",StringComparison.Ordinal)&&sounds[1].Sound=="snakeSTART@","fruit + power cue "+kind);
     Check(sounds.All(s=>s.Cell==w.Player.Cell&&!s.GlobalSound&&s.Time==w.Time),"power cue original position/clock");
     Check(w.Fruits.Count==0&&w.Power&&w.Player.PowerUntil==w.Time+7000&&tape.Draws==draws+1,"power refresh and unchanged fruit RNG");
     sounds.Clear();w.CollectFruit();w.UpdatePower();Check(sounds.Count==0,"no replay without a new fruit");
    }
    w.Time+=4000;sounds.Clear();w.UpdatePower();Check(sounds.Count==1&&sounds[0].Sound=="Tick","original power warning boundary");
    w.Time+=319;sounds.Clear();w.UpdatePower();Check(sounds.Count==0,"no early warning tick");w.Time++;w.UpdatePower();Check(sounds.Count==1&&sounds[0].Sound=="Tick","original warning cadence");
    w.Time=w.Player.PowerUntil;sounds.Clear();w.UpdatePower();Check(!w.Power&&sounds.Count==0,"power expiry does not replay activation");
    w.ActivateShield();Check(sounds.Count==0,"spawn protection does not play fruit power cue");
    w.Player.Score=4990;w.Player.ExactScore=4990;w.Player.NextLifeScore=5000;w.Player.Lives=3;w.Fruits.Add(new NativeFruit{Cell=w.Player.Cell,Kind=0});w.CollectFruit();
    Check(sounds.Count==3&&sounds[0].Sound.StartsWith("EatFruit",StringComparison.Ordinal)&&sounds[1].Sound=="BonusLife@"&&sounds[2].Sound=="snakeSTART@","original fruit/bonus/power sound order");
   }
   {var w=World(new Tape(34),100);w.CheckLevelComplete();w.Time=4488;w.SessionTick();Check(w.CatalogueFinished&&!w.Transition&&w.Level==100&&w.MusicGain==0,"finite catalogue does not wrap / revive music");}
   return result;
  }
 }
}

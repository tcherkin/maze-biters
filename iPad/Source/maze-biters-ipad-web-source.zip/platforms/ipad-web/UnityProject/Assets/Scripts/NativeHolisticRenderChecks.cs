#if UNITY_EDITOR
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Reflection;
using System.Runtime.Serialization;
using UnityEngine;

namespace MazeBiters.NativeStudy {
 [Serializable]public sealed class HolisticRenderBench {public string kind,variant;public int round,iterations;public double elapsedMs;}
 [Serializable]public sealed class HolisticRuntimeRenderReport {
  public bool passed;public string error;
  public string scope="Web-copy CPU-only exact Unity mesh/material/active-light-record checks. Audit instances use tiny dummy texture slots and real Mesh objects, with no GPU resolve targets, graphics execution or real source texture leases. Separate warmed microbench timings are editor CPU samples, not physical iPad/GPU/FPS claims.";
  public int quadCases,snakeCases,ownerCases,cullCases,lightCases,activeRecords,recordFloats,meshValues,checks,kernelWidth;
  public List<HolisticRenderBench> benchmarks=new List<HolisticRenderBench>();
 }
 internal static class HolisticRenderChecks {
  internal static void Check(bool value,string message,HolisticRuntimeRenderReport report){report.checks++;if(!value)throw new InvalidOperationException("Holistic runtime render: "+message);}
  internal static bool F(float a,float b)=>NativeMazeArtwork.HolisticSame(a,b);
  internal static bool V(Vector2 a,Vector2 b)=>F(a.x,b.x)&&F(a.y,b.y);
  internal static bool V(Vector3 a,Vector3 b)=>F(a.x,b.x)&&F(a.y,b.y)&&F(a.z,b.z);
  internal static bool C(Color a,Color b)=>F(a.r,b.r)&&F(a.g,b.g)&&F(a.b,b.b)&&F(a.a,b.a);
  internal static void Mesh(Mesh a,Mesh b,HolisticRuntimeRenderReport report,string label){
   var av=a.vertices;var bv=b.vertices;var au=a.uv;var bu=b.uv;var ai=a.triangles;var bi=b.triangles;
   Check(av.Length==bv.Length&&au.Length==bu.Length&&ai.Length==bi.Length,label+" mesh sizes",report);
   for(int i=0;i<av.Length;i++){Check(V(av[i],bv[i]),label+" vertex "+i,report);report.meshValues+=3;}
   for(int i=0;i<au.Length;i++){Check(V(au[i],bu[i]),label+" UV "+i,report);report.meshValues+=2;}
   for(int i=0;i<ai.Length;i++){Check(ai[i]==bi[i],label+" triangle "+i,report);report.meshValues++;}
   var ac=a.colors;var bc=b.colors;Check(ac.Length==bc.Length,label+" color size",report);for(int i=0;i<ac.Length;i++)Check(C(ac[i],bc[i]),label+" color "+i,report);
   Check(V(a.bounds.center,b.bounds.center)&&V(a.bounds.extents,b.bounds.extents),label+" exact bounds",report);
  }
 }
 public sealed partial class NativeSnake {
  // Validation-only construction avoids source texture decoding and GPU targets.
  // The same production Prepare/SubmitQuad/material functions are exercised.
  NativeSnake(int audit,NativeSnake owner=null,bool tailTexturesOnly=false){
   Palette="audit";geometryOwner=owner;
   if(owner!=null){outline=owner.outline;strips=owner.strips;headMesh=owner.headMesh;ov=owner.ov;sv=owner.sv;uv=owner.uv;oi=owner.oi;si=owner.si;}
   else{outline=new Mesh();strips=new Mesh();headMesh=new Mesh();ov=new List<Vector3>(2048);sv=new List<Vector3>(4096);uv=new List<Vector2>(4096);oi=new List<int>(6000);si=new List<int>(12000);}
   if(!tailTexturesOnly){mouth=new Texture2D(2,2){name="audit-mouth"};solo=new Texture2D(2,2){name="audit-solo"};}
   materialTexture=new Texture2D(2,2){name="audit-material"};stripPaint=new Material(Shader.Find("MazeBiters/SnakeSurface")){mainTexture=materialTexture};outlinePaint=new Material(stripPaint);headPaint=new Material(Shader.Find("MazeBiters/SnakeHead"));
  }
  static void DisposeAudit(IEnumerable<NativeSnake> snakes){var objects=new HashSet<UnityEngine.Object>();foreach(var snake in snakes)foreach(var f in typeof(NativeSnake).GetFields(BindingFlags.Instance|BindingFlags.NonPublic|BindingFlags.Public))if(typeof(UnityEngine.Object).IsAssignableFrom(f.FieldType)){var obj=f.GetValue(snake) as UnityEngine.Object;if(obj)objects.Add(obj);}foreach(var obj in objects)UnityEngine.Object.DestroyImmediate(obj);}
  static void CompareSnake(NativeSnake a,NativeSnake b,HolisticRuntimeRenderReport report,string label){
   HolisticRenderChecks.Mesh(a.outline,b.outline,report,label+" outline");HolisticRenderChecks.Mesh(a.strips,b.strips,report,label+" strips");HolisticRenderChecks.Mesh(a.headMesh,b.headMesh,report,label+" head");
   HolisticRenderChecks.Check(HolisticRenderChecks.F(a.headPaint.GetFloat("_Nape"),b.headPaint.GetFloat("_Nape"))&&HolisticRenderChecks.F(a.headPaint.GetFloat("_Opacity"),b.headPaint.GetFloat("_Opacity")),label+" head material values",report);
   HolisticRenderChecks.Check((a.headPaint.mainTexture?a.headPaint.mainTexture.name:null)==(b.headPaint.mainTexture?b.headPaint.mainTexture.name:null),label+" selected texture slot",report);
   HolisticRenderChecks.Check(a.Culled==b.Culled&&a.ReadyForCulling==b.ReadyForCulling&&a.intakeOnly==b.intakeOnly,label+" culling/intake state",report);
  }
  internal static List<SnakePose> HolisticPoses(){
   var points=new[]{new Vector2Int(5,5),new Vector2Int(6,5),new Vector2Int(7,5),new Vector2Int(7,6),new Vector2Int(7,7),new Vector2Int(8,7),new Vector2Int(9,7),new Vector2Int(9,8),new Vector2Int(9,9),new Vector2Int(8,9),new Vector2Int(7,9)};
   var rail=new SnakeRail(points);var result=new List<SnakePose>();
   for(int i=0;i<80;i++){
    bool single=i%11==0;double phase=(i%17)/16.0,head=180+i*2.71;
    var p=new SnakePose{rail=rail,head=head,length=single?SnakeMotion.Head:90+(i%9)*17,compression=(i%5)*1.3,phase=phase,frontMaterial=200+i*.37,materialSign=i%3==0?-1:1,solo=single,soloAmount=single?1:i%9==0?.45:0,birthProgress=i%7==0?.15+(i%5)*.17:1,rearBirth=i%7==0,mouthOverride=i%4==0?i%97:-1};
    if(i%6==0)p.rigidRear=new RailPoint{x=230+i,y=200-i,angle=i*.19,tx=Math.Cos(i*.19),ty=Math.Sin(i*.19)};
    if(i%8==0){p.paintScale=.88;p.paintAngle=.21;p.paintX=3;p.paintY=-2;p.paintPivotX=250;p.paintPivotY=200;}
    if(i%5==0){p.bendSpan=35;p.bendDx=4;p.bendDy=-3;}result.Add(p);
   }
   return result;
  }
  public static HolisticRuntimeRenderReport ValidateHolisticRuntimeRender(){
   bool mesh=NativeHolisticTuning.MeshSubmission,receivers=NativeHolisticTuning.LightReceivers,trig=NativeHolisticTuning.LightHeadTrig,capture=NativePoseCache.Capture,population=IpadPopulationOptimization.Enabled;
   var report=new HolisticRuntimeRenderReport();
   try{NativePoseCache.Capture=false;VisibilityPreparation.End();AuditQuad(report);AuditSnakes(report);NativeLightField.AuditHolisticLights(report);report.passed=true;}
   catch(Exception error){report.error=error.ToString();report.passed=false;}
   finally{NativeHolisticTuning.MeshSubmission=mesh;NativeHolisticTuning.LightReceivers=receivers;NativeHolisticTuning.LightHeadTrig=trig;NativePoseCache.Capture=capture;IpadPopulationOptimization.Enabled=population;VisibilityPreparation.End();}
   return report;
  }
  static void AuditQuad(HolisticRuntimeRenderReport report){
   var reference=new Mesh();var candidate=new Mesh();var a=new QuadSubmission();var b=new QuadSubmission();var vertices=new Vector3[4];var tex=new Vector2[4];
   try{
    for(int i=0;i<160;i++){
     float x=(i/3)*.17f,y=(i/7)*-.13f,w=1+(i%5)*.1f,h=2+(i%9)*.03f;vertices[0]=new Vector3(x,y);vertices[1]=new Vector3(x+w,y);vertices[2]=new Vector3(x+w,y+h);vertices[3]=new Vector3(x,y+h);
     float u=(i%9)/9f,v=(i%11)/11f;tex[0]=new Vector2(u,v);tex[1]=new Vector2(u+.1f,v);tex[2]=new Vector2(u+.1f,v+.08f);tex[3]=new Vector2(u,v+.08f);
     NativeHolisticTuning.MeshSubmission=false;SubmitQuad(reference,vertices,tex,a);
     // Periodic reference frames on the candidate exercise A/B invalidation.
     NativeHolisticTuning.MeshSubmission=i%13!=0;SubmitQuad(candidate,vertices,tex,b);HolisticRenderChecks.Mesh(reference,candidate,report,"quad "+i);report.quadCases++;
    }
    for(int round=0;round<3;round++)foreach(bool retained in new[]{false,true}){
     NativeHolisticTuning.MeshSubmission=retained;for(int i=0;i<100;i++)SubmitQuad(candidate,vertices,tex,b);
     var watch=Stopwatch.StartNew();const int count=20000;for(int i=0;i<count;i++){if(i%5==0){float x=i*.001f;vertices[0].x=x;vertices[3].x=x;}if(i%7==0)tex[0].x=(i%9)/9f;SubmitQuad(candidate,vertices,tex,b);}
     report.benchmarks.Add(new HolisticRenderBench{kind="quad-submission",variant=retained?"retained":"reference",round=round,iterations=count,elapsedMs=watch.Elapsed.TotalMilliseconds});
    }
   }finally{UnityEngine.Object.DestroyImmediate(reference);UnityEngine.Object.DestroyImmediate(candidate);}
  }
  static void AuditSnakes(HolisticRuntimeRenderReport report){
   var a=new NativeSnake(1);var b=new NativeSnake(1);var ae=new NativeSnake(1,a);var be=new NativeSnake(1,b);var at=new NativeSnake(1,a,true);var bt=new NativeSnake(1,b,true);var all=new[]{a,b,ae,be,at,bt};
   try{foreach(bool population in new[]{false,true}){IpadPopulationOptimization.Enabled=population;int index=0;foreach(var pose in HolisticPoses()){
    bool tail=index%10==0;NativeHolisticTuning.MeshSubmission=false;a.Prepare(pose,tail);ae.Prepare(pose,tail);at.Prepare(pose,true);
    NativeHolisticTuning.MeshSubmission=true;b.Prepare(pose,tail);be.Prepare(pose,tail);bt.Prepare(pose,true);
    CompareSnake(a,b,report,"snake "+index);CompareSnake(ae,be,report,"geometry-owner "+index);CompareSnake(at,bt,report,"tail-only owner "+index);report.snakeCases++;report.ownerCases+=2;
    HolisticRenderChecks.Check(ReferenceEquals(a.headMesh,ae.headMesh)&&ReferenceEquals(b.headMesh,be.headMesh),"geometry mesh sharing preserved",report);
    if(index%9==0){a.Cull(pose);b.Cull(pose);ae.Prepare(pose,tail);be.Prepare(pose,tail);CompareSnake(ae,be,report,"culled owner");report.cullCases++;a.Prepare(pose,tail);b.Prepare(pose,tail);ae.Prepare(pose,tail);be.Prepare(pose,tail);CompareSnake(ae,be,report,"restored owner");}
    if(index%7==0){NativeHolisticTuning.MeshSubmission=false;b.Prepare(pose,tail);NativeHolisticTuning.MeshSubmission=true;b.Prepare(pose,tail);CompareSnake(a,b,report,"A/B reused pose");}index++;
   }}}
   finally{DisposeAudit(all);}
  }
 }
 public sealed partial class NativeLightField {
  static readonly BindingFlags AuditFields=BindingFlags.Instance|BindingFlags.Public|BindingFlags.NonPublic;
  static object AuditGet(object owner,string field)=>owner.GetType().GetField(field,AuditFields).GetValue(owner);
  static void AuditSet(object owner,string field,object value)=>owner.GetType().GetField(field,AuditFields).SetValue(owner,value);
  static Batch AuditBatch(bool walls,float atlasWidth){
   var batch=(Batch)FormatterServices.GetUninitializedObject(typeof(Batch));AuditSet(batch,"walls",walls);AuditSet(batch,"atlasWidth",atlasWidth);AuditSet(batch,"records",new Color[40*Capacity]);AuditSet(batch,"rectangles",new Vector4[36]);AuditSet(batch,"v",new List<Vector3>(Capacity*4));AuditSet(batch,"uv",new List<Vector2>(Capacity*4));AuditSet(batch,"ids",new List<int>(Capacity*6));return batch;
  }
  NativeLightField(string[] geometry,int audit){grid=geometry;receiverFlags=new byte[grid[0].Length,grid.Length];corridorKinds=new byte[2,grid[0].Length,grid.Length];PrepareTopology();PrepareFloorReceivers();var png=File.ReadAllBytes(Path.Combine(WebFiles.Root,"Reference/neon-fruit-kernels.png"));int width=(png[16]<<24)|(png[17]<<16)|(png[18]<<8)|png[19];floor=AuditBatch(false,width);wall=AuditBatch(true,width);}
  static void CompareBatch(Batch a,Batch b,HolisticRuntimeRenderReport report,string label){
   int count=(int)AuditGet(a,"count");HolisticRenderChecks.Check(count==(int)AuditGet(b,"count"),label+" count",report);var ar=(Color[])AuditGet(a,"records");var br=(Color[])AuditGet(b,"records");
   for(int i=0;i<count;i++){int number=(int)ar[i*40+3].r;HolisticRenderChecks.Check(number==(int)br[i*40+3].r&&number>=0&&number<=36,label+" active blocker count",report);for(int n=0;n<4+number;n++){HolisticRenderChecks.Check(HolisticRenderChecks.C(ar[i*40+n],br[i*40+n]),label+" active record "+i+"/"+n,report);report.recordFloats+=4;}report.activeRecords++;}
   foreach(string key in new[]{"v","uv","ids"}){
    if(key=="v"){var av=(List<Vector3>)AuditGet(a,key);var bv=(List<Vector3>)AuditGet(b,key);HolisticRenderChecks.Check(av.Count==bv.Count,label+" vertex size",report);for(int i=0;i<av.Count;i++)HolisticRenderChecks.Check(HolisticRenderChecks.V(av[i],bv[i]),label+" vertex "+i,report);}
    else if(key=="uv"){var av=(List<Vector2>)AuditGet(a,key);var bv=(List<Vector2>)AuditGet(b,key);HolisticRenderChecks.Check(av.Count==bv.Count,label+" UV size",report);for(int i=0;i<av.Count;i++)HolisticRenderChecks.Check(HolisticRenderChecks.V(av[i],bv[i]),label+" UV "+i,report);}
    else{var av=(List<int>)AuditGet(a,key);var bv=(List<int>)AuditGet(b,key);HolisticRenderChecks.Check(av.Count==bv.Count,label+" triangle size",report);for(int i=0;i<av.Count;i++)HolisticRenderChecks.Check(av[i]==bv[i],label+" triangle "+i,report);}
   }
  }
  internal static void AuditHolisticLights(HolisticRuntimeRenderReport report){
   foreach(int level in new[]{1,25,91,100}){
    var source=NativeCampaignComposition.Generate((uint)(811+level),level,NativeMazeGenerator.Difficulties[2]);var a=new NativeLightField(source.geometry,1);var b=new NativeLightField(source.geometry,1);
    report.kernelWidth=(int)(float)AuditGet(a.floor,"atlasWidth");
    try{
     var points=new List<Vector2>();for(int y=0;y<25;y++)for(int x=0;x<36;x++)if(source.geometry[y][x]!='#'){points.Add(new Vector2(x*16+1.60001f,y*16+14.39999f));points.Add(new Vector2(x*16+8,y*16+8));}
     foreach(string mode in new[]{"receivers","trig","all"})for(int group=0;group<8;group++){
      void Fill(NativeLightField field){field.Begin();for(int i=group;i<points.Count;i+=8){var p=points[i];field.Point(p.x,p.y,i%15,.25+(i%4)*.2);}int iPose=0;foreach(var pose in NativeSnake.HolisticPoses()){if(iPose++%8==group)field.Snake(pose,iPose%8);}}
      NativeHolisticTuning.LightReceivers=false;NativeHolisticTuning.LightHeadTrig=false;Fill(a);
      NativeHolisticTuning.LightReceivers=mode!="trig";NativeHolisticTuning.LightHeadTrig=mode!="receivers";Fill(b);
      CompareBatch(a.floor,b.floor,report,"floor "+level+"/"+mode+"/"+group);CompareBatch(a.wall,b.wall,report,"wall "+level+"/"+mode+"/"+group);report.lightCases++;
     }
     if(level==91){var poses=NativeSnake.HolisticPoses();foreach(string mode in new[]{"reference","receivers","trig","all"})for(int round=0;round<3;round++){
      NativeHolisticTuning.LightReceivers=mode=="receivers"||mode=="all";NativeHolisticTuning.LightHeadTrig=mode=="trig"||mode=="all";
      void Frame(int frame){b.Begin();for(int i=0;i<8;i++)b.Snake(poses[(frame+i*7)%poses.Count],i);}
      for(int i=0;i<100;i++)Frame(i);var watch=Stopwatch.StartNew();const int frames=2000;for(int i=0;i<frames;i++)Frame(i);
      report.benchmarks.Add(new HolisticRenderBench{kind="light-records",variant=mode,round=round,iterations=frames,elapsedMs=watch.Elapsed.TotalMilliseconds});
     }}
    }finally{a.commands.Dispose();b.commands.Dispose();}
   }
  }
 }
}

#endif

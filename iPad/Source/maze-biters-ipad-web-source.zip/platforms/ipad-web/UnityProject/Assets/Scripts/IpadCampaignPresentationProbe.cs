using System;
using System.Collections;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using UnityEngine;
using Debug=UnityEngine.Debug;

namespace MazeBiters.NativeStudy {
 // Opt-in functional presentation probe. All state staging is confined to this
 // flag; normal Update/AI/gameplay is left unchanged outside the probe process.
 public sealed class IpadCampaignPresentationProbe:MonoBehaviour {
  string output;
  [RuntimeInitializeOnLoadMethod(RuntimeInitializeLoadType.AfterSceneLoad)]static void Boot(){
   var args=Environment.GetCommandLineArgs();if(!args.Contains("--ipad-campaign-probe"))return;
   int index=Array.IndexOf(args,"--report");
   var host=new GameObject("iPad campaign presentation functional probe").AddComponent<IpadCampaignPresentationProbe>();
   host.output=index>=0&&index+1<args.Length?Path.GetFullPath(args[index+1]):Path.Combine(Application.persistentDataPath,"ipad-campaign-probe.json");
   DontDestroyOnLoad(host.gameObject);
  }
  IEnumerator Start(){
   var wait=Stopwatch.StartNew();NativeGameplayStudy game=null;
   while(game==null){game=FindObjectsOfType<NativeGameplayStudy>().FirstOrDefault(g=>g.CampaignPresentationReady);if(wait.Elapsed.TotalSeconds>180){Fail("Prepared native scene did not become ready within180seconds.");yield break;}yield return null;}
   var probe=game.ProbeIpadCampaignPresentation(output);
   while(true){bool more;try{more=probe.MoveNext();}catch(Exception error){Fail(error.ToString());yield break;}if(!more)yield break;yield return probe.Current;}
  }
  void Fail(string error){Directory.CreateDirectory(Path.GetDirectoryName(output));File.WriteAllText(output,JsonUtility.ToJson(new IpadCampaignPresentationProbeResult{error=error},true));Debug.LogError("IPAD_CAMPAIGN_PRESENTATION_FAILED "+error);Application.Quit(2);}
 }
 [Serializable] public sealed class IpadCampaignPresentationProbeResult {
  public bool passed;public string error,quality,caption;
  public string scope="Staged native functional presentation checks, separate from live gameplay or device/performance claims. No world Tick, AI movement, contacts, forced wins or gameplay RNG advancement is used for the title captures.";
  public int checks,width,height,players;public bool crystalCores;public int wallLights;public float introSide;public List<string> assertions=new List<string>();public List<string> captures=new List<string>();
 }
 public sealed partial class NativeGameplayStudy {
  internal IEnumerator ProbeIpadCampaignPresentation(string output){
   Directory.CreateDirectory(Path.GetDirectoryName(output));var result=new IpadCampaignPresentationProbeResult{quality=quality};
   void Check(bool ok,string name){result.checks++;if(!ok)throw new InvalidOperationException("Level title: "+name);result.assertions.Add(name);}
   void Near(double a,double b,string name,double tolerance=.0001){Check(Math.Abs(a-b)<tolerance,name+" ("+a+", "+b+")");}
   void CaptureState(string label){string file=Path.ChangeExtension(output,null)+"-"+label+".png";Capture(file);result.captures.Add(file);}
   void Pure(HybridLevelTitleState state,object owner,object map,double epoch,double now,bool ready=true,bool pause=false,bool clear=false,bool dead=false,bool revealed=true,double clearAlpha=1){state.Tick(owner,map,epoch,now,ready,pause,clear,dead,revealed,clearAlpha);}
   // Independent envelope/lifecycle cases, using identities rather than Unity
   // objects. Hidden warmup cannot start or consume a future visible intro.
   var owner=new object();var map=new object();var state=new HybridLevelTitleState();
   Pure(state,owner,map,1000,1000,false);Pure(state,owner,map,1000,8000,false);
   Check(state.Mode==HybridLevelTitleMode.Hidden,"hidden preparation keeps title hidden");Near(state.Elapsed,0,"hidden preparation consumes no intro time");
   Pure(state,owner,map,1000,8000);Check(state.Mode==HybridLevelTitleMode.Intro,"first visible prepared render starts intro");Near(state.Elapsed,0,"intro begins at visible elapsed zero");
   Near(state.Scale,.88,"intro begins at88 percent scale");
   Pure(state,owner,map,1000,8125);double earlyAlpha=state.Alpha;Check(earlyAlpha>0&&earlyAlpha<1,"intro125ms is a partial fade in");
   Near(state.Alpha,.0196759259259,"intro125ms is only faintly visible");
   Near(state.Scale,.88515625,"intro125ms scale follows the slower one-second entry");
   Pure(state,owner,map,1000,8250);Near(state.Alpha,.074074074074,"intro250ms remains ghostly");Near(state.Scale,.89875,"intro250ms gently progresses through its longer zoom in");
   Pure(state,owner,map,1000,8500);Near(state.Alpha,.259259259259,"intro500ms continues the longer fade in");Near(state.Scale,.94,"intro500ms is halfway through the separate one-second zoom in");
   Pure(state,owner,map,1000,9000);Near(state.Scale,1,"intro1000ms completes the separate zoom in");
   Pure(state,owner,map,1000,9250);double heldAlpha=state.Alpha;Check(heldAlpha>earlyAlpha,"intro1250ms is fully presented");
   Near(state.Alpha,.925925925926,"intro1250ms is approaching full opacity");
   Near(state.Scale,1,"full hold keeps the original title scale");
   Pure(state,owner,map,1000,9625);Near(state.Alpha,1,"intro1625ms reaches full opacity near the middle");Near(state.Scale,1,"intro midpoint retains full scale");
   Pure(state,owner,map,1000,10250);Near(state.Scale,1,"intro2250ms starts its longer exit at full scale");
   Pure(state,owner,map,1000,10500);Near(state.Alpha,.5,"intro2500ms has faded to half opacity after the return sweep");Near(state.Scale,.98125,"intro2500ms gently begins its longer zoom out");
   Pure(state,owner,map,1000,10750);Near(state.Scale,.94,"intro2750ms is halfway through its longer zoom out");
   Pure(state,owner,map,1000,11000);Check(state.Alpha>0&&state.Alpha<heldAlpha,"intro3000ms is fading out");
   Near(state.Alpha,.074074074074,"intro3000ms is ghostly before disappearing");Near(state.Scale,.89875,"intro3000ms gently approaches the end of its longer zoom out");
   Pure(state,owner,map,1000,11300);Check(state.Mode==HybridLevelTitleMode.Hidden&&state.Alpha==0,"intro ends after3250ms");
   Pure(state,owner,map,1000,11500,pause:true);Pure(state,owner,map,1000,11750,pause:true);Check(state.Mode==HybridLevelTitleMode.Pause&&state.Alpha>0,"pause recalls title after intro expiry");
   Near(state.Scale,1,"pause subtitle is not part of the introductory zoom");
   Pure(state,owner,map,1000,11800,clear:true,revealed:false);Check(state.Alpha==0,"LEVEL CLEARED waits for original reveal gate");
   Pure(state,owner,map,1000,12100,clear:true,clearAlpha:1);Pure(state,owner,map,1000,12350,clear:true,clearAlpha:1);Check(state.Mode==HybridLevelTitleMode.Cleared&&state.Alpha>0,"revealed completion recalls title");
   Pure(state,owner,map,1000,12351,clear:true,clearAlpha:0);Near(state.Alpha,0,"completion subtitle follows original zero-alpha blink");
   Near(state.Scale,1,"completion blinking does not scale the subtitle");
   Pure(state,owner,map,1000,12400,pause:true,dead:true);Check(state.Mode==HybridLevelTitleMode.Hidden&&state.Alpha==0,"GAME OVER suppresses title even with pause flag");
   Pure(state,new object(),map,1000,13000);Near(state.Elapsed,0,"new world restarts title even with same level and epoch");
   Pure(state,owner,new object(),1000,14000);Near(state.Elapsed,0,"new actual level restarts title");
   Pure(state,owner,map,15000,15000);Near(state.Elapsed,0,"new HUD level epoch restarts title");

   // Actual native renderer: freeze ordinary Update, then prepare the selected
   // original populated level through the normal preparation mechanism.
   contactProbe=true;sessionSmoke=true;Reset(12);yield return DrainProbePreparation();
   preparationFrames=0;discardPreparationDelta=false;preparingScene=preparingNextScene=menuPreparing=HideForMenu=false;
   hybridTitleState=new HybridLevelTitleState();paused=false;world.Transition=world.GameOver=false;
   double start=realClock;uint rng=random;var playerCell=world.Player.Cell;double simulation=time;
   Render();Check(hud!=null&&hybridNameLabel!=null,"native title renderer exists");
   Check(NativeCampaignComposition.Enabled,"new campaign is enabled without experiment flags");
   Check(HybridMazeStudy.Report(currentGeneratedLevel)!=null,"normal start uses automatic hybrid composition");
   result.players=world.PlayerCount;result.crystalCores=NativeMazeArtwork.CrystalCoresEnabled;result.wallLights=NativeLevelAtmosphere.ActiveStreams;
   Check(result.crystalCores&&sceneMazeArt.IsGlass&&sceneMazeArt.CoreStructureAudit!=null&&sceneMazeArt.OuterCrystalMaterial!=null,"glass crystal cores are composed by the normal artwork route");
   Check(result.wallLights==32&&NativeWallLightRoutes.StreamCount==32,"approved32 wall lights are active");
   Check(hud.ContactRect(2).height==16&&hud.ContactRect(3).height==16,"LEVEL and SNAKES retain original16-unit size");
   Check(!hud.HybridLevelSweepActive,"top LEVEL has no decorative spotlight during level introduction");
   realClock=start+125;Render();Check(hybridTitleState.Mode==HybridLevelTitleMode.Intro&&hybridNameLabel.Visible,"native125ms intro visible");CaptureState("intro-125ms");
   Near(hybridNameLabel.Zoom,.88515625,"native title transform follows the one-second zoom in at125ms");
   Near(hybridNameLabel.Opacity,.0196759259259,"native125ms title is only faintly visible");
   result.caption=hybridNameLabel.Caption;result.introSide=hybridNameLabel.Side;
   Check(result.caption.Split(new[]{' '},StringSplitOptions.RemoveEmptyEntries).Length<=2,"title retains concise two-word name");
   Near(hybridNameLabel.Side,24,"intro lettering matches the24-unit PAUSE font size");
   Check(DisplayFrame.Width>=576&&22*24<=DisplayFrame.Width-32,"longest22-character name fits the minimum supported frame without shrinking");
   Near(hybridNameLabel.CenterY,DisplayFrame.Height*.5,"intro lies at screen centre",.01);
   void ScreenCentered(string label){var point=camera.WorldToViewportPoint(hybridNameLabel.WorldCenter);Near(point.x,.5,label+" horizontal viewport centre");Near(point.y,.5,label+" vertical viewport centre");}
   ScreenCentered("normal view");double oldX=cameraViewX,oldY=cameraViewY,oldZoom=cameraViewZoom;
   SetGameplayCameraView(90,80,1.7);ScreenCentered("pan and zoom toward upper-left");
   SetGameplayCameraView(460,330,2.4);ScreenCentered("pan and zoom toward lower-right");
   SetGameplayCameraView(oldX,oldY,oldZoom);
   int zoomMeshUpdates=hybridNameLabel.MeshUpdates;
   realClock=start+200;Render();Near(hybridNameLabel.Zoom,.89248,"native introductory scale progresses smoothly at200ms");
   Check(hybridNameLabel.MeshUpdates==zoomMeshUpdates,"changing intro zoom reuses the retained glyph mesh");ScreenCentered("zoom in at200ms");
   realClock=start+250;Render();Near(hybridNameLabel.Zoom,.89875,"native250ms intro gently progresses through its longer zoom in");Near(hybridNameLabel.Opacity,.074074074074,"native250ms intro remains ghostly");CaptureState("intro-250ms");
   realClock=start+400;Render();Check(hybridNameLabel.BeamActive,"intro spotlight is active on its forward pass");float forwardStart=hybridNameLabel.BeamX;
   realClock=start+500;Render();Near(hybridNameLabel.Zoom,.94,"native500ms intro reaches its midpoint scale");Near(hybridNameLabel.Opacity,.259259259259,"native500ms intro continues its longer fade in");CaptureState("intro-500ms");
   realClock=start+1000;Render();Near(hybridNameLabel.Zoom,1,"native1000ms intro completes the longer zoom in");Check(hybridNameLabel.BeamX>forwardStart,"intro spotlight travels right on the first pass");CaptureState("intro-forward");
   realClock=start+1250;Render();CaptureState("intro-1250ms");
   Near(hybridNameLabel.Zoom,1,"native held title uses its original full scale");Near(hybridNameLabel.Opacity,.925925925926,"native1250ms title approaches full opacity");ScreenCentered("full size at1250ms");
   realClock=start+1480;Render();Check(hybridNameLabel.BeamActive,"intro spotlight remains active on its return pass");float returnStart=hybridNameLabel.BeamX;
   realClock=start+1625;Render();Near(hybridNameLabel.Opacity,1,"native intro is fully opaque only near its middle");CaptureState("intro-1625ms");
   int meshUpdates=hybridNameLabel.MeshUpdates;for(int i=0;i<20;i++)Render();Check(meshUpdates==hybridNameLabel.MeshUpdates,"unchanged title reuses retained glyph mesh");
   // Readback proof uses the actual retained label/material over an identical
   // frozen scene, with one fixed beam position, font and full-size transform.
   // Its images allow measured background transmission instead of inferring
   // transparency from an opacity property or changing title brightness alone.
   double proofClock=realClock,proofSimulation=time;uint proofRng=random;float proofBeam=hybridNameLabel.BeamX;
   foreach(var alpha in new[]{0f,.1f,.5f,1f}){
    hybridNameLabel.Render(hybridNameCaption,sessionArt.LevelTitleFont,hud.HybridNameBeam,DisplayFrame,alpha,DisplayFrame.Height*.5f,DisplayFrame.Width-32,hybridTitleState.Elapsed,true,true,24,hud.HybridNamePixelScale,1,1);
    camera.Render();CaptureState("opacity-proof-"+Mathf.RoundToInt(alpha*100));Near(hybridNameLabel.Opacity,alpha,"proof applies requested opacity without changing the material path");
    Near(hybridNameLabel.Zoom,1,"proof keeps title scale fixed");Near(hybridNameLabel.BeamX,proofBeam,"proof keeps travelling highlight position fixed");
   }
   Render();Check(realClock==proofClock&&time==proofSimulation&&random==proofRng,"opacity proof does not advance either clock or gameplay RNG");
   Check(hybridNameLabel.MeshUpdates==meshUpdates,"opacity proof reuses the original retained glyph mesh");
   realClock=start+2080;Render();Check(hybridNameLabel.BeamX<returnStart,"intro spotlight travels left on the return pass");CaptureState("intro-return");
   Check(!hud.HybridLevelSweepActive,"top LEVEL remains static while the name owns both spotlight passes");
   realClock=start+2250;Render();Near(hybridNameLabel.Zoom,1,"native2250ms title starts its longer exit at full scale");CaptureState("intro-2250ms");
   realClock=start+2500;Render();Near(hybridNameLabel.Zoom,.98125,"native2500ms title gently begins its longer zoom out");Near(hybridTitleState.Alpha,.5,"native2500ms intro is halfway transparent");Check(!hybridNameLabel.BeamActive,"spotlight ends while the transparent exit continues");CaptureState("intro-2500ms");
   realClock=start+2750;Render();Near(hybridNameLabel.Zoom,.94,"native2750ms title reaches its midpoint exit scale");Near(hybridNameLabel.Opacity,.259259259259,"native2750ms title opacity keeps the approved exit timing");CaptureState("intro-2750ms");
   realClock=start+3000;Render();Near(hybridNameLabel.Opacity,.074074074074,"native3000ms title is ghostly before disappearing");CaptureState("intro-3000ms");
   Near(hybridNameLabel.Zoom,.89875,"native title transform gently ends its longer zoom out at3000ms");ScreenCentered("zoom out at3000ms");
   Check(hybridNameLabel.MeshUpdates==meshUpdates,"zoom out does not rebuild the retained glyph mesh");
   realClock=start+3300;Render();Check(!hybridNameLabel.Visible&&hybridNameLabel.Opacity==0,"expired intro is absent during gameplay");CaptureState("normal-play");
   paused=true;Render();realClock+=250;Render();Check(hybridTitleState.Mode==HybridLevelTitleMode.Pause&&hybridNameLabel.Visible,"PAUSE recalls current level name");
   Near(hybridNameLabel.Side,12,"PAUSE subtitle keeps its approved12-unit size");
   Near(hybridNameLabel.Zoom,1,"PAUSE subtitle has no introductory scaling");
   Near(hybridNameLabel.Opacity,.95,"PAUSE subtitle retains its approved opacity");
   Near(hybridNameLabel.CenterY,DisplayFrame.Height*.5-4+48,"pause subtitle clears the original status plate",.01);CaptureState("pause");
   double pausePeak=realClock;var pauseSize=sessionArt.StatusBanner.Size;
   Near(sessionArt.StatusBanner.Opacity,1,"PAUSE lettering reaches its full first peak");
   realClock=pausePeak+HybridLevelTitleState.PauseCycleMs*.25;Render();
   Near(sessionArt.StatusBanner.Opacity,.5,"PAUSE lettering smoothly fades to halfway");Near(hybridNameLabel.Opacity,.475,"name fades with PAUSE");CaptureState("pause-half");
   realClock=pausePeak+HybridLevelTitleState.PauseCycleMs*.5;Render();
   Near(sessionArt.StatusBanner.Opacity,0,"PAUSE lettering reaches blink minimum");Near(hybridNameLabel.Opacity,0,"name reaches the same blink minimum");CaptureState("pause-minimum");
   realClock=pausePeak+HybridLevelTitleState.PauseCycleMs;Render();
   Near(sessionArt.StatusBanner.Opacity,1,"PAUSE lettering returns to full brightness");Near(hybridNameLabel.Opacity,.95,"name returns with PAUSE");
   Check(sessionArt.StatusBanner.Size==pauseSize&&hybridNameLabel.Zoom==1,"pause blinking never changes layout or size");
   Check(time==simulation&&random==rng&&world.Player.Cell==playerCell,"pause animation leaves simulation RNG and player frozen");CaptureState("pause-return");
   paused=false;Render();Check(hybridTitleState.Mode==HybridLevelTitleMode.Hidden,"resume does not restart expired intro");
   // Pause while the introductory title is still running: retain its progress.
   hybridTitleState=new HybridLevelTitleState();realClock+=100;Render();realClock+=500;Render();double progress=hybridTitleState.Elapsed;
   paused=true;Render();realClock+=2000;Render();Near(hybridTitleState.Elapsed,progress,"pause freezes remaining intro duration");paused=false;Render();Near(hybridTitleState.Elapsed,progress,"resume keeps the same intro point");
   realClock+=100;Render();Near(hybridTitleState.Elapsed,progress+100,"intro continues from retained progress after pause");
   // Real preparation render may draw a future surface; never advance title.
   progress=hybridTitleState.Elapsed;preparingScene=true;realClock+=1000;Render();Near(hybridTitleState.Elapsed,progress,"hidden GPU warm render leaves intro clock intact");preparingScene=false;Render();Near(hybridTitleState.Elapsed,progress,"preparation return does not catch up hidden elapsed");
   Check(random==rng&&world.Player.Cell==playerCell&&time==simulation,"draws do not advance authoritative RNG, movement or simulation time");
   world.Transition=true;world.TransitionAt=simulation;world.RevealAt=simulation+200;time=world.Time=simulation+100;realClock+=100;Render();Check(hybridNameLabel.Opacity==0,"native clear subtitle waits for reveal");
   time=world.Time=simulation+436;realClock+=100;Render();realClock+=250;Render();Check(hybridTitleState.Mode==HybridLevelTitleMode.Cleared&&hybridNameLabel.Visible,"native LEVEL CLEARED subtitle visible");Near(hybridNameLabel.Side,12,"LEVEL CLEARED subtitle keeps its approved12-unit size");Near(hybridNameLabel.Zoom,1,"LEVEL CLEARED subtitle has no introductory scaling");CaptureState("level-cleared");
   time=world.Time=simulation+872;Render();Near(hybridNameLabel.Opacity,0,"native clear blink also extinguishes subtitle",.001);CaptureState("clear-blink");
   world.Transition=false;world.GameOver=true;world.GameOverAt=realClock-Math.PI*310;paused=false;Render();Check(!hybridNameLabel.Visible,"GAME OVER suppresses any level title");CaptureState("game-over");
   result.width=target.width;result.height=target.height;result.passed=true;
   File.WriteAllText(output,JsonUtility.ToJson(result,true));Debug.Log("IPAD_CAMPAIGN_PRESENTATION_PASSED quality="+quality+" checks="+result.checks+" captures="+result.captures.Count);Application.Quit(0);
  }
 }
}

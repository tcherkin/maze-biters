#if UNITY_EDITOR
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Reflection;
using UnityEngine;

namespace MazeBiters.NativeStudy {
 [Serializable] public sealed class NativeCreatureFeudReport {
  public bool passed;
  public int assertions,failures,decisions;
  public double elapsedMs;
  public string scope;
  public List<NativeDifficultyCheck> checks=new List<NativeDifficultyCheck>();
 }
 public static class NativeCreatureFeudValidation {
  static readonly Vector2Int Right=Vector2Int.right,Left=Vector2Int.left,Down=new Vector2Int(0,1),Up=new Vector2Int(0,-1);
  static readonly Vector2Int[] Directions={Right,Left,Down,Up};
  sealed class Fixture {public NativeGameplayWorld w;public List<NativeWorldEvent> events=new List<NativeWorldEvent>();}
  static void Check(NativeCreatureFeudReport r,bool pass,string name,string detail=""){r.assertions++;if(!pass)r.failures++;r.checks.Add(new NativeDifficultyCheck{name=name,passed=pass,detail=detail});}
  static void Group(NativeCreatureFeudReport r,string name,Action action){try{action();}catch(Exception e){Check(r,false,name+" completes",e.ToString());}}
  static string[] OpenGrid(){var rows=new string[17];for(int y=0;y<17;y++)rows[y]=y==0||y==16?new string('#',17):"#"+new string('.',15)+"#";return rows;}
  static string[] Corridor(){var rows=Enumerable.Range(0,9).Select(_=>new string('#',11)).ToArray();rows[4]="#.........#";return rows;}
  static Fixture Make(int tier=2,int mode=1,string[] grid=null,uint randomSeed=3571){
   uint seed=randomSeed;var f=new Fixture();
   f.w=new NativeGameplayWorld(grid??OpenGrid(),()=>{unchecked{seed+=0x6D2B79F5;uint v=(seed^(seed>>15))*(1|seed);v^=v+(v^(v>>7))*(61|v);return (v^(v>>14))/4294967296.0;}}){Difficulty=NativeMazeGenerator.Difficulties[tier],AiDifficulty=tier,Time=1000,LevelStarted=1000,Assist=false,SessionEnabled=false,LifecycleEnabled=false};
   f.w.SetMode(mode);f.w.Event=e=>f.events.Add(e);
   for(int i=0;i<f.w.PlayerCount;i++){var p=f.w.GetPlayer(i);p.Cell=p.From=p.Previous=new Vector2Int(1,1+i);p.Waiting=true;p.LastMove=1e9;p.Score=120+i;p.ExactScore=p.Score;p.Contribution=7+i;p.Lives=3;p.PowerUntil=0;p.ShieldUntil=0;}
   return f;
  }
  static NativeGameplaySnake Snake(Fixture f,IEnumerable<Vector2Int> cells,Vector2Int direction){var s=f.w.AddSnake(cells,direction,0);s.Temperament=.5;s.LastMove=f.w.Time;return s;}
  static NativeHunter Hunter(Fixture f,Vector2Int cell,int id=100,Vector2Int? direction=null){var h=new NativeHunter{Id=id,Cell=cell,From=cell,Dir=direction??Right,LastMove=f.w.Time,MotherAlive=true};f.w.Hunters.Add(h);return h;}
  static string Players(Fixture f)=>string.Join("|",Enumerable.Range(0,f.w.PlayerCount).Select(i=>{var p=f.w.GetPlayer(i);return p.Id+":"+p.Score+":"+p.ExactScore+":"+p.Contribution+":"+p.Lives+":"+p.PowerUntil+":"+p.ShieldUntil+":"+p.BiteAt+":"+p.BiteEnd+":"+p.Dead;}));
  static void Memory(Fixture f,NativeGameplaySnake s,double time){f.w.Time=time;typeof(NativeGameplayWorld).GetMethod("Memory",BindingFlags.NonPublic|BindingFlags.Instance).Invoke(f.w,new object[]{s});}
  static bool Near(double a,double b)=>Math.Abs(a-b)<1e-7;
  static bool Connected(NativeGameplaySnake s)=>s.Body.Zip(s.Body.Skip(1),(a,b)=>Math.Abs(a.x-b.x)+Math.Abs(a.y-b.y)==1).All(v=>v)&&s.Cell==s.Head;
  static void SplitGeometry(NativeCreatureFeudReport r){
   foreach(int mode in new[]{0,1,2,3,4,5})foreach(var d in Directions){
    var f=Make(mode:mode);var centre=new Vector2Int(8,8);var side=new Vector2Int(-d.y,d.x);var cells=Enumerable.Range(-3,7).Select(k=>centre+d*k).Reverse().ToArray();var s=Snake(f,cells,d);var h=Hunter(f,centre+side,100,-side);var other=Hunter(f,new Vector2Int(13,13),101);
    s.PersonalThreat[0]=1.25;s.PersonalThreat[1]=.75;s.HunterThreat[other.Id]=.6;
    string players=Players(f);int mass=s.Body.Count;var old=s.Body.ToArray();string label="mode="+mode+", direction="+d;
    Check(r,f.w.HunterCanCut(h,s,3),"A live hunter can plan an interior crossing: "+label);
    h.Cell=centre;bool cut=f.w.TryHunterCut(h,centre);var children=f.w.Snakes.ToArray();
    Check(r,cut&&children.Length==2&&!f.w.Snakes.Contains(s),"The struck snake becomes exactly two living fragments: "+label);
    Check(r,children.Sum(c=>c.Body.Count)==mass-1&&children.All(c=>Connected(c)&&!c.Body.Contains(centre))&&children.SelectMany(c=>c.Body).Distinct().Count()==mass-1,"Only the impact segment is removed and both fragments remain connected: "+label);
    Check(r,children.Length==2&&children[0].Body.SequenceEqual(old.Take(3))&&children[1].Body.SequenceEqual(old.Skip(4).Reverse()),"The two fragments retain the established split orientation: "+label);
    Check(r,children.All(c=>Near(c.PersonalThreat[0],1.25)&&Near(c.PersonalThreat[1],.75)&&Near(f.w.HunterGrudge(c,h),2)&&Near(f.w.HunterGrudge(c,other),.6)),"Both fragments inherit player and hunter memories, blaming the actual cutter: "+label);
    Check(r,children.All(c=>Near(c.LastMove,f.w.Time)&&c.Anger>=2)&&h.NextCutAt>f.w.Time&&h.BiteEnd>f.w.Time,"The cut has a cooldown and a normal future first movement: "+label);
    Check(r,Players(f)==players,"A hunter cut changes no player score, contribution, power, life or bite clock: "+label);
    var events=f.events.Where(e=>e.Kind=="hunterSplit").ToArray();
    Check(r,events.Length==1&&events[0].Player==null&&events[0].Hunter==h&&events[0].Snake==s&&events[0].Index==3&&events[0].Cell==centre,"The cut event identifies its real actor and impact without a player eater: "+label);
    Check(r,!f.events.Any(e=>e.Kind=="fruit"||e.Kind=="head"||e.Kind=="tail"||e.Kind=="hunterBite"||e.Kind=="playerBite"||e.Kind=="bonusLife"),"The cut does not masquerade as player feeding: "+label);
    if(children.Length==2){children[0].HunterThreat[h.Id]=99;Check(r,Near(children[1].HunterThreat[h.Id],2),"Fragment grudges are independent mutable memories: "+label);}
   }
  }
  static void InvalidAndCooldown(NativeCreatureFeudReport r){
   var f=Make();var s=Snake(f,Enumerable.Range(4,7).Select(x=>new Vector2Int(x,8)),Left);var h=Hunter(f,new Vector2Int(7,7),direction:Down);
   Check(r,!f.w.HunterCanCut(h,s,0)&&!f.w.HunterCanCut(h,s,s.Body.Count-1),"Hunters cannot cut a head or chew a tail");
   Check(r,!f.w.HunterCanCut(h,s,-1)&&!f.w.HunterCanCut(h,s,s.Body.Count),"Out-of-range contact indices are rejected");
   var absent=new NativeHunter{Id=700,Cell=h.Cell};Check(r,!f.w.HunterCanCut(absent,s,3),"A removed or unregistered hunter cannot cause a cut");
   h.Cell=s.Body[3];Check(r,f.w.TryHunterCut(h,h.Cell),"A first valid contact cuts the snake");
   var child=f.w.Snakes.First(c=>c.Body.Count>=3);h.Cell=child.Body[1];Check(r,f.w.Time<h.NextCutAt&&f.w.TryHunterCut(h,h.Cell),"An incidental body crossing remains possible during the deliberate-planning cooldown");
   Check(r,f.w.Snakes.Count==3&&f.w.Snakes.Sum(c=>c.Body.Count)==5,"Successive incidental contacts make their normal gaps without waiting for a cooldown");
   var protectedWorld=Make();var protectedSnake=Snake(protectedWorld,Enumerable.Range(4,7).Select(x=>new Vector2Int(x,8)),Left);var protectedHunter=Hunter(protectedWorld,new Vector2Int(7,7));protectedWorld.w.Player.Cell=protectedSnake.Body[3];protectedWorld.w.Player.ShieldUntil=protectedWorld.w.Time+1000;
   Check(r,!protectedWorld.w.HunterCanCut(protectedHunter,protectedSnake,3),"Cutting does not bypass a player's spawn shield at the impact cell");
   var overlapping=Make();var a=Snake(overlapping,Enumerable.Range(4,7).Select(x=>new Vector2Int(x,8)),Left);var b=Snake(overlapping,Enumerable.Range(5,7).Select(y=>new Vector2Int(7,y)),Up);var cutter=Hunter(overlapping,new Vector2Int(7,7));
   Check(r,!overlapping.w.HunterCanCut(cutter,a,3),"An overlapping second snake blocks an ambiguous multi-snake cut");
  }
  static void Predation(NativeCreatureFeudReport r){
   foreach(bool hostile in new[]{false,true}){
    var f=Make(grid:Corridor());f.w.Player.Dead=true;var s=Snake(f,new[]{new Vector2Int(4,4),new Vector2Int(3,4)},Right);var h=Hunter(f,new Vector2Int(5,4));if(hostile)s.HunterThreat[h.Id]=2;string players=Players(f);
    bool moved=f.w.SnakeStep(s);
    Check(r,moved&&s.Head==new Vector2Int(5,4)&&!f.w.Hunters.Contains(h),"A forward snake head can catch a hunter in a corridor: hostile="+hostile);
    Check(r,s.Body.Count==2&&Players(f)==players,"Snake predation does not grow the snake or award player benefits: hostile="+hostile);
    var evt=f.events.Where(e=>e.Kind=="snakeHunterBite").ToArray();Check(r,evt.Length==1&&evt[0].Snake==s&&evt[0].Hunter==h&&evt[0].Player==null,"Predation emits one snake/hunter event without a human eater: hostile="+hostile);
    Check(r,!f.w.SnakeEatHunter(s,h)&&Near(f.w.HunterGrudge(s,h),0),"A consumed hunter cannot be eaten twice or remain a live revenge target: hostile="+hostile);
   }
   var rear=Make(grid:Corridor());rear.w.Player.Dead=true;var reversing=Snake(rear,new[]{new Vector2Int(4,4),new Vector2Int(3,4),new Vector2Int(2,4)},Right);var victim=Hunter(rear,new Vector2Int(1,4));reversing.Reversing=true;reversing.Guide=reversing.Tail;reversing.GuideDir=Left;
   Check(r,!rear.w.CanEnter(victim.Cell,reversing),"Tail movement keeps hunters as solid obstacles");rear.w.SnakeStep(reversing);
   Check(r,rear.w.Hunters.Contains(victim)&&!reversing.Body.Contains(victim.Cell),"A retreating tail cannot swallow or overlap a hunter");
   var direct=Make();var snake=Snake(direct,new[]{new Vector2Int(8,8),new Vector2Int(7,8)},Right);var atTail=Hunter(direct,snake.Tail);
   Check(r,!direct.w.SnakeEatHunter(snake,atTail),"Predation requires the snake's mouth, not a body contact");atTail.Cell=snake.Head;
   Check(r,direct.w.SnakeEatHunter(snake,atTail),"An actual same-cell head contact resolves the hunter's death");
  }
  static void MovementCrossing(NativeCreatureFeudReport r){
   for(int tier=0;tier<5;tier++){
    var grid=Enumerable.Range(0,17).Select(_=>new string('#',17)).ToArray();grid[8]="####.......######";grid[7]="#######.#########";grid[9]="#######.#########";
    var f=Make(tier,0,grid);f.w.Player.Dead=true;var s=Snake(f,Enumerable.Range(4,7).Select(x=>new Vector2Int(x,8)),Left);s.LastMove=1e9;var h=Hunter(f,new Vector2Int(7,7),direction:Down);string players=Players(f);
    f.w.Tick(f.w.Time+96);
    Check(r,h.Cell==new Vector2Int(7,8)&&f.w.Snakes.Count==2&&f.w.Snakes.All(c=>!c.Body.Contains(h.Cell)),"A real movement tick makes an incidental crossing at every difficulty: tier="+tier);
    Check(r,f.events.Count(e=>e.Kind=="hunterSplit")==1&&Players(f)==players,"A movement-driven crossing has one attributed cut and no player reward: tier="+tier);
   }
  }
  static void HeadRicochet(NativeCreatureFeudReport r){
   var centre=new Vector2Int(8,8);
   for(int tier=0;tier<5;tier++)foreach(var d in Directions){
    var rows=Enumerable.Range(0,17).Select(_=>new string('#',17).ToCharArray()).ToArray();for(int k=-4;k<=4;k++){var cell=centre+d*k;rows[cell.y][cell.x]='.';}var grid=rows.Select(row=>new string(row)).ToArray();
    var bounce=Make(tier,1,grid);bounce.w.SessionEnabled=true;bounce.w.Player.Cell=bounce.w.Player.From=centre-d*4;var stationary=Snake(bounce,new[]{centre+d,centre+d*2},-d);stationary.LastMove=1e9;var hunter=Hunter(bounce,centre,direction:d);string before=Players(bounce);
    Check(r,!bounce.w.HunterCanEnter(hunter,stationary.Head),"A snake head is a blocking ricochet contact for an approaching hunter: tier="+tier+", direction="+d);
    bounce.w.Tick(bounce.w.Time+96);
    Check(r,bounce.w.Hunters.Contains(hunter)&&hunter.Cell==centre-d&&hunter.Dir==-d&&stationary.Head==centre+d&&!bounce.events.Any(e=>e.Kind=="snakeHunterBite"||e.Sound=="HeadEat"),"An actual hunter tick bounces from a stationary head without being eaten: tier="+tier+", direction="+d);
    var catchWorld=Make(tier,1,grid);catchWorld.w.SessionEnabled=true;catchWorld.w.Player.Cell=catchWorld.w.Player.From=centre-d*4;var mouth=Snake(catchWorld,new[]{centre+d,centre+d*2},-d);mouth.LastMove=catchWorld.w.Time-218;var prey=Hunter(catchWorld,centre,direction:d);prey.LastMove=1e9;string catchBefore=Players(catchWorld);
    catchWorld.w.Tick(catchWorld.w.Time+1);
    Check(r,!catchWorld.w.Hunters.Contains(prey)&&mouth.Head==centre&&mouth.Body.Count==2&&catchWorld.events.Count(e=>e.Kind=="snakeHunterBite")==1&&catchWorld.events.Count(e=>e.Kind=="sound"&&e.Sound=="HeadEat")==1,"An actual moving snake head still catches a stationary hunter once: tier="+tier+", direction="+d);
    Check(r,Players(bounce)==before&&Players(catchWorld)==catchBefore,"Neither ricochet nor creature predation changes player rewards: tier="+tier+", direction="+d);
   }
  }
  static void IncidentalStraightPriority(NativeCreatureFeudReport r){
   var f=Make(0,1);f.w.Player.Cell=f.w.Player.From=new Vector2Int(7,12);f.w.Random=()=>.99;
   var first=Snake(f,Enumerable.Range(5,5).Select(x=>new Vector2Int(x,8)),Left);var second=Snake(f,Enumerable.Range(5,5).Select(x=>new Vector2Int(x,9)),Left);first.LastMove=second.LastMove=1e9;
   var hunter=Hunter(f,new Vector2Int(7,7),direction:Down);var state=f.w.Brain.State(hunter);state.intent="evade";state.intentUntil=f.w.Time+10000;string players=Players(f);
   var preferred=BrainDecision(r,f,hunter,new List<Vector2Int>{Down,Left,Right});
   Check(r,preferred!=Down,"The PICNIC junction fixture contains an actual attractive side route");
   f.w.Tick(f.w.Time+96);
   Check(r,hunter.Cell==new Vector2Int(7,8)&&hunter.Dir==Down&&f.events.Count(e=>e.Kind=="hunterSplit")==1,"PICNIC continues its eligible straight body crossing instead of dodging toward the tempting side route");
   bool intentCooling=f.w.Time+96<hunter.NextCutAt;f.w.Tick(f.w.Time+96);
   Check(r,intentCooling&&hunter.Cell==new Vector2Int(7,9)&&hunter.Dir==Down&&f.events.Count(e=>e.Kind=="hunterSplit")==2,"A second nearby body is crossed on the next normal step despite the deliberate-planning cooldown");
   Check(r,f.w.Snakes.Count==4&&f.w.Snakes.Sum(s=>s.Body.Count)==8&&f.w.Snakes.All(s=>Connected(s))&&Players(f)==players,"Two incidental crossings preserve connected fragments and cause no player reward or feeding benefit");
  }
  static void MemoryContinuity(NativeCreatureFeudReport r){
   var f=Make(mode:5);var s=Snake(f,Enumerable.Range(4,8).Select(x=>new Vector2Int(x,8)),Left);var h=Hunter(f,new Vector2Int(13,13));s.HunterThreat[h.Id]=.8;
   f.w.Player.Cell=s.Tail;f.w.Player.Previous=s.Tail+Right;f.w.Player.Dir=f.w.Player.Next=Left;f.w.Eat(s,s.Body.Count-1);
   Memory(f,s,26000);Check(r,Near(s.PersonalThreat[0],1)&&Near(s.HunterThreat[h.Id],.8),"Fresh injury has a full 25-second calm interval at midpoint temperament");
   Memory(f,s,27000);Check(r,Near(s.PersonalThreat[0],.965)&&Near(s.HunterThreat[h.Id],.765),"Player and hunter grudges decay by the same elapsed-time rule");
   f.w.Player.Cell=s.Tail;f.w.Player.Previous=s.Tail+Right;f.w.Eat(s,s.Body.Count-1);double before=s.PersonalThreat[0],hunterBefore=s.HunterThreat[h.Id];
   Memory(f,s,51999);Check(r,Near(s.PersonalThreat[0],before)&&Near(s.HunterThreat[h.Id],hunterBefore),"A repeated bite holds both memories throughout the renewed calm period");
   Memory(f,s,52000);Check(r,Near(s.PersonalThreat[0],before)&&Near(s.HunterThreat[h.Id],hunterBefore),"The renewed calm period does not get charged as a sudden decay jump");
   Memory(f,s,53000);Check(r,Near(s.PersonalThreat[0],before-.035)&&Near(s.HunterThreat[h.Id],hunterBefore-.035),"Decay resumes only for time after the new calm period");
  }
  static void PlayerSplitInheritance(NativeCreatureFeudReport r){
   foreach(bool poweredHead in new[]{false,true}){
    var f=Make();var s=Snake(f,Enumerable.Range(4,7).Select(x=>new Vector2Int(x,8)),Left);var h=Hunter(f,new Vector2Int(13,13));s.HunterThreat[h.Id]=1.25;
    int index=poweredHead?0:3;f.w.Player.Cell=s.Body[index];f.w.Player.Previous=f.w.Player.Cell+Right;f.w.Player.Dir=Left;if(poweredHead)f.w.Player.PowerUntil=f.w.Time+10000;
    f.w.Eat(s,index);
    Check(r,f.w.Snakes.Count==(poweredHead?1:2)&&f.w.Snakes.All(child=>Near(f.w.HunterGrudge(child,h),1.25)),"A later player bite preserves the original hunter's blame through replacement fragments: powered head="+poweredHead);
   }
   var clean=Make(mode:4);var victim=Snake(clean,Enumerable.Range(4,7).Select(x=>new Vector2Int(x,8)),Left);var cutter=Hunter(clean,victim.Body[3]);var ai=clean.w.GetPlayer(2);ai.Ai=new NativeAllyState();var a=ai.Ai;
   a.locked=a.graded=a.casualSnake=victim;a.split=new AllySplit{snake=victim};a.retreat=new AllyRetreat{snake=victim};a.queue.Add(victim);a.cooldowns[victim]=clean.w.Time+5000;a.mealInitialized=a.mealActive=true;a.mealIntentUntil=clean.w.Time+9999;a.bitten=true;
   clean.w.TryHunterCut(cutter,cutter.Cell);
   Check(r,a.locked==null&&a.graded==null&&a.casualSnake==null&&a.split==null&&a.retreat==null&&a.queue.Count==0&&!a.cooldowns.ContainsKey(victim)&&a.replan,"An external cut clears every stale ally reference to the replaced snake");
   Check(r,a.mealInitialized&&a.mealActive&&Near(a.mealIntentUntil,clean.w.Time+9999),"An external cut does not create, cancel or extend the ally's eating intent");
  }
  static Vector2Int BrainDecision(NativeCreatureFeudReport r,Fixture f,NativeCreature creature,List<Vector2Int> options=null){
   r.decisions++;return f.w.Brain.Choose(creature,creature.Cell,options??new List<Vector2Int>(Directions),creature is NativeGameplaySnake snake?NativeGameplayWorld.Profile(snake):new BrainProfile{kind="hunter",baseline=.22});
  }
  static void PersonalTargets(NativeCreatureFeudReport r){
   var f=Make(4,4);for(int i=0;i<f.w.PlayerCount;i++)f.w.GetPlayer(i).Dead=true;f.w.Random=()=>.5;
   var s=Snake(f,new[]{new Vector2Int(8,8),new Vector2Int(7,8)},Right);var offender=Hunter(f,new Vector2Int(10,8),100);var innocent=Hunter(f,new Vector2Int(8,10),101);s.HunterThreat[offender.Id]=2;
   BrainDecision(r,f,s,new List<Vector2Int>{Right,Down,Up});
   Check(r,s.Brain.targetHunterId==offender.Id&&s.Brain.targetPlayerId==0&&s.VisualTarget==offender.Cell,"A wounded snake plans against its actual hunter offender, not an equally close innocent hunter");
   f.w.Hunters.Remove(offender);BrainDecision(r,f,s,new List<Vector2Int>{Right,Down,Up});
   Check(r,s.Brain.targetHunterId==0&&s.Brain.targetPlayerId==0,"A removed hunter immediately invalidates a held revenge target");
   s.LastAnger=s.LastMemory=f.w.Time;Memory(f,s,f.w.Time+26000);Check(r,!s.HunterThreat.ContainsKey(offender.Id),"Expired memory maintenance removes absent hunters");
   for(int participant=0;participant<3;participant++)foreach(bool ai in new[]{false,true}){
    var fair=Make(4,4);fair.w.Random=()=>.5;for(int i=0;i<fair.w.PlayerCount;i++)fair.w.GetPlayer(i).Dead=i!=participant;
    var p=fair.w.GetPlayer(participant);p.IsAI=ai;p.Cell=new Vector2Int(10,8);var snake=Snake(fair,new[]{new Vector2Int(8,8),new Vector2Int(7,8)},Right);var hunter=Hunter(fair,new Vector2Int(8,6));snake.PersonalThreat[participant]=3;snake.HunterThreat[hunter.Id]=2;
    BrainDecision(r,fair,snake,new List<Vector2Int>{Right,Down,Up});
    Check(r,snake.Brain.targetPlayerId==p.Id&&snake.Brain.targetHunterId==0,"Equal-distance revenge uses personal harm identically for any human or AI slot: participant="+participant+", AI="+ai);
   }
  }
  static void MischiefAndEscape(NativeCreatureFeudReport r){
   int[] planned=new int[5];const int samples=128;
   for(int tier=0;tier<5;tier++)for(int sample=1;sample<=samples;sample++){
    var f=Make(tier,0,randomSeed:(uint)(sample*7919));f.w.Player.Dead=true;
    var s=Snake(f,Enumerable.Range(5,7).Select(x=>new Vector2Int(x,8)),Left);var h=Hunter(f,new Vector2Int(8,5),direction:Down);
    BrainDecision(r,f,h);if(h.Brain.mischiefSnakeId==s.Id)planned[tier]++;
   }
   Check(r,planned[0]>0&&planned[1]>planned[0]&&planned[2]>planned[1]&&planned[3]>planned[2]&&planned[4]>planned[3],"Purposeful cutting is rare on PICNIC and increases across all difficulties with matched random samples","Planned cuts per "+samples+" decisions: "+string.Join(", ",planned));
   var early=Make(0,0);early.w.Player.Dead=true;early.w.Random=()=>.5;var snake=Snake(early,Enumerable.Range(5,7).Select(x=>new Vector2Int(x,8)),Left);var hunter=Hunter(early,new Vector2Int(8,5),direction:Down);BrainDecision(r,early,hunter);bool quiet=hunter.Brain.mischiefSnakeId==0;
   early.w.Time=early.w.LevelStarted+300000;BrainDecision(r,early,hunter);
   Check(r,quiet&&hunter.Brain.mischiefSnakeId==snake.Id,"The same PICNIC hunter develops deliberate mischief with the existing five-minute time escalation");
   hunter.NextCutAt=early.w.Time+1000;BrainDecision(r,early,hunter);Check(r,hunter.Brain.mischiefSnakeId==0,"A cooling hunter does not plan another body crossing before it can cut");
   var escape=Make(4,0,Corridor());escape.w.Player.Dead=true;var mouth=Snake(escape,new[]{new Vector2Int(4,4),new Vector2Int(3,4)},Right);mouth.LastMove=1e9;var runner=Hunter(escape,new Vector2Int(5,4),direction:Left);
   escape.w.Tick(escape.w.Time+96);
   Check(r,escape.w.Hunters.Contains(runner)&&runner.Cell==new Vector2Int(6,4),"A hunter facing a lethal mouth uses its safe backwards escape instead of treating the head as its only choice");
   var imminent=Make(4,0,Corridor());imminent.w.Player.Dead=true;var approach=Snake(imminent,new[]{new Vector2Int(6,4),new Vector2Int(7,4)},Left);approach.LastMove=imminent.w.Time-168;var evader=Hunter(imminent,new Vector2Int(4,4),direction:Right);evader.LastMove=imminent.w.Time-95;
   typeof(NativeGameplayWorld).GetMethod("MoveHunters",BindingFlags.Instance|BindingFlags.NonPublic).Invoke(imminent.w,null);
   Check(r,imminent.w.Hunters.Contains(evader)&&evader.Cell==new Vector2Int(5,4)&&evader.Dir==Right,"A predicted head approach cannot authorize a reverse while the hunter's forward cell is still open");
  }
  static void ForecastContacts(NativeCreatureFeudReport r){
   var rows=Enumerable.Range(0,17).Select(_=>new string('#',17).ToCharArray()).ToArray();for(int y=6;y<=12;y++)rows[y][7]='.';for(int x=5;x<=9;x++){rows[8][x]='.';rows[10][x]='.';}
   var grid=rows.Select(row=>new string(row)).ToArray();var f=Make(4,0,grid);f.w.Player.Cell=new Vector2Int(7,12);var snake=Snake(f,Enumerable.Range(5,5).Select(x=>new Vector2Int(x,8)),Left);snake.LastMove=1e9;var hunter=Hunter(f,new Vector2Int(7,7),direction:Down);var forecast=new NativeAllyThreatForecast();
   forecast.Build(f.w,f.w.Player,f.w.Time,600);
   Check(r,Near(forecast.Arrival(new Vector2Int(7,8),snake),95)&&Near(forecast.Arrival(new Vector2Int(7,9),snake),190),"The ally predicts an interior hunter cut and its continued 95 ms movement");
   hunter.NextCutAt=f.w.Time+100000;forecast.Build(f.w,f.w.Player,f.w.Time,600);Check(r,Near(forecast.Arrival(new Vector2Int(7,9),snake),190),"The ally still predicts incidental crossings while deliberate mischief is cooling down");
   hunter.NextCutAt=f.w.Time+95;forecast.Build(f.w,f.w.Player,f.w.Time,600);Check(r,Near(forecast.Arrival(new Vector2Int(7,8),snake),95),"A deliberate-planning deadline does not delay the next incidental contact");
   hunter.NextCutAt=0;f.w.UseLegacyAi=true;forecast.Build(f.w,f.w.Player,f.w.Time,600);Check(r,double.IsPositiveInfinity(forecast.Arrival(new Vector2Int(7,9),snake)),"The historical forecast retains solid snake bodies for hunters");f.w.UseLegacyAi=false;
   var second=Snake(f,Enumerable.Range(5,5).Select(x=>new Vector2Int(x,10)),Left);second.LastMove=1e9;forecast.Build(f.w,f.w.Player,f.w.Time,600);
   Check(r,Near(forecast.Arrival(new Vector2Int(7,11),snake),380),"The ally predicts successive incidental crossings through two interior bodies at the normal movement rate");
   f.w.Snakes.Remove(second);
   foreach(bool head in new[]{false,true}){
    snake.Body=Enumerable.Range(5,3).Select(x=>new Vector2Int(x,8)).ToList();if(head)snake.Body.Reverse();snake.Cell=snake.Head;snake.Dir=head?Right:Left;forecast.Build(f.w,f.w.Player,f.w.Time,600);
    Check(r,double.IsPositiveInfinity(forecast.Arrival(new Vector2Int(7,9),snake)),"Forecasting never treats a snake endpoint as a survivable body cut: head="+head);
   }
   var catchWorld=Make(4,0,Corridor());catchWorld.w.Player.Cell=new Vector2Int(9,4);var mouth=Snake(catchWorld,new[]{new Vector2Int(4,4),new Vector2Int(3,4)},Right);var prey=Hunter(catchWorld,new Vector2Int(5,4));prey.LastMove=1e9;forecast.Build(catchWorld.w,catchWorld.w.Player,catchWorld.w.Time,600);
   Check(r,Near(forecast.Arrival(prey.Cell,prey),218),"The ally forecasts a forward snake head catching a stationary hunter");
  }
  static bool SameProfile(NativeCreatureFeudProfile a,NativeCreatureFeudProfile b)=>Near(a.Chance,b.Chance)&&Near(a.Pursuit,b.Pursuit)&&Near(a.DecisionMs,b.DecisionMs)&&Near(a.Notice,b.Notice)&&Near(a.CutCooldownMs,b.CutCooldownMs);
  static void ProfileAndTime(NativeCreatureFeudReport r){
   var initial=NativeCreatureFeudProfile.ForIntensity(0);var maximum=NativeCreatureFeudProfile.ForIntensity(4);var previous=initial;bool bounded=true,ordered=true;
   for(int step=0;step<=400;step++){var p=NativeCreatureFeudProfile.ForIntensity(step/100.0);bounded&=p.Chance>=0&&p.Chance<=1&&p.DecisionMs>0&&p.Notice>=0&&p.CutCooldownMs>0;ordered&=p.Chance>=previous.Chance&&p.Notice>=previous.Notice&&p.DecisionMs<=previous.DecisionMs&&p.CutCooldownMs<=previous.CutCooldownMs;previous=p;}
   Check(r,bounded&&ordered,"Mischief becomes gradually more purposeful with bounded decision and contact intervals");
   Check(r,initial.Chance>0&&initial.Chance<.1&&maximum.Chance>initial.Chance,"PICNIC permits incidental cuts and only rarely deliberately searches for a split");
   for(int tier=0;tier<5;tier++){
    var start=NativeCreatureFeudProfile.ForIntensity(tier);var grace=NativeCreatureFeudProfile.ForIntensity(NativeDifficulty.ForIndex(tier,1,60000).Intensity);var late=NativeCreatureFeudProfile.ForIntensity(NativeDifficulty.ForIndex(tier,1,300000).Intensity);
    Check(r,SameProfile(start,grace),"Mischief respects the existing first-minute grace: tier="+tier);
    Check(r,SameProfile(maximum,late),"Mischief reaches the shared maximum after five gameplay minutes: tier="+tier);
   }
  }
  static void Legacy(NativeCreatureFeudReport r){
   var f=Make();f.w.UseLegacyAi=true;var s=Snake(f,Enumerable.Range(4,7).Select(x=>new Vector2Int(x,8)),Left);var h=Hunter(f,s.Body[3]);string players=Players(f);int mass=s.Body.Count;
   Check(r,!f.w.HunterCanCut(h,s,3)&&!f.w.TryHunterCut(h,h.Cell)&&s.Body.Count==mass,"The frozen historical brain has no hunter-cut mechanics");h.Cell=s.Head;
   Check(r,!f.w.SnakeEatHunter(s,h)&&f.w.Hunters.Contains(h)&&Players(f)==players,"The frozen historical brain has no new cross-species predation");
  }
  static void AudioEvents(NativeCreatureFeudReport r){
   var f=Make();f.w.SessionEnabled=true;f.w.Random=()=>.5;var snake=Snake(f,Enumerable.Range(4,7).Select(x=>new Vector2Int(x,8)),Left);var cutter=Hunter(f,snake.Body[3]);var impact=cutter.Cell;string players=Players(f);
   f.w.TryHunterCut(cutter,impact);var sounds=f.events.Where(e=>e.Kind=="sound").ToArray();
   Check(r,sounds.Length==1&&new[]{"Tie1","Tie2","Tie3","Tie5","TieEat"}.Contains(sounds[0].Sound)&&sounds[0].Cell==impact&&!sounds[0].GlobalSound,"A hunter cut emits exactly one existing localized snake-cut sound");
   Check(r,Players(f)==players&&!f.events.Any(e=>e.Sound=="HeadEat"||e.Kind=="characterBite"),"The cut sound does not imply feeding, power or a player's mouth animation");
   f.events.Clear();var eater=f.w.Snakes[0];cutter.Cell=eater.Head;f.w.SnakeEatHunter(eater,cutter);sounds=f.events.Where(e=>e.Kind=="sound").ToArray();
   Check(r,sounds.Length==1&&sounds[0].Sound=="HeadEat"&&sounds[0].Cell==eater.Head&&!sounds[0].GlobalSound,"A snake eating a hunter emits exactly one existing localized HeadEat sound");
   f.events.Clear();f.w.SnakeEatHunter(eater,cutter);Check(r,f.events.Count==0,"Repeated contact with a removed hunter emits no duplicate sound or bite event");
  }
  public static NativeCreatureFeudReport Run(){
   var watch=Stopwatch.StartNew();var r=new NativeCreatureFeudReport{scope="Deterministic native iPad contact, geometry, memory and difficulty checks. No rendered-device or gameplay-balance claim."};
   Group(r,"split geometry and neutral attribution",()=>SplitGeometry(r));Group(r,"invalid contacts and deliberate cooldown",()=>InvalidAndCooldown(r));Group(r,"head predation and tail safety",()=>Predation(r));Group(r,"movement-driven crossings",()=>MovementCrossing(r));Group(r,"hunter ricochet and moving-head capture",()=>HeadRicochet(r));Group(r,"incidental straight crossings",()=>IncidentalStraightPriority(r));Group(r,"memory continuity",()=>MemoryContinuity(r));Group(r,"subsequent player splits and ally state",()=>PlayerSplitInheritance(r));Group(r,"personal offender selection",()=>PersonalTargets(r));Group(r,"deliberate mischief and escape",()=>MischiefAndEscape(r));Group(r,"ally contact forecasts",()=>ForecastContacts(r));Group(r,"difficulty and clock",()=>ProfileAndTime(r));Group(r,"audio attribution",()=>AudioEvents(r));Group(r,"legacy isolation",()=>Legacy(r));
   watch.Stop();r.elapsedMs=watch.Elapsed.TotalMilliseconds;r.passed=r.failures==0;return r;
  }
 }
}
#endif

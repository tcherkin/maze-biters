using System;using System.Collections.Generic;using System.Linq;using UnityEngine;
namespace MazeBiters.NativeStudy {
 public sealed partial class NativeAllyBrain {
  AllyObjective Immediate(NativePlayer p,double t,List<Vector2Int> options){
   if(!CanBite(p,t))return null;
   var a=S(p);bool powered=AttackPower(p,t),pressured=!powered&&Pressure(p,t)>=3;
   bool forecastActive=!w.UseLegacyAi&&PredictivePlanning&&foresightReady&&foresightPlayer==p&&Math.Abs(foresightTime-t)<.0001;
   var cleanup=powered&&a.bitten&&w.Snakes.Contains(a.locked)?a.locked:null;var attacks=new List<AllyObjective>();
   bool escape=options.Any(d=>Collision(p,d,p.Cell+d,t)<100000&&Danger(p,d,p.Cell+d,t)<105);
   foreach(var d in options){var c=p.Cell+d;if(powered&&cleanup==null){var h=w.Hunters.FirstOrDefault(x=>x.Cell==c);if(h!=null)attacks.Add(new AllyObjective{type="power-eat-hunter",target=c,score=-360,hunter=h,kind="hunter",immediate=true,dir=d});}
    foreach(var s in w.Snakes){if(cleanup!=null&&s!=cleanup)continue;int i=s.Body.IndexOf(c);if(i<0)continue;bool head=i==0,tail=i==s.Body.Count-1&&i>0;string kind=head?"head":tail?"tail":"split";
     if(powered&&!head&&!tail)continue;var o=new AllyObjective{target=c,snake=s,kind=kind,bodyIndex=i,immediate=true,dir=d};
     if(head&&!powered&&Collision(p,d,c,t,o)>=100000)continue;if(!powered&&escape&&Danger(p,d,c,t)>=105)continue;
     // Nearby heads are a reason to predict the crossing, not automatically
     // refuse every edible body. The prepared time-aware safety pass still
     // examines the new fragments and every subsequent escape route.
     if(pressured&&kind=="split"&&escape&&!(forecastActive&&Collision(p,d,c,t,o)<100000))continue;
     o.score=(powered&&head?-520:powered&&tail?-500:kind=="split"?-240:kind=="tail"?-220:-180)+(s==a.locked?-12:0)+(d==p.Dir?-6:0);
     // Finish a meal already under way before another adjacent split. This
     // does not favour unbitten remote locks or override an unsafe contact.
     if(forecastActive&&Balance.Maximum&&a.bitten&&s==a.locked&&Collision(p,d,c,t,o)<100000&&Danger(p,d,c,t)<105)o.score-=1000;
     o.type=powered&&head?"power-eat-snake-head":kind=="split"?"immediate-split":kind=="tail"?"immediate-tail-bite":"immediate-head-bite";attacks.Add(o);
   }}return attacks.OrderBy(x=>x.score).FirstOrDefault();
  }
  double FirstRisk(NativePlayer p,double t,AllyObjective o,short[] f){
   var steps=Legal(p,t).Select(d=>new Step{distance=f[w.Index(p.Cell+d)],collision=Collision(p,d,p.Cell+d,t,o),danger=Danger(p,d,p.Cell+d,t)}).Where(s=>s.distance>=0).ToList();
   if(steps.Count==0)return 80;double best=steps.Min(s=>s.distance);return steps.Where(s=>s.distance==best).Min(s=>(s.collision>=100000?55:0)+(s.danger>=105?18:s.danger/35))+ObjectiveForesightRisk(p,t,o,f)*45;
  }
  AllyObjective TacticalFruit(NativePlayer p,double t){
   var a=S(p);if(a.fruit!=null&&!w.Fruits.Contains(a.fruit))a.fruit=null;if(w.Fruits.Count==0||a.bitten)return null;
   bool powered=Power(p,t);double remaining=Math.Max(0,p.PowerUntil-t);Vector2Int? prey=null;
   if(a.locked!=null&&w.Snakes.Contains(a.locked))prey=a.locked.Tail;
   else if(w.Snakes.Count>0)prey=w.Snakes.OrderBy(s=>Distance(p.Cell,s.Tail)).First().Tail;
   double direct=prey.HasValue?Distance(p.Cell,prey.Value):0,maxDistance=powered?(remaining<=4500?8:5):15;if(!w.UseLegacyAi)maxDistance=Math.Min(maxDistance,Skill.notice);var candidates=new List<AllyObjective>();
   foreach(var fruit in w.Fruits){bool committed=fruit==a.fruit;var o=new AllyObjective{type="tactical-fruit",target=fruit.Cell,fruit=fruit};
    var f=ObjectiveField(o);int route=f[w.Index(p.Cell)];if(route<0||route>maxDistance+(committed?4:0))continue;
    double maxDetour=powered?(remaining<=4500?6:3):(route<=10?10:6),detour=0;
    if(prey.HasValue&&Finite(direct)){double onward=Distance(fruit.Cell,prey.Value);if(!Finite(onward))continue;detour=Math.Max(0,route+onward-direct);}
    if(detour>maxDetour+(committed?6:0))continue;o.priorityFruit=committed||route<=7&&detour<=5;double risk=FirstRisk(p,t,o,f);if(risk>=18)continue;
    double benefit=powered?(remaining<=3000?-13:-6):-18;o.score=route+detour*1.35+risk+benefit-(w.UseLegacyAi?Math.Max(0,Math.Min(3,fruit.Kind))*.4:0)-(committed?12:0)-(o.priorityFruit?100:0);candidates.Add(o);
   }return candidates.OrderBy(o=>o.score).FirstOrDefault();
  }
  AllyObjective Objective(NativePlayer p,double t,AllySkill skill=null){
   if(!CanBite(p,t))return TacticalFruit(p,t);
   var a=S(p);var list=new List<AllyObjective>();Clean(p,t);if(skill!=null&&!a.allowSplit.HasValue)a.allowSplit=w.Random()<skill.split;
   bool pressured=Pressure(p,t)>=3;if(pressured&&a.split!=null&&!a.bitten)a.split=null;
   bool Consider(string type,Vector2Int target,double basis,NativeGameplaySnake snake=null,string kind=null,int index=0,bool committed=false,NativeHunter hunter=null){
    if(snake!=null&&(!committed&&!Power(p,t)||foresightReady)&&Cooling(p,snake,t))return false;
    var o=new AllyObjective{type=type,target=target,snake=snake,kind=kind,bodyIndex=index,committed=committed,hunter=hunter};var f=ObjectiveField(o);int route=f[w.Index(p.Cell)];if(route<0||!w.UseLegacyAi&&!committed&&route>Skill.notice)return false;
    double loyalty=snake==a.locked&&kind==a.targetKind?-.35:0;o.score=basis+route+FirstRisk(p,t,o,f)+loyalty;list.Add(o);return true;
   }
   a.queue.RemoveAll(s=>!w.Snakes.Contains(s));if(a.locked!=null&&!w.Snakes.Contains(a.locked)){a.locked=null;a.bitten=false;a.commitMode=null;}
   if(a.graded!=null&&!w.Snakes.Contains(a.graded)){a.graded=null;a.gradedKind=null;a.snakeChoiceUntil=0;}
   var fruit=TacticalFruit(p,t);if(fruit!=null)return fruit;
   if(Power(p,t)){a.split=null;if(a.bitten&&a.locked!=null&&w.Snakes.Contains(a.locked)&&a.locked.Body.Count>0){var s=a.locked;Consider("power-finish-snake",s.Tail,-2000,s,s.Body.Count>1?"tail":"head",committed:true);if(list.Count>0)return list[0];}
    foreach(var s in w.Snakes){if(s.Body.Count==0)continue;double bonus=s==a.locked?-2:0;Consider("power-cleanup-head",s.Head,-90+bonus,s,"head");if(s.Body.Count>1)Consider("power-cleanup-tail",s.Tail,-92+bonus,s,"tail",s.Body.Count-1);}
    if(list.Count>0)return list.OrderBy(o=>o.score).First();foreach(var h in w.Hunters)Consider("power-hunt-enemy",h.Cell,-20,kind:"hunter",hunter:h);if(list.Count>0)return list.OrderBy(o=>o.score).First();
   }
   if(a.split!=null&&(!w.Snakes.Contains(a.split.snake)||a.split.snake.Body.Count<3))a.split=null;
   if(a.split!=null){var s=a.split.snake;int i=Math.Max(1,Math.Min(s.Body.Count-2,Round(a.split.fraction*Math.Max(1,s.Body.Count-1))));
    if(Consider("committed-split",s.Body[i],-1000,s,"split",i,true))return list[0];
    foreach(int j in Splits(s).Where(j=>j!=i))Consider("committed-split-retarget",s.Body[j],-900+Math.Abs(j-(s.Body.Count-1)/2.0)*.15,s,"split",j,true);
    if(list.Count>0){var r=list.OrderBy(o=>o.score).First();a.split.fraction=(double)r.bodyIndex/Math.Max(1,s.Body.Count-1);return r;}a.split=null;
   }
   if(a.bitten&&a.locked!=null&&w.Snakes.Contains(a.locked)&&a.locked.Body.Count>0){var s=a.locked;string kind=s.Body.Count>1?"tail":"head";Consider("committed-tail-finish",s.Tail,-1000,s,kind,committed:true);return list.Count>0?list[0]:new AllyObjective{type="committed-tail-wait",target=s.Tail,score=10000,snake=s,kind=kind,committed=true};}
   if(a.locked!=null&&w.Snakes.Contains(a.locked)&&!a.bitten){var s=a.locked;bool tail=Consider("locked-snake-tail",s.Tail,-1,s,s.Body.Count>1?"tail":"head");
    if(!tail&&s.Body.Count>=3&&!pressured&&(skill==null||a.allowSplit==true)){foreach(int i in Splits(s))Consider("locked-snake-split",s.Body[i],-12+Math.Abs(i-(s.Body.Count-1)/2.0)*.2,s,"split",i);if(list.Count>0)return list.OrderBy(o=>o.score).First();}list.Clear();
   }
   foreach(var s in w.Snakes){Consider(s.Body.Count>1?"eat-tail":"eat-solitary-head",s.Tail,0,s,s.Body.Count>1?"tail":"head");if(s.Body.Count>=3&&!pressured){double bonus=Math.Min(6.5,4.2+s.Body.Count*.2);foreach(int i in Splits(s))Consider("split-snake",s.Body[i],-bonus+Math.Abs(i-(s.Body.Count-1)/2.0)*.2,s,"split",i);}}
   if(list.Count==0)return null;list=list.OrderBy(o=>o.score).ToList();if(skill!=null)return Graded(p,t,list,skill);
   var best=list[0];var current=a.locked==null?null:list.FirstOrDefault(o=>o.snake==a.locked);if(current!=null&&current.score<=best.score+(pressured?1.25:3.25))return current;
   if(current!=null&&best.snake!=null&&best.snake!=current.snake)a.cooldowns[current.snake]=t+1600;return best;
  }
  AllyObjective Graded(NativePlayer p,double t,List<AllyObjective> sorted,AllySkill skill){
   var a=S(p);bool refresh=!Finite(a.snakeChoiceUntil)||t>=a.snakeChoiceUntil||a.graded==null||!w.Snakes.Contains(a.graded);
   if(refresh||!a.allowSplit.HasValue)a.allowSplit=w.Random()<skill.split;var list=new List<AllyObjective>();var seen=new HashSet<NativeGameplaySnake>();
   foreach(var o in sorted){if(o.snake==null||seen.Contains(o.snake)||o.kind=="split"&&a.allowSplit!=true)continue;seen.Add(o.snake);list.Add(o);}if(list.Count==0)return w.UseLegacyAi?sorted.FirstOrDefault():sorted.FirstOrDefault(o=>o.kind!="split");
   if(!refresh){var held=list.FirstOrDefault(o=>o.snake==a.graded);if(held!=null)return held;}
   int pool=Math.Max(1,Math.Min((int)skill.pool,list.Count)),rank=0;if(pool>1&&w.Random()>=skill.optimal)rank=1+(int)(w.Random()*(pool-1));
   var chosen=list[rank];a.graded=chosen.snake;a.gradedKind=chosen.kind;a.snakeChoiceUntil=t+Math.Max(0,skill.rethink);a.thought="graded-snake-choice";return chosen;
  }
 }
}


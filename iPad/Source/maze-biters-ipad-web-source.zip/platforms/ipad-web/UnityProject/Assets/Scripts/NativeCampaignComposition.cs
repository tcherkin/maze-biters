using System;
namespace MazeBiters.NativeStudy {
 // One campaign route for boot/menu caching, live starts and future scenes.
 // The original Generate entry point remains an unchanged diagnostic oracle.
 public static class NativeCampaignComposition {
  public static readonly bool Enabled=Array.IndexOf(Environment.GetCommandLineArgs(),"--legacy-level-generator")<0;
  public static readonly bool MixedCoresEnabled=Array.IndexOf(Environment.GetCommandLineArgs(),"--legacy-core-composition")<0;
  public static SessionLevel Generate(uint seed,int level,double difficulty)=>Generate(new NativeMazeGenerator(seed,difficulty),level);
  public static SessionLevel Generate(uint seed,int level,double difficulty,string family)=>Generate(new NativeMazeGenerator(seed,difficulty),level,family);
  public static SessionLevel Generate(NativeMazeGenerator generator,int level,string family=null){
   if(!Enabled||generator.LegacyStartCorridors||generator.LegacyPaletteOrder)return generator.Generate(level);
   family=family??HybridMazeStudy.FamilyForLevel(generator.Seed,level);
   try{return MixedCoresEnabled?CoreCompositionStudy.Generate(generator.Seed,level,generator.Difficulty,"automatic",family):HybridMazeStudy.Generate(generator.Seed,level,generator.Difficulty,family);}
   catch(InvalidOperationException policyFailure){
    // An unusual seed or a far-future level must not strand the loading gate.
    // Retain native safe-start repair and the intended family's title metadata.
    var fallback=generator.Generate(level);
    HybridMazeStudy.RecordFallback(fallback,generator.Seed,generator.Difficulty,family,policyFailure.Message);
    return fallback;
   }
  }
 }
}

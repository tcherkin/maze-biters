using System;
using System.IO;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Rendering;
namespace MazeBiters.NativeStudy {
 // Same outline and overlapping texture strips as snake-material-ribbon.js.
 // No rubber neck, replacement gradient, palette recolour or baked movement.
 public sealed partial class NativeSnake:IDisposable {
  readonly Texture2D mouth,solo,materialTexture;readonly Material stripPaint,outlinePaint,headPaint;readonly Mesh outline,strips,headMesh;
  readonly List<Vector3> ov,sv;readonly List<Vector2> uv;readonly List<int> oi,si;readonly NativeSnake geometryOwner;
  readonly Vector3[] headVertices=new Vector3[4];readonly Vector2[] headUV=new Vector2[4];static readonly int[] QuadIndices={0,1,2,0,2,3};
  RenderTexture bodyColor,bodyMask,headColor;readonly Mesh bodyQuad=new Mesh(),headQuad=new Mesh();Material bodyComposite,headComposite;public long SurfaceBytes=>(bodyColor?(long)bodyColor.width*bodyColor.height*4*10:0)+(headColor?(long)headColor.width*headColor.height*20:0);
  static void Triangles(List<int> ids,int a,int b,int c,int d,int e,int f){ids.Add(a);ids.Add(b);ids.Add(c);ids.Add(d);ids.Add(e);ids.Add(f);}
  readonly List<NativeSnakeTextures.Lease> textureLeases=new List<NativeSnakeTextures.Lease>(3);
  public readonly string Palette;public long TextureBytes{get{long bytes=0;foreach(var lease in textureLeases)bytes+=lease.CountedBytes;return bytes;}}
  readonly string treatment;
  // Camera zoom reserves the existing resolve surfaces at its maximum density
  // while controls are gated. No per-zoom-step RT allocation or extra scene RT.
  public float ReservedDensity;
  bool intakeOnly;public bool Culled{get;private set;}public bool ReadyForCulling{get;private set;}
  public void Cull(SnakePose pose){if(NativePoseCache.Capture){Prepare(pose);VisibilityPreparation.CheckPreparedBounds(ov.Count>0?outline.bounds:headMesh.bounds,headMesh.bounds);}Culled=true;}
  public NativeSnake(string palette,string treatment=null,NativeSnake geometry=null,bool tailTexturesOnly=false){Palette=palette;this.treatment=treatment;geometryOwner=geometry;
   if(geometry!=null){outline=geometry.outline;strips=geometry.strips;headMesh=geometry.headMesh;ov=geometry.ov;sv=geometry.sv;uv=geometry.uv;oi=geometry.oi;si=geometry.si;}
   else{outline=new Mesh();strips=new Mesh();headMesh=new Mesh();ov=new List<Vector3>(2048);sv=new List<Vector3>(4096);uv=new List<Vector2>(4096);oi=new List<int>(6000);si=new List<int>(12000);outline.MarkDynamic();strips.MarkDynamic();headMesh.MarkDynamic();}
   if(!tailTexturesOnly){mouth=Load("mouth");solo=Load("solo");}materialTexture=Load("material");stripPaint=new Material(Shader.Find("MazeBiters/SnakeSurface")){mainTexture=materialTexture};stripPaint.SetFloat("_Kind",1);outlinePaint=new Material(stripPaint);outlinePaint.SetFloat("_Kind",0);headPaint=new Material(Shader.Find("MazeBiters/SnakeHead"));}
  Texture2D Load(string part){string name=treatment==null?"anim-snake-"+Palette+"-"+part:"neon-"+Palette+"-"+part+"-"+treatment;var lease=NativeSnakeTextures.Lease.Acquire(name,part!="material");textureLeases.Add(lease);return lease.Texture;}
  public void SubmitCoverage(CommandBuffer command){if(Culled)return;if(ov.Count>0)command.DrawMesh(outline,Matrix4x4.identity,outlinePaint,0,3);if(!intakeOnly)command.DrawMesh(headMesh,Matrix4x4.identity,headPaint);}
  static double Mod(double a,double b)=>(a%b+b)%b;
  static Vector3 World(double x,double y)=>new Vector3((float)(x*16/36),(float)(-y*16/36),0);
  static Vector3 Point(RailPoint p,double x,double y){if(!RendererTuning.Optimized)return World(p.x+Math.Cos(p.angle)*x-Math.Sin(p.angle)*y,p.y+Math.Sin(p.angle)*x+Math.Cos(p.angle)*y);return World(p.x+p.tx*x-p.ty*y,p.y+p.ty*x+p.tx*y);}
  readonly List<Color> coverage=new List<Color>(2048);
  public void Prepare(SnakePose pose,bool tailOnly=false){
   Culled=geometryOwner!=null&&geometryOwner.Culled;if(Culled)return;
   intakeOnly=tailOnly;
   headPaint.SetFloat("_Nape",pose.solo?0:(float)pose.soloAmount);headPaint.SetFloat("_Opacity",pose.rearBirth?(float)pose.birthProgress:1);headPaint.mainTexture=pose.solo?solo:mouth;
   if(geometryOwner!=null)return;
   ov.Clear();oi.Clear();sv.Clear();si.Clear();uv.Clear();coverage.Clear();
   double headSpan=pose.rearBirth?SnakeCurve.Mix(SnakeMotion.Tail,SnakeMotion.Head,pose.birthProgress):SnakeMotion.Head,bodyEnd=pose.head-headSpan,tip=pose.Tip;
   double span=Math.Min(SnakeMotion.Tail*(1-pose.soloAmount)*pose.birthProgress,Math.Max(0,bodyEnd-tip)),root=tip+span;
   RailPoint At(double s,bool bend){var p=NativeRenderOptimization.Enabled?pose.rail.SampleForRender(s):pose.rail.Sample(s);if(NativePoseCache.Capture)NativeRenderOptimization.CheckSample(pose.rail,s,p);double d=s-tip;if(bend&&pose.bendSpan>.02&&d>=0&&d<pose.bendSpan){double u=d/pose.bendSpan,w=1-AnimationClock.Ease(u),derivative=-30*u*u*(1-u)*(1-u)/pose.bendSpan;p.x+=pose.bendDx*w;p.y+=pose.bendDy*w;p.angle=Math.Atan2(p.ty+pose.bendDy*derivative,p.tx+pose.bendDx*derivative);p.tx=Math.Cos(p.angle);p.ty=Math.Sin(p.angle);}return p;}
   void Ribbon(double begin,double finish,Func<double,double> widthAt,double alpha=1,bool bend=false,double tailTip=double.NaN,double tailSpan=0,bool simplify=false){
    if(!(finish>begin+1e-6)||alpha<=0)return;
    int count=Math.Max(1,(int)Math.Ceiling((finish-begin)/.4)),outlineBase=ov.Count;
    for(int i=0;i<=count;){double s=begin+(finish-begin)*i/count;var p=At(s,bend);double half=SnakeMotion.Diameter*widthAt(s)/2,extension=half>.004?(i==0?-.23:i==count?.23:0):0;int k=ov.Count;ov.Add(Point(p,extension,half));ov.Add(Point(p,extension,-half));coverage.Add(new Color(1,1,1,(float)alpha));coverage.Add(new Color(1,1,1,(float)alpha));
     if(k>outlineBase)Triangles(oi,k-2,k,k-1,k,k+1,k-1);
     int next=i+1;
     // Only constant-width, axis-aligned straight runs can discard collinear
     // interior vertices. Keep the original grid endpoints and every curve,
     // taper and intake-bend sample. Material strips are entirely unchanged.
     if(NativeRenderOptimization.Enabled&&simplify&&i>0&&s>=root&&s>=tip+pose.bendSpan&&p.curve==0&&((p.tx==0&&Math.Abs(p.ty)==1)||(p.ty==0&&Math.Abs(p.tx)==1))){
      double available=pose.rail.RibbonSpan(s,finish-s);
      if(available>2)next=Math.Max(next,Math.Min(count,(int)Math.Floor((s+available-begin)*count/(finish-begin)-1e-6)));
     }
     i=next;
    }
    double nominal=Math.Max(.01,pose.length-SnakeMotion.Head-SnakeMotion.Tail*(1-pose.soloAmount)),rate=nominal/Math.Max(.01,nominal-pose.compression),sign=pose.materialSign;
    for(double s=begin;s<finish-1e-7;){
     double value=pose.frontMaterial-sign*(SnakeMotion.Head+(pose.Rear-s)*rate),u=Mod(value-SnakeMotion.Tail,36)/36,boundary=(sign>0?1-u:u==0?1:u)*36/rate;
     double ds=pose.rail.RibbonSpan(s,Math.Min(finish-s,Math.Max(.00001,boundary)));if(Math.Abs(s-tailTip)<tailSpan)ds=Math.Min(ds,Math.Min(.35,tailSpan/32));ds=Math.Max(.000001,Math.Min(ds,finish-s));
     var p=At(s+ds/2,bend);double width=SnakeMotion.Diameter*widthAt(s+ds/2);
     if(width>.008){double sw=ds*rate/36*160,pad=.23*rate/36*160,sx=160+u*160-(sign<0?sw:0)-pad,dx=-ds/2-.23,dy=-width/2-width*8/58,dw=ds+.46,dh=width*(1+16.0/58);int k=sv.Count;
      sv.Add(Point(p,sign*dx,dy));sv.Add(Point(p,sign*(dx+dw),dy));sv.Add(Point(p,sign*(dx+dw),dy+dh));sv.Add(Point(p,sign*dx,dy+dh));
      uv.Add(new Vector2((float)(sx/480),1));uv.Add(new Vector2((float)((sx+sw+2*pad)/480),1));uv.Add(new Vector2((float)((sx+sw+2*pad)/480),0));uv.Add(new Vector2((float)(sx/480),0));Triangles(si,k,k+1,k+2,k,k+2,k+3);}
     s+=ds;
    }
   }
   if(!pose.solo){
    double Width(double s)=>SnakeMotion.TailWidth(span>0?(s-tip)/span:1);
    if(tailOnly){if(span>.02)Ribbon(tip,root,Width,1-pose.soloAmount,true,tip,span);}
    else if(span>.02&&pose.soloAmount==0)Ribbon(tip,bodyEnd+.15,Width,1,true,tip,span,true);
    else {Ribbon(root,bodyEnd+.15,s=>1,simplify:true);if(span>.02)Ribbon(tip,root,Width,1-pose.soloAmount,true,tip,span);}
    if(!tailOnly&&pose.rearBirth&&pose.birthProgress<1)Ribbon(pose.head-SnakeMotion.Tail,pose.head,s=>SnakeMotion.TailWidth((pose.head-s)/SnakeMotion.Tail),1-pose.birthProgress,false,pose.head,SnakeMotion.Tail);
   }
   bool transform=pose.paintScale!=1||pose.paintAngle!=0||pose.paintX!=0||pose.paintY!=0;
   double paintCos=NativeRenderOptimization.Enabled?Math.Cos(pose.paintAngle):0,paintSin=NativeRenderOptimization.Enabled?Math.Sin(pose.paintAngle):0;
   Vector3 Painted(Vector3 point){double x=point.x*36/16-pose.paintPivotX,y=-point.y*36/16-pose.paintPivotY,c=NativeRenderOptimization.Enabled?paintCos:Math.Cos(pose.paintAngle),s=NativeRenderOptimization.Enabled?paintSin:Math.Sin(pose.paintAngle);return World(pose.paintPivotX+pose.paintX+pose.paintScale*(c*x-s*y),pose.paintPivotY+pose.paintY+pose.paintScale*(s*x+c*y));}
   if(transform){for(int i=0;i<ov.Count;i++)ov[i]=Painted(ov[i]);for(int i=0;i<sv.Count;i++)sv[i]=Painted(sv[i]);}
   outline.Clear();outline.SetVertices(ov);outline.SetColors(coverage);outline.SetTriangles(oi,0);strips.Clear();strips.SetVertices(sv);strips.SetUVs(0,uv);strips.SetTriangles(si,0);
   if(tailOnly)return;
   var rear=pose.rigidRear??pose.rail.Sample(pose.Rear);double scale=SnakeMotion.Diameter/76,w=224*scale,h=176*scale,y=-70*scale;int frame=pose.mouthOverride<0?SnakeMotion.Mouth(pose.phase):pose.mouthOverride,col=frame%9,row=frame/9;
   headVertices[0]=Point(rear,0,y);headVertices[1]=Point(rear,w,y);headVertices[2]=Point(rear,w,y+h);headVertices[3]=Point(rear,0,y+h);headUV[0]=new Vector2(col/9f,1-row/11f);headUV[1]=new Vector2((col+1)/9f,1-row/11f);headUV[2]=new Vector2((col+1)/9f,1-(row+1)/11f);headUV[3]=new Vector2(col/9f,1-(row+1)/11f);
   if(transform)for(int i=0;i<4;i++)headVertices[i]=Painted(headVertices[i]);
   headMesh.Clear();headMesh.vertices=headVertices;headMesh.uv=headUV;headMesh.triangles=QuadIndices;ReadyForCulling=true;
  }
  public void Submit(CommandBuffer command,int stencil,Camera camera){if(Culled)return;
   if(ov.Count>0){
    // Match Pixi: material and silhouette are independently MSAA-resolved,
    // then multiplied. A stencil-only contour changes subpixel tail coverage.
    float ppu=camera.targetTexture.height/(camera.orthographicSize*2),screenLeft=camera.transform.position.x-camera.orthographicSize*camera.aspect,screenBottom=camera.transform.position.y-camera.orthographicSize;
    var bounds=outline.bounds;int x=Math.Max(0,Mathf.FloorToInt((bounds.min.x-screenLeft)*ppu)-2),y=Math.Max(0,Mathf.FloorToInt((bounds.min.y-screenBottom)*ppu)-2);
    int w=Math.Min(camera.targetTexture.width,Mathf.CeilToInt((bounds.max.x-screenLeft)*ppu)+2)-x,h=Math.Min(camera.targetTexture.height,Mathf.CeilToInt((bounds.max.y-screenBottom)*ppu)+2)-y;
    if(w>0&&h>0){
     if(!bodyColor||bodyColor.width<w||bodyColor.height<h){int cw=Math.Max(bodyColor?bodyColor.width:0,Mathf.CeilToInt(Math.Max(w,Math.Min(camera.targetTexture.width,bounds.size.x*ReservedDensity+6))/32f)*32),ch=Math.Max(bodyColor?bodyColor.height:0,Mathf.CeilToInt(Math.Max(h,Math.Min(camera.targetTexture.height,bounds.size.y*ReservedDensity+6))/32f)*32);ReleaseSurfaces();RenderTexture Make(){var rt=new RenderTexture(cw,ch,0,RenderTextureFormat.ARGB32){antiAliasing=4,filterMode=FilterMode.Bilinear,wrapMode=TextureWrapMode.Clamp};rt.Create();return rt;}bodyColor=Make();bodyMask=Make();if(!bodyComposite)bodyComposite=new Material(Shader.Find("MazeBiters/SnakeComposite"));bodyComposite.mainTexture=bodyColor;bodyComposite.SetTexture("_MaskTex",bodyMask);}
     float left=screenLeft+x/ppu,bottom=screenBottom+y/ppu;var projection=GL.GetGPUProjectionMatrix(Matrix4x4.Ortho(left,left+bodyColor.width/ppu,bottom,bottom+bodyColor.height/ppu,-1,1),true);
     command.SetViewProjectionMatrices(Matrix4x4.identity,projection);command.SetRenderTarget(bodyColor);command.ClearRenderTarget(false,true,treatment=="emission"?Color.black:new Color(16/255f,19/255f,16/255f,1));command.DrawMesh(strips,Matrix4x4.identity,stripPaint,0,2);
     command.SetRenderTarget(bodyMask);command.ClearRenderTarget(false,true,Color.clear);command.DrawMesh(outline,Matrix4x4.identity,outlinePaint,0,3);
     command.SetRenderTarget(camera.targetTexture);command.SetViewProjectionMatrices(camera.worldToCameraMatrix,camera.projectionMatrix);
     bodyQuad.Clear();bodyQuad.vertices=new[]{new Vector3(left,bottom),new Vector3(left+w/ppu,bottom),new Vector3(left+w/ppu,bottom+h/ppu),new Vector3(left,bottom+h/ppu)};bodyQuad.uv=new[]{new Vector2(0,0),new Vector2((float)w/bodyColor.width,0),new Vector2((float)w/bodyColor.width,(float)h/bodyColor.height),new Vector2(0,(float)h/bodyColor.height)};bodyQuad.triangles=QuadIndices;command.DrawMesh(bodyQuad,Matrix4x4.identity,bodyComposite);
    }
   }
   if(intakeOnly)return;
   if(treatment==null){command.DrawMesh(headMesh,Matrix4x4.identity,headPaint);return;}
   // WebGL and D3D11 use different render-target origins. Resolve the small
   // head bounds with the same backend-aware orientation as the ribbon,
   // not a whole-HD/4K multisampled scene just to cover a few sprite edges.
   float density=camera.targetTexture.height/(camera.orthographicSize*2),originX=camera.transform.position.x-camera.orthographicSize*camera.aspect,originY=camera.transform.position.y-camera.orthographicSize;
   var box=headMesh.bounds;int hx=Mathf.FloorToInt((box.min.x-originX)*density)-2,hy=Mathf.FloorToInt((box.min.y-originY)*density)-2,hw=Mathf.CeilToInt((box.max.x-originX)*density)+2-hx,hh=Mathf.CeilToInt((box.max.y-originY)*density)+2-hy;
   if(!headColor||headColor.width<hw||headColor.height<hh){if(headColor){headColor.Release();UnityEngine.Object.Destroy(headColor);}headColor=new RenderTexture(Mathf.CeilToInt(Math.Max(hw,box.size.x*ReservedDensity+6)/16f)*16,Mathf.CeilToInt(Math.Max(hh,box.size.y*ReservedDensity+6)/16f)*16,0,RenderTextureFormat.ARGB32){antiAliasing=4,filterMode=FilterMode.Bilinear,wrapMode=TextureWrapMode.Clamp};headColor.Create();if(!headComposite)headComposite=new Material(Shader.Find("MazeBiters/SnakeComposite"));headComposite.mainTexture=headColor;headComposite.SetTexture("_MaskTex",Texture2D.whiteTexture);}
   float lx=originX+hx/density,by=originY+hy/density;
   command.SetRenderTarget(headColor);command.ClearRenderTarget(false,true,Color.clear);command.SetViewProjectionMatrices(Matrix4x4.identity,GL.GetGPUProjectionMatrix(Matrix4x4.Ortho(lx,lx+headColor.width/density,by,by+headColor.height/density,-1,1),true));command.DrawMesh(headMesh,Matrix4x4.identity,headPaint);
   command.SetRenderTarget(camera.targetTexture);command.SetViewProjectionMatrices(camera.worldToCameraMatrix,camera.projectionMatrix);
   headQuad.Clear();headQuad.vertices=new[]{new Vector3(lx,by),new Vector3(lx+hw/density,by),new Vector3(lx+hw/density,by+hh/density),new Vector3(lx,by+hh/density)};headQuad.uv=new[]{new Vector2(0,0),new Vector2((float)hw/headColor.width,0),new Vector2((float)hw/headColor.width,(float)hh/headColor.height),new Vector2(0,(float)hh/headColor.height)};headQuad.triangles=QuadIndices;command.DrawMesh(headQuad,Matrix4x4.identity,headComposite);
  }
  void ReleaseSurfaces(){foreach(var rt in new[]{bodyColor,bodyMask})if(rt){rt.Release();UnityEngine.Object.Destroy(rt);}bodyColor=bodyMask=null;}
  public void ResetSurfaces(){ReleaseSurfaces();if(headColor){headColor.Release();UnityEngine.Object.Destroy(headColor);headColor=null;}}
  public void Dispose(){ReleaseSurfaces();if(headColor){headColor.Release();UnityEngine.Object.Destroy(headColor);}if(geometryOwner==null)foreach(var mesh in new[]{outline,strips,headMesh})UnityEngine.Object.Destroy(mesh);foreach(var lease in textureLeases)lease.Dispose();foreach(var o in new UnityEngine.Object[]{stripPaint,outlinePaint,headPaint,bodyQuad,bodyComposite,headQuad,headComposite})UnityEngine.Object.Destroy(o);}
 }
}

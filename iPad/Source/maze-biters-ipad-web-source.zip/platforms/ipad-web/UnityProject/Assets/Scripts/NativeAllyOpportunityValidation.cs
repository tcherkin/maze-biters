#if UNITY_EDITOR
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using UnityEngine;

namespace MazeBiters.NativeStudy {
 // These are gameplay/contact tests, not a visual or device-performance test.
 // Fixtures rotate the actual world and use the public planner and movement.
 public static class NativeAllyOpportunityValidation {
  static readonly Vector2Int Centre=new Vector2Int(15,15),Right=Vector2Int.right,Down=Vector2Int.up;
  sealed class Fixture {
   public NativeGameplayWorld w;public NativePlayer p;public int rotation;public List<NativeWorldEvent> events=new List<NativeWorldEvent>();
   public Vector2Int D(Vector2Int d){for(int i=0;i<rotation;i++)d=new Vector2Int(-d.y,d.x);return d;}
   public Vector2Int C(int x,int y)=>Centre+D(new Vector2Int(x,y));
   public string Detail=>"next="+p.Next+", direction="+p.Dir+", thought="+p.Ai.thought+", forecast="+p.Ai.foresightReason+", risk="+p.Ai.foresightChosenRisk;
  }
  static Fixture World(int tier,int mode=0,int rotation=0,double random=.99,bool meal=false,string shape="open"){
   var f=new Fixture{rotation=rotation};var grid=Enumerable.Range(0,31).Select(y=>new string('#',31).ToCharArray()).ToArray();
   for(int y=-13;y<=13;y++)for(int x=-13;x<=13;x++)if(shape=="open"||y==0&&(shape!="dead-end"||x<=0)||shape=="cross"&&x==0){var c=f.C(x,y);grid[c.y][c.x]='.';}
   // Other participants remain alive but distant, outside this encounter.
   grid[1][1]=grid[1][2]=grid[1][3]=grid[29][1]='.';
   f.w=new NativeGameplayWorld(grid.Select(r=>new string(r)).ToArray(),()=>random){AiDifficulty=tier,Difficulty=NativeMazeGenerator.Difficulties[tier],Time=1000,RealTime=1000,LevelStarted=1000,Assist=false,SessionEnabled=true};
   f.w.SetMode(mode);for(int i=0;i<f.w.PlayerCount;i++){var q=f.w.GetPlayer(i);q.Cell=q.From=q.Previous=new Vector2Int(1+i,1);q.Dir=q.Next=f.D(Right);q.Score=0;q.ExactScore=0;q.Waiting=false;q.ShieldUntil=q.PowerUntil=0;}
   f.p=f.w.GetPlayer(f.w.PlayerCount-1);f.p.Cell=f.p.From=f.p.Previous=Centre;f.p.Dir=f.p.Next=f.D(Right);f.p.Score=200;f.p.ExactScore=200;f.p.LastMove=f.w.Time-96;
   f.w.Ally.BeginLevel();f.p.Ai.mealInitialized=true;f.p.Ai.mealActive=meal;f.p.Ai.mealIntentUntil=10000;f.p.Ai.allowSplit=false;f.w.Event=e=>f.events.Add(e);
   // A disconnected sentinel keeps genuine level-completion logic from ending
   // a short synthetic meal, without affecting local routing or forecasting.
   var sentinel=f.w.AddSnake(new[]{new Vector2Int(1,29)},Right,4);sentinel.LastMove=f.w.Time;
   return f;
  }
  static NativeGameplaySnake Add(Fixture f,IEnumerable<Vector2Int> cells,Vector2Int d){var s=f.w.AddSnake(cells.Select(c=>f.C(c.x,c.y)),f.D(d),0);s.LastMove=f.w.Time;return s;}
  static NativeGameplaySnake Tail(Fixture f,int length=4,int start=1)=>Add(f,Enumerable.Range(start,length).Reverse().Select(x=>new Vector2Int(x,0)),Right);
  static void Plan(NativeCasualBiteReport r,Fixture f){f.w.Ally.Plan(f.p,f.w.Time);r.decisions++;}
  static void Advance(Fixture f){using(f.w.ForPlayer(f.p))f.w.AdvancePlayer();f.p.LastMove=f.w.Time;f.w.Time+=95;}
  static void Step(NativeCasualBiteReport r,Fixture f){Plan(r,f);Advance(f);}
  static void Check(NativeCasualBiteReport r,bool passed,string name,string detail=""){r.assertions++;if(!passed)r.failures++;r.checks.Add(new NativeDifficultyCheck{name=name,passed=passed,detail=detail});}
  static void Group(NativeCasualBiteReport r,string name,Action body){try{body();}catch(Exception e){Check(r,false,name+" completed",e.ToString());}}
  static string Label(int tier,int mode,int rotation,double random,bool meal)=>$"tier={tier}, mode={mode}, rotation={rotation}, random={random}, held meal={meal}";

  static void NearbyContacts(NativeCasualBiteReport r){
   for(int tier=0;tier<4;tier++)foreach(int mode in new[]{0,3,4})for(int rotation=0;rotation<4;rotation++)foreach(double random in new[]{0.0,.99})foreach(bool meal in new[]{false,true}){
    string label=Label(tier,mode,rotation,random,meal);
    {var f=World(tier,mode,rotation,random,meal);var s=Tail(f);Plan(r,f);Check(r,f.p.Next==f.D(Right),"Safe forward tail is accepted: "+label,f.Detail);Advance(f);
     Check(r,!f.p.Dead&&f.p.Cell==f.C(1,0)&&s.Body.Count==3&&f.p.ExactScore>200,"Forward tail is actually eaten: "+label,f.Detail);}
    {var f=World(tier,mode,rotation,random,meal);var s=Tail(f);f.p.Dir=f.p.Next=f.D(Down);Plan(r,f);Check(r,f.p.Next==f.D(Right),"Adjacent side tail beats unnecessary wandering: "+label,f.Detail);Advance(f);
     Check(r,!f.p.Dead&&s.Body.Count==3&&f.p.Cell==f.C(1,0),"Side-tail decision resolves through ordinary movement: "+label,f.Detail);}
    {var f=World(tier,mode,rotation,random,meal);var s=Add(f,Enumerable.Range(-3,7).Select(y=>new Vector2Int(1,y)),new Vector2Int(0,-1));Plan(r,f);
     Check(r,f.p.Next==f.D(Right),"Safe transverse body is accepted despite held split-interest veto: "+label,f.Detail);Advance(f);
     Check(r,!f.p.Dead&&!f.w.Snakes.Contains(s)&&f.w.Snakes.Count==3&&f.events.Count(e=>e.Kind=="split"&&e.Snake==s)==1,"Real split creates the two ordinary fragments: "+label,f.Detail);}
    foreach(var facing in new[]{Right,Down,-Down}){var f=World(tier,mode,rotation,random,meal);var s=Add(f,new[]{new Vector2Int(1,0)},facing);Step(r,f);
     Check(r,!f.p.Dead&&!f.w.Snakes.Contains(s)&&f.p.Cell==f.C(1,0),"A safe nonfrontal solitary head is eaten, facing="+facing+": "+label,f.Detail);}
   }
  }

  static void ContinuousMealsAndCombo(NativeCasualBiteReport r){
   for(int tier=0;tier<4;tier++)foreach(int mode in new[]{0,3,4})for(int rotation=0;rotation<4;rotation++)foreach(double random in new[]{0.0,.99}){
    string label=Label(tier,mode,rotation,random,true);
    {var f=World(tier,mode,rotation,random,true);var first=Tail(f);var second=Tail(f,7,5);
     f.p.Ai.mealIntentUntil=f.w.Time+1;
     for(int i=0;i<4;i++){Step(r,f);Check(r,!f.p.Dead&&f.p.Cell==f.C(i+1,0),"An actual continuous meal survives strategic intent expiry, step="+i+": "+label,f.Detail);}
     Check(r,!f.w.Snakes.Contains(first)&&second.Body.Count==7,"Continuous consumption finishes the first snake including its head: "+label,f.Detail);
     Step(r,f);Check(r,!f.p.Dead&&f.p.Cell==f.C(5,0)&&second.Body.Count==6&&f.p.Combo.Active&&f.p.Combo.SnakeCount==2,"Next adjacent snake begins a genuine uninterrupted combo: "+label,f.Detail);
     Check(r,f.events.Count(e=>e.Kind=="sound"&&e.Sound=="snakeSTART@")==1&&f.p.PowerUntil==0&&!f.p.PowerBright,"Combo emits its cue once without granting fruit Power: "+label);
     Step(r,f);Check(r,f.p.Combo.Active&&second.Body.Count==5,"Eating the second snake continues rather than abandoning the combo: "+label,f.Detail);
     double branchAt=f.w.Time;f.p.Next=f.D(Down);f.p.Waiting=false;Advance(f);Check(r,f.p.Combo.Active&&f.p.Combo.CoolingDown&&Math.Abs(f.p.Combo.CooldownUntil-branchAt-1000)<.001,"An actual empty branch step starts the one-second combo grace: "+label);
     f.p.Combo.Advance(f.p.Combo.CooldownUntil);Check(r,!f.p.Combo.Active&&f.p.Combo.SnakeCount==0,"The AI meal chain expires at the grace boundary: "+label);
    }
    {var f=World(tier,mode,rotation,random);var s=Tail(f,2);Step(r,f);Step(r,f);Check(r,!f.p.Dead&&!f.w.Snakes.Contains(s)&&f.p.Cell==f.C(2,0),"One safe tail bite is enough to finish its adjacent head: "+label,f.Detail);}
    {var f=World(tier,mode,rotation,random);var s=Tail(f);Step(r,f);Step(r,f);var distraction=Add(f,new[]{new Vector2Int(2,3),new Vector2Int(2,2),new Vector2Int(2,1)},Down);Step(r,f);
     Check(r,!f.p.Dead&&f.p.Cell==f.C(3,0)&&s.Body.Count==1&&distraction.Body.Count==3,"Remaining nearby meal beats a distracting side snack: "+label,f.Detail);}
   }
  }

  static void BoundariesAndSafety(NativeCasualBiteReport r){
   for(int tier=0;tier<4;tier++)for(int rotation=0;rotation<4;rotation++)foreach(double random in new[]{0.0,.99}){
    string label=Label(tier,0,rotation,random,false);
    {var f=World(tier,rotation:rotation,random:random);var s=Tail(f);f.p.ShieldUntil=f.w.Time+5000;Step(r,f);Check(r,!f.p.Dead&&s.Body.Count==3&&f.p.ExactScore>200,"Spawn shield preserves ordinary safe tail eating: "+label,f.Detail);}
    {var f=World(tier,rotation:rotation,random:random);var s=Add(f,Enumerable.Range(-3,7).Select(y=>new Vector2Int(1,y)),new Vector2Int(0,-1));f.p.ShieldUntil=f.w.Time+5000;Step(r,f);Check(r,!f.p.Dead&&!f.w.Snakes.Contains(s)&&f.w.Snakes.Count==3,"Spawn shield preserves ordinary transverse splitting: "+label,f.Detail);}
    {var f=World(tier,rotation:rotation,random:random);var s=Tail(f,2);f.p.ShieldUntil=f.w.Time+5000;Step(r,f);Step(r,f);Check(r,!f.p.Dead&&!f.w.Snakes.Contains(s)&&f.p.Cell==f.C(2,0),"Spawn shield permits safe rear-head completion: "+label,f.Detail);}
    foreach(string protectedThreat in new[]{"frontal-head","hunter"}){var f=World(tier,rotation:rotation,random:random);NativeGameplaySnake s=null;NativeHunter h=null;
     if(protectedThreat=="frontal-head")s=Add(f,new[]{new Vector2Int(1,0),new Vector2Int(2,0),new Vector2Int(3,0)},-Right);else{h=new NativeHunter{Id=500,Cell=f.C(1,0),From=f.C(1,0),Dir=f.D(-Right),LastMove=f.w.Time};f.w.Hunters.Add(h);}f.p.ShieldUntil=f.w.Time+5000;Step(r,f);
     Check(r,!f.p.Dead&&f.p.ExactScore==200&&(s==null||f.w.Snakes.Contains(s)&&s.Body.Count==3)&&(h==null||f.w.Hunters.Contains(h))&&!f.w.CreatureAttackPower(f.p,f.w.Time),"Spawn shield grants no frontal-head/hunter attack power, "+protectedThreat+": "+label,f.Detail);
    }
    foreach(string threat in new[]{"frontal-head","hunter","predicted-mouth","solid-egg","overlap","scorpion"}){
     var f=World(tier,rotation:rotation,random:random);var s=Tail(f);
     if(threat=="frontal-head"){f.w.Snakes.Remove(s);s=Add(f,new[]{new Vector2Int(1,0),new Vector2Int(2,0),new Vector2Int(3,0)},-Right);}
     if(threat=="hunter")f.w.Hunters.Add(new NativeHunter{Id=500,Cell=f.C(1,-1),From=f.C(1,-1),Dir=f.D(Down),LastMove=f.w.Time});
     if(threat=="predicted-mouth")Add(f,new[]{new Vector2Int(1,-1),new Vector2Int(1,-2)},Down).LastMove=f.w.Time-210;
     if(threat=="solid-egg"){f.w.SolidEggs.Add(f.C(1,0));f.w.ObstacleRevision++;}
     if(threat=="overlap"){Add(f,new[]{new Vector2Int(1,0),new Vector2Int(1,1),new Vector2Int(1,2)},-Down);f.p.PowerUntil=f.w.Time+5000;}
     if(threat=="scorpion")f.w.PlaceScorpion(f.C(1,0),f.D(Right));
     Plan(r,f);Check(r,f.p.Next!=f.D(Right)||f.p.Waiting,"Genuine danger/ambiguity overrides opportunity, "+threat+": "+label,f.Detail);
     if(threat!="overlap"){Advance(f);Check(r,!f.p.Dead&&f.w.Snakes.Contains(s),"Rejected unsafe opportunity does not cause an actual eating death, "+threat+": "+label,f.Detail);}
    }
    {var f=World(tier,3,rotation,random);var s=Tail(f);var human=f.w.GetPlayer(0);human.Cell=human.From=human.Previous=f.C(0,-1);human.Dir=human.Next=f.D(Down);human.Score=500;human.ExactScore=500;Plan(r,f);
     Check(r,f.p.Ai.directive?.type=="flee"&&f.p.Next!=f.D(Right),"A stronger nearby participant keeps its real flee priority: "+label,f.Detail);}
    {var f=World(tier,rotation:rotation,random:random);var s=Tail(f);Step(r,f);f.p.Next=f.D(Down);Advance(f);Plan(r,f);Check(r,f.p.Ai.casualSnake==null,"An actual empty side branch clears local meal continuity: "+label,f.Detail);}
    {var f=World(tier,rotation:rotation,random:random);var s=Tail(f);Step(r,f);s.Body=s.Body.Select(c=>c+f.D(Right)*5).ToList();s.Cell=s.Head;Plan(r,f);Advance(f);Plan(r,f);
     Check(r,f.p.Ai.casualSnake==null,"A departed distant snake cannot retain local finishing priority: "+label,f.Detail);}
   }
  }

  static void MouthArrivalTiming(NativeCasualBiteReport r){
   for(int tier=0;tier<5;tier++)for(int rotation=0;rotation<4;rotation++)foreach(double random in new[]{0.0,.99})foreach(bool dueNow in new[]{false,true}){
    var f=World(tier,rotation:rotation,random:random,meal:true);string label=Label(tier,0,rotation,random,true)+", imminent="+dueNow;
    // Force the approaching head toward the contact cell, while preserving
    // multiple real exits beyond it. A blind corridor would correctly make
    // the second eating step unsafe due to later interception at its gate.
    foreach(var c in new[]{f.C(0,-1),f.C(2,-1)}){var row=f.w.Grid[c.y].ToCharArray();row[c.x]='#';f.w.Grid[c.y]=new string(row);}f.w.ObstacleRevision++;f.w.Ally.ScanMaze(true);
    var meal=Tail(f,5);var approach=Add(f,new[]{new Vector2Int(1,-1),new Vector2Int(1,-2)},Down);approach.LastMove=f.w.Time-(dueNow?210:0);
    double plannedAt=f.w.Time;Plan(r,f);
    if(dueNow){Check(r,f.p.Next!=f.D(Right)||f.p.Waiting,"An almost-due head arrival still vetoes the tempting tail: "+label,f.Detail);Advance(f);Check(r,!f.p.Dead&&meal.Body.Count==5,"Imminent mouth timing preserves the real safety veto: "+label,f.Detail);}
    else{
     Check(r,f.p.Next==f.D(Right)&&!f.p.Waiting,"A future mouth cell is usable when the AI can leave before the snake is due: "+label,f.Detail);Advance(f);Plan(r,f);Advance(f);
     Check(r,!f.p.Dead&&f.p.Cell==f.C(2,0)&&meal.Body.Count==3,"AI actually takes two safe eating steps before the later mouth arrival: "+label,f.Detail);
     f.w.Time=plannedAt+219;f.w.SnakeStep(approach);Check(r,approach.Head==f.C(1,0)&&!f.p.Dead&&f.p.Cell==f.C(2,0),"The genuine delayed snake movement enters the already vacated cell safely: "+label,f.Detail);
    }
   }
  }

  static void MovingTailContinuation(NativeCasualBiteReport r){
   for(int tier=0;tier<4;tier++)for(int rotation=0;rotation<4;rotation++)foreach(double random in new[]{0.0,.99}){
    var f=World(tier,rotation:rotation,random:random,shape:"corridor");var snake=Tail(f);string label=Label(tier,0,rotation,random,false);
    Step(r,f);f.w.SnakeStep(snake);Plan(r,f);
    Check(r,f.p.Next==f.D(Right)&&f.p.Ai.thought=="casual-follow-gap","A real moving tail gets one deliberate safe catch-up cell: "+label,f.Detail);Advance(f);
    Check(r,f.p.Cell==f.C(2,0)&&snake.Tail==f.C(3,0)&&!f.p.Combo.Active&&f.p.Combo.SnakeCount==0,"Catch-up movement is actual empty travel, never an invented combo bite: "+label,f.Detail);
    for(int i=0;i<3;i++)Step(r,f);
    Check(r,!f.p.Dead&&!f.w.Snakes.Contains(snake)&&f.p.Cell==f.C(5,0),"After one natural gap the same nearby moving snake is finished: "+label,f.Detail);
   }
  }

  static void DirectionContinuity(NativeCasualBiteReport r){
   for(int tier=0;tier<4;tier++)for(int rotation=0;rotation<4;rotation++)foreach(double random in new[]{0.0,.99})foreach(bool meal in new[]{false,true}){
    string label=Label(tier,0,rotation,random,meal);
    foreach(string shape in new[]{"corridor","cross","open"}){var f=World(tier,rotation:rotation,random:random,meal:meal,shape:shape);
     for(int step=0;step<6;step++){var previous=f.p.Dir;Plan(r,f);Check(r,!f.p.Waiting&&f.p.Next!=-previous,"Random error cannot invent a safe empty-space reversal, "+shape+", step="+step+": "+label,f.Detail);Advance(f);}}
    {var f=World(tier,rotation:rotation,random:random,meal:meal,shape:"dead-end");Plan(r,f);Check(r,!f.p.Waiting&&f.p.Next==f.D(-Right),"A true dead end still permits necessary retreat: "+label,f.Detail);Advance(f);Check(r,f.p.Cell==f.C(-1,0)&&!f.p.Dead,"Necessary dead-end retreat really moves: "+label);}
    {var f=World(tier,rotation:rotation,random:random,meal:meal,shape:"corridor");Add(f,new[]{new Vector2Int(1,0),new Vector2Int(2,0),new Vector2Int(3,0)},-Right);Plan(r,f);
     Check(r,!f.p.Waiting&&f.p.Next==f.D(-Right),"An imminent frontal head still permits an urgent reverse escape: "+label,f.Detail);Advance(f);Check(r,!f.p.Dead&&f.p.Cell==f.C(-1,0),"Urgent reversal avoids the actual collision: "+label,f.Detail);}
   }
  }

  static void StrongProfileScope(NativeCasualBiteReport r){
   foreach(bool legacy in new[]{false,true})foreach(int rotation in new[]{0,1,2,3}){var f=World(4,rotation:rotation);f.w.UseLegacyAi=legacy;Tail(f);f.p.Next=f.D(Right);Advance(f);Check(r,f.p.Ai.casualSnake==null&&f.p.Ai.casualBites==0,"BRUTAL and historical brain do not gain the lower-tier contact policy: legacy="+legacy+", rotation="+rotation);}
   for(int tier=0;tier<4;tier++){var f=World(tier);Tail(f);Step(r,f);f.w.Time=f.w.LevelStarted+300000;Plan(r,f);Check(r,f.w.DifficultyProfile.Maximum&&f.p.Ai.casualSnake==null&&f.p.Ai.mealActive&&double.IsPositiveInfinity(f.p.Ai.mealIntentUntil),"Escalated maximum retains its existing full strategic meal intent: tier="+tier,f.Detail);}
  }
  static void MaximumPracticalChoices(NativeCasualBiteReport r){
   for(int rotation=0;rotation<4;rotation++)foreach(double random in new[]{0.0,.99}){
    string label=Label(4,0,rotation,random,true);
    {var f=World(4,rotation:rotation,random:random,meal:true);f.p.Ai.allowSplit=true;
     var crossing=Add(f,Enumerable.Range(-3,7).Select(y=>new Vector2Int(1,y)),new Vector2Int(0,-1));
     Add(f,new[]{new Vector2Int(-4,0),new Vector2Int(-3,0)},-Right);Add(f,new[]{new Vector2Int(0,4),new Vector2Int(0,3)},Down);
     Plan(r,f);Check(r,f.p.Next==f.D(Right),"BRUTAL predicts a safe dense crossing instead of rejecting all nearby-head pressure: "+label,f.Detail);Advance(f);
     Check(r,!f.p.Dead&&!f.w.Snakes.Contains(crossing)&&f.events.Any(e=>e.Kind=="split"&&e.Snake==crossing),"Dense safe crossing executes the actual split: "+label,f.Detail);
    }
    {var f=World(4,rotation:rotation,random:random,meal:true);var meal=Tail(f);Step(r,f);f.p.Dir=f.p.Next=f.D(Down);f.p.Ai.allowSplit=true;
     var distraction=Add(f,Enumerable.Range(-2,7).Reverse().Select(x=>new Vector2Int(x,1)),Right);
     Check(r,f.p.Ai.bitten&&f.p.Ai.locked==meal,"The BRUTAL continuation fixture is established by an actual tail bite: "+label);
     Plan(r,f);Check(r,f.p.Next==f.D(Right),"BRUTAL keeps its safe ongoing side meal over an unrelated forward split: "+label,f.Detail);Advance(f);
     Check(r,!f.p.Dead&&meal.Body.Count==2&&f.w.Snakes.Contains(distraction)&&distraction.Body.Count==7,"The established meal is really continued without cutting the distraction: "+label,f.Detail);
    }
    foreach(bool shield in new[]{false,true}){var f=World(4,rotation:rotation,random:random);var s=Tail(f,2);if(shield)f.p.ShieldUntil=f.w.Time+5000;Step(r,f);Step(r,f);
     Check(r,!f.p.Dead&&!f.w.Snakes.Contains(s)&&f.p.Cell==f.C(2,0)&&f.p.Ai.mealActive,"BRUTAL begins and completes ordinary safe eating, including initial spawn shield="+shield+": "+label,f.Detail);}
   }
  }
  static NativePlayer HoldHunt(Fixture f,Vector2Int relative){
   var human=f.w.GetPlayer(0);human.Cell=human.From=human.Previous=f.p.Cell+f.D(relative);human.Dir=human.Next=f.D(Right);human.Score=0;human.ExactScore=0;human.ShieldUntil=human.PowerUntil=0;
   // Hold a genuine, legal competitive intention inside even PICNIC's notice
   // radius, independently of whether its rare hunt-interest roll fires now.
   var skill=(AllySkill)typeof(NativeAllyBrain).GetProperty("Skill",System.Reflection.BindingFlags.Instance|System.Reflection.BindingFlags.NonPublic).GetValue(f.w.Ally);
   f.p.Ai.directive=new AllyDirective{type="hunt",target=human,threats=new List<NativePlayer>(),skill=skill};f.p.Ai.opponentHuntUntil=f.w.Time+5000;f.p.Ai.assessmentAt=f.w.Time+5000;return human;
  }
  static void LocalMealVersusHunt(NativeCasualBiteReport r){
   for(int tier=0;tier<5;tier++)for(int rotation=0;rotation<4;rotation++){
    string label=Label(tier,3,rotation,.99,true);
    foreach(int length in new[]{2,4}){var f=World(tier,3,rotation,meal:true);var snake=Tail(f,length);Step(r,f);HoldHunt(f,new Vector2Int(0,-3));Plan(r,f);
     Check(r,f.p.Ai.directive?.type=="hunt"&&f.p.Next==f.D(Right)&&f.p.Ai.thought=="continue-meal-before-hunt","A held distant opponent hunt keeps an actual nearby meal, initial length="+length+": "+label,f.Detail);Advance(f);
     Check(r,!f.p.Dead&&f.p.Cell==f.C(2,0)&&(length==2?!f.w.Snakes.Contains(snake):snake.Body.Count==length-2),"Ongoing body/final-head continuation executes through genuine contact: "+label,f.Detail);
    }
    {var f=World(tier,3,rotation,meal:true);var snake=Tail(f);HoldHunt(f,new Vector2Int(0,-3));Step(r,f);
     Check(r,!f.p.Dead&&f.p.Cell==f.C(1,0)&&snake.Body.Count==3&&f.p.Ai.thought=="forward-bite-before-hunt","Distant hunt accepts an incidental safe forward tail without detouring: "+label,f.Detail);
    }
    {var f=World(tier,3,rotation,meal:true);var snake=Add(f,new[]{new Vector2Int(0,3),new Vector2Int(0,2),new Vector2Int(0,1)},Down);HoldHunt(f,new Vector2Int(0,-3));Step(r,f);
     Check(r,!f.p.Dead&&snake.Body.Count==3&&f.p.Cell!=f.C(0,1)&&f.p.Ai.thought!="forward-bite-before-hunt","Untouched side food does not create a detour away from a held opponent hunt: "+label,f.Detail);
    }
    {var f=World(tier,3,rotation,meal:true);var snake=Tail(f);Step(r,f);var human=HoldHunt(f,Down);Plan(r,f);
     Check(r,f.p.Next==f.D(Down)&&f.p.Ai.directive?.type=="hunt","An adjacent legal rival contact retains competitive priority over the meal: "+label,f.Detail);Advance(f);
     Check(r,human.Dead&&!f.p.Dead&&snake.Body.Count==3,"The adjacent rival is actually eaten while the snake is untouched: "+label,f.Detail);
    }
    {var f=World(tier,3,rotation,meal:true);var snake=Tail(f);Step(r,f);var human=HoldHunt(f,new Vector2Int(0,-1));human.Score=1000;human.ExactScore=1000;Plan(r,f);
     Check(r,f.p.Ai.directive?.type=="flee"&&f.p.Ai.thought!="continue-meal-before-hunt"&&f.p.Ai.thought!="forward-bite-before-hunt","A nearby stronger rival overrides local-food continuity with real flee: "+label,f.Detail);Advance(f);Check(r,!f.p.Dead,"Flee remains safe after actual movement: "+label,f.Detail);
    }
    {var f=World(tier,3,rotation,meal:true);var snake=Tail(f);Step(r,f);HoldHunt(f,new Vector2Int(0,-3));f.w.Hunters.Add(new NativeHunter{Id=500,Cell=f.C(2,-1),From=f.C(2,-1),Dir=f.D(Down),LastMove=f.w.Time});Plan(r,f);
     Check(r,f.p.Next!=f.D(Right)||f.p.Waiting,"Imminent hunter danger still vetoes a real meal during distant hunt: "+label,f.Detail);Advance(f);Check(r,!f.p.Dead&&snake.Body.Count==3,"Unsafe continuation neither eats nor kills the actor: "+label,f.Detail);
    }
   }
   for(int rotation=0;rotation<4;rotation++){
    var f=World(4,3,rotation,meal:true);var remote=Add(f,new[]{new Vector2Int(-8,-8)},Right);var snake=Add(f,new[]{new Vector2Int(3,2),new Vector2Int(2,2),new Vector2Int(1,2),new Vector2Int(1,1),new Vector2Int(1,0)},Right);f.w.Ally.Commit(f.p,remote,"hunt");HoldHunt(f,new Vector2Int(0,-3));Step(r,f);
    Check(r,f.p.Cell==f.C(1,0)&&snake.Body.Count==4&&f.p.Ai.locked==snake&&f.p.Ai.bitten,"BRUTAL incidental actual contact replaces a stale unbitten remote lock: rotation="+rotation,f.Detail);Plan(r,f);Advance(f);
    Check(r,!f.p.Dead&&f.p.Cell==f.C(1,1)&&snake.Body.Count==3,"BRUTAL keeps the newly bitten meal through its bend after stale-lock replacement: rotation="+rotation,f.Detail);
   }
  }
  public static NativeCasualBiteReport Run(){var watch=Stopwatch.StartNew();var report=new NativeCasualBiteReport{scope="Editor-only real Plan/AdvancePlayer contact regressions for PICNIC, EASY, MEDIUM and STRONG local opportunities, meal continuity, actual second-snake combo and meaningful direction changes. Includes all AI participant modes, rotations and both extremes of the random decision input, plus all-tier actual mouth-arrival timing and BRUTAL dense crossings/meal priority. Prediction remains enabled. No rendered performance or physical-device claim."};Group(report,"nearby contacts",()=>NearbyContacts(report));Group(report,"continuous meals and combo",()=>ContinuousMealsAndCombo(report));Group(report,"moving tail continuation",()=>MovingTailContinuation(report));Group(report,"boundaries and safety",()=>BoundariesAndSafety(report));Group(report,"mouth arrival timing",()=>MouthArrivalTiming(report));Group(report,"direction continuity",()=>DirectionContinuity(report));Group(report,"maximum practical choices",()=>MaximumPracticalChoices(report));Group(report,"local meal versus distant hunt",()=>LocalMealVersusHunt(report));Group(report,"maximum profile scope",()=>StrongProfileScope(report));report.elapsedMs=watch.Elapsed.TotalMilliseconds;report.passed=report.failures==0;return report;}
 }
}
#endif

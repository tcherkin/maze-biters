#if UNITY_EDITOR
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Globalization;
using System.Linq;
using System.Text;
using UnityEngine;

namespace MazeBiters.NativeStudy {
 [Serializable] public sealed class NativeSafeStartCase {
  public string name;
  public int mode, difficulty, level, seed, snakes, mass, reservedCells;
  public double spawnMs;
 }
 [Serializable] public sealed class NativeSafeStartReport {
  public bool passed;
  public int assertions, generatedCases, syntheticCases, previewCases, failures;
  public double elapsedMs, maxSpawnMs;
  public string scope="Native iPad current start placement, independent topology and population invariants, deterministic repeated layouts and actual next-level preview/activation parity. Editor CPU timing is diagnostic, not an iPad performance result.";
  public List<string> failureDetails=new List<string>();
  public List<NativeSafeStartCase> cases=new List<NativeSafeStartCase>();
 }
 public static class NativeSafeStartValidation {
  sealed class Tape {
   public uint state;public int draws;
   public Tape(uint seed){state=seed;}
   public double Next(){draws++;unchecked{state+=0x6D2B79F5;uint n=(state^(state>>15))*(1|state);n^=n+(n^(n>>7))*(61|n);return (n^(n>>14))/4294967296.0;}}
   public Tape Copy()=>new Tape(state){draws=draws};
  }
  static readonly Vector2Int[] Steps={new Vector2Int(1,0),new Vector2Int(-1,0),new Vector2Int(0,1),new Vector2Int(0,-1)};
  static void Check(NativeSafeStartReport r,bool ok,string name){r.assertions++;if(ok)return;r.failures++;if(r.failureDetails.Count<100)r.failureDetails.Add(name);}
  static string P(Vector2Int c)=>c.x+","+c.y;
  static string Fingerprint(NativeGameplayWorld w){
   var text=new StringBuilder().Append(w.Level).Append('|').Append(w.Mode).Append('|').Append(w.StartingSnakeMass);
   foreach(var s in w.Snakes){text.Append('|').Append(s.Id).Append(':').Append(s.Palette).Append(':').Append(P(s.Dir)).Append(':').Append(s.Temperament.ToString("R",CultureInfo.InvariantCulture)).Append(':').Append(s.TurnBias.ToString("R",CultureInfo.InvariantCulture));foreach(var c in s.Body)text.Append('/').Append(P(c));}
   return text.ToString();
  }
  static NativeGameplayWorld Make(SessionLevel level,int mode,int difficulty,Tape rng){
   var w=new NativeGameplayWorld(level.geometry,rng.Next){Level=level.level,AiDifficulty=difficulty,Difficulty=NativeMazeGenerator.Difficulties[difficulty],Time=1000,LevelStarted=1000};
   w.SetMode(mode);w.SetStarts(level);
   for(int i=0;i<w.PlayerCount;i++){var p=w.GetPlayer(i);var start=level.starts[i];p.Cell=p.From=p.Previous=new Vector2Int(start.x,start.y);p.Dir=p.Next=start.dir;}
   return w;
  }
  static int[] IntendedLengths(int level){
   int count=Math.Min(9,Math.Max(4,3+Math.Min(2,Math.Max(0,level-1))+Math.Max(0,level-3)/2));
   int average=Math.Max(7,16-count),spread=Math.Min(4,Math.Max(1,(level+1)/2));var lengths=new List<int>();
   if((count&1)!=0)lengths.Add(average);
   for(int pair=0;lengths.Count<count;pair++){int delta=1+pair%spread;lengths.Add(average-delta);lengths.Add(average+delta);}
   return lengths.OrderBy(x=>x).ToArray();
  }
  static List<Vector2Int> Neighbours(NativeGameplayWorld w,Vector2Int c)=>Steps.Select(d=>c+d).Where(w.Floor).ToList();
  // Independent dead-arm oracle: follow the sole path from a genuine endpoint
  // until the first choice. No production reservation/flow-field helper is used.
  static HashSet<Vector2Int> DeadArm(NativeGameplayWorld w,Vector2Int start){
   var route=new HashSet<Vector2Int>{start};var neighbours=Neighbours(w,start);
   if(neighbours.Count!=1)return route;
   var previous=start;var current=neighbours[0];
   while(route.Add(current)){
    var exits=Neighbours(w,current).Where(c=>c!=previous).ToList();if(exits.Count!=1)break;
    previous=current;current=exits[0];
   }
   return route;
  }
  static int[] Distances(NativeGameplayWorld w,Vector2Int start){
   var distances=Enumerable.Repeat(-1,w.Width*w.Height).ToArray();var queue=new Queue<Vector2Int>();distances[w.Index(start)]=0;queue.Enqueue(start);
   while(queue.Count>0){var at=queue.Dequeue();foreach(var next in Neighbours(w,at))if(distances[w.Index(next)]<0){distances[w.Index(next)]=distances[w.Index(at)]+1;queue.Enqueue(next);}}
   return distances;
  }
  // Peel terminal cells to find the graph's genuine looping region. A branch
  // may contain several degree-three forks and still offer no way around a
  // snake; its complete route back to the looping region must stay unblocked.
  static HashSet<Vector2Int> CycleCore(NativeGameplayWorld w){
   var cells=new HashSet<Vector2Int>();for(int y=0;y<w.Height;y++)for(int x=0;x<w.Width;x++){var c=new Vector2Int(x,y);if(w.Floor(c))cells.Add(c);}
   var degree=cells.ToDictionary(c=>c,c=>Neighbours(w,c).Count);var trim=new Queue<Vector2Int>(cells.Where(c=>degree[c]<2));
   while(trim.Count>0){var cell=trim.Dequeue();if(!cells.Remove(cell))continue;foreach(var next in Neighbours(w,cell))if(cells.Contains(next)&&--degree[next]==1)trim.Enqueue(next);}
   return cells;
  }
  static HashSet<Vector2Int> EscapeReservation(NativeGameplayWorld w){
   var result=new HashSet<Vector2Int>();var core=CycleCore(w);
   for(int pi=0;pi<w.PlayerCount;pi++){
    var p=w.GetPlayer(pi);if(p.Dead||p.Lives<=0)continue;var start=p.Cell;result.Add(start);foreach(var c in Neighbours(w,start))result.Add(c);
    if(!core.Contains(start)&&core.Count>0){
     var parent=new Dictionary<Vector2Int,Vector2Int>();var pending=new Queue<Vector2Int>();var seen=new HashSet<Vector2Int>{start};pending.Enqueue(start);Vector2Int? gate=null;
     while(pending.Count>0&&!gate.HasValue){var c=pending.Dequeue();foreach(var n in Neighbours(w,c))if(seen.Add(n)){parent[n]=c;if(core.Contains(n)){gate=n;break;}pending.Enqueue(n);}}
     if(gate.HasValue){var c=gate.Value;foreach(var n in Neighbours(w,c))result.Add(n);while(c!=start){result.Add(c);c=parent[c];}result.Add(start);}
    }else if(Neighbours(w,start).Count==2){
     foreach(var first in Neighbours(w,start)){var previous=start;var at=first;var walked=new HashSet<Vector2Int>{start};while(walked.Add(at)){result.Add(at);var next=Neighbours(w,at).Where(n=>n!=previous).ToList();if(next.Count!=1)break;previous=at;at=next[0];}}
    }
   }
   return result;
  }
  static bool ForcedApproach(NativeGameplayWorld w,Vector2Int head,Vector2Int direction,HashSet<Vector2Int> protectedCells){
   var previous=head;var at=head+direction;var seen=new HashSet<Vector2Int>{head};
   while(w.Floor(at)&&seen.Add(at)){
    if(protectedCells.Contains(at))return true;
    var next=Neighbours(w,at).Where(n=>n!=previous).ToList();if(next.Count!=1)return false;previous=at;at=next[0];
   }
   return false;
  }
  static void Inspect(NativeSafeStartReport r,NativeGameplayWorld w,string label,bool exactMass=true){
   var expected=IntendedLengths(w.Level);var actual=w.Snakes.Select(s=>s.Body.Count).OrderBy(x=>x).ToArray();
   Check(r,w.Snakes.Count==expected.Length,label+" snake count");
   if(exactMass)Check(r,actual.SequenceEqual(expected),label+" intended length distribution: "+string.Join(",",actual)+" != "+string.Join(",",expected));
   Check(r,w.StartingSnakeMass==w.Snakes.Sum(s=>s.Body.Count),label+" initial mass accounting");
   Check(r,w.Snakes.Select(s=>s.Id).Distinct().Count()==w.Snakes.Count,label+" unique snake identities");
   var occupied=new HashSet<Vector2Int>();
   foreach(var s in w.Snakes){
    Check(r,s.Body.Count>0,label+" nonempty snake");if(s.Body.Count==0)continue;
    Check(r,s.Cell==s.Head,label+" cached head matches body");
    Check(r,Math.Abs(s.Dir.x)+Math.Abs(s.Dir.y)==1,label+" cardinal head direction");
    if(s.Body.Count>1)Check(r,s.Dir==s.Head-s.Body[1],label+" head and neck share direction");
    for(int i=0;i<s.Body.Count;i++){
     var c=s.Body[i];Check(r,w.Floor(c),label+" snake stays on floor "+P(c));
     Check(r,occupied.Add(c),label+" no snake overlap at "+P(c));
     Check(r,w.PlayerAt(c)==null,label+" player spawn clear at "+P(c));
     if(i>0){var d=c-s.Body[i-1];Check(r,Math.Abs(d.x)+Math.Abs(d.y)==1,label+" connected body");}
    }
   }
   for(int pi=0;pi<w.PlayerCount;pi++){
    var p=w.GetPlayer(pi);if(p.Dead||p.Lives<=0)continue;
    foreach(var c in DeadArm(w,p.Cell))Check(r,!occupied.Contains(c),label+" dead-arm escape stays clear at "+P(c));
   }
   var reservation=EscapeReservation(w);foreach(var c in reservation)Check(r,!occupied.Contains(c),label+" complete initial escape route stays clear at "+P(c));
   var playerDistances=Enumerable.Range(0,w.PlayerCount).Select(w.GetPlayer).Where(p=>!p.Dead&&p.Lives>0).Select(p=>Distances(w,p.Cell)).ToArray();
   foreach(var s in w.Snakes){
    var next=s.Head+s.Dir;
    Check(r,w.Floor(next),label+" head points into floor");
    Check(r,!w.Snakes.Any(other=>other!=s&&other.Body.Contains(next))&&!s.Body.Take(s.Body.Count-1).Contains(next),label+" first step is clear");
    Check(r,!ForcedApproach(w,s.Head,s.Dir,reservation),label+" no forced approach into initial escape corridor");
    if(w.Floor(next))foreach(var distances in playerDistances){int before=distances[w.Index(s.Head)],after=distances[w.Index(next)];Check(r,before<0||before>14||after<0||after>=before,label+" nearby head initially faces away from living participant");}
   }
  }
  static void Record(NativeSafeStartReport r,NativeGameplayWorld w,string name,int seed,int difficulty,double ms){
   r.maxSpawnMs=Math.Max(r.maxSpawnMs,ms);r.cases.Add(new NativeSafeStartCase{name=name,mode=w.Mode,difficulty=difficulty,level=w.Level,seed=seed,snakes=w.Snakes.Count,mass=w.StartingSnakeMass,reservedCells=EscapeReservation(w).Count,spawnMs=ms});
  }
  static Vector2Int Rotate(Vector2Int p,int rotation){for(int i=0;i<rotation;i++)p=new Vector2Int(-p.y,p.x);return p;}
  static SessionLevel LongArm(int rotation,bool forks=false){
   var cells=new HashSet<Vector2Int>();for(int y=1;y<=25;y++)for(int x=38;x<=65;x++)cells.Add(new Vector2Int(x,y));
   for(int x=1;x<=38;x++)cells.Add(new Vector2Int(x,13));
   if(forks)for(int y=4;y<=22;y++)cells.Add(new Vector2Int(18,y));
   var turned=cells.Select(c=>Rotate(c,rotation)).ToArray();int minX=turned.Min(c=>c.x),minY=turned.Min(c=>c.y);var offset=new Vector2Int(1-minX,1-minY);
   int width=turned.Max(c=>c.x)-minX+3,height=turned.Max(c=>c.y)-minY+3;
   var rows=Enumerable.Range(0,height).Select(_=>Enumerable.Repeat('#',width).ToArray()).ToArray();
   foreach(var c in turned){var v=c+offset;rows[v.y][v.x]='.';}
   var starts=new List<SessionStart>();
   void Start(Vector2Int cell,Vector2Int direction){var p=Rotate(cell,rotation)+offset;starts.Add(new SessionStart{x=p.x,y=p.y,dir=Rotate(direction,rotation)});}
   Start(new Vector2Int(1,13),Vector2Int.right);if(forks){Start(new Vector2Int(18,4),Vector2Int.up);Start(new Vector2Int(18,22),Vector2Int.down);}
   return new SessionLevel{level=1,theme="green",geometry=rows.Select(row=>new string(row)).ToArray(),starts=starts.ToArray()};
  }
  static void OpeningStep(NativeSafeStartReport report,NativeGameplayWorld w,string label){
   var original=w.Snakes.Select(s=>(snake:s,head:s.Head,direction:s.Dir)).ToArray();
   foreach(var state in original){bool moved=w.SnakeStep(state.snake);Check(report,moved&&state.snake.Head==state.head+state.direction,label+" actual first snake step continues safely away");}
   for(int i=0;i<w.PlayerCount;i++)Check(report,!w.GetPlayer(i).Dead&&w.GetPlayer(i).Score==0,label+" opening move leaves participants unharmed");
  }
  static void FalseJunctions(NativeSafeStartReport report){
   // A large right-hand room connects two long sides of a loop. The upper
   // passage has two apparent junctions whose side arms terminate. They do not
   // provide a route around a snake. The real choice is at x=50 in the room.
   var cells=new HashSet<Vector2Int>();
   for(int x=1;x<=50;x++){cells.Add(new Vector2Int(x,10));cells.Add(new Vector2Int(x,30));}
   for(int y=10;y<=30;y++)cells.Add(new Vector2Int(1,y));
   for(int y=10;y<=30;y++)for(int x=50;x<=70;x++)cells.Add(new Vector2Int(x,y));
   for(int y=3;y<=10;y++)cells.Add(new Vector2Int(5,y));
   for(int y=6;y<=10;y++)cells.Add(new Vector2Int(20,y));
   for(int y=10;y<=14;y++)cells.Add(new Vector2Int(30,y));
   foreach(int rotation in Enumerable.Range(0,4))foreach(int mode in new[]{0,1})foreach(bool coreStart in new[]{false,true}){
    var rotated=cells.Select(c=>Rotate(c,rotation)).ToArray();int minX=rotated.Min(c=>c.x),minY=rotated.Min(c=>c.y);var offset=new Vector2Int(1-minX,1-minY);
    Vector2Int C(int x,int y)=>Rotate(new Vector2Int(x,y),rotation)+offset;
    int width=rotated.Max(c=>c.x)-minX+3,height=rotated.Max(c=>c.y)-minY+3;var rows=Enumerable.Range(0,height).Select(_=>Enumerable.Repeat('#',width).ToArray()).ToArray();
    foreach(var cell in rotated){var c=cell+offset;rows[c.y][c.x]='.';}
    var start=C(5,coreStart?10:3);var level=new SessionLevel{level=1,theme="green",geometry=rows.Select(row=>new string(row)).ToArray(),starts=new[]{new SessionStart{x=start.x,y=start.y,dir=Rotate(Vector2Int.up,rotation)}}};
    var w=Make(level,mode,4,new Tape((uint)(842+rotation)));var safety=new NativeSpawnSafety(w);string label="false side-spur junctions rotation="+rotation+" mode="+mode+" coreStart="+coreStart;
    var core=CycleCore(w);var knownHead=C(40,10);var distances=Distances(w,start);
    Check(report,distances[w.Index(knownHead)]>14,label+" known danger lies beyond the near-head range");
    foreach(int x in new[]{20,30}){
     var junction=C(x,10);Check(report,Neighbours(w,junction).Count==3&&Neighbours(w,junction).Count(core.Contains)==2,label+" three visual exits but only two genuine continuation cells at "+x);
    }
    Check(report,safety.FacingRisk(knownHead,Rotate(Vector2Int.left,rotation)),label+" approaching head cannot treat blind side spurs as escape choices");
    if(coreStart){
     Check(report,safety.Reserved(C(40,10))&&safety.Reserved(C(40,30)),label+" both forced loop passages remain reserved until the real choice");
    }else{
     Check(report,!safety.Reserved(knownHead),label+" head is outside the reserved spawn branch so forward tracing is tested");
     Check(report,!safety.FacingRisk(knownHead,Rotate(Vector2Int.right,rotation)),label+" safe reverse toward the genuine room junction remains available");
    }
    var timer=Stopwatch.StartNew();w.SpawnLevelSnakes();timer.Stop();Inspect(report,w,label);Record(report,w,label,842+rotation,4,timer.Elapsed.TotalMilliseconds);OpeningStep(report,w,label);report.syntheticCases++;
   }
  }
  static void PreviewParity(NativeSafeStartReport r,int mode,int difficulty,bool eliminated){
   var generator=new NativeMazeGenerator(913,NativeMazeGenerator.Difficulties[difficulty]);var first=generator.Generate(1);var next=generator.Generate(2);var tape=new Tape(229);
   var w=new NativeGameplayWorld(first.geometry,tape.Next){Difficulty=NativeMazeGenerator.Difficulties[difficulty],AiDifficulty=difficulty};w.SetMode(mode);w.StartSession(n=>n==1?first:next);
   if(eliminated&&w.PlayerCount>1){var p=w.GetPlayer(w.PlayerCount-1);p.Dead=p.Eliminated=p.HideDeath=true;p.Lives=0;}
   w.Snakes.Clear();w.CheckLevelComplete();var copied=tape.Copy();uint before=tape.state;int draws=tape.draws;
   double at=w.TransitionAt+NativeGameplayWorld.ClearDuration;var preview=w.PreviewNextLevel(next,copied.Next,at);
   string label="preview mode="+mode+" difficulty="+difficulty+" eliminated="+eliminated;
   Check(r,tape.state==before&&tape.draws==draws,label+" never changes authoritative RNG");
   Check(r,w.Level==1&&w.Snakes.Count==0,label+" never mutates active population");
   // The detached preview ends after population/AI preparation. Activation
   // additionally schedules the next scorpion using exactly one random draw.
   // Predict that draw and the full deadline independently: fresh level age and
   // full initial snake mass make time/depletion pressure exactly one.
   var activatedRandom=copied.Copy();double scorpionRoll=activatedRandom.Next();
   double scorpionRate=1+Math.Min(9,Math.Max(0,next.level-1))/9.0;
   double expectedScorpionAt=at+Math.Max(5000,(15000+scorpionRoll*15000)/scorpionRate/(.5+.25*difficulty));
   w.Time=at;w.AdvanceLevel();
   Check(r,Fingerprint(preview)==Fingerprint(w),label+" prepared and activated snake layouts match");
   Check(r,activatedRandom.state==tape.state&&activatedRandom.draws==tape.draws&&tape.draws==copied.draws+1,label+" activation adds only the one scheduled-scorpion RNG draw");
   Check(r,Math.Abs(w.ScorpionSpawnAt-expectedScorpionAt)<1e-8,label+" scorpion deadline uses the exact predicted post-preview draw");
   Inspect(r,w,label);r.previewCases++;
  }
  public static NativeSafeStartReport Run(){
   var report=new NativeSafeStartReport();var total=Stopwatch.StartNew();
   foreach(uint seed in new uint[]{1,2,17,34,913,7719,45678,0x00C0FFEE})foreach(int difficulty in Enumerable.Range(0,5)){
    var generator=new NativeMazeGenerator(seed,NativeMazeGenerator.Difficulties[difficulty]);
    foreach(int levelNumber in new[]{1,2,3,5,10,30,130}){
     var level=generator.Generate(levelNumber);string[] geometry=(string[])level.geometry.Clone();
     for(int mode=0;mode<=5;mode++){
      string label="seed="+seed+" difficulty="+difficulty+" level="+levelNumber+" mode="+mode;
      var a=new Tape(seed+9841);var w=Make(level,mode,difficulty,a);var timer=Stopwatch.StartNew();w.SpawnLevelSnakes();timer.Stop();Inspect(report,w,label);
      var b=new Tape(seed+9841);var repeat=Make(level,mode,difficulty,b);repeat.SpawnLevelSnakes();
      Check(report,Fingerprint(w)==Fingerprint(repeat)&&a.state==b.state&&a.draws==b.draws,label+" deterministic seed/population/RNG");
      Check(report,level.geometry.SequenceEqual(geometry),label+" geometry remains untouched");
      OpeningStep(report,repeat,label);
      Record(report,w,label,(int)seed,difficulty,timer.Elapsed.TotalMilliseconds);report.generatedCases++;
     }
    }
   }
   foreach(bool forks in new[]{false,true})foreach(int rotation in Enumerable.Range(0,4))foreach(int mode in forks?Enumerable.Range(0,6):new[]{0,1}){
    var level=LongArm(rotation,forks);var tape=new Tape((uint)(33+rotation));var w=Make(level,mode,4,tape);string label="long blind arm rotation="+rotation+" mode="+mode+" forks="+forks;
    Check(report,(forks?EscapeReservation(w):DeadArm(w,w.Player.Cell)).Count>30,label+" fixture exceeds old 14-cell window");
    var timer=Stopwatch.StartNew();w.SpawnLevelSnakes();timer.Stop();Inspect(report,w,label);Record(report,w,label,33+rotation,4,timer.Elapsed.TotalMilliseconds);report.syntheticCases++;
   }
   FalseJunctions(report);
   foreach(int mode in Enumerable.Range(0,6))foreach(int difficulty in new[]{0,4}){PreviewParity(report,mode,difficulty,false);if(mode>=2)PreviewParity(report,mode,difficulty,true);}
   total.Stop();report.elapsedMs=total.Elapsed.TotalMilliseconds;report.passed=report.failures==0;return report;
  }
 }
}
#endif

using System;using System.IO;using System.Collections.Generic;using UnityEngine;using UnityEngine.Rendering;
namespace MazeBiters.NativeStudy {
 // Exact blocker rules from neon-maze-reflection.js; GPU visibility shader
 // shares its original 40-column records. No raycasting against Unity colliders.
 public sealed class NativeLightField:IDisposable {
  const int Capacity=1024;readonly string[] grid;readonly Texture2D kernels;public Texture2D Receiver{get;private set;}readonly Batch floor,wall;readonly byte[,] receiverFlags;readonly byte[,,] corridorKinds;readonly CommandBuffer commands=new CommandBuffer();
  public RenderTexture Floor=>floor.target;public RenderTexture Walls=>wall.target;
  public long TextureBytes=>kernels.width*kernels.height*4+576*400*4+floor.RecordBytes+wall.RecordBytes;public long TargetBytes=>2L*576*400*4;
  public NativeLightField(string[] grid,bool creatures=false,bool hunters=false,bool pickups=false,string prefix="",Texture2D generatedReceiver=null){this.grid=grid;if(NativeRenderOptimization.Enabled){receiverFlags=new byte[grid[0].Length,grid.Length];corridorKinds=new byte[2,grid[0].Length,grid.Length];PrepareTopology();}kernels=Load("neon-fruit-kernels.png",true);Receiver=generatedReceiver??Load(prefix+"neon-receiver.png",true);floor=new Batch(kernels,false);wall=new Batch(kernels,true);}
  internal static Texture2D Load(string name,bool premultiply=false){if(NativeSmoothLoading.Enabled&&Array.IndexOf(Environment.GetCommandLineArgs(),"--smooth-original-light")<0){var ready=NativePreparedLight.Load(name,premultiply);if(ready)return ready;}var t=new Texture2D(2,2,TextureFormat.RGBA32,false,false){filterMode=FilterMode.Bilinear,wrapMode=TextureWrapMode.Clamp};if(!t.LoadImage(File.ReadAllBytes(Path.Combine(WebFiles.Root,"Reference",name))))throw new IOException(name);if(premultiply){var p=t.GetPixels32();for(int i=0;i<p.Length;i++){p[i].r=(byte)Math.Round(p[i].r*p[i].a/255.0);p[i].g=(byte)Math.Round(p[i].g*p[i].a/255.0);p[i].b=(byte)Math.Round(p[i].b*p[i].a/255.0);}t.SetPixels32(p);}t.Apply(false,true);return t;}
  bool Open(int x,int y)=>y>=0&&y<grid.Length&&x>=0&&x<grid[0].Length&&grid[y][x]!='#';bool Solid(int x,int y)=>y>=0&&y<grid.Length&&x>=0&&x<grid[0].Length&&!Open(x,y);
  void PrepareTopology(){for(int ty=0;ty<grid.Length;ty++)for(int tx=0;tx<grid[0].Length;tx++){
   bool tl=Open(tx-1,ty-1)&&Solid(tx-1,ty)&&Solid(tx,ty-1),tr=Open(tx+1,ty-1)&&Solid(tx+1,ty)&&Solid(tx,ty-1),bl=Open(tx-1,ty+1)&&Solid(tx-1,ty)&&Solid(tx,ty+1),br=Open(tx+1,ty+1)&&Solid(tx+1,ty)&&Solid(tx,ty+1);
   receiverFlags[tx,ty]=(byte)((Open(tx-1,ty)?1:0)|(Open(tx+1,ty)?2:0)|(Open(tx,ty-1)?4:0)|(Open(tx,ty+1)?8:0)|((Open(tx-1,ty)||tl||bl)?16:0)|((Open(tx+1,ty)||tr||br)?32:0)|((Open(tx,ty-1)||tl||tr)?64:0)|((Open(tx,ty+1)||bl||br)?128:0));
   for(int kind=0;kind<2;kind++){int range=kind==1?2:1;bool horizontal=true,vertical=true;for(int i=-range;i<=range;i++){horizontal&=Solid(tx+i,ty-1)&&Solid(tx+i,ty+1)&&(kind==1?Open(tx+i,ty):i==0||Open(tx+i,ty));vertical&=Solid(tx-1,ty+i)&&Solid(tx+1,ty+i)&&(kind==1?Open(tx,ty+i):i==0||Open(tx,ty+i));}corridorKinds[kind,tx,ty]=(byte)(horizontal?1:vertical?2:0);}
  }}
  static double Smooth(double x){x=Math.Max(0,Math.Min(1,x));return x*x*(3-2*x);}
  public void Begin(){floor.Begin();wall.Begin();}
  public void Point(double x,double y,int palette,double opacity=1){if(VisibilityPreparation.RejectLight(x,y))return;if(!Open((int)Math.Floor(x/16),(int)Math.Floor(y/16)))return;Stamp(floor,x,y,palette,opacity*.7);Stamp(wall,x,y,palette,opacity*.7*.4);}
  public void Snake(SnakePose p,int palette){
   // Removed creatures retain a shrinking emission image, but no longer
   // belong to the live world's wall/floor illumination source roster.
   if(p.consumed)return;
   const double scale=16.0/36,spacing=16.0*2/9;double length=(p.solo?SnakeMotion.Head:p.length-p.compression)*scale,bodyEnd=Math.Max(0,length-SnakeMotion.Head*scale);var rear=p.rigidRear??p.rail.Sample(p.Rear);
   void At(double d,double a){RailPoint r;if(d>bodyEnd||p.solo){double local=d-bodyEnd;r=new RailPoint{x=rear.x*scale+Math.Cos(rear.angle)*local,y=rear.y*scale+Math.Sin(rear.angle)*local};}else {var s=NativeRenderOptimization.Enabled?p.rail.SampleForRender(p.Tip+d/scale):p.rail.Sample(p.Tip+d/scale);r=new RailPoint{x=s.x*scale,y=s.y*scale};}Point(r.x,r.y,NativeSnakePalettes.LightSlot(palette),a);}
   if(length<spacing){At(length*.5,Math.Max(.25,length/spacing));return;}int count=(int)Math.Floor(length/spacing);double remainder=length-count*spacing;
   for(int i=0;i<=count;i++)At(i*spacing,i==0?.5:i==count?.5+remainder/spacing*.5:1);if(remainder>0)At(length,remainder/spacing*.5);
  }
  void Stamp(Batch b,double x,double y,int palette,double alpha){
   int tx=(int)Math.Floor(x/16),ty=(int)Math.Floor(y/16),simple=0,range=b.walls?2:1;
   if(NativeRenderOptimization.Enabled)simple=corridorKinds[b.walls?1:0,tx,ty];else{bool horizontal=true,vertical=true;for(int i=-range;i<=range;i++){horizontal&=Solid(tx+i,ty-1)&&Solid(tx+i,ty+1)&&(b.walls?Open(tx+i,ty):i==0||Open(tx+i,ty));vertical&=Solid(tx-1,ty+i)&&Solid(tx+1,ty+i)&&(b.walls?Open(tx,ty+i):i==0||Open(tx,ty+i));}
   if(horizontal)simple=1;else if(vertical)simple=2;}
   float radius=b.walls?23.2f:10.88f,depth=b.walls?13.6f:1.6f;Vector4 clip=new Vector4(-1e6f,-1e6f,1e6f,1e6f);int count=0;var rectangles=b.rectangles;
   if(simple!=0)clip=simple==1?new Vector4(-radius,ty*16-depth,576+radius,ty*16+16+depth):new Vector4(tx*16-depth,-radius,tx*16+16+depth,400+radius);
   else for(int cy=Math.Max(0,(int)Math.Floor((y-radius)/16));cy<=Math.Min(24,(int)Math.Floor((y+radius)/16));cy++)for(int cx=Math.Max(0,(int)Math.Floor((x-radius)/16));cx<=Math.Min(35,(int)Math.Floor((x+radius)/16));cx++){
    if(!Solid(cx,cy))continue;double l=cx*16,r=l+16,t=cy*16,bt=t+16;
    if(NativeRenderOptimization.Enabled){byte f=receiverFlags[cx,cy];if(!b.walls){l+=(f&1)!=0?depth:0;r-=(f&2)!=0?depth:0;t+=(f&4)!=0?depth:0;bt-=(f&8)!=0?depth:0;}else{l+=(f&16)!=0?depth*Smooth((l-x)/(16*.22)):0;r-=(f&32)!=0?depth*Smooth((x-r)/(16*.22)):0;t+=(f&64)!=0?depth*Smooth((t-y)/(16*.22)):0;bt-=(f&128)!=0?depth*Smooth((y-bt)/(16*.22)):0;}}
    else if(!b.walls){l+=Open(cx-1,cy)?depth:0;r-=Open(cx+1,cy)?depth:0;t+=Open(cx,cy-1)?depth:0;bt-=Open(cx,cy+1)?depth:0;}
    else {bool tl=Open(cx-1,cy-1)&&Solid(cx-1,cy)&&Solid(cx,cy-1),tr=Open(cx+1,cy-1)&&Solid(cx+1,cy)&&Solid(cx,cy-1),bl=Open(cx-1,cy+1)&&Solid(cx-1,cy)&&Solid(cx,cy+1),br=Open(cx+1,cy+1)&&Solid(cx+1,cy)&&Solid(cx,cy+1);
     l+=(Open(cx-1,cy)||tl||bl)?depth*Smooth((l-x)/(16*.22)):0;r-=(Open(cx+1,cy)||tr||br)?depth*Smooth((x-r)/(16*.22)):0;t+=(Open(cx,cy-1)||tl||tr)?depth*Smooth((t-y)/(16*.22)):0;bt-=(Open(cx,cy+1)||bl||br)?depth*Smooth((y-bt)/(16*.22)):0;
    }
    if(r<x-radius||l>x+radius||bt<y-radius||t>y+radius)continue;if(count>=36)throw new Exception("Light blocker overflow");rectangles[count++]=new Vector4((float)l,(float)t,(float)r,(float)bt);
   }
   b.Add((float)x,(float)y,radius,(float)alpha,palette,clip,count);
  }
  public void Render(){commands.Clear();commands.SetViewProjectionMatrices(Matrix4x4.identity,Matrix4x4.Ortho(0,576,-400,0,-1,1));floor.Draw(commands);wall.Draw(commands);Graphics.ExecuteCommandBuffer(commands);}
  internal void ReplaceReceiver(Texture2D next){if(Receiver!=next){UnityEngine.Object.Destroy(Receiver);Receiver=next;}}
  public void Dispose()=>Dispose(false); public void Dispose(bool keepReceiver){floor.Dispose();wall.Dispose();commands.Dispose();UnityEngine.Object.Destroy(kernels);if(!keepReceiver)UnityEngine.Object.Destroy(Receiver);}
  sealed class Batch:IDisposable {
   public readonly bool walls;public readonly RenderTexture target;Texture2D data;int recordCapacity;readonly Color[] records=new Color[40*Capacity];readonly Material paint;readonly Mesh mesh=new Mesh();readonly List<Vector3> v=new List<Vector3>(Capacity*4);readonly List<Vector2> uv=new List<Vector2>(Capacity*4);readonly List<int> ids=new List<int>(Capacity*6);public readonly Vector4[] rectangles=new Vector4[36];int count;float atlasWidth;
   public long RecordBytes=>(long)recordCapacity*40*16;
   public Batch(Texture2D atlas,bool walls){this.walls=walls;atlasWidth=atlas.width;target=new RenderTexture(576,400,0,RenderTextureFormat.ARGB32){filterMode=FilterMode.Bilinear,wrapMode=TextureWrapMode.Clamp};target.Create();paint=new Material(Shader.Find("MazeBiters/NeonField"));EnsureRecords(64);paint.SetTexture("_Atlas",atlas);mesh.MarkDynamic();}
   public void Begin(){count=0;v.Clear();uv.Clear();ids.Clear();}
   void Record(int n,Vector4 value){records[count*40+n]=new Color(value.x,value.y,value.z,value.w);}
   public void Add(float x,float y,float radius,float alpha,int palette,Vector4 clip,int number){if(count>=Capacity)throw new Exception("Study light capacity exceeded");Record(0,new Vector4(x,y,radius,alpha));float size=walls?47:22;Record(1,new Vector4(palette*64/atlasWidth,walls?.5f:0,size/atlasWidth,size/128));Record(2,clip);Record(3,new Vector4(number,0,0,0));for(int i=0;i<number;i++)Record(i+4,rectangles[i]);int k=v.Count;v.Add(new Vector3(x-radius,-y+radius));v.Add(new Vector3(x+radius,-y+radius));v.Add(new Vector3(x+radius,-y-radius));v.Add(new Vector3(x-radius,-y-radius));for(int i=0;i<4;i++)uv.Add(new Vector2(count,0));ids.Add(k);ids.Add(k+1);ids.Add(k+2);ids.Add(k);ids.Add(k+2);ids.Add(k+3);count++;}
   // WebGL2 has no structured buffers. RGBAFloat stores the exact same float4
   // layout; texelFetch in the shader preserves signed coordinates and precision.
   // Grow by powers of two rather than uploading the 1024-row maximum every frame.
   void EnsureRecords(int needed){if(needed<=recordCapacity)return;recordCapacity=Mathf.NextPowerOfTwo(Math.Max(64,needed));if(data)UnityEngine.Object.Destroy(data);data=new Texture2D(40,recordCapacity,TextureFormat.RGBAFloat,false,true){filterMode=FilterMode.Point,wrapMode=TextureWrapMode.Clamp};paint.SetTexture("_Data",data);}
   public void Draw(CommandBuffer c){c.SetRenderTarget(target);c.ClearRenderTarget(false,true,Color.clear);if(count==0)return;EnsureRecords(count);data.SetPixelData(records,0,0);data.Apply(false,false);mesh.Clear();mesh.SetVertices(v);mesh.SetUVs(0,uv);mesh.SetTriangles(ids,0);c.DrawMesh(mesh,Matrix4x4.identity,paint);}
   public void Dispose(){target.Release();foreach(var o in new UnityEngine.Object[]{target,data,paint,mesh})UnityEngine.Object.Destroy(o);}
  }
 }
}


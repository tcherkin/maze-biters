using UnityEngine;
using Screen = UnityEngine.Device.Screen;
namespace MazeBiters.NativeStudy {
 public static class IpadPointer {
  public static Vector3 Position=>Input.touchCount>0?(Vector3)Input.GetTouch(0).position:Input.mousePosition;
  public static bool Pressed=>Input.touchCount>0?Input.GetTouch(0).phase==TouchPhase.Began:Input.GetMouseButtonDown(0);
 }
 public static class IpadTouchSettings {
  // Kept for the future touch-options screen; no game/menu choice is changed.
  public static IpadTouchStyle Style=IpadTouchStyle.LegacySwipe;
 }
 public sealed partial class NativeGameplayStudy {
  IpadOrbitInput ipadOrbit;
  IpadOrbitRenderer ipadOrbitRenderer;
  NativeGameplayWorld ipadInputWorld;
  readonly int[] ipadPadIds=new int[2],ipadPadMasks=new int[2];
  readonly Vector2[] ipadPadSticks=new Vector2[2];
  readonly string[] ipadKeyboardNames=new string[keys.Length];
  float ipadLastTouch=-1000;
  IpadSwipeInput ipadSwipe;
  bool OrbitControls=>IpadPresentation.Enabled&&IpadTouchSettings.Style==IpadTouchStyle.Orbit;
  bool IpadControlsAvailable=>Application.isFocused&&!paused&&!menuPreparing&&!HideForMenu&&world!=null&&!world.GameOver&&!world.Transition;
  void PrepareIpadOrbit(){if(!OrbitControls)return;if(ipadOrbit==null){ipadOrbit=new IpadOrbitInput();for(int i=0;i<keys.Length;i++)ipadKeyboardNames[i]=keys[i].ToString();}if(ipadOrbitRenderer==null)ipadOrbitRenderer=new IpadOrbitRenderer();}
  void IpadControlsStep(){
   PrepareIpadOrbit();
   if(!ReferenceEquals(ipadInputWorld,world)){ipadInputWorld=world;for(int slot=0;slot<2;slot++){ipadPadIds[slot]=ipadPadMasks[slot]=0;ipadPadSticks[slot]=Vector2.zero;}}
   bool active=IpadControlsAvailable;ipadOrbit.BeginFrame(world,Screen.width,Screen.height,active);
   var first=NativeGamepadInput.ReadSlot(0);var second=NativeGamepadInput.ReadSlot(1);
   ObserveIpadGamepad(0,first);ObserveIpadGamepad(1,second);
   for(int i=0;i<keys.Length;i++)if(Input.GetKeyDown(keys[i]))ipadOrbit.ClaimExternal(KeyboardPlayerSlot(i),IpadOrbitSource.Keyboard);
   for(int i=0;i<Input.touchCount;i++){var touch=Input.GetTouch(i);ipadLastTouch=Time.unscaledTime;ipadOrbit.Touch(touch.fingerId,touch.position,touch.phase);}
   ipadOrbit.EndFrame(0);
   NativeGamepadInput.Sync(world,0,first,ipadOrbit.DeviceActive(0,IpadOrbitSource.Gamepad));
   NativeGamepadInput.Sync(world,1,second,ipadOrbit.DeviceActive(1,IpadOrbitSource.Gamepad));
   for(int i=0;i<keys.Length;i++){
    int slot=KeyboardPlayerSlot(i);var player=slot<world.PlayerCount?world.GetPlayer(slot):null;if(player==null||player.IsAI)continue;
    using(world.ForPlayer(player)){
     string key=ipadKeyboardNames[i];bool held=ipadOrbit.DeviceActive(slot,IpadOrbitSource.Keyboard)&&Input.GetKey(keys[i]);
     if(held){if(!player.Keys.ContainsKey(key))world.Press(key,NativeGameplayWorld.Dirs[i/3]);}else world.Release(key);
    }
   }
   // A touch may only drive its captured Orbit slot, never click-to-route too.
   if(active&&Input.touchCount==0&&Time.unscaledTime-ipadLastTouch>.35f&&Input.GetMouseButtonDown(0)&&GameplayPointer(Input.mousePosition,out var cell)){
    if(world.Multiplayer){var r=Viewport();var point=DisplayFrame.Logical(Input.mousePosition,r,Screen.height);DisplayFrame.WorldPoint(point,cameraViewX,cameraViewY,cameraViewZoom,out double x,out double y);var player=world.PointerPlayer(cell,x,y);for(int slot=0;slot<2&&slot<world.PlayerCount;slot++)if(world.GetPlayer(slot)==player)ipadOrbit.ClaimExternal(slot,IpadOrbitSource.Pointer);world.NavigateCoop(cell,x,y);}
    else{ipadOrbit.ClaimExternal(0,IpadOrbitSource.Pointer);world.Navigate(cell);}
   }
  }
  void ObserveIpadGamepad(int slot,NativePadState pad){
   int mask=pad.Directions;
   bool changed=pad.Id!=ipadPadIds[slot]||mask!=ipadPadMasks[slot]||(pad.Stick-ipadPadSticks[slot]).sqrMagnitude>=.18f*.18f;
   if(mask!=0&&changed)ipadOrbit.ClaimExternal(slot,IpadOrbitSource.Gamepad);
   if(changed||mask==0)ipadPadSticks[slot]=pad.Stick;
   ipadPadIds[slot]=pad.Id;ipadPadMasks[slot]=mask;
  }
  void LateUpdate(){
   ipadSwipe?.BeginFrame(world,Screen.width,Screen.height,IpadPresentation.Enabled&&IpadTouchSettings.Style==IpadTouchStyle.LegacySwipe&&IpadControlsAvailable);
   if(ipadOrbit==null)return;
   ipadOrbit.BeginFrame(world,Screen.width,Screen.height,OrbitControls&&IpadControlsAvailable);
   ipadOrbit.AdvanceVisual(Time.unscaledDeltaTime);
  }
  void DrawIpadOrbit(){if(OrbitControls&&ipadOrbit!=null)ipadOrbitRenderer?.Draw(ipadOrbit,Screen.width,Screen.height);}
  void OnDisable(){ClearIpadTouchImmediately();}
  void ClearIpadTouchImmediately(){ReleaseIpadTouch();ipadOrbit?.ClearImmediately();}
  void DisposeIpadOrbit(){ReleaseIpadTouch();ipadOrbitRenderer?.Dispose();ipadOrbitRenderer=null;ipadOrbit=null;ipadSwipe=null;}

  // Each human owns an independent trailing origin and eight-direction gesture.
  void IpadTouchStep(){
   if(!IpadPresentation.Enabled||IpadTouchSettings.Style!=IpadTouchStyle.LegacySwipe){ipadSwipe?.CancelAll();return;}
   if(ipadSwipe==null)ipadSwipe=new IpadSwipeInput();
   ipadSwipe.BeginFrame(world,Screen.width,Screen.height,IpadControlsAvailable);
   for(int i=0;i<Input.touchCount;i++){var touch=Input.GetTouch(i);
    ipadSwipe.Touch(touch.fingerId,touch.position,touch.phase);
   }
   ipadSwipe.EndFrame();
  }
  void ReleaseIpadTouch(){ipadOrbit?.CancelAll();ipadSwipe?.CancelAll();}
 }
}

using UnityEngine;
using Screen = UnityEngine.Device.Screen;
namespace MazeBiters.NativeStudy {
 public static class IpadPointer {
  public static Vector3 Position=>Input.touchCount>0?(Vector3)Input.GetTouch(0).position:Input.mousePosition;
  public static bool Pressed=>Input.touchCount>0?Input.GetTouch(0).phase==TouchPhase.Began:Input.GetMouseButtonDown(0);
 }
 public sealed partial class NativeGameplayStudy {
  int ipadFinger=-1;Vector2 ipadOrigin;Vector2Int ipadDirection;
  void IpadTouchStep(){
   if(!IpadPresentation.Enabled)return;
   if(paused||!Application.isFocused||Input.touchCount==0){ReleaseIpadTouch();return;}
   for(int i=0;i<Input.touchCount;i++){var touch=Input.GetTouch(i);
    if(ipadFinger<0&&touch.phase==TouchPhase.Began){ipadFinger=touch.fingerId;ipadOrigin=touch.position;ipadDirection=Vector2Int.zero;}
    if(touch.fingerId!=ipadFinger)continue;
    if(touch.phase==TouchPhase.Ended||touch.phase==TouchPhase.Canceled){ReleaseIpadTouch();continue;}
    var d=touch.position-ipadOrigin;float threshold=Mathf.Max(10,Screen.height*.012f);if(d.magnitude<threshold)continue;
    var direction=Mathf.Abs(d.x)>Mathf.Abs(d.y)?new Vector2Int(d.x>0?1:-1,0):new Vector2Int(0,d.y>0?-1:1);
    if(direction!=ipadDirection){using(world.ForPlayer(world.GetPlayer(0))){world.Release("ipad-drag");world.Press("ipad-drag",direction);}ipadDirection=direction;}
    if(d.magnitude>threshold*3)ipadOrigin=touch.position-d.normalized*threshold*3;
   }
  }
  void ReleaseIpadTouch(){if(ipadFinger<0)return;if(world!=null)using(world.ForPlayer(world.GetPlayer(0)))world.Release("ipad-drag");ipadFinger=-1;ipadDirection=Vector2Int.zero;}
 }
}

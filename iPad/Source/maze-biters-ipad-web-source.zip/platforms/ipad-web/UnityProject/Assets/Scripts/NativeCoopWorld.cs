using System;using System.Linq;using UnityEngine;
namespace MazeBiters.NativeStudy {
 public sealed partial class NativeGameplayWorld {
  NativePlayer primary=new NativePlayer{Id=1},secondary,tertiary;int actingSlot;
  public int Mode{get;private set;}=1;
  public bool Cooperative=>Mode==5;
  public bool HasAI=>Mode==0||Mode==3||Mode==4;
  public bool Competitive=>Mode==2||Mode==3||Mode==4;
  public bool Multiplayer=>Mode==5||Competitive;
  public int PlayerCount=>Mode==4?3:Multiplayer?2:1;
  public NativePlayer Player {get=>GetPlayer(actingSlot);set{if(actingSlot==2)tertiary=value;else if(actingSlot==1)secondary=value;else primary=value;}}
  public NativePlayer GetPlayer(int index)=>index==0?primary:index==1?secondary:tertiary;
  public NativePlayer PlayerById(int id)=>id>=1&&id<=PlayerCount?GetPlayer(id-1):null;
  public void SetMode(int mode){if(mode<0||mode>5)throw new ArgumentOutOfRangeException(nameof(mode));Mode=mode;primary.IsAI=mode==0;primary.Palette=mode==0?2:0;primary.Waiting=!primary.IsAI;if(Multiplayer&&secondary==null)secondary=new NativePlayer{Id=2,Palette=1};if(secondary!=null){secondary.IsAI=mode==3;secondary.Palette=mode==3?2:1;}if(mode==4&&tertiary==null)tertiary=new NativePlayer{Id=3,Palette=2,IsAI=true};actingSlot=0;}
  // Explicit scoped actor context keeps the translated per-player rules shared.
  // No field swapping, allocations or temporary changes to player identities.
  public readonly struct PlayerScope:IDisposable {
   readonly NativeGameplayWorld world;readonly int previous;
   internal PlayerScope(NativeGameplayWorld w,int slot){world=w;previous=w.actingSlot;w.actingSlot=slot;}
   public void Dispose(){world.actingSlot=previous;}
  }
  public PlayerScope ForPlayer(NativePlayer p)=>new PlayerScope(this,p.Id-1);
  public NativePlayer TeammateAt(NativePlayer p,Vector2Int cell){for(int i=0;i<PlayerCount;i++){var other=GetPlayer(i);if(other!=p&&!other.Dead&&other.Lives>0&&other.Cell==cell)return other;}return null;}
  public bool PlayerCellOpen(NativePlayer p,Vector2Int cell)=>Floor(cell)&&!SolidEgg(cell)&&!PlayerContactBlocks(p,cell);
  public bool AllLivesLost {get{for(int i=0;i<PlayerCount;i++)if(GetPlayer(i).Lives>0)return false;return true;}}
  public int LeaderId {get{if(!Multiplayer)return 0;int highest=int.MinValue,leader=0;bool tied=false;for(int i=0;i<PlayerCount;i++){var p=GetPlayer(i);if(p.Score>highest){highest=p.Score;leader=p.Id;tied=false;}else if(p.Score==highest)tied=true;}return tied?0:leader;}}
  public double ScoreAlpha(NativePlayer p,double t)=>LeaderId!=p.Id||NativeHud.Active(p.ScoreSpotlight,620,t)?1:.6+.4*Math.Sin(t/310);
  SessionStart[] sessionStarts;
  internal void SetStarts(SessionLevel level){sessionStarts=level.starts;PlayerStart=new Vector2Int(level.starts[0].x,level.starts[0].y);StartDirection=level.starts[0].dir;}
  Vector2Int StartCell(NativePlayer p)=>sessionStarts!=null&&sessionStarts.Length>=p.Id?new Vector2Int(sessionStarts[p.Id-1].x,sessionStarts[p.Id-1].y):PlayerStart;
  Vector2Int StartDir(NativePlayer p)=>sessionStarts!=null&&sessionStarts.Length>=p.Id?sessionStarts[p.Id-1].dir:StartDirection;
  public void ClearAllKeys(){for(int i=0;i<PlayerCount;i++)using(ForPlayer(GetPlayer(i)))ClearKeys();}
  public void UpdateAllTilts(double t){for(int i=0;i<PlayerCount;i++)using(ForPlayer(GetPlayer(i)))UpdateTilt(t);}
  public bool MeasureAlly;public double LastAllyMs,AllyCpuMs;public int AllyDecisions;
  void TickPlayers(double t){LastAllyMs=0;for(int i=0;i<PlayerCount;i++)using(ForPlayer(GetPlayer(i))){UpdatePower();if(!Player.Dead&&Player.Lives>0&&t-Player.LastMove>PlayerDelay){if(Player.IsAI){long begin=MeasureAlly?System.Diagnostics.Stopwatch.GetTimestamp():0;Ally.Plan(Player,t);if(MeasureAlly){LastAllyMs+=(System.Diagnostics.Stopwatch.GetTimestamp()-begin)*1000.0/System.Diagnostics.Stopwatch.Frequency;AllyCpuMs=AllyCpuMs+LastAllyMs;AllyDecisions++;}}AdvancePlayer();Player.LastMove=t;}if(Transition)break;}}
  void TouchHead(NativeGameplaySnake s,bool retreat=false){var p=PlayerAt(s.Head);if(p==null)return;using(ForPlayer(p)){if(CombatPower)PowerEatHead(s);else if(!retreat)LoseLife();}}
  void Provoke(NativeCreature creature,double amount,bool record=true){if(!Multiplayer)return;creature.PersonalThreat[Player.Id-1]+=amount;if(record)Player.Contribution+=amount;}
  public NativePlayer PointerPlayer(Vector2Int target,double x,double y){
   var field=Brain.Field(target);NativePlayer best=null;int nearest=int.MaxValue;double visual=double.PositiveInfinity;
   for(int i=0;i<PlayerCount;i++){var p=GetPlayer(i);if(p.Dead||p.Eliminated||p.IsAI)continue;int distance=field[Index(p.Cell)];if(distance<0)distance=int.MaxValue;var v=p.Visual(Time);double d=Math.Pow(x-(v.x+.5)*16,2)+Math.Pow(y-(v.y+.5)*16,2);if(best==null||distance<nearest||distance==nearest&&d<visual){best=p;nearest=distance;visual=d;}}
   return best;
  }
  public void NavigateCoop(Vector2Int target,double x,double y){
   var p=PointerPlayer(target,x,y);if(p==null||!Floor(target))return;using(ForPlayer(p)){ClearKeys();p.PointerMomentum=true;p.Pointer=p.Cell==target?null:(Vector2Int?)target;var step=p.Pointer.HasValue?Brain.RouteStep(p,target):null;p.Next=step??p.Dir;if(!step.HasValue)p.Pointer=null;p.Waiting=false;}
  }
  double gameOverUntil;
 }
}

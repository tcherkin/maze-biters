using System;
using UnityEngine;
namespace MazeBiters.NativeStudy {
 public sealed partial class NativeGameplayStudy {
  string lastNextSceneFailure,lastAdoptionFailure;
  [Serializable] sealed class WebPreparationSnapshot {
   public uint seed,random,previewRandom;
   public int installedLayoutAttempt,preparedLayoutAttempt,mazeNumber,stage,index,passes,primed,retries,hits,fallbacks;
   public bool mazeQueued,mazePending,mazePublishing,mazeReady,mazeFailed,sceneReady,sceneFailed,gpuPending,gateWaiting;
   public string failure,adoptionFailure;
  }
  string WebPreparationState(){
   if(!Application.absoluteURL.Contains("diagnostic=1"))return "null";
   return JsonUtility.ToJson(new WebPreparationSnapshot{installedLayoutAttempt=currentGeneratedLevel?.openingLayoutAttempt??0,preparedLayoutAttempt=nextMaze?.level.openingLayoutAttempt??0,seed=mazeSeed,random=random,previewRandom=nextScene?.randomAtStart??0,mazeNumber=nextMazeNumber,
    stage=nextScene?.stage??-99,index=nextScene?.index??0,passes=nextScene?.passes??0,primed=nextScene?.primedSnakes??0,retries=levelGateRetries,hits=nextSceneHits,fallbacks=nextSceneFallbacks,
    mazeQueued=nextMazeQueued,mazePending=nextMazeTask!=null,mazePublishing=publishingMaze!=null,mazeReady=nextMaze!=null,mazeFailed=nextMazeFailed,sceneReady=nextScene?.ready==true,sceneFailed=nextSceneFailed,gpuPending=nextScene?.gpuPending==true,gateWaiting=levelGateWaiting,
    failure=lastNextSceneFailure,adoptionFailure=lastAdoptionFailure});
  }
 }
}

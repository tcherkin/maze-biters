using System;
using System.Collections.Generic;
using System.Linq;
using UnityEngine;
namespace MazeBiters.NativeStudy {
 // Loading-only translation of the frozen generateMazeForLevel. Keep JS double
 // arithmetic, rounding, stable sort and RNG draw order. The deterministic iPad
 // start-access pass runs afterwards; legacyStartCorridors retains the oracle.
 [Serializable] public sealed class MazePatterns {
  public int level,diagonalCorridors,wideDiagonalCorridors,cornerDiagonalStructures,cornerCoverageMask,diagonalPointRuns,orthogonalPointRuns,lateralPointRuns,diagonalIsolatedWalls,preservedPointCells,fullyOrbitablePointCells;
 }
 [Serializable] public sealed class MazeMetrics {public double rating,patternDifficulty;public int floorCells,junctions,deadEnds,openTwoByTwo;}
 public sealed partial class NativeMazeGenerator {
  const int W=36,H=25;static readonly Vector2Int[] D={new Vector2Int(1,0),new Vector2Int(-1,0),new Vector2Int(0,1),new Vector2Int(0,-1)};
  public static readonly string[] DifficultyNames={"PICNIC","EASY","MEDIUM","HARD","BRUTAL"};public static readonly double[] Difficulties={.5,.75,1,1.25,1.5};
  public static readonly string[] Themes={"green","orange","blue-violet","ruby-red","turquoise","gold","amethyst","rose-quartz","moonstone"};public static readonly int[] Hues={132,24,248,348,177,44,278,340,224};
  public static SessionStart[] Starts()=>new[]{new SessionStart{x=1,y=1,dir=new Vector2Int(0,1)},new SessionStart{x=W-2,y=H-2,dir=new Vector2Int(0,-1)},new SessionStart{x=1,y=H-2,dir=new Vector2Int(0,-1)}};
  public readonly uint Seed;public readonly double Difficulty;public readonly bool LegacyStartCorridors,LegacyPaletteOrder;public MazePatterns Patterns;public MazeMetrics Metrics;public double Target;
  char[][] g;int stage,styleOffset;string style;double adjusted,absurd,edge,ultra;Func<double> random;
  readonly HashSet<Vector2Int> diagonal=new HashSet<Vector2Int>(),points=new HashSet<Vector2Int>(),orthogonal=new HashSet<Vector2Int>(),reserved=new HashSet<Vector2Int>(),safe=new HashSet<Vector2Int>();
  public NativeMazeGenerator(uint seed,double difficulty=1,bool legacyStartCorridors=false,bool legacyPaletteOrder=false){Seed=seed;Difficulty=difficulty;LegacyStartCorridors=legacyStartCorridors;LegacyPaletteOrder=legacyPaletteOrder;if(!Difficulties.Contains(difficulty))throw new ArgumentOutOfRangeException(nameof(difficulty));}
  static int Round(double x)=>(int)Math.Floor(x+.5);static int Floor(double x)=>(int)Math.Floor(x);static double Clamp(double x)=>Math.Max(0,Math.Min(1,x));
  public static Func<double> Rng(uint seed){uint state=seed;return ()=>{unchecked{state+=0x6D2B79F5;uint v=(state^(state>>15))*(state|1);v^=v+(v^(v>>7))*(v|61);return (v^(v>>14))/4294967296.0;}};}
  uint LevelSeed(int n,int attempt=0){unchecked{return Seed^(uint)(n+1)*0x9E3779B1u^(uint)(attempt+1)*0x85EBCA6Bu;}}
  public static double Absurdity(double n){n=Math.Max(1,n);double p=Clamp((n-1)/29),baseValue=p*p*(3-2*p)*.98;if(n<=30)return baseValue;return Math.Min(3.25,.98+Math.Pow(Math.Min(1,(n-30)/70),.82)*1.62+(n>100?Math.Log(1+(n-100)/20)*.30:0));}
  static double Ultra(double n){double p=Clamp((Math.Max(1,n)-30)/70);return p*p*(3-2*p);}
  static double Edge(double n){n=Math.Max(1,n);return n<=20?0:Math.Min(2.2,1-Math.Exp(-(n-20)/22)+Math.Max(0,Absurdity(n)-.98)*.60);}
  static double HueDistance(int a,int b){double d=Math.Abs(a-b)%360;return Math.Min(d,360-d);}
  // Retained only for frozen six-colour browser/art oracle comparisons.
  int LegacyThemeIndex(int n){var history=new List<int>{Floor(Rng(LevelSeed(1,733))()*6)};for(int k=2;k<=Math.Max(1,n);k++){var recent=history.Skip(Math.Max(0,history.Count-2)).ToArray();var unused=Enumerable.Range(0,6).Where(i=>!recent.Contains(i)).ToArray();var candidates=unused.Where(i=>recent.All(p=>HueDistance(Hues[i],Hues[p])>=55)).ToArray();if(candidates.Length==0)candidates=unused.OrderByDescending(i=>recent.Min(p=>HueDistance(Hues[i],Hues[p]))).Take(Math.Max(1,(int)Math.Ceiling(unused.Length/2.0))).ToArray();history.Add(candidates[Floor(Rng(LevelSeed(k,733))()*candidates.Length)]);}return history[history.Count-1];}
  int Integer(int lo,int hi)=>lo+Floor(random()*(hi-lo+1));int Half(int n)=>n/2+((n&1)!=0&&random()<.5?1:0);
  bool Inside(int x,int y)=>x>0&&y>0&&x<W-1&&y<H-1;bool Inside(Vector2Int p)=>Inside(p.x,p.y);
  char At(int x,int y)=>x>=0&&y>=0&&x<W&&y<H?g[y][x]:'\0';char At(Vector2Int p)=>At(p.x,p.y);
  static Vector2Int P(int x,int y)=>new Vector2Int(x,y);static Vector2Int Mirror(int x,int y)=>P(W-1-x,H-1-y);
  void Open(int x,int y){var p=P(x,y);if(Inside(p)&&!diagonal.Contains(p)&&!points.Contains(p))g[y][x]='.';}void Open(Vector2Int p)=>Open(p.x,p.y);
  void Wall(int x,int y){if(Inside(x,y))g[y][x]='#';}void Wall(Vector2Int p)=>Wall(p.x,p.y);
  void OpenPair(int x,int y){Open(x,y);Open(Mirror(x,y));}void WallPair(int x,int y){Wall(x,y);Wall(Mirror(x,y));}
  List<Vector2Int> Copies(int x,int y){var list=new List<Vector2Int>{P(x,y)};switch(style){case "rotational":list.Add(Mirror(x,y));break;case "left-right":list.Add(P(W-1-x,y));break;case "top-bottom":list.Add(P(x,H-1-y));break;case "four-way":list.Add(P(W-1-x,y));list.Add(P(x,H-1-y));list.Add(Mirror(x,y));break;}return list.Where(Inside).Distinct().ToList();}
  void OpenFeature(int x,int y){foreach(var p in Copies(x,y))Open(p);}void WallFeature(int x,int y){foreach(var p in Copies(x,y))Wall(p);}
  bool Claim(int x,int y,int width,int height,bool raw=false){var expanded=new List<Vector2Int>();for(int dy=-1;dy<height+1;dy++)for(int dx=-1;dx<width+1;dx++){if(raw){if(Inside(x+dx,y+dy))expanded.Add(P(x+dx,y+dy));}else expanded.AddRange(Copies(x+dx,y+dy));}if(expanded.Any(reserved.Contains))return false;foreach(var p in expanded)reserved.Add(p);return true;}
  int ZoneY(int height)=>Integer(4,Math.Max(4,(style=="top-bottom"||style=="four-way"?H/2-height-1:H-5-height)));
  void Shuffle<T>(IList<T> a){for(int i=a.Count-1;i>0;i--){int j=Floor(random()*(i+1));var v=a[i];a[i]=a[j];a[j]=v;}}
  char[][] Snapshot()=>g.Select(r=>(char[])r.Clone()).ToArray();
  bool Mutation(Action change){var snapshot=Snapshot();change();if(Connected())return true;g=snapshot;return false;}
  bool Near(Vector2Int p,int margin=4)=>(Math.Abs(1-p.x)<=margin&&(Math.Abs(1-p.y)<=margin||Math.Abs(H-2-p.y)<=margin))||(Math.Abs(W-2-p.x)<=margin&&Math.Abs(H-2-p.y)<=margin);
  static List<Vector2Int> Ring(Vector2Int p){var list=new List<Vector2Int>();for(int dy=-1;dy<=1;dy++)for(int dx=-1;dx<=1;dx++)list.Add(p+P(dx,dy));return list;}
  bool ClearPoints(List<Vector2Int> cells)=>cells.All(p=>Ring(p).All(q=>Inside(q)&&!diagonal.Contains(q)&&!points.Contains(q)));
  void CarvePoints(List<Vector2Int> cells){foreach(var p in cells)foreach(var q in Ring(p))if(q!=p)Open(q);foreach(var p in cells)Wall(p);}
  bool Connected(){if(g[1][1]!='.')return false;var seen=new bool[W*H];var queue=new List<Vector2Int>{P(1,1)};seen[W+1]=true;int total=g.Sum(r=>r.Count(c=>c=='.'));for(int read=0;read<queue.Count;read++)foreach(var d in D){var p=queue[read]+d;if(At(p)!='.'||seen[p.y*W+p.x])continue;seen[p.y*W+p.x]=true;queue.Add(p);}return queue.Count==total&&total>=W*H*.32;}
  public SessionLevel Generate(int n){stage=Math.Max(1,n);adjusted=1+(stage-1)*Difficulty;absurd=Absurdity(adjusted);edge=Edge(adjusted);ultra=Ultra(adjusted);Patterns=new MazePatterns{level=stage};diagonal.Clear();points.Clear();orthogonal.Clear();reserved.Clear();safe.Clear();random=Rng(LevelSeed(stage,91));
   string[] styles={"rotational","left-right","top-bottom","four-way","asymmetric"};styleOffset=Floor(random()*styles.Length);style=absurd>0&&random()<Math.Min(.97,absurd*.88)?"asymmetric":styles[styleOffset];g=Enumerable.Range(0,H).Select(_=>Enumerable.Repeat('#',W).ToArray()).ToArray();
   BaseMaze();EarlyFeatures();LateFeatures();Finish();if(!Connected())g=Enumerable.Range(0,H).Select(y=>Enumerable.Range(0,W).Select(x=>x==0||y==0||x==W-1||y==H-1?'#':'.').ToArray()).ToArray();StartAccessOpenedWalls=0;if(!LegacyStartCorridors)EnsureStartAccess();var geometry=g.Select(r=>new string(r)).ToArray();
   Metrics=Rate(geometry,Patterns);Target=45+Math.Min(1,(adjusted-1)/9)*75+Clamp((adjusted-10)/20)*50+Clamp((adjusted-30)/70)*120;
   return new SessionLevel{level=stage,geometry=geometry,theme=Themes[ThemeIndex(stage)],starts=Starts()};
  }
  void BaseMaze(){int columns=(W-4)/4,rows=(H-1)/2,left=1+(columns-1)*2,right=W-1-left;var visited=new bool[columns*rows];var stack=new List<Vector2Int>{P(0,0)};visited[0]=true;Open(1,1);
   while(stack.Count>0){var current=stack[stack.Count-1];var choices=new List<Vector2Int>();foreach(var d in D){var p=current+d;if(p.x<0||p.y<0||p.x>=columns||p.y>=rows)continue;if(!visited[p.y*columns+p.x])choices.Add(p);}if(choices.Count==0){stack.RemoveAt(stack.Count-1);continue;}var next=choices[Floor(random()*choices.Count)];var a=P(1+current.x*2,1+current.y*2);var b=P(1+next.x*2,1+next.y*2);Open((a.x+b.x)/2,(a.y+b.y)/2);Open(b);visited[next.y*columns+next.x]=true;stack.Add(next);}
   var snapshot=Snapshot();for(int y=1;y<H-1;y++)for(int x=1;x<=left;x++)if(snapshot[y][x]=='.')Open(Mirror(x,y));int bridgeY=5+Integer(0,2)*2;for(int x=left;x<=right;x++)OpenPair(x,bridgeY);OpenPair(right,bridgeY+1);
   int bridges=style=="rotational"?0:style=="four-way"?2:1;int[] bridgeRows={3,(H-1)/2,H-6};for(int i=0;i<bridges;i++){int y=bridgeRows[(i+styleOffset)%3];if(style=="asymmetric"){for(int x=left;x<=right;x++)Open(x,y);Open(right,y+1);}else{for(int x=left;x<=right;x++)OpenPair(x,y);OpenPair(right,y+1);}}
   snapshot=Snapshot();if(style=="left-right"){for(int y=1;y<H-1;y++)for(int x=1;x<W/2.0;x++)g[y][W-1-x]=snapshot[y][x];}else if(style=="top-bottom"){for(int y=1;y<H/2.0;y++)for(int x=1;x<W-1;x++)g[H-1-y][x]=snapshot[y][x];}else if(style=="four-way"){for(int y=1;y<H/2.0;y++)for(int x=1;x<W/2.0;x++){char v=snapshot[y][x];g[y][x]=g[y][W-1-x]=g[H-1-y][x]=g[H-1-y][W-1-x]=v;}}
   foreach(var p in new[]{P(1,1),P(2,1),P(3,1),P(1,2),P(1,3),P(W-2,H-2),P(W-3,H-2),P(W-4,H-2),P(W-2,H-3),P(W-2,H-4),P(1,H-2),P(2,H-2),P(3,H-2),P(1,H-3),P(1,H-4)}){Open(p);safe.Add(p);}
   for(int repair=0;repair<20&&!Connected();repair++){var seen=new HashSet<Vector2Int>{P(1,1)};var queue=new List<Vector2Int>{P(1,1)};for(int i=0;i<queue.Count;i++)foreach(var d in D){var p=queue[i]+d;if(Inside(p)&&At(p)=='.'&&seen.Add(p))queue.Add(p);}Vector2Int? orphan=null;for(int y=1;y<H-1&&!orphan.HasValue;y++)for(int x=1;x<W-1;x++)if(At(x,y)=='.'&&!seen.Contains(P(x,y))){orphan=P(x,y);break;}if(!orphan.HasValue)break;
    Vector2Int? nearest=null;int distance=int.MaxValue;for(int y=1;y<H-1;y++)for(int x=1;x<W-1;x++){var p=P(x,y);if(!seen.Contains(p))continue;int v=Math.Abs(x-orphan.Value.x)+Math.Abs(y-orphan.Value.y);if(v<distance){nearest=p;distance=v;}}if(!nearest.HasValue)break;int cx=orphan.Value.x,cy=orphan.Value.y;void Horizontal(){while(cx!=nearest.Value.x){OpenFeature(cx,cy);cx+=Math.Sign(nearest.Value.x-cx);}OpenFeature(cx,cy);}void Vertical(){while(cy!=nearest.Value.y){OpenFeature(cx,cy);cy+=Math.Sign(nearest.Value.y-cy);}OpenFeature(cx,cy);}if(random()<.5){Horizontal();Vertical();}else{Vertical();Horizontal();}
   }
  }
  bool CreatesRoom(int x,int y){var planned=Copies(x,y);bool FloorAt(int a,int b)=>Inside(a,b)&&(At(a,b)=='.'||planned.Contains(P(a,b)));foreach(var p in planned)for(int dy=-1;dy<=0;dy++)for(int dx=-1;dx<=0;dx++)if(FloorAt(p.x+dx,p.y+dy)&&FloorAt(p.x+dx+1,p.y+dy)&&FloorAt(p.x+dx,p.y+dy+1)&&FloorAt(p.x+dx+1,p.y+dy+1))return true;return false;}
  void EarlyFeatures(){var candidates=new List<Vector2Int>();for(int y=1;y<H-1;y++)for(int x=1;x<W-1;x++)if(At(x,y)=='#'&&(At(x-1,y)=='.'&&At(x+1,y)=='.'||At(x,y-1)=='.'&&At(x,y+1)=='.'))candidates.Add(P(x,y));Shuffle(candidates);int shortcuts=0;foreach(var p in candidates){if(shortcuts>=Math.Min(14,Math.Max(0,stage-1)*2))break;if(stage<4&&CreatesRoom(p.x,p.y))continue;OpenFeature(p.x,p.y);shortcuts++;}
   int passages=stage<4?0:Half(Math.Min(3,1+(stage-4)/3));for(int i=0;i<passages;i++)for(int attempt=0;attempt<40;attempt++){bool horizontal=random()<.5;int width=horizontal?3:2,height=horizontal?2:3,x=Integer(4,11),y=ZoneY(height);if(!Claim(x,y,width,height))continue;for(int dy=0;dy<height;dy++)for(int dx=0;dx<width;dx++)OpenFeature(x+dx,y+dy);break;}
   if(stage<5)for(int pass=0;pass<24;pass++){Vector2Int? isolated=null;for(int y=1;y<H-1&&!isolated.HasValue;y++)for(int x=1;x<W-1;x++)if(At(x,y)=='#'&&!D.Any(d=>At(P(x,y)+d)=='#')){isolated=P(x,y);break;}if(!isolated.HasValue)break;var dirs=D.ToArray();Shuffle(dirs);bool attached=false;foreach(var d in dirs){var p=isolated.Value+d;if(safe.Contains(p)||At(p)!='.')continue;var changes=new[]{p,Mirror(p.x,p.y)}.Where(Inside).Distinct().Select(q=>(p:q,v:At(q))).ToArray();WallPair(p.x,p.y);if(Connected()){attached=true;break;}foreach(var c in changes)g[c.p.y][c.p.x]=c.v;}if(!attached)OpenPair(isolated.Value.x,isolated.Value.y);}
   void Pocket(int tries){for(int attempt=0;attempt<tries;attempt++){int x=Integer(5,11),y=ZoneY(3),cy=y+1;if(!Claim(x-1,y,3,3))continue;for(int dy=-1;dy<=1;dy++)for(int dx=-1;dx<=1;dx++)OpenFeature(x+dx,cy+dy);WallFeature(x,cy);break;}}
   int pointPairs=stage<5?0:Math.Min(3,1+(stage-5)/2);for(int i=0;i<pointPairs;i++)Pocket(60);
   if(stage>=6){int arenas=Half(Math.Min(2,1+(stage-6)/4));for(int i=0;i<arenas;i++)for(int attempt=0;attempt<60;attempt++){int x=Integer(4,10),y=ZoneY(3);if(!Claim(x,y,3,3))continue;for(int dy=0;dy<3;dy++)for(int dx=0;dx<3;dx++)OpenFeature(x+dx,y+dy);break;}}
   if(stage>=9)for(int i=0;i<2;i++)Pocket(80);
  }
  public static MazeMetrics Rate(string[] grid,MazePatterns p){var m=new MazeMetrics();bool OpenAt(int x,int y)=>y>=0&&x>=0&&y<grid.Length&&x<grid[0].Length&&grid[y][x]!='#';for(int y=1;y<H-1;y++)for(int x=1;x<W-1;x++){if(!OpenAt(x,y))continue;m.floorCells++;int exits=D.Count(d=>OpenAt(x+d.x,y+d.y));if(exits==1)m.deadEnds++;if(exits>=3)m.junctions++;if(OpenAt(x+1,y)&&OpenAt(x,y+1)&&OpenAt(x+1,y+1))m.openTwoByTwo++;}m.patternDifficulty=p.fullyOrbitablePointCells*4.5+p.wideDiagonalCorridors*9+p.diagonalCorridors*2.5+p.cornerDiagonalStructures*4+p.orthogonalPointRuns*3+p.diagonalPointRuns*2;m.rating=m.floorCells*.10+m.junctions*.45+m.openTwoByTwo*1.30-m.deadEnds*.20+m.patternDifficulty;return m;}
 }
}

using System;
using System.Collections.Generic;
using UnityEngine;
namespace MazeBiters.NativeStudy {
 // Disposable presentation of a completed level. Never tick the live world:
 // its RNG already belongs to the prepared next level, and its result is final.
 public sealed class IpadClearCelebration {
  public NativeGameplayWorld World {get;}
  public double Started {get;}
  public double Time {get;private set;}
  public readonly List<NativeHunter> Hunters=new List<NativeHunter>();
  public NativeScorpion Scorpion {get;}
  readonly HashSet<Vector2Int> blocked=new HashSet<Vector2Int>();
  readonly Dictionary<Vector2Int,double> departingPlayers=new Dictionary<Vector2Int,double>();
  readonly string[] grid;
  readonly List<Vector2Int> players=new List<Vector2Int>();
  readonly Vector2Int[] options=new Vector2Int[4];
  uint random=0x7a2d9041;
  public IpadClearCelebration(NativeGameplayWorld world){
   World=world;Time=Started=world.TransitionAt;grid=(string[])world.Grid.Clone();
   foreach(var c in world.SolidEggs)blocked.Add(c);
   foreach(var e in world.Eggs)if(world.SolidEgg(e.Cell))blocked.Add(e.Cell);
   for(int i=0;i<world.PlayerCount;i++){
    var p=world.GetPlayer(i);if(p.Dead||p.Lives<=0)continue;
    players.Add(p.Cell);blocked.Add(p.Cell);
    if(p.From!=p.Cell){departingPlayers.TryGetValue(p.From,out double until);departingPlayers[p.From]=Math.Max(until,p.MoveStarted+p.MoveDuration);}
   }
   foreach(var h in world.Hunters)Hunters.Add(new NativeHunter{
    Id=h.Id,Cell=h.Cell,From=h.From,Dir=h.Dir,Palette=h.Palette,LastMove=h.LastMove,
    MoveStarted=h.MoveStarted,MoveDuration=h.MoveDuration,BiteAt=h.BiteAt,BiteEnd=h.BiteEnd,
    Aggression=h.Aggression,MotherAlive=h.MotherAlive
   });
   var s=world.Scorpion;
   if(s!=null)Scorpion=new NativeScorpion{Id=s.Id,Cell=s.Cell,Tail=s.Tail,Dir=s.Dir,
    Born=s.Born,LastMove=s.LastMove,Aggression=s.Aggression,Motion=CopyMotion(s.Motion)};
  }
  static NativeScorpionMotion CopyMotion(NativeScorpionMotion m)=>new NativeScorpionMotion(Vector2Int.zero,Vector2Int.zero,Vector2Int.right,Vector2Int.zero,Vector2Int.zero,Vector2Int.right,m.started,m.origin){
   started=m.started,duration=m.duration,origin=m.origin,fromX=m.fromX,fromY=m.fromY,toX=m.toX,toY=m.toY,
   fromAngle=m.fromAngle,delta=m.delta,turnSign=m.turnSign,incoming=m.incoming,kind=m.kind
  };
  double Random(){unchecked{random^=random<<13;random^=random>>17;random^=random<<5;}return random/4294967296.0;}
  bool Open(Vector2Int cell,NativeHunter except=null,bool scorpion=false){
   if(cell.y<0||cell.y>=grid.Length||cell.x<0||cell.x>=grid[cell.y].Length||grid[cell.y][cell.x]=='#'||blocked.Contains(cell))return false;
   if(departingPlayers.TryGetValue(cell,out double until)&&Time<until)return false;
   foreach(var h in Hunters)if(h!=except&&(h.Cell==cell||Time<h.MoveStarted+h.MoveDuration&&h.From==cell))return false;
   if(!scorpion&&Scorpion!=null){
    if(cell==Scorpion.Cell||cell==Scorpion.Tail)return false;
    // Reserve both cells of the departing body until its curved turn ends.
    if(Time<Scorpion.Motion.started+Scorpion.Motion.duration){
     double x=(cell.x+.5)*16,y=(cell.y+.5)*16;
     if(Math.Abs(x-Scorpion.Motion.fromX)+Math.Abs(y-Scorpion.Motion.fromY)<=8.01)return false;
    }
   }
   return true;
  }
  Vector2Int Choose(Vector2Int cell,Vector2Int dir,NativeHunter hunter,bool scorpion){
   int count=0;
   foreach(var d in NativeGameplayWorld.Dirs)if(d!=-dir&&Open(cell+d,hunter,scorpion))options[count++]=d;
   // Ricochet at a player or a closed passage; no arbitrary U-turn in open space.
   if(count==0){if(Open(cell-dir,hunter,scorpion))return -dir;return Vector2Int.zero;}
   Vector2Int chosen=options[0];double best=double.NegativeInfinity;
   for(int i=0;i<count;i++){
    var d=options[i];var next=cell+d;double distance=5;
    foreach(var p in players)distance=Math.Min(distance,Math.Abs(p.x-next.x)+Math.Abs(p.y-next.y));
    double score=distance*2+(d==dir?.65:0)+Random()*.9;
    if(score>best){best=score;chosen=d;}
   }
   return chosen;
  }
  public void Advance(double time,Action<NativeHunter,Vector2Int,double> onTurn=null){
   if(double.IsNaN(time)||double.IsInfinity(time)||time<=Time)return;
   Time=time;
   foreach(var h in Hunters){
    if(time<Math.Max(h.LastMove+95,h.MoveStarted+h.MoveDuration))continue;
    var old=h.Dir;var from=h.Cell;var dir=Choose(from,old,h,false);
    h.LastMove=time;h.From=from;h.MoveStarted=time;h.MoveDuration=95;
    if(dir==Vector2Int.zero)continue;
    h.Dir=dir;h.Cell+=dir;onTurn?.Invoke(h,old,time);
   }
   var s=Scorpion;
   if(s==null||time<Math.Max(s.LastMove+218,s.Motion.started+s.Motion.duration))return;
   var head=s.Cell;var tail=s.Tail;var incoming=s.Dir;var chosen=Choose(head,incoming,null,true);
   if(chosen!=Vector2Int.zero){s.Dir=chosen;s.Cell+=chosen;s.Tail=head;}
   s.LastMove=time;s.Motion=new NativeScorpionMotion(head,tail,incoming,s.Cell,s.Tail,s.Dir,time,s.Motion.origin);
  }
 }
}

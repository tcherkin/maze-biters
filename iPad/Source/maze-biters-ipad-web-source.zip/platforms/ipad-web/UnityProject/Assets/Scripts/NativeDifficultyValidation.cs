using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using UnityEngine;

namespace MazeBiters.NativeStudy {
 [Serializable] public sealed class NativeDifficultyCheck {
  public string name,detail;
  public bool passed;
 }
 [Serializable] public sealed class NativeDifficultySample {
  public string difficulty;
  public int index,level,samples,toward,away,neutral,legal,hunt,evade,wander;
  public bool injured;
  public double ageMs,pursuitRate,escapeRate,huntRate,meanAggression,meanIntelligence;
 }
 [Serializable] public sealed class NativeDifficultyPolicySample {
  public int index,level;
  public NativeDifficultyProfile policy;
 }
 [Serializable] public sealed class NativeDifficultyReport {
  public bool passed;
  public int assertions,failures,decisions;
  public double elapsedMs;
  public string note;
  public List<NativeDifficultyCheck> checks=new List<NativeDifficultyCheck>();
  public List<NativeDifficultySample> samples=new List<NativeDifficultySample>();
  public List<NativeDifficultyPolicySample> policies=new List<NativeDifficultyPolicySample>();
 }

 // Behaviour checks intentionally use seeded decisions and real collision/path
 // rules. They are independent of the frozen browser's direction/RNG snapshots.
 public static class NativeDifficultyValidation {
  const int Samples=128;
  static readonly Vector2Int Up=new Vector2Int(0,-1);
  sealed class Tape {
   uint state;
   public Tape(int seed){state=(uint)seed;}
   public double Next(){unchecked{state+=0x6D2B79F5;uint v=(state^(state>>15))*(1|state);v^=v+(v^(v>>7))*(61|v);return (v^(v>>14))/4294967296.0;}}
  }
  static string[] OpenGrid(int width=17,int height=15){
   var grid=new string[height];
   for(int y=0;y<height;y++)grid[y]=y==0||y==height-1?new string('#',width):"#"+new string('.',width-2)+"#";
   return grid;
  }
  static NativeGameplayWorld World(int index,int seed,int level=1,double age=0,string[] grid=null){
   var rng=new Tape(seed);
   var w=new NativeGameplayWorld(grid??OpenGrid(),rng.Next){Difficulty=NativeMazeGenerator.Difficulties[index],AiDifficulty=index,Level=level,Time=1000+age,LevelStarted=1000,Assist=false};
   w.Player.Cell=w.Player.From=w.Player.Previous=new Vector2Int(3,7);
   w.Player.Dir=w.Player.Next=Vector2Int.left;
   return w;
  }
  static NativeGameplaySnake Snake(NativeGameplayWorld w,Vector2Int cell,bool injured=false,int length=6){
   var s=new NativeGameplaySnake{Id=10,Cell=cell,Dir=Up,Temperament=.5,Anger=injured?12:0,Threat=injured?12:0};
   for(int i=0;i<length;i++)s.Body.Add(cell+new Vector2Int(0,i));
   if(injured)s.PersonalThreat[0]=12;
   w.Snakes.Add(s);return s;
  }
  static List<Vector2Int> Options(NativeGameplayWorld w,NativeGameplaySnake s)=>NativeGameplayWorld.Dirs.Where(d=>w.CanEnter(s.Head+d,s)).ToList();
  static void Intent(NativeGameplayWorld w,NativeGameplaySnake s,string intent){
   var state=w.Brain.State(s);state.intent=intent;state.intentUntil=w.Time+60000;state.observedAnger=s.Anger;state.intentPlayerId=1;
  }
  static int Distance(NativeGameplayWorld w,Vector2Int cell,NativePlayer p)=>w.Brain.Field(p.Cell)[w.Index(cell)];
  static int NearestLivingDistance(NativeGameplayWorld w,Vector2Int cell){
   int value=int.MaxValue;
   for(int i=0;i<w.PlayerCount;i++){var p=w.GetPlayer(i);if(p.Dead||p.Lives<=0)continue;int d=Distance(w,cell,p);if(d>=0)value=Math.Min(value,d);}
   return value;
  }
  static Vector2Int Decide(NativeGameplayWorld w,NativeGameplaySnake s,List<Vector2Int> options=null)=>w.Brain.Choose(s,s.Head,options??Options(w,s),NativeGameplayWorld.Profile(s));
  static void Check(NativeDifficultyReport r,bool passed,string name,string detail=""){
   r.assertions++;if(!passed)r.failures++;r.checks.Add(new NativeDifficultyCheck{name=name,passed=passed,detail=detail});
  }
  static void Group(NativeDifficultyReport r,string name,Action action){
   try{action();}catch(Exception e){Check(r,false,name+" completed",e.GetType().Name+": "+e.Message);}
  }
  static NativeDifficultySample Measure(int index,int level,double age,bool injured,NativeDifficultyReport report){
   var sample=new NativeDifficultySample{index=index,difficulty=NativeMazeGenerator.DifficultyNames[index],level=level,ageMs=age,injured=injured,samples=Samples};
   for(int seed=1;seed<=Samples;seed++){
    var w=World(index,seed*7919,level,age);var s=Snake(w,new Vector2Int(8,7),injured);var options=Options(w,s);
    int before=Distance(w,s.Head,w.Player);var d=Decide(w,s,options);report.decisions++;
    if(options.Contains(d)&&w.CanEnter(s.Head+d,s))sample.legal++;
    int after=Distance(w,s.Head+d,w.Player);
    if(after<before)sample.toward++;else if(after>before)sample.away++;else sample.neutral++;
    string intent=s.Brain?.intent;if(intent=="hunt")sample.hunt++;else if(intent=="evade")sample.evade++;else if(intent=="wander")sample.wander++;
    sample.meanAggression+=s.Aggression;sample.meanIntelligence+=s.Intelligence;
   }
   sample.pursuitRate=(double)sample.toward/Samples;sample.escapeRate=(double)sample.away/Samples;sample.huntRate=(double)sample.hunt/Samples;
   sample.meanAggression/=Samples;sample.meanIntelligence/=Samples;report.samples.Add(sample);return sample;
  }
  static void Scale(NativeDifficultyReport r){
   foreach(int level in new[]{1,10,100})foreach(int index in Enumerable.Range(0,5)){
    r.policies.Add(new NativeDifficultyPolicySample{index=index,level=level,policy=NativeDifficulty.ForIndex(index,level)});
    foreach(double age in new[]{0.0,600000.0})foreach(bool injured in new[]{false,true}){
     var s=Measure(index,level,age,injured,r);string name=s.difficulty+" level="+level+" age="+age+" injured="+injured;
     Check(r,s.legal==s.samples,name+" always chooses a legal cell",s.legal+"/"+s.samples);
     if(index==0){Check(r,s.pursuitRate<=(injured?.35:.20),name+" remains mostly evasive","pursuit="+s.pursuitRate.ToString("F3"));Check(r,s.huntRate<=(injured?.30:.12),name+" aggression is rare","hunt="+s.huntRate.ToString("F3"));}
     if(index==4){Check(r,s.pursuitRate>=.90,name+" pursues the unique shortest route","pursuit="+s.pursuitRate.ToString("F3"));Check(r,s.huntRate>=.90,name+" strongly engages","hunt="+s.huntRate.ToString("F3"));}
    }
   }
   foreach(int index in Enumerable.Range(0,5))foreach(int level in new[]{1,10,100})foreach(bool injured in new[]{false,true}){
    var pair=r.samples.Where(s=>s.index==index&&s.level==level&&s.injured==injured).OrderBy(s=>s.ageMs).ToArray();
    Check(r,Math.Abs(pair[0].pursuitRate-pair[1].pursuitRate)<=.15,"Elapsed time does not erase tier "+index+" at level "+level+" injured="+injured,"start="+pair[0].pursuitRate.ToString("F3")+", ten minutes="+pair[1].pursuitRate.ToString("F3"));
   }
   var opening=r.samples.Where(s=>s.level==1&&s.ageMs==0&&!s.injured).OrderBy(s=>s.index).ToArray();
   for(int i=1;i<opening.Length;i++)Check(r,opening[i].pursuitRate+.08>=opening[i-1].pursuitRate,"Pursuit progresses between tiers "+(i-1)+" and "+i);
   Check(r,opening[4].pursuitRate-opening[0].pursuitRate>=.70,"Difficulty endpoints have a wide behavioural gap");
   var easyFresh=r.samples.First(s=>s.index==0&&s.level==1&&s.ageMs==0&&!s.injured);
   var easyHurt=r.samples.First(s=>s.index==0&&s.level==1&&s.ageMs==0&&s.injured);
   Check(r,easyHurt.huntRate>=easyFresh.huntRate&&easyHurt.huntRate<=.30,"Injury permits bounded revenge on PICNIC","healthy="+easyFresh.huntRate.ToString("F3")+", injured="+easyHurt.huntRate.ToString("F3"));
  }
  static void StrongPursuit(NativeDifficultyReport r){
   int correct=0;
   for(int seed=1;seed<=Samples;seed++){
    var w=World(4,seed*3571);var s=Snake(w,new Vector2Int(8,7));Intent(w,s,"hunt");var d=Decide(w,s);r.decisions++;
    if(d==Vector2Int.left)correct++;
   }
   Check(r,correct==Samples,"BRUTAL committed pursuit makes no deliberate routing errors",correct+"/"+Samples);
   int shortest=0;
   string[] grid={"#############","#...........#","#.#########.#","#...........#","#.#########.#","#...........#","#############"};
   for(int seed=1;seed<=Samples;seed++){
    var w=World(4,seed*5113,grid:grid);w.Player.Cell=new Vector2Int(2,1);var s=Snake(w,new Vector2Int(10,5),length:1);Intent(w,s,"hunt");
    var options=Options(w,s);int best=options.Min(d=>Distance(w,s.Head+d,w.Player));var chosen=Decide(w,s,options);r.decisions++;
    if(Distance(w,s.Head+chosen,w.Player)==best)shortest++;
   }
   Check(r,shortest==Samples,"BRUTAL routes around maze walls using actual path distance",shortest+"/"+Samples);
  }
  static void MultiplePlayers(NativeDifficultyReport r){
   foreach(int count in new[]{2,3}){
    int safe=0;
    for(int seed=1;seed<=Samples;seed++){
     var w=World(0,seed*9811);w.SetMode(count==3?4:5);
     w.GetPlayer(0).Cell=new Vector2Int(5,7);w.GetPlayer(1).Cell=new Vector2Int(11,7);if(count==3)w.GetPlayer(2).Cell=new Vector2Int(8,10);
     var s=Snake(w,new Vector2Int(8,7),length:1);s.PersonalThreat[0]=100;Intent(w,s,"evade");
     int before=NearestLivingDistance(w,s.Head);var d=Decide(w,s);r.decisions++;
     if(NearestLivingDistance(w,s.Head+d)>before)safe++;
    }
    Check(r,safe>=Samples*.90,"PICNIC escape considers all "+count+" living players",safe+"/"+Samples+" increase distance to nearest threat");
   }
   int ignoresDead=0;
   for(int seed=1;seed<=Samples;seed++){
    var w=World(0,seed*9973);w.SetMode(4);w.GetPlayer(0).Cell=new Vector2Int(5,7);w.GetPlayer(1).Cell=new Vector2Int(11,7);
    var dead=w.GetPlayer(2);dead.Cell=new Vector2Int(8,6);dead.Dead=true;dead.Lives=0;
    var s=Snake(w,new Vector2Int(8,7),length:1);Intent(w,s,"evade");
    // Both vertical branches are safe from living players; one contains only a dead player.
    var options=new List<Vector2Int>{Up,Vector2Int.right};var d=Decide(w,s,options);r.decisions++;
    if(d==Up)ignoresDead++;
   }
   Check(r,ignoresDead>=Samples*.90,"Dead players do not distort escape threat selection",ignoresDead+"/"+Samples);
  }
  static string[] EscapeGrid(bool eggAlternative){
   const int width=15,height=13;var rows=new char[height][];for(int y=0;y<height;y++)rows[y]=new string('#',width).ToCharArray();
   for(int x=2;x<=9;x++)rows[7][x]='.';
   for(int y=2;y<=7;y++)rows[y][7]='.';
   for(int y=2;y<=5;y++)for(int x=2;x<=12;x++)rows[y][x]='.';
   if(eggAlternative)for(int y=6;y<=10;y++)for(int x=9;x<=12;x++)rows[y][x]='.';
   return rows.Select(row=>new string(row)).ToArray();
  }
  static void EscapeRoutes(NativeDifficultyReport r){
   int avoidsDeadEnd=0,avoidsEggTrap=0;
   for(int seed=1;seed<=Samples;seed++){
    var w=World(0,seed*2371,grid:EscapeGrid(false));w.Player.Cell=new Vector2Int(4,7);var s=Snake(w,new Vector2Int(7,7),length:1);Intent(w,s,"evade");
    var d=Decide(w,s,new List<Vector2Int>{Up,Vector2Int.right});r.decisions++;if(d==Up)avoidsDeadEnd++;
    var blocked=World(0,seed*2371,grid:EscapeGrid(true));blocked.Player.Cell=new Vector2Int(4,7);blocked.SolidEggs.Add(new Vector2Int(7,5));blocked.ObstacleRevision++;
    var other=Snake(blocked,new Vector2Int(7,7),length:1);Intent(blocked,other,"evade");
    var move=Decide(blocked,other,new List<Vector2Int>{Up,Vector2Int.right});r.decisions++;if(move==Vector2Int.right)avoidsEggTrap++;
   }
   Check(r,avoidsDeadEnd>=Samples*.90,"Escape looks beyond the next cell and avoids a short dead end",avoidsDeadEnd+"/"+Samples);
   Check(r,avoidsEggTrap>=Samples*.90,"Escape lookahead respects an egg that blocks the corridor",avoidsEggTrap+"/"+Samples);
   var single=World(0,83,grid:new[]{"#######","#.....#","#######"});single.Player.Cell=new Vector2Int(1,1);
   var snake=Snake(single,new Vector2Int(3,1),length:1);single.SolidEggs.Add(new Vector2Int(2,1));single.ObstacleRevision++;
   var options=Options(single,snake);var chosen=Decide(single,snake,options);r.decisions++;
   Check(r,options.Count==1&&chosen==Vector2Int.right,"A forced legal exit never enters a wall or solid egg");
   single.SolidEggs.Add(new Vector2Int(4,1));single.ObstacleRevision++;var stopped=Decide(single,snake,Options(single,snake));r.decisions++;
   Check(r,stopped==Vector2Int.zero,"A fully blocked creature stops without inventing a route");
  }
  static void NoThreatsAndScorpion(NativeDifficultyReport r){
   int legal=0,wanders=0,scorpionAway=0;
   for(int seed=1;seed<=Samples;seed++){
    var w=World(0,seed*9239);w.SetMode(4);for(int i=0;i<w.PlayerCount;i++){w.GetPlayer(i).Dead=true;w.GetPlayer(i).Lives=0;}
    var s=Snake(w,new Vector2Int(8,7));var options=Options(w,s);var d=Decide(w,s,options);r.decisions++;
    if(options.Contains(d))legal++;if(s.Brain?.intent=="wander")wanders++;
    var scorpionWorld=World(0,seed*9241);var scorpion=scorpionWorld.PlaceScorpion(new Vector2Int(8,7),Up);
    var exits=NativeGameplayWorld.Dirs.Where(x=>scorpionWorld.Floor(scorpion.Cell+x)&&scorpionWorld.PlayerAt(scorpion.Cell+x)==null).ToList();
    int before=Distance(scorpionWorld,scorpion.Cell,scorpionWorld.Player);
    var step=scorpionWorld.Brain.Choose(scorpion,scorpion.Cell,exits,new BrainProfile{kind="scorpion",flee=true,baseline=.46,listenBoost=.15});r.decisions++;
    if(Distance(scorpionWorld,scorpion.Cell+step,scorpionWorld.Player)>before)scorpionAway++;
   }
   Check(r,legal==Samples&&wanders==Samples,"No living players produces legal wandering",legal+" legal and "+wanders+" wandering of "+Samples);
   Check(r,scorpionAway>=Samples*.85,"PICNIC scorpions continue to navigate away from the player",scorpionAway+"/"+Samples);
  }
  static void InjuryAndPersistence(NativeDifficultyReport r){
   int revenge=0,evades=0;
   for(int seed=1;seed<=Samples;seed++){
    var w=World(0,seed*2357);var s=Snake(w,new Vector2Int(8,7));Intent(w,s,"evade");
    Decide(w,s);r.decisions++;s.Anger=12;s.Threat=12;w.Time+=218;
    Decide(w,s);r.decisions++;if(s.Brain.intent=="hunt")revenge++;if(s.Brain.intent=="evade")evades++;
   }
   Check(r,revenge>0&&revenge<=Samples*.30&&evades>=Samples*.70,"A new injury occasionally interrupts evasion for gentle revenge",revenge+" hunt, "+evades+" evade of "+Samples);
   var sustained=World(0,4711);var resident=Snake(sustained,new Vector2Int(8,7));int lateHunts=0,lateAway=0;
   for(int step=0;step<240;step++){
    sustained.Time=1000+step*3000;var d=Decide(sustained,resident);r.decisions++;
    if(step>=120){if(resident.Brain.intent=="hunt")lateHunts++;if(Distance(sustained,resident.Head+d,sustained.Player)>Distance(sustained,resident.Head,sustained.Player))lateAway++;}
   }
   Check(r,lateHunts<=24&&lateAway>=96,"A persistent PICNIC brain still favours evasion after six to twelve minutes",lateHunts+" hunt and "+lateAway+" escape of 120 late decisions");
  }
  static void BoundedPressure(NativeDifficultyReport r){
   foreach(int index in Enumerable.Range(0,5))foreach(int level in new[]{1,100}){
    var w=World(index,89,level,3600000);w.StartingSnakeMass=48;
    double hour=w.TimePressure,depleted=w.DepletionPressure;w.Time=w.LevelStarted+86400000;
    var tuning=NativeDifficulty.ForIndex(index,level);
    Check(r,hour>=1&&hour<=tuning.MaxTimePressure+1e-9&&Math.Abs(w.TimePressure-hour)<1e-9,"Time pressure plateaus for tier "+index+" level "+level,"hour="+hour.ToString("F3")+", day="+w.TimePressure.ToString("F3"));
    Check(r,depleted>=1&&depleted<=1+tuning.DepletionBoost+1e-9,"Depletion pressure is bounded for tier "+index+" level "+level,"depleted="+depleted.ToString("F3"));
   }
   var picnic=World(0,83,age:120000);double twoMinutes=picnic.TimePressure;picnic.Time=picnic.LevelStarted+600000;double tenMinutes=picnic.TimePressure;
   Check(r,twoMinutes<=1.10&&tenMinutes<=1.30&&tenMinutes-twoMinutes<=.20,"PICNIC remains gently paced between two and ten minutes","two minutes="+twoMinutes.ToString("F3")+", ten minutes="+tenMinutes.ToString("F3"));
  }
  static void CoordinationAndChangingRoutes(NativeDifficultyReport r){
   int converged=0,maximumSteps=0;
   for(int seed=1;seed<=32;seed++){
    var w=World(4,seed*4691);w.Player.Cell=new Vector2Int(6,7);w.Player.Dir=Vector2Int.right;
    var s=Snake(w,new Vector2Int(12,7),length:1);
    Snake(w,new Vector2Int(13,12),length:1);Snake(w,new Vector2Int(14,12),length:1);
    Intent(w,s,"hunt");s.Brain.brainId=2;
    // The left wing's first target is (9,9), five cells from the player.
    // Completing that flank must eventually become a strike, not an orbit.
    int steps=0;
    while(s.Head!=w.Player.Cell&&steps<24){
     var options=Options(w,s);var d=Decide(w,s,options);r.decisions++;if(!options.Contains(d))break;
     s.Body[0]+=d;s.Cell=s.Head;s.Dir=d;w.Time+=300;steps++;
    }
    if(s.Head==w.Player.Cell){converged++;maximumSteps=Math.Max(maximumSteps,steps);}
   }
   Check(r,converged==32,"BRUTAL wings converge on the player after reaching their flank",converged+"/32 reached the player; longest successful route="+maximumSteps);
   {
    var committed=new NativeGameplayWorld(OpenGrid(),()=>0){Difficulty=1.5,Time=1000};committed.Player.Cell=new Vector2Int(6,7);committed.Player.Dir=Vector2Int.right;
    var s=Snake(committed,new Vector2Int(12,7),length:1);s.Dir=new Vector2Int(0,1);Snake(committed,new Vector2Int(13,12),length:1);Snake(committed,new Vector2Int(14,12),length:1);
    Intent(committed,s,"hunt");s.Brain.brainId=2;s.Brain.targetPlayerId=1;s.Brain.targetPlayerUntil=2000;s.Brain.intentUntil=900;s.Brain.target=committed.Player.Cell;s.Brain.planType="coordinate-strike";s.Brain.planUntil=2000;
    var d=Decide(committed,s);r.decisions++;
    Check(r,d==Vector2Int.left&&s.Brain.planType=="coordinate-strike","Renewing a hunt continues the strike instead of starting a second flank");
   }
   string[] crowdGrid={"#########","#.......#","#..###..#","#.......#","#..###..#","#.......#","#########"};
   int aroundCrowd=0;
   for(int seed=1;seed<=32;seed++){
    var w=World(4,seed*4787,grid:crowdGrid);w.Player.Cell=new Vector2Int(6,3);
    var s=Snake(w,new Vector2Int(2,3),length:1);s.Dir=Vector2Int.right;
    Snake(w,new Vector2Int(4,3),length:1);Intent(w,s,"hunt");var d=Decide(w,s);r.decisions++;
    if(d==Up||d==new Vector2Int(0,1))aroundCrowd++;
   }
   Check(r,aroundCrowd==32,"BRUTAL routes around a body blocking the otherwise shortest corridor",aroundCrowd+"/32 chose an open bypass");
   var changing=World(4,631,grid:OpenGrid(9,7));changing.Player.Cell=new Vector2Int(6,3);
   var hunter=Snake(changing,new Vector2Int(2,3),length:1);hunter.Dir=Vector2Int.right;Intent(changing,hunter,"hunt");
   var before=changing.Brain.Field(changing.Player.Cell);int oldDistance=before[changing.Index(hunter.Head)],revision=changing.ObstacleRevision;
   changing.Grid=new[]{"#########","#.......#","#..###..#","#...#...#","#..###..#","#.......#","#########"};
   var after=changing.Brain.Field(changing.Player.Cell);var direction=Decide(changing,hunter);r.decisions++;
   Check(r,changing.ObstacleRevision==revision&&!ReferenceEquals(before,after)&&oldDistance==4&&after[changing.Index(hunter.Head)]>oldDistance,"Replacing a maze invalidates fields even when player coordinates and obstacle revision match","before="+oldDistance+", after="+after[changing.Index(hunter.Head)]);
   Check(r,direction==Up||direction==new Vector2Int(0,1),"A replaced maze changes the next actual pursuit choice");
  }
  public static NativeDifficultyReport Run(){
   var clock=Stopwatch.StartNew();var r=new NativeDifficultyReport{note="Seeded native brain outcome audit. Shortest-route, multi-player escape and obstacle checks use actual world/brain methods. Rates describe controlled junctions, not play-session win rates or device frame time. No screenshots, browser implementation or physical iPad execution are involved."};
   Group(r,"difficulty scale",()=>Scale(r));Group(r,"strong pursuit",()=>StrongPursuit(r));Group(r,"all living threats",()=>MultiplePlayers(r));
   Group(r,"escape topology",()=>EscapeRoutes(r));Group(r,"no threats and scorpion",()=>NoThreatsAndScorpion(r));
   Group(r,"injury and persistence",()=>InjuryAndPersistence(r));Group(r,"bounded pressure",()=>BoundedPressure(r));
   Group(r,"coordination and changing routes",()=>CoordinationAndChangingRoutes(r));
   clock.Stop();r.elapsedMs=clock.Elapsed.TotalMilliseconds;r.passed=r.failures==0;return r;
  }
 }
}

#if UNITY_EDITOR
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Reflection;
using UnityEngine;
namespace MazeBiters.NativeStudy {
 [Serializable] public sealed class NativeComboReport {
  public bool passed;public int assertions,failures,movementSteps;public double elapsedMs;
  public string scope="Deterministic iPad gameplay contacts, four directions, human/AI actors, real movement and lifecycle. Simulation tests; no device-performance claim.";
  public List<NativeDifficultyCheck> checks=new List<NativeDifficultyCheck>();
 }
 public static partial class NativeComboValidation {
  static readonly Vector2Int Centre=new Vector2Int(48,48);
  sealed class Fixture {
   public NativeGameplayWorld world;public readonly List<NativeWorldEvent> events=new List<NativeWorldEvent>();
   public int StartSounds=>events.Count(e=>e.Kind=="sound"&&e.Sound=="snakeSTART@");
  }
  static Fixture World(int mode=1,int tier=2){
   var rows=Enumerable.Range(0,96).Select(y=>y==0||y==95?new string('#',96):"#"+new string('.',94)+"#").ToArray();
   var f=new Fixture{world=new NativeGameplayWorld(rows,NativeMazeGenerator.Rng(419)){Time=1000,LevelStarted=1000,Assist=false,SessionEnabled=true,AiDifficulty=tier,Difficulty=1}};var w=f.world;w.SetMode(mode);w.Event=e=>f.events.Add(e);
   for(int i=0;i<w.PlayerCount;i++){var p=w.GetPlayer(i);Position(p,Centre+new Vector2Int(0,i*12),Vector2Int.right);p.ShieldUntil=0;}
   w.PlayerStart=Centre;w.StartDirection=Vector2Int.right;
   // Keep normal CheckLevelComplete active without ending the synthetic chain.
   w.AddSnake(new[]{new Vector2Int(3,3)},Vector2Int.right,4);
   return f;
  }
  static void Position(NativePlayer p,Vector2Int at,Vector2Int dir){p.Cell=p.From=p.Previous=at;p.Dir=p.Next=dir;p.Waiting=false;p.Pointer=null;p.PointerMomentum=false;p.Keys.Clear();p.Ricochet=null;}
  static NativeGameplaySnake Add(NativeGameplayWorld w,Vector2Int tail,Vector2Int dir,int length,int palette=0)=>w.AddSnake(Enumerable.Range(0,length).Select(i=>tail+dir*(length-1-i)),dir,palette);
  static void Check(NativeComboReport r,bool ok,string name){r.assertions++;if(!ok)r.failures++;r.checks.Add(new NativeDifficultyCheck{name=name,passed=ok});}
  static void Clock(NativeGameplayWorld w,double t){w.Time=t;w.UpdateCombos();}
  static bool Near(double a,double b,double tolerance=1e-8)=>Math.Abs(a-b)<=tolerance;
  static void Group(NativeComboReport r,string name,Action action){try{action();}catch(Exception e){r.assertions++;r.failures++;r.checks.Add(new NativeDifficultyCheck{name=name,passed=false,detail=e.ToString()});}}
  static void Step(NativeComboReport r,NativeGameplayWorld w,Vector2Int? dir=null){if(dir.HasValue)w.Player.Next=dir.Value;w.Time+=w.PlayerDelay+.01;w.AdvancePlayer();w.Player.LastMove=w.Time;r.movementSteps++;}
  static void AddChain(NativeGameplayWorld w,Vector2Int origin,Vector2Int dir){Add(w,origin+dir,dir,3);Add(w,origin+dir*4,dir,24,1);Add(w,origin+dir*28,dir,8,2);}
  static Fixture Active(NativeComboReport r,int mode=1,int slot=0,int tier=2){var f=World(mode,tier);var w=f.world;var p=w.GetPlayer(slot);using(w.ForPlayer(p)){AddChain(w,p.Cell,Vector2Int.right);for(int i=0;i<5;i++)Step(r,w);}return f;}

  static void Continuous(NativeComboReport r){
   foreach(var d in NativeGameplayWorld.Dirs)foreach(bool ai in new[]{false,true}){
    var f=World(ai?0:1);var w=f.world;Position(w.Player,Centre,d);AddChain(w,Centre,d);string label=$"direction={d}, AI={ai}";
    for(int i=1;i<=3;i++){Step(r,w);Check(r,!w.ComboActive&&Near(w.PlayerDelay,95)&&w.Player.Combo.SnakeCount==1,$"First snake never accelerates, including rear head {i}: {label}");}
    Check(r,f.StartSounds==0,"No Power sound for first snake: "+label);
    Step(r,w);double activated=w.Time;
    Check(r,w.ComboActive&&w.Player.Combo.SnakeCount==2&&f.StartSounds==1,"Second distinct snake starts combo exactly once: "+label);
    Check(r,!w.Power&&!w.CombatPower&&!w.PlayerProtected(w.Player,w.Time)&&!w.Player.PowerBright&&w.Player.PowerUntil==0,"Combo grants speed only, no attack/protection/Power flash: "+label);
    Check(r,Near(w.ComboStrength,0),"Acceleration begins continuously at the first second-snake bite: "+label);
    double previous=0;
    for(int i=5;i<=27;i++){Step(r,w);double u=Math.Min(1,(w.Time-activated)/500),expected=1-(1-u)*(1-u);Check(r,w.ComboActive&&w.ComboStrength>=previous&&Near(w.ComboStrength,expected)&&w.PlayerDelay>=47.5&&w.PlayerDelay<=95,"Continuous half-time speed ramp while eating second snake, step "+i+": "+label);previous=w.ComboStrength;}
    Check(r,Near(w.ComboStrength,1)&&Near(w.PlayerDelay,47.5),"Long uninterrupted eating reaches normal Power maximum: "+label);
    Step(r,w);Check(r,w.ComboActive&&w.Player.Combo.SnakeCount==3&&f.StartSounds==2,"Third snake upgrades the score and cue without restarting its speed ramp: "+label);
    for(int i=29;i<=35;i++)Step(r,w);
    Check(r,w.ComboActive&&f.StartSounds==2,"Final rear head remains part of uninterrupted meal: "+label);
    Step(r,w);double ended=w.Time,strength=w.ComboStrength;
    Check(r,w.ComboActive&&w.Player.Combo.CoolingDown&&w.Player.Combo.SnakeCount==3&&Near(strength,1),"First empty step starts grace without losing speed or multiplier: "+label);
    Clock(w,ended+999);Check(r,w.ComboActive&&Near(w.ComboStrength,1),"Full speed survives the whole grace window: "+label);ended+=1000;Clock(w,ended);Check(r,!w.ComboActive&&w.Player.Combo.SnakeCount==0,"Exact grace expiry clears the multiplier: "+label);
    foreach(double age in new[]{1.0,100.0,500.0,750.0,1499.0,1500.0,8000.0}){w.Time=ended+age;double u=Math.Min(1,age/1500);Check(r,Near(w.ComboStrength,strength*(1-u*u)),"Original deceleration after the grace window at "+age+"ms: "+label);}
    Check(r,Near(w.PlayerDelay,95)&&w.Player.Combo.SnakeCount==0&&f.StartSounds==2,"Normal speed restored after combo: "+label);
   }
  }
  static void EarlyBreaks(NativeComboReport r){
   foreach(double age in new[]{100.0,250.0,499.0,500.0,1000.0}){
    var f=World();var w=f.world;AddChain(w,Centre,Vector2Int.right);for(int i=0;i<4;i++)Step(r,w);double activated=w.Time;Clock(w,activated+age);
    double u=Math.Min(1,age/500),attained=1-(1-u)*(1-u);Check(r,Near(w.ComboStrength,attained),"Original smooth acceleration at "+age+"ms");
    w.Player.Waiting=true;w.AdvancePlayer();r.movementSteps++;double stopped=w.Time;
    Check(r,w.ComboActive&&w.Player.Combo.CoolingDown&&Near(w.ComboStrength,attained)&&f.StartSounds==1,"Early stop begins grace continuously at "+age+"ms");
    Clock(w,stopped+999);Check(r,w.ComboActive&&Near(w.ComboStrength,1),"An active combo finishes acceleration during grace");
    foreach(double fallAge in new[]{0.0,1.0,250.0,750.0,1499.0,1500.0}){Clock(w,stopped+1000+fallAge);double down=Math.Min(1,fallAge/1500);Check(r,!w.ComboActive&&Near(w.ComboStrength,1-down*down),"Decay starts only after grace: rise="+age+", decay="+fallAge);}
   }
   foreach(int bodyBites in new[]{1,2,3}){
    var f=World();var w=f.world;Add(w,Centre+Vector2Int.right,Vector2Int.right,1);Add(w,Centre+Vector2Int.right*2,Vector2Int.right,8);Step(r,w);Step(r,w);for(int i=1;i<bodyBites;i++)Step(r,w);
    Step(r,w,Vector2Int.down);double stopped=w.Time;
    Check(r,w.ComboActive&&w.Player.Combo.CoolingDown&&Near(w.Player.Combo.CooldownUntil,stopped+1000),"Short second meal receives the same one-second grace: "+bodyBites);
    Clock(w,stopped+2500);Check(r,!w.ComboActive&&Near(w.ComboStrength,0)&&Near(w.PlayerDelay,95)&&f.StartSounds==1,"Short meal returns to normal speed after grace and existing decay");
   }
   {
    var f=World();var w=f.world;AddChain(w,Centre,Vector2Int.right);for(int i=0;i<20;i++)Step(r,w);Check(r,Near(w.ComboStrength,1),"Restart fixture reached full speed");w.BreakCombo();double stopped=w.Time;w.Time+=100;
    w.Snakes.Clear();w.AddSnake(new[]{new Vector2Int(3,3)},Vector2Int.right,4);Add(w,w.Player.Cell+Vector2Int.right,Vector2Int.right,1);Add(w,w.Player.Cell+Vector2Int.right*2,Vector2Int.right,8);
    Step(r,w);double at=w.Time+w.PlayerDelay+.01,u=(at-stopped)/1500,remaining=1-u*u;Step(r,w);double restarted=w.Time;
    Check(r,w.ComboActive&&Near(w.ComboStrength,remaining)&&remaining>0&&remaining<1&&f.StartSounds==2,"New chain during decay restarts continuously from its exact residual speed");
    w.Time=restarted+250;Check(r,Near(w.ComboStrength,remaining+(1-remaining)*.75),"Restarted acceleration preserves the same continuous half-time curve");
   }
  }
  static void Interruptions(NativeComboReport r){
   foreach(string cause in new[]{"waiting","wall","egg","empty"}){
    var f=Active(r);var w=f.world;var p=w.Player;var next=p.Cell+p.Dir;
    if(cause=="waiting")p.Waiting=true;
    if(cause=="wall"){var row=w.Grid[next.y].ToCharArray();row[next.x]='#';w.Grid[next.y]=new string(row);}
    if(cause=="egg")w.SolidEggs.Add(next);
    if(cause=="empty")w.Snakes.RemoveAll(s=>s.Body.Contains(next));
    double before=w.ComboStrength;Step(r,w);Check(r,w.ComboActive&&w.Player.Combo.SnakeCount==2&&w.ComboStrength>=before,"Movement interruption starts grace: "+cause);
    double at=w.Time,deadline=w.Player.Combo.CooldownUntil;w.Player.Waiting=true;
    for(int frame=1;frame<20;frame++){Clock(w,at+frame*49);w.AdvancePlayer();Check(r,w.ComboActive&&w.Player.Combo.CooldownUntil==deadline,"Repeated empty/stopped steps cannot renew grace: "+cause);}
    Clock(w,deadline);Check(r,!w.ComboActive&&w.Player.Combo.SnakeCount==0,"Expiry runs without another movement step: "+cause);Clock(w,deadline+1500);Check(r,Near(w.ComboStrength,0),"Interrupted boost completely expires: "+cause);
   }
   {
    var f=World();var w=f.world;Add(w,Centre+Vector2Int.right,Vector2Int.right,1);Add(w,Centre+Vector2Int.right*3,Vector2Int.right,4);
    Step(r,w);Step(r,w);Step(r,w);Check(r,!w.ComboActive&&w.Player.Combo.SnakeCount==1&&f.StartSounds==0,"Even one empty cell prevents chaining two snakes");
   }
   {
    var f=Active(r);var w=f.world;double strength=w.ComboStrength;w.BreakCombo();double ended=w.Time;w.Time+=300;double remaining=w.ComboStrength;
    // Begin a new independent two-snake chain during the old speed decay.
    w.Snakes.Clear();w.AddSnake(new[]{new Vector2Int(3,3)},Vector2Int.right,4);Add(w,w.Player.Cell+Vector2Int.right,Vector2Int.right,1);Add(w,w.Player.Cell+Vector2Int.right*2,Vector2Int.right,6);
    Step(r,w);Check(r,!w.ComboActive&&w.ComboStrength<remaining,"A first meal during decay does not restore the old combo");Step(r,w);
    Check(r,w.ComboActive&&f.StartSounds==2&&w.ComboStrength>0&&w.ComboStrength<strength,"A new second snake restarts smoothly from remaining speed, with one new cue");
   }
  }
  static void Lineage(NativeComboReport r){
   foreach(var d in NativeGameplayWorld.Dirs){
    var f=World();var w=f.world;var cross=new Vector2Int(-d.y,d.x);Position(w.Player,Centre,d);var hit=Centre+d;
    var source=Add(w,hit-cross*2,cross,5);Step(r,w);
    Check(r,!w.ComboActive&&w.Player.Combo.SnakeCount==1&&!w.Snakes.Contains(source),"Splitting first snake starts one meal: "+d);
    var children=w.Snakes.Where(s=>s.Id!=10).ToArray();Check(r,children.Length==2&&children.All(s=>s.ComboLineageId==source.ComboLineageId),"Both fragments retain source lineage: "+d);
    Step(r,w,-cross);Step(r,w,-cross);Check(r,!w.ComboActive&&w.Player.Combo.SnakeCount==1&&f.StartSounds==0,"Eating split fragment and rear head cannot falsely count as a second snake: "+d);
    Add(w,w.Player.Cell-cross,-cross,4);Step(r,w,-cross);Check(r,w.ComboActive&&w.Player.Combo.SnakeCount==2&&f.StartSounds==1,"A genuinely different snake after split continuation activates: "+d);
   }
  }
  static void Exclusions(NativeComboReport r){
   {
    var f=World();var w=f.world;
    foreach(double gap in new[]{0.0,1.0,5000.0,30000.0}){w.Time+=gap;var s=Add(w,Centre+new Vector2Int(0,5),Vector2Int.right,3);w.Player.Cell=s.Tail;w.Player.Previous=w.Player.Cell-Vector2Int.right;w.Eat(s,s.Body.Count-1);}
    Check(r,!w.ComboActive&&w.Player.Combo.SnakeCount==0&&f.StartSounds==0,"Direct fixture/passive Eat calls cannot manufacture an uninterrupted movement combo");
   }
   foreach(string excluded in new[]{"front-head","hunter","scorpion","fruit"}){
    var f=World();var w=f.world;var d=Vector2Int.right;Add(w,Centre+d,d,1);Step(r,w);var cell=w.Player.Cell+d;
    if(excluded=="front-head"){w.ActivatePower();Add(w,cell+d*3,-d,4);}
    else if(excluded=="hunter"){w.ActivatePower();w.Hunters.Add(new NativeHunter{Id=555,Cell=cell,From=cell});}
    else if(excluded=="scorpion")w.PlaceScorpion(cell+d,d);
    else w.Fruits.Add(new NativeFruit{Cell=cell,Kind=0});
    int sounds=f.StartSounds;Step(r,w);Check(r,!w.ComboActive&&w.Player.Combo.SnakeCount==0,"Nonqualifying consumption interrupts snake chain: "+excluded);
    if(excluded=="front-head")w.Snakes.RemoveAll(s=>s.Id!=10);if(excluded=="scorpion")w.Scorpion=null;
    Add(w,w.Player.Cell+d,d,5);Step(r,w);Check(r,!w.ComboActive&&w.Player.Combo.SnakeCount==1&&f.StartSounds==sounds+(excluded=="fruit"?1:0),"First snake after nonqualifying contact is not a combo: "+excluded);
   }
   {
    var f=Active(r);var w=f.world;w.Snakes.RemoveAll(s=>s.Id!=10);Add(w,w.Player.Cell+Vector2Int.right*4,Vector2Int.left,4);int score=w.Player.Score;Step(r,w);
    Check(r,w.Player.Dead&&w.Player.Score==score&&!w.ComboActive&&Near(w.ComboStrength,0),"Combo does not permit frontal head eating or prevent death");
   }
   {
    var f=Active(r);var w=f.world;w.Snakes.RemoveAll(s=>s.Id!=10);w.Hunters.Add(new NativeHunter{Id=55,Cell=w.Player.Cell+Vector2Int.right});int score=w.Player.Score;Step(r,w);
    Check(r,w.Player.Dead&&w.Hunters.Count==1&&w.Player.Score==score&&!w.ComboActive,"Combo cannot eat or survive an enemy humanoid");
   }
   {
    var f=World();var w=f.world;AddChain(w,Centre,Vector2Int.right);w.ActivateShield();for(int i=0;i<5;i++)Step(r,w);
    Check(r,w.Player.Cell==Centre+Vector2Int.right*5&&w.ComboActive&&w.Player.Combo.SnakeCount==2&&f.StartSounds==1&&w.Player.Score>0&&!w.CombatPower,"Ordinary meals chain during spawn protection without granting frontal attack power");
   }
  }
  static void PowerAndPlayers(NativeComboReport r){
   {
    var f=World();var w=f.world;AddChain(w,Centre,Vector2Int.right);w.ActivatePower();double until=w.Player.PowerUntil;for(int i=0;i<6;i++)Step(r,w);
    Check(r,w.ComboActive&&w.Power&&w.Player.PowerUntil==until&&f.StartSounds==2,"Rear-head completion still chains under real fruit Power, with independent clocks");
    Check(r,Near(w.MovementSpeedMultiplier,(1+w.PowerStrength)*(1+w.ComboStrength))&&Near(w.PlayerDelay,95/((1+w.PowerStrength)*(1+w.ComboStrength)))&&w.PlayerDelay>=23.75,"Independent Power and combo speed ramps multiply, bounded by four times ordinary speed");
    w.BreakCombo();Check(r,w.Power&&w.CombatPower&&w.Player.PowerUntil==until,"Breaking combo never cancels real fruit Power");
   }
   foreach(int mode in new[]{0,1,2,3,4,5})foreach(int tier in new[]{0,1,2,3,4}){
    var f=World(mode,tier);var w=f.world;
    for(int i=0;i<w.PlayerCount;i++){var p=w.GetPlayer(i);using(w.ForPlayer(p)){AddChain(w,p.Cell,Vector2Int.right);for(int step=0;step<5;step++)Step(r,w);Check(r,w.ComboActive&&p.Combo.SnakeCount==2,$"Shared actual eating path activates for mode={mode}, tier={tier}, player={i}, AI={p.IsAI}");}for(int later=i+1;later<w.PlayerCount;later++)Check(r,!w.GetPlayer(later).Combo.Active&&w.GetPlayer(later).Combo.SnakeCount==0,"A player's chain cannot activate another participant");}
    if(w.PlayerCount>1){using(w.ForPlayer(w.GetPlayer(0)))w.BreakCombo();Check(r,!w.GetPlayer(0).Combo.Active&&w.GetPlayer(1).Combo.Active,"Breaking one participant's combo leaves another's active");}
   }
   {
    var f=World(2);var w=f.world;Add(w,Centre+Vector2Int.right,Vector2Int.right,1);Step(r,w);var rival=w.GetPlayer(1);Position(rival,w.Player.Cell+Vector2Int.right,Vector2Int.left);w.Player.Score=100;rival.Score=0;Step(r,w);
    Check(r,rival.Dead&&!w.ComboActive&&w.Player.Combo.SnakeCount==0&&f.StartSounds==0,"Competitive player eating cannot start or continue a snake combo");
   }
   {
    var f=World();var w=f.world;w.UseLegacyAi=true;AddChain(w,Centre,Vector2Int.right);for(int i=0;i<8;i++)Step(r,w);Check(r,!w.ComboActive&&Near(w.PlayerDelay,95)&&f.StartSounds==0,"Explicit frozen historical oracle retains original movement speed");
   }
  }
  static void MultipliedMeals(NativeComboReport r){
   foreach(var d in NativeGameplayWorld.Dirs)foreach(bool ai in new[]{false,true}){
    var f=World(ai?0:1);var w=f.world;Position(w.Player,Centre,d);string label=$"direction={d}, AI={ai}";
    for(int snake=0;snake<4;snake++)Add(w,Centre+d*(snake*2+1),d,2,snake);
    int expectedScore=0;
    for(int snake=0;snake<4;snake++){
     int factor=1<<snake;Step(r,w);expectedScore+=25*factor;
     Check(r,w.Player.Score==expectedScore&&Near(w.Player.ExactScore,expectedScore),$"The first tail bite of snake {snake+1} immediately awards {factor} times points: {label}");
     Check(r,w.Player.Combo.MultiplierExponent==snake&&Near(w.Player.Combo.ScoreMultiplier,factor)&&f.StartSounds==snake,$"HUD multiplier and one sound per new snake agree at snake {snake+1}: {label}");
     double upgrade=w.Player.Combo.LastUpgradeAt;
     Check(r,snake==0?double.IsNegativeInfinity(upgrade):Near(upgrade,w.Time),$"Only a genuine multiplier upgrade starts the HUD clock: snake {snake+1}, {label}");
     Step(r,w);expectedScore+=125*factor;
     Check(r,w.Player.Score==expectedScore&&Near(w.Player.ExactScore,expectedScore)&&w.Player.Combo.LastUpgradeAt==upgrade&&f.StartSounds==snake,$"Safe rear-head completion retains its snake multiplier without a duplicate cue: snake {snake+1}, {label}");
    }
    Check(r,w.Player.Score==2250&&w.ComboActive&&!w.Power&&!w.CombatPower,"Four actual two-segment meals score 2250 without granting Power: "+label);
    Step(r,w);double ends=w.Player.Combo.CooldownUntil;Check(r,w.ComboActive&&w.Player.Combo.MultiplierExponent==3&&Near(w.Player.Combo.ScoreMultiplier,8)&&w.ComboStrength>0,"The first empty step retains score/HUD during grace: "+label);Clock(w,ends);Check(r,!w.ComboActive&&w.Player.Combo.MultiplierExponent==0&&Near(w.Player.Combo.ScoreMultiplier,1),"Grace expiry resets score/HUD while speed begins decay: "+label);
   }
   foreach(var d in NativeGameplayWorld.Dirs){
    var f=World();var w=f.world;var cross=new Vector2Int(-d.y,d.x);Position(w.Player,Centre,d);
    Add(w,Centre+d,d,1);Step(r,w);int score=w.Player.Score;
    var cut=Add(w,w.Player.Cell+d-cross*2,cross,5);Step(r,w);
    Check(r,w.Player.Score-score==20&&w.Player.Combo.MultiplierExponent==1&&f.StartSounds==1,"Second-snake transverse cut gets x2 on the cut itself: "+d);
    double upgrade=w.Player.Combo.LastUpgradeAt;int lineage=cut.ComboLineageId;score=w.Player.Score;
    Step(r,w,-cross);Step(r,w,-cross);
    Check(r,w.Player.Score-score==300&&w.Player.Combo.SnakeCount==2&&w.Player.Combo.MultiplierExponent==1&&w.Player.Combo.LastUpgradeAt==upgrade&&f.StartSounds==1,"Following a split descendant keeps x2 and cannot farm multiplier or sounds: "+d);
    Check(r,w.Snakes.Any(s=>s.ComboLineageId==lineage),"The other split descendant remains present for lineage coverage: "+d);
    Add(w,w.Player.Cell-cross,-cross,2);score=w.Player.Score;Step(r,w,-cross);
    Check(r,w.Player.Score-score==100&&w.Player.Combo.MultiplierExponent==2&&f.StartSounds==2,"Only a distinct third lineage upgrades the next tail to x4: "+d);
   }
   {
    var f=World();var w=f.world;w.Difficulty=.35;w.ScoreSpeed=1.25;
    for(int i=1;i<=4;i++)Add(w,Centre+Vector2Int.right*i,Vector2Int.right,1);
    double exact=0;for(int i=0;i<4;i++){Step(r,w);exact+=125*(1<<i)*.35*1.25;Check(r,Near(w.Player.ExactScore,exact)&&w.Player.Score==(int)(Math.Floor(exact/5)*5),"Combo applies before existing difficulty/speed scaling and retains fractional score: snake "+(i+1));}
   }
  }
  static void MixedAwards(NativeComboReport r){
   {
    var f=World();var w=f.world;var d=Vector2Int.right;Add(w,Centre+d,d,1);Add(w,Centre+d*2,d,1);Add(w,Centre+d*3,d,2);
    w.Fruits.Add(new NativeFruit{Cell=Centre+d*2,Kind=1});w.Fruits.Add(new NativeFruit{Cell=Centre+d*3,Kind=3});
    Step(r,w);int before=w.Player.Score;Step(r,w);
    Check(r,w.Player.Score-before==350&&w.ComboActive&&w.Player.Combo.ScoreMultiplier==2&&w.Power&&f.StartSounds==2,"Fruit under second rear head gives normal 100 points plus x2 head, with separate Power and combo cues");
    before=w.Player.Score;Step(r,w);
    Check(r,w.Player.Score-before==300&&w.Player.Combo.ScoreMultiplier==4&&w.Power&&f.StartSounds==4,"Fruit under third tail gives normal 200 points plus x4 tail, preserving both effects");
    before=w.Player.Score;Step(r,w);
    Check(r,w.Player.Score-before==500&&w.Player.Combo.ScoreMultiplier==4&&f.StartSounds==4,"Real Power rear-head completion keeps x4 without another multiplier cue");
   }
   foreach(string kind in new[]{"front-head","hunter","scorpion","fruit"}){
    var f=Active(r);var w=f.world;var d=Vector2Int.right;w.Snakes.RemoveAll(s=>s.Id!=10);var cell=w.Player.Cell+d;int expected;
    if(kind=="front-head"){w.ActivatePower();Add(w,cell+d*3,-d,4);expected=125;}
    else if(kind=="hunter"){w.ActivatePower();w.Hunters.Add(new NativeHunter{Id=555,Cell=cell,From=cell});expected=200;}
    else if(kind=="scorpion"){w.PlaceScorpion(cell+d,d);expected=150;}
    else{w.Fruits.Add(new NativeFruit{Cell=cell,Kind=2});expected=150;}
    int before=w.Player.Score;Step(r,w);
    bool grace=kind=="scorpion"||kind=="fruit";Check(r,w.Player.Score-before==expected&&w.ComboActive==grace&&Near(w.Player.Combo.ScoreMultiplier,grace?2:1),"Non-snake award stays unmultiplied; fruit retains grace and scorpion refreshes it: "+kind);
   }
   {
    var f=Active(r,2);var w=f.world;w.Snakes.RemoveAll(s=>s.Id!=10);var rival=w.GetPlayer(1);Position(rival,w.Player.Cell+Vector2Int.right,Vector2Int.left);rival.Score=0;int before=w.Player.Score;
    Step(r,w);Check(r,rival.Dead&&w.Player.Score-before==1000&&!w.ComboActive,"Competitive rival award is 1000 even after x2 snake combo");
   }
   {
    var f=Active(r);var w=f.world;w.Snakes.Clear();int before=w.Player.Score;w.LevelLoader=new NativeMazeGenerator(107,1).Generate;w.AdvanceLevel();
    Check(r,w.Player.Score-before==500&&Near(w.Player.Combo.ScoreMultiplier,1),"Next-level completion bonus stays 500 and begins a fresh multiplier");
   }
   {
    var f=World();var w=f.world;Add(w,Centre+Vector2Int.right,Vector2Int.right,1);Add(w,Centre+Vector2Int.right*2,Vector2Int.right,2);w.Snakes.RemoveAll(s=>s.Id==10);
    Step(r,w);Step(r,w);int before=w.Player.Score;Step(r,w);
    Check(r,w.Transition&&w.Player.Score-before==250&&Near(w.Player.Combo.ScoreMultiplier,1),"Final rear head receives x2 before LEVEL CLEARED resets combo state");
   }
  }
  static void ProductTimingAndForecast(NativeComboReport r){
   var own=typeof(NativeAllyBrain).GetMethod("PredictPlayerDelay",BindingFlags.Static|BindingFlags.NonPublic);
   var rival=typeof(NativeAllyThreatForecast).GetMethod("PlayerPeriod",BindingFlags.Static|BindingFlags.NonPublic);
   Check(r,own!=null&&rival!=null,"Both tactical and rival movement forecasts are available for clock parity");if(own==null||rival==null)return;
   foreach(double fruitOffset in new[]{-4000.0,-700.0,0.0}){
    var f=Active(r);var w=f.world;double start=w.Time;w.Time=start+fruitOffset;w.ActivatePower();w.Time=start;
    foreach(double age in new[]{0.0,100.0,250.0,500.0,1000.0,2000.0,3000.0,4500.0,6500.0,8000.0}){
     w.Time=start+age;double speed=(1+w.PowerStrength)*(1+w.ComboStrength);double actual=w.PlayerDelay;
     Check(r,Near(actual,95/speed)&&actual>=23.75&&actual<=95,"Actual product speed keeps independent fruit/combo clocks, offset="+fruitOffset+", age="+age);
     double a=(double)own.Invoke(null,new object[]{w.Player,w.Time,double.PositiveInfinity});double b=(double)rival.Invoke(null,new object[]{w.Player,w.Time});
     Check(r,Near(a,actual)&&Near(b,actual),"Both AI forecasts match live combined speed exactly, offset="+fruitOffset+", age="+age);
    }
   }
   {
    var f=Active(r);var w=f.world;w.ActivatePower();w.Time+=1200;Check(r,Near(w.PlayerDelay,23.75)&&Near(w.MovementSpeedMultiplier,4),"Full fruit and full combo reach four times ordinary speed");
    double at=w.Time;var forecastPlayer=new NativePlayer{PowerUntil=w.Player.PowerUntil,RampAt=w.Player.RampAt,RampDuration=w.Player.RampDuration,RampFrom=w.Player.RampFrom};forecastPlayer.Combo.CopyMotionFrom(w.Player.Combo);
    w.PauseComboFeeding();Check(r,w.ComboActive&&Near(w.PlayerDelay,23.75)&&w.Power,"Beginning grace preserves exact product speed at the boundary");
    foreach(double age in new[]{1.0,250.0,999.0,1000.0,1499.0,1500.0,2499.0,2500.0,4500.0,6000.0}){
     Clock(w,at+age);double forecast=(double)own.Invoke(null,new object[]{forecastPlayer,w.Time,at});
     Check(r,Near(forecast,w.PlayerDelay),"Hypothetical combo break forecast equals real independent deceleration at "+age+"ms");
    }
    Clock(w,at+2500);Check(r,Near(w.ComboStrength,0)&&Near(w.PlayerDelay,47.5)&&w.Power,"Combo grace plus deceleration ends while fruit stays at double speed");
   }
   {
    var f=Active(r);var w=f.world;w.ActivatePower();double at=w.Time,delay=w.PlayerDelay,upgrade=w.Player.Combo.LastUpgradeAt;int score=w.Player.Score,sounds=f.StartSounds;
    // Pause advances presentation time, not the simulation clock.
    for(int frame=0;frame<600;frame++){w.RealTime+=16.6666667;var read=w.Player.Combo.ScoreMultiplier+w.PlayerDelay+w.ComboStrength;}
    Check(r,w.Time==at&&Near(w.PlayerDelay,delay)&&w.Player.Score==score&&f.StartSounds==sounds&&w.Player.Combo.LastUpgradeAt==upgrade,"Paused presentation/getter sampling neither spends feeding clocks nor scores or replays the cue");
    Step(r,w);Check(r,w.ComboActive&&w.Player.Combo.MultiplierExponent==1&&f.StartSounds==sounds,"Resuming actual snake eating preserves the chain without duplicate upgrade");
   }
   {
    var f=World(4);var w=f.world;
    for(int slot=0;slot<3;slot++)using(w.ForPlayer(w.GetPlayer(slot))){for(int n=1;n<=slot+2;n++)Add(w,w.Player.Cell+Vector2Int.right*n,Vector2Int.right,1);for(int n=0;n<slot+2;n++)Step(r,w);}
    Check(r,w.GetPlayer(0).Combo.ScoreMultiplier==2&&w.GetPlayer(1).Combo.ScoreMultiplier==4&&w.GetPlayer(2).Combo.ScoreMultiplier==8,"Three simultaneous participants independently retain x2, x4 and x8");
    Check(r,w.GetPlayer(0).Score==375&&w.GetPlayer(1).Score==875&&w.GetPlayer(2).Score==1875,"Different participant multipliers never leak into another participant's scoring");
    using(w.ForPlayer(w.GetPlayer(1)))w.BreakCombo();Check(r,w.GetPlayer(0).Combo.ScoreMultiplier==2&&w.GetPlayer(1).Combo.ScoreMultiplier==1&&w.GetPlayer(2).Combo.ScoreMultiplier==8,"Only the interrupted participant loses its score multiplier");
   }
  }
  static void ScoreLimits(NativeComboReport r){
   {
    var f=World();var w=f.world;var p=w.Player;p.Score=4990;p.ExactScore=4990;p.Lives=3;p.NextLifeScore=5000;
    w.Award(25);Check(r,p.Score==5015&&p.ExactScore==5015&&p.Lives==4&&p.ExtraLives==1&&p.NextLifeScore==10000,"Ordinary award retains existing exact bonus-life threshold behavior");
    p.Score=9990;p.ExactScore=9990;p.Lives=9;w.Award(25);Check(r,p.Score==10015&&p.Lives==9&&p.ExtraLives==1&&p.NextLifeScore==15000,"Awards at full lives discard only crossed bonus thresholds");
    p.Lives=8;w.Award(25);Check(r,p.Lives==8&&p.NextLifeScore==15000,"A later lost life cannot claim an old discarded threshold");
    w.Award(5000);Check(r,p.Lives==9&&p.ExtraLives==2&&p.NextLifeScore==20000,"The next new threshold grants precisely one additional life");
   }
   {
    var f=World();var w=f.world;var p=w.Player;for(int snake=1;snake<=36;snake++)Add(w,Centre+Vector2Int.right*snake,Vector2Int.right,1);
    for(int snake=1;snake<=36;snake++)Step(r,w);
    Check(r,p.Score==2147483645&&p.ExactScore==2147483645&&p.Lives==9&&p.ExtraLives==6&&p.NextLifeScore==int.MaxValue,"A long actual doubled chain saturates signed-int score safely and grants at most the available six lives");
    Check(r,p.Combo.MultiplierExponent==35&&p.Combo.ScoreMultiplier==34359738368.0&&f.StartSounds==35,"Score saturation does not corrupt distinct-snake count, multiplier display or upgrade sounds");
    int bonusSounds=f.events.Count(e=>e.Kind=="sound"&&e.Sound=="BonusLife@");p.Lives=8;w.Award(int.MaxValue);
    Check(r,p.Score==2147483645&&p.ExactScore==2147483645&&p.Lives==8&&p.NextLifeScore==int.MaxValue&&f.events.Count(e=>e.Kind=="sound"&&e.Sound=="BonusLife@")==bonusSounds,"Repeated awards at the score ceiling do not overflow or manufacture bonus lives");
   }
  }
  static void Lifecycle(NativeComboReport r){
   {
    var f=Active(r);var w=f.world;w.SessionDeath();Check(r,w.Player.Dead&&!w.ComboActive&&Near(w.ComboStrength,0),"Actual SessionDeath clears acceleration and chain");
    w.Snakes.Clear();w.Time=w.Player.RespawnAt;w.UpdateDeath();Check(r,!w.Player.Dead&&!w.ComboActive&&Near(w.ComboStrength,0)&&w.Player.Combo.SnakeCount==0&&w.Player.ShieldUntil>w.Time,"Respawn starts with clean combo and ordinary defensive shield");
   }
   {
    var f=Active(r);var w=f.world;var generator=new NativeMazeGenerator(107,1);w.LevelLoader=generator.Generate;w.AdvanceLevel();
    Check(r,w.Level==2&&!w.ComboActive&&Near(w.ComboStrength,0)&&w.Player.Combo.SnakeCount==0,"Actual next-level installation never carries combo speed");
   }
   {
    var f=Active(r);var w=f.world;w.Snakes.Clear();w.CheckLevelComplete();Check(r,w.Transition&&!w.ComboActive&&Near(w.ComboStrength,0),"LEVEL CLEARED removes stale combo immediately");
   }
   foreach(double speed in NativeMenuState.Speeds){
    var f=World();var w=f.world;w.ScoreSpeed=speed;AddChain(w,Centre,Vector2Int.right);double real=0;for(int i=0;i<5;i++){double delta=w.PlayerDelay+.01;real+=delta/speed;Step(r,w);}Check(r,w.ComboActive&&Near((w.Time-1000)/speed,real),"Every configured game speed uses the existing shared simulation clock: "+speed);
   }
  }
  public static NativeComboReport Run(){var clock=Stopwatch.StartNew();var r=new NativeComboReport();Group(r,"continuous real movement",()=>Continuous(r));Group(r,"continuous early breaks",()=>EarlyBreaks(r));Group(r,"interruptions",()=>Interruptions(r));Group(r,"fragment lineage",()=>Lineage(r));Group(r,"nonqualifying contacts",()=>Exclusions(r));Group(r,"power and participants",()=>PowerAndPlayers(r));Group(r,"multiplied real meals",()=>MultipliedMeals(r));Group(r,"mixed contact awards",()=>MixedAwards(r));Group(r,"product timing and forecast",()=>ProductTimingAndForecast(r));Group(r,"cooldown and uninterrupted multipliers",()=>CooldownRules(r));Group(r,"score saturation",()=>ScoreLimits(r));Group(r,"lifecycle",()=>Lifecycle(r));r.elapsedMs=clock.Elapsed.TotalMilliseconds;r.passed=r.failures==0;return r;}
 }
}
#endif

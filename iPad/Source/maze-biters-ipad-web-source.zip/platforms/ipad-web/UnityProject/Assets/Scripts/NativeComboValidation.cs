#if UNITY_EDITOR
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using UnityEngine;
namespace MazeBiters.NativeStudy {
 [Serializable] public sealed class NativeComboReport {
  public bool passed;public int assertions,failures,movementSteps;public double elapsedMs;
  public string scope="Deterministic iPad gameplay contacts, four directions, human/AI actors, real movement and lifecycle. Simulation tests; no device-performance claim.";
  public List<NativeDifficultyCheck> checks=new List<NativeDifficultyCheck>();
 }
 public static class NativeComboValidation {
  static readonly Vector2Int Centre=new Vector2Int(48,48);
  sealed class Fixture {
   public NativeGameplayWorld world;public readonly List<NativeWorldEvent> events=new List<NativeWorldEvent>();
   public int StartSounds=>events.Count(e=>e.Kind=="sound"&&e.Sound=="snakeSTART@");
  }
  static Fixture World(int mode=1,int tier=2){
   var rows=Enumerable.Range(0,96).Select(y=>y==0||y==95?new string('#',96):"#"+new string('.',94)+"#").ToArray();
   var f=new Fixture{world=new NativeGameplayWorld(rows,NativeMazeGenerator.Rng(419)){Time=1000,LevelStarted=1000,Assist=false,SessionEnabled=true,AiDifficulty=tier,Difficulty=1}};var w=f.world;w.SetMode(mode);w.Event=e=>f.events.Add(e);
   for(int i=0;i<w.PlayerCount;i++){var p=w.GetPlayer(i);Position(p,Centre+new Vector2Int(0,i*12),Vector2Int.right);p.ShieldUntil=0;}
   w.PlayerStart=Centre;w.StartDirection=Vector2Int.right;
   // Keep normal CheckLevelComplete active without ending the synthetic chain.
   w.AddSnake(new[]{new Vector2Int(3,3)},Vector2Int.right,4);
   return f;
  }
  static void Position(NativePlayer p,Vector2Int at,Vector2Int dir){p.Cell=p.From=p.Previous=at;p.Dir=p.Next=dir;p.Waiting=false;p.Pointer=null;p.PointerMomentum=false;p.Keys.Clear();p.Ricochet=null;}
  static NativeGameplaySnake Add(NativeGameplayWorld w,Vector2Int tail,Vector2Int dir,int length,int palette=0)=>w.AddSnake(Enumerable.Range(0,length).Select(i=>tail+dir*(length-1-i)),dir,palette);
  static void Check(NativeComboReport r,bool ok,string name){r.assertions++;if(!ok)r.failures++;r.checks.Add(new NativeDifficultyCheck{name=name,passed=ok});}
  static bool Near(double a,double b,double tolerance=1e-8)=>Math.Abs(a-b)<=tolerance;
  static void Group(NativeComboReport r,string name,Action action){try{action();}catch(Exception e){r.assertions++;r.failures++;r.checks.Add(new NativeDifficultyCheck{name=name,passed=false,detail=e.ToString()});}}
  static void Step(NativeComboReport r,NativeGameplayWorld w,Vector2Int? dir=null){if(dir.HasValue)w.Player.Next=dir.Value;w.Time+=w.PlayerDelay+.01;w.AdvancePlayer();w.Player.LastMove=w.Time;r.movementSteps++;}
  static void AddChain(NativeGameplayWorld w,Vector2Int origin,Vector2Int dir){Add(w,origin+dir,dir,3);Add(w,origin+dir*4,dir,24,1);Add(w,origin+dir*28,dir,8,2);}
  static Fixture Active(NativeComboReport r,int mode=1,int slot=0,int tier=2){var f=World(mode,tier);var w=f.world;var p=w.GetPlayer(slot);using(w.ForPlayer(p)){AddChain(w,p.Cell,Vector2Int.right);for(int i=0;i<5;i++)Step(r,w);}return f;}

  static void Continuous(NativeComboReport r){
   foreach(var d in NativeGameplayWorld.Dirs)foreach(bool ai in new[]{false,true}){
    var f=World(ai?0:1);var w=f.world;Position(w.Player,Centre,d);AddChain(w,Centre,d);string label=$"direction={d}, AI={ai}";
    for(int i=1;i<=3;i++){Step(r,w);Check(r,!w.ComboActive&&Near(w.PlayerDelay,95)&&w.Player.Combo.SnakeCount==1,$"First snake never accelerates, including rear head {i}: {label}");}
    Check(r,f.StartSounds==0,"No Power sound for first snake: "+label);
    Step(r,w);double activated=w.Time;
    Check(r,w.ComboActive&&w.Player.Combo.SnakeCount==2&&f.StartSounds==1,"Second distinct snake starts combo exactly once: "+label);
    Check(r,!w.Power&&!w.CombatPower&&!w.PlayerProtected(w.Player,w.Time)&&!w.Player.PowerBright&&w.Player.PowerUntil==0,"Combo grants speed only, no attack/protection/Power flash: "+label);
    Check(r,Near(w.ComboStrength,0),"Acceleration begins continuously at the first second-snake bite: "+label);
    double previous=0;
    for(int i=5;i<=27;i++){Step(r,w);double u=Math.Min(1,(w.Time-activated)/500),expected=1-(1-u)*(1-u);Check(r,w.ComboActive&&w.ComboStrength>=previous&&Near(w.ComboStrength,expected)&&w.PlayerDelay>=47.5&&w.PlayerDelay<=95,"Continuous half-time speed ramp while eating second snake, step "+i+": "+label);previous=w.ComboStrength;}
    Check(r,Near(w.ComboStrength,1)&&Near(w.PlayerDelay,47.5),"Long uninterrupted eating reaches normal Power maximum: "+label);
    Step(r,w);Check(r,w.ComboActive&&w.Player.Combo.SnakeCount==3&&f.StartSounds==1,"Third snake continues existing combo without retrigger: "+label);
    for(int i=29;i<=35;i++)Step(r,w);
    Check(r,w.ComboActive&&f.StartSounds==1,"Final rear head remains part of uninterrupted meal: "+label);
    Step(r,w);double ended=w.Time,strength=w.ComboStrength;
    Check(r,!w.ComboActive&&w.Player.Combo.SnakeCount==0&&Near(strength,1),"First empty movement step breaks chain and begins continuous deceleration: "+label);
    foreach(double age in new[]{1.0,100.0,500.0,750.0,1499.0,1500.0,8000.0}){w.Time=ended+age;double u=Math.Min(1,age/1500);Check(r,Near(w.ComboStrength,strength*(1-u*u)),"Half-time decay has no hold or stale boost at "+age+"ms: "+label);}
    Check(r,Near(w.PlayerDelay,95)&&w.Player.Combo.SnakeCount==0&&f.StartSounds==1,"Normal speed restored after combo: "+label);
   }
  }
  static void EarlyBreaks(NativeComboReport r){
   // Break at precise elapsed times, including one millisecond before full
   // capacity. This catches hidden plateaus, forced tiers and resets to full.
   foreach(double age in new[]{100.0,250.0,499.0,500.0,1000.0}){
    var f=World();var w=f.world;AddChain(w,Centre,Vector2Int.right);for(int i=0;i<4;i++)Step(r,w);double activated=w.Time;w.Time=activated+age;
    double u=Math.Min(1,age/500),attained=1-(1-u)*(1-u);Check(r,Near(w.ComboStrength,attained),"Continuous acceleration reaches its actual value at "+age+"ms");
    w.Player.Waiting=true;w.AdvancePlayer();r.movementSteps++;
    Check(r,!w.ComboActive&&Near(w.ComboStrength,attained)&&f.StartSounds==1,"Early interruption preserves exact speed and starts decay at "+age+"ms");
    double stopped=w.Time;
    foreach(double fallAge in new[]{1.0,250.0,750.0,1499.0,1500.0}){w.Time=stopped+fallAge;double down=Math.Min(1,fallAge/1500);Check(r,Near(w.ComboStrength,attained*(1-down*down)),"Early-break decay starts from attained speed, rise="+age+"ms, fall="+fallAge+"ms");}
   }
   foreach(int bodyBites in new[]{1,2,3}){
    var f=World();var w=f.world;Add(w,Centre+Vector2Int.right,Vector2Int.right,1);Add(w,Centre+Vector2Int.right*2,Vector2Int.right,8);Step(r,w);Step(r,w);double activated=w.Time;
    for(int i=1;i<bodyBites;i++)Step(r,w);
    Step(r,w,Vector2Int.down);double stopped=w.Time,u=Math.Min(1,(stopped-activated)/500),attained=1-(1-u)*(1-u);
    Check(r,!w.ComboActive&&Near(w.ComboStrength,attained)&&attained>0&&attained<1,"A short meal decelerates immediately from naturally attained speed, body bites="+bodyBites);
    w.Time=stopped+1500;Check(r,Near(w.ComboStrength,0)&&Near(w.PlayerDelay,95)&&f.StartSounds==1,"Short meal has no lingering boost, body bites="+bodyBites);
   }
   {
    var f=World();var w=f.world;AddChain(w,Centre,Vector2Int.right);for(int i=0;i<20;i++)Step(r,w);Check(r,Near(w.ComboStrength,1),"Restart fixture reached full speed");w.BreakCombo();double stopped=w.Time;w.Time+=100;
    w.Snakes.Clear();w.AddSnake(new[]{new Vector2Int(3,3)},Vector2Int.right,4);Add(w,w.Player.Cell+Vector2Int.right,Vector2Int.right,1);Add(w,w.Player.Cell+Vector2Int.right*2,Vector2Int.right,8);
    Step(r,w);double at=w.Time+w.PlayerDelay+.01,u=(at-stopped)/1500,remaining=1-u*u;Step(r,w);double restarted=w.Time;
    Check(r,w.ComboActive&&Near(w.ComboStrength,remaining)&&remaining>0&&remaining<1&&f.StartSounds==2,"New chain during decay restarts continuously from its exact residual speed");
    w.Time=restarted+250;Check(r,Near(w.ComboStrength,remaining+(1-remaining)*.75),"Restarted acceleration preserves the same continuous half-time curve");
   }
  }
  static void Interruptions(NativeComboReport r){
   foreach(string cause in new[]{"waiting","wall","egg","empty"}){
    var f=Active(r);var w=f.world;var p=w.Player;var next=p.Cell+p.Dir;
    if(cause=="waiting")p.Waiting=true;
    if(cause=="wall"){var row=w.Grid[next.y].ToCharArray();row[next.x]='#';w.Grid[next.y]=new string(row);}
    if(cause=="egg")w.SolidEggs.Add(next);
    if(cause=="empty")w.Snakes.RemoveAll(s=>s.Body.Contains(next));
    double before=w.ComboStrength;Step(r,w);Check(r,!w.ComboActive&&w.Player.Combo.SnakeCount==0&&w.ComboStrength>=before,"Actual movement interruption starts decay: "+cause);
    double at=w.Time,value=w.ComboStrength;w.Time+=.1;Check(r,w.ComboStrength<value,"Deceleration starts immediately without grace period: "+cause);w.Time=at+1500;Check(r,Near(w.ComboStrength,0),"Interrupted boost completely expires: "+cause);
   }
   {
    var f=World();var w=f.world;Add(w,Centre+Vector2Int.right,Vector2Int.right,1);Add(w,Centre+Vector2Int.right*3,Vector2Int.right,4);
    Step(r,w);Step(r,w);Step(r,w);Check(r,!w.ComboActive&&w.Player.Combo.SnakeCount==1&&f.StartSounds==0,"Even one empty cell prevents chaining two snakes");
   }
   {
    var f=Active(r);var w=f.world;double strength=w.ComboStrength;w.BreakCombo();double ended=w.Time;w.Time+=300;double remaining=w.ComboStrength;
    // Begin a new independent two-snake chain during the old speed decay.
    w.Snakes.Clear();w.AddSnake(new[]{new Vector2Int(3,3)},Vector2Int.right,4);Add(w,w.Player.Cell+Vector2Int.right,Vector2Int.right,1);Add(w,w.Player.Cell+Vector2Int.right*2,Vector2Int.right,6);
    Step(r,w);Check(r,!w.ComboActive&&w.ComboStrength<remaining,"A first meal during decay does not restore the old combo");Step(r,w);
    Check(r,w.ComboActive&&f.StartSounds==2&&w.ComboStrength>0&&w.ComboStrength<strength,"A new second snake restarts smoothly from remaining speed, with one new cue");
   }
  }
  static void Lineage(NativeComboReport r){
   foreach(var d in NativeGameplayWorld.Dirs){
    var f=World();var w=f.world;var cross=new Vector2Int(-d.y,d.x);Position(w.Player,Centre,d);var hit=Centre+d;
    var source=Add(w,hit-cross*2,cross,5);Step(r,w);
    Check(r,!w.ComboActive&&w.Player.Combo.SnakeCount==1&&!w.Snakes.Contains(source),"Splitting first snake starts one meal: "+d);
    var children=w.Snakes.Where(s=>s.Id!=10).ToArray();Check(r,children.Length==2&&children.All(s=>s.ComboLineageId==source.ComboLineageId),"Both fragments retain source lineage: "+d);
    Step(r,w,-cross);Step(r,w,-cross);Check(r,!w.ComboActive&&w.Player.Combo.SnakeCount==1&&f.StartSounds==0,"Eating split fragment and rear head cannot falsely count as a second snake: "+d);
    Add(w,w.Player.Cell-cross,-cross,4);Step(r,w,-cross);Check(r,w.ComboActive&&w.Player.Combo.SnakeCount==2&&f.StartSounds==1,"A genuinely different snake after split continuation activates: "+d);
   }
  }
  static void Exclusions(NativeComboReport r){
   {
    var f=World();var w=f.world;
    foreach(double gap in new[]{0.0,1.0,5000.0,30000.0}){w.Time+=gap;var s=Add(w,Centre+new Vector2Int(0,5),Vector2Int.right,3);w.Player.Cell=s.Tail;w.Player.Previous=w.Player.Cell-Vector2Int.right;w.Eat(s,s.Body.Count-1);}
    Check(r,!w.ComboActive&&w.Player.Combo.SnakeCount==0&&f.StartSounds==0,"Direct fixture/passive Eat calls cannot manufacture an uninterrupted movement combo");
   }
   foreach(string excluded in new[]{"front-head","hunter","scorpion","fruit"}){
    var f=World();var w=f.world;var d=Vector2Int.right;Add(w,Centre+d,d,1);Step(r,w);var cell=w.Player.Cell+d;
    if(excluded=="front-head"){w.ActivatePower();Add(w,cell+d*3,-d,4);}
    else if(excluded=="hunter"){w.ActivatePower();w.Hunters.Add(new NativeHunter{Id=555,Cell=cell,From=cell});}
    else if(excluded=="scorpion")w.PlaceScorpion(cell+d,d);
    else w.Fruits.Add(new NativeFruit{Cell=cell,Kind=0});
    int sounds=f.StartSounds;Step(r,w);Check(r,!w.ComboActive&&w.Player.Combo.SnakeCount==0,"Nonqualifying consumption interrupts snake chain: "+excluded);
    if(excluded=="front-head")w.Snakes.RemoveAll(s=>s.Id!=10);if(excluded=="scorpion")w.Scorpion=null;
    Add(w,w.Player.Cell+d,d,5);Step(r,w);Check(r,!w.ComboActive&&w.Player.Combo.SnakeCount==1&&f.StartSounds==sounds+(excluded=="fruit"?1:0),"First snake after nonqualifying contact is not a combo: "+excluded);
   }
   {
    var f=Active(r);var w=f.world;w.Snakes.RemoveAll(s=>s.Id!=10);Add(w,w.Player.Cell+Vector2Int.right*4,Vector2Int.left,4);int score=w.Player.Score;Step(r,w);
    Check(r,w.Player.Dead&&w.Player.Score==score&&!w.ComboActive&&Near(w.ComboStrength,0),"Combo does not permit frontal head eating or prevent death");
   }
   {
    var f=Active(r);var w=f.world;w.Snakes.RemoveAll(s=>s.Id!=10);w.Hunters.Add(new NativeHunter{Id=55,Cell=w.Player.Cell+Vector2Int.right});int score=w.Player.Score;Step(r,w);
    Check(r,w.Player.Dead&&w.Hunters.Count==1&&w.Player.Score==score&&!w.ComboActive,"Combo cannot eat or survive an enemy humanoid");
   }
   {
    var f=World();var w=f.world;AddChain(w,Centre,Vector2Int.right);w.ActivateShield();for(int i=0;i<5;i++)Step(r,w);
    Check(r,w.Player.Cell==Centre&&!w.ComboActive&&w.Player.Combo.SnakeCount==0&&f.StartSounds==0&&w.Player.Score==0,"Defensive spawn shield cannot manufacture a combo through blocked food");
   }
  }
  static void PowerAndPlayers(NativeComboReport r){
   {
    var f=World();var w=f.world;AddChain(w,Centre,Vector2Int.right);w.ActivatePower();double until=w.Player.PowerUntil;for(int i=0;i<6;i++)Step(r,w);
    Check(r,w.ComboActive&&w.Power&&w.Player.PowerUntil==until&&f.StartSounds==2,"Rear-head completion still chains under real fruit Power, with independent clocks");
    Check(r,Near(w.MovementStrength,Math.Max(w.PowerStrength,w.ComboStrength))&&w.PlayerDelay>=47.5,"Power and combo choose greater speed, never stack");
    w.BreakCombo();Check(r,w.Power&&w.CombatPower&&w.Player.PowerUntil==until,"Breaking combo never cancels real fruit Power");
   }
   foreach(int mode in new[]{0,1,2,3,4,5})foreach(int tier in new[]{0,1,2,3,4}){
    var f=World(mode,tier);var w=f.world;
    for(int i=0;i<w.PlayerCount;i++){var p=w.GetPlayer(i);using(w.ForPlayer(p)){AddChain(w,p.Cell,Vector2Int.right);for(int step=0;step<5;step++)Step(r,w);Check(r,w.ComboActive&&p.Combo.SnakeCount==2,$"Shared actual eating path activates for mode={mode}, tier={tier}, player={i}, AI={p.IsAI}");}for(int later=i+1;later<w.PlayerCount;later++)Check(r,!w.GetPlayer(later).Combo.Active&&w.GetPlayer(later).Combo.SnakeCount==0,"A player's chain cannot activate another participant");}
    if(w.PlayerCount>1){using(w.ForPlayer(w.GetPlayer(0)))w.BreakCombo();Check(r,!w.GetPlayer(0).Combo.Active&&w.GetPlayer(1).Combo.Active,"Breaking one participant's combo leaves another's active");}
   }
   {
    var f=World(2);var w=f.world;Add(w,Centre+Vector2Int.right,Vector2Int.right,1);Step(r,w);var rival=w.GetPlayer(1);Position(rival,w.Player.Cell+Vector2Int.right,Vector2Int.left);w.Player.Score=100;rival.Score=0;Step(r,w);
    Check(r,rival.Dead&&!w.ComboActive&&w.Player.Combo.SnakeCount==0&&f.StartSounds==0,"Competitive player eating cannot start or continue a snake combo");
   }
   {
    var f=World();var w=f.world;w.UseLegacyAi=true;AddChain(w,Centre,Vector2Int.right);for(int i=0;i<8;i++)Step(r,w);Check(r,!w.ComboActive&&Near(w.PlayerDelay,95)&&f.StartSounds==0,"Explicit frozen historical oracle retains original movement speed");
   }
  }
  static void Lifecycle(NativeComboReport r){
   {
    var f=Active(r);var w=f.world;w.SessionDeath();Check(r,w.Player.Dead&&!w.ComboActive&&Near(w.ComboStrength,0),"Actual SessionDeath clears acceleration and chain");
    w.Snakes.Clear();w.Time=w.Player.RespawnAt;w.UpdateDeath();Check(r,!w.Player.Dead&&!w.ComboActive&&Near(w.ComboStrength,0)&&w.Player.Combo.SnakeCount==0&&w.Player.ShieldUntil>w.Time,"Respawn starts with clean combo and ordinary defensive shield");
   }
   {
    var f=Active(r);var w=f.world;var generator=new NativeMazeGenerator(107,1);w.LevelLoader=generator.Generate;w.AdvanceLevel();
    Check(r,w.Level==2&&!w.ComboActive&&Near(w.ComboStrength,0)&&w.Player.Combo.SnakeCount==0,"Actual next-level installation never carries combo speed");
   }
   {
    var f=Active(r);var w=f.world;w.Snakes.Clear();w.CheckLevelComplete();Check(r,w.Transition&&!w.ComboActive&&Near(w.ComboStrength,0),"LEVEL CLEARED removes stale combo immediately");
   }
   foreach(double speed in NativeMenuState.Speeds){
    var f=World();var w=f.world;w.ScoreSpeed=speed;AddChain(w,Centre,Vector2Int.right);double real=0;for(int i=0;i<5;i++){double delta=w.PlayerDelay+.01;real+=delta/speed;Step(r,w);}Check(r,w.ComboActive&&Near((w.Time-1000)/speed,real),"Every configured game speed uses the existing shared simulation clock: "+speed);
   }
  }
  public static NativeComboReport Run(){var clock=Stopwatch.StartNew();var r=new NativeComboReport();Group(r,"continuous real movement",()=>Continuous(r));Group(r,"continuous early breaks",()=>EarlyBreaks(r));Group(r,"interruptions",()=>Interruptions(r));Group(r,"fragment lineage",()=>Lineage(r));Group(r,"nonqualifying contacts",()=>Exclusions(r));Group(r,"power and participants",()=>PowerAndPlayers(r));Group(r,"lifecycle",()=>Lifecycle(r));r.elapsedMs=clock.Elapsed.TotalMilliseconds;r.passed=r.failures==0;return r;}
 }
}
#endif

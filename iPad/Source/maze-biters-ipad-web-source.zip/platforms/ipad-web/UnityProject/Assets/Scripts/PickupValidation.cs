using System;using System.IO;using System.Linq;using System.Collections;using System.Collections.Generic;using UnityEngine;using UnityEngine.Rendering;
namespace MazeBiters.NativeStudy {
 [Serializable]class PickupClockFixture {public double bornAt,time,fade,pulse;public int egg;}
 [Serializable]class PickupClockFixtures {public PickupClockFixture[] timing;}
 [Serializable]class PickupReport {
  public string quality,note;public bool passed;public int timingChecks,coveredEmissionPixels,exposedEmissionPixels;
  public double maximumTimingError,brightWallAlpha,dimWallAlpha;public long textureBytes;public VisualCheck[] images;
 }
 public sealed class PickupValidation:MonoBehaviour {
  string quality="hd",report;Mesh quad;Camera camera;RenderTexture target;NativePickups pickups;NativeDusk dusk;NativeNeon neon;
  CommandBuffer draw;PackedArt art;NativeTurnBank bank;NativeTurnActor player;Material mazeMaterial,opaque;Texture2D maze,lit,emission;readonly List<GameObject> objects=new List<GameObject>();
  static Texture2D Read(RenderTexture rt){var old=RenderTexture.active;RenderTexture.active=rt;var t=new Texture2D(rt.width,rt.height,TextureFormat.RGBA32,false);t.ReadPixels(new Rect(0,0,rt.width,rt.height),0,0);t.Apply();RenderTexture.active=old;return t;}
  static Texture2D Load(string f){var t=new Texture2D(2,2,TextureFormat.RGBA32,false);t.LoadImage(File.ReadAllBytes(Path.Combine(WebFiles.Root,"Reference",f)));return t;}
  void Save(RenderTexture rt,string name){var t=Read(rt);File.WriteAllBytes(Path.Combine(Path.GetDirectoryName(report),name),t.EncodeToPNG());Destroy(t);}
  static int Visible(RenderTexture rt){var t=Read(rt);int n=t.GetPixels32().Count(p=>p.a>0);Destroy(t);return n;}
  static double Alpha(RenderTexture rt){var t=Read(rt);double n=t.GetPixels32().Sum(p=>(double)p.a);Destroy(t);return n;}
  void Target(int w,int h){if(target){camera.targetTexture=null;target.Release();Destroy(target);}target=new RenderTexture(w,h,0,RenderTextureFormat.ARGB32);target.Create();camera.targetTexture=target;}
  VisualCheck Compare(Texture2D reference,double fruitOpacity,string name){
   var t=Read(target);var a=t.GetPixels32();var b=reference.GetPixels32();var result=new VisualCheck{name=name,pixels=a.Length};double sum=0;
   for(int i=0;i<a.Length;i++){double opacity=i/reference.width>=reference.height/2?fruitOpacity:1;int max=0;
    for(int k=0;k<4;k++){int actual=k==0?a[i].r:k==1?a[i].g:k==2?a[i].b:a[i].a;double source=k==0?b[i].r:k==1?b[i].g:k==2?b[i].b:b[i].a;
     if(k<3)source=Math.Round(source*b[i].a/255.0);int expected=(int)Math.Round(source*opacity),error=Math.Abs(actual-expected);max=Math.Max(max,error);sum+=error*error;}
    result.maxError=Math.Max(result.maxError,max);if(max>2)result.over2++;
   }result.rmse=Math.Sqrt(sum/(a.Length*4));Destroy(t);return result;
  }
  MeshRenderer Add(Material paint,Vector3 position,Vector3 scale,int order=0){var go=new GameObject("Pickup validation object");objects.Add(go);go.AddComponent<MeshFilter>().sharedMesh=quad;var r=go.AddComponent<MeshRenderer>();r.sharedMaterial=paint;r.sortingOrder=order;go.transform.position=position;go.transform.localScale=scale;return r;}
  IEnumerator Start(){
   var args=Environment.GetCommandLineArgs();for(int i=0;i<args.Length;i++){if(args[i]=="--quality")quality=args[++i];if(args[i]=="--report")report=args[++i];}
   Application.runInBackground=true;QualitySettings.vSyncCount=0;QualitySettings.anisotropicFiltering=AnisotropicFiltering.Disable;Directory.CreateDirectory(Path.GetDirectoryName(report));
   var fixtures=JsonUtility.FromJson<PickupClockFixtures>(File.ReadAllText(Path.Combine(WebFiles.Root,"Reference/pickup-timing-reference.json")));double clockError=0;
   foreach(var f in fixtures.timing){clockError=Math.Max(clockError,Math.Abs(NativePickupTiming.Fade(f.bornAt,f.time)-f.fade));clockError=Math.Max(clockError,Math.Abs(NativePickupTiming.Pulse(f.bornAt,f.time)-f.pulse));clockError=Math.Max(clockError,Math.Abs(NativePickupTiming.EggFrame(f.bornAt,f.time)-f.egg));}
   quad=new Mesh();quad.vertices=new[]{new Vector3(0,0),new Vector3(1,0),new Vector3(1,-1),new Vector3(0,-1)};quad.uv=new[]{new Vector2(0,1),new Vector2(1,1),new Vector2(1,0),new Vector2(0,0)};quad.triangles=new[]{0,1,2,0,2,3};quad.RecalculateBounds();
   camera=new GameObject("Pickup validation camera").AddComponent<Camera>();camera.enabled=false;camera.orthographic=true;camera.orthographicSize=16;camera.aspect=2;camera.transform.position=new Vector3(32,-16,-10);camera.cullingMask=0;camera.clearFlags=CameraClearFlags.SolidColor;camera.backgroundColor=Color.clear;camera.allowHDR=false;
   draw=new CommandBuffer{name="Pickup validation"};camera.AddCommandBuffer(CameraEvent.BeforeForwardAlpha,draw);
   pickups=new NativePickups(quad,quality);int size=quality=="4k"?160:80;Target(size*4,size*2);lit=Load("pickup-"+quality+"-lit-reference.png");emission=Load("pickup-"+quality+"-emission-reference.png");
   var checks=new List<VisualCheck>();int[] eggAges={1000,10000,11000,12000};
   foreach(double age in new double[]{0,1,125,250,436,872,1744}){
    pickups.Clear();for(int i=0;i<4;i++){pickups.Add(false,i,new Vector2(i,0),0,age);pickups.Add(true,0,new Vector2(i,1),0,eggAges[i]);}
    double opacity=NativePickupTiming.Fade(0,age)*NativePickupTiming.Pulse(0,age);
    foreach(bool glow in new[]{false,true}){draw.Clear();pickups.Submit(draw,glow);camera.Render();checks.Add(Compare(glow?emission:lit,opacity,(glow?"emission-":"lit-")+age));if(age==1744)Save(target,"atlas-"+quality+"-"+(glow?"emission":"lit")+".png");}
    yield return null;
   }
   // Same material compositing order as gameplay; the pickup must not shine
   // through a covering actor. No new per-frame full-scene target is required.
   draw.Clear();var level=JsonUtility.FromJson<LevelData>(File.ReadAllText(Path.Combine(WebFiles.Root,"Reference/level.json")));
   for(int i=0;i<8;i++){var cell=NativePickups.GalleryCell(i);if(level.geometry[(int)cell.y][(int)cell.x]=='#')throw new Exception("Gallery pickup inside a wall: "+i);}
   camera.orthographicSize=216;camera.aspect=4f/3;camera.transform.position=new Vector3(288,-184,-10);camera.cullingMask=~(1<<28);camera.backgroundColor=Color.black;int height=quality=="4k"?2160:1080;Target(height*4/3,height);
   dusk=new NativeDusk(quad,camera);neon=new NativeNeon(level.geometry,quad,dusk,false,Array.Empty<NativeSnake>(),true,true,true);
   opaque=new Material(Shader.Find("MazeBiters/PickupImage")){mainTexture=Texture2D.whiteTexture};opaque.SetFloat("_Opacity",1);
   pickups.Clear();pickups.Add(false,0,new Vector2(5,1),0,1744);
   var covering=Matrix4x4.TRS(new Vector3(80,-16,-1),Quaternion.identity,new Vector3(16,16,1));
   var outside=Matrix4x4.TRS(new Vector3(-1000,-1000,-1),Quaternion.identity,new Vector3(16,16,1));
   neon.Render(Array.Empty<NativeSnake>(),Array.Empty<SnakePose>(),opaque,covering,1744,pickups:pickups);int covered=Visible(neon.PickupValidationEmission);
   neon.Render(Array.Empty<NativeSnake>(),Array.Empty<SnakePose>(),opaque,outside,1744,pickups:pickups);int exposed=Visible(neon.PickupValidationEmission);
   double bright=Alpha(neon.Field.Walls);pickups.Clear();pickups.Add(false,0,new Vector2(5,1),0,872);
   neon.Render(Array.Empty<NativeSnake>(),Array.Empty<SnakePose>(),opaque,outside,872,pickups:pickups);double dim=Alpha(neon.Field.Walls);
   maze=NativeLightField.Load("maze.png");mazeMaterial=new Material(Shader.Find("MazeBiters/ExactImage")){mainTexture=maze};Add(mazeMaterial,Vector3.zero,new Vector3(576,400,1));
   art=new PackedArt(quality);bank=new NativeTurnBank(quality,art,quad);player=new NativeTurnActor(bank,"fantasy","p1");bank.Render(player,new TurnPose{from=0,to=0,mix=0},16,0);var pr=Add(player.Display,new Vector3(32,-16,-1),new Vector3(16,16,1),10);
   pickups.Clear();for(int i=0;i<4;i++){pickups.Add(false,i,NativePickups.GalleryCell(i),0,1744);pickups.Add(true,0,NativePickups.GalleryCell(i+4),0,eggAges[i]);}
   draw.Clear();pickups.Submit(draw);dusk.Render(new Vector2(2,1),Vector2Int.right,16,false,false);
   neon.Render(Array.Empty<NativeSnake>(),Array.Empty<SnakePose>(),player.Display,pr.transform.localToWorldMatrix,1744,pickups:pickups);camera.Render();Save(target,"maze-"+quality+".png");
   // Exercise independent ages, dynamic opacity, and both sets of materials.
   // This is a functional loop, not a frame-rate benchmark.
   for(int frame=0;frame<240;frame++){
    double time=1000+frame*60;pickups.Clear();for(int i=0;i<4;i++){pickups.Add(false,i,NativePickups.GalleryCell(i),1000,time);double age=(time-1000+eggAges[i])%13000;pickups.Add(true,0,NativePickups.GalleryCell(i+4),time-age,time);}
    draw.Clear();pickups.Submit(draw);neon.Render(Array.Empty<NativeSnake>(),Array.Empty<SnakePose>(),player.Display,pr.transform.localToWorldMatrix,time,pickups:pickups);camera.Render();if(frame%8==0)yield return null;
   }
   var result=new PickupReport{quality=quality,passed=clockError<1e-12&&covered==0&&exposed>0&&bright>dim&&dim>0&&checks.All(c=>c.maxError<=2),timingChecks=fixtures.timing.Length*3,maximumTimingError=clockError,coveredEmissionPixels=covered,exposedEmissionPixels=exposed,brightWallAlpha=bright,dimWallAlpha=dim,textureBytes=pickups.TextureBytes,images=checks.ToArray(),note="Original eight pickup artworks and materials, 250ms fade, 1744ms fruit pulse, 10/11/12s egg frames; 240 integrated functional frames. Gallery only, no collection, power mode, hatching or scorpion drop scheduling. Not a performance benchmark."};
   File.WriteAllText(report,JsonUtility.ToJson(result,true));Debug.Log("PICKUP_VALIDATION "+result.passed);Application.Quit(result.passed?0:2);
  }
  void OnDestroy(){draw?.Clear();if(camera){camera.RemoveCommandBuffer(CameraEvent.BeforeForwardAlpha,draw);camera.targetTexture=null;Destroy(camera.gameObject);}draw?.Dispose();neon?.Dispose();dusk?.Dispose();pickups?.Dispose();player?.Dispose();bank?.Dispose();art?.Dispose();foreach(var go in objects)Destroy(go);foreach(var m in new[]{mazeMaterial,opaque})Destroy(m);foreach(var t in new[]{maze,lit,emission})Destroy(t);if(target){if(RenderTexture.active==target)RenderTexture.active=null;target.Release();Destroy(target);}Destroy(quad);}
 }
}

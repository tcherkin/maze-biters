using System;
using UnityEngine;
namespace MazeBiters.NativeStudy {
 public static class IpadSoloPaceValidation {
  public static int Run(){
   int checks=0;void Check(bool value,string label){checks++;if(!value)throw new Exception("iPad SOLO pace: "+label);}
   var frame=new NativeFrame(4f/3,true);var safe=new Rect(0,0,frame.Width,frame.Height);double close=160.0*432/(16*2064);
   foreach(int hz in new[]{60,120})foreach(bool opening in new[]{true,false}){
    var solo=new NativeGameplayCamera();solo.Reset(0);var identity=new object();var camera=new IpadCameraMotion();
    double initial=opening?2:1,target=opening?1:2,span=opening?IpadCameraMotion.RevealDuration:IpadCameraMotion.DeathDuration;
    var start=camera.Sample(frame,288,200,initial,close,safe,null,0,288,200,null,target);
    if(opening)camera.BeginReveal(0,2);else camera.BeginLoss(0,2);
    var destination=IpadFraming.Calculate(frame,288,200,target,close,safe);double last=0;
    for(int i=1;i<=hz*6;i++){
     double t=i*1000.0/hz;
     solo.Update(identity,288,200,false,false,false,false,t,t);
     var view=camera.Sample(frame,288,200,target,close,safe,null,t,288,200,null,target);
     double progress=(view.zoom-start.zoom)/(destination.zoom-start.zoom);
     Check(progress>=last-1e-8&&progress<=1.000001,"monotonic coherent zoom "+opening+" "+hz+" "+i);last=progress;
     if(t<=span)Check(Math.Abs(progress-IpadCameraMotion.RevealProgress(t*IpadCameraMotion.RevealDuration/span))<1e-10,"shared death/respawn easing");
     if(opening&&t>=span&&t<span+1000.0/hz){
      Check(solo.Zoom-1>=.95&&solo.Zoom-1<.952,"duration matches main 95% SOLO opening");
     }
     if(t>=span){Check(!camera.Revealing,"completed handoff");Check(Math.Abs(view.zoom-destination.zoom)<1e-8,"exact endpoint");}
    }
   }
   double h=.1,duration=IpadCameraMotion.RevealDuration;
   double Slope(double t)=>(IpadCameraMotion.RevealProgress(t+h)-IpadCameraMotion.RevealProgress(t-h))/(2*h);
   Check(Slope(0)<1e-8&&Slope(duration)<1e-8,"soft start and stop");
   Check(Slope(duration*.15)<Slope(duration*.3)&&Slope(duration*.3)<Slope(duration*.5),"gradual acceleration");
   Check(Slope(duration*.5)>Slope(duration*.7)&&Slope(duration*.7)>Slope(duration*.85),"gradual deceleration");
   return checks;
  }
 }
}

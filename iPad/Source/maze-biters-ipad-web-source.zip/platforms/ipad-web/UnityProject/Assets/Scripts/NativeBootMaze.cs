using System;
using System.Globalization;
using System.IO;
using System.Threading;
using System.Threading.Tasks;
using UnityEngine;
namespace MazeBiters.NativeStudy {
 public sealed partial class NativeGameplayStudy {
  static Task<PreparedMaze> bootMaze;static CancellationTokenSource bootCancellation;
  static uint bootSeed;static string bootQuality;static bool bootFixedSeed;
  bool bootMazeAdopted;
  // Pure CPU job only: no scene, texture, input, game clock or authoritative
  // simulation is created before the engine's original splash finishes.
  internal static bool QueueBootMaze(){
   var args=Environment.GetCommandLineArgs();
   bool menu=IpadPresentation.DefaultMenu||args.Length==1||Array.IndexOf(args,"--menu")>=0||Array.IndexOf(args,"--menu-smoke")>=0||Array.IndexOf(args,"--records-smoke")>=0;
   if(!NativeStartupLoading.Enabled||!menu||!NativeMenu.InstantMenuStart||!EarlyMazePreparation||Array.IndexOf(args,"--legacy-glass-presentation")>=0||Array.IndexOf(args,"--catalogue-control")>=0)return false;
   int at=Array.IndexOf(args,"--quality");bootQuality=at>=0?args[at+1]:IpadPresentation.DefaultQuality;
   if(bootQuality!="hd"&&bootQuality!="4k")return false;
   at=Array.IndexOf(args,"--seed");bootFixedSeed=at>=0;
   if(bootFixedSeed)bootSeed=uint.Parse(args[at+1],CultureInfo.InvariantCulture);
   else{var bytes=new byte[4];using(var rng=System.Security.Cryptography.RandomNumberGenerator.Create())rng.GetBytes(bytes);bootSeed=BitConverter.ToUInt32(bytes,0);}
   string source=Path.Combine(WebFiles.Root,"Reference/maze-brushes"),q=bootQuality;uint seed=bootSeed;
   // The 4K first map can finish before the animation banks: retain its CPU
   // pixels in the existing lossless cache rather than overlap two raw fields.
   bootMaze=NativeMazeWorker.Run(()=>BuildMenuMaze(seed,NativeMazeGenerator.Difficulties[2],source,q,NativeStartupLoading.Assets&&q=="4k"),out bootCancellation);
   Application.quitting+=CancelBootMaze;NativeStartupLoading.Mark("boot map queued");return true;
  }
  bool TakeBootMaze(){
   if(bootMaze==null)return false;
   if(menuDifficulty!=2||quality!=bootQuality){CancelBootMaze();return false;}
   mazeSeed=bootSeed;seedFixed=bootFixedSeed;difficultyIndex=menuDifficulty;generator=new NativeMazeGenerator(mazeSeed,NativeMazeGenerator.Difficulties[difficultyIndex]);
   menuMazeTask=bootMaze;menuMazeCancellation=bootCancellation;bootMaze=null;bootCancellation=null;
   bootMazeAdopted=true;
   menuMazeDifficulty=menuDifficulty;menuMazeQuality=quality;
   NativeStartupLoading.Mark(menuMazeTask.IsCompleted?"boot map adopted complete":"boot map adopted in flight");return true;
  }
  static void CancelBootMaze(){
   var task=bootMaze;var cancellation=bootCancellation;bootMaze=null;bootCancellation=null;if(task==null)return;cancellation?.Cancel();
   WebWorkQueue.Continue(task,t=>{try{if(t.Status==TaskStatus.RanToCompletion)t.Result.art.DisposeStaging();else if(t.IsFaulted){_ = t.Exception;}}finally{cancellation?.Dispose();}});
  }
 }
}

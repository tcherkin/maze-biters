#if UNITY_EDITOR
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using UnityEngine;

namespace MazeBiters.NativeStudy {
 [Serializable] public sealed class NativeAllyEscapeTopologyCase {
  public string name, direction, thought, directive;
  public int rotation, mode, decisions, moves;
  public double rate, gameElapsedMs, risk;
  public bool alive, waiting;
 }
 [Serializable] public sealed class NativeAllyEscapeTopologyReport {
  public bool passed;
  public int assertions, failures, decisions;
  public double elapsedMs;
  public string scope;
  public List<NativeDifficultyCheck> checks=new List<NativeDifficultyCheck>();
  public List<NativeAllyEscapeTopologyCase> cases=new List<NativeAllyEscapeTopologyCase>();
 }

 // Behavioural regression boards exercise the actual competitive directive,
 // planner and cell-contact engine. No private planner method is substituted,
 // no flee/escape target is injected, and no new search implementation is used
 // as the oracle. Expected exits follow the explicitly constructed geometry.
 public static class NativeAllyEscapeTopologyValidation {
  static readonly Vector2Int Right=Vector2Int.right, Left=Vector2Int.left;
  static readonly Vector2Int Up=new Vector2Int(0,-1), Down=new Vector2Int(0,1);
  const int BlindLength=32;
  sealed class Fixture {
   public NativeGameplayWorld world;
   public NativePlayer ai, rival;
   public Vector2Int offset;
   public int rotation, randomCalls, decisions;
   public Vector2Int C(int x,int y)=>Rotate(new Vector2Int(x,y),rotation)+offset;
   public Vector2Int D(Vector2Int d)=>Rotate(d,rotation);
  }
  static Vector2Int Rotate(Vector2Int v,int n){for(int i=0;i<n;i++)v=new Vector2Int(-v.y,v.x);return v;}
  static void Line(HashSet<Vector2Int> cells,int ax,int ay,int bx,int by){
   if(ax!=bx&&ay!=by)throw new ArgumentException("Axis-aligned fixture lines only");
   var c=new Vector2Int(ax,ay);var end=new Vector2Int(bx,by);var d=new Vector2Int(Math.Sign(bx-ax),Math.Sign(by-ay));
   for(int i=0;i<200;i++){cells.Add(c);if(c==end)return;c+=d;}throw new ArgumentException("Fixture line too long");
  }
  static void Pose(NativePlayer p,Vector2Int c,Vector2Int d,double time,bool waiting=false){
   p.Cell=p.From=p.Previous=c;p.Dir=p.Next=d;p.Waiting=waiting;p.Dead=p.Eliminated=p.HideDeath=false;p.Lives=3;
   p.LastMove=time-96;p.PowerUntil=p.ShieldUntil=0;
  }
  static Fixture Make(HashSet<Vector2Int> cells,int rotation=0,int mode=3){
   var f=new Fixture{rotation=rotation};var rotated=cells.Select(c=>Rotate(c,rotation)).ToArray();
   int minX=rotated.Min(c=>c.x),minY=rotated.Min(c=>c.y);f.offset=new Vector2Int(2-minX,2-minY);
   int width=rotated.Max(c=>c.x)-minX+5,height=rotated.Max(c=>c.y)-minY+5;
   var rows=Enumerable.Range(0,height).Select(_=>new string('#',width).ToCharArray()).ToArray();
   foreach(var c in rotated){var v=c+f.offset;rows[v.y][v.x]='.';}
   var w=new NativeGameplayWorld(rows.Select(row=>new string(row)).ToArray(),()=>{f.randomCalls++;return .99;}){
    AiDifficulty=4,Difficulty=NativeMazeGenerator.Difficulties[4],Time=1000,LevelStarted=1000,Assist=false,SessionEnabled=false
   };
   w.SetMode(mode);f.world=w;f.rival=w.GetPlayer(0);f.ai=w.GetPlayer(w.PlayerCount-1);
   for(int i=0;i<w.PlayerCount;i++){var p=w.GetPlayer(i);Pose(p,f.C(0,0),f.D(Right),w.Time);if(p!=f.ai&&p!=f.rival){p.Dead=true;p.Lives=0;}}
   Pose(f.ai,f.C(0,0),f.D(Right),w.Time);f.ai.Score=200;f.ai.ExactScore=200;
   Pose(f.rival,f.C(-4,0),f.D(Right),w.Time,true);f.rival.Score=1000;f.rival.ExactScore=1000;
   w.Ally.BeginLevel();return f;
  }
  // A genuine bypass reconnects to the approach without visiting the dead arm.
  static Fixture Bypass(int rotation=0,int mode=3){
   var cells=new HashSet<Vector2Int>();Line(cells,-8,0,BlindLength,0);
   Line(cells,0,0,0,8);Line(cells,0,8,-8,8);Line(cells,-8,8,-8,0);
   return Make(cells,rotation,mode);
  }
  // Only the first step left approaches the pursuer. The next step turns away
  // into a loop. A greedy "increase distance every step" rule loses this exit.
  static Fixture TemporaryApproach(int rotation=0,int mode=3){
   var cells=new HashSet<Vector2Int>();Line(cells,-5,0,BlindLength,0);
   Line(cells,-1,0,-1,-8);Line(cells,-1,-8,8,-8);Line(cells,8,-8,8,-2);Line(cells,8,-2,-1,-2);
   return Make(cells,rotation,mode);
  }
  static void Check(NativeAllyEscapeTopologyReport r,bool pass,string name,string detail=""){
   r.assertions++;if(!pass)r.failures++;r.checks.Add(new NativeDifficultyCheck{name=name,passed=pass,detail=detail});
  }
  static void Group(NativeAllyEscapeTopologyReport r,string name,Action body){try{body();}catch(Exception e){Check(r,false,name+" completes",e.ToString());}}
  static void Plan(NativeAllyEscapeTopologyReport r,Fixture f){using(f.world.ForPlayer(f.ai))f.world.Ally.Plan(f.ai,f.world.Time);f.decisions++;r.decisions++;}
  static void Advance(Fixture f){using(f.world.ForPlayer(f.ai))f.world.AdvancePlayer();f.ai.LastMove=f.world.Time;f.world.Time+=100;}
  static string Detail(Fixture f)=>"next="+f.ai.Next+", thought="+f.ai.Ai.thought+", directive="+f.ai.Ai.directive?.type+", target="+f.ai.Ai.escapeTarget+", risk="+f.ai.Ai.foresightRisk;
  static void Record(NativeAllyEscapeTopologyReport r,string name,Fixture f,int moves=0,double rate=1){r.cases.Add(new NativeAllyEscapeTopologyCase{
   name=name,rotation=f.rotation,mode=f.world.Mode,direction=f.ai.Next.ToString(),thought=f.ai.Ai.thought,directive=f.ai.Ai.directive?.type,
   decisions=f.decisions,moves=moves,rate=rate,gameElapsedMs=f.world.Time-1000,risk=f.ai.Ai.foresightRisk,alive=!f.ai.Dead,waiting=f.ai.Waiting
  });}
  static void Premise(NativeAllyEscapeTopologyReport r,Fixture f,string label){
   Check(r,f.ai.IsAI&&f.world.Competitive&&f.world.CanEatPlayer(f.rival,f.ai,f.world.Time)&&!f.world.CanEatPlayer(f.ai,f.rival,f.world.Time),"Actual competitive contact priority establishes the pursuer: "+label);
  }
  static void LongDeadEnd(NativeAllyEscapeTopologyReport r){
   var budget=NativeAllyForesightProfile.ForIntensity(4);
   Check(r,BlindLength>budget.Steps&&BlindLength*95>budget.HorizonMs,"Fixture dead arm extends beyond both the step and time forecast windows","length="+BlindLength+", steps="+budget.Steps+", horizon="+budget.HorizonMs);
   for(int rotation=0;rotation<4;rotation++)foreach(int mode in new[]{3,4}){
    var f=Bypass(rotation,mode);string label="rotation="+rotation+", mode="+mode;Premise(r,f,label);Plan(r,f);
    Check(r,f.ai.Ai.directive?.type=="flee","The real planner enters flee intent without test-side injection: "+label,Detail(f));
    Check(r,!f.ai.Waiting&&f.ai.Next==f.D(Down),"BRUTAL chooses the open bypass rather than the distant dead end: "+label,Detail(f));
    Advance(f);Check(r,!f.ai.Dead&&f.ai.Cell==f.C(0,1),"The bypass decision becomes a legal, surviving real movement: "+label,"cell="+f.ai.Cell);
    Record(r,"long-dead-end-versus-bypass",f,1);
   }
  }
  static void AlreadyInside(NativeAllyEscapeTopologyReport r){
   for(int rotation=0;rotation<4;rotation++)foreach(int mode in new[]{3,4}){
    var f=Bypass(rotation,mode);Pose(f.ai,f.C(3,0),f.D(Right),f.world.Time);Pose(f.rival,f.C(7,0),f.D(Left),f.world.Time,true);
    string label="rotation="+rotation+", mode="+mode;bool allExit=true;
    for(int i=0;i<3;i++){Plan(r,f);allExit&=!f.ai.Waiting&&f.ai.Next==f.D(Left);Advance(f);}
    Check(r,allExit&&!f.ai.Dead&&f.ai.Cell==f.C(0,0),"Already inside, the AI reverses and reaches the gate instead of going deeper or oscillating: "+label,Detail(f)+", cell="+f.ai.Cell);
    Record(r,"already-inside-escape",f,3);
   }
  }
  static void SoleChoice(NativeAllyEscapeTopologyReport r){
   for(int rotation=0;rotation<4;rotation++){
    var cells=new HashSet<Vector2Int>();Line(cells,0,0,BlindLength,0);var f=Make(cells,rotation);
    Pose(f.rival,f.C(3,0),f.D(Left),f.world.Time,true);Plan(r,f);
    Check(r,!f.ai.Waiting&&f.ai.Next==f.D(Right),"An unavoidable dead branch does not make the AI freeze or choose a wall: rotation="+rotation,Detail(f));
    Advance(f);Check(r,f.ai.Cell==f.C(1,0)&&!f.ai.Dead,"Sole-choice fallback preserves the available non-contact step: rotation="+rotation,"cell="+f.ai.Cell);
    Record(r,"only-legal-step",f,1);
   }
  }
  static void SafeDetour(NativeAllyEscapeTopologyReport r){
   for(int rotation=0;rotation<4;rotation++)foreach(int mode in new[]{3,4}){
    var f=TemporaryApproach(rotation,mode);string label="rotation="+rotation+", mode="+mode;Premise(r,f,label);Plan(r,f);
    Check(r,!f.ai.Waiting&&f.ai.Next==f.D(Left),"A safe temporary approach beats escaping farther into a blind arm: "+label,Detail(f));
    Advance(f);Plan(r,f);
    Check(r,!f.ai.Waiting&&f.ai.Next==f.D(Up),"The second decision follows the loop exit instead of reversing to the blind arm: "+label,Detail(f));
    Advance(f);Check(r,!f.ai.Dead&&f.ai.Cell==f.C(-1,-1),"Temporary detour reaches its turning escape through actual movement: "+label,"cell="+f.ai.Cell);
    Record(r,"temporary-approach-to-loop",f,2);
   }
  }
  static void HarmlessPocket(NativeAllyEscapeTopologyReport r){
   for(int rotation=0;rotation<4;rotation++){
    var f=Bypass(rotation);f.rival.Dead=true;f.rival.Lives=0;var cell=f.C(BlindLength,0);
    f.world.Snakes.Add(new NativeGameplaySnake{Id=10,Cell=cell,Body=new List<Vector2Int>{cell},Dir=f.D(Right),LastMove=f.world.Time,Temperament=.5});Plan(r,f);
    Check(r,!f.ai.Waiting&&f.ai.Next==f.D(Right),"A harmless long pocket remains usable for a real food objective: rotation="+rotation,Detail(f));
    Record(r,"safe-food-pocket",f);
   }
  }
  static void BridgeBetweenLoops(NativeAllyEscapeTopologyReport r){
   for(int rotation=0;rotation<4;rotation++)foreach(int mode in new[]{3,4}){
    var cells=new HashSet<Vector2Int>();Line(cells,-12,0,12,0);
    Line(cells,-12,0,-12,6);Line(cells,-12,6,-6,6);Line(cells,-6,6,-6,0);
    Line(cells,6,0,6,6);Line(cells,6,6,12,6);Line(cells,12,6,12,0);
    var f=Make(cells,rotation,mode);string label="rotation="+rotation+", mode="+mode;Premise(r,f,label);
    bool forward=true;for(int step=0;step<6;step++){Plan(r,f);forward&=!f.ai.Waiting&&f.ai.Next==f.D(Right);Advance(f);}
    Check(r,forward&&!f.ai.Dead&&f.ai.Cell==f.C(6,0),"The narrow bridge between two loops remains a valid continuous escape: "+label,Detail(f)+", cell="+f.ai.Cell);
    Record(r,"bridge-between-loops",f,6);
   }
  }
  static void RemoveRival(Fixture f){f.rival.Dead=true;f.rival.Lives=0;}
  static NativeGameplaySnake Food(Fixture f){
   var cell=f.C(BlindLength,0);var snake=new NativeGameplaySnake{Id=50,Cell=cell,Body=new List<Vector2Int>{cell},Dir=f.D(Right),LastMove=f.world.Time,Temperament=.5};
   f.world.Snakes.Add(snake);return snake;
  }
  static void CreaturePursuers(NativeAllyEscapeTopologyReport r){
   for(int rotation=0;rotation<4;rotation++)foreach(int mode in new[]{3,4})foreach(bool snake in new[]{true,false}){
    var f=Bypass(rotation,mode);RemoveRival(f);
    if(snake){var body=new[]{f.C(-2,0),f.C(-3,0),f.C(-4,0)};f.world.Snakes.Add(new NativeGameplaySnake{Id=10,Cell=body[0],Body=body.ToList(),Dir=f.D(Right),LastMove=f.world.Time-219,Temperament=.5});}
    else f.world.Hunters.Add(new NativeHunter{Id=100,Cell=f.C(-2,0),From=f.C(-2,0),Dir=f.D(Right),LastMove=f.world.Time-95,MotherAlive=false});
    string label=(snake?"snake":"hunter")+", rotation="+rotation+", mode="+mode;Plan(r,f);
    Check(r,f.ai.Ai.directive?.type!="flee","Creature danger is tested without a competitive rival flee directive: "+label,Detail(f));
    Check(r,!f.ai.Waiting&&f.ai.Next==f.D(Down),"BRUTAL retains the open escape from a creature instead of entering the long dead arm: "+label,Detail(f));
    Advance(f);Check(r,!f.ai.Dead&&f.ai.Cell==f.C(0,1),"The creature escape becomes real surviving movement: "+label,"cell="+f.ai.Cell);
    Record(r,"creature-pursuer-"+(snake?"snake":"hunter"),f,1);
   }
  }
  static void ShortRetreatReturn(NativeAllyEscapeTopologyReport r){
   for(int rotation=0;rotation<4;rotation++){
    var f=Bypass(rotation);RemoveRival(f);Food(f);
    // A held retreat can survive from the previous congested decision. Its
    // close waypoint is not evidence of a safe future return when an open
    // alternative is now available. Use the public state, then the real Plan.
    f.ai.Ai.retreat=new AllyRetreat{kind="route",reason="temporary-congestion",originalTarget=f.C(BlindLength,0),waypoint=f.C(1,0),started=f.world.Time-100,observed=f.ai.Cell,turnGoal=3};
    Plan(r,f);
    var openStep=f.ai.Next;bool entersLoop=openStep==f.D(Left)||openStep==f.D(Down);var expectedCell=f.ai.Cell+openStep;
    Check(r,!f.ai.Waiting&&entersLoop,"A short held retreat waypoint cannot override an available open escape: rotation="+rotation,Detail(f));
    Advance(f);Check(r,entersLoop&&!f.ai.Dead&&f.ai.Cell==expectedCell&&f.ai.Cell!=f.C(1,0)&&f.ai.Score==200,"Rejecting the inward retreat takes the bypass without following its deeper food: rotation="+rotation,"cell="+f.ai.Cell+", score="+f.ai.Score);
    Record(r,"short-retreat-open-guard",f,1);

    f=Bypass(rotation);RemoveRival(f);var food=Food(f);Pose(f.ai,f.C(1,0),f.D(Right),f.world.Time);
    f.world.Hunters.Add(new NativeHunter{Id=100,Cell=f.C(-3,0),From=f.C(-3,0),Dir=f.D(Right),LastMove=f.world.Time-95,MotherAlive=false});
    f.ai.Ai.retreat=new AllyRetreat{kind="route",reason="temporary-congestion",originalTarget=food.Head,waypoint=f.ai.Cell,started=f.world.Time-100,observed=f.ai.Cell,steps=1,turnGoal=3};
    Plan(r,f);
    Check(r,!f.ai.Waiting&&f.ai.Next==f.D(Left),"After a completed one-cell retreat the hunter's gate race beats food farther inward: rotation="+rotation,Detail(f));
    Advance(f);Plan(r,f);
    Check(r,!f.ai.Waiting&&f.ai.Next==f.D(Down),"Returning from the short detour continues through the open escape, not back toward food: rotation="+rotation,Detail(f));
    Advance(f);Check(r,!f.ai.Dead&&f.ai.Cell==f.C(0,1)&&f.ai.Score==200&&f.world.Snakes.Contains(food),"The short detour exits in two real steps while the tempting food remains uneaten: rotation="+rotation,"cell="+f.ai.Cell+", score="+f.ai.Score);
    Record(r,"short-retreat-return",f,2);
   }
  }
  static void ClockRates(NativeAllyEscapeTopologyReport r){
   // Runtime speed scales gameplay milliseconds, not planner coordinates or
   // the 95 ms base movement rule. Tick the actual scheduler at medium/high/
   // maximum menu rates, rather than inventing a test-only movement speed.
   foreach(double rate in new[]{NativeMenuState.Speeds[2],NativeMenuState.Speeds[3],NativeMenuState.Speeds[4]})for(int rotation=0;rotation<4;rotation++){
    var f=TemporaryApproach(rotation);f.world.MeasureAlly=true;var previous=f.ai.Cell;int moves=0;bool enteredBlindArm=false;double gameStart=f.world.Time;
    for(int frame=0;frame<120&&moves<2&&!f.ai.Dead;frame++){
     f.world.Tick(gameStart+(frame+1)*(1000.0/120)*rate);
     if(f.ai.Cell!=previous){moves++;previous=f.ai.Cell;}
     enteredBlindArm|=f.ai.Cell==f.C(1,0);
    }
    r.decisions+=f.world.AllyDecisions;f.decisions=f.world.AllyDecisions;
    Check(r,moves==2&&!f.ai.Dead&&!enteredBlindArm&&f.ai.Cell==f.C(-1,-1),"Real tick scheduling preserves the two-step safe escape at rate="+rate+", rotation="+rotation,"moves="+moves+", cell="+f.ai.Cell+", "+Detail(f));
    Record(r,"medium-high-clock",f,moves,rate);
   }
  }
  public static NativeAllyEscapeTopologyReport Run(){
   var watch=Stopwatch.StartNew();var r=new NativeAllyEscapeTopologyReport{scope="Editor-only BRUTAL escape regression through real Ally.Plan, AdvancePlayer and Tick. Long dead arms, open bypass, escape from inside, sole-choice fallback, safe temporary approach, harmless food, bridges between loops, snake/hunter pursuers and short retreat returns. All four rotations and medium/high menu clock rates. No visual/device performance or perfect survival claim."};
   Group(r,"long dead end",()=>LongDeadEnd(r));Group(r,"already inside",()=>AlreadyInside(r));Group(r,"sole choice",()=>SoleChoice(r));
   Group(r,"temporary detour",()=>SafeDetour(r));Group(r,"harmless pocket",()=>HarmlessPocket(r));Group(r,"bridge between loops",()=>BridgeBetweenLoops(r));
   Group(r,"creature pursuers",()=>CreaturePursuers(r));Group(r,"short retreat return",()=>ShortRetreatReturn(r));Group(r,"clock rates",()=>ClockRates(r));
   r.elapsedMs=watch.Elapsed.TotalMilliseconds;r.passed=r.failures==0;return r;
  }
  public static void RunBatch(){
   string directory=Path.GetFullPath(Path.Combine(Application.dataPath,"../../Results/ally-escape-topology"));Directory.CreateDirectory(directory);
   var r=Run();string path=Path.Combine(directory,"validation-report.json");File.WriteAllText(path,JsonUtility.ToJson(r,true));
   UnityEngine.Debug.Log("IPAD_ALLY_ESCAPE_TOPOLOGY assertions="+r.assertions+" decisions="+r.decisions+" failures="+r.failures+" elapsedMs="+r.elapsedMs.ToString("F1"));
   foreach(var check in r.checks.Where(c=>!c.passed))UnityEngine.Debug.LogError("IPAD_ALLY_ESCAPE_TOPOLOGY_FAILURE "+check.name+": "+check.detail);
   if(!r.passed)throw new InvalidOperationException("Ally escape topology validation failed "+r.failures+" checks. See "+path);
  }
 }
}
#endif

using System;
using System.IO;
using System.Linq;
using UnityEngine;
namespace MazeBiters.NativeStudy {
 // Pure simulation only. Runs after the original AI source is ready, before
 // the menu's main-thread asset stage. No Unity objects, live RNG or clocks.
 internal static class NativeLogicCpuPreparation {
  internal static void Run(string root){
   long stamp=NativeStartupLoading.Stamp();var level=JsonUtility.FromJson<LevelData>(File.ReadAllText(Path.Combine(root,"level.json")));uint random=34;
   double Next(){unchecked{random+=0x6D2B79F5;uint v=(random^(random>>15))*(1|random);v^=v+(v^(v>>7))*(61|v);return (v^(v>>14))/4294967296.0;}}
   var session=new NativeGameplayWorld(level.geometry,Next);session.SetMode(4);
   var cells=new[]{session.Brain.Nearest(new Vector2Int(1,1)),session.Brain.Nearest(new Vector2Int(34,23)),session.Brain.Nearest(new Vector2Int(1,23))};
   session.StartSession(_=>new SessionLevel{level=1,geometry=level.geometry,theme="green",starts=cells.Select(c=>new SessionStart{x=c.x,y=c.y,dir=Vector2Int.right}).ToArray()});
   var world=new NativeGameplayWorld(level.geometry,Next){Time=2000,RealTime=2000,SessionEnabled=true};
   var snake=world.AddSnake(Enumerable.Range(3,7).Reverse().Select(x=>new Vector2Int(x,1)),Vector2Int.right,0);
   var motion=new NativeLiveSnake(snake,2000);world.Event=e=>{if(e.Kind=="split"){var parts=motion.Split(e.Created.ToArray(),e.Index,e.OldBody.Length,e.Time,world.Player);foreach(var p in parts){p.Evaluate(e.Time);p.Evaluate(e.Time+48);}}};
   var player=world.Player;player.Cell=player.From=player.Previous=new Vector2Int(5,1);player.Dir=player.Next=Vector2Int.right;player.Waiting=false;player.LastMove=1900;
   for(int i=0;i<48;i++){world.RealTime=2000+(i+1)*1000.0/120;world.Tick(world.RealTime);world.UpdateTilt(world.RealTime);if(i==0)world.Event=null;}
   NativeStartupLoading.Add("pure logic CPU worker",stamp);
  }
 }
}

using System;
using System.IO;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
namespace MazeBiters.NativeStudy {
 public sealed partial class NativeMenu {
  bool ipadMenuTesting;
  [Serializable] sealed class IpadMenuResult {public bool passed;public int width,height;public int[] modes,rosters;public string note;}
  IEnumerator IpadMenuProbe(){
   Directory.CreateDirectory(Path.GetDirectoryName(report));yield return null;
   SaveFrame("menu",renderer.Target);int width=renderer.Target.width,height=renderer.Target.height;var modes=new List<int>();var rosters=new List<int>();
   for(int i=0;i<6;i++){
    State.SetFocus(i,Now);Choose();yield return new WaitForSecondsRealtime(.2f);
    if(!State.Pending)throw new Exception("iPad mode confirmation did not blink");
    if(i==0)SaveFrame("confirmation",renderer.Target);
    double began=Time.realtimeSinceStartupAsDouble;
    while(!gameplay||!gameplay.MenuReady){if(Time.realtimeSinceStartupAsDouble-began>180)throw new TimeoutException("iPad menu preparation");yield return null;}
    yield return null;
    if(!gameplay.MenuOptionsValid)throw new Exception("iPad mode raster/settings mismatch");
    int mode=NativeMenuState.Modes[i],expected=mode==4?3:mode==2||mode==3||mode==5?2:1;
    if(gameplay.MenuMode!=mode||gameplay.IpadPlayerCount!=expected)throw new Exception("iPad roster mismatch");
    modes.Add(mode);rosters.Add(gameplay.IpadPlayerCount);SaveFrame("mode-"+mode,gameplay.MenuTarget);
    ReturnToMenu();while(changing)yield return null;yield return null;
   }
   File.WriteAllText(report,JsonUtility.ToJson(new IpadMenuResult{passed=true,width=width,height=height,modes=modes.ToArray(),rosters=rosters.ToArray(),note="Six original modes: animated confirmation, prepared start, original rosters and return to interactive menu. Desktop functional test, not iPad performance."},true));Application.Quit();
  }
 }
 public sealed partial class NativeGameplayStudy {internal int IpadPlayerCount=>world.PlayerCount;}
}

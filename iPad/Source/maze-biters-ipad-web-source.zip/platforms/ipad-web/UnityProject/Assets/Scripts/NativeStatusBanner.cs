using System;
using System.Collections.Generic;
using UnityEngine;
namespace MazeBiters.NativeStudy {
 public sealed class NativeStatusBanner:IDisposable {
  const string Characters="ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789?";
  readonly NativeMessagePanel backdrop=new NativeMessagePanel();
  readonly Material fontPaint=new Material(Shader.Find("MazeBiters/SessionImage"));
  readonly Mesh letters=new Mesh(){name="Status notice glyphs"};
  readonly GameObject plate,label;
  float frameWidth=576,frameHeight=432;
  public bool Visible=>plate.activeSelf;
  public string Caption{get;private set;}="";
  public Vector2 Size{get;private set;}
  public float TextScale{get;private set;}=1;
  public NativeStatusBanner(Mesh quad,Transform parent){plate=Make("Soft status backdrop",quad,backdrop.Paint,parent,110);label=Make("Original status lettering",letters,fontPaint,parent,111);plate.SetActive(false);label.SetActive(false);}
  static GameObject Make(string name,Mesh mesh,Material paint,Transform parent,int order){var go=new GameObject(name);go.transform.SetParent(parent,false);go.AddComponent<MeshFilter>().sharedMesh=mesh;var r=go.AddComponent<MeshRenderer>();r.sharedMaterial=paint;r.sortingOrder=order;return go;}
  public void SetFont(Texture2D font){fontPaint.mainTexture=font;}
  public void Layout(NativeFrame frame){if(frameWidth==frame.Width&&frameHeight==frame.Height)return;frameWidth=frame.Width;frameHeight=frame.Height;Rebuild();}
  public void Show(string caption,float alpha,bool visible){caption=caption??"";if(Caption!=caption){Caption=caption;Rebuild();}plate.SetActive(visible);label.SetActive(visible&&alpha>0);fontPaint.SetFloat("_Opacity",Mathf.Clamp01(alpha));}
  void Rebuild(){
   float available=Mathf.Max(48,frameWidth-80),width=Caption.Length*24;
   TextScale=width>0?Mathf.Min(1,(available-56)/width):1;
   Size=new Vector2(Mathf.Min(available,Mathf.Max(112,width*TextScale+64)),64);
   float cx=frameWidth*.5f,cy=180+(frameHeight-432)*.5f;
   plate.transform.localPosition=new Vector3(cx-Size.x*.5f,-cy+Size.y*.5f,-3);plate.transform.localScale=new Vector3(Size.x,Size.y,1);backdrop.SetSize(Size);
   var vertices=new List<Vector3>();var uv=new List<Vector2>();var indices=new List<int>();float side=24*TextScale,start=cx-width*TextScale*.5f;
   for(int i=0;i<Caption.Length;i++){int c=Characters.IndexOf(Caption[i]);if(c<0)continue;int n=vertices.Count;float x=start+i*side,u=(float)c/Characters.Length,u2=(float)(c+1)/Characters.Length;
    vertices.AddRange(new[]{new Vector3(x,-cy+side*.5f,-3),new Vector3(x+side,-cy+side*.5f,-3),new Vector3(x+side,-cy-side*.5f,-3),new Vector3(x,-cy-side*.5f,-3)});uv.AddRange(new[]{new Vector2(u,1),new Vector2(u2,1),new Vector2(u2,0),new Vector2(u,0)});indices.AddRange(new[]{n,n+1,n+2,n,n+2,n+3});}
   letters.Clear();letters.SetVertices(vertices);letters.SetUVs(0,uv);letters.SetTriangles(indices,0);letters.RecalculateBounds();
  }
  public void Dispose(){UnityEngine.Object.Destroy(plate);UnityEngine.Object.Destroy(label);UnityEngine.Object.Destroy(letters);UnityEngine.Object.Destroy(fontPaint);backdrop.Dispose();}
 }
}

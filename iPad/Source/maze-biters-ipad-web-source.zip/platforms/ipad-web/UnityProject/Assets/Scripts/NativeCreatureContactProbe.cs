using System;
using System.Collections;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using UnityEngine;
namespace MazeBiters.NativeStudy {
 // Opt-in verification only. No automatic pilot or fixture enters normal play.
 public sealed partial class NativeGameplayStudy {
  bool creatureContactProbe;
  [Serializable] sealed class CreatureContactCheck {
   public string name,mode,expectedEvent,scorpionMotion;
   public int palette,direction,cut,eventCount,lateLoads,textureDecodes,scoreAtContact,snakeCountAtContact,massAtContact;
   public bool passed,finite=true,visualAdvance,ghostsReleased;
   public double contactCpuMs,maxCpuMs,nextMoveMs;
  }
  [Serializable] sealed class CreatureContactReport {
   public string quality,note,graphics;public bool passed;public int audioAccepted;
   public PreparationSample[] preparation;public CreatureContactCheck[] checks;public StallFrame[] frames;
  }
  readonly List<CreatureContactCheck> creatureChecks=new List<CreatureContactCheck>();
  void ContactProbeSession(string mode){
   StallSession();world.LifecycleEnabled=false;
   // Prevent the level-clear sequence from replacing this contact-only scene.
   var sentinel=world.AddSnake(new[]{new Vector2Int(27,9)},Vector2Int.right,4);
   sentinel.LastMove=time+100000;AddSnake(sentinel);
   if(mode=="spawn")world.ActivateShield();
   if(mode=="power"){world.ActivatePower();world.Player.RampAt=time-1500;world.Player.PowerUntil=time+5500;}
  }
  void ContactProbePlayer(Vector2Int cell,Vector2Int direction){
   var p=world.Player;p.Cell=p.From=p.Previous=cell;p.Dir=p.Next=direction;
   p.Waiting=true;p.LastMove=time;p.MoveStarted=time-1000;
  }
  // Find a real corridor of the unchanged maze. Split paths may bend after
  // the intersection, but cannot cross a wall or the player's starting cell.
  Vector2Int[] ContactSnakePath(Vector2Int approach,int cut,bool split){
   for(int y=1;y<world.Height-1;y++)for(int x=1;x<world.Width-1;x++){
    var contact=new Vector2Int(x,y);var start=contact-approach;
    if(!world.Floor(contact)||!world.Floor(start))continue;
    if(!split){
     var body=Enumerable.Range(0,7).Select(i=>contact+approach*(cut==0?i:6-i)).ToArray();
     if(body.All(c=>world.Floor(c)&&!world.Occupied(c))&&!body.Contains(start))return body;
     continue;
    }
    foreach(var side in new[]{new Vector2Int(-approach.y,approach.x),new Vector2Int(approach.y,-approach.x)}){
     var front=new List<Vector2Int>{contact};var back=new List<Vector2Int>{contact};
     bool Walk(List<Vector2Int> path,int count,HashSet<Vector2Int> blocked,Vector2Int first){
      if(path.Count==count+1)return true;
      var options=path.Count==1?new[]{first}:NativeGameplayWorld.Dirs;
      foreach(var d in options){var c=path[path.Count-1]+d;if(c==start||!world.Floor(c)||world.Occupied(c)||path.Contains(c)||blocked.Contains(c))continue;
       path.Add(c);if(Walk(path,count,blocked,first))return true;path.RemoveAt(path.Count-1);}
      return false;
     }
     if(!Walk(front,cut,new HashSet<Vector2Int>(),side))continue;
     if(!Walk(back,6-cut,new HashSet<Vector2Int>(front.Skip(1)),-side))continue;
     return front.AsEnumerable().Reverse().Concat(back.Skip(1)).ToArray();
    }
   }
   throw new InvalidOperationException("No legal snake fixture "+approach+" cut "+cut);
  }
  void ContactScorpionPose(string kind,Vector2Int incoming,double phase,out Vector2Int contact,out Vector2Int approach){
   for(int y=1;y<world.Height-1;y++)for(int x=1;x<world.Width-1;x++){
    var head=new Vector2Int(x,y);var tail=head-incoming;
    if(!world.Floor(head)||!world.Floor(tail)||world.Occupied(head)||world.Occupied(tail))continue;
    var exits=NativeGameplayWorld.Dirs.Where(d=>world.Floor(head+d)&&!world.Occupied(head+d)).ToArray();
    if(kind=="reverse"&&(exits.Length!=1||exits[0]!=-incoming||!world.Floor(tail-incoming)))continue;
    if(kind=="quarter"&&(exits.Length!=2||exits.Contains(incoming)||!exits.Contains(-incoming)))continue;
    if(kind=="still"&&(!world.Floor(head+incoming)||!world.Floor(tail-incoming)))continue;
    var s=world.PlaceScorpion(head,incoming);
    if(kind!="still"){
     // The original AI creates the turn; only the sampling instant is staged.
     world.Player.Cell=new Vector2Int(27,9);s.LastMove=time-218;world.MoveScorpion();
     if(s.Motion.kind!=kind){world.Scorpion=null;continue;}
     time+=s.Motion.duration*phase;world.Time=world.RealTime=realClock=time;
    }
    foreach(var c in new[]{s.Cell,s.Tail})foreach(var d in NativeGameplayWorld.Dirs){
     if(!world.Floor(c-d)||world.ScorpionAt(c-d)||world.Occupied(c-d))continue;
     contact=c;approach=d;scorpionArt=CreateScorpionArt();return;
    }
    world.Scorpion=null;
   }
   throw new InvalidOperationException("No legal scorpion fixture "+kind+" "+incoming);
  }
  IEnumerator ContactWindow(CreatureContactCheck check,Vector2Int cell,Vector2Int approach,int expectedScore,int expectedSnakes,int expectedMass){
   var p=world.Player;ContactProbePlayer(cell-approach,approach);
   // Source/instance creation precedes contact, just as a visible live creature
   // already exists before being eaten. Never pre-render the consumption effect.
   for(int i=0;i<4;i++){Render();yield return null;}
   int decoded=NativeSnakeTextures.DecodeCount;int count=0;string motion="";
   world.Event=e=>{if(e.Kind==check.expectedEvent){count++;if(e.Scorpion!=null)motion=e.Scorpion.Motion.kind;}TraceWorldEvent(e);};
   p.Waiting=false;p.LastMove=time-world.PlayerDelay;
   var visualStart=p.Visual(time);double contactAt=time+1000.0/120;long previous=0;
   Snake firstHeadGhost=null;NativeScorpionArt firstScorpionGhost=null;
   for(int frame=0;frame<60;frame++){
    long now=Stopwatch.GetTimestamp();var sample=MeasureStallFrame(check.name,check.mode,frame,previous);previous=now;
    check.maxCpuMs=Math.Max(check.maxCpuMs,sample.cpuMs);
    check.lateLoads+=sample.stages.Count(s=>s.name.StartsWith("load-"));
    if(frame==0){
     check.contactCpuMs=sample.cpuMs;check.scoreAtContact=p.Score;check.snakeCountAtContact=world.Snakes.Count;
     firstHeadGhost=ghosts.FirstOrDefault();firstScorpionGhost=scorpionGhosts.Count>0?scorpionGhosts[0].art:null;
     check.massAtContact=world.Snakes.Sum(s=>s.Body.Count);
     check.passed=count==1&&p.Cell==cell&&p.Score==expectedScore&&!p.Dead&&!p.Waiting&&p.Ricochet==null&&
      world.Snakes.Count==expectedSnakes&&check.massAtContact==expectedMass;
     if(check.scorpionMotion!=null)check.passed&=world.Scorpion==null&&motion==check.scorpionMotion;
    }
    if(frame>0&&frame<5&&Vector2.Distance(p.Visual(time),visualStart)>.01)check.visualAdvance=true;
    if(check.nextMoveMs==0&&p.Cell!=cell&&p.Cell!=cell-approach)check.nextMoveMs=time-contactAt;
    foreach(var snake in snakes.Values){
     var pose=snake.motion.Evaluate(time);var tip=pose.rail.Sample(pose.Tip);
     check.finite&=!double.IsNaN(pose.length)&&!double.IsInfinity(pose.length)&&pose.length>=0&&
      !double.IsNaN(tip.x)&&!double.IsNaN(tip.y);
    }
    yield return null;
   }
   check.eventCount=count;check.textureDecodes=NativeSnakeTextures.DecodeCount-decoded;
   // Consecutive tail bites can legitimately create a NEW head ghost near the
   // end of the window. Only the first contact and already-expired ghosts must
   // have been disposed, not an animation which is still in progress.
   check.ghostsReleased=(firstHeadGhost==null||!ghosts.Contains(firstHeadGhost))&&
    (firstScorpionGhost==null||!scorpionGhosts.Any(g=>g.art==firstScorpionGhost))&&
    ghosts.All(g=>time<g.eaten+140)&&scorpionGhosts.All(g=>time<g.motion.end);
   check.passed&=check.finite&&check.visualAdvance&&check.ghostsReleased&&check.lateLoads==0&&check.textureDecodes==0;
   creatureChecks.Add(check);
  }
  IEnumerator ProbeCreatureContacts(){
   var args=Environment.GetCommandLineArgs();bool splitOnly=args.Contains("--creature-split-only");
   if(args.Contains("--creature-warm-lead")){
    // A separate fresh-process control: ordinary movement/AI before the FIRST
    // split, without warming the split/consumption path itself.
    Reset(0);yield return DrainProbePreparation();StallSession();world.LifecycleEnabled=false;
    world.Player.Cell=world.Player.From=world.Player.Previous=new Vector2Int(2,1);world.Player.ShieldUntil=time+100000;
    var visits=new Dictionary<Vector2Int,int>();long previous=0;int score=world.Player.Score;
    for(int frame=0;frame<180;frame++){
     StallPilot(visits,true);long now=Stopwatch.GetTimestamp();MeasureStallFrame("pre-contact-walk","spawn",frame,previous);previous=now;yield return null;
    }
    if(world.Player.Score!=score||events.Any(e=>e=="split"||e=="tail"||e=="head"||e=="scorpionBite"))
     throw new InvalidOperationException("Warm-lead control accidentally ate a creature");
   }
   var dirs=NativeGameplayWorld.Dirs;
   foreach(string kind in splitOnly?new[]{"split-middle"}:new[]{"split-middle","split-neck","split-tail","tail","solo-front","head-front"})
    for(int palette=0;palette<(splitOnly?1:5);palette++)for(int direction=0;direction<(splitOnly?1:4);direction++){
     bool split=kind.StartsWith("split");int cut=kind=="split-middle"?3:kind=="split-neck"?1:kind=="split-tail"?5:kind=="tail"?6:0;
     string mode=kind.Contains("front")?((palette+direction)%2==0?"spawn":"power"):"normal";
     Reset(9);yield return DrainProbePreparation();ContactProbeSession(mode);
     var body=ContactSnakePath(dirs[direction],cut,split);if(kind=="solo-front")body=new[]{body[0]};
     var snake=world.AddSnake(body,body.Length==1?-dirs[direction]:body[0]-body[1],palette);
     snake.LastMove=time;AddSnake(snake);
     // Near-midstep fixture clocks remain original; no movement path is replaced.
     var check=new CreatureContactCheck{name=kind+"-"+palette+"-"+direction,mode=mode,palette=palette,direction=direction,cut=cut,
      expectedEvent=split?"split":kind=="tail"?"tail":kind=="solo-front"?"head":"split"};
     int expectedScore=split?10:kind=="tail"?25:125;
     int expectedSnakes=split?3:kind=="solo-front"?1:2;
     int expectedMass=kind=="solo-front"?1:7; // six remaining cells + sentinel
     yield return ContactWindow(check,body[cut],dirs[direction],expectedScore,expectedSnakes,expectedMass);
    }
   foreach(string kind in splitOnly?Array.Empty<string>():new[]{"still-tail","still-claws","quarter","reverse"})
    for(int direction=0;direction<4;direction++)
     foreach(double phase in kind.StartsWith("still")?new[]{0.0}:new[]{.25,.5,.75}){
      Reset(9);yield return DrainProbePreparation();ContactProbeSession("normal");
      string motion=kind.StartsWith("still")?"still":kind;
      ContactScorpionPose(motion,dirs[direction],phase,out var cell,out var approach);
      if(motion=="still"){var s=world.Scorpion;bool tail=kind=="still-tail";cell=tail?s.Tail:s.Cell;approach=tail?s.Dir:-s.Dir;}
      var check=new CreatureContactCheck{name="scorpion-"+kind+"-"+direction+"-"+phase,mode="normal",palette=0,direction=direction,
       expectedEvent="scorpionBite",scorpionMotion=motion};
      yield return ContactWindow(check,cell,approach,150,1,1);
     }
   // Exact replay of the first split after all common game paths have run.
   // Distinguishes first-use work from a repeatable split-algorithm cost.
   for(int repeat=0;repeat<3;repeat++){
    Reset(9);yield return DrainProbePreparation();ContactProbeSession("normal");
    var body=ContactSnakePath(Vector2Int.right,3,true);
    var snake=world.AddSnake(body,body[0]-body[1],0);snake.LastMove=time;AddSnake(snake);
    yield return ContactWindow(new CreatureContactCheck{name="split-middle-repeat-"+repeat,mode="normal",palette=0,direction=0,cut=3,expectedEvent="split"},
     body[3],Vector2Int.right,10,3,7);
   }
   NativeStallTrace.Enabled=false;
   bool passed=creatureChecks.All(c=>c.passed);
   var result=new CreatureContactReport{quality=quality,passed=passed,graphics=SystemInfo.graphicsDeviceName,audioAccepted=sessionAudio.Accepted,
    preparation=preparationSamples.ToArray(),checks=creatureChecks.ToArray(),frames=stallFrames.ToArray(),
    note="Opt-in staged encounters in the unchanged maze, through original full world Tick and event/render paths. Five snake palettes, four approaches, three split locations, tail and protected frontal head eating; scorpion tail/claws and original quarter/reverse turns at 25/50/75%. Includes the entire consumption/cleanup window, no screenshot readback or per-frame file writes. Fixed 120Hz simulation, CPU elapsed submission is not FPS/GPU duration. Fixture setup and two preparation-drain frames excluded. Muted live audio callback; inspect output-device fallback. Split fragments retain original AI and can move immediately. A sentinel keeps the level-clear sequence out of this contact-only test."};
   Directory.CreateDirectory(Path.GetDirectoryName(report));File.WriteAllText(report,JsonUtility.ToJson(result,true));Application.Quit(passed?0:2);
  }
 }
}

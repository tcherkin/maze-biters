using System;using System.IO;using System.Text;using System.Collections.Generic;using UnityEngine;
namespace MazeBiters.NativeStudy {
 [Serializable] public sealed class NativeRecord {public string id,name,createdAt,modeLabel="SOLO",difficulty="MEDIUM",speed="MEDIUM";public int score,level=1,mode=1;public double multiplier=1;public int[] playerIds={1};}
 [Serializable] public sealed class NativeRecordFile {public int version=1;public NativeRecord[] entries;}
 // Native files and the web build's namespaced store both remain independent
 // of the protected original browser game's local storage keys.
 public sealed class NativeHighScores {
  public readonly string FilePath;public NativeRecord[] Entries{get;private set;}=Array.Empty<NativeRecord>();public string Warning{get;private set;}="";
  public NativeHighScores(string file){FilePath=Path.GetFullPath(file);Reload();}
  public static string Sanitize(string value){var b=new StringBuilder(10);foreach(char c in ValidUnicode(value).Normalize(NormalizationForm.FormKD).Replace("ß","SS").Replace("ı","I").ToUpperInvariant()){if(c>='A'&&c<='Z'||c>='0'&&c<='9'||"'@,.-?".IndexOf(c)>=0)b.Append(c);if(b.Length==10)break;}return b.ToString();}
  static string ValidUnicode(string value){var b=new StringBuilder();value=value??"";for(int i=0;i<value.Length;i++){char c=value[i];if(char.IsHighSurrogate(c)){if(i+1<value.Length&&char.IsLowSurrogate(value[i+1])){b.Append(c);b.Append(value[++i]);}}else if(!char.IsLowSurrogate(c))b.Append(c);}return b.ToString();}
  public static NativeRecord[] Normalize(IEnumerable<NativeRecord> input){var map=new Dictionary<string,NativeRecord>(StringComparer.Ordinal);if(input!=null)foreach(var r in input){if(r==null||r.score<=0)continue;string name=Sanitize(r.name);if(name.Length==0)continue;var n=new NativeRecord{id=string.IsNullOrEmpty(r.id)?Guid.NewGuid().ToString():r.id,name=name,score=r.score,level=Math.Max(1,r.level),mode=Math.Max(1,Math.Min(5,r.mode)),createdAt=string.IsNullOrEmpty(r.createdAt)?DateTime.UtcNow.ToString("yyyy-MM-ddTHH:mm:ss.fffZ"):r.createdAt,modeLabel=Short(r.modeLabel,"SOLO",16),difficulty=Short(r.difficulty,"MEDIUM",12),speed=Short(r.speed,"MEDIUM",12),multiplier=double.IsNaN(r.multiplier)||double.IsInfinity(r.multiplier)?1:Math.Round(r.multiplier==0?1:r.multiplier,2,MidpointRounding.AwayFromZero),playerIds=r.playerIds==null?Array.Empty<int>():Array.ConvertAll(r.playerIds.Length<=2?r.playerIds:new[]{r.playerIds[0],r.playerIds[1]},v=>Math.Max(1,v))};map[n.id]=n;}
   var list=new List<NativeRecord>(map.Values);list.Sort((a,b)=>{int c=b.score.CompareTo(a.score);if(c==0)c=StringComparer.Ordinal.Compare(a.createdAt,b.createdAt);return c==0?StringComparer.Ordinal.Compare(a.id,b.id):c;});if(list.Count>25)list.RemoveRange(25,list.Count-25);return list.ToArray();}
  static string Short(string s,string fallback,int max){s=string.IsNullOrEmpty(s)?fallback:s;return s.Length>max?s.Substring(0,max):s;}
  static NativeRecord[] ReadJson(string json){var f=JsonUtility.FromJson<NativeRecordFile>(json);if(f==null||f.version!=1||f.entries==null)throw new InvalidDataException("Invalid leaderboard file");return Normalize(f.entries);}
  static NativeRecord[] Read(string path)=>ReadJson(File.ReadAllText(path));
  public void Reload(){Warning="";
#if UNITY_WEBGL && !UNITY_EDITOR
   try{string json=NativeWebScores.Read();if(json==null){Entries=Array.Empty<NativeRecord>();return;}Entries=ReadJson(json);}
   catch(Exception e)when(e is IOException||e is UnauthorizedAccessException||e is ArgumentException){
    try{string backup=NativeWebScores.Read(true);if(backup==null)throw new InvalidDataException("Missing browser score backup");Entries=ReadJson(backup);Warning="RECOVERED SAVED SCORES";}
    catch{Entries=Array.Empty<NativeRecord>();Warning="SCORES COULD NOT BE READ";}
   }
#else
   if(!File.Exists(FilePath)){Entries=Array.Empty<NativeRecord>();return;}try{Entries=Read(FilePath);}catch(Exception e)when(e is IOException||e is UnauthorizedAccessException||e is ArgumentException){try{Entries=Read(FilePath+".bak");Warning="RECOVERED SAVED SCORES";}catch{Entries=Array.Empty<NativeRecord>();Warning="SCORES COULD NOT BE READ";}}
#endif
  }
  public bool Qualifies(int score)=>score>0&&(Entries.Length<25||score>Entries[Entries.Length-1].score);
  public NativeRecordFile Prepare(NativeRecord candidate,string name){name=Sanitize(name);if(name.Length==0)throw new InvalidOperationException("EMPTY_NAME");if(candidate==null||!Qualifies(candidate.score))throw new InvalidOperationException("NOT_QUALIFIED");var list=new List<NativeRecord>(Entries);var r=JsonUtility.FromJson<NativeRecord>(JsonUtility.ToJson(candidate));r.id=Guid.NewGuid().ToString();r.name=name;r.createdAt=DateTime.UtcNow.ToString("yyyy-MM-ddTHH:mm:ss.fffZ");list.Add(r);return new NativeRecordFile{entries=Normalize(list)};}
  public void Persist(string json){
#if UNITY_WEBGL && !UNITY_EDITOR
   PersistWebMerged(json);
#else
   Directory.CreateDirectory(Path.GetDirectoryName(FilePath));string temp=FilePath+"."+Guid.NewGuid().ToString("N")+".tmp";try{using(var f=new FileStream(temp,FileMode.CreateNew,FileAccess.Write,FileShare.None)){byte[] bytes=new UTF8Encoding(false).GetBytes(json);f.Write(bytes,0,bytes.Length);f.Flush(true);}if(File.Exists(FilePath)){// Keep a recovery copy of unreadable data as well as the last successful save.
     if(!string.IsNullOrEmpty(Warning))File.Copy(FilePath,FilePath+".unreadable-"+DateTime.UtcNow.Ticks,false);
     File.Replace(temp,FilePath,string.IsNullOrEmpty(Warning)?FilePath+".bak":null);}else File.Move(temp,FilePath);
   }finally{if(File.Exists(temp))File.Delete(temp);}
#endif
  }
#if UNITY_WEBGL && !UNITY_EDITOR
  public NativeRecordFile PersistWebMerged(string json)=>new NativeRecordFile{entries=ReadJson(NativeWebScores.Write(json,!string.IsNullOrEmpty(Warning)))};
#endif
  public void Commit(NativeRecordFile file){Entries=file.entries;Warning="";}
 }
 // The original spatial keyboard / pagination, independent of rendering and I/O.
 public sealed class NativeRecordState {
  public const string Keys="ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789-.@?";
  public bool Entry,Navigation,Submitting;public NativeRecord Candidate;public string Draft="",Status="",Highlight="";public int Row,Column,Page,Action=1,Revision;
  public double Entered,ImprintAt=-1e6;public int Imprint=-1;public readonly RecordFocus Focus=new RecordFocus(),Cursor=new RecordFocus();
  public void SetDraft(string value,double t){string next=NativeHighScores.Sanitize(value);if(next==Draft)return;Imprint=next.Length>Draft.Length?next.Length-1:-1;ImprintAt=t;Draft=next;Status="";Revision++;}
  public bool Append(string s,double t){string before=Draft;SetDraft(Draft+s,t);return Draft!=before;}
  public bool Delete(double t){if(Draft.Length==0)return false;SetDraft(Draft.Substring(0,Draft.Length-1),t);return true;}
  public bool Move(int d){if(Submitting)return false;Navigation=true;if(!Entry){if(d<2)return false;Action=(Action+(d==2?2:1))%3;}else if(Row<5){if(d==2)Column=(Column+7)%8;if(d==3)Column=(Column+1)%8;if(d==0)Row=(Row+4)%5;if(d==1){if(Row<4)Row++;else{Row=5;Column=Column<3?0:Column<6?1:2;}}}else{if(d==2)Column=(Column+2)%3;else if(d==3)Column=(Column+1)%3;else if(d==0){Row=4;Column=new[]{1,4,6}[Column];}else return false;}Revision++;return true;}
  public bool ChangePage(int delta,int count){int pages=Math.Max(1,(count+9)/10);if(pages==1)return false;Page=(Page+delta+pages)%pages;Highlight="";Revision++;return true;}
  public static Rect Area(int group,int index){if(group==0)return new Rect(236+index*56,218,48,48);if(group==1)return new Rect(196+index%8*80,308+index/8*48,72,40);return new Rect((group==2?180:176)+index*(group==2?232:236),group==2?570:650,200,54);}
 }
 public sealed class RecordFocus {
  public int Current=-1,Old=-1;public double Alpha,OldAlpha,start,oldStart,changed,observed;
  public void Set(int next,double t){if(Current>=0&&(t<observed||t-observed>1000)){Current=next;Old=-1;Alpha=start=next<0?0:1;OldAlpha=oldStart=0;changed=observed=t;return;}double u=NativeMenuState.Smooth((t-changed)/200);if(Current>=0){Alpha=start+(1-start)*u;OldAlpha=oldStart*(1-u);}observed=t;if(next==Current)return;
   if(next==Old){int prev=Current;start=OldAlpha;oldStart=Alpha;Old=prev;}else{if(OldAlpha<=Alpha){Old=Current;oldStart=Alpha;}else oldStart=OldAlpha;start=0;}Current=next;Alpha=start;OldAlpha=oldStart;changed=t;if(next<0){Old=Current=-1;Alpha=OldAlpha=0;}}
 }
}

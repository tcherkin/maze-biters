using System;
using UnityEngine;
namespace MazeBiters.NativeStudy {
 [Serializable] sealed class WebSpeedBalanceSnapshot {
  public string revision="20261108-speed-life-balance",name;
  public int index,firstLife,lifeInterval;public double rate,points;
  public WebLifeSnapshot[] players;
 }
 [Serializable] sealed class WebLifeSnapshot {public int id,lives,score,nextLife,extraLives;public double exact;}
 public sealed partial class NativeMenu {
  string WebSpeedBalanceState()=>JsonUtility.ToJson(new WebSpeedBalanceSnapshot{index=State.Speed,name=State.SpeedName,rate=State.Rate,points=State.ScoreRate,firstLife=(int)Math.Round(5000*State.ScoreRate),lifeInterval=(int)Math.Round(10000*State.ScoreRate)});
 }
 public sealed partial class NativeGameplayStudy {
  string WebSpeedBalanceState(){
   if(world==null)return "null";
   var players=new WebLifeSnapshot[world.PlayerCount];for(int i=0;i<players.Length;i++){var p=world.GetPlayer(i);players[i]=new WebLifeSnapshot{id=p.Id,lives=p.Lives,score=p.Score,exact=p.ExactScore,nextLife=p.NextLifeScore,extraLives=p.ExtraLives};}
   return JsonUtility.ToJson(new WebSpeedBalanceSnapshot{index=MenuOwner?MenuOwner.State.Speed:2,name=MenuOwner?MenuOwner.State.SpeedName:"MEDIUM",rate=MenuSpeed,points=world.ScoreSpeed,firstLife=world.FirstLifeScore,lifeInterval=world.LifeScoreInterval,players=players});
  }
 }
}

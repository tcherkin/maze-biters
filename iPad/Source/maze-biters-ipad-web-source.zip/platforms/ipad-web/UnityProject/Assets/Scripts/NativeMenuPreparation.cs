using System;
using System.IO;
using System.Collections;
using System.Collections.Generic;
using System.Threading.Tasks;
using UnityEngine;
using UnityEngine.SceneManagement;
namespace MazeBiters.NativeStudy {
 public sealed partial class NativeMenu {
  static readonly bool ColdMenuStart=Array.IndexOf(Environment.GetCommandLineArgs(),"--cold-menu-start")>=0;
  internal static readonly bool InstantMenuStart=!ColdMenuStart&&Array.IndexOf(Environment.GetCommandLineArgs(),"--legacy-menu-preload")<0;
  NativeGameplayStudy preparedGame;
  Scene preparedScene;
  Coroutine menuPreparation;IEnumerator menuPreparationSteps;
  bool preloadFailed;
  string preparationError,preparationFailure;int preparationRetries;double lastPreparationWorkAt;
  double preparationStarted,preparationMs,largestPreparationStepMs;string largestPreparationStage;
  int preparationSteps,preparedBuilds;
  bool PreparedWorldForSelection=>!preloadFailed&&preparedGame&&preparedGame.MenuPrepared&&preparedGame.MenuQuality==State.Quality&&preparedGame.PreparedDifficulty==State.Difficulty&&preparedGame.PreparedMode==State.SelectedMode&&(!NativeBalancedLaunch.Distributed||preparedGame.MenuModeGpuReady);
  bool PreparedForSelection=>MenuArtworkReady&&PreparedWorldForSelection;
  bool LaunchReady=>!preloadFailed&&(ColdMenuStart||preparedGame&&preparedGame.MenuPrepared&&preparedGame.MenuQuality==State.Quality&&preparedGame.PreparedDifficulty==State.Difficulty&&(!InstantMenuStart||preparedGame.AllMenuModesReady));
  bool SelectionAvailable=>NativeBalancedLaunch.Distributed||LaunchReady;

  void CreateMenuPreparation(){
   preparedScene=SceneManager.CreateScene("Prepared first level");
   var previous=SceneManager.GetActiveScene();SceneManager.SetActiveScene(preparedScene);
   try{var go=new GameObject("Prepared first level");go.SetActive(false);preparedGame=go.AddComponent<NativeGameplayStudy>();preparedGame.MenuOwner=this;preparedGame.ConfigureMenuPreparation(State.Quality,State.Difficulty);preparedBuilds++;}
   finally{SceneManager.SetActiveScene(previous);}
  }
  bool TryCreateMenuPreparation(){try{CreateMenuPreparation();return true;}catch(Exception e){FailMenuPreparation(e);return false;}}
  void BeginEarlyMenuPreparation(){if(!WebFiles.Ready)return;if(!InstantMenuStart)return;preparationStarted=Time.realtimeSinceStartupAsDouble;try{if(TryCreateMenuPreparation())preparedGame.StartMenuMazeEarly();}catch(Exception e){FailMenuPreparation(e);}}

  void QueueMenuPreparation(){
   if(!WebFiles.Ready)return;
   if(ColdMenuStart||menuPreparation!=null)return;
   if(preparationStarted==0)preparationStarted=Time.realtimeSinceStartupAsDouble;
   menuPreparationSteps=PrepareMenu();menuPreparation=StartCoroutine(menuPreparationSteps);
  }
  IEnumerator PrepareMenu(){
   yield return null;
   try{
    while(!gameplay){
     Exception failure=null;var core=PrepareMenuCore();
     try{
      while(true){
       bool more=false;object step=null;
       try{more=core.MoveNext();if(more)step=core.Current;}catch(Exception e){failure=e;}
       if(failure!=null||!more)break;yield return step;
      }
     }finally{try{(core as IDisposable)?.Dispose();}catch(Exception e){failure=failure??e;}}
     if(failure==null)break;FailMenuPreparation(failure);yield return null;
    }
   }finally{menuPreparation=null;}
  }
  IEnumerator PrepareMenuCore(){
   // Present the original menu before the first upload, then keep yielding
   // between bounded preparation units. No gameplay Update/input/audio runs.
   yield return null;yield return null;
   while(!gameplay){
    if(preloadFailed){
     if(preparationRetries>=2){
      preparationError="Подготовката не завърши. Изберете режим отново за нов опит.";
      State.CancelStart();confirmationPresentedFrame=-1;yield return null;continue;
     }
     preparationRetries++;State.SignalPrepared(Now,false);confirmationPresentedFrame=-1;
     yield return null;
     if(preparedGame){preparedGame.DisposeMenuPreparation();preparedGame=null;}
     if(preparedScene.IsValid()&&preparedScene.isLoaded)yield return SceneManager.UnloadSceneAsync(preparedScene);
     preloadFailed=false;menuArtworkFailed=false;yield return null;
    }
    if(!preparedGame||preparedGame.MenuQuality!=State.Quality){
     if(preparedGame){
      preparedGame.DisposeMenuPreparation();preparedGame=null;
      yield return SceneManager.UnloadSceneAsync(preparedScene);
     }
     if(!TryCreateMenuPreparation()){yield return null;continue;}
    }
    if(!preparedGame.MenuAssetsReady){
     foreach(var unused in RunMenuSteps(preparedGame.PrepareMenuAssets()))yield return null;
     if(preloadFailed)continue;
     if(preparedGame.MenuQuality!=State.Quality)continue;
    }
    if(InstantMenuStart&&preparedGame.AllMenuModesReady&&!PreparedWorldForSelection&&preparedGame.MenuQuality==State.Quality&&preparedGame.PreparedDifficulty==State.Difficulty){
     if(NativeBalancedLaunch.Distributed){foreach(var unused in RunMenuSteps(preparedGame.PrepareSelectedMenuMode(State.SelectedMode)))yield return null;if(preloadFailed)continue;if(!PreparedWorldForSelection)continue;}
     else preparedGame.SelectPreparedMenuMode(State.SelectedMode);
    }
    if(!PreparedWorldForSelection){
     preparedGame.ConfigureMenuPreparation(State.Quality,State.Difficulty);
     foreach(var unused in RunMenuSteps(preparedGame.PrepareMenuWorld()))yield return null;
     if(preloadFailed)continue;
     preparationMs=(Time.realtimeSinceStartupAsDouble-preparationStarted)*1000;
    }
    yield return null;
   }
   menuPreparation=null;
  }
  IEnumerable<object> RunMenuSteps(IEnumerable<object> sequence){
   using(var steps=sequence.GetEnumerator()){
    var slice=System.Diagnostics.Stopwatch.StartNew();
    double lastProgress=Time.realtimeSinceStartupAsDouble;
    while(true){
     if(preloadFailed)yield break;
     // Give navigation/setting feedback a clear frame before more background
     // uploads, and yield after a slow frame. Never defer the menu's own Update.
     if(NativeBalancedLaunch.Distributed&&!State.Pending&&Now-Math.Max(State.Changed,Math.Max(State.PulseAt,State.ActiveAt))<35&&Now-lastPreparationWorkAt<100){yield return null;slice.Restart();continue;}
     var previous=SceneManager.GetActiveScene();bool more=false;Exception failure=null;
     var watch=System.Diagnostics.Stopwatch.StartNew();
     if(NativeSmoothLoading.Profile)NativeStallTrace.Begin();
     try{NativeResponsiveStartFaults.BeforePreparationStep();SceneManager.SetActiveScene(preparedScene);more=steps.MoveNext();
      if(!more||(steps.Current as string)!="wait")lastProgress=Time.realtimeSinceStartupAsDouble;
      else if(Time.realtimeSinceStartupAsDouble-lastProgress>90)throw new TimeoutException("Preparation made no progress for 90 seconds");
     }
     catch(Exception e){failure=e;}
     finally{SceneManager.SetActiveScene(previous);if(watch.Elapsed.TotalMilliseconds>largestPreparationStepMs){largestPreparationStepMs=watch.Elapsed.TotalMilliseconds;largestPreparationStage=more?steps.Current as string:"completion";}}
     preparationSteps++;
     lastPreparationWorkAt=Now;
     if(NativeSmoothLoading.Profile)foreach(var span in NativeStallTrace.End())NativeStartupLoading.AddMs("detail "+span.name,span.ms);
     NativeStartupLoading.AddMs(more?steps.Current as string??"unnamed step":"step completion",watch.Elapsed.TotalMilliseconds);
     if(failure!=null){FailMenuPreparation(failure);yield break;}
     if(!more||preparedGame.MenuQuality!=State.Quality)yield break;
     if((steps.Current as string)=="wait"||slice.Elapsed.TotalMilliseconds>=(NativeBalancedLaunch.Distributed?2:3)){yield return null;slice.Restart();}
    }
   }
  }
  bool InstallMenuPreparation(){
   if(ColdMenuStart)return false;
   if(!NativeBalancedLaunch.Distributed&&InstantMenuStart&&LaunchReady&&!PreparedForSelection)preparedGame.SelectPreparedMenuMode(State.SelectedMode);
   if(!PreparedForSelection)return false;
   StopMenuPreparation();
   runScene=preparedScene;gameplay=preparedGame;preparedGame=null;
   SceneManager.SetActiveScene(runScene);
   gameplay.ReleaseMenuPreparation();
   return true;
  }
  void StopMenuPreparation(){
   var pending=menuPreparationSteps;menuPreparationSteps=null;
   if(menuPreparation!=null)StopCoroutine(menuPreparation);menuPreparation=null;
   (pending as IDisposable)?.Dispose();
  }
  void CancelMenuPreparation(){
   StopMenuPreparation();
   if(preparedGame){preparedGame.DisposeMenuPreparation();preparedGame=null;}
  }
 }
 public sealed partial class NativeGameplayStudy {
  bool menuPreparing,menuInitialized;
  string menuQuality;
  int menuDifficulty,menuMode=1;
  public int PreparedMode=>menuMode;
  public bool MenuPrepared{get;private set;}
  public int PreparedDifficulty=>menuDifficulty;
  public bool MenuAssetsReady=>menuInitialized;
  public void StartMenuMazeEarly(){if(EarlyMazePreparation){NativeGlassPresentation.EnableGameplay();EnsureMenuMaze();MenuMazeStartedBeforeAssets=menuMazeTask!=null;}}
  PreparedMaze menuInitialMaze;
  Task<PreparedMaze> menuMazeTask;NativeSnakeTextures.Prefetch menuSnakeSources;
  bool menuMazePublishedEarly;
  System.Threading.CancellationTokenSource menuMazeCancellation;
  int menuMazeDifficulty=-1;string menuMazeQuality;
  public bool MenuMazeStartedBeforeAssets{get;private set;}

  public void ConfigureMenuPreparation(string q,int d){
   ClearMenuModes();
   menuPreparing=true;HideForMenu=true;MenuPrepared=false;
   menuQuality=quality=q;menuDifficulty=d;menuMode=MenuOwner?MenuOwner.State.SelectedMode:1;difficultyOverride=d;
  }
  public IEnumerable<object> PrepareMenuAssets(){
   // Start the pure CPU first-level painter before loading the shared animation
   // banks. Menu input and the original menu rendering remain responsive.
   StartMenuMazeEarly();
   foreach(var step in NativeStartupLoading.WaitForCpu())yield return step;
   if(NativeStartupLoading.Assets&&quality=="hd"&&bootMazeAdopted){
    // Release the large first-map CPU pixels before loading animation banks.
    // The same unpublished GPU textures will be installed by PrepareMenuWorld.
    while(!menuMazeTask.IsCompleted)yield return "wait";
    var art=menuMazeTask.GetAwaiter().GetResult().art;menuMazePublishedEarly=true;
    while(!art.PublishStep())yield return "early maze upload";
    yield return "early maze upload";
   }
   foreach(var step in InitializeGameplaySteps())yield return step??"core assets";
   foreach(var step in bank.PrepareGameplaySteps(NativeSmoothLoading.Enabled))yield return (step as string)=="wait"?"wait":"turn banks";
   if(NativeBalancedLaunch.Distributed){coopArt=new NativeCoopArt(quality,deferred:true);coopArtQuality=quality;foreach(var step in coopArt.LoadSteps(quality))yield return "aura source";}
   // Spread collection across frames while the menu remains interactive.
   if(NativeBalancedLaunch.Distributed&&UnityEngine.Scripting.GarbageCollector.isIncremental){
    while(UnityEngine.Scripting.GarbageCollector.CollectIncremental(2000000))yield return "wait";
    yield return "menu collection";
   }
   scorpionImages=new NativeScorpionImages();foreach(var step in scorpionImages.PrepareSteps())yield return "scorpion source";
   using(var warm=new NativeScorpionArt(quad,1,scorpionImages))warm.Prepare(quality);
   preparedScorpionQuality=quality;yield return "scorpion shader";
   sessionArt.SetQuality(quality);if(NativeSmoothLoading.Enabled)yield return "session art";hud?.SetQuality(quality);yield return "HUD and session art";
   foreach(var step in PrepareMenuSnakeSources())yield return step;
   foreach(var step in PrepareGameplayLogicSteps(NativeSmoothLoading.Enabled))yield return step??"logic";
   menuInitialized=true;
  }
  public IEnumerable<object> PrepareMenuWorld(){
   MenuPrepared=false;
   if((menuMode==0||menuMode==3||menuMode==4)){NativeAllyValidation.Prepare();yield return "original ally decisions";}
   // GAME OVER has already prepared this same first-level scene using the
   // resident banks/target. Finish any outstanding units without playing it.
   if(restartPreparing&&restartDifficulty==menuDifficulty&&(restartMode==menuMode||NativeBalancedLaunch.Distributed)){
    if(nextScene!=null)sessionAudio.PrepareTrack(nextScene.preview.MusicTrack);
    while(nextMazeTask!=null||publishingMaze!=null||nextMaze!=null&&nextScene?.ready!=true){
     PollNextMaze();PollNextScene();yield return "wait";
     if(nextSceneFailed)break;
    }
    if(nextScene?.ready==true){
     var preview=nextScene.preview;
     time=realClock=1000;random=restartRandom;world=preview;world.Random=Random;
     menuMode=preview.Mode;
     mazeSeed=restartSeed;difficultyIndex=menuDifficulty;
     generator=new NativeMazeGenerator(mazeSeed,world.Difficulty);
     currentGeneratedLevel=nextMaze.level;world.LevelLoader=LoadCampaignLevel;world.Event=OnEvent;
     hud?.BeginLevel(realClock,true);ResetGameplayCamera();
     if(!TryInstallNextScene())throw new InvalidOperationException("Prepared restart scene could not be installed");
     restartPreparing=false;
     yield return null;
     foreach(var step in FinishMenuWorld())yield return step;
     yield break;
    }
   }
   CancelNextMaze();restartPreparing=false;EnsureMenuMaze();
   while(!menuMazeTask.IsCompleted)yield return "wait";
   var pending=menuMazeTask;menuMazeTask=null;
   try{menuInitialMaze=pending.GetAwaiter().GetResult();menuMazePublishedEarly=false;}finally{menuMazeCancellation?.Dispose();menuMazeCancellation=null;}while(!menuInitialMaze.art.PublishStep())yield return "maze upload";yield return "maze upload";
   foreach(var step in PrepareMenuSnakeSources())yield return step;
   time=realClock=1000;Reset(12);
   foreach(var step in RebuildSessionVisualsSteps())yield return step;
   yield return "scene construction";yield return "wait";yield return "wait";
   if(NativeBalancedLaunch.Distributed){foreach(var step in PrepareSceneGpuSteps(true))yield return step;}else PrepareSceneGpu();preparationFrames=0;yield return "scene GPU";
   if(!NativeBalancedLaunch.Distributed){GC.Collect();yield return "wait";}
   foreach(var step in FinishMenuWorld())yield return step;
  }
  static PreparedMaze BuildMenuMaze(uint seed,double difficulty,string source,string artQuality=null,bool packForBoot=false){
   long mark=NativeStartupLoading.Stamp();
   var level=new NativeMazeGenerator(seed,difficulty).Generate(1);
   // Ordinary menu/GAME OVER maps avoid immediate compression/decompression.
   // Only the early 4K boot cache is packed while shared assets are loading.
   var result=new PreparedMaze{level=level,art=new NativeMazeArtwork(level,1,true,true,source,glassQuality:artQuality,packGlassCache:false)};
   if(packForBoot)result.art.PackStartupStaging();
   NativeStartupLoading.Add("map CPU worker",mark);return result;
  }
  void EnsureMenuMaze(){
   // Mode/speed/music do not change generated geometry. An in-flight first map
   // can therefore survive those choices, but never a difficulty/quality change.
   if(menuMazeTask!=null&&menuMazeDifficulty==menuDifficulty&&menuMazeQuality==quality)return;
   if(TakeBootMaze())return;
   CancelMenuMaze(false);ConfigureGeneration();
   menuMazeDifficulty=menuDifficulty;menuMazeQuality=quality;
   uint seed=mazeSeed;double difficulty=NativeMazeGenerator.Difficulties[difficultyIndex];
   string source=Path.Combine(WebFiles.Root,"Reference/maze-brushes"),artQuality=GlassQuality;
   menuMazeTask=NativeMazeWorker.Run(()=>BuildMenuMaze(seed,difficulty,source,artQuality),out menuMazeCancellation);
  }
  IEnumerable<object> FinishMenuWorld(){
   // Display-ready frame uses the ORIGINAL starting camera, not the wide
   // off-screen GPU-preflight camera. It does not consume a simulation tick.
   discardPreparationDelta=false;preparationLightFrame=true;Render();
   foreach(var step in NativePreparation.DrainSteps(target,NativeSmoothLoading.Enabled))yield return step;
   sessionAudio.PrepareTrack(world.MusicTrack);
   while(!sessionAudio.PreparedTrackReady)yield return "wait";
   menuSnakeSources?.Dispose();menuSnakeSources=null;
   preparationFrames=0;
   if(NativeMenu.InstantMenuStart)foreach(var step in PrepareMenuModes())yield return step;
   CaptureStartupProof();MenuPrepared=true;menuInitialized=true;
  }
  NativeMazeArtwork TakeMenuInitialMaze(){
   if(menuInitialMaze==null)return null;
   var result=menuInitialMaze.art;menuInitialMaze=null;return result;
  }
  void CancelMenuMaze(bool releaseSources=true){
   menuMazeDifficulty=-1;menuMazeQuality=null;
   if(releaseSources){menuSnakeSources?.Dispose();menuSnakeSources=null;}
   menuInitialMaze?.art.Discard();menuInitialMaze=null;
   if(menuMazeTask!=null){
    var pending=menuMazeTask;menuMazeTask=null;var cancellation=menuMazeCancellation;menuMazeCancellation=null;cancellation?.Cancel();
    if(menuMazePublishedEarly){pending.GetAwaiter().GetResult().art.Discard();cancellation?.Dispose();}
    else WebWorkQueue.Continue(pending,t=>{try{if(t.Status==TaskStatus.RanToCompletion)t.Result.art.DisposeStaging();else if(t.IsFaulted){_ = t.Exception;}}finally{cancellation?.Dispose();}});
   }
   menuMazePublishedEarly=false;bootMazeAdopted=false;
  }
  IEnumerable<object> PrepareMenuSnakeSources(){
   if(menuSnakeSources==null)menuSnakeSources=new NativeSnakeTextures.Prefetch(Colors);
   while(!menuSnakeSources.Step())yield return "wait";
  }
  public void ReleaseMenuPreparation(){
   CaptureInstantMenuProof();ReleaseUnusedMenuPlayers();ClearMenuModes();
   world.ScoreSpeed=MenuSpeed;world.ClearAllKeys();
   menuPreparing=false;HideForMenu=false;MenuPrepared=false;
   // The first visible update must not inherit the menu/preparation delta.
   discardPreparationDelta=true;enabled=true;gameObject.SetActive(true);
   if(!NativeMenu.InstantMenuStart)sessionAudio.ResetBus();else sessionAudio.BeginPreparedSession();
   sessionAudio.SetTrack(world.MusicTrack,realClock);
  }
  public void HoldForMenu(){ClearMenuModes();menuPreparing=true;MenuPrepared=false;HideForMenu=true;enabled=false;}
  public void DisposeMenuPreparation()=>DisposeGameplayResources();
 }
}


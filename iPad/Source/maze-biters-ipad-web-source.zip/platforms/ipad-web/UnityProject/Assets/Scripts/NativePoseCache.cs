using System;
using UnityEngine;
namespace MazeBiters.NativeStudy {
 // Cache only exactly unchanged authored poses. Simulation and animation clocks
 // remain live. --no-pose-cache is a diagnostic before/after control, not quality.
 public static class NativePoseCache {
  public static bool Enabled=true;
  public static bool Test,Capture;
  public static long PoseCalls,PoseHits,NeonCalls,NeonHits,EyeCalls,EyeHits;
  public static string Variant=>Enabled?"after":"before";
  [RuntimeInitializeOnLoadMethod(RuntimeInitializeLoadType.BeforeSceneLoad)] static void Boot(){
   var args=Environment.GetCommandLineArgs();Enabled=Array.IndexOf(args,"--no-pose-cache")<0;
   Capture=Array.IndexOf(args,"--pose-cache-capture")>=0;
   Test=Capture||Array.IndexOf(args,"--pose-cache-benchmark")>=0;
  }
  public static void ResetCounters(){PoseCalls=PoseHits=NeonCalls=NeonHits=EyeCalls=EyeHits=0;}
 }
 internal struct NativePoseKey {
  string family,palette;int from,to,mouth,blink;double mix;
  public NativePoseKey(NativeTurnActor actor,TurnPose pose,int mouthFrame,int blinkFrame){
   family=actor.Family;palette=actor.ArtPalette;mouth=mouthFrame;blink=blinkFrame;
   // Same endpoint classification as the compositor; no new quantization.
   bool cardinal=pose.from==pose.to||pose.mix<1e-9||pose.mix>1-1e-9;
   from=cardinal?(pose.mix>1-1e-9?pose.to:pose.from):pose.from;
   to=cardinal?from:pose.to;mix=cardinal?0:pose.mix;
  }
  public bool Same(NativePoseKey other)=>family==other.family&&palette==other.palette&&from==other.from&&to==other.to&&mouth==other.mouth&&blink==other.blink&&mix==other.mix;
 }
}

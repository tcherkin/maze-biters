using System;
using UnityEngine;
using UnityEngine.InputSystem;
namespace MazeBiters.NativeStudy {
 // Xbox/standard controllers use Unity's device layouts, not OS-specific legacy axes.
 // Positive Y is converted to the game's down-positive coordinates exactly once.
 public struct NativePadState {
  public int Id;public Vector2 Stick;public bool Left,Right,Up,Down,Confirm,Back,Pause,Exit;
  public bool Connected=>Id!=0;
  public int Directions=>NativeGamepadInput.Directions(this);
  public Vector2? Tilt {
   get {var digital=new Vector2((Right?1:0)-(Left?1:0),(Down?1:0)-(Up?1:0));
    if(digital!=Vector2.zero)return digital;
    return Stick.sqrMagnitude>=.16f*.16f?(Vector2?)Stick:null;}
  }
 }
 public static class NativeGamepadInput {
  public const float DeadZone=.42f;
  static readonly string[,] Keys={{"GamepadSlot0:left","GamepadSlot0:right","GamepadSlot0:up","GamepadSlot0:down"},{"GamepadSlot1:left","GamepadSlot1:right","GamepadSlot1:up","GamepadSlot1:down"}};
  static readonly Vector2Int[] Dirs={Vector2Int.left,Vector2Int.right,new Vector2Int(0,-1),new Vector2Int(0,1)};
  [RuntimeInitializeOnLoadMethod(RuntimeInitializeLoadType.BeforeSceneLoad)]
  static void Initialize(){InputSystem.pollingFrequency=120;InputSystem.settings.updateMode=InputSettings.UpdateMode.ProcessEventsInDynamicUpdate;}
  public static NativePadState Read(Gamepad pad){
   if(pad==null||!pad.added||!pad.enabled)return default;
   // Read unprocessed stick values: the original game applies its own .42/.16 thresholds.
   var axis=pad.leftStick.ReadUnprocessedValue();
   return new NativePadState{Id=pad.deviceId,Stick=new Vector2(axis.x,-axis.y),
    Left=pad.dpad.left.isPressed,Right=pad.dpad.right.isPressed,Up=pad.dpad.up.isPressed,Down=pad.dpad.down.isPressed,
    Confirm=pad.buttonSouth.wasPressedThisFrame||pad.startButton.wasPressedThisFrame,
    Back=pad.buttonEast.wasPressedThisFrame,Pause=pad.startButton.wasPressedThisFrame,Exit=pad.selectButton.wasPressedThisFrame};
  }
  public static NativePadState ReadSlot(int slot){
   int connected=0;foreach(var pad in Gamepad.all)if(pad.added&&pad.enabled){if(connected++==slot)return Read(pad);}return default;
  }
  public static int Directions(NativePadState p){
   if(!p.Connected)return 0;int mask=(p.Left?1:0)|(p.Right?2:0)|(p.Up?4:0)|(p.Down?8:0);
   // D-pad wins independently on each axis, preserving the original two-key diagonal cadence.
   if(!p.Left&&!p.Right&&Math.Abs(p.Stick.x)>=DeadZone)mask|=p.Stick.x<0?1:2;
   if(!p.Up&&!p.Down&&Math.Abs(p.Stick.y)>=DeadZone)mask|=p.Stick.y<0?4:8;
   return mask;
  }
  public static void Sync(NativeGameplayWorld world,int slot,NativePadState pad,bool active){
   if(world==null||slot<0||slot>1)return;
   var target=slot<world.PlayerCount?world.GetPlayer(slot):null;
   if(target!=null&&target.IsAI)target=null;
   bool moving=active&&!world.GameOver&&!world.Transition&&target!=null&&!target.Dead&&target.Lives>0;
   int desired=moving?pad.Directions:0;
   // Remove only this controller's keys. Keyboard input and the other player's pad survive.
   for(int i=0;i<world.PlayerCount;i++){var p=world.GetPlayer(i);using(world.ForPlayer(p))
    for(int d=0;d<4;d++)if(p!=target||(desired&(1<<d))==0)world.Release(Keys[slot,d]);}
   if(target==null)return;
   target.GamepadTilt=moving&&pad.Connected?pad.Tilt:null;
   if(desired==0)return;
   using(world.ForPlayer(target)){
    for(int d=0;d<4;d++)if((desired&(1<<d))!=0&&!target.Keys.ContainsKey(Keys[slot,d]))world.Press(Keys[slot,d],Dirs[d]);
    int order=-1;foreach(var held in target.Keys.Values)if(held.order>order){order=held.order;target.Next=held.dir;}
    target.Pointer=null;target.PointerMomentum=false;target.Waiting=false;
   }
  }
 }
 public sealed class NativePadMenu {
  int identity,held,repeat=-1;double repeatAt;
  static readonly int[] Bits={4,8,1,2}; // menu: up, down, left, right
  public void Reset(){identity=held=0;repeat=-1;repeatAt=0;}
  public int Move(NativePadState pad,double time){
   if(identity!=pad.Id){Reset();identity=pad.Id;}
   int current=pad.Directions,result=-1;
   for(int i=0;i<4;i++)if((current&Bits[i])!=0&&(held&Bits[i])==0){result=repeat=i;repeatAt=time+360;break;}
   if(result<0&&repeat>=0&&(current&Bits[repeat])!=0&&time>=repeatAt){result=repeat;repeatAt=time+135;}
   if(repeat>=0&&(current&Bits[repeat])==0){repeat=-1;for(int i=0;i<4;i++)if((current&Bits[i])!=0){repeat=i;break;}repeatAt=repeat<0?0:time+360;}
   held=current;return result;
  }
 }
}


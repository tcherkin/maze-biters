using System;
namespace MazeBiters.NativeStudy {
 public sealed partial class NativeMazeGenerator {
  public const int PaletteRepeatGap=4;
  // Pure seeded sequence: menu preloading, cancelled jobs, out-of-order requests
  // and next-level warming cannot consume/re-shuffle the campaign's colour bag.
  // The palette stream never advances topology, spawn or creature RNG.
  public int ThemeIndex(int level){
   if(LegacyPaletteOrder)return LegacyThemeIndex(level);
   int count=Themes.Length,target=Math.Max(1,level)-1,gap=Math.Min(PaletteRepeatGap,count-1);
   var recent=new int[gap];for(int i=0;i<gap;i++)recent[i]=-1;
   var remaining=new bool[count];var candidates=new int[count];int picked=0,used=0;
   for(int cycle=0;cycle<=target/count;cycle++){
    for(int i=0;i<count;i++)remaining[i]=true;
    var paletteRandom=Rng(LevelSeed(cycle+1,734));
    for(int slot=0;slot<count;slot++){
     int available=0;
     for(int color=0;color<count;color++){
      if(!remaining[color])continue;bool blocked=false;
      for(int j=0;j<gap;j++)if(recent[j]==color){blocked=true;break;}
      if(!blocked)candidates[available++]=color;
     }
     if(available==0)throw new InvalidOperationException("Palette bag exhausted before cycle completion");
     picked=candidates[Floor(paletteRandom()*available)];remaining[picked]=false;
     if(gap>0)recent[used%gap]=picked;
     if(used++==target)return picked;
    }
   }
   return picked;
  }
 }
}

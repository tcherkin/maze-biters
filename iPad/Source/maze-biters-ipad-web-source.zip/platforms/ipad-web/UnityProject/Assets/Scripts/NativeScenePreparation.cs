using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using UnityEngine;
namespace MazeBiters.NativeStudy {
 public sealed partial class NativeGameplayStudy {
  bool scenePreparationPending,preparingScene,coldSceneControl;
  [Serializable] sealed class ScenePreparationSample {
   public string quality;public int scenario,snakes,hunters,passes;
   public double ms;public long snakeSurfaceBytes,neonTargetBytes;
  }
  readonly List<ScenePreparationSample> scenePreparationSamples=new List<ScenePreparationSample>();

  // Run on the ACTUAL scene/targets after deferred destruction, not on a
  // tiny surrogate camera. The resources stay resident and are reused in play.
  // No Tick/input/audio/SFX or simulation delta is consumed here.
  void PrepareSceneGpu(){foreach(var step in PrepareSceneGpuSteps(false)){} }
  IEnumerable<object> PrepareSceneGpuSteps(bool asynchronous){
   if(!scenePreparationPending||coldSceneControl||logicPreparationInstance)yield break;
   if(world==null||neon==null||!target||!actors.ContainsKey(1))yield break;
   long start=Stopwatch.GetTimestamp();
   var restore=new List<Action>();
   var active=RenderTexture.active;
   bool priorLight=preparationLightFrame;
   try{
    preparingScene=true;preparationLightFrame=true;SetGameplayCameraView(288,200,1);
    restore.Add(dusk.PreserveClock());restore.Add(neon.PreserveClocks());
    foreach(var a in actors.Values){
     var aura=a.aura;a.aura=aura.Copy();restore.Add(()=>a.aura=aura);
     var saved=a.blink;a.blink=saved.Copy();restore.Add(()=>a.blink=saved);
     if(a.neon!=null)restore.Add(a.neon.PreserveClock());
    }
    // A quality change can occur midway through intake or a blocked snake.
    // Preserve the rail hold clock as well as glint/blink randomness.
    foreach(var s in snakes.Values.Concat(ghosts)){
     var motion=s.motion;s.motion=motion.Capture();
     restore.Add(()=>s.motion=motion);
    }
    void SaveScorpion(NativeScorpionArt s){if(s==null)return;var clock=s.Clock;s.Clock=clock.Copy();restore.Add(()=>s.Clock=clock);}
    SaveScorpion(scorpionArt);foreach(var g in scorpionGhosts)SaveScorpion(g.art);
    // Normally created by Reset; handle a not-yet-visible initial scorpion too.
    if(world.Scorpion!=null&&scorpionArt==null){scorpionArt=CreateScorpionArt();SaveScorpion(scorpionArt);}
    if(asynchronous){
     using(var commands=new UnityEngine.Rendering.CommandBuffer{name="Menu one-snake surface preparation"}){
      for(int i=0;i<world.Snakes.Count;i++){
       var model=world.Snakes[i];var snake=snakes[model.Id];var pose=snake.motion.Evaluate(time);
       snake.art.Prepare(pose);snake.art.ReservedDensity=fixedCamera?0:target.height/(DisplayFrame.Height/2);
       commands.Clear();commands.SetRenderTarget(target);commands.SetViewProjectionMatrices(camera.worldToCameraMatrix,camera.projectionMatrix);
       snake.art.Submit(commands,i+1,camera);Graphics.ExecuteCommandBuffer(commands);neon.PrimeSnakeSurface(i,pose);
       yield return "wait";
      }
     }
    }
    for(int pass=0;pass<2;pass++){
     preparationLightFrame=true;
     Render();
     if(pass==0&&world.Multiplayer)for(int i=0;i<world.PlayerCount;i++){var p=world.GetPlayer(i);actors[p.Id].leader.Warm(actors[p.Id].art,p,time);if(asynchronous)yield return "leader GPU";}
     // Completion, not merely command submission: first-use GPU work must
     // finish before the loading gate releases the player's controls.
     foreach(var step in NativePreparation.DrainSteps(target,asynchronous))yield return step;
     if(asynchronous)yield return "scene GPU pass";
    }
    scenePreparationPending=false;
    scenePreparationSamples.Add(new ScenePreparationSample{
     quality=quality,scenario=scenario,snakes=snakes.Count,hunters=world.Hunters.Count,passes=2,
     ms=(Stopwatch.GetTimestamp()-start)*1000.0/Stopwatch.Frequency,
     snakeSurfaceBytes=snakes.Values.Sum(s=>s.art.SurfaceBytes)+ghosts.Sum(s=>s.art.SurfaceBytes),
     neonTargetBytes=neon.TargetBytes});
   }finally{
    for(int i=restore.Count-1;i>=0;i--)restore[i]();
    preparingScene=false;preparationLightFrame=priorLight;ApplyGameplayCamera();RenderTexture.active=active;
   }
  }
 }
}

using System;
using System.IO;
using UnityEngine;
using UnityEngine.Rendering;
namespace MazeBiters.NativeStudy {
 // Original DUSK recipe: 576x400 RGBA8, 80% tint, authored halo / beam,
 // destination-out in the original order. Reference fixtures retain their 65ms
 // response; live gameplay follows the rendered head pose directly. No Light2D
 // approximation, bloom or colour grading is inserted into the look.
 public sealed class NativeDusk:IDisposable {
  public readonly RenderTexture mask;readonly Camera camera;readonly GameObject root,halo,beamPivot,overlay;
  readonly Texture2D haloTexture,beamTexture;readonly Material haloMaterial,beamMaterial,overlayMaterial,powerMaterial;readonly GameObject powerBeam;
  readonly CommandBuffer direct=new CommandBuffer{name="Exact DUSK compositor"};readonly Mesh sharedQuad;readonly Transform beamTransform;
  double priorLife=double.NaN;bool priorDead;double priorPower=double.NaN;double angle;bool initialized;Vector2 priorPosition;double priorAngle=double.NaN;
  bool glassLighting;float auraSize=1;Vector2 auraVector;Texture2D glassCoverage;
  public const float GlassDarkness=.45f,AuraCoreRadius=12.16f,AuraRearScale=24,AuraFrontScale=68,AuraTailStart=2.35f,AuraTailEnd=3,AuraQuadSize=448;
  public bool GlassLightingEnabled=>glassLighting;
  public Vector2 AuraVector=>auraVector;public float AuraSize=>auraSize;
  public double Angle=>angle;
  internal Action PreserveClock(){
   double savedAngle=angle;bool savedInitialized=initialized,savedGlass=glassLighting;var savedVector=auraVector;var savedCoverage=glassCoverage;float savedSize=auraSize;
   // The GPU mask is a cache, not a clock. Invalidate it after the preview so
   // the first playable frame redraws from its ORIGINAL angular history.
   return ()=>{ConfigureGlassLighting(savedGlass,savedCoverage);angle=savedAngle;initialized=savedInitialized;auraVector=savedVector;auraSize=savedSize;priorAngle=double.NaN;};
  }
  public NativeDusk(Mesh quad,Camera mainCamera){
   sharedQuad=quad;
   root=new GameObject("Native DUSK");camera=root.AddComponent<Camera>();camera.enabled=false;camera.orthographic=true;camera.orthographicSize=200;camera.aspect=576f/400;
   camera.transform.position=new Vector3(288,-200,-10);camera.cullingMask=1<<29;camera.clearFlags=CameraClearFlags.SolidColor;
   camera.backgroundColor=new Color(0,3/255f*.8f,12/255f*.8f,.8f);camera.allowHDR=false;camera.allowMSAA=false;
   mask=new RenderTexture(576,400,0,RenderTextureFormat.ARGB32){name="Original-resolution DUSK mask",antiAliasing=1,filterMode=FilterMode.Bilinear,wrapMode=TextureWrapMode.Clamp};mask.Create();camera.targetTexture=mask;
   haloTexture=Load("light-halo.png");beamTexture=Load("light-beam.png");
   haloMaterial=new Material(Shader.Find("MazeBiters/EraseLight")){mainTexture=haloTexture};beamMaterial=new Material(Shader.Find("MazeBiters/EraseLight")){mainTexture=beamTexture};
   halo=Quad("Halo",quad,haloMaterial,29,0);halo.transform.localScale=new Vector3(89.6f,89.6f,1);
   beamPivot=new GameObject("Beam pivot");var beam=Quad("Beam",quad,beamMaterial,29,1);beam.transform.SetParent(beamPivot.transform,false);beam.transform.localPosition=new Vector3(0,56,0);beam.transform.localScale=new Vector3(144,112,1);
   beamTransform=beam.transform;powerMaterial=new Material(beamMaterial);powerBeam=Quad("Original power beam intensity",quad,powerMaterial,29,2);powerBeam.transform.SetParent(beamPivot.transform,false);powerBeam.SetActive(false);
   overlayMaterial=new Material(Shader.Find("MazeBiters/PremultipliedImage")){mainTexture=mask};overlay=Quad("DUSK compositing",quad,overlayMaterial,0,20);overlay.transform.position=new Vector3(0,0,-2);overlay.transform.localScale=new Vector3(576,400,1);
   mainCamera.cullingMask&=~((1<<29)|(1<<30));
  }
  // Production opts in explicitly; legacy probes/fixtures retain their original
  // texture recipe and cache/command-buffer path unless configured otherwise.
  public void ConfigureGlassLighting(bool enabled,Texture2D mazeCoverage=null){
   if(glassLighting==enabled){SetGlassCoverage(mazeCoverage);return;}
   var light=Shader.Find(enabled?"MazeBiters/GlideLanternLight":"MazeBiters/EraseLight");
   var overlayShader=Shader.Find(enabled?"MazeBiters/ContourDusk":"MazeBiters/PremultipliedImage");
   if(!light||!overlayShader)throw new InvalidOperationException("Missing approved glass lighting shader");
   beamMaterial.shader=light;powerMaterial.shader=light;
   if(!enabled){beamMaterial.mainTexture=beamTexture;powerMaterial.mainTexture=beamTexture;beamTransform.localPosition=new Vector3(0,56,0);}
   overlayMaterial.shader=overlayShader;overlayMaterial.mainTexture=mask;overlayMaterial.SetFloat("_Opacity",1);
   glassLighting=enabled;halo.SetActive(!enabled);
   float darkness=enabled?GlassDarkness:.8f;camera.backgroundColor=new Color(0,3/255f*darkness,12/255f*darkness,darkness);
   SetGlassCoverage(mazeCoverage);priorAngle=double.NaN;
  }
  public void SetGlassCoverage(Texture2D mazeCoverage){
   glassCoverage=mazeCoverage;
   if(glassLighting)overlayMaterial.SetTexture("_MazeCoverage",mazeCoverage?mazeCoverage:Texture2D.whiteTexture);
  }
  void SetAuraSize(float size){
   if(float.IsNaN(size)||float.IsInfinity(size)||size<=0||size>1)throw new ArgumentOutOfRangeException(nameof(size));
   // A stationary player still breathes: size is part of the cached mask pose.
   if(size!=auraSize){auraSize=size;priorAngle=double.NaN;}
  }
  void SetAuraVector(Vector2 direction){
   if(float.IsNaN(direction.x)||float.IsNaN(direction.y)||float.IsInfinity(direction.x)||float.IsInfinity(direction.y)||direction.sqrMagnitude>1.0001f)throw new ArgumentOutOfRangeException(nameof(direction));
   // Compare components, not Unity's approximate vector equality: even small
   // magnitude changes during a straight reversal must invalidate the mask.
   if(direction.x!=auraVector.x||direction.y!=auraVector.y){auraVector=direction;priorAngle=double.NaN;}
  }
  public void RenderAuraPose(Vector2 position,Vector2 direction,double power=0,bool dead=false,double lifeAlpha=1,bool reset=false,float size=1){
   if(!glassLighting)throw new InvalidOperationException("Glass lighting is not configured");
   SetAuraSize(size);SetAuraVector(direction);angle=direction.sqrMagnitude>1e-10f?Math.Atan2(direction.y,direction.x):0;initialized=true;RenderMask(position,reset,power,dead,lifeAlpha);
  }
  public void AppendAuraPose(Vector2 position,Vector2 direction,double power,bool dead,double lifeAlpha,float size=1){
   if(!glassLighting)throw new InvalidOperationException("Glass lighting is not configured");
   SetAuraSize(size);SetAuraVector(direction);angle=direction.sqrMagnitude>1e-10f?Math.Atan2(direction.y,direction.x):0;initialized=true;RenderMask(position,true,power,dead,lifeAlpha,true);
  }
  static GameObject Quad(string name,Mesh mesh,Material m,int layer,int order){var go=new GameObject(name){layer=layer};go.AddComponent<MeshFilter>().sharedMesh=mesh;var r=go.AddComponent<MeshRenderer>();r.sharedMaterial=m;r.sortingOrder=order;return go;}
  static Texture2D Load(string name){var t=new Texture2D(2,2,TextureFormat.RGBA32,false){filterMode=FilterMode.Bilinear,wrapMode=TextureWrapMode.Clamp};if(!t.LoadImage(File.ReadAllBytes(Path.Combine(WebFiles.Root,"Reference",name)),true))throw new IOException(name);return t;}
  // The turn bank uses clockwise quarter-turns; the sprite's outer transform
  // adds clockwise tilt in degrees. Share that exact pose, not the destination
  // cell heading or a second easing clock. Pausing naturally holds this pose.
  public static double HeadAngle(TurnPose pose,double tilt)=>pose.angle*Math.PI/2+tilt*Math.PI/180;
  public void RenderHeadPose(Vector2 position,TurnPose pose,double tilt,double power=0,bool dead=false,double lifeAlpha=1,bool reset=false){
   angle=HeadAngle(pose,tilt);initialized=true;if(glassLighting)SetAuraVector(new Vector2((float)Math.Cos(angle),(float)Math.Sin(angle)));RenderMask(position,reset,power,dead,lifeAlpha);
  }
  public void Render(Vector2 position,Vector2 dir,double elapsed,bool frozen=false,bool reset=false,double power=0,bool dead=false,double lifeAlpha=1){
   var desired=Math.Atan2(dir.y,dir.x);if(!initialized||reset){angle=desired;initialized=true;}else if(!frozen){var blend=1-Math.Exp(-Math.Max(0,Math.Min(50,elapsed))/65);angle+=Math.Atan2(Math.Sin(desired-angle),Math.Cos(desired-angle))*blend;}
   if(glassLighting)SetAuraVector(new Vector2((float)Math.Cos(angle),(float)Math.Sin(angle)));RenderMask(position,reset,power,dead,lifeAlpha);
  }
  public void AppendHeadPose(Vector2 position,TurnPose pose,double tilt,double power,bool dead,double lifeAlpha){angle=HeadAngle(pose,tilt);if(glassLighting)SetAuraVector(new Vector2((float)Math.Cos(angle),(float)Math.Sin(angle)));RenderMask(position,true,power,dead,lifeAlpha,true);}
  void RenderMask(Vector2 position,bool reset,double power,bool dead,double lifeAlpha,bool append=false){
   power=Math.Max(0,Math.Min(1,power));if(!reset&&position==priorPosition&&angle==priorAngle&&power==priorPower&&dead==priorDead&&lifeAlpha==priorLife)return;
   priorDead=dead;priorLife=lifeAlpha;haloMaterial.SetFloat("_Opacity",(float)lifeAlpha);beamMaterial.SetFloat("_Opacity",dead?0:1);priorPosition=position;priorAngle=angle;priorPower=power;
   float x=(position.x+.5f)*16,y=(position.y+.5f)*16;
   if(glassLighting){RenderAuraMask(x,y,power,dead,lifeAlpha,append);return;}
   float radius=44.8f*(float)(1+.30*power);halo.transform.localScale=new Vector3(radius*2,radius*2,1);halo.transform.position=new Vector3(x-radius,-y+radius,0);beamTransform.localScale=new Vector3(144*(float)(1+.45*power),112,1);powerBeam.transform.localPosition=beamTransform.localPosition;powerBeam.transform.localScale=beamTransform.localScale;powerBeam.SetActive(power>0);powerMaterial.SetFloat("_Opacity",(float)(.85*power));beamPivot.transform.position=new Vector3(x,-y,0);beamPivot.transform.rotation=Quaternion.Euler(0,0,-(float)(angle*180/Math.PI));
   if(RendererTuning.Optimized||append){direct.Clear();direct.SetRenderTarget(mask);if(!append)direct.ClearRenderTarget(false,true,camera.backgroundColor);direct.SetViewProjectionMatrices(camera.worldToCameraMatrix,camera.projectionMatrix);direct.DrawMesh(sharedQuad,halo.transform.localToWorldMatrix,haloMaterial);direct.DrawMesh(sharedQuad,beamTransform.localToWorldMatrix,beamMaterial);if(power>0)direct.DrawMesh(sharedQuad,beamTransform.localToWorldMatrix,powerMaterial);Graphics.ExecuteCommandBuffer(direct);}else{camera.Render();RenderProfile.Camera();}
  }
  void RenderAuraMask(float x,float y,double power,bool dead,double lifeAlpha,bool append){
   float extent=AuraQuadSize*.5f*(float)(1+.45*power)*auraSize;beamTransform.localPosition=new Vector3(-extent,extent,0);beamTransform.localScale=new Vector3(extent*2,extent*2,1);
   var vector=new Vector4(auraVector.x,auraVector.y,0,0);beamMaterial.SetVector("_Direction",vector);powerMaterial.SetVector("_Direction",vector);
   // Death retains only the fading symmetric near glow. Power keeps its
   // approved wider reach and extra intensity, without introducing a new RT.
   beamMaterial.SetFloat("_Opacity",dead?(float)lifeAlpha:1);beamMaterial.SetFloat("_Directional",dead?0:1);powerMaterial.SetFloat("_Directional",dead?0:1);
   bool showPower=power>0&&!dead;powerBeam.transform.localPosition=beamTransform.localPosition;powerBeam.transform.localScale=beamTransform.localScale;powerBeam.SetActive(showPower);powerMaterial.SetFloat("_Opacity",(float)(.85*power));
   beamPivot.transform.position=new Vector3(x,-y,0);beamPivot.transform.rotation=Quaternion.identity;
   if(RendererTuning.Optimized||append){
    direct.Clear();direct.SetRenderTarget(mask);if(!append)direct.ClearRenderTarget(false,true,camera.backgroundColor);direct.SetViewProjectionMatrices(camera.worldToCameraMatrix,camera.projectionMatrix);
    direct.DrawMesh(sharedQuad,beamTransform.localToWorldMatrix,beamMaterial);if(showPower)direct.DrawMesh(sharedQuad,beamTransform.localToWorldMatrix,powerMaterial);Graphics.ExecuteCommandBuffer(direct);
   }else{camera.Render();RenderProfile.Camera();}
  }
  public string Validate(){
   var root=Path.Combine(WebFiles.Root,"Reference");var specs=JsonUtility.FromJson<LightCases>(File.ReadAllText(Path.Combine(root,"light-masks.json")));
   var expected=new Texture2D(2,2,TextureFormat.RGBA32,false);expected.LoadImage(File.ReadAllBytes(Path.Combine(root,"light-masks.png")));var expectedPixels=expected.GetPixels32();
   var actual=new Texture2D(576,400,TextureFormat.RGBA32,false);int max=0,bad=0;long sum=0;var previous=RenderTexture.active;
   try{for(int k=0;k<specs.cases.Length;k++){
    var p=specs.cases[k];Render(new Vector2(p.x,p.y),new Vector2(p.dx,p.dy),16,false,true);RenderTexture.active=mask;actual.ReadPixels(new Rect(0,0,576,400),0,0);actual.Apply();var pixels=actual.GetPixels32();
    for(int y=0;y<400;y++)for(int x=0;x<576;x++){
     var a=pixels[y*576+x];var b=expectedPixels[((1-k/2)*400+y)*1152+k%2*576+x];
     int e=Math.Abs(a.a-b.a);max=Math.Max(max,e);sum+=e;if(e>2)bad++;
    }
   }}finally{RenderTexture.active=previous;UnityEngine.Object.Destroy(expected);UnityEngine.Object.Destroy(actual);}
   int count=specs.cases.Length*576*400;
   return JsonUtility.ToJson(new LightResult{samples=specs.cases.Length,pixels=count,maxAlphaError=max,meanAlphaError=(double)sum/count,pixelsBeyondTwo=bad,passed=max<=2,note="Mask alpha comparison at original logical resolution, four headings/sub-cell positions; no neon/reflections, power, death or camera tests yet."},true);
  }
  public void Dispose(){direct.Dispose();mask.Release();UnityEngine.Object.Destroy(mask);UnityEngine.Object.Destroy(root);UnityEngine.Object.Destroy(halo);UnityEngine.Object.Destroy(beamPivot);UnityEngine.Object.Destroy(overlay);UnityEngine.Object.Destroy(haloTexture);UnityEngine.Object.Destroy(beamTexture);UnityEngine.Object.Destroy(haloMaterial);UnityEngine.Object.Destroy(beamMaterial);UnityEngine.Object.Destroy(powerMaterial);UnityEngine.Object.Destroy(overlayMaterial);}
 }
 [Serializable]class LightCases{public LightCase[] cases;}[Serializable]class LightCase{public float x,y,dx,dy;}
 [Serializable]class LightResult{public int samples,pixels,maxAlphaError,pixelsBeyondTwo;public double meanAlphaError;public bool passed;public string note;}
}

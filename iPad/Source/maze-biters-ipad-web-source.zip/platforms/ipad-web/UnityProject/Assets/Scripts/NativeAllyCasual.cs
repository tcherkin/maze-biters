using System.Collections.Generic;
using System.Linq;
using UnityEngine;
namespace MazeBiters.NativeStudy {
 public sealed partial class NativeAllyBrain {
  bool CasualTier=>!w.UseLegacyAi&&w.AiDifficulty<=1&&Balance.Intensity<2;
  void ClearCasualMeal(NativePlayer p){var a=S(p);a.casualSnake=null;a.casualBites=0;a.casualGap=false;}
  void CheckCasualMeal(NativePlayer p){
   var a=S(p);var snake=a.casualSnake;if(snake==null)return;
   if(!CasualTier||!w.Snakes.Contains(snake)||snake.Body.Count==0){ClearCasualMeal(p);return;}
   if(p.Cell==a.casualFollowCell)return;
   var step=p.Cell-p.Previous;
   // A moving snake can vacate one cell between contacts. Preserve the meal
   // only while the AI actually continues into that short gap without reversing and
   // the same tail is still immediately ahead. This never steers a pursuit.
   if(!a.casualGap&&p.Previous==a.casualFollowCell&&Man(p.Cell,p.Previous)==1&&step!=-a.casualDirection&&p.Cell+step==snake.Tail){a.casualFollowCell=p.Cell;a.casualGap=true;return;}
   ClearCasualMeal(p);
  }
  void RecordCasualBite(NativePlayer p,NativeGameplaySnake snake){
   if(!p.IsAI)return;if(!CasualTier){ClearCasualMeal(p);return;}var a=S(p);
   // Record successful contacts, not a plan to eat. A different snake starts
   // a new sequence; a snake can also move into a stationary player.
   bool continuing=a.casualSnake==snake&&(a.casualFollowCell==p.Previous||a.casualFollowCell==p.Cell);
   a.casualBites=continuing?System.Math.Min(2,a.casualBites+1):1;a.casualSnake=snake;a.casualBiteCell=a.casualFollowCell=p.Cell;a.casualDirection=p.Dir;a.casualGap=false;
  }
  // A nearby snack is a legal step, not a strategic hunt. The peaceful tiers
  // should not treat edible bodies as walls and reverse away from them.
  bool CasualBite(NativePlayer p,double t,List<Vector2Int> options){
   if(!CasualTier||!CanBite(p,t))return false;
   var a=S(p);
   AllyObjective best=null;double bestScore=double.PositiveInfinity;
   foreach(var d in options){
    if(d==-p.Dir)continue; // Do not turn around to chase food just passed.
    var c=p.Cell+d;
    foreach(var snake in w.Snakes){
     int i=snake.Body.IndexOf(c);
     bool head=i==0&&snake.Body.Count==1;
     bool finish=head&&a.casualSnake==snake&&a.casualBites>=2&&a.casualFollowCell==p.Cell;
     if(i<0||i==0&&!head)continue;
     if(w.Snakes.Any(other=>other!=snake&&other.Body.Contains(c)))continue;
     double danger=Danger(p,d,c,t);
     if(danger>=105||w.ScorpionAt(c)||w.HunterAt(c))continue;
     bool tail=i==snake.Body.Count-1;
     var bite=new AllyObjective{type=finish?"casual-finish-head":head?"casual-head-bite":tail?"casual-tail-bite":"casual-split",target=c,snake=snake,bodyIndex=i,kind=head?"head":tail?"tail":"split",immediate=true,dir=d};
     // Lone heads use the same real contact rules: side/rear is edible,
     // head-on needs genuine power. Spawn protection alone cannot eat.
     if(Collision(p,d,c,t,bite)>=100000)continue;
     // Continue a safe route first; turn for a snack only one adjacent cell away.
     double score=(finish?-2000:0)+(d==p.Dir?0:1000)+danger;
     if(score<bestScore){best=bite;bestScore=score;}
    }
   }
   if(best==null)return false;
   ClearRetreat(p);Choose(p,best.dir.Value,t);Thought(p,best.type,best.target,Danger(p,best.dir.Value,best.target,t),bestScore);
   // Deliberately leave mealActive, locked, allowSplit and fragment queues alone.
   // Normal bite callbacks return a casual AI to its stroll after contact.
   return true;
  }
 }
}

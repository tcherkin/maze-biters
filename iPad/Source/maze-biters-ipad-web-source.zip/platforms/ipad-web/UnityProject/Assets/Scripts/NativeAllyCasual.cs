using System.Collections.Generic;
using System.Linq;
using UnityEngine;
namespace MazeBiters.NativeStudy {
 public sealed partial class NativeAllyBrain {
  // All imperfect tiers can recognise food beside them. Difficulty still
  // controls distant hunting, deliberation and the predictive safety review.
  bool CasualTier=>!w.UseLegacyAi&&!Balance.Maximum;
  void ClearCasualMeal(NativePlayer p){var a=S(p);a.casualSnake=null;a.casualBites=0;a.casualGap=false;}
  void CheckCasualMeal(NativePlayer p){
   var a=S(p);var snake=a.casualSnake;if(snake==null)return;
   if(!CasualTier||!w.Snakes.Contains(snake)||snake.Body.Count==0){ClearCasualMeal(p);return;}
   if(p.Cell==a.casualFollowCell)return;
   var step=p.Cell-p.Previous;
   // A moving snake can vacate one cell between contacts. Preserve the meal
   // only while the AI actually continues into that short gap without reversing and
   // the same tail is still immediately ahead. More empty travel ends the meal.
   if(!a.casualGap&&p.Previous==a.casualFollowCell&&Man(p.Cell,p.Previous)==1&&step!=-a.casualDirection&&p.Cell+step==snake.Tail){a.casualFollowCell=p.Cell;a.casualGap=true;return;}
   ClearCasualMeal(p);
  }
  void RecordCasualBite(NativePlayer p,NativeGameplaySnake snake){
   if(!p.IsAI)return;if(!CasualTier){ClearCasualMeal(p);return;}var a=S(p);
   // Record successful contacts, not a plan to eat. A different snake starts
   // a new sequence; a snake can also move into a stationary player.
   bool continuing=a.casualSnake==snake&&(a.casualFollowCell==p.Previous||a.casualFollowCell==p.Cell);
   a.casualBites=continuing?System.Math.Min(2,a.casualBites+1):1;a.casualSnake=snake;a.casualBiteCell=a.casualFollowCell=p.Cell;a.casualDirection=p.Dir;a.casualGap=false;
  }
  // A nearby snack is a legal step, not a strategic hunt. The imperfect tiers
  // should not treat edible bodies as walls and reverse away from them.
  bool CasualBite(NativePlayer p,double t,List<Vector2Int> options){
   if(!CasualTier||!CanBite(p,t))return false;
   var a=S(p);
   AllyObjective best=null;double bestScore=double.PositiveInfinity;
   foreach(var d in options){
    if(d==-p.Dir)continue; // Do not turn around to chase food just passed.
    var c=p.Cell+d;
    foreach(var snake in w.Snakes){
     int i=snake.Body.IndexOf(c);
     bool head=i==0&&snake.Body.Count==1;
     bool continuing=a.casualSnake==snake&&a.casualBites>0&&a.casualFollowCell==p.Cell;
     bool finish=head&&continuing&&a.casualBites>=2;
     if(i<0||i==0&&!head)continue;
     if(w.Snakes.Any(other=>other!=snake&&other.Body.Contains(c)))continue;
     double danger=Danger(p,d,c,t);
     if(danger>=105||w.ScorpionAt(c)||w.HunterAt(c))continue;
     bool tail=i==snake.Body.Count-1;
     var bite=new AllyObjective{type=finish?"casual-finish-head":head?"casual-head-bite":tail?"casual-tail-bite":"casual-split",target=c,snake=snake,bodyIndex=i,kind=head?"head":tail?"tail":"split",immediate=true,dir=d};
     // Lone heads use the same real contact rules: side/rear is edible,
     // head-on needs genuine power. Spawn protection grants no such attack.
     if(Collision(p,d,c,t,bite)>=100000)continue;
     // Once eating, follow that same adjacent body through a bend instead of
     // abandoning it for a random new interest window or another nearby tail.
     // Outside a meal, prefer a forward snack before a side contact.
     double score=(continuing?-2000:0)+(d==p.Dir?0:1000)+danger;
     if(score<bestScore){best=bite;bestScore=score;}
    }
   }
   if(best==null)return FollowCasualGap(p,t,options);
   ClearRetreat(p);Choose(p,best.dir.Value,t);Thought(p,best.type,best.target,Danger(p,best.dir.Value,best.target,t),bestScore);
   // Deliberately leave mealActive, locked, allowSplit and fragment queues alone.
   // Normal bite callbacks return a casual AI to its stroll after contact.
   return true;
  }
  bool FollowCasualGap(NativePlayer p,double t,List<Vector2Int> options){
   var a=S(p);var snake=a.casualSnake;
   if(snake==null||a.casualGap||a.casualBites==0||a.casualFollowCell!=p.Cell||!w.Snakes.Contains(snake)||snake.Body.Count==0)return false;
   var d=p.Dir;var c=p.Cell+d;
   // A moving tail can get one tile ahead between bites. Follow only that
   // visible, straight gap; never acquire a distant target or reverse for it.
   if(d==-a.casualDirection||!options.Contains(d)||c+d!=snake.Tail)return false;
   if(Danger(p,d,c,t)>=105||Collision(p,d,c,t)>=100000||w.ScorpionAt(c)||w.HunterAt(c))return false;
   ClearRetreat(p);Choose(p,d,t);Thought(p,"casual-follow-gap",snake.Tail,Danger(p,d,c,t));return true;
  }
  bool BiteBeforeDistantHunt(NativePlayer p,double t,List<Vector2Int> options,AllyDirective directive){
   if(w.UseLegacyAi||!CanBite(p,t)||directive?.type!="hunt"||directive.target==null)return false;
   var rivalStep=directive.target.Cell-p.Cell;
   // A reachable rival beside us is already a real contact opportunity. Keep
   // that established competitive choice, rather than silently changing it.
   if(Man(p.Cell,directive.target.Cell)==1&&options.Contains(rivalStep)){
    var rival=new AllyObjective{target=directive.target.Cell,player=directive.target,kind="player",immediate=true,dir=rivalStep};
    if(Collision(p,rivalStep,rival.target,t,rival)<100000)return false;
   }
   var a=S(p);NativeGameplaySnake ongoing=null;
   if(a.casualSnake!=null&&a.casualBites>0&&a.casualFollowCell==p.Cell)ongoing=a.casualSnake;
   // The strongest tier uses its existing real-bite commitment. A recent
   // mouth animation allows one natural catch-up step, not an old remote lock.
   else if(Balance.Maximum&&a.bitten&&a.locked!=null&&p.BiteEnd>=t-125)ongoing=a.locked;
   AllyObjective best=null;double bestScore=double.PositiveInfinity;
   foreach(var d in options){
    if(d==-p.Dir)continue;
    var c=p.Cell+d;
    foreach(var snake in w.Snakes){
     int i=snake.Body.IndexOf(c);if(i<0)continue;
     bool continuing=snake==ongoing;
     // Finish the meal already touching us, or take food directly in our
     // path. A distant player hunt never gains a new side detour for food.
     if(!continuing&&d!=p.Dir)continue;
     if(w.Snakes.Any(other=>other!=snake&&other.Body.Contains(c))||w.ScorpionAt(c)||w.HunterAt(c))continue;
     double danger=Danger(p,d,c,t);if(danger>=105)continue;
     var bite=new AllyObjective{type=continuing?"continue-meal-before-hunt":"forward-bite-before-hunt",target=c,snake=snake,bodyIndex=i,kind=i==0?"head":i==snake.Body.Count-1?"tail":"split",immediate=true,dir=d};
     if(Collision(p,d,c,t,bite)>=100000)continue;
     double score=(continuing?-2000:0)+(d==p.Dir?0:1000)+danger;
     if(score<bestScore){best=bite;bestScore=score;}
    }
   }
   if(best==null)return false;
   // Mirror the normal strongest-tier planner's provisional target change.
   // Only TailBite/Split after real contact can mark this as an eaten meal;
   // the outer safety review may still cancel this proposed move and lock.
   if(Balance.Maximum&&best.snake!=a.locked)Commit(p,best.snake,best.kind=="split"?"split-target":"hunt",t);
   ClearRetreat(p);Choose(p,best.dir.Value,t);Thought(p,best.type,best.target,Danger(p,best.dir.Value,best.target,t),bestScore);return true;
  }
 }
}

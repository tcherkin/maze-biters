using System.Collections.Generic;
using System.Linq;
using UnityEngine;
namespace MazeBiters.NativeStudy {
 public sealed partial class NativeAllyBrain {
  // A nearby snack is a legal step, not a strategic hunt. The peaceful tiers
  // should not treat edible bodies as walls and reverse away from them.
  bool CasualBite(NativePlayer p,double t,List<Vector2Int> options){
   if(w.UseLegacyAi||w.AiDifficulty>1||Balance.Intensity>=2)return false;
   AllyObjective best=null;double bestScore=double.PositiveInfinity;
   foreach(var d in options){
    if(d==-p.Dir)continue; // Do not turn around to chase food just passed.
    var c=p.Cell+d;
    foreach(var snake in w.Snakes){
     int i=snake.Body.IndexOf(c);if(i<=0)continue; // Heads retain normal policy.
     if(w.Snakes.Any(other=>other!=snake&&other.Body.Contains(c)))continue;
     double danger=Danger(p,d,c,t);
     if(danger>=105||w.ScorpionAt(c)||w.HunterAt(c))continue;
     bool tail=i==snake.Body.Count-1;
     var bite=new AllyObjective{type=tail?"casual-tail-bite":"casual-split",target=c,snake=snake,bodyIndex=i,kind=tail?"tail":"split",immediate=true,dir=d};
     if(Collision(p,d,c,t,bite)>=100000)continue;
     // Continue a safe route first; turn for a snack only one adjacent cell away.
     double score=(d==p.Dir?0:1000)+danger;
     if(score<bestScore){best=bite;bestScore=score;}
    }
   }
   if(best==null)return false;
   ClearRetreat(p);Choose(p,best.dir.Value,t);Thought(p,best.type,best.target,Danger(p,best.dir.Value,best.target,t),bestScore);
   // Deliberately leave mealActive, locked, allowSplit and fragment queues alone.
   // Normal bite callbacks return a casual AI to its stroll after contact.
   return true;
  }
 }
}

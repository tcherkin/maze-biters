using System;

namespace MazeBiters.NativeStudy {
 // Three retained first-order stages give a soft S-shaped speed change. The
 // output's velocity and acceleration remain continuous even when retargeted.
 // Analytic advancement and phase integration are independent of frame rate.
 public sealed class MenuEffectTempo {
  public const double ResponseRate=9;
  double first,second,third,target,milliseconds;
  public double Value=>third;
  public double Target=>target;
  public double Milliseconds=>milliseconds;

  public MenuEffectTempo(double initialTempo=2.5,double initialMilliseconds=0){
   CheckNonnegative(initialTempo,nameof(initialTempo));
   CheckNonnegative(initialMilliseconds,nameof(initialMilliseconds));
   first=second=third=target=initialTempo;milliseconds=initialMilliseconds;
  }

  internal MenuEffectTempo Copy()=>new MenuEffectTempo(target,milliseconds){first=this.first,second=this.second,third=this.third};

  public void SetTarget(double tempo){
   CheckNonnegative(tempo,nameof(tempo));
   // Do not reset any stage or animation phase when another choice arrives.
   target=tempo;
  }

  public void Advance(double seconds){
   CheckNonnegative(seconds,nameof(seconds));if(seconds==0)return;
   double oldFirst=first,oldSecond=second,oldThird=third;
   double a=first-target,b=second-target,c=third-target;
   double x=ResponseRate*seconds;
   if(x>700){first=second=third=target;}
   else {
    double decay=Math.Exp(-x);
    first=target+a*decay;
    second=target+(b+a*x)*decay;
    third=target+(c+b*x+a*x*x*.5)*decay;
   }
   // Summing the three ODEs gives S' = rate*(target-output). Integrating this
   // identity gives the exact travelled phase, including during retargeting.
   // It also avoids subtracting nearly equal exponential polynomials at dt~0.
   double integral=target*seconds+((oldFirst-first)+(oldSecond-second)+(oldThird-third))/ResponseRate;
   milliseconds+=Math.Max(0,integral)*1000;
  }

  static void CheckNonnegative(double value,string name){
   if(double.IsNaN(value)||double.IsInfinity(value)||value<0)throw new ArgumentOutOfRangeException(name);
  }
  static void Require(bool condition,string message){if(!condition)throw new InvalidOperationException(message);}

  // Called only by the isolated capture/verification path, never each frame.
  public static string Validate(){
   var steady=new MenuEffectTempo(2.5,125);
   for(int i=0;i<120;i++)steady.Advance(1.0/120);
   Require(steady.Value==2.5&&Math.Abs(steady.Milliseconds-2625)<1e-8,"Medium tempo changed at steady state");
   foreach(bool rising in new[]{true,false}){
    double from=rising?1.5:4,to=rising?4:1.5,previous=from;
    var step=new MenuEffectTempo(from);step.SetTarget(to);
    for(int i=0;i<240;i++){
     step.Advance(1.0/120);
     Require(step.Value>=1.5-1e-12&&step.Value<=4+1e-12,"Tempo step overshoots its bounds");
     Require(rising?step.Value>=previous-1e-12:step.Value<=previous+1e-12,"Tempo step oscillates");
     previous=step.Value;
     if(i==95)Require(Math.Abs(step.Value-to)<Math.Abs(to-from)*.026,"Tempo response takes too long");
    }
   }
   var reference=RetargetSequence(0);
   foreach(int fps in new[]{30,60,120}){
    var partitioned=RetargetSequence(fps);
    Require(Math.Abs(partitioned.Value-reference.Value)<1e-10,"Tempo depends on frame partition");
    Require(Math.Abs(partitioned.Milliseconds-reference.Milliseconds)<1e-7,"Travelled phase depends on frame partition");
   }
   return "Smooth tempo: steady Medium preserved; monotonic acceleration/deceleration; rapid retargets retain phase; 30/60/120 fps agree; 97.45% transition in 0.8s, 99.38% in 1s";
  }

  static MenuEffectTempo RetargetSequence(int fps){
   var tempo=new MenuEffectTempo();
   double[] targets={4,1.5,3.125,2,4,1.5,2.5,4,2.5};
   double[] durations={.1,.1,.2,.1,.1,.2,.1,.1,1};
   for(int i=0;i<targets.Length;i++){
    double phase=tempo.Milliseconds,value=tempo.Value;
    tempo.SetTarget(targets[i]);
    Require(tempo.Milliseconds==phase&&tempo.Value==value,"Retarget resets position or speed");
    int steps=fps==0?1:(int)Math.Round(durations[i]*fps);
    for(int j=0;j<steps;j++){
     phase=tempo.Milliseconds;tempo.Advance(durations[i]/steps);
     Require(tempo.Milliseconds>phase&&tempo.Value>=1.5-1e-12&&tempo.Value<=4+1e-12,"Rapid changes reverse or overshoot the animation");
    }
   }
   return tempo;
  }
 }
}

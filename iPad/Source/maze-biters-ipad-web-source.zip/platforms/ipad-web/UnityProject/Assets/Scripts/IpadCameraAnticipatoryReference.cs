using System;
using UnityEngine;
namespace MazeBiters.NativeStudy {
 // One camera follow stage, with the PC's 470 ms response. Tablet framing is
 // part of the destination, not a second warp applied after the follow step.
 public sealed class IpadCameraAnticipatoryReference {
  bool ready;double stamp,zoomCeiling;IpadView current;float width,height;Rect lastSafe;double lastClose;
  public int EmergencyCorrections{get;private set;}
  public void Reset(){ready=false;EmergencyCorrections=0;}
  static double Clamp(double x,double a,double b)=>a>b?(a+b)/2:Math.Max(a,Math.Min(b,x));
  static double Blend(double dt,double tau)=>1-Math.Exp(-dt/tau);
  static double LimitZoom(double zoom,double available,double distance)=>distance>0?Math.Min(zoom,available/distance):zoom;
  // Ease the same follow stage forward before an actor reaches the edge.
  // This avoids switching directly to the actor's 95 ms cell interpolation.
  static double Response(double clearance,double minimum=170)=>470-(470-minimum)*IpadFraming.Smooth((40-clearance)/40);
  public IpadView Sample(NativeFrame f,double x,double y,double zoom,double close,Rect safe,Rect? bounds,double real,double? targetX=null,double? targetY=null,Rect? upcoming=null,double? targetZoom=null){
   var desired=IpadFraming.Calculate(f,x,y,zoom,close,safe);
   bool reset=!ready||real<stamp||width!=f.Width||height!=f.Height||lastSafe!=safe||lastClose!=close;
   if(reset){ready=true;width=f.Width;height=f.Height;lastSafe=safe;lastClose=close;stamp=real;zoomCeiling=close;current=bounds.HasValue?IpadFraming.KeepPlayers(f,desired,bounds.Value,safe):desired;return current;}
   if(real==stamp)return current;
   double dt=Math.Max(0,Math.Min(50,real-stamp));stamp=real;
   double sx=targetX??x,sy=targetY??y;
   var goal=IpadFraming.Calculate(f,sx,sy,zoom,close,safe);
   double ceilingTarget=targetZoom.HasValue?IpadFraming.Calculate(f,sx,sy,targetZoom.Value,close,safe).zoom:close;
   if(upcoming.HasValue){var b=upcoming.Value;
    // The same clamped half-board windows as the original roster camera.
    // Using the literal bounds centre would bias a wide shot toward the spawn,
    // then pull back again when the original live roster takes over.
    double cx=(Clamp(b.xMin,144,432)+Clamp(b.xMax,144,432))/2;
    double cy=(Clamp(b.yMin,100,300)+Clamp(b.yMax,100,300))/2;
    var destination=IpadFraming.Calculate(f,cx,cy,zoom,close,safe);
    var future=destination;future.zoom=close;
    // The extra lead room lets the exponential follow finish fitting before
    // the original respawn deadline, without delaying or hiding a participant.
    future=IpadFraming.KeepPlayers(f,future,b,safe,32);
    // Fit at the intended roster centre as well as fitting the union's size.
    // Otherwise an asymmetric spawn can technically fit only after a snap pan.
    future.zoom=LimitZoom(future.zoom,f.Width/2-safe.xMin,destination.x-b.xMin+24);
    future.zoom=LimitZoom(future.zoom,safe.xMax-f.Width/2,b.xMax+24-destination.x);
    future.zoom=LimitZoom(future.zoom,f.Height/2-Math.Max(safe.yMin,goal.header),destination.y-b.yMin+24);
    future.zoom=LimitZoom(future.zoom,safe.yMax-f.Height/2,b.yMax+24-destination.y);
    double overview=Math.Min(f.Width/576.0,(f.Height-32-safe.yMin)/400.0);
    future.zoom=Math.Max(overview,future.zoom);
    ceilingTarget=Math.Min(ceilingTarget,future.zoom);goal.x=destination.x;goal.y=destination.y;
   }
   zoomCeiling+=(ceilingTarget-zoomCeiling)*Blend(dt,ceilingTarget<zoomCeiling?230:1040);
   goal.zoom=Math.Min(goal.zoom,zoomCeiling);
   double tauX=470,tauY=470;
   if(bounds.HasValue){var b=upcoming??bounds.Value;double z=goal.zoom,top=Math.Max(safe.yMin,goal.header);
    double minX=b.xMax+12-(safe.xMax-f.Width/2)/z,maxX=b.xMin-12+(f.Width/2-safe.xMin)/z;
    double minY=b.yMax+12-(safe.yMax-f.Height/2)/z,maxY=b.yMin-12+(f.Height/2-top)/z;
    // A wide roster can approach opposite edges simultaneously; catch up
    // earlier within the same follow stage instead of activating a hard clamp.
    double minimum=b.width>24||b.height>24?100:170;
    tauX=Response(Math.Min(current.x-minX,maxX-current.x),minimum);tauY=Response(Math.Min(current.y-minY,maxY-current.y),minimum);
    var active=bounds.Value;double margin=12;
    if(upcoming.HasValue||active.width>24||active.height>24){
     // Do not pan a moving survivor onto the last visible pixel while making
     // room for a respawn. Use only spare space already available at this zoom.
     double spare=Math.Min((safe.xMax-safe.xMin)/goal.zoom-active.width,(safe.yMax-top)/goal.zoom-active.height)/2;
     margin=Math.Max(12,Math.Min(32,spare-1));
    }
    double requestedZoom=goal.zoom;goal=IpadFraming.KeepPlayers(f,goal,active,safe,margin);
    if(goal.zoom<requestedZoom)zoomCeiling=Math.Min(zoomCeiling,goal.zoom);
   }
   var view=goal;view.x=current.x+(goal.x-current.x)*Blend(dt,tauX);view.y=current.y+(goal.y-current.y)*Blend(dt,tauY);
   // The PC world-boundary clamp, expressed in the tablet viewport.
   double sky=52*IpadFraming.Smooth((zoom-1)/.5),minWorldX=(f.Width/2-sky)/view.zoom,maxWorldX=576-minWorldX;
   double minWorldY=(f.Height/2-view.header-sky)/view.zoom,maxWorldY=400-(f.Height/2-sky)/view.zoom;
   view.x=Clamp(view.x,minWorldX,maxWorldX);view.y=Clamp(view.y,minWorldY,maxWorldY);
   if(bounds.HasValue){var protectedView=IpadFraming.KeepPlayers(f,view,bounds.Value,safe);
    if(Math.Abs(protectedView.x-view.x)>.001||Math.Abs(protectedView.y-view.y)>.001||Math.Abs(protectedView.zoom-view.zoom)>.00001)EmergencyCorrections++;
    // Release a visibility limit with the original slow zoom-in response.
    // Removing a participant must not reveal an already advanced raw zoom.
    if(protectedView.zoom<view.zoom)zoomCeiling=Math.Min(zoomCeiling,protectedView.zoom);
    view=protectedView;
   }
   current=view;return view;
  }
 }
}


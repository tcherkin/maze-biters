using System;

namespace MazeBiters.NativeStudy {
 // Values describe completed preparation work, never an elapsed frame or a
 // polling call. Comparing references avoids hashes, strings and allocations.
 internal struct LevelPreparationProgress : IEquatable<LevelPreparationProgress> {
  internal object scene,mazeTask,publishingMaze,readyMaze;
  internal long cpuSteps;
  internal int taskStatus,publicationStage,publicationOffset,stage,index,passes,primedSnakes,actors,snakes,neonSteps,packedUploads,flags;
  public bool Equals(LevelPreparationProgress other)=>ReferenceEquals(scene,other.scene)&&ReferenceEquals(mazeTask,other.mazeTask)&&ReferenceEquals(publishingMaze,other.publishingMaze)&&ReferenceEquals(readyMaze,other.readyMaze)
   &&cpuSteps==other.cpuSteps&&taskStatus==other.taskStatus&&publicationStage==other.publicationStage&&publicationOffset==other.publicationOffset&&stage==other.stage&&index==other.index&&passes==other.passes&&primedSnakes==other.primedSnakes&&actors==other.actors&&snakes==other.snakes&&neonSteps==other.neonSteps&&packedUploads==other.packedUploads&&flags==other.flags;
 }

 internal enum LevelPreparationWatchdogStatus { Waiting,Stalled,Deadline }

 // An attempt expires only after 90 seconds without observable work. The
 // separate transition deadline survives retries, so progress cannot wait forever.
 internal struct LevelPreparationWatchdog {
  internal const double InactivitySeconds=90,MaximumSeconds=300;
  bool initialized;
  double startedAt,progressAt;
  LevelPreparationProgress previous;
  internal void Reset(double now,LevelPreparationProgress progress){initialized=true;startedAt=progressAt=now;previous=progress;}
  internal void RestartAttempt(double now,LevelPreparationProgress progress){if(!initialized){Reset(now,progress);return;}progressAt=now;previous=progress;}
  internal LevelPreparationWatchdogStatus Observe(double now,LevelPreparationProgress progress){
   if(!initialized)Reset(now,progress);
   if(now-startedAt>=MaximumSeconds)return LevelPreparationWatchdogStatus.Deadline;
   if(!previous.Equals(progress)){previous=progress;progressAt=now;}
   return now-progressAt>=InactivitySeconds?LevelPreparationWatchdogStatus.Stalled:LevelPreparationWatchdogStatus.Waiting;
  }
 }
}

using System;using System.IO;using System.Linq;using System.Collections;using System.Collections.Generic;using UnityEngine;
namespace MazeBiters.NativeStudy {
 [Serializable]class HunterFixtures {public int size,columns,rows;public HunterFixture[] samples;}
 [Serializable]class HunterFixture {public string palette;public int from,to,mouth,blink;public double mix;}
 [Serializable]class HunterReport {public string quality,note;public bool passed;public int samples,closedEyePixels,backEyePixels;public long targetBytes;public VisualCheck[] eyes,lit,emission;public int[] fieldPixels;}
 public sealed class HunterNeonValidation:MonoBehaviour {
  Mesh quad;PackedArt art;NativeTurnBank bank;NativeTurnActor actor;NativeHunterNeon effect;Texture2D eyes,lit,emission;string quality="hd",report;NativeDusk dusk;NativeNeon neon;Camera camera;RenderTexture target;readonly List<GameObject> scene=new List<GameObject>();readonly List<Material> scenePaint=new List<Material>();Texture2D maze;NativeTurnActor[] gallery;NativeHunterNeon[] lights;
  static Texture2D Read(RenderTexture rt){var prev=RenderTexture.active;RenderTexture.active=rt;var t=new Texture2D(rt.width,rt.height,TextureFormat.RGBA32,false);t.ReadPixels(new Rect(0,0,rt.width,rt.height),0,0);t.Apply();RenderTexture.active=prev;return t;}
  static Texture2D Load(string f){var t=new Texture2D(2,2,TextureFormat.RGBA32,false);t.LoadImage(File.ReadAllBytes(Path.Combine(WebFiles.Root,"Reference",f)));return t;}
  static VisualCheck Compare(RenderTexture rt,Texture2D reference,int x,int y,string name){
   var t=Read(rt);var aa=t.GetPixels32();var bb=reference.GetPixels32();var check=new VisualCheck{name=name,pixels=aa.Length};double sum=0;
   for(int row=0;row<t.height;row++)for(int col=0;col<t.width;col++){var a=aa[row*t.width+col];var b=bb[(reference.height-y-t.height+row)*reference.width+x+col];int max=0;for(int k=0;k<4;k++){int n=k==0?a.r:k==1?a.g:k==2?a.b:a.a,m=k==0?b.r:k==1?b.g:k==2?b.b:b.a;if(k<3)m=(int)Math.Round(m*b.a/255.0);int e=Math.Abs(n-m);max=Math.Max(max,e);sum+=e*e;}check.maxError=Math.Max(check.maxError,max);if(max>2)check.over2++;}
   check.rmse=Math.Sqrt(sum/(aa.Length*4));Destroy(t);return check;
  }
  static int Visible(RenderTexture rt){var t=Read(rt);int n=t.GetPixels32().Count(p=>p.a>0);Destroy(t);return n;}
  void Save(RenderTexture rt,string file){var t=Read(rt);File.WriteAllBytes(Path.Combine(Path.GetDirectoryName(report),file),t.EncodeToPNG());Destroy(t);}
  MeshRenderer Add(string name,Material m,Vector3 pos,Vector3 scale,int order){var go=new GameObject(name);scene.Add(go);go.AddComponent<MeshFilter>().sharedMesh=quad;var r=go.AddComponent<MeshRenderer>();r.sharedMaterial=m;r.sortingOrder=order;go.transform.position=pos;go.transform.localScale=scale;return r;}
  IEnumerator Start(){
   var args=Environment.GetCommandLineArgs();for(int i=0;i<args.Length;i++){if(args[i]=="--quality")quality=args[++i];if(args[i]=="--report")report=args[++i];}
   Application.runInBackground=true;QualitySettings.vSyncCount=0;QualitySettings.anisotropicFiltering=AnisotropicFiltering.Disable;Directory.CreateDirectory(Path.GetDirectoryName(report));
   quad=new Mesh();quad.vertices=new[]{new Vector3(0,0),new Vector3(1,0),new Vector3(1,-1),new Vector3(0,-1)};quad.uv=new[]{new Vector2(0,1),new Vector2(1,1),new Vector2(1,0),new Vector2(0,0)};quad.triangles=new[]{0,1,2,0,2,3};quad.RecalculateBounds();
   art=new PackedArt(quality);bank=new NativeTurnBank(quality,art,quad);actor=new NativeTurnActor(bank,"dragon","h1");effect=new NativeHunterNeon(quad,bank.Size,1);
   var data=JsonUtility.FromJson<HunterFixtures>(File.ReadAllText(Path.Combine(WebFiles.Root,"Reference/hunter-"+quality+"-reference.json")));
   eyes=Load("hunter-"+quality+"-eyes.png");lit=Load("hunter-"+quality+"-lit.png");emission=Load("hunter-"+quality+"-emission.png");
   var eyeChecks=new List<VisualCheck>();var litChecks=new List<VisualCheck>();var glowChecks=new List<VisualCheck>();int closed=0,back=0;
   for(int i=0;i<data.samples.Length;i++){var s=data.samples[i];actor.Palette=s.palette;var pose=new TurnPose{from=s.from,to=s.to,mix=s.mix};bank.Render(actor,pose,s.mouth,s.blink);effect.Render(bank,actor,pose,s.mouth,s.blink,1000+i,0,Matrix4x4.identity,0,true);
    int x=i%data.columns*bank.Size,y=i/data.columns*bank.Size;eyeChecks.Add(Compare(effect.Mask,eyes,x,y,"eyes-"+i));litChecks.Add(Compare(effect.Lit,lit,x,y,"lit-"+i));glowChecks.Add(Compare(effect.Glow,emission,x,y,"emission-"+i));
    if(s.blink==24)closed+=Visible(effect.Mask);if(s.from==3&&s.to==3)back+=Visible(effect.Mask);
    if(i%18==0){Save(effect.Mask,"eye-"+quality+"-"+i+".png");Save(effect.Lit,"lit-"+quality+"-"+i+".png");}if(i%12==0)yield return null;
   }
   // Integrated maze composition, with all three original palettes. Compare
   // before/after at exactly the same poses; explicit attention is test-only.
   var level=JsonUtility.FromJson<LevelData>(File.ReadAllText(Path.Combine(WebFiles.Root,"Reference/level.json")));
   camera=new GameObject("Hunter light validation").AddComponent<Camera>();camera.enabled=false;camera.orthographic=true;camera.orthographicSize=216;camera.transform.position=new Vector3(288,-184,-10);camera.aspect=4f/3;camera.clearFlags=CameraClearFlags.SolidColor;camera.backgroundColor=Color.black;camera.cullingMask&=~(1<<28);
   int height=quality=="4k"?2160:1080;target=new RenderTexture(height*4/3,height,0,RenderTextureFormat.ARGB32);target.Create();camera.targetTexture=target;
   maze=NativeLightField.Load("maze.png");var mazeMat=new Material(Shader.Find("MazeBiters/ExactImage")){mainTexture=maze};scenePaint.Add(mazeMat);Add("Maze",mazeMat,Vector3.zero,new Vector3(576,400,1),0);
   dusk=new NativeDusk(quad,camera);neon=new NativeNeon(level.geometry,quad,dusk,false,Array.Empty<NativeSnake>(),true,true);
   gallery=new NativeTurnActor[3];lights=new NativeHunterNeon[3];var renderers=new MeshRenderer[3];int[] xs={5,15,27};string[] palettes={"h1","h3","h4"};
   for(int i=0;i<3;i++){gallery[i]=new NativeTurnActor(bank,"dragon",palettes[i]);lights[i]=new NativeHunterNeon(quad,bank.Size,i+1);renderers[i]=Add("Hunter",gallery[i].Display,new Vector3(xs[i]*16,-16,-1),new Vector3(16,16,1),10);var p=new TurnPose{from=1,to=1,mix=0};bank.Render(gallery[i],p,16,0);lights[i].Render(bank,gallery[i],p,16,0,1000,1,renderers[i].transform.localToWorldMatrix,i);lights[i].Render(bank,gallery[i],p,16,0,1400,1,renderers[i].transform.localToWorldMatrix,i);}
   var player=new NativeTurnActor(bank,"fantasy","p1");var pp=new TurnPose{from=0,to=0,mix=0};bank.Render(player,pp,16,0);var pr=Add("Player flashlight",player.Display,new Vector3(32,-16,-1),new Vector3(16,16,1),10);
   dusk.Render(new Vector2(2,1),Vector2Int.right,16,false,false);
   neon.Enabled=false;neon.Render(Array.Empty<NativeSnake>(),Array.Empty<SnakePose>(),player.Display,pr.transform.localToWorldMatrix,1400);camera.Render();Save(target,"maze-"+quality+"-before.png");
   for(int i=0;i<3;i++)renderers[i].sharedMaterial=lights[i].Display;neon.Enabled=true;neon.Render(Array.Empty<NativeSnake>(),Array.Empty<SnakePose>(),player.Display,pr.transform.localToWorldMatrix,1400,hunters:lights);camera.Render();Save(target,"maze-"+quality+"-after.png");
   var fieldCounts=new int[3];for(int i=0;i<3;i++){neon.Field.Begin();lights[i].Light(neon.Field);neon.Field.Render();fieldCounts[i]=Visible(neon.Field.Walls);}
   player.Dispose();
   var result=new HunterReport{quality=quality,samples=data.samples.Length,eyes=eyeChecks.ToArray(),lit=litChecks.ToArray(),emission=glowChecks.ToArray(),closedEyePixels=closed,backEyePixels=back,fieldPixels=fieldCounts,targetBytes=lights.Sum(l=>l.TargetBytes),passed=closed==0&&back==0&&fieldCounts.All(n=>n>0)&&eyeChecks.All(c=>c.rmse<1)&&litChecks.All(c=>c.rmse<2)&&glowChecks.All(c=>c.rmse<2),note="Independent frozen-browser native pose/eye/material reference. Rendering backend rounding may differ. Explicit test attention only in gallery; gameplay uses authoritative hunter Aggression. No gameplay algorithm or original browser edits."};
   File.WriteAllText(report,JsonUtility.ToJson(result,true));Debug.Log("HUNTER_NEON_VALIDATION "+result.passed);Application.Quit(result.passed?0:2);
  }
  void OnDestroy(){neon?.Dispose();dusk?.Dispose();if(lights!=null)foreach(var l in lights)l?.Dispose();if(gallery!=null)foreach(var a in gallery)a?.Dispose();effect?.Dispose();actor?.Dispose();bank?.Dispose();art?.Dispose();if(camera){camera.targetTexture=null;Destroy(camera.gameObject);}if(target){if(RenderTexture.active==target)RenderTexture.active=null;target.Release();Destroy(target);}foreach(var go in scene)Destroy(go);foreach(var m in scenePaint)Destroy(m);foreach(var t in new[]{eyes,lit,emission,maze})Destroy(t);Destroy(quad);}
 }
}

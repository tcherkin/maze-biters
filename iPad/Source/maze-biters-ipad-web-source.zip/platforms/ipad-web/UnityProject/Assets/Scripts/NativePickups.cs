using System;using System.Collections.Generic;using UnityEngine;using UnityEngine.Rendering;
namespace MazeBiters.NativeStudy {
 public static class NativePickupTiming {
  // Verbatim production timing, measured in game-clock milliseconds.
  public static double Fade(double born,double time){if(double.IsNaN(born)||double.IsInfinity(born))return 1;double u=Math.Max(0,Math.Min(1,(time-born)/250));return 1-(1-u)*(1-u);}
  public static double Pulse(double born,double time){if(double.IsNaN(born)||double.IsInfinity(born))born=time;const double cycle=218*8;double phase=((time-born)%cycle+cycle)%cycle/cycle;return .85+.15*Math.Cos(phase*Math.PI*2);}
  public static int EggFrame(double born,double time){double age=time-born;return age>=12000?3:age>=11000?2:age>=10000?1:0;}
 }
 public sealed class NativePickups:IDisposable {
  // Walkable cells in the unchanged test labyrinth (the top row has walls).
  static readonly int[] galleryColumns={5,9,13,15,21,23,27,29};
  internal static Vector2 GalleryCell(int index)=>new Vector2(galleryColumns[index],1);
  public struct Pose {public bool egg;public int kind,frame;public Vector2 cell;public double alpha;public Matrix4x4 transform;}
  readonly Mesh quad;readonly Material[] lit=new Material[8],emission=new Material[8];readonly MaterialPropertyBlock block=new MaterialPropertyBlock();
  public readonly List<Pose> Poses=new List<Pose>();public long TextureBytes{get;private set;}public int Count=>Poses.Count;
  public NativePickups(Mesh quad,string quality,bool deferred=false){this.quad=quad;if(!deferred)foreach(var step in LoadSteps(quality)){} }
  public IEnumerable<object> LoadSteps(string quality){for(int i=0;i<8;i++){
   string key="pickup-"+quality+"-"+(i<4?"fruit-":"egg-")+(i%4);
   Material Make(string type){var texture=NativeLightField.Load(key+"-"+type+".png",true);TextureBytes+=(long)texture.width*texture.height*4;return new Material(Shader.Find("MazeBiters/PickupImage")){mainTexture=texture};}
   lit[i]=Make("lit");yield return null;emission[i]=Make("emission");yield return null;
  }}
  public void Clear()=>Poses.Clear();
  public void Add(bool egg,int kind,Vector2 cell,double born,double time){int frame=egg?NativePickupTiming.EggFrame(born,time):Math.Max(0,Math.Min(3,kind));double a=NativePickupTiming.Fade(born,time)*(egg?1:NativePickupTiming.Pulse(born,time));Poses.Add(new Pose{egg=egg,kind=kind,frame=frame,cell=cell,alpha=a,transform=Matrix4x4.TRS(new Vector3(cell.x*16,-cell.y*16,-1),Quaternion.identity,new Vector3(16,16,1))});}
  public void Submit(CommandBuffer commands,bool glow=false){foreach(var p in Poses){if(p.alpha<=0)continue;block.SetFloat("_Opacity",(float)p.alpha);commands.DrawMesh(quad,p.transform,(glow?emission:lit)[p.frame+(p.egg?4:0)],0,0,block);}}
  public void Light(NativeLightField field){foreach(var p in Poses){if(p.alpha<=0)continue;int palette=p.egg?10:p.kind==1?1:p.kind==3?0:9;const double spacing=16.0*2/9,length=8;int count=(int)Math.Floor(length/spacing);double remainder=length-count*spacing;void Stamp(double weight)=>field.Point((p.cell.x+.5)*16,(p.cell.y+.5)*16,palette,weight*p.alpha);
    for(int i=0;i<=count;i++)Stamp(i==0?.5:i==count?.5+remainder/spacing*.5:1);if(remainder>0)Stamp(remainder/spacing*.5);
  }}
  public void Dispose(){foreach(var array in new[]{lit,emission})foreach(var m in array)if(m){UnityEngine.Object.Destroy(m.mainTexture);UnityEngine.Object.Destroy(m);}Poses.Clear();}
 }
}

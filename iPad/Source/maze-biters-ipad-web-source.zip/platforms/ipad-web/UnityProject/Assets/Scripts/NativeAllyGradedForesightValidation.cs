#if UNITY_EDITOR
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using UnityEngine;

namespace MazeBiters.NativeStudy {
 [Serializable] public sealed class NativeAllyGradedForesightRow {
  public int tier, beamWidth, expansionLimit, pocketCells;
  public double ageMs, intensity, horizonMs, steps, corridorSteps, overrideRisk, minimumGain, combinedThreatWeight, objectiveWeight;
 }
 [Serializable] public sealed class NativeAllyGradedForesightReport {
  public bool passed;
  public int assertions, failures, decisions;
  public double elapsedMs;
  public string scope;
  public List<NativeDifficultyCheck> checks=new List<NativeDifficultyCheck>();
  public List<NativeAllyGradedForesightRow> profiles=new List<NativeAllyGradedForesightRow>();
 }
 public static class NativeAllyGradedForesightValidation {
  static readonly Vector2Int Centre=new Vector2Int(10,10), Right=Vector2Int.right, Left=Vector2Int.left, Up=new Vector2Int(0,-1), Down=new Vector2Int(0,1);
  static readonly Vector2Int[] Directions={Right,Left,Up,Down};
  sealed class Fixture {public NativeGameplayWorld world;public NativePlayer ai;public int randomCalls;public Vector2Int target;}
  static void Check(NativeAllyGradedForesightReport r,bool pass,string name,string detail=""){r.assertions++;if(!pass)r.failures++;r.checks.Add(new NativeDifficultyCheck{name=name,passed=pass,detail=detail});}
  static void Group(NativeAllyGradedForesightReport r,string name,Action action){try{action();}catch(Exception e){Check(r,false,name+" completes",e.ToString());}}
  static bool Finite(double v)=>!double.IsNaN(v)&&!double.IsInfinity(v);
  static double[] SmoothValues(NativeAllyForesightProfile p)=>new[]{p.HorizonMs,p.Steps,p.CombinedThreatWeight,p.OverrideRisk,p.MinimumGain,p.ObjectiveWeight,p.CorridorSteps};
  static bool Equal(NativeAllyForesightProfile a,NativeAllyForesightProfile b)=>SmoothValues(a).Zip(SmoothValues(b),(x,y)=>Math.Abs(x-y)<1e-9).All(x=>x)&&a.BeamWidth==b.BeamWidth&&a.ExpansionLimit==b.ExpansionLimit&&a.PocketCells==b.PocketCells;
  static bool Increasing(NativeAllyForesightProfile a,NativeAllyForesightProfile b)=>b.HorizonMs>=a.HorizonMs&&b.Steps>=a.Steps&&b.BeamWidth>=a.BeamWidth&&b.ExpansionLimit>=a.ExpansionLimit&&b.CombinedThreatWeight>=a.CombinedThreatWeight&&b.ObjectiveWeight>=a.ObjectiveWeight&&b.PocketCells>=a.PocketCells&&b.CorridorSteps>=a.CorridorSteps&&b.OverrideRisk<=a.OverrideRisk&&b.MinimumGain<=a.MinimumGain;
  static NativeAllyGradedForesightRow Row(int tier,double age,double intensity,NativeAllyForesightProfile p)=>new NativeAllyGradedForesightRow{tier=tier,ageMs=age,intensity=intensity,horizonMs=p.HorizonMs,steps=p.Steps,beamWidth=p.BeamWidth,expansionLimit=p.ExpansionLimit,combinedThreatWeight=p.CombinedThreatWeight,overrideRisk=p.OverrideRisk,minimumGain=p.MinimumGain,objectiveWeight=p.ObjectiveWeight,pocketCells=p.PocketCells,corridorSteps=p.CorridorSteps};
  static void ProfileContract(NativeAllyGradedForesightReport r){
   var minimum=NativeAllyForesightProfile.ForIntensity(0);var maximum=NativeAllyForesightProfile.ForIntensity(4);
   Check(r,minimum.HorizonMs==450&&minimum.Steps==2&&minimum.BeamWidth==3&&minimum.ExpansionLimit==96&&minimum.CombinedThreatWeight==0&&minimum.OverrideRisk==.80&&minimum.MinimumGain==.24&&minimum.ObjectiveWeight==.15&&minimum.PocketCells==12&&minimum.CorridorSteps==1,"PICNIC retains a small but nonzero predictive budget");
   Check(r,maximum.HorizonMs==2400&&maximum.Steps==10&&maximum.BeamWidth==16&&maximum.ExpansionLimit==512&&maximum.CombinedThreatWeight==.18&&maximum.OverrideRisk==.55&&maximum.MinimumGain==.14&&maximum.ObjectiveWeight==1&&maximum.PocketCells==64&&maximum.CorridorSteps==4,"BRUTAL retains the validated maximum forecast constants");
   Check(r,Equal(NativeAllyForesightProfile.ForIntensity(-1),minimum)&&Equal(NativeAllyForesightProfile.ForIntensity(5),maximum),"Out-of-range finite intensity is bounded by the valid difficulty endpoints");
   bool finite=true,bounded=true,monotonic=true;string firstIssue="";var previous=minimum;
   for(int step=0;step<=400;step++){
    double intensity=step/100.0;var p=NativeAllyForesightProfile.ForIntensity(intensity);bool valid=SmoothValues(p).All(Finite);
    bool bounds=p.HorizonMs>=450&&p.HorizonMs<=2400&&p.Steps>=2&&p.Steps<=10&&p.BeamWidth>=3&&p.BeamWidth<=16&&p.ExpansionLimit>=96&&p.ExpansionLimit<=512&&p.PocketCells>=12&&p.PocketCells<=64&&p.CorridorSteps>=1&&p.CorridorSteps<=4&&p.CombinedThreatWeight>=0&&p.CombinedThreatWeight<=.18&&p.OverrideRisk>=.55&&p.OverrideRisk<=.80&&p.MinimumGain>=.14&&p.MinimumGain<=.24&&p.ObjectiveWeight>=.15&&p.ObjectiveWeight<=1;
    bool ordered=Increasing(previous,p);if((!valid||!bounds||!ordered)&&firstIssue=="")firstIssue="intensity="+intensity;finite&=valid;bounded&=bounds;monotonic&=ordered;previous=p;
   }
   Check(r,finite,"All fractional profiles remain finite",firstIssue);Check(r,bounded,"401 sampled intensities stay within the agreed CPU/search budgets",firstIssue);Check(r,monotonic,"Forecast reach and caution grow monotonically across all fractional intensities",firstIssue);
   for(int knot=1;knot<4;knot++){
    var left=SmoothValues(NativeAllyForesightProfile.ForIntensity(knot-1e-7));var right=SmoothValues(NativeAllyForesightProfile.ForIntensity(knot+1e-7));
    Check(r,left.Zip(right,(a,b)=>Math.Abs(a-b)<.001).All(x=>x),"Continuous forecast values do not jump at a difficulty boundary: intensity="+knot);
   }
  }
  static void TimeProgression(NativeAllyGradedForesightReport r){
   double[] ages={0,60000,120000,180000,240000,300000};
   for(int tier=0;tier<5;tier++){
    var start=NativeAllyForesightProfile.ForIntensity(tier);var previous=start;
    foreach(double age in ages){
     var difficulty=NativeDifficulty.ForIndex(tier,1,age);var p=NativeAllyForesightProfile.ForIntensity(difficulty.Intensity);r.profiles.Add(Row(tier,age,difficulty.Intensity,p));
     Check(r,Increasing(previous,p),"Predictive skill increases with the existing shared level clock: tier="+tier+", age="+age,"intensity="+difficulty.Intensity+", horizon="+p.HorizonMs);previous=p;
     if(age<=60000)Check(r,Equal(p,start),"The original first-minute grace does not silently change: tier="+tier+", age="+age);
     if(age==300000)Check(r,Equal(p,NativeAllyForesightProfile.ForIntensity(4)),"Each selected difficulty reaches the validated maximum profile at five minutes: tier="+tier);
    }
    var justAfter=NativeAllyForesightProfile.ForIntensity(NativeDifficulty.ForIndex(tier,1,60000.001).Intensity);
    Check(r,SmoothValues(start).Zip(SmoothValues(justAfter),(a,b)=>Math.Abs(a-b)<.001).All(x=>x),"Forecast begins rising continuously after the first minute: tier="+tier);
   }
  }
  static HashSet<Vector2Int> OpenRoom(){var cells=new HashSet<Vector2Int>();for(int y=3;y<=17;y++)for(int x=3;x<=17;x++)cells.Add(new Vector2Int(x,y));return cells;}
  static Fixture Make(int tier,HashSet<Vector2Int> cells){
   var f=new Fixture();var rows=Enumerable.Range(0,21).Select(_=>new string('#',21).ToCharArray()).ToArray();foreach(var c in cells)rows[c.y][c.x]='.';
   var w=new NativeGameplayWorld(rows.Select(row=>new string(row)).ToArray(),()=>{f.randomCalls++;return .99;}){AiDifficulty=tier,Difficulty=NativeMazeGenerator.Difficulties[tier],Time=1000,LevelStarted=1000,Assist=false,SessionEnabled=false};w.SetMode(0);f.world=w;f.ai=w.Player;f.ai.Cell=f.ai.From=f.ai.Previous=Centre;f.ai.Dir=f.ai.Next=Right;f.ai.Score=200;f.ai.ExactScore=200;f.ai.Waiting=false;f.ai.LastMove=w.Time-96;w.Ally.BeginLevel();return f;
  }
  static NativeGameplaySnake Snake(Fixture f,IEnumerable<Vector2Int> body,Vector2Int direction){var cells=body.ToList();var s=new NativeGameplaySnake{Id=10+f.world.Snakes.Count,Body=cells,Cell=cells[0],Dir=direction,Temperament=.5,LastMove=f.world.Time};f.world.Snakes.Add(s);return s;}
  static Fixture Pocket(int tier,bool nearby){
   var cells=new HashSet<Vector2Int>();for(int x=2;x<=16;x++)cells.Add(new Vector2Int(x,10));for(int y=1;y<=10;y++)cells.Add(new Vector2Int(10,y));for(int y=9;y<=14;y++)for(int x=2;x<=9;x++)cells.Add(new Vector2Int(x,y));
   var f=Make(tier,cells);f.target=new Vector2Int(16,10);Snake(f,new[]{f.target},Right);f.world.Hunters.Add(new NativeHunter{Id=100,Cell=new Vector2Int(10,nearby?9:1),From=new Vector2Int(10,nearby?9:1),Dir=Down,LastMove=f.world.Time-95,MotherAlive=false});return f;
  }
  static void HeldMeal(Fixture f){f.ai.Ai.mealInitialized=f.ai.Ai.mealActive=true;f.ai.Ai.mealIntentUntil=f.world.Time+10000;f.ai.Ai.allowSplit=true;}
  static void Plan(NativeAllyGradedForesightReport r,Fixture f){f.world.Ally.Plan(f.ai,f.world.Time);r.decisions++;}
  static NativeAllyForesightSample Inspect(Fixture f,Vector2Int direction,Vector2Int? target=null)=>f.world.Ally.InspectForesight(f.ai,f.world.Time,direction,target);
  static string Detail(NativeAllyForesightSample p)=>"risk="+p.risk+", pocket="+p.pocketRisk+", intercept="+p.interceptRisk+", gate="+p.exitArrivalMs+", return="+p.returnMs;
  static void ObviousAndDistantDanger(NativeAllyGradedForesightReport r){
   for(int tier=0;tier<5;tier++){
    var close=Pocket(tier,true);var profile=NativeAllyForesightProfile.ForIntensity(tier);var sample=Inspect(close,Right,close.target);Plan(r,close);
    Check(r,sample.risk>=profile.OverrideRisk,"Even a peaceful AI can recognize an obviously closing nearby exit: tier="+tier,Detail(sample));
    Check(r,!close.ai.Waiting&&close.ai.Next!=Right,"Every tier rejects the obvious near-gate trap instead of freezing: tier="+tier,"next="+close.ai.Next+"; "+Detail(sample));
    var far=Pocket(tier,false);sample=Inspect(far,Right,far.target);Plan(r,far);
    if(tier<=1)Check(r,sample.pocketRisk==0,"The two easiest tiers do not anticipate a hunter beyond their short horizon: tier="+tier,Detail(sample));
    if(tier==4){Check(r,sample.pocketRisk>0,"BRUTAL anticipates the same distant gate interception",Detail(sample));Check(r,!far.ai.Waiting&&far.ai.Next!=Right,"BRUTAL chooses another route before the distant trap becomes immediate","next="+far.ai.Next+"; "+Detail(sample));}
   }
  }
  static void SafeFoodAndAppetite(NativeAllyGradedForesightReport r){
   for(int tier=0;tier<5;tier++)foreach(var direction in Directions)foreach(bool tail in new[]{false,true}){
    var f=Make(tier,OpenRoom());f.ai.Dir=f.ai.Next=direction;HeldMeal(f);var snake=Snake(f,tail?new[]{Centre+direction*3,Centre+direction*2,Centre+direction}:new[]{Centre+direction},direction);
    var sample=Inspect(f,direction,Centre+direction);Plan(r,f);Check(r,f.ai.Next==direction&&!f.ai.Waiting,"Graded foresight preserves an unthreatened adjacent "+(tail?"tail":"head")+": tier="+tier+", direction="+direction,Detail(sample));
    f.world.AdvancePlayer();Check(r,!f.ai.Dead&&f.ai.Cell==Centre+direction&&(tail?snake.Body.Count==2&&f.ai.Score==225:!f.world.Snakes.Contains(snake)&&f.ai.Score==325),"Original contact and points remain intact for an unthreatened "+(tail?"tail":"head")+": tier="+tier+", direction="+direction,"score="+f.ai.Score);
   }
   for(int tier=0;tier<=1;tier++){
    var f=Make(tier,OpenRoom());var a=f.ai.Ai;a.mealInitialized=true;a.mealActive=false;a.mealIntentUntil=f.world.Time+10000;Snake(f,new[]{Centre+Right},Right);Plan(r,f);f.world.AdvancePlayer();
    Check(r,f.ai.Score==325&&!a.mealActive&&a.locked==null,"PICNIC/EASY can still eat an incidental safe head without starting a hunt: tier="+tier);
    f=Make(tier,OpenRoom());a=f.ai.Ai;a.mealInitialized=true;a.mealActive=false;a.mealIntentUntil=f.world.Time+10000;Snake(f,new[]{new Vector2Int(15,4)},Up);Plan(r,f);
    Check(r,!a.mealActive&&a.locked==null&&a.thought=="casual-roam","Predictive safety does not turn a peaceful stroll into a distant food hunt: tier="+tier,"thought="+a.thought);
   }
  }
  static string Snapshot(Fixture f)=>f.world.Time+"|"+f.ai.Cell+"|"+f.ai.Dir+"|"+f.ai.Next+"|"+f.ai.Score+"|"+f.ai.PowerUntil+"|"+f.ai.ShieldUntil+"|"+f.randomCalls+"|"+string.Join(";",f.world.Snakes.Select(s=>s.Id+":"+s.LastMove+":"+s.Dir+":"+string.Join(",",s.Body)))+"|"+string.Join(";",f.world.Hunters.Select(h=>h.Cell+":"+h.Dir+":"+h.LastMove));
  static void InspectionIsPure(NativeAllyGradedForesightReport r){
   for(int tier=0;tier<5;tier++){
    var f=Pocket(tier,true);string before=Snapshot(f);foreach(var d in Directions)for(int repeat=0;repeat<3;repeat++)Inspect(f,d,f.target);
    Check(r,Snapshot(f)==before,"Repeated graded inspections do not consume randomness, move actors or change contact state: tier="+tier);
   }
  }
  public static NativeAllyGradedForesightReport Run(){
   var watch=Stopwatch.StartNew();var r=new NativeAllyGradedForesightReport{scope="Editor-only graded predictive-budget, smooth level-age progression and real planner/contact checks. Peaceful appetite remains separate from predictive safety. Highest-tier constants stay at the previously validated maximum. No rendered/device performance or perfect-play claim."};
   Group(r,"profile contract",()=>ProfileContract(r));Group(r,"time progression",()=>TimeProgression(r));Group(r,"obvious and distant danger",()=>ObviousAndDistantDanger(r));Group(r,"safe food and appetite",()=>SafeFoodAndAppetite(r));Group(r,"inspection purity",()=>InspectionIsPure(r));r.elapsedMs=watch.Elapsed.TotalMilliseconds;r.passed=r.failures==0;return r;
  }
 }
}
#endif

using System;using System.IO;using System.Linq;using System.Collections;using System.Collections.Generic;using UnityEngine;
namespace MazeBiters.NativeStudy {
 public sealed partial class NativeMenu {
  bool balancedTesting;
  [Serializable] sealed class LaunchMemory {public long working,peak,committed,used,reserved;}
  [Serializable] sealed class LaunchFrame {public string phase;public double ms,gapMs,alpha;public bool focused;}
  [Serializable] sealed class BalancedResult {
   public bool passed,distributed,fastCache,focused,gameOverReady;public string quality,state,note;public int mode;
   public double menuAvailableMs,clickToPlayMs,totalToPlayMs,cpuToMenuMs,cpuToPlayMs,preparedAfterClickMs,restartClickMs,restartPreparedAfterClickMs,plannedBlinkMs,restartPlannedBlinkMs;
   public LaunchMemory menuMemory,playMemory;public string[] checks;public LaunchFrame[] frames;
  }
  static double ProcessCpu(){using(var p=System.Diagnostics.Process.GetCurrentProcess())return p.TotalProcessorTime.TotalMilliseconds;}
  static LaunchMemory LaunchMemoryNow(){NativeMemory.TryRead(out var w,out var p,out var c);return new LaunchMemory{working=w,peak=p,committed=c,used=UnityEngine.Profiling.Profiler.GetTotalAllocatedMemoryLong(),reserved=UnityEngine.Profiling.Profiler.GetTotalReservedMemoryLong()};}
  IEnumerator BalancedStartProbe(){
   Directory.CreateDirectory(Path.GetDirectoryName(report));var args=Environment.GetCommandLineArgs();int at=Array.IndexOf(args,"--mode"),mode=at<0?1:int.Parse(args[at+1]);
   bool lifecycle=Array.IndexOf(args,"--balanced-lifecycle")>=0;
   var r=new BalancedResult{mode=mode,quality=State.Quality,distributed=NativeBalancedLaunch.Distributed,fastCache=NativeBalancedLaunch.FastCache,preparedAfterClickMs=-1,restartPreparedAfterClickMs=-1};
   var checks=new List<string>();var frames=new List<LaunchFrame>();double last=Time.realtimeSinceStartupAsDouble;
   void Check(bool ok,string label){if(!ok){r.frames=frames.ToArray();r.checks=checks.ToArray();File.WriteAllText(report,JsonUtility.ToJson(r,true));throw new Exception("Balanced start: "+label+" ready="+r.preparedAfterClickMs+" click="+r.clickToPlayMs+" restart="+r.restartClickMs);}checks.Add(label);}
   void Frame(string phase){double now=Time.realtimeSinceStartupAsDouble;frames.Add(new LaunchFrame{phase=phase,ms=now*1000,gapMs=(now-last)*1000,alpha=State.Alpha("mode:"+State.SelectedMode,Now),focused=Application.isFocused});last=now;}
   IEnumerator Available(){double deadline=Time.realtimeSinceStartupAsDouble+120;while(!SelectionAvailable||Time.frameCount<=openedFrame){if(preloadFailed||Time.realtimeSinceStartupAsDouble>deadline)throw new TimeoutException("Menu selection gate");yield return null;Frame("loading");}}
   IEnumerator Click(int selection,bool restart){
    State.SetFocus(Array.IndexOf(NativeMenuState.Modes,selection),Now);double click=Time.realtimeSinceStartupAsDouble;Choose();last=click;
    while(!gameplay||!gameplay.MenuReady){
     if(LaunchReady&&PreparedForSelection){if(restart&&r.restartPreparedAfterClickMs<0)r.restartPreparedAfterClickMs=(Time.realtimeSinceStartupAsDouble-click)*1000;if(!restart&&r.preparedAfterClickMs<0)r.preparedAfterClickMs=(Time.realtimeSinceStartupAsDouble-click)*1000;}
     if(Time.realtimeSinceStartupAsDouble-click>120)throw new TimeoutException("Balanced launch completion");
     yield return null;Frame(restart?"restart-confirmation":"confirmation");
    }
    double elapsed=(Time.realtimeSinceStartupAsDouble-click)*1000;
    if(restart)r.restartClickMs=elapsed;else r.clickToPlayMs=elapsed;
    if(NativeBalancedLaunch.Distributed){double planned=State.PendingFinishAt-State.PendingAt;if(restart)r.restartPlannedBlinkMs=planned;else r.plannedBlinkMs=planned;
     Check(planned>=900&&Math.Abs(planned/300-Math.Round(planned/300))<1e-8,"confirmation ends at a full original blink cycle");
     Check(elapsed>=planned-1&&elapsed<planned+90,"play follows completed blink without additional loading pause");
     Check(confirmationPresentedFrame>=0&&State.Alpha("mode:"+selection,Now)==1,"completed bright caption frame presented before gameplay");
    }
    Check(gameplay.MenuMode==selection&&gameplay.MenuOptionsValid,"selected mode and current settings installed");
    Check(!NativeBalancedLaunch.Distributed||elapsed>=890,"original 900ms selection blink retained");
   }
   yield return Available();r.menuAvailableMs=Time.realtimeSinceStartupAsDouble*1000;r.cpuToMenuMs=ProcessCpu();r.menuMemory=LaunchMemoryNow();r.focused=Application.isFocused;
   if(Array.IndexOf(args,"--smooth-menu-navigation")>=0){double until=Time.realtimeSinceStartupAsDouble+1.2,next=0;int focus=0;while(Time.realtimeSinceStartupAsDouble<until){if(Time.realtimeSinceStartupAsDouble>=next){State.SetFocus(focus++%6,Now);TickSound("Tick");next=Time.realtimeSinceStartupAsDouble+.1;}yield return null;Frame("navigation");}Check(!State.Pending,"navigation remains active during preparation");}
   yield return Click(mode,false);r.totalToPlayMs=Time.realtimeSinceStartupAsDouble*1000;r.cpuToPlayMs=ProcessCpu();r.playMemory=LaunchMemoryNow();r.state=gameplay.InstantMenuState;
   Check(!string.IsNullOrEmpty(r.state),"frozen original state captured before control release");
   NativeStartupLoading.Save(report);last=Time.realtimeSinceStartupAsDouble;
   r.focused&=frames.Where(f=>f.phase=="confirmation").All(f=>f.focused);
   if(NativeBalancedLaunch.Distributed){var blink=frames.Where(f=>f.phase=="confirmation").ToArray();Check(blink.Min(f=>f.alpha)<.25&&blink.Max(f=>f.alpha)>.95,"chosen caption visibly blinks through original alpha cycle");Check(r.preparedAfterClickMs<=r.plannedBlinkMs+15&&r.preparedAfterClickMs>=0,"GPU and selected mode ready before confirmation finishes");if(r.preparedAfterClickMs>1200)Check(blink.Any(f=>f.ms>r.menuAvailableMs+900&&f.alpha<.3),"early click keeps blinking during unfinished cache");}
   for(int i=0;i<120;i++){yield return null;Frame("first-play");}
   if(lifecycle){
    if(mode==1||mode==0)gameplay.StartupLastLife();else gameplay.CoopLastLives();
    double deadline=Time.realtimeSinceStartupAsDouble+60;
    while(gameplay){r.gameOverReady|=gameplay.RestartPrepared;if(Time.realtimeSinceStartupAsDouble>deadline)throw new TimeoutException("GAME OVER");yield return null;Frame("game-over");}
    while(changing)yield return null;if(records!=null)CloseRecords();yield return Available();
    int calls=NativeStartupLoading.StageCalls("map CPU worker"),next=mode==4?1:4;
    yield return Click(next,true);
    if(NativeBalancedLaunch.Distributed){Check(NativeStartupLoading.StageCalls("map CPU worker")==calls,"mode change reuses GAME OVER first-map cache");Check(r.restartPreparedAfterClickMs>=0&&r.restartPreparedAfterClickMs<=r.restartPlannedBlinkMs+15,"restart finishes preparation during blink");}
   }
   r.passed=true;r.checks=checks.ToArray();r.frames=frames.ToArray();
   r.note="Immediate choice on first interactive menu frame. New policy blinks for at least 900ms, then until cache readiness rounded up to the final 300ms cycle. CPU summed across process threads, not percentage. First-play frames separate; no screenshots during timings. Fixed seed 34 unless omitted; no simulation tick in prepared worlds. Native HD/4K targets in a 1920x1080 window. OS file cache not flushed.";
   File.WriteAllText(report,JsonUtility.ToJson(r,true));Application.Quit();
  }
 }
}

mergeInto(LibraryManager.library, {
  $MBWAudio: {
    context: null, buses: {}, nextBus: 1, nextVoice: 1, unlock: null,
    start: function () {
      if (!MBWAudio.context) {
        var AudioContextClass = window.AudioContext || window.webkitAudioContext;
        if (!AudioContextClass) return false;
        MBWAudio.context = new AudioContextClass();
        MBWAudio.unlock = function () {
          var context = MBWAudio.context;
          if (context && context.state !== 'running') context.resume().catch(function () {});
        };
        document.addEventListener('pointerdown', MBWAudio.unlock, true);
        document.addEventListener('touchend', MBWAudio.unlock, true);
        document.addEventListener('keydown', MBWAudio.unlock, true);
      }
      return true;
    },
    stop: function (bus, id) {
      var voice = bus.voices[id];
      if (!voice) return;
      delete bus.voices[id];
      voice.source.onended = null;
      try { voice.source.stop(); } catch (e) {}
      voice.source.disconnect(); voice.pan.disconnect();
    }
  },
  MBWAudioCreate__deps: ['$MBWAudio'],
  MBWAudioCreate: function () {
    try {
      if (!MBWAudio.start()) return 0;
      var context = MBWAudio.context, gain = context.createGain(), compressor = context.createDynamicsCompressor(), output = context.createGain();
      gain.gain.value = 0.72;
      compressor.threshold.value = -10; compressor.knee.value = 12; compressor.ratio.value = 3;
      compressor.attack.value = 0.003; compressor.release.value = 0.16;
      gain.connect(compressor); compressor.connect(output); output.connect(context.destination);
      var id = MBWAudio.nextBus++;
      MBWAudio.buses[id] = {gain:gain, compressor:compressor, output:output, sounds:{}, voices:{}};
      return id;
    } catch (e) { console.error('Maze Biters audio initialization', e); return 0; }
  },
  MBWAudioRegister__deps: ['$MBWAudio'],
  MBWAudioRegister: function (id, namePtr, samplesPtr, length, channels, rate) {
    try {
      var bus = MBWAudio.buses[id]; if (!bus) return 0;
      var sound = MBWAudio.context.createBuffer(channels, length / channels, rate), start = samplesPtr >> 2;
      for (var c = 0; c < channels; c++) {
        var output = sound.getChannelData(c);
        for (var n = 0; n < output.length; n++) output[n] = HEAPF32[start + n * channels + c];
      }
      bus.sounds[UTF8ToString(namePtr)] = sound; return 1;
    } catch (e) { console.error('Maze Biters sound registration', e); return 0; }
  },
  MBWAudioPlay__deps: ['$MBWAudio'],
  MBWAudioPlay: function (id, namePtr, panValue) {
    var bus = MBWAudio.buses[id]; if (!bus) return 0;
    var buffer = bus.sounds[UTF8ToString(namePtr)]; if (!buffer) return 0;
    var context = MBWAudio.context, source = context.createBufferSource();
    // The native bus bypasses panning within .01 of center. This also preserves
    // its unattenuated mono-to-stereo center instead of equal-power -3 dB.
    var pan = Math.abs(panValue) < 0.01 ? context.createGain() : context.createStereoPanner();
    source.buffer = buffer;
    if (pan.pan) pan.pan.value = Math.max(-1, Math.min(1, panValue));
    source.connect(pan); pan.connect(bus.gain);
    var voiceId = MBWAudio.nextVoice++;
    bus.voices[voiceId] = {source:source, pan:pan, endsAt:context.currentTime + buffer.duration};
    source.onended = function () { if (bus.voices[voiceId]) { delete bus.voices[voiceId]; source.disconnect(); pan.disconnect(); } };
    source.start(); return voiceId;
  },
  MBWAudioPlaying__deps: ['$MBWAudio'],
  MBWAudioPlaying: function (id, voiceId) {
    var bus = MBWAudio.buses[id], voice = bus && bus.voices[voiceId]; if (!voice) return 0;
    if (MBWAudio.context.currentTime >= voice.endsAt) { MBWAudio.stop(bus, voiceId); return 0; }
    return 1;
  },
  MBWAudioStop__deps: ['$MBWAudio'],
  MBWAudioStop: function (id, voiceId) { var bus = MBWAudio.buses[id]; if (bus) MBWAudio.stop(bus, voiceId); },
  MBWAudioMute__deps: ['$MBWAudio'],
  MBWAudioMute: function (id, muted) { var bus = MBWAudio.buses[id]; if (bus) bus.output.gain.value = muted ? 0 : 1; },
  MBWAudioDestroy__deps: ['$MBWAudio'],
  MBWAudioDestroy: function (id) {
    var bus = MBWAudio.buses[id]; if (!bus) return;
    Object.keys(bus.voices).forEach(function (voice) { MBWAudio.stop(bus, voice); });
    bus.gain.disconnect(); bus.compressor.disconnect(); bus.output.disconnect(); delete MBWAudio.buses[id];
    if (!Object.keys(MBWAudio.buses).length && MBWAudio.context) {
      document.removeEventListener('pointerdown', MBWAudio.unlock, true);
      document.removeEventListener('touchend', MBWAudio.unlock, true);
      document.removeEventListener('keydown', MBWAudio.unlock, true);
      MBWAudio.context.close().catch(function () {}); MBWAudio.context = null; MBWAudio.unlock = null;
    }
  }
});

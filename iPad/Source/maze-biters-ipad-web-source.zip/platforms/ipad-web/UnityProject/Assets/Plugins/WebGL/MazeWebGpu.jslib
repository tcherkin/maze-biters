mergeInto(LibraryManager.library, {
  $MBWGpu: { next: 1, fences: {} },
  MBWGpuSubmit__deps: ['$MBWGpu', '$GL'],
  MBWGpuSubmit: function () {
    var gl = GL.currentContext && GL.currentContext.GLctx;
    if (!gl || typeof gl.fenceSync !== 'function' || gl.isContextLost()) return 0;
    var fence = gl.fenceSync(gl.SYNC_GPU_COMMANDS_COMPLETE, 0); if (!fence) return 0;
    gl.flush(); // Submit, never gl.finish or a nonzero client wait timeout.
    var id = MBWGpu.next++; MBWGpu.fences[id] = {gl:gl, fence:fence}; return id;
  },
  MBWGpuPoll__deps: ['$MBWGpu'],
  MBWGpuPoll: function (id) {
    var item = MBWGpu.fences[id]; if (!item || item.gl.isContextLost()) return -1;
    var gl = item.gl, result = gl.clientWaitSync(item.fence, 0, 0);
    if (result === gl.ALREADY_SIGNALED || result === gl.CONDITION_SATISFIED) return 1;
    return result === gl.TIMEOUT_EXPIRED ? 0 : -1;
  },
  MBWGpuRelease__deps: ['$MBWGpu'],
  MBWGpuRelease: function (id) {
    var item = MBWGpu.fences[id]; if (!item) return;
    if (!item.gl.isContextLost()) item.gl.deleteSync(item.fence);
    delete MBWGpu.fences[id];
  }
});

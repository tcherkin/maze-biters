mergeInto(LibraryManager.library, {
 MBWebStatus: function(ptr, progress, phase) { if(window.mazeWebStatus)window.mazeWebStatus(UTF8ToString(ptr),progress,phase); },
 MBWebState: function(ptr) {if(window.mazeWebState)window.mazeWebState(UTF8ToString(ptr));},
 MBWebSync: function(){FS.syncfs(false,function(error){if(error)console.warn('Local score save failed',error);});},
 MBWebPaused: function(){return document.hidden?1:0;}
});

mergeInto(LibraryManager.library, {
 $MBWLifecycle__deps: ['$MBWAudio'],
 $MBWLifecycle: {
  installed: false, blocked: false, generation: 0, origin: 0, pausedAt: 0, pausedTotal: 0, blurred: false,
  now: function () { return performance.now(); },
  refresh: function () {
   var blocked = document.hidden || MBWLifecycle.blurred || (document.hasFocus && !document.hasFocus());
   if (blocked !== MBWLifecycle.blocked) {
    var now = MBWLifecycle.now();
    if (blocked) { MBWLifecycle.pausedAt = now; MBWLifecycle.generation++; }
    else MBWLifecycle.pausedTotal += now - MBWLifecycle.pausedAt;
    MBWLifecycle.blocked = blocked;
    MBWAudio.setLifecycle(blocked);
   }
   return blocked;
  },
  install: function () {
   if (MBWLifecycle.installed) return;
   MBWLifecycle.installed = true; MBWLifecycle.origin = MBWLifecycle.now();
   // Element blur/focus does not bubble, but a capture listener also receives
   // it when a retry/tool button disappears. Only the browsing context owns
   // suspension; moving DOM focus to the canvas/body must never freeze a menu.
   window.addEventListener('blur', function (event) { if (event.target !== window) return; MBWLifecycle.blurred = true; MBWLifecycle.refresh(); }, false);
   window.addEventListener('focus', function (event) { if (event.target !== window) return; MBWLifecycle.blurred = false; MBWLifecycle.refresh(); }, false);
   document.addEventListener('visibilitychange', function () { MBWLifecycle.refresh(); }, true);
   window.addEventListener('pagehide', function () { MBWLifecycle.blurred = true; MBWLifecycle.refresh(); }, true);
   window.addEventListener('pageshow', function () { MBWLifecycle.blurred = false; MBWLifecycle.refresh(); }, true);
   MBWLifecycle.refresh();
  }
 },
 MBWLifecycleState__deps: ['$MBWLifecycle'],
 MBWLifecycleState: function () { MBWLifecycle.install(); MBWLifecycle.refresh(); return MBWLifecycle.generation * 2 + (MBWLifecycle.blocked ? 1 : 0); },
 MBWLifecycleSeconds__deps: ['$MBWLifecycle'],
 MBWLifecycleSeconds: function () {
  MBWLifecycle.install(); MBWLifecycle.refresh();
  var end = MBWLifecycle.blocked ? MBWLifecycle.pausedAt : MBWLifecycle.now();
  return Math.max(0, end - MBWLifecycle.origin - MBWLifecycle.pausedTotal) / 1000;
 }
});

mergeInto(LibraryManager.library, {
  $MBWScores: {
    key:'MazeBiters:iPad:v1:scores',
    read: function (json) {
      if (typeof json!=='string' || json.length>1048576) return null;
      var file;try {file=JSON.parse(json);}catch(error){return null;}
      if (!file || file.version!==1 || !Array.isArray(file.entries) || file.entries.length>25) return null;
      var entries=[];
      for(var i=0;i<file.entries.length;i++){
        var r=file.entries[i];
        if(!r || typeof r.id!=='string' || !r.id.length || r.id.length>128 || typeof r.name!=='string' || !/^[A-Z0-9'@,.?\-]{1,10}$/.test(r.name) || !Number.isInteger(r.score) || r.score<=0 || r.score>2147483647 || typeof r.createdAt!=='string' || !r.createdAt.length || r.createdAt.length>128)return null;
        if(r.level!==undefined&&(!Number.isInteger(r.level)||r.level<1||r.level>2147483647) || r.mode!==undefined&&(!Number.isInteger(r.mode)||r.mode<1||r.mode>5) || r.multiplier!==undefined&&(typeof r.multiplier!=='number'||!Number.isFinite(r.multiplier)))return null;
        if(r.modeLabel!==undefined&&(typeof r.modeLabel!=='string'||r.modeLabel.length>16) || r.difficulty!==undefined&&(typeof r.difficulty!=='string'||r.difficulty.length>12) || r.speed!==undefined&&(typeof r.speed!=='string'||r.speed.length>12))return null;
        if(r.playerIds!==undefined&&(!Array.isArray(r.playerIds)||r.playerIds.length>2||r.playerIds.some(function(id){return !Number.isInteger(id)||id<1||id>2147483647;})))return null;
        // Keep only the original record schema; unknown properties never reach
        // Unity's deserializer or grow the stored table unexpectedly.
        entries.push({id:r.id,name:r.name,createdAt:r.createdAt,modeLabel:r.modeLabel===undefined?'SOLO':r.modeLabel,difficulty:r.difficulty===undefined?'MEDIUM':r.difficulty,speed:r.speed===undefined?'MEDIUM':r.speed,score:r.score,level:r.level===undefined?1:r.level,mode:r.mode===undefined?1:r.mode,multiplier:r.multiplier===undefined?1:r.multiplier,playerIds:r.playerIds===undefined?[1]:r.playerIds.slice()});
      }
      return entries;
    },
    merge: function (incoming, latest) {
      var records=new Map();incoming.forEach(function(r){records.set(r.id,r);});
      latest.forEach(function(r){records.set(r.id,r);});
      var entries=Array.from(records.values());
      entries.sort(function(a,b){return b.score-a.score || (a.createdAt<b.createdAt?-1:a.createdAt>b.createdAt?1:0) || (a.id<b.id?-1:a.id>b.id?1:0);});
      return entries.slice(0,25);
    }
  },
  MBWScoreRead__deps: ['$MBWScores'],
  MBWScoreRead: function (backup, destination, capacity) {
    try {
      var value=window.localStorage.getItem(MBWScores.key+(backup?':backup':''));
      if (value===null) return 0;
      var length=lengthBytesUTF8(value)+1;
      if (destination && capacity>=length) stringToUTF8(value,destination,capacity);
      return length;
    } catch (error) { return -1; }
  },
  MBWScoreCommit__deps: ['$MBWScores'],
  MBWScoreCommit: function (jsonPointer, preserveUnreadable) {
    var incoming=MBWScores.read(UTF8ToString(jsonPointer));
    if (!incoming) return -3;
    try {
      var storage=window.localStorage, previous=storage.getItem(MBWScores.key);
      var latest=previous===null?[]:MBWScores.read(previous), damaged=previous!==null&&latest===null;
      if(damaged)latest=MBWScores.read(storage.getItem(MBWScores.key+':backup'))||[];
      var json=JSON.stringify({version:1,entries:MBWScores.merge(incoming,latest)});
      if (previous!==null) storage.setItem(MBWScores.key+((preserveUnreadable||damaged)?':unreadable':':backup'),previous);
      // localStorage.setItem is atomic: quota/security failures leave the old
      // primary value in place. A read-back precedes reporting success to Unity.
      // The merge handles stale sequential tabs. This is not a cross-process
      // transaction: localStorage does not offer compare-and-swap or a lock.
      storage.setItem(MBWScores.key,json);
      return storage.getItem(MBWScores.key)===json?1:-2;
    } catch (error) { return -1; }
  }
});

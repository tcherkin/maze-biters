mergeInto(LibraryManager.library, {
  $MBWScores: { key:'MazeBiters:iPad:v1:scores' },
  MBWScoreRead__deps: ['$MBWScores'],
  MBWScoreRead: function (backup, destination, capacity) {
    try {
      var value=window.localStorage.getItem(MBWScores.key+(backup?':backup':''));
      if (value===null) return 0;
      var length=lengthBytesUTF8(value)+1;
      if (destination && capacity>=length) stringToUTF8(value,destination,capacity);
      return length;
    } catch (error) { return -1; }
  },
  MBWScoreCommit__deps: ['$MBWScores'],
  MBWScoreCommit: function (jsonPointer, preserveUnreadable) {
    var json= UTF8ToString(jsonPointer), parsed;
    try { parsed=JSON.parse(json); } catch (error) { return -3; }
    if (!parsed || parsed.version!==1 || !Array.isArray(parsed.entries) || parsed.entries.length>25 || json.length>1048576) return -3;
    try {
      var storage=window.localStorage, previous=storage.getItem(MBWScores.key);
      if (previous!==null) storage.setItem(MBWScores.key+(preserveUnreadable?':unreadable':':backup'),previous);
      // localStorage.setItem is atomic: quota/security failures leave the old
      // primary value in place. A read-back precedes reporting success to Unity.
      storage.setItem(MBWScores.key,json);
      return storage.getItem(MBWScores.key)===json?1:-2;
    } catch (error) { return -1; }
  }
});

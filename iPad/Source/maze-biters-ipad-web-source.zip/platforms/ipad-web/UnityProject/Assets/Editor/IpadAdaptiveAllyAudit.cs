using System;
using System.IO;
using System.Linq;
using UnityEditor;
using UnityEngine;
using MazeBiters.NativeStudy;

public static class IpadAdaptiveAllyAudit {
 [MenuItem("Maze Biters/iPad/Validate adaptive ally intelligence")]
 public static void Run(){
  string directory=Path.GetFullPath(Path.Combine(Application.dataPath,"../../Results/adaptive-ally"));Directory.CreateDirectory(directory);
  var report=NativeAdaptiveAllyValidation.Run();string path=Path.Combine(directory,"adaptive-report.json");File.WriteAllText(path,JsonUtility.ToJson(report,true));
  Debug.Log("IPAD_ADAPTIVE_ALLY_CHECKS assertions="+report.assertions+" failures="+report.failures+" ticks="+report.ticks+" decisions="+report.decisions+" elapsedMs="+report.elapsedMs.ToString("F1"));
  foreach(var failed in report.checks.Where(c=>!c.passed))Debug.LogError("IPAD_ADAPTIVE_ALLY_FAILURE "+failed.name+": "+failed.detail);
  if(!report.passed)throw new InvalidOperationException("Adaptive ally validation failed "+report.failures+" checks. See "+path);
 }
}

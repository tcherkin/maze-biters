public static class IpadLevelAtmosphereAudit { public static void Run()=>MazeBiters.NativeStudy.NativeLevelAtmosphereValidation.Run(); }

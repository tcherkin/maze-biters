using System;
using System.IO;
using UnityEngine;
using MazeBiters.NativeStudy;
public static class IpadPowerAuraRelease {
 [Serializable]public sealed class Report{public bool passed;public int colors,combo;public string glide;public string scope="Power palette/transition rules and unchanged glide/combo clocks; desktop functional validation, not device performance.";}
 public static void Validate(){
  var r=new Report();r.colors=NativePowerAuraValidation.Run();string glide=NativeLanternGlideValidation.Run();r.glide="glide-clock-v2 validated";
  var combo=NativeComboValidation.Run();r.combo=combo.assertions;if(!combo.passed)throw new Exception("Combo regression");r.passed=true;
  string folder=Path.GetFullPath(Path.Combine(Application.dataPath,"../../Results/power-aura"));Directory.CreateDirectory(folder);File.WriteAllText(Path.Combine(folder,"validation.json"),JsonUtility.ToJson(r,true));Debug.Log("POWER_AURA_VALIDATION "+JsonUtility.ToJson(r));
 }
 public static void Build(){Validate();WebBuild.BuildArtifacts();}
}

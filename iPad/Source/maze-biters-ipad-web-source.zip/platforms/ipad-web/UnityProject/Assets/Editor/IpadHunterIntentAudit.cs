using System;
using System.IO;
using System.Linq;
using UnityEditor;
using UnityEngine;
using MazeBiters.NativeStudy;
public static class IpadHunterIntentAudit {
 [MenuItem("Maze Biters/iPad/Validate hunter intentions")]
 public static void Run(){
  string directory=Path.GetFullPath(Path.Combine(Application.dataPath,"../../Results/hunter-intentions"));Directory.CreateDirectory(directory);
  var report=NativeHunterIntentValidation.Run();string path=Path.Combine(directory,"validation-report.json");File.WriteAllText(path,JsonUtility.ToJson(report,true));
  Debug.Log("IPAD_HUNTER_INTENT_CHECKS "+report.assertions+" decisions="+report.decisions+" failures="+report.failures+" elapsedMs="+report.elapsedMs.ToString("F1"));
  foreach(var c in report.checks.Where(c=>!c.passed))Debug.LogError("IPAD_HUNTER_INTENT_FAILURE "+c.name+": "+c.detail);
  if(!report.passed)throw new InvalidOperationException("Hunter intention validation failed "+report.failures+" checks. See "+path);
 }
}

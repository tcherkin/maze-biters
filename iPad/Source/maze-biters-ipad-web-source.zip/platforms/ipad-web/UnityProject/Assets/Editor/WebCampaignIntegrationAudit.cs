using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Security.Cryptography;
using MazeBiters.NativeStudy;
using UnityEditor;
using UnityEngine;
using Debug=UnityEngine.Debug;

// Production WebGL CPU gate, independently checked before artwork creation.
// Uses the shared native generator as its reference, without external fixtures.
public static class WebCampaignIntegrationAudit {
 [Serializable] public sealed class Case {
  public uint seed;public int level,tier,attempt,snakes,openingChecks;public string family,theme,name,hash;
  public bool nativeExact,repeated,repeatExact,hybridFallback;
 }
 [Serializable] public sealed class Report {
  public bool passed;public int checks,failures,cases,retries,nativeExact,repeatCases,safeStartChecks,titleChecks,modeChecks;
  public double elapsedMilliseconds;public string generatedUtc;
  public string scope="Web production campaign and safe-opening retry gate: seed34 levels1-100 plus101/130/250/1000 at all five difficulties; seeds17/811 at1/2/25/100/130/250/1000; former failing seed221749 level2 at all five tiers. Every case protects all three starts; actual first snake steps are checked independently. Retries retain the original family, palette and naming seed. Deterministic repeats sample representative and reproduced cases. No physical iPad performance claim.";
  public List<string> issues=new List<string>();public List<Case> results=new List<Case>();
 }
 static readonly BindingFlags PrivateStatic=BindingFlags.NonPublic|BindingFlags.Static;
 static readonly MethodInfo Inspect=typeof(NativeSafeStartValidation).GetMethod("Inspect",PrivateStatic);
 static readonly MethodInfo SetStarts=typeof(NativeGameplayWorld).GetMethod("SetStarts",BindingFlags.NonPublic|BindingFlags.Instance);
 static string Output=>Path.GetFullPath(Path.Combine(Application.dataPath,"../../Results/full-integration"));
 static void Check(Report r,bool ok,string message){r.checks++;if(ok)return;r.failures++;if(r.issues.Count<100)r.issues.Add(message);}
 static string Hash(string[] rows){using(var sha=SHA256.Create())return BitConverter.ToString(sha.ComputeHash(System.Text.Encoding.UTF8.GetBytes(string.Join("\n",rows)))).Replace("-","").ToLowerInvariant();}
 static bool SameOpening(SessionLevel a,SessionLevel b)=>a.safeOpening!=null&&b.safeOpening!=null&&a.safeOpening.Length==b.safeOpening.Length&&a.safeOpening.Where((path,i)=>!path.SequenceEqual(b.safeOpening[i])).Count()==0;
 static NativeGameplayWorld World(SessionLevel level,int tier,int mode=4){
  var w=new NativeGameplayWorld(level.geometry,NativeMazeGenerator.Rng(9182)){Level=level.level,AiDifficulty=tier,Difficulty=NativeMazeGenerator.Difficulties[tier],Time=1000,LevelStarted=1000};w.SetMode(mode);SetStarts.Invoke(w,new object[]{level});
  for(int i=0;i<w.PlayerCount;i++){var p=w.GetPlayer(i);var s=level.starts[i];p.Cell=p.From=p.Previous=new Vector2Int(s.x,s.y);p.Dir=p.Next=s.dir;}
  w.SpawnLevelSnakes();return w;
 }
 static void One(Report r,uint seed,int number,int tier){
  string label="seed="+seed+" level="+number+" tier="+tier;double difficulty=NativeMazeGenerator.Difficulties[tier];
  var reference=NativeCampaignComposition.Generate(seed,number,difficulty);var level=WebPlayableMaze.Generate(seed,difficulty,number);var details=HybridMazeStudy.Report(level);
  var row=new Case{seed=seed,level=number,tier=tier,attempt=level.openingLayoutAttempt,theme=level.theme,family=details?.family,name=HybridLevelNames.EnglishName(level),hash=Hash(level.geometry),nativeExact=reference.geometry.SequenceEqual(level.geometry),hybridFallback=details?.fallback==true};r.cases++;r.results.Add(row);if(row.nativeExact)r.nativeExact++;if(row.attempt>0)r.retries++;
  Check(r,level.level==number&&level.geometry.Length==25&&level.geometry.All(x=>x.Length==36),label+" native grid and uncapped campaign");
  Check(r,details!=null&&details.passed&&details.family==HybridMazeStudy.FamilyForLevel(seed,number),label+" original seed family retained through preparation/retry");
  Check(r,level.theme==reference.theme&&level.paletteSeed==seed,label+" original palette and naming seed retained");
  Check(r,level.openingLayoutAttempt>=0&&level.openingLayoutAttempt<16,label+" bounded retry attempt");
  Check(r,level.safeOpening!=null&&level.safeOpening.Length>=4,label+" complete original opening proved before painting");
  Check(r,row.name.Split(new[]{' '},StringSplitOptions.RemoveEmptyEntries).Length==2,label+" concise two-word gemstone name");
  if(row.attempt==0)Check(r,row.nativeExact&&row.name==HybridLevelNames.EnglishName(reference),label+" viable native geometry and title are exact");
  else{
   uint candidateSeed=unchecked(seed+(uint)row.attempt*0x9e3779b9u);var candidate=NativeCampaignComposition.Generate(candidateSeed,number,difficulty,row.family);
   Check(r,candidate.geometry.SequenceEqual(level.geometry),label+" retry geometry matches deterministic same-family candidate");
   Check(r,row.name==HybridLevelNames.EnglishName(seed,number,reference.theme,row.family),label+" retry title follows campaign seed rather than retry seed");
  }
  var world=World(level,tier);row.snakes=world.Snakes.Count;var safety=new NativeSafeStartReport();Inspect.Invoke(null,new object[]{safety,world,label,true});row.openingChecks=safety.assertions;r.safeStartChecks+=safety.assertions;r.checks+=safety.assertions;
  Check(r,safety.failures==0,label+" independent three-start population safety: "+string.Join("; ",safety.failureDetails.Take(3)));
  var before=Enumerable.Range(0,world.PlayerCount).Select(world.GetPlayer).Select(p=>(player:p,score:p.Score,lives:p.Lives)).ToArray();
  foreach(var snake in world.Snakes.ToArray()){var head=snake.Head;var dir=snake.Dir;Check(r,world.SnakeStep(snake)&&snake.Head==head+dir,label+" first snake step follows its safe heading");}
  Check(r,before.All(p=>!p.player.Dead&&p.player.Score==p.score&&p.player.Lives==p.lives),label+" first steps leave all participants unharmed");
  row.repeated=seed==221749||new[]{1,2,25,100,130,250,1000}.Contains(number);
  if(row.repeated){var again=WebPlayableMaze.Generate(seed,difficulty,number);row.repeatExact=again.geometry.SequenceEqual(level.geometry)&&again.theme==level.theme&&again.openingLayoutAttempt==level.openingLayoutAttempt&&SameOpening(level,again)&&HybridLevelNames.EnglishName(again)==row.name;r.repeatCases++;Check(r,row.repeatExact,label+" repeat geometry, opening proof, palette, retry and name exact");}
 }
 static void Bags(Report r){
  foreach(uint seed in new uint[]{17,34,811,221749}){string previous=null;for(int first=1;first<=1000;first+=4){var families=Enumerable.Range(first,4).Select(n=>HybridMazeStudy.FamilyForLevel(seed,n)).ToArray();Check(r,families.Distinct().Count()==4&&families[0]!=previous,"four-family bag and boundary seed="+seed+" first="+first);previous=families[3];}}
 }
 static void Titles(Report r){
  int before=r.checks;var state=new HybridLevelTitleState();var owner=new object();var map=new object();
  void Tick(double t,bool ready=true,bool pause=false,bool clear=false,bool dead=false,bool revealed=true,double clearAlpha=1)=>state.Tick(owner,map,1000,t,ready,pause,clear,dead,revealed,clearAlpha);
  void Near(double a,double b,string name)=>Check(r,Math.Abs(a-b)<.000001,name);
  Tick(1000,false);Tick(9000,false);Check(r,state.Mode==HybridLevelTitleMode.Hidden&&state.Elapsed==0,"loading does not consume title time");
  Tick(9000);Near(state.Scale,.88,"intro starts88 percent");Near(state.Alpha,0,"intro starts transparent");Tick(9125);Near(state.Alpha,.0196759259259259,"intro faint entry");Tick(10625);Near(state.Alpha,1,"intro fully visible only near centre");
  Tick(11500);Near(state.Scale,.98125,"intro slow exit zoom");Near(state.Alpha,.5,"intro exit transparency");Tick(12250);Check(r,state.Mode==HybridLevelTitleMode.Hidden,"intro ends3250ms");
  Tick(12500,pause:true);Tick(12750,pause:true);Near(state.Alpha,1,"pause recalls name at first peak");Tick(12750+HybridLevelTitleState.PauseCycleMs*.5,pause:true);Near(state.Alpha,0,"pause name follows smooth blink");
  Tick(15000,clear:true,revealed:false);Check(r,state.Mode==HybridLevelTitleMode.Hidden,"completion reveal gate retained");Tick(15500,clear:true);Tick(15750,clear:true);Near(state.Alpha,1,"completion recalls name");Tick(15751,clear:true,clearAlpha:0);Near(state.Alpha,0,"completion name follows original blink");
  Tick(16000,dead:true);Check(r,state.Mode==HybridLevelTitleMode.Hidden,"game over suppresses title");map=new object();Tick(17000);Near(state.Elapsed,0,"new level resets title");Tick(17500);double elapsed=state.Elapsed;state.Freeze(20000);Tick(20000);Near(state.Elapsed,elapsed,"GPU preflight does not advance visible title");r.titleChecks=r.checks-before;
 }
 static void Modes(Report r){
  int before=r.checks;var first=WebPlayableMaze.Generate(34,1,1);var next=WebPlayableMaze.Generate(34,1,2);
  foreach(int mode in Enumerable.Range(0,6)){
   var w=new NativeGameplayWorld(first.geometry,NativeMazeGenerator.Rng(9191)){Difficulty=1,AiDifficulty=2};w.SetMode(mode);w.StartSession(n=>n==1?first:next);
   Check(r,w.Level==1&&w.PlayerCount==new[]{1,1,2,2,3,2}[mode]&&w.Grid.SequenceEqual(first.geometry),"mode starts on prepared hybrid map mode="+mode);
   var preview=w.PreviewNextLevel(next,NativeMazeGenerator.Rng(2121),5000);Check(r,preview.Mode==mode&&preview.PlayerCount==w.PlayerCount&&preview.Grid.SequenceEqual(next.geometry),"mode retains hybrid prepared next scene mode="+mode);
  }r.modeChecks=r.checks-before;
 }
 [MenuItem("Maze Biters/Web/Validate integrated campaign and titles")]
 public static void Run(){
  Directory.CreateDirectory(Output);var r=new Report{generatedUtc=DateTime.UtcNow.ToString("o")};var timer=Stopwatch.StartNew();
  try{
   Check(r,NativeCampaignComposition.Enabled,"production hybrid is enabled by default");Check(r,Inspect!=null&&SetStarts!=null,"independent native safe-start oracle available");
   foreach(int tier in Enumerable.Range(0,5))foreach(int number in Enumerable.Range(1,100).Concat(new[]{101,130,250,1000}))try{One(r,34,number,tier);}catch(Exception e){Check(r,false,"seed34 level="+number+" tier="+tier+": "+(e is TargetInvocationException&&e.InnerException!=null?e.InnerException:e));}
   foreach(uint seed in new uint[]{17,811})foreach(int tier in Enumerable.Range(0,5))foreach(int number in new[]{1,2,25,100,130,250,1000})try{One(r,seed,number,tier);}catch(Exception e){Check(r,false,"seed="+seed+" level="+number+" tier="+tier+": "+e);}
   foreach(int tier in Enumerable.Range(0,5))try{One(r,221749,2,tier);}catch(Exception e){Check(r,false,"former failing seed221749 level2 tier="+tier+": "+e);}
   Check(r,r.cases==595,"all595 production web campaign cases completed");Bags(r);Titles(r);Modes(r);
  }finally{timer.Stop();r.elapsedMilliseconds=timer.Elapsed.TotalMilliseconds;r.passed=r.failures==0;File.WriteAllText(Path.Combine(Output,"campaign-validation.json"),JsonUtility.ToJson(r,true));}
  Debug.Log("WEB_CAMPAIGN_INTEGRATION passed="+r.passed+" cases="+r.cases+" checks="+r.checks+" failures="+r.failures+" nativeExact="+r.nativeExact+" retries="+r.retries+" titleChecks="+r.titleChecks);
  foreach(var issue in r.issues)Debug.LogError("WEB_CAMPAIGN_FAILURE "+issue);
  if(!r.passed)throw new InvalidOperationException("Web campaign validation failed; see Results/full-integration/campaign-validation.json");
 }
}

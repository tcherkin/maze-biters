using System;
using System.IO;
using System.Collections.Generic;
using UnityEngine;
using MazeBiters.NativeStudy;

// The shipping swipe selector feeds the shipping cardinal-key movement engine.
// Finger lifecycle and native/browser event delivery are checked separately.
public static class IpadSwipeAudit {
 [Serializable] public sealed class Entry {public string name,detail;public bool passed;}
 [Serializable] public sealed class Report {public bool passed;public int checks,failures;public string revision="20261108-diagonal-swipe",note="Deterministic 8-way swipe and actual maze-cell movement checks. No renderer, simulated device, or performance claims.";public List<Entry> results=new List<Entry>();}
 static Report report;
 static readonly Vector2Int[] Directions={new Vector2Int(1,0),new Vector2Int(1,1),new Vector2Int(0,1),new Vector2Int(-1,1),new Vector2Int(-1,0),new Vector2Int(-1,-1),new Vector2Int(0,-1),new Vector2Int(1,-1)};
 static readonly int[] Masks={2,10,8,9,1,5,4,6};
 static Vector2 ScreenDelta(float degrees,float distance=80)=>new Vector2(Mathf.Cos(degrees*Mathf.Deg2Rad),-Mathf.Sin(degrees*Mathf.Deg2Rad))*distance;
 static int Mask(NativePlayer p){int mask=0;foreach(var k in p.Keys.Values){if(k.dir.x<0)mask|=1;if(k.dir.x>0)mask|=2;if(k.dir.y<0)mask|=4;if(k.dir.y>0)mask|=8;}return mask;}
 static NativeGameplayWorld World(int mode=1){
  var grid=new string[11];for(int y=0;y<11;y++)grid[y]=y==0||y==10?new string('#',11):"#.........#";
  var w=new NativeGameplayWorld(grid,()=>.5){Time=1000,Assist=false};w.SetMode(mode);
  for(int i=0;i<w.PlayerCount;i++){var p=w.GetPlayer(i);p.Cell=p.From=p.Previous=new Vector2Int(5,5);p.Dir=p.Next=Vector2Int.right;p.Waiting=true;}
  return w;
 }
 static void Wall(NativeGameplayWorld w,Vector2Int c){var row=w.Grid[c.y].ToCharArray();row[c.x]='#';w.Grid[c.y]=new string(row);}
 static void Check(bool ok,string name,string detail=""){report.checks++;if(!ok){report.failures++;Debug.LogError("SWIPE_FAILURE "+name+" "+detail);}report.results.Add(new Entry{name=name,passed=ok,detail=detail});}
 public static void Run(){
  report=new Report();
  try{Sectors();Hysteresis();Stepping();WallChoices();KeyContinuity();PlayersAndExternalKeys();}
  catch(Exception e){Check(false,"Audit completes without exception",e.ToString());}
  report.passed=report.failures==0;var directory=Path.GetFullPath(Path.Combine(Application.dataPath,"../../Results/diagonal-swipe"));Directory.CreateDirectory(directory);
  File.WriteAllText(Path.Combine(directory,"input-validation.json"),JsonUtility.ToJson(report,true));Debug.Log("SWIPE_INPUT_CHECKS "+report.checks+" failures="+report.failures);
  if(!report.passed)throw new Exception("Diagonal swipe validation failed; see Results/diagonal-swipe/input-validation.json");
 }
 static void Sectors(){
  for(int i=0;i<8;i++){
   foreach(float distance in new[]{20f,80f,160f})Check(IpadSwipeDirections.Choose(ScreenDelta(i*45,distance),Vector2Int.zero)==Directions[i],"Eight equal sectors independent of display-distance "+i+"/"+distance);
   var w=World();var p=w.Player;var direction=IpadSwipeDirections.Choose(ScreenDelta(i*45),Vector2Int.zero);IpadSwipeDirections.Sync(w,p,direction);
   Check(Mask(p)==Masks[i]&&p.Keys.Count==((i&1)==0?1:2),"Sector maps to original cardinal-key mask "+i);
   bool cardinal=true;foreach(var k in p.Keys.Values)cardinal&=Mathf.Abs(k.dir.x)+Mathf.Abs(k.dir.y)==1;
   Check(cardinal,"No illegal diagonal vector enters world keys "+i);
   int serial=p.KeySerial;var alternate=p.Alternate;
   for(int sample=0;sample<20;sample++)IpadSwipeDirections.Sync(w,p,direction);
   Check(p.KeySerial==serial&&p.Alternate==alternate,"Repeated samples preserve key order and alternation "+i);
   IpadSwipeDirections.Release(w,p);Check(p.Keys.Count==0,"Release removes all swipe axes "+i);
  }
  var previous=Vector2Int.zero;
  foreach(int i in new[]{0,1,2,3,4,5,6,7,0,4,0}){previous=IpadSwipeDirections.Choose(ScreenDelta(i*45),previous);Check(previous==Directions[i],"Held-finger sweep and reversal selects sector "+i);}
 }
 static void Hysteresis(){
  for(int i=0;i<8;i++){
   var initial=Directions[i];int next=(i+1)%8;float start=i*45;
   var retained=IpadSwipeDirections.Choose(ScreenDelta(start+25),initial);
   Check(retained==initial,"Boundary jitter retains current sector "+i);
   var crossed=IpadSwipeDirections.Choose(ScreenDelta(start+30),retained);
   Check(crossed==Directions[next],"Decisive turn enters adjacent sector "+i);
   Check(IpadSwipeDirections.Choose(ScreenDelta(start+20),crossed)==Directions[next],"Reverse jitter retains adjacent sector "+i);
   Check(IpadSwipeDirections.Choose(ScreenDelta(start+15),crossed)==initial,"Decisive reverse returns to sector "+i);
  }
 }
 static void Stepping(){
  for(int i=0;i<8;i++){
   var w=World();var p=w.Player;IpadSwipeDirections.Sync(w,p,Directions[i]);var start=p.Cell;Vector2Int previous=Vector2Int.zero;bool legal=true,alternating=true;
   int steps=(i&1)==0?3:6;
   for(int n=0;n<steps;n++){
    var before=p.Cell;w.Time+=120;w.AdvancePlayer();var delta=p.Cell-before;
    legal&=Mathf.Abs(delta.x)+Mathf.Abs(delta.y)==1&&w.Floor(p.Cell);
    if((i&1)!=0&&n>0)alternating&=delta!=previous&&delta.x*previous.x==0&&delta.y*previous.y==0;
    previous=delta;
   }
   Check(legal,"Actual movement advances only traversable cardinal cells "+i);
   Check(p.Cell-start==Directions[i]*3,"Actual movement reaches expected three-cell displacement "+i);
   if((i&1)!=0)Check(alternating,"Diagonal uses original alternating staircase "+i);
  }
 }
 static void WallChoices(){
  foreach(int i in new[]{1,3,5,7}){
   var d=Directions[i];
   foreach(bool blockHorizontal in new[]{true,false}){
    var w=World();var p=w.Player;var start=p.Cell;var horizontal=new Vector2Int(d.x,0);var vertical=new Vector2Int(0,d.y);
    Wall(w,start+(blockHorizontal?horizontal:vertical));IpadSwipeDirections.Sync(w,p,d);w.AdvancePlayer();
    Check(p.Cell==start+(blockHorizontal?vertical:horizontal),"Blocked diagonal axis uses open cardinal alternative "+i+"/"+blockHorizontal);
   }
   {
    var w=World();var p=w.Player;var start=p.Cell;
    foreach(var cardinal in NativeGameplayWorld.Dirs)Wall(w,start+cardinal);
    Check(w.Floor(start+d),"Corner fixture leaves diagonal destination open "+i);IpadSwipeDirections.Sync(w,p,d);
    w.AdvancePlayer();w.AdvancePlayer();Check(p.Cell==start,"Diagonal never cuts through blocked corner "+i);
   }
  }
 }
 static void KeyContinuity(){
  var w=World();var p=w.Player;var up=new Vector2Int(0,-1);IpadSwipeDirections.Sync(w,p,up);
  int upOrder=p.Keys["ipad-drag-up"].order;IpadSwipeDirections.Sync(w,p,new Vector2Int(1,-1));
  Check(p.Keys["ipad-drag-up"].order==upOrder&&p.Keys["ipad-drag-right"].order>upOrder,"Entering diagonal retains original axis and adds newest axis");
  Check(p.Next==Vector2Int.right,"Next follows newest actual cardinal key");int serial=p.KeySerial;
  var start=p.Cell;w.AdvancePlayer();Check(p.Cell-start==Vector2Int.right,"Existing-axis diagonal first follows newly requested axis");
  start=p.Cell;w.AdvancePlayer();Check(p.Cell-start==up,"Existing-axis diagonal then alternates original axis");
  IpadSwipeDirections.Sync(w,p,up);Check(p.KeySerial==serial&&p.Keys["ipad-drag-up"].order==upOrder&&p.Next==up,"Leaving diagonal keeps surviving key and restores Next without repressing");
  IpadSwipeDirections.Sync(w,p,new Vector2Int(-1,-1));Check(Mask(p)==5&&p.Keys["ipad-drag-up"].order==upOrder,"Adjacent diagonal replaces only changed axis");
  Check(!p.Keys.ContainsKey("ipad-drag-right")&&p.Next==Vector2Int.left,"Removed axis cannot remain pending after direction change");
 }
 static void PlayersAndExternalKeys(){
  foreach(int mode in new[]{0,1,2,3,4,5}){
   var w=World(mode);var p=w.GetPlayer(0);IpadSwipeDirections.Sync(w,p,new Vector2Int(1,-1));
   Check(mode==0?p.Keys.Count==0:Mask(p)==6,"Selected player's human/AI status respected "+mode);
   for(int slot=1;slot<w.PlayerCount;slot++)Check(w.GetPlayer(slot).Keys.Count==0,"P1 swipe does not steer other participant "+mode+"/"+slot);
   IpadSwipeDirections.Release(w,p);
  }
  {
   var w=World();var p=w.Player;w.Press("W",new Vector2Int(0,-1));w.Press("GamepadSlot0:right",Vector2Int.right);
   int keyboardOrder=p.Keys["W"].order,gamepadOrder=p.Keys["GamepadSlot0:right"].order;
   IpadSwipeDirections.Sync(w,p,new Vector2Int(-1,1));IpadSwipeDirections.Release(w,p);
   Check(p.Keys.Count==2&&p.Keys["W"].order==keyboardOrder&&p.Keys["GamepadSlot0:right"].order==gamepadOrder,"Swipe release preserves external keyboard/controller keys and order");
   int serial=p.KeySerial;IpadSwipeDirections.Release(w,p);Check(p.KeySerial==serial&&p.Keys.Count==2,"Repeated release has no external side effects");
  }
  {
   var w=World(4);var p=w.GetPlayer(0);var other=w.GetPlayer(1);
   using(w.ForPlayer(other)){IpadSwipeDirections.Sync(w,p,new Vector2Int(1,1));Check(w.Player==other&&other.Keys.Count==0&&Mask(p)==10,"Explicit target preserves enclosing player scope");IpadSwipeDirections.Release(w,p);Check(w.Player==other,"Release preserves enclosing player scope");}
   IpadSwipeDirections.Sync(w,w.GetPlayer(2),new Vector2Int(1,-1));Check(w.GetPlayer(2).Keys.Count==0,"Explicit AI target cannot receive swipe keys");
  }
 }
}

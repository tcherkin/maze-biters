using System;using System.IO;using System.Security.Cryptography;using UnityEngine;
// Focused Web-only release: the actual bootstrap is covered by the boundary
// regression fixture. Build provenance does not claim device performance.
public static class WebFirstLevelRelease {
 [Serializable] sealed class Report {public bool passed;public string buildGuid,bootstrapSha256;public string scope="Exact validated bootstrap source and successful WebGL artifact build; pipeline fixtures and actual browser checks are separate evidence.";}
 [Serializable] sealed class Identity {public string buildGuid;}
 public static void Build(){
  string source=Path.Combine(Application.dataPath,"Scripts/WebBootstrap.cs"),hash;
  using(var sha=SHA256.Create())hash=BitConverter.ToString(sha.ComputeHash(File.ReadAllBytes(source))).Replace("-","").ToLowerInvariant();
  if(hash!="69ab8c985d29c765f09054d8a132db251724580db3950054d48f0bd051c03602")throw new InvalidOperationException("Bootstrap changed after pipeline validation");
  WebBuild.BuildArtifacts();
  string info=Path.GetFullPath(Path.Combine(Application.dataPath,"../../Builds/iPad/build-info.json"));
  var r=new Report{passed=true,buildGuid=JsonUtility.FromJson<Identity>(File.ReadAllText(info)).buildGuid,bootstrapSha256=hash};
  string folder=Path.GetFullPath(Path.Combine(Application.dataPath,"../../Results/first-level-loading"));Directory.CreateDirectory(folder);
  File.WriteAllText(Path.Combine(folder,"build-validation.json"),JsonUtility.ToJson(r,true));Debug.Log("WEB_FIRST_LEVEL_RELEASE_SUCCESS "+r.buildGuid);
 }
}

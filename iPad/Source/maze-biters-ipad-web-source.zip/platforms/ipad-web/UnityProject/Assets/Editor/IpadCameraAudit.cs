using System;
using System.IO;
using System.Text;
using System.Globalization;
using UnityEngine;
using MazeBiters.NativeStudy;

// Controlled routes use the actual player interpolation and original PC camera.
// They isolate presentation behaviour from wall collisions and rendering cost.
public static class IpadCameraAudit {
 public static void Baseline()=>Run(false);
 public static void Compare()=>Run(true);
 static void Run(bool compare){
  string dir=Path.GetFullPath(Path.Combine(Application.dataPath,"../../Results/camera-motion/"+(compare?"comparison":"baseline")));Directory.CreateDirectory(dir);
  foreach(int fps in new[]{60,120})foreach(bool vertical in new[]{true,false})foreach(double pace in new[]{1.0,1.4}){
   var p=new NativePlayer{Id=1,Cell=new Vector2Int(1,1),From=new Vector2Int(1,1),MoveDuration=95,LastMove=4000};
   if(vertical)p.Cell=p.From=new Vector2Int(18,1);else p.Cell=p.From=new Vector2Int(1,12);
   var raw=new NativeGameplayCamera();raw.Reset(0);var motion=new IpadCameraMotion();var f=new NativeFrame(4f/3,true);var pc=new NativeFrame(16f/9,true);var safe=new Rect(0,0,f.Width,f.Height);double close=160.0*432/(16*2064);
   var csv=new StringBuilder("time,px,py,rawX,rawY,rawZoom,pcX,pcY,pcZoom,ipadX,ipadY,ipadZoom,guardX,guardY,guardZoom,screenX,screenY,newX,newY,newZoom,newScreenX,newScreenY,emergency\n");
   int direction=1;double waitUntil=4000;double game=0;
   for(int frame=0;frame<fps*30;frame++){
    double real=frame*1000.0/fps;game+=1000.0/fps*pace;
    if(real>=4000&&real>=waitUntil&&game-p.LastMove>95){
     int cell=vertical?p.Cell.y:p.Cell.x,max=vertical?23:34;
     if(cell==max&&direction>0||cell==1&&direction<0){direction=-direction;waitUntil=real+650;}
     else {p.From=p.Cell;p.Cell+=vertical?new Vector2Int(0,direction):new Vector2Int(direction,0);p.MoveStarted=game;p.MoveDuration=95;p.LastMove=game;}
    }
    var pos=p.Visual(game);double px=(pos.x+.5)*16,py=(pos.y+.5)*16;raw.Update(p,px,py,false,false,false,false,real,game);
    double pz=NativeOverviewFraming.Zoom(pc,raw.Zoom),pcY=NativeOverviewFraming.Y(pc,raw.Y,raw.Zoom,pz);pcY=pc.KeepVisibleY(raw.Y,pcY,pz,py);
    var v=IpadFraming.Calculate(f,raw.X,raw.Y,raw.Zoom,close,safe);var before=v;v=IpadFraming.KeepPlayers(f,v,Rect.MinMaxRect((float)px,(float)py,(float)px,(float)py),safe);
    var next=motion.Sample(f,raw.X,raw.Y,raw.Zoom,close,safe,Rect.MinMaxRect((float)px,(float)py,(float)px,(float)py),real,raw.TargetX,raw.TargetY);
    var values=new[]{real,px,py,raw.X,raw.Y,raw.Zoom,raw.X,pcY,pz,v.x,v.y,v.zoom,v.x-before.x,v.y-before.y,v.zoom-before.zoom,288+(px-v.x)*v.zoom,216+(py-v.y)*v.zoom,next.x,next.y,next.zoom,288+(px-next.x)*next.zoom,216+(py-next.y)*next.zoom,(double)motion.EmergencyCorrections};
    for(int i=0;i<values.Length;i++){if(i>0)csv.Append(',');csv.Append(values[i].ToString("R",CultureInfo.InvariantCulture));}csv.AppendLine();
   }
   File.WriteAllText(Path.Combine(dir,(vertical?"vertical":"horizontal")+"-"+fps+"-"+pace.ToString(CultureInfo.InvariantCulture)+".csv"),csv.ToString());
  }
  Debug.Log("IPAD_CAMERA_MOTION_TESTS "+IpadCameraMotionValidation.Run());Debug.Log("IPAD_CAMERA_AUDIT "+dir);
 }
}

using System;
using System.Collections.Generic;
using System.IO;
using MazeBiters.NativeStudy;
using UnityEngine;

public static class WebHolisticRenderAudit {
 [Serializable]public sealed class CorePair {
  public bool passed;public string theme,quality;
  public WebCrystalMaterialCase reference,optimized;
 }
 [Serializable]public sealed class Report {
  public bool passed;public string error;
  public string scope="Accepted native renderer optimizations in the Web copy: exact Unity mesh/material/active light records, route vectors and slot/part boundaries, all9palette HD/4K angle/material calibration pairs. Existing WebPreparationValidation separately checks complete cooperative RGBA/receiver hashes and cancellation. No repeated90-raster suite or browser/device-performance claim.";
  public HolisticRuntimeRenderReport runtime;public HolisticRendererReport routes;
  public List<CorePair> cores=new List<CorePair>();
 }
 public static void Run(){
  string folder=Path.GetFullPath(Path.Combine(Application.dataPath,"../../Results/holistic-optimization"));Directory.CreateDirectory(folder);
  var report=new Report();bool angles=NativeHolisticTuning.CoreAngles;
  try{
   report.runtime=NativeSnake.ValidateHolisticRuntimeRender();if(!report.runtime.passed)throw new InvalidOperationException(report.runtime.error);
   report.routes=NativeMazeArtwork.ValidateWebHolisticRoutes();if(!report.routes.passed)throw new InvalidOperationException(report.routes.error);
   var source=NativeCampaignComposition.Generate(811,91,NativeMazeGenerator.Difficulties[2]);
   foreach(string quality in new[]{"hd","4k"})foreach(string theme in NativeMazeGenerator.Themes){
    var level=JsonUtility.FromJson<SessionLevel>(JsonUtility.ToJson(source));level.theme=theme;var pair=new CorePair{theme=theme,quality=quality};report.cores.Add(pair);
    NativeHolisticTuning.CoreAngles=false;pair.reference=NativeMazeArtwork.ValidateWebCrystalMaterial(level,quality);
    NativeHolisticTuning.CoreAngles=true;pair.optimized=NativeMazeArtwork.ValidateWebCrystalMaterial(level,quality);
    pair.passed=pair.reference.passed&&pair.optimized.passed&&JsonUtility.ToJson(pair.reference)==JsonUtility.ToJson(pair.optimized);
    if(!pair.passed)throw new InvalidOperationException("Web fixed-angle material/geometry mismatch "+theme+"/"+quality);
   }
   report.passed=report.cores.Count==18;
  }catch(Exception error){report.error=error.ToString();report.passed=false;}
  finally{NativeHolisticTuning.CoreAngles=angles;File.WriteAllText(Path.Combine(folder,"render-audit.json"),JsonUtility.ToJson(report,true));}
  Debug.Log("WEB_HOLISTIC_RENDER_AUDIT passed="+report.passed+" corePairs="+report.cores.Count);
  if(!report.passed)throw new InvalidOperationException(report.error);
 }
}

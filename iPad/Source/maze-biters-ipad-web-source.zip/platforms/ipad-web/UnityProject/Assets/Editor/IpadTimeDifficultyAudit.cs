using System;
using System.IO;
using System.Linq;
using UnityEditor;
using UnityEngine;
using MazeBiters.NativeStudy;

public static class IpadTimeDifficultyAudit {
 [MenuItem("Maze Biters/iPad/Validate time difficulty escalation")]
 public static void Run(){
  string directory=Path.GetFullPath(Path.Combine(Application.dataPath,"../../Results/time-escalation"));Directory.CreateDirectory(directory);
  var report=NativeTimeDifficultyValidation.Run();string path=Path.Combine(directory,"time-difficulty-report.json");File.WriteAllText(path,JsonUtility.ToJson(report,true));
  File.WriteAllText(Path.Combine(directory,"validation-method.txt"),report.scope+"\nThe suite observes all public profile double fields at multiple levels, dense time samples, actual snake decisions at a junction, a persistent AI policy cache, real death/respawn/next-level methods, and lifecycle population limits. Seeded local fixtures are functional checks, not complete player sessions.\n");
  Debug.Log("IPAD_TIME_DIFFICULTY_CHECKS "+report.assertions+" decisions="+report.decisions+" failures="+report.failures+" elapsedMs="+report.elapsedMs.ToString("F1"));
  foreach(var check in report.checks.Where(c=>!c.passed))Debug.LogError("IPAD_TIME_DIFFICULTY_FAILURE "+check.name+": "+check.detail);
  if(!report.passed)throw new InvalidOperationException("Time difficulty validation failed "+report.failures+" checks. See "+path);
 }
}

using System;
using System.IO;
using System.Linq;
using System.Collections.Generic;
using UnityEngine;
using MazeBiters.NativeStudy;

public static class IpadStartPaletteAudit {
 [Serializable] public sealed class Report {public bool passed;public int checks,campaigns,modeCases,previewCases;public int distinctOpeningSets,distinctOpeningOrders;public int[] snakeFirstAppearances=new int[8],mazeFirstAppearances=new int[9];public string[] examples;}
 sealed class Tape {public uint state;public int draws;public Tape(uint seed){state=seed;}public double Next(){draws++;unchecked{state+=0x6D2B79F5;uint v=(state^(state>>15))*(1|state);v^=v+(v^(v>>7))*(61|v);return (v^(v>>14))/4294967296.0;}}}
 static string Colours(NativeGameplayWorld w)=>string.Join(",",w.Snakes.Select(s=>s.Palette));
 static string Shape(NativeGameplayWorld w)=>string.Join(";",w.Snakes.Select(s=>s.Id+":"+s.Dir+":"+s.Temperament.ToString("R",System.Globalization.CultureInfo.InvariantCulture)+":"+s.TurnBias.ToString("R",System.Globalization.CultureInfo.InvariantCulture)+":"+string.Join("/",s.Body)));
 public static void Validate(){
  var r=new Report();var sets=new HashSet<string>();var orders=new HashSet<string>();var examples=new List<string>();
  var topology=new NativeMazeGenerator(34);var fixedFirst=topology.Generate(1);var fixedNext=topology.Generate(2);
  void Check(bool ok,string why){r.checks++;if(!ok)throw new Exception("START_PALETTE "+why);}
  // The maze seed is already randomly chosen by boot/menu/GAME OVER. Keep all
  // gameplay tapes fixed here, reproducing the previously identical openings.
  for(uint index=0;index<64;index++){
   uint seed=unchecked(index*0x9e3779b9u+117);var generator=new NativeMazeGenerator(seed);var first=generator.Generate(1);var next=generator.Generate(2);
   Check(first.paletteSeed==seed&&next.paletteSeed==seed,"generation carries campaign appearance seed");
   r.mazeFirstAppearances[Array.IndexOf(NativeMazeGenerator.Themes,first.theme)]++;
   // Isolate appearance from unrelated random-layout placement failures: use
   // the established six-mode fixture topology with each new campaign seed.
   first.geometry=fixedFirst.geometry;next.geometry=fixedNext.geometry;
   string modeColours=null;
   foreach(int mode in NativeMenuState.Modes){
    var tape=new Tape(34);var w=new NativeGameplayWorld(first.geometry,tape.Next);w.SetMode(mode);w.StartSession(n=>n==1?first:next);
    var colours=w.Snakes.Select(s=>s.Palette).ToArray();string order=Colours(w);
    Check(w.SnakePaletteSeed==seed&&colours.Length==4&&colours.Distinct().Count()==4,"all modes receive four distinct opening colours");
    if(modeColours==null)modeColours=order;else Check(order==modeColours,"all cached modes share the same colour surface pool");
    var controlLevel=new SessionLevel{level=first.level,geometry=first.geometry,theme=first.theme,starts=first.starts};
    var controlTape=new Tape(34);var control=new NativeGameplayWorld(first.geometry,controlTape.Next);control.SetMode(mode);control.StartSession(_=>controlLevel);
    Check(tape.state==controlTape.state&&tape.draws==controlTape.draws,"appearance never consumes gameplay randomness");
    Check(Shape(w)==Shape(control)&&w.MusicTrack==control.MusicTrack,"same bodies, directions, temperament and music");
    if(index<4){
     w.Snakes.Clear();w.CheckLevelComplete();double at=w.TransitionAt+NativeGameplayWorld.ClearDuration;
     var copied=new Tape(tape.state);var preview=w.PreviewNextLevel(next,copied.Next,at);w.Time=at;w.AdvanceLevel();
     Check(preview.SnakePaletteSeed==seed&&w.SnakePaletteSeed==seed,"next scene retains appearance seed");
     Check(Colours(preview)==Colours(w)&&Shape(preview)==Shape(w),"GPU-prepared next scene matches live adoption");r.previewCases++;
    }
    r.modeCases++;
   }
   var opening=modeColours.Split(',').Select(int.Parse).ToArray();foreach(int c in opening)r.snakeFirstAppearances[c]++;
   sets.Add(string.Join(",",opening.OrderBy(c=>c)));orders.Add(modeColours);r.campaigns++;
   if(index<8)examples.Add(seed+" / "+first.theme+" / "+string.Join(", ",opening.Select(c=>NativeSnakePalettes.Names[c])));
   // Reordered/cancelled preparation and quality changes cannot reroll colours.
   var original=new[]{1,2,3,4};var planned=NativeSnakePalettes.Expand(original,1,seed);
   NativeSnakePalettes.Expand(original,7,seed);Check(planned.SequenceEqual(NativeSnakePalettes.Expand(original,1,seed)),"order-independent preparation");
  }
  Check(r.snakeFirstAppearances.All(n=>n>0),"all eight snake palettes can appear from level one");
  Check(r.mazeFirstAppearances.All(n=>n>0),"all nine maze palettes can start a game");
  Check(sets.Count>=20&&orders.Count>=40,"fresh campaign seeds vary colours despite the fixed gameplay tape");
  r.distinctOpeningSets=sets.Count;r.distinctOpeningOrders=orders.Count;r.examples=examples.ToArray();r.passed=true;
  var dir=Path.GetFullPath(Path.Combine(Application.dataPath,"../../Results/random-start-colours"));Directory.CreateDirectory(dir);File.WriteAllText(Path.Combine(dir,"logic.json"),JsonUtility.ToJson(r,true));
  Debug.Log("START_PALETTE_CHECKS "+r.checks+" campaigns="+r.campaigns+" modes="+r.modeCases+" sets="+sets.Count+" orders="+orders.Count);
 }
}

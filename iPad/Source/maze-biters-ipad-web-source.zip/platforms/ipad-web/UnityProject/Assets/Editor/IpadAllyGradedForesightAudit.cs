using System;
using System.IO;
using System.Linq;
using UnityEditor;
using UnityEngine;
using MazeBiters.NativeStudy;

public static class IpadAllyGradedForesightAudit {
 [MenuItem("Maze Biters/iPad/Validate graded predictive planning")]
 public static void Run(){
  string directory=Path.GetFullPath(Path.Combine(Application.dataPath,"../../Results/ally-foresight"));Directory.CreateDirectory(directory);
  var report=NativeAllyGradedForesightValidation.Run();string path=Path.Combine(directory,"graded-foresight-report.json");File.WriteAllText(path,JsonUtility.ToJson(report,true));
  Debug.Log("IPAD_ALLY_GRADED_FORESIGHT_CHECKS "+report.assertions+" decisions="+report.decisions+" failures="+report.failures+" elapsedMs="+report.elapsedMs.ToString("F1"));
  foreach(var check in report.checks.Where(c=>!c.passed))Debug.LogError("IPAD_ALLY_GRADED_FORESIGHT_FAILURE "+check.name+": "+check.detail);
  if(!report.passed)throw new InvalidOperationException("Graded predictive validation failed "+report.failures+" checks. See "+path);
 }
}

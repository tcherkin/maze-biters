using System;
using System.IO;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using MazeBiters.NativeStudy;
using UnityEngine;

public static class WebCoreLightRelease {
 [Serializable] public sealed class OracleCase {public uint seed;public int level,tier;public string hash;}
 [Serializable] public sealed class Oracle {public string sourceSHA256;public OracleCase[] cases;}
 [Serializable] public sealed class Report {
  public bool passed;public string error,oracleSHA256;
  public string scope="Actual Web project default campaign bridge compared with all300 frozen approved automatic maps; original central controls retained; exact WebGL light-record texture transport, continuous32-stream source evaluation and unchanged Power/combo/glide validation. Full existing web campaign/safe-opening/renderer/input audits follow before IL2CPP build. No physical-device/performance claim.";
  public int cases,exact,centralControls;public WallLightContinuityReport lights;public WebWallLightRecordAudit records;
 }
 static string Folder=>Path.GetFullPath(Path.Combine(Application.dataPath,"../../Results/core-light-integration"));
 static string Hash(string[] rows){using(var h=SHA256.Create())return BitConverter.ToString(h.ComputeHash(Encoding.UTF8.GetBytes(string.Join("\n",rows)))).Replace("-","").ToLowerInvariant();}
 public static void Validate(){
  Directory.CreateDirectory(Folder);var report=new Report();
  try {
   if(!NativeCampaignComposition.Enabled||!NativeCampaignComposition.MixedCoresEnabled)throw new InvalidOperationException("Default mixed campaign bridge is disabled");
   var oracle=JsonUtility.FromJson<Oracle>(File.ReadAllText(Path.Combine(Application.dataPath,"Editor/CoreCompositionApproved300.json")));
   if(oracle.cases.Length!=300||oracle.cases.Select(c=>c.seed+"/"+c.level).Distinct().Count()!=300)throw new InvalidOperationException("Incomplete approved oracle");
   report.oracleSHA256=oracle.sourceSHA256;
   foreach(var sample in oracle.cases){
    var map=NativeCampaignComposition.Generate(sample.seed,sample.level,NativeMazeGenerator.Difficulties[sample.tier]);var core=CoreCompositionStudy.Report(map);report.cases++;
    if(core==null||!core.passed||core.requested!="automatic"||Hash(map.geometry)!=sample.hash)throw new InvalidOperationException("Approved automatic geometry differs "+sample.seed+"/"+sample.level);
    report.exact++;
    if(core.profile=="central"){
     var original=HybridMazeStudy.Generate(sample.seed,sample.level,NativeMazeGenerator.Difficulties[sample.tier]);
     if(!original.geometry.SequenceEqual(map.geometry))throw new InvalidOperationException("Original central composition changed");report.centralControls++;
    }
   }
   report.lights=NativeWallLightContinuityValidation.Run();
   if(!report.lights.passed)throw new InvalidOperationException("Light continuity: "+string.Join("; ",report.lights.issues));
   report.records=NativeMazeArtwork.ValidateWebWallLightRecords();
   if(!report.records.passed)throw new InvalidOperationException("WebGL light-record texture transport changed");
   IpadPowerAuraRelease.Validate();report.passed=true;
  }catch(Exception e){report.error=e.ToString();}
  finally {File.WriteAllText(Path.Combine(Folder,"validation.json"),JsonUtility.ToJson(report,true));}
  Debug.Log("WEB_CORE_LIGHT_VALIDATION passed="+report.passed+" exact="+report.exact+" central="+report.centralControls+" newJumps="+(report.lights?.newVisibleJumps??-1));
  if(!report.passed)throw new InvalidOperationException(report.error);
 }
 public static void Build(){Validate();WebBuild.Build();File.WriteAllText(Path.Combine(Folder,"release-built.txt"),"WebGL mixed core compositions and smooth32-stream wall lights\n"+DateTime.UtcNow.ToString("o"));Debug.Log("WEB_CORE_LIGHT_RELEASE_SUCCESS");}
 // The complete unchanged campaign/render/input suite passed in build.log.
 // This final rebuild validates only the newly corrected progress watchdog.
 public static void BuildFinal(){
  Directory.CreateDirectory(Folder);var report=NativeLevelPreparationWatchdogValidation.Run();
  File.WriteAllText(Path.Combine(Folder,"watchdog-validation.json"),JsonUtility.ToJson(report,true));
  if(!report.passed)throw new InvalidOperationException("Level preparation watchdog failed: "+string.Join("; ",report.issues));
  WebBuild.BuildArtifacts();File.WriteAllText(Path.Combine(Folder,"release-built.txt"),"WebGL mixed core compositions, smooth32-stream wall lights and progress-aware preparation timeout\n"+DateTime.UtcNow.ToString("o"));Debug.Log("WEB_CORE_LIGHT_FINAL_RELEASE_SUCCESS");
 }
}

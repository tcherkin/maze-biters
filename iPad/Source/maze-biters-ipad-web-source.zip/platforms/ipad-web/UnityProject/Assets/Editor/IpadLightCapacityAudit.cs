using System;
using System.Linq;
using System.Reflection;
using UnityEngine;
using UnityEngine.Rendering;
using MazeBiters.NativeStudy;
public static class IpadLightCapacityAudit {
 public static int Run(){
  int checks=0;void Check(bool ok,string label){checks++;if(!ok)throw new Exception("Growing light records: "+label);}
  var type=typeof(NativeLightField).GetNestedType("Batch",BindingFlags.NonPublic);
  var atlas=new Texture2D(512,128,TextureFormat.RGBA32,false);atlas.SetPixels32(Enumerable.Repeat(new Color32(80,120,160,255),512*128).ToArray());atlas.Apply();
  try{foreach(bool walls in new[]{false,true}){
   var batch=(IDisposable)Activator.CreateInstance(type,new object[]{atlas,walls});var command=new CommandBuffer();
   object Field(string name)=>type.GetField(name,BindingFlags.Instance|BindingFlags.Public|BindingFlags.NonPublic).GetValue(batch);
   void Call(string name,params object[] args)=>type.GetMethod(name,BindingFlags.Instance|BindingFlags.Public|BindingFlags.NonPublic).Invoke(batch,args);
   void Add(int i)=>Call("Add",40f+i*.01f,60f,8f,.1f,0,new Vector4(-100,-100,800,800),0);
   Color32[] Pixels(){Call("Draw",command);Graphics.ExecuteCommandBuffer(command);command.Clear();var old=RenderTexture.active;var rt=(RenderTexture)Field("target");RenderTexture.active=rt;var image=new Texture2D(rt.width,rt.height,TextureFormat.RGBA32,false);try{image.ReadPixels(new Rect(0,0,rt.width,rt.height),0,0);return image.GetPixels32();}finally{RenderTexture.active=old;UnityEngine.Object.DestroyImmediate(image);}}
   try{
    Call("Begin");for(int i=0;i<12;i++)Add(i);
    var original=((Color[])Field("records")).Take(12*40).ToArray();
    bool gpu=SystemInfo.graphicsDeviceType!=GraphicsDeviceType.Null;var before=gpu?Pixels():null;
    for(int i=12;i<2100;i++)Add(i);
    var records=(Color[])Field("records");Check(records.Length>=2100*40,"all records retained beyond 1024 and 2048");
    Check(original.SequenceEqual(records.Take(original.Length)),"existing records survive growth exactly");
    foreach(int i in new[]{0,11,1023,1024,2047,2048,2099})Check(Math.Abs(records[i*40].r-(40f+i*.01f))<.00001f&&records[i*40].g==60f&&Math.Abs(records[i*40].a-.1f)<.000001f,"ordered record "+i);
    Check((int)Field("count")==2100,"no light samples dropped");
    if(gpu)Pixels();
    Call("Begin");for(int i=0;i<12;i++)Add(i);
    Check(ReferenceEquals(records,Field("records")),"capacity reused on subsequent frames");
    if(gpu)Check(before.SequenceEqual(Pixels()),"pixel-identical light field after growth");
   }finally{command.Dispose();batch.Dispose();}
  }}finally{UnityEngine.Object.DestroyImmediate(atlas);}
  Debug.Log("IPAD_LIGHT_CAPACITY checks="+checks+" passed=true gpu="+(SystemInfo.graphicsDeviceType!=GraphicsDeviceType.Null));return checks;
 }
}

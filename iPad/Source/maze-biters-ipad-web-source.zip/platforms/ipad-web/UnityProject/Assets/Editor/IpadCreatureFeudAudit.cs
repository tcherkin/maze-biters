using System;
using System.IO;
using System.Linq;
using UnityEditor;
using UnityEngine;
using MazeBiters.NativeStudy;
public static class IpadCreatureFeudAudit {
 [MenuItem("Maze Biters/iPad/Validate creature feuds")]
 public static void Run(){
  string directory=Path.GetFullPath(Path.Combine(Application.dataPath,"../../Results/creature-feuds"));Directory.CreateDirectory(directory);
  var report=NativeCreatureFeudValidation.Run();string path=Path.Combine(directory,"validation-report.json");File.WriteAllText(path,JsonUtility.ToJson(report,true));
  Debug.Log("IPAD_CREATURE_FEUD_CHECKS "+report.assertions+" decisions="+report.decisions+" failures="+report.failures+" elapsedMs="+report.elapsedMs.ToString("F1"));
  foreach(var c in report.checks.Where(c=>!c.passed))Debug.LogError("IPAD_CREATURE_FEUD_FAILURE "+c.name+": "+c.detail);
  if(!report.passed)throw new InvalidOperationException("Creature feud validation failed "+report.failures+" checks. See "+path);
 }
}

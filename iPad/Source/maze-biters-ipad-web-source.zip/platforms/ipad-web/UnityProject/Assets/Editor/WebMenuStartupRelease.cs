using System;
using System.IO;
using System.Security.Cryptography;
using UnityEditor;
using UnityEngine;

// The standalone bootstrap/payload suites execute these exact source bytes.
// This build gate verifies that provenance and the Web-only build policy;
// it does not present those suites as an Editor or device performance test.
public static class WebMenuStartupRelease {
 [Serializable] public sealed class Source {public string file,sha256;public bool exact;}
 [Serializable] public sealed class Report {public bool passed,buildDefaultBackground;public string buildGuid;public Source[] sources;public string scope="Source provenance gate and successful WebGL artifact build. Actual bootstrap control-flow and full46-pack extraction regressions are recorded separately in Results/menu-startup. No physical-device performance claim.";}
 static readonly string[] Files={"Scripts/WebBootstrap.cs","Scripts/WebPayload.cs","Scripts/WebStartupDiagnostics.cs"};
 static readonly string[] Hashes={"e634d9da7138c00b89e85106c55c180e6f19969a0b7b469e37cfdd9135b5c39d","a8721fc2d86f1d1e1ed3dce86b609d1a7849bfc74424caa272ccbd73bd16025f","d962cc6748c1a628bff23d1d020f921fe411ef00595e8520b2534786bdbd14f4"};
 static string Digest(string file){using(var sha=SHA256.Create())return BitConverter.ToString(sha.ComputeHash(File.ReadAllBytes(file))).Replace("-","").ToLowerInvariant();}
 public static void Build(){
  var r=new Report{sources=new Source[Files.Length]};
  for(int i=0;i<Files.Length;i++){
   var row=r.sources[i]=new Source{file=Files[i],sha256=Digest(Path.Combine(Application.dataPath,Files[i]))};row.exact=row.sha256==Hashes[i];
   if(!row.exact)throw new InvalidOperationException("Startup source changed after validation: "+row.file);
  }
  WebBuild.BuildArtifacts();r.buildDefaultBackground=PlayerSettings.runInBackground;
  if(!r.buildDefaultBackground)throw new InvalidOperationException("Web startup background policy was not saved");
  string folder=Path.GetFullPath(Path.Combine(Application.dataPath,"../../Results/menu-startup"));Directory.CreateDirectory(folder);
  string info=Path.GetFullPath(Path.Combine(Application.dataPath,"../../Builds/iPad/build-info.json"));
  r.buildGuid=JsonUtility.FromJson<BuildIdentity>(File.ReadAllText(info)).buildGuid;r.passed=true;
  File.WriteAllText(Path.Combine(folder,"build-validation.json"),JsonUtility.ToJson(r,true));
  Debug.Log("WEB_MENU_STARTUP_RELEASE_SUCCESS "+r.buildGuid);
 }
 [Serializable] sealed class BuildIdentity {public string buildGuid;}
}

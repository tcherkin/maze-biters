using System;
using System.IO;
using System.Linq;
using UnityEditor;
using UnityEngine;
using MazeBiters.NativeStudy;

public static class IpadCasualBiteAudit {
 [MenuItem("Maze Biters/iPad/Validate casual incidental bites")]
 public static void Run(){
  string directory=Path.GetFullPath(Path.Combine(Application.dataPath,"../../Results/casual-bites"));Directory.CreateDirectory(directory);
  var report=NativeCasualBiteValidation.Run();string path=Path.Combine(directory,"casual-bite-report.json");File.WriteAllText(path,JsonUtility.ToJson(report,true));
  Debug.Log("IPAD_CASUAL_BITE_CHECKS "+report.assertions+" decisions="+report.decisions+" failures="+report.failures+" elapsedMs="+report.elapsedMs.ToString("F1"));
  foreach(var check in report.checks.Where(c=>!c.passed))Debug.LogError("IPAD_CASUAL_BITE_FAILURE "+check.name+": "+check.detail);
  if(!report.passed)throw new InvalidOperationException("Casual bite validation failed "+report.failures+" checks. See "+path);
 }
}

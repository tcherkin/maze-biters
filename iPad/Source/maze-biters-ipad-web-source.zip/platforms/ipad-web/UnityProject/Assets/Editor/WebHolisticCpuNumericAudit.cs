using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Security.Cryptography;
using System.Text;
using MazeBiters.NativeStudy;
using UnityEditor;
using UnityEngine;
using Debug=UnityEngine.Debug;
public static class WebHolisticCpuNumericAudit {
 [Serializable] public sealed class Report {
  public bool passed;public int checks,failures,fieldArrays,hudStates,aiTraces;
  public bool allocationCounterAvailable;public long allocationCalibrationBytes;public string allocationCounterNote;
  public long referenceHitBytes,optimizedHitBytes,referenceQueueBytes,optimizedQueueBytes,referenceHudVisibilityWrites,optimizedHudVisibilityWrites,referenceHudToggles,optimizedHudToggles,referenceHudFontWrites,optimizedHudFontWrites,referenceHudEffectWrites,optimizedHudEffectWrites;
  public double referenceHitMs,optimizedHitMs,referenceQueueMs,optimizedQueueMs,elapsedMs;
  public string scope="Native iPad CPU exact-work checks. Field arrays are compared against the original string-epoch/Queue path across all four A/B combinations, roster/egg/grid invalidations and targets. Fixed-step AI traces compare observable world state, events and RNG. Actual HUD meshes/materials/visibility are compared with the reference across HD/4K, all modes, contact fades, score/life sweeps and combos. Editor timing is diagnostic; HD/4K player captures/performance are separate.";
  public List<string> issues=new List<string>();public List<string> traceHashes=new List<string>();
 }
 static byte[] calibrationAllocation;
 static long Allocated(Report r)=>r.allocationCounterAvailable?GC.GetAllocatedBytesForCurrentThread():0;
 static void Calibrate(Report r){
  try{long before=GC.GetAllocatedBytesForCurrentThread();calibrationAllocation=new byte[65536];r.allocationCalibrationBytes=GC.GetAllocatedBytesForCurrentThread()-before;r.allocationCounterAvailable=r.allocationCalibrationBytes>=65536;GC.KeepAlive(calibrationAllocation);}
  catch(NotSupportedException){r.allocationCounterAvailable=false;}
  r.allocationCounterNote=r.allocationCounterAvailable?"Counter calibrated with a retained65536-byte allocation outside measurement windows; byte assertions enabled.":"Allocation counter unavailable or uncalibrated on this runtime. Zero-valued byte fields are unavailable readings, not proof of zero allocation. Cache/build counters, exact output traces and diagnostic timing remain checked.";
 }
 sealed class Tape {public uint state;public int draws;public Tape(uint seed){state=seed;}public double Next(){draws++;unchecked{state+=0x6D2B79F5;uint v=(state^(state>>15))*(state|1);v^=v+(v^(v>>7))*(v|61);return (v^(v>>14))/4294967296.0;}}}
 static void Check(Report r,bool ok,string name){r.checks++;if(ok)return;r.failures++;if(r.issues.Count<100)r.issues.Add(name);}
 static NativeGameplayWorld Bare(int mode=4){var level=NativeCampaignComposition.Generate(34,1,1);var w=new NativeGameplayWorld(level.geometry,NativeMazeGenerator.Rng(63));w.SetMode(mode);for(int i=0;i<w.PlayerCount;i++)w.GetPlayer(i).Cell=new Vector2Int(level.starts[i].x,level.starts[i].y);return w;}
 static Vector2Int[] Targets(NativeGameplayWorld w)=>new[]{new Vector2Int(-3,-4),new Vector2Int(1,1),new Vector2Int(2,2),new Vector2Int(w.Width-2,w.Height-2),new Vector2Int(w.Width+4,w.Height+3)};
 static void Fields(Report r){
  var world=Bare();var target=new Vector2Int(1,1);
  void Case(string name){
   foreach(var t in Targets(world)){
    NativeHolisticTuning.FieldEpoch=false;NativeHolisticTuning.FieldQueue=false;var expected=(int[])world.Brain.Field(t).Clone();
    foreach(bool epoch in new[]{false,true})foreach(bool queue in new[]{false,true}){NativeHolisticTuning.FieldEpoch=epoch;NativeHolisticTuning.FieldQueue=queue;world.ObstacleRevision++;var actual=world.Brain.Field(t);r.fieldArrays++;Check(r,actual.SequenceEqual(expected),"complete field array "+name+" epoch="+epoch+" queue="+queue+" target="+t);}
   }
  }
  Case("initial three-player roster");world.GetPlayer(0).Cell=new Vector2Int(3,1);Case("primary move");world.GetPlayer(1).Cell=new Vector2Int(1,3);Case("secondary move");world.GetPlayer(2).Cell=new Vector2Int(3,3);Case("third move");
  for(int i=0;i<3;i++){world.GetPlayer(i).Dead=true;Case("death "+i);world.GetPlayer(i).Dead=false;Case("revive "+i);}
  world.SolidEggs.Add(target);world.ObstacleRevision++;Case("solid egg at occupied goal");world.GetPlayer(0).Cell=target;Case("player occupying egg goal");world.GetPlayer(0).Cell=new Vector2Int(3,1);Case("egg goal unoccupied again");world.SolidEggs.Clear();world.ObstacleRevision++;Case("egg removed");
  world.Grid=(string[])world.Grid.Clone();Case("new grid identity");var rows=world.Grid.Select(s=>s.ToCharArray()).ToArray();rows[1][3]='#';world.Grid=rows.Select(s=>new string(s)).ToArray();world.ObstacleRevision++;Case("changed grid contents");
  foreach(int mode in new[]{1,0,2,3,5,4}){world.SetMode(mode);Case("mode "+mode);}
  EpochSequence(r);
  // A zero-allocation warmed hit specifically exercises the former hot string
  // construction; no report formatting or snapshots occur in these windows.
  var reference=Bare();NativeHolisticTuning.FieldEpoch=false;NativeHolisticTuning.FieldQueue=true;for(int i=0;i<100;i++)reference.Brain.Field(target);
  var timer=new Stopwatch();timer.Start();long start=Allocated(r);for(int i=0;i<10000;i++)reference.Brain.Field(target);r.referenceHitBytes=Allocated(r)-start;timer.Stop();r.referenceHitMs=timer.Elapsed.TotalMilliseconds;
  var optimized=Bare();NativeHolisticTuning.FieldEpoch=true;NativeHolisticTuning.FieldQueue=true;for(int i=0;i<100;i++)optimized.Brain.Field(target);
  timer.Restart();start=Allocated(r);for(int i=0;i<10000;i++)optimized.Brain.Field(target);r.optimizedHitBytes=Allocated(r)-start;timer.Stop();r.optimizedHitMs=timer.Elapsed.TotalMilliseconds;
  Check(r,reference.Brain.FieldBuilds==1&&optimized.Brain.FieldBuilds==1&&reference.Brain.FieldCacheHits==10099&&optimized.Brain.FieldCacheHits==10099,"both warmed hit windows reuse exactly one built field");
  if(r.allocationCounterAvailable)Check(r,r.referenceHitBytes>0&&r.optimizedHitBytes==0,"ten thousand warmed typed-epoch hits allocate zero calibrated bytes");
  var queueReference=Bare();NativeHolisticTuning.FieldQueue=false;queueReference.Brain.Field(target);timer.Restart();start=Allocated(r);for(int i=0;i<500;i++){queueReference.ObstacleRevision++;queueReference.Brain.Field(target);}r.referenceQueueBytes=Allocated(r)-start;timer.Stop();r.referenceQueueMs=timer.Elapsed.TotalMilliseconds;
  var queueOptimized=Bare();NativeHolisticTuning.FieldQueue=true;queueOptimized.Brain.Field(target);timer.Restart();start=Allocated(r);for(int i=0;i<500;i++){queueOptimized.ObstacleRevision++;queueOptimized.Brain.Field(target);}r.optimizedQueueBytes=Allocated(r)-start;timer.Stop();r.optimizedQueueMs=timer.Elapsed.TotalMilliseconds;
  Check(r,queueReference.Brain.FieldBuilds==501&&queueOptimized.Brain.FieldBuilds==501,"both BFS queue windows perform exactly501 independently owned field builds");
  if(r.allocationCounterAvailable)Check(r,r.optimizedQueueBytes<r.referenceQueueBytes,"retained BFS queue reduces calibrated miss allocation while result arrays stay independently owned");
 }
 static void EpochSequence(Report r){
  var a=Bare();var b=Bare();
  void Compare(string name){foreach(var target in Targets(a)){NativeHolisticTuning.FieldEpoch=NativeHolisticTuning.FieldQueue=false;var expected=a.Brain.Field(target);NativeHolisticTuning.FieldEpoch=NativeHolisticTuning.FieldQueue=true;var actual=b.Brain.Field(target);Check(r,actual.SequenceEqual(expected),"persistent cache outputs "+name);r.fieldArrays++;}Check(r,a.Brain.FieldEpochResets==b.Brain.FieldEpochResets,"persistent epoch invalidation count "+name);}
  void Change(Action<NativeGameplayWorld> mutate,string name){mutate(a);mutate(b);Compare(name);}
  Compare("initial");Change(w=>w.GetPlayer(0).Cell=new Vector2Int(3,1),"primary move");Change(w=>w.GetPlayer(1).Dead=true,"secondary death");Change(w=>w.GetPlayer(1).Dead=false,"secondary revive");Change(w=>w.GetPlayer(2).Cell=new Vector2Int(3,3),"third move");
  Change(w=>{w.SolidEggs.Add(new Vector2Int(1,1));w.ObstacleRevision++;},"egg becomes solid");Change(w=>w.GetPlayer(0).Cell=new Vector2Int(1,1),"egg occupied goal");Change(w=>w.GetPlayer(0).Dead=true,"egg occupant dies");Change(w=>{w.SolidEggs.Clear();w.ObstacleRevision++;},"egg removed");Change(w=>w.Grid=(string[])w.Grid.Clone(),"grid identity");
  foreach(int mode in new[]{1,0,2,3,5,4})Change(w=>w.SetMode(mode),"mode "+mode);
 }
 static string Hash(string value){using(var sha=SHA256.Create())return BitConverter.ToString(sha.ComputeHash(Encoding.UTF8.GetBytes(value))).Replace("-","").ToLowerInvariant();}
 static string Trace(int mode,int tier,int level,bool optimized){
  NativeHolisticTuning.FieldEpoch=NativeHolisticTuning.FieldQueue=optimized;var tape=new Tape(991);var first=NativeCampaignComposition.Generate(811,1,NativeMazeGenerator.Difficulties[tier]);
  var w=new NativeGameplayWorld(first.geometry,tape.Next){Difficulty=NativeMazeGenerator.Difficulties[tier],AiDifficulty=tier};w.SetMode(mode);w.StartSession(n=>NativeCampaignComposition.Generate(811,n,NativeMazeGenerator.Difficulties[tier]));if(level>1){w.Level=level-1;w.AdvanceLevel();}
  var b=new StringBuilder();w.Event=e=>b.Append(e.Kind).Append(':').Append(e.Sound).Append(':').Append(e.Player?.Id??0).Append(':').Append(e.Cell).Append(';');
  for(int frame=0;frame<800;frame++){
   double time=1000+frame*25;w.RealTime=time;
   if(frame%12==0)for(int i=0;i<w.PlayerCount;i++){var p=w.GetPlayer(i);if(p.IsAI)continue;using(w.ForPlayer(p)){w.ClearKeys();w.Press("audit",NativeGameplayWorld.Dirs[frame/12%4]);}}
   w.Tick(time);b.Append(frame).Append('|').Append(w.Level).Append('|').Append(tape.state).Append('|').Append(tape.draws).Append('|');
   for(int i=0;i<w.PlayerCount;i++){var p=w.GetPlayer(i);b.Append(p.Id).Append(':').Append(p.Cell).Append(':').Append(p.Dir).Append(':').Append(p.Next).Append(':').Append(p.Score).Append(':').Append(p.Lives).Append(':').Append(p.Dead).Append(':').Append(p.Ai?.thought).Append(':').Append(p.PowerUntil.ToString("R",CultureInfo.InvariantCulture)).Append(';');}
   foreach(var s in w.Snakes){b.Append(s.Id).Append(':').Append(s.Dir).Append(':').Append(s.Palette).Append(':').Append(s.Anger.ToString("R",CultureInfo.InvariantCulture)).Append(':');foreach(var c in s.Body)b.Append(c).Append('/');b.Append(';');}
   foreach(var h in w.Hunters)b.Append('H').Append(h.Id).Append(':').Append(h.Cell).Append(':').Append(h.Dir).Append(';');
   foreach(var f in w.Fruits)b.Append('F').Append(f.Cell).Append(':').Append(f.Kind).Append(';');foreach(var e in w.Eggs)b.Append('E').Append(e.Cell).Append(':').Append(e.Born.ToString("R",CultureInfo.InvariantCulture)).Append(';');
  }return Hash(b.ToString());
 }
 static void Traces(Report r){foreach(var item in new[]{(mode:0,tier:4,level:25),(mode:3,tier:0,level:1),(mode:4,tier:2,level:25)}){var a=Trace(item.mode,item.tier,item.level,false);var b=Trace(item.mode,item.tier,item.level,true);r.aiTraces++;r.traceHashes.Add(a);Check(r,a==b,"AI events/state/RNG trace mode="+item.mode+" tier="+item.tier+" level="+item.level);}}
 static Mesh Quad(){var q=new Mesh();q.vertices=new[]{new Vector3(0,0),new Vector3(1,0),new Vector3(1,-1),new Vector3(0,-1)};q.uv=new[]{new Vector2(0,1),new Vector2(1,1),new Vector2(1,0),new Vector2(0,0)};q.triangles=new[]{0,1,2,0,2,3};return q;}
 static void Hud(Report r){
  var quad=Quad();var aRoot=new GameObject("Reference HUD audit");var bRoot=new GameObject("Retained HUD audit");var a=new NativeHud(quad,aRoot.transform);var b=new NativeHud(quad,bRoot.transform);
  try{a.BeginLevel(1000,true);b.BeginLevel(1000,true);var frame=new NativeFrame(4f/3,true);
   var bite=typeof(NativeComboState).GetMethod("Bite",BindingFlags.NonPublic|BindingFlags.Instance);var pause=typeof(NativeComboState).GetMethod("PauseFeeding",BindingFlags.NonPublic|BindingFlags.Instance);
   foreach(string quality in new[]{"hd","4k"})foreach(int mode in new[]{1,2,3,4,5,0,1}){
    var w=Bare(mode);for(int i=0;i<w.PlayerCount;i++){var p=w.GetPlayer(i);p.Score=900-i*200;p.Lives=3;p.ScoreSpotlight=1200;p.LifeSpotlight=1400;}
    foreach(double t in new[]{1000.0,1250,1500,2000,2500,3000,4000}){
     for(int i=0;i<w.PlayerCount;i++){var p=w.GetPlayer(i);if(t==1250){bite.Invoke(p.Combo,new object[]{100+i*10,t});bite.Invoke(p.Combo,new object[]{101+i*10,t});}if(t==2000)bite.Invoke(p.Combo,new object[]{102+i*10,t});if(t==2500)pause.Invoke(p.Combo,new object[]{t});p.Combo.Advance(t);p.Dead=t==3000;}
     w.Time=t;NativeHolisticTuning.Hud=false;a.Render(w,t,quality);a.HolisticContacts(frame,t,t<2500);
     NativeHolisticTuning.Hud=true;b.Render(w,t,quality);b.HolisticContacts(frame,t,t<2500);
     r.hudStates++;Check(r,a.HolisticState()==b.HolisticState(),"actual HUD meshes/materials/visibility mode="+mode+" quality="+quality+" time="+t);
    }
   }
   // Stationary DUO frames expose unnecessary hide/re-enable calls without
   // changing their final visible state or animation sampling.
   var duo=Bare(2);duo.GetPlayer(0).Score=100;duo.GetPlayer(1).Score=10;
   long av=a.StateVisibilityWrites,bv=b.StateVisibilityWrites,at=a.StateVisibilityToggles,bt=b.StateVisibilityToggles,af=a.StateFontWrites,bf=b.StateFontWrites,ae=a.StateEffectWrites,be=b.StateEffectWrites;
   for(int i=0;i<200;i++){NativeHolisticTuning.Hud=false;a.Render(duo,5000+i*8,"4k");NativeHolisticTuning.Hud=true;b.Render(duo,5000+i*8,"4k");}
   Check(r,a.HolisticState()==b.HolisticState(),"stationary DUO final renderer state exact");r.referenceHudVisibilityWrites=a.StateVisibilityWrites-av;r.optimizedHudVisibilityWrites=b.StateVisibilityWrites-bv;r.referenceHudToggles=a.StateVisibilityToggles-at;r.optimizedHudToggles=b.StateVisibilityToggles-bt;r.referenceHudFontWrites=a.StateFontWrites-af;r.optimizedHudFontWrites=b.StateFontWrites-bf;r.referenceHudEffectWrites=a.StateEffectWrites-ae;r.optimizedHudEffectWrites=b.StateEffectWrites-be;
   Check(r,r.optimizedHudVisibilityWrites<r.referenceHudVisibilityWrites&&r.optimizedHudToggles<r.referenceHudToggles,"retained DUO rows remove repeated visibility toggles");Check(r,r.optimizedHudFontWrites<r.referenceHudFontWrites,"unchanged fonts avoid repeated material bindings");Check(r,r.optimizedHudEffectWrites<r.referenceHudEffectWrites,"DUO effects are submitted once at their final values");
  }finally{a.HolisticDispose();b.HolisticDispose();UnityEngine.Object.DestroyImmediate(aRoot);UnityEngine.Object.DestroyImmediate(bRoot);UnityEngine.Object.DestroyImmediate(quad);}
 }
 [MenuItem("Maze Biters/Web/Validate native CPU exact-work reuse")]
 public static void Run(){
  var r=new Report();var watch=Stopwatch.StartNew();bool epoch=NativeHolisticTuning.FieldEpoch,queue=NativeHolisticTuning.FieldQueue,hud=NativeHolisticTuning.Hud,title=NativeHolisticTuning.Title;
  try{Calibrate(r);Fields(r);Traces(r);Hud(r);}finally{calibrationAllocation=null;NativeHolisticTuning.FieldEpoch=epoch;NativeHolisticTuning.FieldQueue=queue;NativeHolisticTuning.Hud=hud;NativeHolisticTuning.Title=title;watch.Stop();r.elapsedMs=watch.Elapsed.TotalMilliseconds;r.passed=r.failures==0;string directory=Path.GetFullPath(Path.Combine(Application.dataPath,"../../Results/holistic-optimization"));Directory.CreateDirectory(directory);File.WriteAllText(Path.Combine(directory,"cpu-validation.json"),JsonUtility.ToJson(r,true));}
  Debug.Log("WEB_HOLISTIC_CPU passed="+r.passed+" checks="+r.checks+" fields="+r.fieldArrays+" hud="+r.hudStates+" traces="+r.aiTraces+" hitBytes="+r.referenceHitBytes+"→"+r.optimizedHitBytes);
  foreach(string issue in r.issues)Debug.LogError("WEB_HOLISTIC_CPU_FAILURE "+issue);if(!r.passed)throw new InvalidOperationException("Native CPU exact-work checks failed");
 }
}

using System;
using System.IO;
using UnityEngine;
using MazeBiters.NativeStudy;
public static class IpadComboTailAudit {
 public static void Validate(){
  string directory=Path.GetFullPath(Path.Combine(Application.dataPath,"../../Results/combo-tail"));Directory.CreateDirectory(directory);
  var report=NativeComboValidation.Run();File.WriteAllText(Path.Combine(directory,"validation.json"),JsonUtility.ToJson(report,true));
  foreach(var check in report.checks)if(!check.passed)Debug.LogError("COMBO_TAIL_FAILURE "+check.name+" "+check.detail);
  Debug.Log("COMBO_TAIL_CHECKS "+report.assertions+" failures="+report.failures);
  if(!report.passed)throw new Exception("Combo tail validation failed");
  Debug.Log("COMBO_TAIL_HUD_CHECKS "+NativeHudComboValidation.Numeric());
  IpadAllyOpportunityAudit.Run();
 }
 public static void Build(){Validate();StudyBuild.Build();}
}

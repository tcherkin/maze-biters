using System;
using System.IO;
using UnityEngine;
using MazeBiters.NativeStudy;

public static class WebPreparationValidation {
 public static void Run(){
  var results=new[]{NativeMazeArtwork.ValidateWebPainter("hd"),NativeMazeArtwork.ValidateWebPainter("4k")};
  string destination=Path.GetFullPath(Path.Combine(Application.dataPath,"../../Results"));Directory.CreateDirectory(destination);
  File.WriteAllLines(Path.Combine(destination,"cooperative-painter.txt"),results);
  foreach(string result in results)Debug.Log("WEB_PAINTER_PARITY "+result);
 }
}

using System;
using System.IO;
using UnityEditor;
using UnityEngine;
using MazeBiters.NativeStudy;
public static class IpadComboMultiplierAudit {
 [MenuItem("Maze Biters/iPad/Validate combo score multipliers")]
 public static void Run(){
  string directory=Path.GetFullPath(Path.Combine(Application.dataPath,"../../Results/combo-multiplier"));Directory.CreateDirectory(directory);
  var report=NativeComboValidation.Run();string path=Path.Combine(directory,"combo-validation.json");File.WriteAllText(path,JsonUtility.ToJson(report,true));
  Debug.Log("IPAD_COMBO_MULTIPLIER checks="+report.assertions+" movementSteps="+report.movementSteps+" failures="+report.failures+" elapsedMs="+report.elapsedMs.ToString("F1"));
  foreach(var check in report.checks)if(!check.passed)Debug.LogError("IPAD_COMBO_MULTIPLIER_FAILURE "+check.name+": "+check.detail);
  if(!report.passed)throw new InvalidOperationException("Combo multiplier validation failed "+report.failures+" checks. See "+path);
 }
}

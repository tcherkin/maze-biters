using System;
using System.IO;
using System.Linq;
using UnityEditor;
using UnityEngine;
using MazeBiters.NativeStudy;

public static class IpadCasualFinishAudit {
 [MenuItem("Maze Biters/iPad/Validate continuous casual meals")]
 public static void Run(){
  string directory=Path.GetFullPath(Path.Combine(Application.dataPath,"../../Results/finish-head"));Directory.CreateDirectory(directory);
  var report=NativeCasualFinishValidation.Run();string path=Path.Combine(directory,"finish-head-report.json");File.WriteAllText(path,JsonUtility.ToJson(report,true));
  Debug.Log("IPAD_CASUAL_FINISH_CHECKS "+report.assertions+" decisions="+report.decisions+" failures="+report.failures+" elapsedMs="+report.elapsedMs.ToString("F1"));
  foreach(var check in report.checks.Where(c=>!c.passed))Debug.LogError("IPAD_CASUAL_FINISH_FAILURE "+check.name+": "+check.detail);
  if(!report.passed)throw new InvalidOperationException("Continuous casual meal validation failed "+report.failures+" checks. See "+path);
 }
}

using System;
using System.IO;
using System.Collections.Generic;
using UnityEngine;
using MazeBiters.NativeStudy;

public static class IpadDuoSwipeAudit {
 [Serializable] public sealed class Entry {public string name,detail;public bool passed;}
 [Serializable] public sealed class Report {public bool passed;public int checks,failures;public string revision="20261108-duo-swipe";public List<Entry> results=new List<Entry>();}
 struct Finger {public int id;public Vector2 at;public TouchPhase phase;public Finger(int id,Vector2 at,TouchPhase phase){this.id=id;this.at=at;this.phase=phase;}}
 static Report report;
 static readonly Vector2Int[] Dirs={new Vector2Int(1,0),new Vector2Int(1,1),new Vector2Int(0,1),new Vector2Int(-1,1),new Vector2Int(-1,0),new Vector2Int(-1,-1),new Vector2Int(0,-1),new Vector2Int(1,-1)};
 static readonly int[] Masks={2,10,8,9,1,5,4,6};
 static readonly Vector2 Left=new Vector2(330,500),Right=new Vector2(1046,500);
 static Finger F(int id,Vector2 at,TouchPhase phase=TouchPhase.Moved)=>new Finger(id,at,phase);
 static void Check(bool ok,string name){report.checks++;if(!ok){report.failures++;Debug.LogError("DUO_SWIPE_FAILURE "+name);}report.results.Add(new Entry{name=name,passed=ok});}
 static int Mask(NativePlayer p){int bits=0;foreach(var k in p.Keys.Values){if(k.dir.x<0)bits|=1;if(k.dir.x>0)bits|=2;if(k.dir.y<0)bits|=4;if(k.dir.y>0)bits|=8;}return bits;}
 static NativeGameplayWorld World(int mode=5){var grid=new string[17];for(int y=0;y<grid.Length;y++)grid[y]=y==0||y==16?new string('#',25):"#"+new string('.',23)+"#";var w=new NativeGameplayWorld(grid,()=>.5){Time=1000,Assist=false};w.SetMode(mode);for(int i=0;i<w.PlayerCount;i++){var p=w.GetPlayer(i);p.Cell=p.From=p.Previous=new Vector2Int(5+i*6,5+i*2);p.Dir=p.Next=Vector2Int.right;p.Waiting=true;}return w;}
 static void Frame(IpadSwipeInput input,NativeGameplayWorld w,bool active,int width,int height,params Finger[] fingers){input.BeginFrame(w,width,height,active);foreach(var f in fingers)input.Touch(f.id,f.at,f.phase);input.EndFrame();}
 static void Step(IpadSwipeInput input,NativeGameplayWorld w,params Finger[] fingers)=>Frame(input,w,true,1376,1032,fingers);
 static IpadSwipeInput Capture(NativeGameplayWorld w){var input=new IpadSwipeInput();Step(input,w,F(11,Left,TouchPhase.Began),F(22,Right,TouchPhase.Began));Step(input,w,F(11,Left+new Vector2(100,100)),F(22,Right-new Vector2(100,100)));return input;}
 public static void Run(){
  report=new Report();try{ModesAndDirections();Ownership();Lifecycle();ExternalAndSharedWorld();TrailingOrigin();}catch(Exception e){report.failures++;report.results.Add(new Entry{name="Audit completes",detail=e.ToString(),passed=false});Debug.LogException(e);}
  report.passed=report.failures==0;var root=Path.GetFullPath(Path.Combine(Application.dataPath,"../../Results/duo-swipe"));Directory.CreateDirectory(root);File.WriteAllText(Path.Combine(root,"input-validation.json"),JsonUtility.ToJson(report,true));Debug.Log("DUO_SWIPE_CHECKS "+report.checks+" failures="+report.failures);if(!report.passed)throw new Exception("Two-finger swipe audit failed");
 }
 static void ModesAndDirections(){
  foreach(int scale in new[]{1,2})foreach(int mode in new[]{0,1,2,3,4,5})for(int dir=0;dir<8;dir++){
   var w=World(mode);var input=new IpadSwipeInput();bool duo=mode==2||mode==4||mode==5;int width=1376*scale,height=1032*scale;var left=Left*scale;var right=Right*scale;var delta=new Vector2(Dirs[dir].x,-Dirs[dir].y)*100*scale;
   Frame(input,w,true,width,height,F(11,left,TouchPhase.Began),F(22,right,TouchPhase.Began));
   Frame(input,w,true,width,height,F(22,right-delta),F(11,left+delta));
   Check(input.Duo==duo,"Mode splits only two-human screen "+mode+"/"+scale+"/"+dir);
   Check(Mask(w.GetPlayer(0))==(mode==0?0:Masks[dir]),"P1 eight-direction ownership "+mode+"/"+scale+"/"+dir);
   if(w.PlayerCount>1)Check(Mask(w.GetPlayer(1))==(duo?Masks[(dir+4)%8]:0),"P2 independent opposite direction "+mode+"/"+scale+"/"+dir);
   for(int i=0;i<w.PlayerCount;i++)if(w.GetPlayer(i).IsAI)Check(w.GetPlayer(i).Keys.Count==0,"AI cannot receive touch "+mode+"/"+i+"/"+dir);
   if(duo){for(int slot=0;slot<2;slot++){var p=w.GetPlayer(slot);var start=p.Cell;using(w.ForPlayer(p))for(int n=0;n<((dir&1)==0?1:2);n++)w.AdvancePlayer();Check(p.Cell-start==Dirs[dir]*(slot==0?1:-1),"Both players actually step independently "+mode+"/"+scale+"/"+slot+"/"+dir);}}
   input.CancelAll();for(int i=0;i<w.PlayerCount;i++)Check(w.GetPlayer(i).Keys.Count==0,"Cancel releases both owners "+mode+"/"+i+"/"+dir);
  }
  foreach(int mode in new[]{1,3}){var w=World(mode);var input=new IpadSwipeInput();Step(input,w,F(41,Right,TouchPhase.Began));Step(input,w,F(41,Right+new Vector2(100,100)));Check(input.Pads[0].FingerId==41&&Mask(w.Player)==6&&!input.Pads[1].Held,"Solo human can swipe on right half "+mode);}
 }
 static void Ownership(){
  var w=World();var input=Capture(w);
  Check(Mask(w.GetPlayer(0))==6&&Mask(w.GetPlayer(1))==9,"Two initial diagonals coexist");
  var a=new Vector2(1120,500);var b=new Vector2(256,500);Step(input,w,F(22,b),F(33,Left,TouchPhase.Began),F(11,a));
  Check(input.Pads[0].FingerId==11&&input.Pads[1].FingerId==22&&Mask(w.GetPlayer(0))==2&&Mask(w.GetPlayer(1))==1,"Crossing middle and reversed event order retain both owners; extra finger ignored");
  a+=Vector2.up*150;Step(input,w,F(11,a),F(22,b,TouchPhase.Stationary));Check(Mask(w.GetPlayer(0))==4&&Mask(w.GetPlayer(1))==1,"One turns while other keeps its direction");
  Step(input,w,F(11,a,TouchPhase.Ended),F(22,b,TouchPhase.Stationary));Check(!input.Pads[0].Held&&Mask(w.GetPlayer(0))==0&&input.Pads[1].FingerId==22&&Mask(w.GetPlayer(1))==1,"Lifting P1 leaves P2 active");
  Step(input,w,F(33,Left+Vector2.up*100),F(22,b,TouchPhase.Stationary));Check(!input.Pads[0].Held,"Previously ignored finger cannot acquire ownership on Move");
  Step(input,w,F(44,Left,TouchPhase.Began),F(22,b,TouchPhase.Stationary));Step(input,w,F(44,Left+Vector2.down*120),F(22,b,TouchPhase.Stationary));
  Check(input.Pads[0].FingerId==44&&Mask(w.GetPlayer(0))==8,"Fresh P1 finger starts while P2 remains down");
  Step(input,w,F(44,Left+Vector2.down*120,TouchPhase.Stationary),F(22,b,TouchPhase.Canceled));Check(input.Pads[0].Held&&Mask(w.GetPlayer(0))==8&&!input.Pads[1].Held&&Mask(w.GetPlayer(1))==0,"Cancel P2 does not cancel P1");
  Step(input,w);Check(!input.Pads[0].Held&&Mask(w.GetPlayer(0))==0,"Missing finger event releases remaining owner");
 }
 static void Lifecycle(){
  foreach(string cause in new[]{"inactive","transition","gameover","resize","world","cancel"}){
   var w=World();var input=Capture(w);var next=w;int width=1376,height=1032;bool active=true;
   if(cause=="inactive")active=false;if(cause=="transition")w.Transition=true;if(cause=="gameover")w.GameOver=true;if(cause=="resize"){width*=2;height*=2;}if(cause=="world")next=World();if(cause=="cancel")input.CancelAll();
   Frame(input,next,active,width,height,F(11,Left+Vector2.up*100),F(22,Right+Vector2.up*100));
   Check(!input.Pads[0].Held&&!input.Pads[1].Held&&w.GetPlayer(0).Keys.Count==0&&w.GetPlayer(1).Keys.Count==0,"Both touches cleared on "+cause);
   w.Transition=w.GameOver=false;Frame(input,next,true,width,height,F(11,Left),F(22,Right));Check(!input.Pads[0].Held&&!input.Pads[1].Held,"Old held fingers cannot revive after "+cause);
  }
  foreach(int lost in new[]{0,1})foreach(string cause in new[]{"dead","lives","eliminated"}){
   var w=World();var input=Capture(w);var p=w.GetPlayer(lost);if(cause=="dead")p.Dead=true;if(cause=="lives")p.Lives=0;if(cause=="eliminated")p.Eliminated=true;
   Step(input,w,F(11,Left+new Vector2(100,100)),F(22,Right-new Vector2(100,100)));
   Check(!input.Pads[lost].Held&&p.Keys.Count==0&&input.Pads[1-lost].Held&&w.GetPlayer(1-lost).Keys.Count==2,"Only affected player releases on "+cause+"/"+lost);
   p.Dead=p.Eliminated=false;p.Lives=3;Step(input,w,F(11,Left+new Vector2(100,100)),F(22,Right-new Vector2(100,100)));Check(!input.Pads[lost].Held,"Respawn requires fresh finger "+cause+"/"+lost);
  }
 }
 static void ExternalAndSharedWorld(){
  var w=World();using(w.ForPlayer(w.GetPlayer(0)))w.Press("W",new Vector2Int(0,-1));using(w.ForPlayer(w.GetPlayer(1)))w.Press("GamepadSlot1:right",Vector2Int.right);
  var input=Capture(w);var inactive=new IpadSwipeInput();Frame(inactive,w,false,1376,1032);inactive.CancelAll();Check(w.GetPlayer(0).Keys.Count==3&&w.GetPlayer(1).Keys.Count==3,"Inactive cached scene cannot clear active owners");
  input.CancelAll();Check(w.GetPlayer(0).Keys.Count==1&&w.GetPlayer(0).Keys.ContainsKey("W")&&w.GetPlayer(1).Keys.Count==1&&w.GetPlayer(1).Keys.ContainsKey("GamepadSlot1:right"),"Releasing touch preserves each external input source");
 }
 static void TrailingOrigin(){
  var w=World();var input=new IpadSwipeInput();Step(input,w,F(11,Left,TouchPhase.Began),F(22,Right,TouchPhase.Began));Step(input,w,F(11,Left+Vector2.right*2),F(22,Right+Vector2.up*2));Check(w.GetPlayer(0).Keys.Count==0&&w.GetPlayer(1).Keys.Count==0,"Independent dead zones ignore tap jitter");
  var a=Left+Vector2.right*600;var b=Right+Vector2.down*300;Step(input,w,F(11,a),F(22,b));Check(Mathf.Abs(Vector2.Distance(input.Pads[0].Origin,a)-1032*.012f*3)<.01f,"Original trailing anchor follows long drag");
  a-=Vector2.right*120;Step(input,w,F(11,a),F(22,b,TouchPhase.Stationary));Check(Mask(w.GetPlayer(0))==1&&Mask(w.GetPlayer(1))==8,"Long-drag reversal works without returning to touch-down point");
  int first=w.GetPlayer(0).KeySerial,second=w.GetPlayer(1).KeySerial;for(int i=0;i<20;i++)Step(input,w,F(22,b,TouchPhase.Stationary),F(11,a,TouchPhase.Stationary));Check(w.GetPlayer(0).KeySerial==first&&w.GetPlayer(1).KeySerial==second,"Stationary fingers do not reissue held keys");
 }
}

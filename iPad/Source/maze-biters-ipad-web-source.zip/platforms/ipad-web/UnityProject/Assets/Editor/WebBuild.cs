using System;
using System.IO;
using System.Security.Cryptography;
using System.Text.RegularExpressions;
using UnityEditor;
using UnityEditor.Build;
using UnityEditor.Build.Reporting;
using UnityEngine;
using UnityEngine.Rendering;
public static class WebBuild {
 public static void Build(){
  Debug.Log("WEB_CLEAR_CELEBRATION checks="+MazeBiters.NativeStudy.IpadClearCelebrationValidation.Run());
  var exitCamera=MazeBiters.NativeStudy.IpadExitCameraValidation.Run();
  if(!exitCamera.passed)throw new Exception("iPad exit camera validation failed");
  Debug.Log("WEB_EXIT_CAMERA checks="+exitCamera.assertions+" failures="+exitCamera.failures);
  MazeBiters.NativeStudy.NativeAllyEscapeTopologyValidation.RunBatch();
  IpadDifficultyAudit.Run();
  PlayerSettings.companyName="Maze Biters";PlayerSettings.productName="Maze Biters iPad Web";
  PlayerSettings.colorSpace=ColorSpace.Gamma;PlayerSettings.defaultScreenWidth=1376;PlayerSettings.defaultScreenHeight=1032;
  PlayerSettings.runInBackground=false;PlayerSettings.SetScriptingBackend(NamedBuildTarget.WebGL,ScriptingImplementation.IL2CPP);
  PlayerSettings.SetUseDefaultGraphicsAPIs(BuildTarget.WebGL,false);PlayerSettings.SetGraphicsAPIs(BuildTarget.WebGL,new[]{GraphicsDeviceType.OpenGLES3});
  PlayerSettings.WebGL.compressionFormat=WebGLCompressionFormat.Gzip;
  PlayerSettings.WebGL.nameFilesAsHashes=true;
  PlayerSettings.WebGL.decompressionFallback=true;PlayerSettings.WebGL.dataCaching=true;
  PlayerSettings.WebGL.initialMemorySize=256;PlayerSettings.WebGL.maximumMemorySize=2048;
  PlayerSettings.WebGL.memoryGrowthMode=WebGLMemoryGrowthMode.Geometric;
  PlayerSettings.WebGL.threadsSupport=false;
  PlayerSettings.SetManagedStrippingLevel(NamedBuildTarget.WebGL,ManagedStrippingLevel.Low);
  PlayerSettings.WebGL.template="PROJECT:MazeBiters";
  var graphics=AssetDatabase.LoadAllAssetsAtPath("ProjectSettings/GraphicsSettings.asset")[0];var so=new SerializedObject(graphics);var list=so.FindProperty("m_AlwaysIncludedShaders");
  foreach(string guid in AssetDatabase.FindAssets("t:Shader",new[]{"Assets/Shaders"})){
   var shader=AssetDatabase.LoadAssetAtPath<Shader>(AssetDatabase.GUIDToAssetPath(guid));bool found=false;
   for(int i=0;i<list.arraySize;i++)found|=list.GetArrayElementAtIndex(i).objectReferenceValue==shader;
   if(!found){list.InsertArrayElementAtIndex(list.arraySize);list.GetArrayElementAtIndex(list.arraySize-1).objectReferenceValue=shader;}
  }so.ApplyModifiedPropertiesWithoutUndo();AssetDatabase.SaveAssets();
  string output=Path.GetFullPath(Path.Combine(Application.dataPath,"../../Builds/iPad"));Directory.CreateDirectory(output);
  var report=BuildPipeline.BuildPlayer(new BuildPlayerOptions{scenes=new[]{"Assets/NativeStudy.unity"},locationPathName=output,target=BuildTarget.WebGL,options=BuildOptions.None});
  if(report.summary.result!=BuildResult.Succeeded)throw new Exception("Web build failed "+report.summary.result);
  HashRuntimeFiles(output);
  string buildGuid=report.summary.guid.ToString();
  string payload=Path.Combine(output,"StreamingAssets/WebPayload");
  string manifest="manifest-"+buildGuid+".json";
  File.Copy(Path.Combine(payload,"manifest.json"),Path.Combine(payload,manifest),true);
  File.WriteAllText(Path.Combine(output,"build-info.json"),JsonUtility.ToJson(new BuildInfo{buildGuid=buildGuid,assetManifest=manifest},true));
  Debug.Log("WEB_BUILD_SUCCESS bytes="+report.summary.totalSize+" "+output);
 }
 public static void NormalizeExistingBuild(){
  string output=Path.GetFullPath(Path.Combine(Application.dataPath,"../../Builds/iPad"));
  HashRuntimeFiles(output);
  Debug.Log("WEB_RUNTIME_HASH_SUCCESS "+output);
 }
 static void HashRuntimeFiles(string output){
  // Unity can retain a filename when only the gzip timestamp changes. Hash
  // the actual delivered bytes so every runtime URL remains immutable.
  string indexPath=Path.Combine(output,"index.html"),html=File.ReadAllText(indexPath);
  foreach(string suffix in new[]{".loader.js",".framework.js.unityweb",".wasm.unityweb",".data.unityweb"}){
   var matches=Regex.Matches(html,"Build/[^'\"\\s<>?]+"+Regex.Escape(suffix));
   if(matches.Count!=1)throw new Exception("Expected one generated Unity resource "+suffix);
   string original=matches[0].Value,from=Path.Combine(output,original),name;
   using(var sha=SHA256.Create())name=BitConverter.ToString(sha.ComputeHash(File.ReadAllBytes(from))).Replace("-","").ToLowerInvariant()+suffix;
   string relative="Build/"+name,to=Path.Combine(output,relative);
   if(!string.Equals(from,to,StringComparison.OrdinalIgnoreCase))File.Copy(from,to,true);
   html=html.Replace(original,relative);
  }
  File.WriteAllText(indexPath,html);
 }
 [Serializable] sealed class BuildInfo {public int version=1;public string buildGuid,assetManifest;}
}

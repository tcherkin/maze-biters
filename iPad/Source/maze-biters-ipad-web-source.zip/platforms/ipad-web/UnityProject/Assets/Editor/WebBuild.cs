using System;
using System.IO;
using UnityEditor;
using UnityEditor.Build;
using UnityEditor.Build.Reporting;
using UnityEngine;
using UnityEngine.Rendering;
public static class WebBuild {
 public static void Build(){
  PlayerSettings.companyName="Maze Biters";PlayerSettings.productName="Maze Biters iPad Web";
  PlayerSettings.colorSpace=ColorSpace.Gamma;PlayerSettings.defaultScreenWidth=1376;PlayerSettings.defaultScreenHeight=1032;
  PlayerSettings.runInBackground=false;PlayerSettings.SetScriptingBackend(NamedBuildTarget.WebGL,ScriptingImplementation.IL2CPP);
  PlayerSettings.SetUseDefaultGraphicsAPIs(BuildTarget.WebGL,false);PlayerSettings.SetGraphicsAPIs(BuildTarget.WebGL,new[]{GraphicsDeviceType.OpenGLES3});
  PlayerSettings.WebGL.compressionFormat=WebGLCompressionFormat.Gzip;
  PlayerSettings.WebGL.decompressionFallback=true;PlayerSettings.WebGL.dataCaching=true;
  PlayerSettings.WebGL.initialMemorySize=256;PlayerSettings.WebGL.maximumMemorySize=2048;
  PlayerSettings.WebGL.memoryGrowthMode=WebGLMemoryGrowthMode.Geometric;
  PlayerSettings.WebGL.threadsSupport=false;
  PlayerSettings.SetManagedStrippingLevel(NamedBuildTarget.WebGL,ManagedStrippingLevel.Low);
  PlayerSettings.WebGL.template="PROJECT:MazeBiters";
  var graphics=AssetDatabase.LoadAllAssetsAtPath("ProjectSettings/GraphicsSettings.asset")[0];var so=new SerializedObject(graphics);var list=so.FindProperty("m_AlwaysIncludedShaders");
  foreach(string guid in AssetDatabase.FindAssets("t:Shader",new[]{"Assets/Shaders"})){
   var shader=AssetDatabase.LoadAssetAtPath<Shader>(AssetDatabase.GUIDToAssetPath(guid));bool found=false;
   for(int i=0;i<list.arraySize;i++)found|=list.GetArrayElementAtIndex(i).objectReferenceValue==shader;
   if(!found){list.InsertArrayElementAtIndex(list.arraySize);list.GetArrayElementAtIndex(list.arraySize-1).objectReferenceValue=shader;}
  }so.ApplyModifiedPropertiesWithoutUndo();AssetDatabase.SaveAssets();
  string output=Path.GetFullPath(Path.Combine(Application.dataPath,"../../Builds/iPad"));Directory.CreateDirectory(output);
  var report=BuildPipeline.BuildPlayer(new BuildPlayerOptions{scenes=new[]{"Assets/NativeStudy.unity"},locationPathName=output,target=BuildTarget.WebGL,options=BuildOptions.None});
  if(report.summary.result!=BuildResult.Succeeded)throw new Exception("Web build failed "+report.summary.result);
  Debug.Log("WEB_BUILD_SUCCESS bytes="+report.summary.totalSize+" "+output);
 }
}

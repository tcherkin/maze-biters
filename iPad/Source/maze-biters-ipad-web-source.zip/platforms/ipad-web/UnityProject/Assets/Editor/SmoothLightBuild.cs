using System;
using System.IO;
using System.Linq;
using UnityEngine;
using MazeBiters.NativeStudy;
public static class SmoothLightBuild {
 public static void Prepare(){
  string root=Path.Combine(Application.streamingAssetsPath,"Reference"),output=Path.GetFullPath(Path.Combine(Application.dataPath,"../Library/PreparedLight"));int count=0;long bytes=0;var paths=new System.Collections.Generic.List<string>();
  var files=Directory.GetFiles(root,"*.png").Where(p=>{
   string n=Path.GetFileName(p);return n.StartsWith("bite-")||n.StartsWith("pickup-hd-")||n.StartsWith("pickup-4k-")||n.StartsWith("session-font-")||n.StartsWith("session-skull-")||n.StartsWith("scorpion-")||n=="neon-eyes.png"||n.EndsWith("kernels.png")||n=="neon-receiver.png";
  }).Concat(Directory.GetFiles(Path.Combine(root,"coop"),"*.png").Where(p=>p.EndsWith("-sparks.png")||p.EndsWith("-outline.png")));
  foreach(string file in files){
   string name=file.Substring(root.Length+1).Replace('\\','/');bool pm=!name.StartsWith("session-");
   var t=new Texture2D(2,2,TextureFormat.RGBA32,false,false);
   try{
    if(!t.LoadImage(File.ReadAllBytes(file)))throw new InvalidDataException(file);
    if(pm){var p=t.GetPixels32();for(int i=0;i<p.Length;i++){p[i].r=(byte)Math.Round(p[i].r*p[i].a/255.0);p[i].g=(byte)Math.Round(p[i].g*p[i].a/255.0);p[i].b=(byte)Math.Round(p[i].b*p[i].a/255.0);}t.SetPixels32(p);}
    t.Apply(false,false);
    var raw=t.GetRawTextureData<byte>().ToArray();string path=Path.Combine(output,name+(pm?".pm.pixels":".raw.pixels"));Directory.CreateDirectory(Path.GetDirectoryName(path));
    NativePreparedLight.Write(path,t,raw);
    paths.Add(path);
    // Validate the runtime reader against Unity's original PNG decoder and
    // exact original alpha rounding, including all invisible RGB edge pixels.
    var actual=NativePreparedLight.Read(path);
    var expected=new uint[raw.Length/4];Buffer.BlockCopy(raw,0,expected,0,raw.Length);
    if(actual.width!=t.width||actual.height!=t.height||actual.format!=t.format||actual.linear==t.isDataSRGB||!expected.SequenceEqual(actual.words))throw new Exception("Prepared light mismatch: "+name);
    var copy=new Texture2D(actual.width,actual.height,actual.format,false,actual.linear);
    try{copy.SetPixelData(actual.words,0);copy.Apply(false,false);if(copy.graphicsFormat!=t.graphicsFormat||!copy.GetPixels32().SequenceEqual(t.GetPixels32()))throw new Exception("Prepared GPU format/color mismatch: "+name);}finally{UnityEngine.Object.DestroyImmediate(copy);}
    count++;bytes+=raw.Length;
   }finally{UnityEngine.Object.DestroyImmediate(t);}
  }
  string bank=Path.Combine(Application.streamingAssetsPath,"PreparedLight.bytes");
  using(var w=new BinaryWriter(File.Create(bank))){w.Write(0x4d424c32);w.Write(paths.Count);foreach(string p in paths){var data=File.ReadAllBytes(p);w.Write(p.Substring(output.Length+1).Replace('\\','/'));w.Write(data.Length);w.Write(data);}}
  using(var archive=new NativePreparedLight.Archive(bank))foreach(string p in paths){var a=NativePreparedLight.Read(p);var b=archive.Read(p.Substring(output.Length+1).Replace('\\','/'));if(a.width!=b.width||a.height!=b.height||a.format!=b.format||a.linear!=b.linear||!a.words.SequenceEqual(b.words))throw new Exception("Light archive mismatch: "+p);}
  Debug.Log("PREPARED_LIGHT_EXACT_TESTS "+count+" bytes="+bytes+" archive="+new FileInfo(bank).Length);
 }
}

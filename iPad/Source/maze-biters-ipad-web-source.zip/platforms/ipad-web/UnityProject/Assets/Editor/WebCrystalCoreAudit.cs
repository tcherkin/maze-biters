using System;
using System.Collections.Generic;
using System.IO;
using MazeBiters.NativeStudy;
using UnityEngine;

public static class WebCrystalCoreAudit {
 [Serializable]public sealed class Report {
  public bool passed;public int cases;public List<WebCrystalMaterialCase> results=new List<WebCrystalMaterialCase>();
  public WebWallLightRecordAudit routeRecords;
  public string scope="Small-brush cooperative core material calibration and actual geometry/alpha sampling in all nine palettes at HD/4K, without complete maze images or GPU allocations. Full synchronous/cooperative RGBA parity and cancellation are checked separately by WebPreparationValidation.Run. This does not claim browser GPU or physical iPad performance.";
 }
 public static void Run(){
  string folder=Path.GetFullPath(Path.Combine(Application.dataPath,"../../Results/full-integration"));Directory.CreateDirectory(folder);
  var report=new Report();
  try{
   var source=NativeCampaignComposition.Generate(811,91,NativeMazeGenerator.Difficulties[2]);
   foreach(string quality in new[]{"hd","4k"})foreach(string theme in NativeMazeGenerator.Themes){
    var level=JsonUtility.FromJson<SessionLevel>(JsonUtility.ToJson(source));level.theme=theme;
    report.results.Add(NativeMazeArtwork.ValidateWebCrystalMaterial(level,quality));report.cases++;
   }
   report.routeRecords=NativeMazeArtwork.ValidateWebWallLightRecords();
   report.passed=report.cases==NativeMazeGenerator.Themes.Length*2&&report.results.TrueForAll(item=>item.passed)&&report.routeRecords.passed;
  }
  finally{File.WriteAllText(Path.Combine(folder,"crystal-materials.json"),JsonUtility.ToJson(report,true));}
  if(!report.passed)throw new InvalidOperationException("Web crystal CPU painter parity failed");
  Debug.Log("WEB_CRYSTAL_CORE_AUDIT passed="+report.passed+" cases="+report.cases);
 }
}

using System;
using System.IO;
using UnityEditor;
using UnityEngine;
using MazeBiters.NativeStudy;
public static class IpadSafeStartAudit {
 [MenuItem("Maze Biters/iPad/Validate fair initial placement")]
 public static void Run(){
  string directory=Path.GetFullPath(Path.Combine(Application.dataPath,"../../Results/safe-start"));Directory.CreateDirectory(directory);
  var shields=NativeSpawnShieldValidation.Run();string shieldPath=Path.Combine(directory,"shield-validation.json");File.WriteAllText(shieldPath,JsonUtility.ToJson(shields,true));
  Debug.Log("IPAD_SPAWN_SHIELD checks="+shields.assertions+" failures="+shields.failures+" elapsedMs="+shields.elapsedMs.ToString("F1"));
  foreach(var check in shields.checks)if(!check.passed)Debug.LogError("IPAD_SPAWN_SHIELD_FAILURE "+check.name+": "+check.detail);
  if(!shields.passed)throw new InvalidOperationException("Spawn shield failed "+shields.failures+" checks. See "+shieldPath);
  var report=NativeSafeStartValidation.Run();string path=Path.Combine(directory,"placement-validation.json");File.WriteAllText(path,JsonUtility.ToJson(report,true));
  Debug.Log("IPAD_SAFE_START checks="+report.assertions+" generated="+report.generatedCases+" synthetic="+report.syntheticCases+" previews="+report.previewCases+" failures="+report.failures+" elapsedMs="+report.elapsedMs.ToString("F1"));
  foreach(var failure in report.failureDetails)Debug.LogError("IPAD_SAFE_START_FAILURE "+failure);
  if(!report.passed)throw new InvalidOperationException("Safe start placement failed "+report.failures+" checks. See "+path);
 }
 public static void Build(){Run();StudyBuild.Build();}
}

using System;
using System.IO;
using System.Collections.Generic;
using UnityEngine;
using MazeBiters.NativeStudy;

// Exercises the shipping input model against the shipping cell-movement engine.
// No physical device injection and no changes to the user's controls/settings.
public static class IpadOrbitAudit {
 [Serializable] public sealed class CheckResult {public string name,detail;public bool passed;}
 [Serializable] public sealed class Report {public bool passed;public int checks,failures;public string revision="20261108-orbit-touch";public string note;public List<CheckResult> results=new List<CheckResult>();}
 struct Finger {public int id;public Vector2 position;public TouchPhase phase;public Finger(int id,Vector2 position,TouchPhase phase){this.id=id;this.position=position;this.phase=phase;}}
 static Report report;
 static readonly string[] Grid={"###############","#.............#","#.............#","#.............#","#.............#","#.............#","#.............#","#.............#","###############"};
 static readonly Vector2 Origin=new Vector2(300,400);
 static readonly Vector2 Origin2=new Vector2(1100,400);
 static string DirectoryPath=>Path.GetFullPath(Path.Combine(Application.dataPath,"../../Results/orbit-touch"));
 static void Check(bool ok,string name,string detail=""){report.checks++;if(!ok){report.failures++;Debug.LogError("ORBIT_FAILURE "+name+" "+detail);}report.results.Add(new CheckResult{name=name,passed=ok,detail=detail});}
 static NativeGameplayWorld World(int mode=1){var w=new NativeGameplayWorld(Grid,()=>.5){Time=1000,Assist=false};w.SetMode(mode);for(int i=0;i<w.PlayerCount;i++){var p=w.GetPlayer(i);p.Cell=p.From=p.Previous=new Vector2Int(3+i*4,4);p.Dir=p.Next=Vector2Int.right;p.Waiting=true;}return w;}
 static Finger F(int id,Vector2 position,TouchPhase phase=TouchPhase.Moved)=>new Finger(id,position,phase);
 static void Frame(IpadOrbitInput input,NativeGameplayWorld world,bool active,params Finger[] touches){input.BeginFrame(world,1376,1032,active);foreach(var t in touches)input.Touch(t.id,t.position,t.phase);input.EndFrame(1f/60);}
 static void Step(IpadOrbitInput input,NativeGameplayWorld world,params Finger[] touches)=>Frame(input,world,true,touches);
 static Vector2 At(Vector2 origin,float angle,float distance)=>origin+new Vector2(Mathf.Cos(angle),-Mathf.Sin(angle))*distance;
 static int KeyMask(NativePlayer player){int bits=0;foreach(var key in player.Keys.Values){if(key.dir.x<0)bits|=1;if(key.dir.x>0)bits|=2;if(key.dir.y<0)bits|=4;if(key.dir.y>0)bits|=8;}return bits;}
 static float AngleDifference(float a,float b)=>Mathf.Abs(Mathf.DeltaAngle(a*Mathf.Rad2Deg,b*Mathf.Rad2Deg))*Mathf.Deg2Rad;
 static void Begin(IpadOrbitInput input,NativeGameplayWorld world,Vector2 origin,int id=1){Step(input,world,F(id,origin,TouchPhase.Began));}
 static void Settle(IpadOrbitInput input,NativeGameplayWorld world,Vector2 position,int frames=40,int id=1){for(int i=0;i<frames;i++)Step(input,world,F(id,position,TouchPhase.Stationary));}

 public static void Run(){
  report=new Report{note="Deterministic functional validation of the actual Orbit input and world movement. GPU screenshots are a separate Capture run. This is not a physical iPad/controller performance test."};
  try{Directions();Modes();Ownership();SharedWorldOwnership();ReleaseAndLifecycle();Handover();VisualMotion();CachedSceneVisualReset();}
  catch(Exception e){Check(false,"Audit completed without exception",e.ToString());}
  report.passed=report.failures==0;Directory.CreateDirectory(DirectoryPath);File.WriteAllText(Path.Combine(DirectoryPath,"input-validation.json"),JsonUtility.ToJson(report,true));
  Debug.Log("ORBIT_INPUT_CHECKS "+report.checks+" failures="+report.failures);
  if(!report.passed)throw new Exception("Orbit input validation failed; see input-validation.json");
 }
 static void Directions(){
  int[] expected={2,10,8,9,1,5,4,6};
  for(int dir=0;dir<8;dir++){
   var w=World();var input=new IpadOrbitInput();Begin(input,w,Origin);float r=input.Pads[0].Radius;var point=At(Origin,dir*Mathf.PI/4,r*.8f);Step(input,w,F(1,point));
   Check(input.Pads[0].Direction==dir,"Exact 45-degree sector "+dir);Check(KeyMask(w.Player)==expected[dir],"Shipping held keys for direction "+dir);
   int serial=w.Player.KeySerial;Settle(input,w,point,3);Check(serial==w.Player.KeySerial,"Stationary touch does not repeat key presses "+dir);
   var before=w.Player.Cell;w.AdvancePlayer();var delta=w.Player.Cell-before;Check(Mathf.Abs(delta.x)+Mathf.Abs(delta.y)==1,"Real world one-cell movement "+dir);
   if((dir&1)!=0){var first=delta;before=w.Player.Cell;w.AdvancePlayer();delta=w.Player.Cell-before;Check(first!=delta&&first.x*delta.x==0&&first.y*delta.y==0,"Original two-key staircase movement "+dir);}
   input.CancelAll();Check(w.Player.Keys.Count==0,"Cancel releases direction "+dir);
  }
  {var w=World();var input=new IpadOrbitInput();Begin(input,w,Origin);float r=input.Pads[0].Radius;
   Step(input,w,F(1,At(Origin,0,r*.5f)));Step(input,w,F(1,At(Origin,25*Mathf.Deg2Rad,r*.5f)));Check(input.Pads[0].Direction==0,"Sector boundary hysteresis holds east");
   Step(input,w,F(1,At(Origin,30*Mathf.Deg2Rad,r*.5f)));Check(input.Pads[0].Direction==1,"Sector boundary enters south-east");
   Step(input,w,F(1,At(Origin,20*Mathf.Deg2Rad,r*.5f)));Check(input.Pads[0].Direction==1,"Reverse boundary hysteresis holds diagonal");
   Step(input,w,F(1,At(Origin,15*Mathf.Deg2Rad,r*.5f)));Check(input.Pads[0].Direction==0,"Reverse boundary returns east");
   Step(input,w,F(1,Origin+Vector2.right*r*.10f));Check(input.Pads[0].Direction<0&&w.Player.Keys.Count==0,"Return to center releases held keys");
   Step(input,w,F(1,Origin+Vector2.right*r*.16f));Check(input.Pads[0].Direction<0,"Deadzone re-entry hysteresis");
   Step(input,w,F(1,Origin+Vector2.right*r*.20f));Check(input.Pads[0].Direction==0,"Exit deadzone reactivates immediately");
  }
 }
 static void Modes(){
  for(int mode=0;mode<=5;mode++){
   var w=World(mode);var input=new IpadOrbitInput();bool two=mode==2||mode==4||mode==5;
   Step(input,w,F(11,Origin,TouchPhase.Began),F(22,Origin2,TouchPhase.Began));
   Step(input,w,F(11,Origin+Vector2.right*80),F(22,Origin2+Vector2.down*80));
   if(mode==0)Check(w.Player.Keys.Count==0&&!input.Pads[0].Held&&!input.Pads[1].Held,"AI ONLY ignores touch");
   else Check(KeyMask(w.GetPlayer(0))==2,"P1 touch works in mode "+mode);
   if(two)Check(KeyMask(w.GetPlayer(1))==8&&input.Pads[1].Held,"Right half controls P2 in mode "+mode);
   else Check(!input.Pads[1].Held,"Single-human mode has only one pad "+mode);
   for(int n=0;n<w.PlayerCount;n++)if(w.GetPlayer(n).IsAI)Check(w.GetPlayer(n).Keys.Count==0,"Touch cannot drive AI slot "+mode+"/"+n);
  }
  foreach(int mode in new[]{1,3}){var w=World(mode);var input=new IpadOrbitInput();Begin(input,w,Origin2);Step(input,w,F(1,Origin2+Vector2.left*80));Check(KeyMask(w.Player)==1&&input.Pads[0].Held,"Single human can touch either half "+mode);}
 }
 static void Ownership(){
  var w=World(4);var input=new IpadOrbitInput();Step(input,w,F(1,Origin,TouchPhase.Began),F(2,Origin2,TouchPhase.Began));
  Step(input,w,F(1,Origin+new Vector2(70,70)),F(2,Origin2+new Vector2(-70,-70)));
  Check(KeyMask(w.GetPlayer(0))==6&&KeyMask(w.GetPlayer(1))==9,"Independent simultaneous opposite diagonals");
  Step(input,w,F(1,new Vector2(1200,600)),F(2,Origin2+new Vector2(-70,-70)));
  Check(input.Pads[0].Center==Origin&&input.Pads[1].Center==Origin2,"Crossing halves preserves finger ownership and origin");
  Step(input,w,F(1,new Vector2(1200,600)),F(2,Origin2+new Vector2(-70,-70)),F(3,new Vector2(200,200),TouchPhase.Began));
  Check(input.Pads[0].Center==Origin&&input.Pads[1].Center==Origin2,"Extra finger cannot replace either player");
  Step(input,w,F(1,Origin,TouchPhase.Ended),F(2,Origin2+new Vector2(-70,-70)),F(3,new Vector2(300,200)));
  Check(!input.Pads[0].Held&&input.Pads[1].Held&&KeyMask(w.GetPlayer(1))==9,"Releasing P1 preserves P2 and ignores old rejected finger");
  Step(input,w,F(4,new Vector2(200,200),TouchPhase.Began),F(2,Origin2+new Vector2(-70,-70)));
  Check(input.Pads[0].Center==new Vector2(200,200),"Fresh touch recenters at new finger contact");
 }
 static void SharedWorldOwnership(){
  var w=World();var live=new IpadOrbitInput();var preparation=new IpadOrbitInput();
  Begin(live,w,Origin);Step(live,w,F(1,Origin+new Vector2(100,100)));
  int serial=w.Player.KeySerial;Check(KeyMask(w.Player)==6&&w.Player.Keys.Count==2,"Shared-world fixture holds live north-east diagonal");
  void Unchanged(string action){Check(KeyMask(w.Player)==6&&w.Player.Keys.Count==2&&w.Player.KeySerial==serial&&live.Pads[0].Held,"Inactive preparation preserves live keys after "+action);}
  preparation.BeginFrame(w,1376,1032,false);preparation.EndFrame(1f/60);Unchanged("inactive frame");
  preparation.CancelAll();Unchanged("cancel");
  preparation.BeginFrame(w,2752,2064,false);preparation.EndFrame(1f/60);Unchanged("resize");
  preparation.BeginFrame(World(),2752,2064,false);preparation.EndFrame(1f/60);Unchanged("world replacement");
  preparation.BeginFrame(w,1376,1032,false);preparation.CancelAll();Unchanged("return and repeated cancellation");
  var before=w.Player.Cell;w.AdvancePlayer();var first=w.Player.Cell-before;before=w.Player.Cell;w.AdvancePlayer();var second=w.Player.Cell-before;
  Check(first!=second&&first+second==new Vector2Int(1,-1),"Live diagonal still advances actual world after preparation");
  live.CancelAll();Check(w.Player.Keys.Count==0&&!live.Pads[0].Held,"Owning model cancellation still releases its keys");
 }
 static void ReleaseAndLifecycle(){
  foreach(string cause in new[]{"ended","canceled","missing","paused","dead","eliminated","lives","transition","gameover","resize","newworld","cancel"}){
   var w=World();var input=new IpadOrbitInput();Begin(input,w,Origin);var point=Origin+Vector2.right*80;Step(input,w,F(1,point));
   switch(cause){
    case "ended":Step(input,w,F(1,point,TouchPhase.Ended));break;
    case "canceled":Step(input,w,F(1,point,TouchPhase.Canceled));break;
    case "missing":Step(input,w);break;
    case "paused":Frame(input,w,false,F(1,point,TouchPhase.Stationary));break;
    case "dead":w.Player.Dead=true;Step(input,w,F(1,point,TouchPhase.Stationary));break;
    case "eliminated":w.Player.Eliminated=true;Step(input,w,F(1,point,TouchPhase.Stationary));break;
    case "lives":w.Player.Lives=0;Step(input,w,F(1,point,TouchPhase.Stationary));break;
    case "transition":w.Snakes.Clear();w.Transition=true;Step(input,w,F(1,point,TouchPhase.Stationary));break;
    case "gameover":w.GameOver=true;Step(input,w,F(1,point,TouchPhase.Stationary));break;
    case "resize":input.BeginFrame(w,2064,2752,true);input.Touch(1,point,TouchPhase.Stationary);input.EndFrame(1f/60);break;
    case "newworld":input.BeginFrame(World(),1376,1032,true);input.EndFrame(1f/60);break;
    case "cancel":input.CancelAll();break;
   }
   Check(w.Player.Keys.Count==0&&!input.Pads[0].Held,"Release on "+cause);
   if(cause=="paused"||cause=="dead"){
    w.Player.Dead=false;Step(input,w,F(1,point,TouchPhase.Stationary));Check(w.Player.Keys.Count==0&&!input.Pads[0].Held,"Old held finger cannot revive after "+cause);
   }
  }
 }
 static void Handover(){
  foreach(var source in new[]{IpadOrbitSource.Keyboard,IpadOrbitSource.Gamepad}){
   var w=World(2);var input=new IpadOrbitInput();Step(input,w,F(1,Origin,TouchPhase.Began),F(2,Origin2,TouchPhase.Began));
   Step(input,w,F(1,Origin+Vector2.right*80),F(2,Origin2+Vector2.up*80));
   input.ClaimExternal(0,source);using(w.ForPlayer(w.GetPlayer(0)))w.Press(source==IpadOrbitSource.Keyboard?"D":"GamepadSlot0:right",Vector2Int.right);
   Check(input.SourceFor(0)==source&&!input.Pads[0].Held,"External source takes P1 ownership "+source);
   Check(KeyMask(w.GetPlayer(1))==4&&input.Pads[1].Held,"External P1 does not affect touch P2 "+source);
   Step(input,w,F(1,Origin+Vector2.right*80,TouchPhase.Stationary),F(2,Origin2+Vector2.up*80,TouchPhase.Stationary));
   Check(input.SourceFor(0)==source,"Stationary old touch cannot steal source "+source);
   input.CancelAll();Check(w.GetPlayer(0).Keys.Count==1,"Touch cancellation preserves external keys "+source);
   Begin(input,w,Origin,30);Step(input,w,F(30,Origin+Vector2.left*80));Check(input.SourceFor(0)==IpadOrbitSource.Touch,"Fresh finger switches back to touch "+source);
  }
 }
 static void VisualMotion(){
  var w=World();var input=new IpadOrbitInput();Begin(input,w,Origin);var pad=input.Pads[0];
  Check(pad.Alpha>0&&pad.Alpha<1,"First contact fades in rather than popping");
  var east=Origin+Vector2.right*100;Settle(input,w,east,30);Check(pad.Alpha==1&&Mathf.Abs(pad.LightStrength-1)<.001f,"Held contact settles fully visible");
  float angle=pad.LightAngle;Step(input,w,F(1,Origin+Vector2.up*100));Check(pad.Direction==6&&AngleDifference(pad.LightAngle,angle)<Mathf.PI*.5f,"Input changes immediately while ring light travels");
  Settle(input,w,Origin+Vector2.up*100,60);Check(AngleDifference(pad.LightAngle,-Mathf.PI/2)<.005f,"Ring light settles at single north center");
  for(int dir=0;dir<8;dir++){var point=At(Origin,dir*Mathf.PI/4,200);Settle(input,w,point,60);Check(AngleDifference(pad.LightAngle,dir*Mathf.PI/4)<.005f,"Independent illuminated direction "+dir);Check(pad.ThumbOffset.magnitude+pad.Radius*((128*.26f+120*.52f)/2/120)<pad.Radius,"Thumb remains within outer ring "+dir);}
  Step(input,w,F(1,east,TouchPhase.Ended));Check(!pad.Held&&pad.Alpha>0&&pad.Alpha<1,"Release begins visible fade-out");for(int i=0;i<20;i++)Step(input,w);Check(pad.Alpha==0,"Released pad disappears fully");
 }
 static void CachedSceneVisualReset(){
  var w=World(2);var input=new IpadOrbitInput();
  Step(input,w,F(1,Origin,TouchPhase.Began),F(2,Origin2,TouchPhase.Began));
  for(int i=0;i<30;i++)Step(input,w,F(1,Origin+new Vector2(100,100)),F(2,Origin2+new Vector2(-100,100)));
  Check(input.Pads[0].Alpha==1&&input.Pads[1].Alpha==1,"Cached-scene fixture starts with both visible touch cursors");
  input.ClearImmediately();
  for(int slot=0;slot<2;slot++){
   var p=input.Pads[slot];Check(!p.Held&&p.Alpha==0&&p.LightStrength==0&&p.ThumbOffset==Vector2.zero&&w.GetPlayer(slot).Keys.Count==0,"Disable clears cached cursor and owned keys immediately "+slot);
  }
  // No visual updates happen while the cached GameObject is disabled. Resuming
  // the same object/world must not replay the old fade or reuse old finger IDs.
  Step(input,w,F(1,Origin+new Vector2(100,100),TouchPhase.Stationary),F(2,Origin2+new Vector2(-100,100),TouchPhase.Stationary));
  for(int slot=0;slot<2;slot++)Check(input.Pads[slot].Alpha==0&&!input.Pads[slot].Held&&w.GetPlayer(slot).Keys.Count==0,"Cached scene restart has no ghost cursor or old input "+slot);
  Begin(input,w,Origin,10);Check(input.Pads[0].Held&&input.Pads[0].Alpha>0&&input.Pads[0].Alpha<1,"Fresh post-restart touch begins normal fade-in");
 }
 public static void All(){Run();Capture();}
 public static void Capture(){
  if(SystemInfo.graphicsDeviceType==UnityEngine.Rendering.GraphicsDeviceType.Null)throw new Exception("Orbit captures require a graphics device");
  Directory.CreateDirectory(DirectoryPath);using(var renderer=new IpadOrbitRenderer())foreach(int height in new[]{1032,2064}){
   int width=height*4/3;string quality=height==1032?"hd":"4k";
   var backdropPath=Path.GetFullPath(Path.Combine(Application.dataPath,"../../Results/eight-wall-lights/"+quality+"/"+quality+"-amethyst-eight-lights.png"));
   var backdrop=new Texture2D(2,2,TextureFormat.RGBA32,false);if(!ImageConversion.LoadImage(backdrop,File.ReadAllBytes(backdropPath)))throw new Exception("Cannot load native gameplay capture");
   var target=new RenderTexture(width,height,0,RenderTextureFormat.ARGB32);target.Create();var old=RenderTexture.active;
   try{foreach(int mode in new[]{1,2}){
    var input=new IpadOrbitInput();var w=World(mode);Vector2 left=new Vector2(width*.24f,height*.27f),right=new Vector2(width*.76f,height*.27f);
    input.BeginFrame(w,width,height,true);input.Touch(1,left,TouchPhase.Began);if(mode==2)input.Touch(2,right,TouchPhase.Began);input.EndFrame(1f/60);
    for(int frame=0;frame<60;frame++){input.BeginFrame(w,width,height,true);input.Touch(1,left+new Vector2(200,200),TouchPhase.Moved);if(mode==2)input.Touch(2,right+new Vector2(-200,200),TouchPhase.Moved);input.EndFrame(1f/60);}
    Graphics.Blit(backdrop,target);renderer.DrawToTarget(target,input);RenderTexture.active=target;
    var image=new Texture2D(width,height,TextureFormat.RGBA32,false);image.ReadPixels(new Rect(0,0,width,height),0,0);image.Apply();File.WriteAllBytes(Path.Combine(DirectoryPath,quality+"-"+(mode==1?"solo":"duo")+"-orbit.png"),image.EncodeToPNG());UnityEngine.Object.DestroyImmediate(image);
   }}finally{RenderTexture.active=old;target.Release();UnityEngine.Object.DestroyImmediate(target);UnityEngine.Object.DestroyImmediate(backdrop);}
  }
  Debug.Log("ORBIT_GPU_CAPTURES "+DirectoryPath);
 }
}

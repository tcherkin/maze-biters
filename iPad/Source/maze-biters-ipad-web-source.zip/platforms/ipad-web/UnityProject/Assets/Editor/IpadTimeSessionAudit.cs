using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using UnityEngine;
using MazeBiters.NativeStudy;

// Editor-only controlled sessions. No renderer, UI automation, or runtime override.
public static class IpadTimeSessionAudit {
 [Serializable] public sealed class Count {public string name;public int count;}
 [Serializable] public sealed class Death {public int player,level;public double seconds;public string reason;public int x,y;}
 [Serializable] public sealed class Actor {public int id,score,lives,deaths,respawns,extraLives,steps,reversals,uniqueCells,wallBlockedDecisions;public double rawPoints,actionRawPoints,aliveSeconds,stationaryAliveMaxSeconds,firstDeathSeconds=-1;public Count[] thoughts;public Count[] events;}
 [Serializable] public sealed class Row {public string difficulty,mode,policy;public int difficultyIndex,seed,startLevel,endLevel,initialSnakeMass,finalSnakeMass;public double durationSeconds,elapsedMs,firstScorpionSeconds=-1,maxLevelAgeSeconds,maxIntensity;public int peakHunters,peakHunterReservations;public bool gameOver;public Actor human,ai;public Count[] snakeIntents;public Death[] deaths;}
 [Serializable] public sealed class Report {public string kind,policy,limitations;public int sessionCount;public double simulationSeconds,elapsedMs;public Row[] sessions;}
 static string DirectoryPath=>Path.GetFullPath(Path.Combine(Application.dataPath,"../../Results/time-escalation"));
 static void Add(Dictionary<string,int> target,string key){if(string.IsNullOrEmpty(key))key="none";target.TryGetValue(key,out int n);target[key]=n+1;}
 static Count[] Counts(Dictionary<string,int> d)=>d.OrderByDescending(k=>k.Value).Select(k=>new Count{name=k.Key,count=k.Value}).ToArray();
 sealed class Tracking {
  public Actor result;public Dictionary<string,int> thoughts=new Dictionary<string,int>(),events=new Dictionary<string,int>();public HashSet<string> cells=new HashSet<string>();public Vector2Int position,previous;public double stationary;public bool observed;
  public Tracking(int id){result=new Actor{id=id};}
  public void Observe(NativeGameplayWorld w,NativePlayer p,double dt){
   if(p.Dead||p.Lives<=0||w.Transition){stationary=0;observed=false;return;}
   result.aliveSeconds+=dt/1000;cells.Add(w.Level+":"+p.Cell.x+":"+p.Cell.y);
   if(!observed){position=previous=p.Cell;observed=true;}
   if(position==p.Cell){stationary+=dt;result.stationaryAliveMaxSeconds=Math.Max(result.stationaryAliveMaxSeconds,stationary/1000);}
   else {result.steps++;if(previous==p.Cell)result.reversals++;previous=position;position=p.Cell;stationary=0;}
  }
  public Actor Finish(NativeGameplayWorld w,NativePlayer p,int startLevel){result.score=p.Score;result.rawPoints=p.ExactScore/w.Difficulty;result.actionRawPoints=result.rawPoints-500*(w.Level-startLevel);result.lives=p.Lives;result.extraLives=p.ExtraLives;result.uniqueCells=cells.Count;result.thoughts=Counts(thoughts);result.events=Counts(events);return result;}
 }
 sealed class Collector {
  readonly Dictionary<int,int> visits=new Dictionary<int,int>();int level=-1;Vector2Int last;bool seen;
  static bool Safe(NativeGameplayWorld w,NativePlayer p,Vector2Int from,Vector2Int to){
   if(!w.PlayerCellOpen(p,to)||!w.PlayerRouteSafe(p,to))return false;
   bool power=p.PowerUntil>w.Time||p.ShieldUntil>w.Time;if(power)return true;
   var move=to-from;
   foreach(var snake in w.Snakes){
    if(to==snake.Head){bool safe=snake.Body.Count==1?move!=-snake.Dir:move==snake.Dir;if(!safe)return false;}
    else if(!snake.Reversing&&to==snake.Head+snake.Dir)return false;
   }
   foreach(var hunter in w.Hunters)if(to==hunter.Cell||to==hunter.Cell+hunter.Dir)return false;
   if(w.Scorpion!=null&&to==w.Scorpion.Cell)return false;
   return true;
  }
  public void Plan(NativeGameplayWorld w,Tracking tracking,bool novice){
   var p=w.GetPlayer(0);if(p.Dead||p.Lives<=0||w.Transition)return;
   if(level!=w.Level){visits.Clear();level=w.Level;seen=false;}
   if(!seen||last!=p.Cell){int key=w.Index(p.Cell);visits.TryGetValue(key,out int n);visits[key]=n+1;last=p.Cell;seen=true;}
   if(novice){
    Vector2Int? direction=null;double noviceRank=double.PositiveInfinity;
    foreach(var d in NativeGameplayWorld.Dirs){var cell=p.Cell+d;if(!w.PlayerCellOpen(p,cell))continue;visits.TryGetValue(w.Index(cell),out int n);double score=n*2+(d==p.Dir?-.2:0)+(d==-p.Dir?.35:0);if(score<noviceRank){noviceRank=score;direction=d;}}
    using(w.ForPlayer(p)){w.ClearKeys();p.Pointer=null;p.PointerMomentum=false;if(direction.HasValue)w.Press("balance-explorer",direction.Value);else{p.Waiting=true;tracking.result.wallBlockedDecisions++;}}
    return;
   }
   int count=w.Width*w.Height;var distances=Enumerable.Repeat(-1,count).ToArray();var first=new Vector2Int[count];var q=new List<Vector2Int>{p.Cell};distances[w.Index(p.Cell)]=0;
   for(int r=0;r<q.Count;r++){var at=q[r];foreach(var dir in NativeGameplayWorld.Dirs){var next=at+dir;if(!w.Floor(next)||distances[w.Index(next)]>=0||!Safe(w,p,at,next))continue;int key=w.Index(next);distances[key]=distances[w.Index(at)]+1;first[key]=at==p.Cell?dir:first[w.Index(at)];q.Add(next);}}
   Vector2Int? best=null;double rank=double.PositiveInfinity;
   void Goal(Vector2Int cell,double bias){if(!w.Floor(cell))return;int key=w.Index(cell),d=distances[key];if(d<=0)return;double value=d+bias+(first[key]==p.Dir?-.1:0);if(value<rank){rank=value;best=first[key];}}
   foreach(var fruit in w.Fruits)Goal(fruit.Cell,-4);
   foreach(var snake in w.Snakes)Goal(snake.Tail,snake.Body.Count==1?1:0);
   if(best==null){foreach(var cell in q){int key=w.Index(cell),d=distances[key];if(d==0)continue;visits.TryGetValue(key,out int n);double score=n*4+d*.15+(first[key]==p.Dir?-.1:0);if(score<rank){rank=score;best=first[key];}}}
   // Input goes through the same public keyboard controller as a human.
   using(w.ForPlayer(p)){w.ClearKeys();p.Pointer=null;p.PointerMomentum=false;if(best.HasValue){w.Press("balance-collector",best.Value);if(!w.PlayerCellOpen(p,p.Cell+best.Value))tracking.result.wallBlockedDecisions++;}else{p.Waiting=true;tracking.result.wallBlockedDecisions++;}}
  }
 }
 static Row Session(int difficulty,int mode,int seed,int startLevel,bool novice){
  var watch=Stopwatch.StartNew();var gen=new NativeMazeGenerator((uint)seed,NativeMazeGenerator.Difficulties[difficulty]);var levels=new Dictionary<int,SessionLevel>();
  SessionLevel Load(int n){if(!levels.TryGetValue(n,out var value)){value=gen.Generate(n);levels.Add(n,value);}return value;}
  var world=new NativeGameplayWorld(Load(1).geometry,NativeMazeGenerator.Rng((uint)(seed+8123))){Difficulty=NativeMazeGenerator.Difficulties[difficulty],AiDifficulty=difficulty,Time=1000,RealTime=1000,ScoreSpeed=1,Assist=true};world.SetMode(mode);world.StartSession(Load);
  for(int n=1;n<startLevel;n++)world.AdvanceLevel();
  for(int i=0;i<world.PlayerCount;i++){var p=world.GetPlayer(i);p.Score=0;p.ExactScore=0;p.Lives=3;p.NextLifeScore=5000;p.ExtraLives=0;}
  var row=new Row{difficulty=NativeMazeGenerator.DifficultyNames[difficulty],difficultyIndex=difficulty,mode=mode==1?"SOLO":"SOLO VS AI",policy=novice?"novice-explorer":"collector",seed=seed,startLevel=startLevel,initialSnakeMass=world.Snakes.Sum(s=>s.Body.Count)};
  var tracks=Enumerable.Range(0,world.PlayerCount).Select(i=>new Tracking(i+1)).ToArray();var deaths=new List<Death>();var eatenBy=new Dictionary<int,double>();
  var snakeIntents=new Dictionary<string,int>();var collector=new Collector();double start=world.Time;bool observedScorpion=false;
  world.Event=e=>{
   if(e.Kind=="playerBite"&&e.Victim!=null)eatenBy[e.Victim.Id]=world.Time;
   if(e.Player==null)return;var track=tracks[e.Player.Id-1];if(e.Kind!="sound"&&e.Kind!="snakeMove"&&e.Kind!="playerTurn"&&e.Kind!="hunterTurn")Add(track.events,e.Kind);
   if(e.Kind=="respawn")track.result.respawns++;
   if(e.Kind=="death"){
    track.result.deaths++;double t=(world.Time-start)/1000;if(track.result.firstDeathSeconds<0)track.result.firstDeathSeconds=t;
    string reason=eatenBy.TryGetValue(e.Player.Id,out double at)&&at==world.Time?"competing-player":world.Snakes.Any(s=>s.Head==e.Player.Cell)?"snake-head":world.Hunters.Any(h=>h.Cell==e.Player.Cell)?"hunter":"unclassified-contact";
    deaths.Add(new Death{player=e.Player.Id,level=world.Level,seconds=t,reason=reason,x=e.Player.Cell.x,y=e.Player.Cell.y});
   }
  };
  int iteration=0;while(world.Time-start<360000&&!world.GameOver){
   double now=world.Time+10;var human=world.GetPlayer(0);
   if(now-human.LastMove>world.PlayerDelay)collector.Plan(world,tracks[0],novice);world.RealTime=now;world.Tick(now);
   for(int i=0;i<world.PlayerCount;i++)tracks[i].Observe(world,world.GetPlayer(i),10);
   row.maxLevelAgeSeconds=Math.Max(row.maxLevelAgeSeconds,(world.Time-world.LevelStarted)/1000);row.maxIntensity=Math.Max(row.maxIntensity,world.DifficultyProfile.Intensity);row.peakHunters=Math.Max(row.peakHunters,world.Hunters.Count);row.peakHunterReservations=Math.Max(row.peakHunterReservations,world.Hunters.Count+world.Eggs.Count+world.PendingDrops.Count(d=>d.Egg));
   if(!observedScorpion&&world.Scorpion!=null){observedScorpion=true;row.firstScorpionSeconds=(world.Time-start)/1000;}
   if(++iteration%10==0&&!world.Transition){
    foreach(var snake in world.Snakes)Add(snakeIntents,snake.Brain?.intent??"undecided");
    for(int i=1;i<world.PlayerCount;i++){var p=world.GetPlayer(i);if(!p.Dead&&p.Lives>0)Add(tracks[i].thoughts,p.Ai?.thought??"none");}
   }
  }
  row.durationSeconds=(world.Time-start)/1000;row.endLevel=world.Level;row.gameOver=world.GameOver;row.finalSnakeMass=world.Snakes.Sum(s=>s.Body.Count);row.human=tracks[0].Finish(world,world.GetPlayer(0),startLevel);if(world.PlayerCount>1)row.ai=tracks[1].Finish(world,world.GetPlayer(1),startLevel);row.snakeIntents=Counts(snakeIntents);row.deaths=deaths.ToArray();row.elapsedMs=watch.Elapsed.TotalMilliseconds;return row;
 }
 public static void Run(){
  Directory.CreateDirectory(DirectoryPath);var watch=Stopwatch.StartNew();var rows=new List<Row>();
  foreach(bool novice in new[]{false})foreach(int startLevel in new[]{1})foreach(int mode in new[]{1,3})for(int difficulty=0;difficulty<5;difficulty++)foreach(int seed in new[]{34,107,1009}){
   var row=Session(difficulty,mode,seed,startLevel,novice);rows.Add(row);UnityEngine.Debug.Log("TIME_ESCALATION_SESSION "+row.policy+" "+row.startLevel+" "+row.mode+" "+row.difficulty+" seed="+seed+" humanRaw="+row.human.rawPoints+" deaths="+row.human.deaths+" aiRaw="+(row.ai?.rawPoints??0));
  }
  var report=new Report{kind="Controlled full-session simulation of the native iPad time-escalation gameplay code, no rendering or device timing measurement",policy="Fixed independent collector policy: shortest safe route to current snake tails or fruit, avoid current/predicted heads and hunters, explore least-visited reachable cells when no food route exists. The collector uses public keyboard Press/Release with normal assist enabled, no invulnerability or gameplay overrides. All settings use identical policy and medium speed. Each campaign starts naturally at level 1 with three lives.",limitations="Synthetic collector sees the whole board and reacts every simulation movement step, unlike a human with touch input. Results compare a consistent synthetic policy, not human win rates. Enemy generation and collisions are genuine; no visual rendering, GPU, device-memory or frame-pacing measurement. Sessions last 360 simulation seconds or until GameOver. Normal level clearing resets escalation. Maximum level age is reported; a campaign lasting six minutes does not imply that any individual level reached the five-minute escalation endpoint. actionRawPoints excludes normal shared level-clear bonuses and score multipliers.",sessionCount=rows.Count,simulationSeconds=rows.Sum(r=>r.durationSeconds),elapsedMs=watch.Elapsed.TotalMilliseconds,sessions=rows.ToArray()};
  File.WriteAllText(Path.Combine(DirectoryPath,"continuous-sessions.json"),JsonUtility.ToJson(report,true));UnityEngine.Debug.Log("TIME_ESCALATION_SESSION_COMPLETE count="+rows.Count+" simSeconds="+report.simulationSeconds+" ms="+report.elapsedMs);
 }
}

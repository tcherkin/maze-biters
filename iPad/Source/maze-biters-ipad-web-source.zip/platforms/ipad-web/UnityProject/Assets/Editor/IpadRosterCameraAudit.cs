using System;
using System.IO;
using System.Text;
using System.Globalization;
using UnityEngine;
using MazeBiters.NativeStudy;
public static class IpadRosterCameraAudit {
 public static void Build(){Run();StudyBuild.Build();}
 public static void Run(){
  string root=Path.GetFullPath(Path.Combine(Application.dataPath,"../../Results/camera-balance/numeric"));Directory.CreateDirectory(root);
  Debug.Log("IPAD_BALANCE_CHECKS "+IpadCameraBalanceValidation.Run());
  int checks=0;void Check(bool ok,string name){checks++;if(!ok)throw new Exception("iPad roster camera: "+name);}
  foreach(int count in new[]{2,3})foreach(int fps in new[]{60,120})foreach(string kind in new[]{"movement","respawn","simultaneous","blocked","elimination","farrespawn","farfinal"}){
   string name=count+"-"+kind+"-"+fps;var grid=new string[25];for(int i=0;i<25;i++)grid[i]=new string('.',36);
   var w=new NativeGameplayWorld(grid,()=>.5);w.SetMode(count==3?4:2);var scenario=new IpadRosterScenario(w,kind=="farfinal"?"elimination":kind=="farrespawn"?"respawn":kind,1.4);
   if(kind=="farfinal"||kind=="farrespawn")for(int i=0;i<count;i++){var p=w.GetPlayer(i);p.Cell=p.From=p.Previous=i==0?new Vector2Int(34,23):i==1?new Vector2Int(1,1):new Vector2Int(34,1);}
   var raw=new NativeGameplayCamera();raw.Reset(1000);var before=new IpadCameraBeforeBalance();var passive=new IpadCameraAnticipatoryReference();var after=new IpadCameraMotion();
   w.Event=e=>{if(e.Kind=="respawn"){after.BeginReveal(w.RealTime,e.Player.Id);before.BeginReveal(w.RealTime,e.Player.Id);}else if(e.Kind=="death"){after.BeginLoss(w.RealTime,e.Player.Id);before.BeginLoss(w.RealTime,e.Player.Id);}};
   var f=new NativeFrame(4f/3,true);var safe=new Rect(0,0,f.Width,f.Height);double close=160.0*432/(16*2064);
   var csv=new StringBuilder("time,event,living,oldX,oldY,oldZoom,newX,newY,newZoom,oldCorrections,newCorrections,revealing\n");
   double oldZ=1,newZ=1,minZ=3,maxZ=0;bool wasRevealing=false;int handoffFrames=0;
   for(int frame=0;frame<fps*28;frame++){
    double t=frame*1000.0/fps;scenario.Step(t);raw.UpdateRoster(w,false,1000+t,w.Time);
    var active=IpadCameraRoster.Bounds(w,w.Time);var upcoming=IpadCameraRoster.Upcoming(w,w.Time,active);
    var a=before.Sample(f,raw.X,raw.Y,raw.Zoom,close,safe,active,1000+t,raw.TargetX,raw.TargetY,IpadCameraRoster.Bounds(w,w.Time,excludeMask:before.JoiningMask),raw.TargetZoom);
    var retained=IpadCameraRoster.Bounds(w,w.Time,excludeMask:after.JoiningMask);
    var control=passive.Sample(f,raw.X,raw.Y,raw.Zoom,close,safe,active,1000+t,raw.TargetX,raw.TargetY,null,raw.TargetZoom);
    var b=after.Sample(f,raw.X,raw.Y,raw.Zoom,close,safe,active,1000+t,raw.TargetX,raw.TargetY,retained,raw.TargetZoom);
    if(scenario.Respawns==0)Check(after.JoiningMask==0,name+" no early joining player");
    if(scenario.Event.StartsWith("respawn")){Check(Math.Abs(b.zoom-newZ)<.01,name+" no zoom step at respawn");}
    if(wasRevealing&&!after.Revealing)handoffFrames=3;
    if(handoffFrames>0){Check(Math.Abs(b.zoom-newZ)<.005,name+" smooth handoff to ordinary following frame="+frame+" dz="+(b.zoom-newZ)+" x="+b.x+" y="+b.y+" z="+b.zoom);handoffFrames--;}
    wasRevealing=after.Revealing;
    oldZ=a.zoom;newZ=b.zoom;minZ=Math.Min(minZ,b.zoom);maxZ=Math.Max(maxZ,b.zoom);
    var required=after.Revealing?retained:active;
    if(required.HasValue){var r=required.Value;var board=f.ProjectBoard(b.x,b.y,b.zoom);Check(board.x+(r.xMin-12)*b.zoom>=-.002&&board.x+(r.xMax+12)*b.zoom<=f.Width+.002&&board.y+(r.yMin-12)*b.zoom>=b.header-.002&&board.y+(r.yMax+12)*b.zoom<=f.Height+.002,name+" visibility "+frame);}
    csv.Append(t.ToString("R",CultureInfo.InvariantCulture)).Append(',').Append(scenario.Event).Append(',').Append(raw.Living);
    foreach(double value in new[]{a.x,a.y,a.zoom,b.x,b.y,b.zoom,(double)before.EmergencyCorrections,after.EmergencyCorrections,after.Revealing?1:0})csv.Append(',').Append(value.ToString("R",CultureInfo.InvariantCulture));csv.AppendLine();
   }
   Check(kind=="movement"||scenario.Deaths==count-1,name+" deaths");Check(kind=="movement"||(kind=="elimination"||kind=="farfinal")||scenario.Respawns==count-1,name+" original respawns");
   Check(kind!="movement"||minZ<1.2&&maxZ>1.6,name+" exercises both separated and gathered framing");
   Check(after.EmergencyCorrections==0,name+" no abrupt visibility corrections");
   File.WriteAllText(Path.Combine(root,name+".csv"),csv.ToString());
  }
  Debug.Log("IPAD_SOLO_PACE_CHECKS "+IpadSoloPaceValidation.Run());
  Debug.Log("IPAD_ROSTER_CAMERA_CHECKS "+checks);Debug.Log("IPAD_CAMERA_MOTION_TESTS "+IpadCameraMotionValidation.Run());
 }
}

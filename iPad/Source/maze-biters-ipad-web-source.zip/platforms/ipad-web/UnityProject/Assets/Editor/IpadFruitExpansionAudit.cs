using System;
using System.IO;
using System.Linq;
using System.Collections.Generic;
using UnityEngine;
using MazeBiters.NativeStudy;
public static class IpadFruitExpansionAudit {
 [Serializable] public sealed class Report {public bool passed;public int checks,sequences,collections,basePoints,comboChecks;public string scope="Native iPad: ten equal-value pickups, appearance variety, blocked drops, all participant slots, difficulty/speed scoring, Power/combos and original lifecycle oracles.";}
 public static void Validate(){
  var r=new Report{basePoints=NativeFruitCatalog.Points};void Check(bool ok,string why){r.checks++;if(!ok)throw new Exception("FRUIT_EXPANSION "+why);}
  var empty=new List<NativeFruit>();var firsts=new HashSet<int>();
  for(uint seed=1;seed<=96;seed++)for(int level=1;level<=3;level++){
   var bag=new NativeFruitVariety();var twin=new NativeFruitVariety();var visible=new List<NativeFruit>();var rng=new System.Random((int)seed+level*987);int last=-1;
   for(int cycle=0;cycle<3;cycle++){
    var seen=new HashSet<int>();
    for(int i=0;i<NativeFruitCatalog.Count;i++){
     var at=new Vector2Int(cycle*25+i*2,1);double roll=rng.NextDouble();int kind=bag.Select(level,seed,roll,at,visible);
     Check(kind==twin.Select(level,seed,roll,at,visible),"reproducible appearance stream");Check(seen.Add(kind),"no repeat before every kind has appeared");
     if(cycle==0&&i==0)firsts.Add(kind);if(cycle>0&&i==0)Check(kind!=last,"no immediate repeat across bag boundary");
     visible.Add(new NativeFruit{Cell=at,Kind=kind});last=kind;
    }
    Check(seen.Count==10,"complete ten-kind bag");r.sequences++;
   }
   bag.Reset();var fresh=new NativeFruitVariety();Check(bag.Select(level,seed,.33,Vector2Int.zero,empty)==fresh.Select(level,seed,.33,Vector2Int.zero,empty),"new-session bag reset");
  }
  Check(firsts.Count==10,"every kind can be the first fruit");
  {
   var bag=new NativeFruitVariety();int previous=0;for(int i=0;i<10;i++)previous=bag.Select(1,5,.2,new Vector2Int(i,1),empty);
   var nearby=new List<NativeFruit>{new NativeFruit{Kind=previous,Cell=new Vector2Int(5,1)}};
   Check(bag.Select(1,5,.4,new Vector2Int(6,1),nearby)!=previous,"prefer another kind beside an existing fruit");
   var crowded=new List<NativeFruit>();for(int i=0;i<9;i++)crowded.Add(new NativeFruit{Kind=i,Cell=new Vector2Int(i*4,10)});
   Check(new NativeFruitVariety().Select(1,5,.4,new Vector2Int(1,1),crowded)==9,"prefer missing kind over already present kinds");
  }
  string[] grid={new string('#',100),"#"+new string('.',98)+"#",new string('#',100)};
  foreach(int mode in NativeMenuState.Modes)foreach(double difficulty in NativeMazeGenerator.Difficulties)foreach(double speed in NativeMenuState.Speeds){
   var w=new NativeGameplayWorld(grid,()=>.5){SessionEnabled=true,Time=1000,Difficulty=difficulty,ScoreSpeed=speed};w.SetMode(mode);var events=new List<NativeWorldEvent>();w.Event=e=>events.Add(e);
   for(int slot=0;slot<w.PlayerCount;slot++)using(w.ForPlayer(w.GetPlayer(slot)))for(int kind=0;kind<10;kind++){
    var p=w.Player;p.Cell=p.From=new Vector2Int(3,1);p.Score=0;p.ExactScore=0;p.PowerUntil=0;p.NextLifeScore=5000;events.Clear();
    w.Fruits.Add(new NativeFruit{Kind=kind,Cell=p.Cell});w.CollectFruit();int expected=(int)(Math.Floor((200*difficulty*speed+1e-9)/5)*5);
    Check(p.Score==expected&&Math.Abs(p.ExactScore-200*difficulty*speed)<1e-7,"same 200 base points through existing coefficients for every kind and slot");
    Check(w.Fruits.Count==0&&w.Power&&p.PowerUntil==w.Time+7000&&p.RampDuration==1000,"collection/removal and unchanged Power timing");
    Check(events.Count(e=>e.Kind=="sound"&&e.Sound=="snakeSTART@")==1&&events.Any(e=>e.Kind=="fruit"&&e.Index==kind),"pickup sound, Power sound and correct type event");r.collections++;
   }
  }
  {
   int calls=0;var w=new NativeGameplayWorld(grid,()=>{calls++;return .4;}){LifecycleEnabled=true};var s=w.PlaceScorpion(new Vector2Int(90,1),Vector2Int.right);s.NextEgg=double.PositiveInfinity;
   var seen=new HashSet<int>();for(int i=0;i<10;i++){
    s.NextFruit=w.Time;int before=calls;w.QueueScorpionDrops(new Vector2Int(2+i*2,1),true);Check(calls-before==2,"one appearance roll and original next-fruit schedule roll");before=calls;w.ReleaseDrops();Check(calls==before,"variety never advances AI RNG");Check(seen.Add(w.Fruits.Last().Kind),"actual scorpion drop pipeline covers distinct kinds");
   }Check(seen.Count==10,"scorpion can drop every new fruit");
   var actual=new NativeGameplayWorld(grid,()=>.4);var control=new NativeGameplayWorld(grid,()=>.4);
   actual.Fruits.Add(new NativeFruit{Cell=new Vector2Int(2,1),Kind=3});actual.PendingDrops.Add(new NativeDrop{Cell=new Vector2Int(2,1),ChooseFruit=true,AppearanceRoll=.7});actual.ReleaseDrops();actual.Fruits.Clear();
   for(int i=0;i<10;i++){
    foreach(var test in new[]{actual,control}){test.PendingDrops.Add(new NativeDrop{Cell=new Vector2Int(2+i*2,1),ChooseFruit=true,AppearanceRoll=.3});test.ReleaseDrops();}
    Check(actual.Fruits.Last().Kind==control.Fruits.Last().Kind,"blocked spawn does not consume a variety choice");
   }
  }
  var combo=NativeComboValidation.Run();r.comboChecks=combo.assertions;Check(combo.passed,"combo regression: "+string.Join("; ",combo.checks.Where(c=>!c.passed).Select(c=>c.name)));
  r.passed=true;string folder=Path.GetFullPath(Path.Combine(Application.dataPath,"../../Results/fruit-expansion"));Directory.CreateDirectory(folder);File.WriteAllText(Path.Combine(folder,"logic.json"),JsonUtility.ToJson(r,true));Debug.Log("FRUIT_EXPANSION_CHECKS "+r.checks+" collections="+r.collections+" combo="+r.comboChecks);
 }
 public static void Build(){Validate();StudyBuild.Build();}
}

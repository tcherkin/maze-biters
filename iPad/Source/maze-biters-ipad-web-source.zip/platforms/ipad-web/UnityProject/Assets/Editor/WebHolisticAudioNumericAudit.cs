using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using MazeBiters.NativeStudy;
using UnityEditor;
using UnityEngine;
using Debug=UnityEngine.Debug;
public static class WebHolisticAudioNumericAudit {
 [Serializable] public sealed class Bench {public bool muted;public int voices,buffers,samples;public double referenceMs,optimizedMs;}
 [Serializable] public sealed class Report {
  public bool passed;public int checks,failures,scenarios,buffers,pcmSamples;public double elapsedMs;
  public string scope="Native SFX mixer exact comparison against retained original arithmetic. Deterministic finite mono/stereo PCM fixtures exercise all six voice groups, panning branches, admission/rejection/eviction, clip endings, muted/unmuted output, output channel counts1/2/4, rates22050/44100/48000, mid-stream rate reconfiguration, original silent warmup/reset, compressor release through silence and32-voice microbenchmarks. No audio device is started; editor timing is diagnostic, not device performance.";
  public List<string> issues=new List<string>();public List<Bench> benchmarks=new List<Bench>();
 }
 static readonly string[] Names={"TieAudit","EatFruitAudit","Tick","EggKnock","HeadEat","OtherAudit"};
 static void Check(Report r,bool ok,string label){r.checks++;if(ok)return;r.failures++;if(r.issues.Count<80)r.issues.Add(label);}
 static NativeSessionAudio.HolisticClip[] Sources(int frames=1536,int frequency=44100){
  var mono=new float[frames];var stereo=new float[frames*2];for(int i=0;i<frames;i++){mono[i]=(float)(.72*Math.Sin(i*.073)+.11*Math.Cos(i*.031));stereo[i*2]=(float)(.61*Math.Sin(i*.053)+.19*Math.Cos(i*.017));stereo[i*2+1]=(float)(.57*Math.Cos(i*.067)-.21*Math.Sin(i*.023));}
  var clips=new NativeSessionAudio.HolisticClip[Names.Length];for(int i=0;i<clips.Length;i++)clips[i]=new NativeSessionAudio.HolisticClip{name=Names[i],samples=i%2==0?mono:stereo,channels=i%2==0?1:2,rate=frequency};return clips;
 }
 static bool Same(float[] a,float[] b,byte[] first,byte[] second){Buffer.BlockCopy(a,0,first,0,first.Length);Buffer.BlockCopy(b,0,second,0,second.Length);for(int i=0;i<first.Length;i++)if(first[i]!=second[i])return false;return true;}
 static void Pair(Report report,int sampleRate,int channels,bool muted){
  var first=new GameObject("Reference mixer audit");var second=new GameObject("Cached mixer audit");var a=first.AddComponent<NativeSessionAudio>();var b=second.AddComponent<NativeSessionAudio>();var clips=Sources();a.HolisticConfigure(sampleRate,muted,clips);b.HolisticConfigure(sampleRate,muted,clips);
  string label="rate="+sampleRate+" channels="+channels+" muted="+muted;
  try{
   NativeHolisticTuning.AudioConstants=false;a.HolisticWarm();NativeHolisticTuning.AudioConstants=true;b.HolisticWarm();Check(report,a.HolisticMixerState()==b.HolisticMixerState(),label+" silent warmup restores the exact initial bus state");
   var x=new float[256*channels];var y=new float[x.Length];var xb=new byte[x.Length*4];var yb=new byte[xb.Length];
   for(int chunk=0;chunk<72;chunk++){
    double time=1000+chunk*12;
    if(chunk<36){
     for(int eventIndex=0;eventIndex<3;eventIndex++){
      int group=(chunk+eventIndex)%Names.Length;var cell=new Vector2Int(new[]{0,8,17,18,27,35}[(chunk+eventIndex)%6],1);bool global=(chunk+eventIndex)%7==0;
      NativeHolisticTuning.AudioConstants=false;a.Play(Names[group],cell,global,time);NativeHolisticTuning.AudioConstants=true;b.Play(Names[group],cell,global,time);
     }
     // Saturate the two wide groups, then submit a high-priority voice to
     // exercise exactly the original backward mixing/admission/eviction order.
     if(chunk==4)for(int i=0;i<38;i++){string name=i<19?"TieAudit":"HeadEat";NativeHolisticTuning.AudioConstants=false;a.Play(name,new Vector2Int(i%36,1),false,time);NativeHolisticTuning.AudioConstants=true;b.Play(name,new Vector2Int(i%36,1),false,time);}
    }
    if(chunk==24){int next=sampleRate==48000?22050:48000;a.HolisticChangeRate(next);b.HolisticChangeRate(next);}
    if(chunk==48){a.HolisticChangeRate(sampleRate);b.HolisticChangeRate(sampleRate);}
    for(int i=0;i<x.Length;i++)x[i]=y[i]=.123f;
    NativeHolisticTuning.AudioConstants=false;a.MixForValidation(x,channels);NativeHolisticTuning.AudioConstants=true;b.MixForValidation(y,channels);
    report.buffers++;report.pcmSamples+=x.Length;Check(report,Same(x,y,xb,yb),label+" exact PCM bits chunk="+chunk);Check(report,a.HolisticMixerState()==b.HolisticMixerState(),label+" exact compressor/energy/voice/admission state chunk="+chunk);
   }
   Check(report,a.Accepted==b.Accepted&&a.Rejected==b.Rejected&&a.Rejected>0,label+" admission/rejection exercised without policy change");
   Check(report,a.Voices==0&&b.Voices==0,label+" voices end before the silent release tail finishes");
   // Exercise the real bus reset; no AudioSource was attached or started.
   NativeHolisticTuning.AudioConstants=false;a.ResetBus();NativeHolisticTuning.AudioConstants=true;b.ResetBus();Check(report,a.HolisticMixerState()==b.HolisticMixerState(),label+" reset lifecycle retains exact state");report.scenarios++;
  }finally{UnityEngine.Object.DestroyImmediate(first);UnityEngine.Object.DestroyImmediate(second);}
 }
 static void Bench32(Report report,bool muted){
  var first=new GameObject("Reference32 voice mixer");var second=new GameObject("Cached32 voice mixer");var a=first.AddComponent<NativeSessionAudio>();var b=second.AddComponent<NativeSessionAudio>();var clips=Sources(131072,48000);a.HolisticConfigure(48000,muted,clips);b.HolisticConfigure(48000,muted,clips);
  try{
   for(int i=0;i<32;i++){string name=i<16?"TieAudit":"HeadEat";NativeHolisticTuning.AudioConstants=false;a.Play(name,new Vector2Int(i%36,1),false,1000);NativeHolisticTuning.AudioConstants=true;b.Play(name,new Vector2Int(i%36,1),false,1000);}
   Check(report,a.Voices==32&&b.Voices==32,"known32 voices before benchmark muted="+muted);var x=new float[512];var y=new float[512];var xb=new byte[x.Length*4];var yb=new byte[xb.Length];
   for(int i=0;i<4;i++){NativeHolisticTuning.AudioConstants=false;a.MixForValidation(x,2);NativeHolisticTuning.AudioConstants=true;b.MixForValidation(y,2);}
   var row=new Bench{muted=muted,voices=32,buffers=320,samples=x.Length};var timer=Stopwatch.StartNew();NativeHolisticTuning.AudioConstants=false;for(int i=0;i<row.buffers;i++)a.MixForValidation(x,2);timer.Stop();row.referenceMs=timer.Elapsed.TotalMilliseconds;
   timer.Restart();NativeHolisticTuning.AudioConstants=true;for(int i=0;i<row.buffers;i++)b.MixForValidation(y,2);timer.Stop();row.optimizedMs=timer.Elapsed.TotalMilliseconds;report.benchmarks.Add(row);
   Check(report,a.Voices==32&&b.Voices==32,"all32 voices remain active throughout benchmark muted="+muted);Check(report,Same(x,y,xb,yb)&&a.HolisticMixerState()==b.HolisticMixerState(),"benchmark final PCM and complete mixer state exact muted="+muted);
  }finally{UnityEngine.Object.DestroyImmediate(first);UnityEngine.Object.DestroyImmediate(second);}
 }
 [MenuItem("Maze Biters/Web/Validate exact audio constant reuse")]
 public static void Run(){
  var report=new Report();var timer=Stopwatch.StartNew();bool old=NativeHolisticTuning.AudioConstants;
  try{foreach(int rate in new[]{22050,44100,48000})foreach(int channels in new[]{1,2,4})foreach(bool muted in new[]{false,true})Pair(report,rate,channels,muted);Bench32(report,false);Bench32(report,true);}
  finally{NativeHolisticTuning.AudioConstants=old;timer.Stop();report.elapsedMs=timer.Elapsed.TotalMilliseconds;report.passed=report.failures==0;string directory=Path.GetFullPath(Path.Combine(Application.dataPath,"../../Results/holistic-optimization"));Directory.CreateDirectory(directory);File.WriteAllText(Path.Combine(directory,"audio-audit.json"),JsonUtility.ToJson(report,true));}
  Debug.Log("WEB_HOLISTIC_AUDIO passed="+report.passed+" scenarios="+report.scenarios+" buffers="+report.buffers+" samples="+report.pcmSamples+" checks="+report.checks);foreach(string issue in report.issues)Debug.LogError("WEB_HOLISTIC_AUDIO_FAILURE "+issue);if(!report.passed)throw new InvalidOperationException("Native audio exact-work audit failed");
 }
}

using UnityEditor;using UnityEngine;
public sealed class SessionAudioImport:AssetPostprocessor {
 void OnPreprocessAudio(){if(!assetPath.StartsWith("Assets/Resources/SessionAudio/"))return;var importer=(AudioImporter)assetImporter;var s=importer.defaultSampleSettings;s.loadType=assetPath.EndsWith(".mp3")?AudioClipLoadType.Streaming:AudioClipLoadType.DecompressOnLoad;s.compressionFormat=assetPath.EndsWith(".mp3")?AudioCompressionFormat.Vorbis:AudioCompressionFormat.PCM;s.sampleRateSetting=AudioSampleRateSetting.PreserveSampleRate;s.quality=1;importer.defaultSampleSettings=s;importer.forceToMono=false;importer.loadInBackground=false;}
}

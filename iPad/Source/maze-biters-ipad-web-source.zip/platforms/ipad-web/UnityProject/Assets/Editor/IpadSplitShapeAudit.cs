using System;
using System.IO;
using System.Linq;
using System.Collections.Generic;
using UnityEngine;
using MazeBiters.NativeStudy;

public static class IpadSplitShapeAudit {
 [Serializable] public class Frame {public double time,length,tip,head,error;public float[] points;}
 [Serializable] public class Case {public int shape,index,child,turn;public double phase,error;public string motion;public Frame[] frames;public float[] route;}
 [Serializable] public class Report {public int cases,checks;public bool passed;public double maxTailOverrun,maxRecordJump;public Case[] worst;}
 static int checks;static double maxTailOverrun,maxRecordJump;
 static void Check(bool ok,string name){checks++;if(!ok)throw new Exception("SPLIT_SHAPE: "+name);}
 static void Continuous(SnakePose a,SnakePose b,string name){for(int j=0;j<=24;j++){var x=a.rail.Sample(a.Tip+(a.Rear-a.Tip)*j/24);var y=b.rail.Sample(b.Tip+(b.Rear-b.Tip)*j/24);double d=SnakeCurve.Hypot(x.x-y.x,x.y-y.y);maxRecordJump=Math.Max(maxRecordJump,d);Check(d<.001,name+" jump="+d);}}
 public static void Step(NativeGameplaySnake s, Vector2Int d){s.Body.Insert(0,s.Head+d);s.Body.RemoveAt(s.Body.Count-1);s.Dir=d;}
 public static Vector2Int[][] Shapes = {
  new[]{new Vector2Int(12,7),new Vector2Int(11,7),new Vector2Int(10,7),new Vector2Int(9,7),new Vector2Int(8,7),new Vector2Int(7,7),new Vector2Int(6,7)},
  new[]{new Vector2Int(12,7),new Vector2Int(11,7),new Vector2Int(10,7),new Vector2Int(10,8),new Vector2Int(10,9),new Vector2Int(9,9),new Vector2Int(8,9)},
  new[]{new Vector2Int(12,7),new Vector2Int(11,7),new Vector2Int(11,8),new Vector2Int(10,8),new Vector2Int(10,9),new Vector2Int(9,9),new Vector2Int(9,10)},
  new[]{new Vector2Int(12,7),new Vector2Int(11,7),new Vector2Int(10,7),new Vector2Int(9,7),new Vector2Int(9,8),new Vector2Int(9,9),new Vector2Int(10,9)}
 };
 public static void Fixture(int shape,double phase,int index,int child,int turn,out NativeLiveSnake live,out NativeGameplaySnake model,out double at){
  var parent=new NativeGameplaySnake{Body=Shapes[shape].ToList(),Dir=Vector2Int.right};
  var motion=new NativeLiveSnake(parent,1000);var old=parent.Body.ToArray();Step(parent,Vector2Int.right);motion.Record(parent,old,1000,218);at=1000+218*phase;
  var children=NativeGameplayWorld.Fragments(parent,index).Select(x=>new NativeGameplaySnake{Body=x.body,Dir=x.dir}).ToArray();
  live=motion.Split(children,index,parent.Body.Count,at,at+33.25)[child];model=children[child];
  old=model.Body.ToArray();var d=model.Dir;if(turn!=0)d=new Vector2Int(-d.y*turn,d.x*turn);var before=live.Evaluate(at);before.rail=before.rail.Snapshot();Step(model,d);live.Record(model,old,at,218);
  if(model.Body.Count>1)Continuous(before,live.Evaluate(at),"first step after cut");
 }
 public static float[] Points(SnakeCurve path,double a,double b){var p=new List<float>();for(double t=a;t<=b+.001;t+=.5){var q=path.Sample(t);p.Add((float)q.x);p.Add((float)q.y);}return p.ToArray();}
 public static double Error(SnakePose pose,SnakeRail route){double error=0;for(double s=pose.Tip;s<=pose.Rear;s+=.5){var p=pose.rail.Sample(s);var q=route.Sample(route.Project(p.x,p.y,0));error=Math.Max(error,SnakeCurve.Hypot(p.x-q.x,p.y-q.y));}return error;}
 public static void Run(){
  checks=0;maxTailOverrun=maxRecordJump=0;var cases=new List<Case>();
  for(int sh=0;sh<Shapes.Length;sh++)foreach(double ph in new[]{0,.12,.35,.6,.85,1.0})for(int ix=1;ix<6;ix++)for(int ch=0;ch<2;ch++)foreach(int turn in new[]{0,-1,1}){
   Fixture(sh,ph,ix,ch,turn,out var live,out var model,out double at);
   if(model.Body.Count<2)continue;var path=(SnakeRail)live.Path;var frames=new List<Frame>();
   for(int i=0;i<=26;i++){double t=at+218*i/26.0;var p=live.Evaluate(t);maxTailOverrun=Math.Max(maxTailOverrun,-p.Tip);Check(p.Tip>=-1e-6,"tail outside moving split curve");Check(p.length>0&&!double.IsNaN(p.length),"finite positive length");frames.Add(new Frame{time=t-at,length=p.length,tip=p.Tip,head=p.head,error=Error(p,path),points=Points(p.rail,p.Tip,p.Rear)});}
   cases.Add(new Case{shape=sh,phase=ph,index=ix,child=ch,turn=turn,motion=live.Motion.GetType().Name,error=frames.Max(x=>x.error),frames=frames.ToArray(),route=Points(path,0,path.Total)});
   // A new bite during birth must not resurrect the old absolute birth length.
   Fixture(sh,ph,ix,ch,turn,out live,out model,out at);var prior=live.Evaluate(at+65);prior.rail=prior.rail.Clone();int count=model.Body.Count;model.Body.RemoveAt(count-1);live.BiteTail(model,count,at+65,new NativePlayer{Dir=Vector2Int.down});Continuous(prior,live.Evaluate(at+65),"bite during birth");
   for(int i=0;i<40;i++){var p=live.Evaluate(at+65+i*5);Check(!double.IsNaN(p.Tip)&&!double.IsInfinity(p.Tip),"finite after bite");}
   // A second cut freezes the current shape; evaluating one sibling cannot
   // mutate the other, even while the parent's first movement is incomplete.
   Fixture(sh,ph,ix,ch,turn,out live,out model,out at);if(model.Body.Count>=3){var children=NativeGameplayWorld.Fragments(model,1).Select(x=>new NativeGameplaySnake{Body=x.body,Dir=x.dir}).ToArray();var parts=live.Split(children,1,model.Body.Count,at+65,at+98.25);var before=parts[1].Evaluate(at+65);var points=Points(before.rail,before.Tip,before.Rear);live.Evaluate(at+200);parts[0].Evaluate(at+180);var after=parts[1].Evaluate(at+65);Check(points.SequenceEqual(Points(after.rail,after.Tip,after.Rear)),"independent repeated split snapshot");}
  }
  var report=new Report{cases=cases.Count,checks=checks,passed=true,maxTailOverrun=maxTailOverrun,maxRecordJump=maxRecordJump,worst=cases.OrderByDescending(x=>x.error).Take(20).ToArray()};
  var dir=Path.GetFullPath(Path.Combine(Application.dataPath,"../../Results/split-shape"));Directory.CreateDirectory(dir);File.WriteAllText(Path.Combine(dir,"audit.json"),JsonUtility.ToJson(report,true));
  foreach(var c in report.worst.Take(8))Debug.Log("SPLIT_SHAPE "+c.shape+" ph="+c.phase+" cut="+c.index+" child="+c.child+" turn="+c.turn+" "+c.motion+" error="+c.error);
  Debug.Log("SPLIT_SHAPE_PASSED cases="+report.cases+" checks="+checks+" maxRecordJump="+maxRecordJump+" maxTailOverrun="+maxTailOverrun);
 }
 public static void FollowBites(){
  double worst=0;string name="";int frames=0;
  for(int sh=0;sh<Shapes.Length;sh++)foreach(double ph in new[]{.12,.6,1.0})foreach(int ix in new[]{1,2,3,4,5})for(int ch=0;ch<2;ch++)foreach(int turn in new[]{-1,0,1})foreach(double bite in new[]{1.0,20,65,120}){
   Fixture(sh,ph,ix,ch,turn,out var live,out var model,out double at);if(model.Body.Count<3)continue;
   int count=model.Body.Count;model.Body.RemoveAt(count-1);live.BiteTail(model,count,at+bite,new NativePlayer{Dir=Vector2Int.down});
   for(int i=0;i<50;i++){var p=live.Evaluate(at+bite+i*5);frames++;if(-p.Tip>worst){worst=-p.Tip;name="shape="+sh+" phase="+ph+" cut="+ix+" child="+ch+" turn="+turn+" bite="+bite+" t="+(bite+i*5);}}
   var previous=live.Evaluate(at+219);previous.rail=previous.rail.Clone();var old=model.Body.ToArray();Step(model,model.Dir);live.Record(model,old,at+219,218);var now=live.Evaluate(at+219);Continuous(previous,now,"next move sh="+sh+" ph="+ph+" ix="+ix+" ch="+ch+" turn="+turn+" bite="+bite+" before length/head/tip="+previous.length+"/"+previous.head+"/"+previous.Tip+" after="+now.length+"/"+now.head+"/"+now.Tip+" motion="+live.Motion.GetType().Name);
   for(int i=0;i<50;i++){var p=live.Evaluate(at+219+i*5);frames++;if(-p.Tip>worst){worst=-p.Tip;name="next move after bite";}}
  }
  Debug.Log("SPLIT_FOLLOW_BITES frames="+frames+" maxTailOverrun="+worst+" "+name);
  // The unchanged normal two-cell outline keeps up to .15 world units of
  // head/tail allowance around a full 90-degree bend (<1 pixel at 4K).
  Check(worst<.16,"follow-up bite extends curve: "+name);
 }
}

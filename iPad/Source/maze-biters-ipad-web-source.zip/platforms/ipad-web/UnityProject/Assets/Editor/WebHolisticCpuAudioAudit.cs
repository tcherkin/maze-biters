using System;
using System.IO;
using UnityEditor;
using UnityEngine;
public static class WebHolisticCpuAudioAudit {
 [Serializable] sealed class NumericReport {public bool passed;public int checks;}
 [Serializable] sealed class Report {
  public bool passed;public int cpuChecks,audioChecks;public string revision="20261116-holistic-optimization";
  public string scope="Web-project Editor validation of accepted brain-cache, HUD/title and native PCM-fallback changes. Browser SFX continue through the unchanged NativeWebAudio/JavaScript Web Audio bridge; PCM benchmark results do not describe browser Web Audio performance. No external native-project fixtures are required.";
 }
 [MenuItem("Maze Biters/Web/Validate holistic CPU and audio changes")]
 public static void Run(){
  WebHolisticCpuNumericAudit.Run();WebHolisticAudioNumericAudit.Run();string output=Path.GetFullPath(Path.Combine(Application.dataPath,"../../Results/holistic-optimization"));
  var cpu=JsonUtility.FromJson<NumericReport>(File.ReadAllText(Path.Combine(output,"cpu-validation.json")));var audio=JsonUtility.FromJson<NumericReport>(File.ReadAllText(Path.Combine(output,"audio-audit.json")));
  var report=new Report{passed=cpu.passed&&audio.passed,cpuChecks=cpu.checks,audioChecks=audio.checks};File.WriteAllText(Path.Combine(output,"cpu-audio-validation.json"),JsonUtility.ToJson(report,true));
  Debug.Log("WEB_HOLISTIC_CPU_AUDIO passed="+report.passed+" cpuChecks="+report.cpuChecks+" audioChecks="+report.audioChecks);if(!report.passed)throw new InvalidOperationException("Web CPU/audio validation failed");
 }
}

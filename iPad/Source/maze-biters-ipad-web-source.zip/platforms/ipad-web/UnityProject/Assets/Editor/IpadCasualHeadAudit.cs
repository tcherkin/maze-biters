using System;
using System.IO;
using System.Linq;
using UnityEditor;
using UnityEngine;
using MazeBiters.NativeStudy;

public static class IpadCasualHeadAudit {
 [MenuItem("Maze Biters/iPad/Validate incidental safe heads")]
 public static void Run(){
  string directory=Path.GetFullPath(Path.Combine(Application.dataPath,"../../Results/casual-heads"));Directory.CreateDirectory(directory);
  var report=NativeCasualHeadValidation.Run();string path=Path.Combine(directory,"casual-head-report.json");File.WriteAllText(path,JsonUtility.ToJson(report,true));
  Debug.Log("IPAD_CASUAL_HEAD_CHECKS "+report.assertions+" decisions="+report.decisions+" failures="+report.failures+" elapsedMs="+report.elapsedMs.ToString("F1"));
  foreach(var check in report.checks.Where(c=>!c.passed))Debug.LogError("IPAD_CASUAL_HEAD_FAILURE "+check.name+": "+check.detail);
  if(!report.passed)throw new InvalidOperationException("Incidental head validation failed "+report.failures+" checks. See "+path);
 }
}

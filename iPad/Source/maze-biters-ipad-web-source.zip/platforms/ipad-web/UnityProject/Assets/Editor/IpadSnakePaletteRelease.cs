using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Reflection;
using UnityEngine;
using MazeBiters.NativeStudy;
public static class IpadSnakePaletteRelease {
 [Serializable] public sealed class Report {public bool passed;public int checks,spawnCases,splitCases;public int[] appearances=new int[8];public string[] names;}
 sealed class Rng {public uint state;public int draws;public Rng(uint seed){state=seed;}public double Next(){draws++;unchecked{state+=0x6D2B79F5;uint v=(state^(state>>15))*(1|state);v^=v+(v^(v>>7))*(61|v);return (v^(v>>14))/4294967296.0;}}}
 public static void Validate(){
  var r=new Report{names=NativeSnakePalettes.Names};void Check(bool ok,string text){r.checks++;if(!ok)throw new Exception("SNAKE_PALETTE "+text);}
  Check(r.names.Length==8&&r.names.Distinct().Count()==8,"eight distinct colours");
  var floor=Enumerable.Range(0,25).Select(y=>y==0||y==24?new string('#',36):"#"+new string(' ',34)+"#").ToArray();
  var flags=BindingFlags.Instance|BindingFlags.NonPublic;
  var old=typeof(NativeGameplayWorld).GetMethod("LegacySpawnColors",flags);var expanded=typeof(NativeGameplayWorld).GetMethod("SpawnColors",flags);
  foreach(uint seed in Enumerable.Range(0,80).Select(i=>(uint)i))foreach(int level in new[]{1,3,5,9,20,130})foreach(int count in new[]{4,5,8,9}){
   var a=new Rng(seed);var b=new Rng(seed);var wa=new NativeGameplayWorld(floor,a.Next){Level=level};var wb=new NativeGameplayWorld(floor,b.Next){Level=level};
   var prior=(List<int>)old.Invoke(wa,new object[]{count});var now=(List<int>)expanded.Invoke(wb,new object[]{count});
   // Level one only has four snakes in production; preserve the legacy count
   // when intentionally exercising its shorter opening list here.
   Check(now.Count==prior.Count&&a.state==b.state&&a.draws==b.draws,"appearance consumes no additional gameplay RNG");
   Check(now.SequenceEqual(NativeSnakePalettes.Expand(prior,level)),"reordered preload deterministic");
   Check(now.All(c=>c>=0&&c<8)&&now.Take(8).Distinct().Count()==Math.Min(now.Count,8),"balanced bag has no early repeats");
   for(int i=1;i<now.Count;i++)Check(now[i]!=now[i-1],"adjacent duplicate colour");foreach(int c in now)r.appearances[c]++;
  }
  Check(r.appearances.All(v=>v>0),"all palettes spawn");
  foreach(uint seed in new uint[]{34,117})foreach(int mode in NativeMenuState.Modes){
   var rng=new Rng(seed);var scene=new NativeMazeGenerator(34).Generate(1);var w=new NativeGameplayWorld(scene.geometry,rng.Next);w.SetMode(mode);w.StartSession(_=>scene);
   Check(w.Snakes.Count==4&&w.Snakes.Select(s=>s.Palette).Distinct().Count()==4,"first-level shared menu snake pool");
   var expected=NativeSnakePalettes.Expand((List<int>)old.Invoke(new NativeGameplayWorld(floor,new Rng(0).Next){Level=1},new object[]{4}),1);
   foreach(var s in w.Snakes){Check(s.Palette>=0&&s.Palette<8,"live spawn palette");Check(s.Body.Count>=7&&s.Body.All(w.Floor),"live spawn geometry preserved");}
   r.spawnCases++;
  }
  for(int palette=0;palette<8;palette++){
   Check(NativeSnakePalettes.BiteNames[NativeSnakePalettes.BiteSlot(palette)]==r.names[palette],"dust follows snake colour");
   Check(NativeSnakePalettes.LightSlot(palette)==(palette<5?palette:palette+6),"no collision with creature light slots");
   var w=new NativeGameplayWorld(floor,()=>.4);w.Player.Cell=new Vector2Int(8,8);w.Player.Previous=w.Player.Cell+Vector2Int.down;
   var s=w.AddSnake(Enumerable.Range(4,9).Reverse().Select(x=>new Vector2Int(x,8)),Vector2Int.right,palette);w.Eat(s,4);
   Check(w.Snakes.Count==2&&w.Snakes.All(c=>c.Palette==palette),"both split children inherit colour");r.splitCases++;
  }
  Check(NativeSnakePalettes.BiteNames[5]=="Scorpion"&&NativeSnakePalettes.BiteNames[6]=="Hunter1"&&NativeSnakePalettes.BiteNames[11]=="Player3","legacy non-snake dust slots untouched");
  var root=Path.Combine(WebFiles.Root,"Reference");
  foreach(var name in r.names)foreach(var part in new[]{"mouth","solo","material"})foreach(var treatment in new[]{"lit","emission"})Check(File.Exists(Path.Combine(root,"neon-"+name+"-"+part+"-"+treatment+".native.gz")),"prepacked animation source");
  r.passed=true;string dir=Path.GetFullPath(Path.Combine(Application.dataPath,"../../Results/snake-palettes"));Directory.CreateDirectory(dir);File.WriteAllText(Path.Combine(dir,"logic.json"),JsonUtility.ToJson(r,true));Debug.Log("SNAKE_PALETTE_CHECKS "+r.checks);
 }
}

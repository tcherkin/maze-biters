using System;
using System.IO;
using System.Collections.Generic;
using UnityEngine;
using MazeBiters.NativeStudy;
public static class IpadSnakeGlintAudit {
 [Serializable] public sealed class Cadence {public double aggression,frequencyRatio;public int before,after;}
 [Serializable] public sealed class Report {public bool passed;public int checks,notices,legacyChecks;public Cadence[] cadence;public double minimumRecognitionDelay=double.PositiveInfinity,maximumRecognitionDelay;}
 static NativeGameplayWorld Room(out NativeGameplaySnake snake){
  var w=new NativeGameplayWorld(new[]{"###########","#.........#","#.........#","#.........#","###########"},()=>throw new Exception("Visual cue consumed gameplay RNG"));
  w.Player.Cell=new Vector2Int(8,2);w.Player.Lives=3;
  snake=new NativeGameplaySnake{Id=11,Body=new List<Vector2Int>{new Vector2Int(2,1),new Vector2Int(1,1)},Dir=Vector2Int.down};w.Snakes.Add(snake);return w;
 }
 static void Turn(NativeGameplaySnake s){s.Body[0]=new Vector2Int(2,2);s.Dir=Vector2Int.right;}
 public static void Validate(){
  var report=new Report();void Check(bool ok,string reason){report.checks++;if(!ok)throw new Exception("SNAKE_GLINT "+reason);}
  var cadence=new List<Cadence>();
  foreach(double aggression in new[]{.2,.45,.7,1}){
   var row=new Cadence{aggression=aggression};
   for(uint seed=1;seed<=48;seed++){
    var prior=new NativeAggressionGlint(seed);var next=new NativeSnakeGlint(seed);prior.SetAggression(aggression,0);next.SetAggression(aggression,0);double previous=double.NegativeInfinity;int seen=0;
    for(int t=0;t<=300000;t+=16){prior.Sample(t);double v=next.Sample(t);if(v<0||v>1||double.IsNaN(v))throw new Exception("Invalid pulse envelope");if(next.Events!=seen){Check(next.LastStart-previous>=NativeSnakeGlint.MinimumSpacing,"shared start-to-start spacing");previous=next.LastStart;seen=next.Events;}}
    row.before+=prior.Events;row.after+=next.Events;
   }
   row.frequencyRatio=(double)row.after/row.before;Check(row.frequencyRatio>=1.45&&row.frequencyRatio<=2.05,"requested 1.5–2x cadence at "+aggression+": "+row.frequencyRatio);cadence.Add(row);
  }
  for(uint seed=1;seed<=80;seed++){
   var w=Room(out var snake);var clock=new NativeSnakeGlint(seed);clock.SetAggression(0,0);clock.Observe(w,snake,0);clock.Sample(0);Turn(snake);clock.Observe(w,snake,100);
   double due=clock.NoticeAt,delay=due-100;Check(delay>=1000&&delay<=2000,"recognition delay between one and two seconds");report.minimumRecognitionDelay=Math.Min(report.minimumRecognitionDelay,delay);report.maximumRecognitionDelay=Math.Max(report.maximumRecognitionDelay,delay);
   clock.Sample(due-.01);Check(clock.RecognitionEvents==0,"no premature notice");clock.Observe(w,snake,due);clock.Sample(due);Check(clock.RecognitionEvents==1&&clock.Events==1,"calm snake notices player");
   clock.Sample(due+300);Check(clock.Sample(due+300)>.99,"readable soft crest");clock.Observe(w,snake,due+8000);clock.Sample(due+8000);Check(clock.Events==1,"one notice per turn, no repeating stare");report.notices++;
  }
  {
   var w=Room(out var s);var c=new NativeSnakeGlint(4);c.Observe(w,s,0);Turn(s);c.Observe(w,s,100);double due=c.NoticeAt;w.Player.Cell=new Vector2Int(8,3);c.Observe(w,s,due-10);c.Sample(due+300);Check(c.Events==0,"player leaves tunnel before recognition");
   w.Player.Cell=new Vector2Int(8,2);c.Observe(w,s,due+400);c.Sample(due+2500);Check(c.Events==0,"reappearance without another turn does not retrigger");
  }
  foreach(string reason in new[]{"wall","behind","diagonal","dead","reversing","egg"}){
   var w=Room(out var s);var c=new NativeSnakeGlint(9);c.Observe(w,s,0);Turn(s);
   if(reason=="wall")w.Grid[2]="#....#....#";
   if(reason=="behind")w.Player.Cell=new Vector2Int(1,2);
   if(reason=="diagonal")w.Player.Cell=new Vector2Int(8,3);
   if(reason=="dead")w.Player.Dead=true;
   if(reason=="reversing")s.Reversing=true;
   if(reason=="egg")w.SolidEggs.Add(new Vector2Int(5,2));
   c.Observe(w,s,100);c.Sample(2100);Check(c.RecognitionEvents==0&&double.IsPositiveInfinity(c.NoticeAt),"no false sight through "+reason);
  }
  foreach(int mode in NativeMenuState.Modes){
   var w=Room(out var s);w.SetMode(mode);for(int i=0;i<w.PlayerCount;i++){w.GetPlayer(i).Dead=true;w.GetPlayer(i).Cell=new Vector2Int(8,3);}
   var p=w.GetPlayer(w.PlayerCount-1);p.Dead=false;p.Eliminated=false;p.Lives=3;p.Cell=new Vector2Int(8,2);p.ShieldUntil=999999;
   var c=new NativeSnakeGlint(15);c.Observe(w,s,0);Turn(s);c.Observe(w,s,100);Check(!double.IsPositiveInfinity(c.NoticeAt),"all human/AI slots and protected players are visible in mode "+mode);c.Sample(c.NoticeAt);Check(c.RecognitionEvents==1,"mode notice delivered");
  }
  for(uint seed=1;seed<=48;seed++){
   var w=Room(out var s);var c=new NativeSnakeGlint(seed);c.SetAggression(1,0);c.Observe(w,s,0);Turn(s);c.Observe(w,s,100);double due=c.NoticeAt;
   for(int t=100;t<due;t+=16){c.Observe(w,s,t);c.Sample(t);Check(c.Events==0,"periodic glint cannot steal pending recognition");}
   var copy=c.Copy();copy.Sample(due);Check(c.Events==0&&copy.Events==1,"GPU preflight clock copy is isolated");c.Sample(due);Check(c.Events==1&&c.RecognitionEvents==1,"one unified pulse");
   for(int t=(int)due+1;t<due+1600;t+=16)c.Sample(t);Check(c.Events==1,"no immediate periodic pulse after recognition");
  }
  {
   var w=Room(out var s);var c=new NativeSnakeGlint(18);c.Observe(w,s,0);Turn(s);c.Observe(w,s,100);double due=c.NoticeAt;
   s.Body[0]=new Vector2Int(2,3);s.Dir=Vector2Int.down;c.Observe(w,s,200);c.Sample(due+50);Check(c.Events==0,"rapid turn cancels stale recognition");
  }
  report.legacyChecks=NeonValidation.EyeTests();Check(report.legacyChecks>0,"hunter/scorpion original cadence retained");
  report.cadence=cadence.ToArray();report.passed=true;var folder=Path.GetFullPath(Path.Combine(Application.dataPath,"../../Results/snake-eye-signals"));Directory.CreateDirectory(folder);File.WriteAllText(Path.Combine(folder,"logic.json"),JsonUtility.ToJson(report,true));
  Debug.Log("SNAKE_GLINT_CHECKS "+report.checks+" recognition="+report.notices+" original="+report.legacyChecks);
 }
}

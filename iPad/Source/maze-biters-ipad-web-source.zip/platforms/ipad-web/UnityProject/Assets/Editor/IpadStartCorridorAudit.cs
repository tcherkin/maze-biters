using System;
using System.IO;
using UnityEditor;
using UnityEngine;
using MazeBiters.NativeStudy;
public static class IpadStartCorridorAudit {
 [MenuItem("Maze Biters/iPad/Validate short initial corridors")]
 public static void Run(){
  string directory=Path.GetFullPath(Path.Combine(Application.dataPath,"../../Results/start-corridors"));Directory.CreateDirectory(directory);
  var report=NativeMazeStartAccessValidation.Run();string path=Path.Combine(directory,"validation.json");File.WriteAllText(path,JsonUtility.ToJson(report,true));
  Debug.Log("IPAD_START_CORRIDORS checks="+report.assertions+" generated="+report.generatedCases+" synthetic="+report.syntheticCases+" changed="+report.changedCases+" failures="+report.failures+" elapsedMs="+report.elapsedMs.ToString("F1"));
  foreach(var failure in report.failureDetails)Debug.LogError("IPAD_START_CORRIDOR_FAILURE "+failure);
  if(!report.passed)throw new InvalidOperationException("Start corridor validation failed "+report.failures+" checks. See "+path);
 }
 public static void Build(){Run();IpadSafeStartAudit.Run();StudyBuild.Build();}
}

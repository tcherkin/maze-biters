using System;
using System.IO;
using System.Linq;
using UnityEngine;
using MazeBiters.NativeStudy;

public static class IpadSpeedBalanceAudit {
 [Serializable] sealed class Result {public bool passed;public int checks;public string revision="20261108-speed-life-balance";public string[] speeds=NativeMenuState.SpeedNames;public double[] rates=NativeMenuState.Speeds,multipliers=NativeMenuState.ScoreMultipliers;}
 public static void Run(){
  int checks=0;void Check(bool ok,string what){checks++;if(!ok)throw new Exception("Speed/life balance: "+what);}
  double[] rates={.4,.6,.8,1,1.25,1.6},points={.5,.75,1,1.25,1.5,2};
  int[] first={2500,3750,5000,6250,7500,10000},interval={5000,7500,10000,12500,15000,20000};
  Check(NativeMenuState.Speeds.SequenceEqual(rates)&&NativeMenuState.ScoreMultipliers.SequenceEqual(points),"approved independent movement and point tables");
  var menu=new NativeMenuState();Check(menu.SpeedName=="MEDIUM"&&menu.Rate==.8&&menu.ScoreRate==1,"default is new Medium");
  menu.Focus=9;for(int n=0;n<12;n++){int old=menu.Speed;menu.Activate(n*500);Check(menu.Speed==(old+1)%6,"all six options cycle and wrap");}
  NativeGameplayWorld World(double scale,int mode=1){var w=new NativeGameplayWorld(new[]{"##########","#........#","##########"},()=>.5){ScoreSpeed=scale,SessionEnabled=true,Time=1000,RealTime=1000};w.SetMode(mode);return w;}
  for(int speed=0;speed<6;speed++)foreach(int mode in NativeMenuState.Modes)foreach(double difficulty in NativeMazeGenerator.Difficulties){
   var w=World(points[speed],mode);w.Difficulty=difficulty;
   Check(w.FirstLifeScore==first[speed]&&w.LifeScoreInterval==interval[speed],"life thresholds depend on speed only");
   for(int slot=0;slot<w.PlayerCount;slot++)using(w.ForPlayer(w.GetPlayer(slot))){
    var p=w.Player;Check(p.NextLifeScore==first[speed],"all participants start with their scaled threshold");
    p.Cell=new Vector2Int(3,1);w.Fruits.Add(new NativeFruit{Cell=p.Cell,Kind=0});w.CollectFruit();
    Check(Math.Abs(p.ExactScore-200*points[speed]*difficulty)<1e-8&&p.PowerUntil>w.Time,"fruit award and independent power mode");
    // Small awards below/at exact thresholds, including fractional scoring.
    p.Score=(first[speed]-5);p.ExactScore=first[speed]-points[speed]*difficulty;
    w.Award(1);Check(p.Lives==4&&p.ExtraLives==1&&p.NextLifeScore==first[speed]+interval[speed],"first threshold grants precisely one life");
    p.Score=p.NextLifeScore-5;p.ExactScore=p.NextLifeScore-.01;int next=p.NextLifeScore;
    w.Award(1);Check(p.Lives==5&&p.ExtraLives==2&&p.NextLifeScore==next+interval[speed],"subsequent threshold uses full interval");
    p.Lives=9;p.ExactScore=p.Score=p.NextLifeScore-5;next=p.NextLifeScore;
    w.Award(40);Check(p.Lives==9&&p.NextLifeScore==next+interval[speed],"full-life threshold is consumed");
    p.Lives=8;w.Award(1);Check(p.Lives==8,"no banked life after losing one at the cap");
    w.Award(int.MaxValue);Check(p.Lives==9&&p.NextLifeScore>p.ExactScore,"large combo-sized award remains bounded");
    for(int burst=0;burst<8;burst++)w.Award(int.MaxValue);
    Check(p.Score==NativeGameplayWorld.MaximumScore&&p.NextLifeScore==int.MaxValue,"saturated bonus threshold sentinel");
    p.Lives=8;w.Award(int.MaxValue);Check(p.Lives==8,"score saturation cannot mint endless lives");
   }
   var cached=World(1,mode);cached.ScoreSpeed=points[speed];
   Check(Enumerable.Range(0,cached.PlayerCount).All(i=>cached.GetPlayer(i).NextLifeScore==first[speed]),"late menu speed selection updates all prepared participants");
  }
  foreach(int mode in new[]{2,3,4})foreach(int speed in Enumerable.Range(0,6))foreach(string rule in new[]{"score","shield","power"}){
   var w=World(points[speed],mode);
   for(int a=0;a<w.PlayerCount;a++)for(int b=0;b<w.PlayerCount;b++)if(a!=b){
    var attacker=w.GetPlayer(a);var victim=w.GetPlayer(b);attacker.Dead=victim.Dead=false;attacker.Lives=victim.Lives=3;
    attacker.ShieldUntil=victim.ShieldUntil=attacker.PowerUntil=victim.PowerUntil=0;
    attacker.Score=first[speed]-5;attacker.ExactScore=attacker.Score+.25;victim.Score=rule=="score"?100:attacker.Score+100;
    if(rule=="shield")attacker.ShieldUntil=2000;if(rule=="power")attacker.PowerUntil=2000;
    double before=attacker.ExactScore;int threshold=attacker.NextLifeScore;
    Check(w.EatPlayer(attacker,victim)&&victim.Dead&&victim.Lives==2,"every human/AI pair uses existing contact rules");
    Check(attacker.ExactScore==before&&attacker.Score==first[speed]-5&&attacker.Lives==3&&attacker.NextLifeScore==threshold,"knockout changes neither points nor extra-life progress");
   }
  }
  for(int speed=0;speed<6;speed++){
   var generator=new NativeMazeGenerator(913,1);var level=generator.Generate(1);
   var w=new NativeGameplayWorld(level.geometry,NativeMazeGenerator.Rng(913)){ScoreSpeed=points[speed],Time=1000,RealTime=1000};w.SetMode(4);w.StartSession(generator.Generate);
   for(int i=0;i<w.PlayerCount;i++){var p=w.GetPlayer(i);p.ExactScore=p.Score=first[speed]-5;}
   var preview=w.PreviewNextLevel(generator.Generate(2),NativeMazeGenerator.Rng(27),6000);
   for(int i=0;i<w.PlayerCount;i++){var p=preview.GetPlayer(i);Check(p.Lives==4&&p.NextLifeScore==first[speed]+interval[speed]&&w.GetPlayer(i).Lives==3,"next-level preparation preserves bonus progress without altering the live world");}
  }
  // Existing regression suites also cover contact effects, combos and overflow.
  checks+=NativeVersusValidation.Run()+NativeDuoAiValidation.Run()+NativeMenuValidation.Numeric();
  var combo=NativeComboValidation.Run();Check(combo.passed,"combo speed, score, grace and saturation regressions");checks+=combo.assertions;
  string dir=Path.GetFullPath(Path.Combine(Application.dataPath,"../../Results/speed-life-balance"));Directory.CreateDirectory(dir);
  File.WriteAllText(Path.Combine(dir,"rules.json"),JsonUtility.ToJson(new Result{passed=true,checks=checks},true));
  Debug.Log("IPAD_SPEED_LIFE_BALANCE checks="+checks);
 }
 public static void RenderMenus(){
  string dir=Path.GetFullPath(Path.Combine(Application.dataPath,"../../Results/speed-life-balance"));Directory.CreateDirectory(dir);
  foreach(string quality in new[]{"hd","4k"})using(var menu=new NativeMenuRenderer(quality)){
   var state=new NativeMenuState{Quality=quality,Focus=9};
   for(int i=0;i<NativeMenuState.Speeds.Length;i++){
    state.Speed=i;state.Advance(1000);menu.Render(state,1000);
    var previous=RenderTexture.active;RenderTexture.active=menu.Target;var image=new Texture2D(menu.Target.width,menu.Target.height,TextureFormat.RGBA32,false);
    image.ReadPixels(new Rect(0,0,image.width,image.height),0,0);image.Apply();RenderTexture.active=previous;
    File.WriteAllBytes(Path.Combine(dir,quality+"-"+state.SpeedName+".png"),image.EncodeToPNG());UnityEngine.Object.DestroyImmediate(image);
   }
  }
  Debug.Log("SPEED_MENU_RENDERED HD/4K all six options");
 }
 public static void Build(){Run();RenderMenus();StudyBuild.Build();}
}

using System;
using System.Collections.Generic;
using System.IO;
using System.IO.Compression;
using System.Linq;
using System.Threading.Tasks;
using UnityEngine;
using MazeBiters.NativeStudy;
public static class IpadPaletteRelease {
 [Serializable] public sealed class Report {public bool passed;public int checks,seeds,levelsPerSeed,minimumInterveningLevels=999,materialFiles,geometryChecks;public int[] firstPaletteCounts;public string[] sampleSequence;}
 public static void Validate(){
  var r=new Report{seeds=200,levelsPerSeed=180,firstPaletteCounts=new int[9]};
  void Check(bool ok,string why){r.checks++;if(!ok)throw new Exception("PALETTE_CHECK "+why);}
  Check(NativeMazeGenerator.Themes.Length==9&&NativeMazeGenerator.Hues.Length==9,"nine complete themes");
  var sequences=new HashSet<string>();
  for(uint seed=0;seed<r.seeds;seed++){
   var g=new NativeMazeGenerator(seed);var sequence=Enumerable.Range(1,r.levelsPerSeed).Select(g.ThemeIndex).ToArray();var last=Enumerable.Repeat(-999,9).ToArray();r.firstPaletteCounts[sequence[0]]++;
   sequences.Add(string.Join(",",sequence.Take(18)));
   for(int i=0;i<sequence.Length;i++){
    int color=sequence[i];Check(color>=0&&color<9,"palette index");
    if(last[color]>=0){int between=i-last[color]-1;r.minimumInterveningLevels=Math.Min(r.minimumInterveningLevels,between);Check(between>=NativeMazeGenerator.PaletteRepeatGap,"recent colour repeats across bag boundary");}last[color]=i;
    if(i%9==0)Check(sequence.Skip(i).Take(9).Distinct().Count()==9,"complete bag has each theme exactly once");
   }
   for(int i=sequence.Length-1;i>=0;i-=7)Check(g.ThemeIndex(i+1)==sequence[i],"cancelled/reordered preload changes colour");
   foreach(double difficulty in NativeMazeGenerator.Difficulties)Check(new NativeMazeGenerator(seed,difficulty).ThemeIndex(19)==sequence[18],"difficulty change changes the cached palette");
  }
  Check(sequences.Count==r.seeds,"new sessions share identical shuffled cycles");
  Check(r.firstPaletteCounts.All(n=>n>=5),"every palette can begin a campaign");
  var shared=new NativeMazeGenerator(34);var parallel=new int[180];Parallel.For(0,parallel.Length,i=>parallel[i]=shared.ThemeIndex(parallel.Length-i));
  for(int i=0;i<parallel.Length;i++)Check(parallel[i]==shared.ThemeIndex(parallel.Length-i),"worker palette scheduling race");
  Check(shared.ThemeIndex(0)==shared.ThemeIndex(1)&&shared.ThemeIndex(-1)==shared.ThemeIndex(1),"level clamp");
  int far=shared.ThemeIndex(10000);Check(far>=0&&far<9&&far==new NativeMazeGenerator(34).ThemeIndex(10000),"long campaign deterministic");
  foreach(uint seed in new uint[]{0,34,987,uint.MaxValue})foreach(double difficulty in NativeMazeGenerator.Difficulties)foreach(int level in new[]{1,9,10,18,19,130}){
   var now=new NativeMazeGenerator(seed,difficulty);var prior=new NativeMazeGenerator(seed,difficulty,legacyPaletteOrder:true);var a=now.Generate(level);var b=prior.Generate(level);
   Check(a.geometry.SequenceEqual(b.geometry)&&JsonUtility.ToJson(now.Patterns)==JsonUtility.ToJson(prior.Patterns)&&JsonUtility.ToJson(now.Metrics)==JsonUtility.ToJson(prior.Metrics)&&JsonUtility.ToJson(a.starts)==JsonUtility.ToJson(b.starts),"palette RNG altered gameplay geometry");r.geometryChecks++;
  }
  string source=Path.Combine(WebFiles.Root,"Reference/glass-brushes");
  foreach(string theme in NativeMazeGenerator.Themes)foreach(string q in new[]{"hd","4k"}){
   int size=q=="hd"?80:160;
   foreach(var spec in new[]{("wall.rgba.gz",16*size*size*4),("emission.f32.gz",16*size*size*12),("receiver.r8.gz",16*size*size),("receiver-low.r8.gz",256*16)}){
    using(var file=File.OpenRead(Path.Combine(source,theme,q,spec.Item1)))using(var zip=new GZipStream(file,CompressionMode.Decompress))using(var memory=new MemoryStream()){zip.CopyTo(memory);Check(memory.Length==spec.Item2,"native brush dimensions "+theme+"/"+q+"/"+spec.Item1);}r.materialFiles++;
   }
   Check(new FileInfo(Path.Combine(source,theme,q,"floor-coefficients.f64")).Length==120,"floor coefficients "+theme+"/"+q);r.materialFiles++;
  }
  r.sampleSequence=Enumerable.Range(1,36).Select(n=>NativeMazeGenerator.Themes[shared.ThemeIndex(n)]).ToArray();r.passed=true;
  var folder=Path.GetFullPath(Path.Combine(Application.dataPath,"../../Results/palette-expansion"));Directory.CreateDirectory(folder);File.WriteAllText(Path.Combine(folder,"logic.json"),JsonUtility.ToJson(r,true));
  Debug.Log("NINE_PALETTE_CHECKS "+r.checks+" minIntervening="+r.minimumInterveningLevels+" geometry="+r.geometryChecks);
 }
}

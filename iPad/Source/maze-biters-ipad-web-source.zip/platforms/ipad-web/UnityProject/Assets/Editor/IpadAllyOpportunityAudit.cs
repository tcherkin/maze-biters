using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using UnityEditor;
using UnityEngine;
using MazeBiters.NativeStudy;

// Editor-only gameplay observations. These do not render or benchmark a device.
public static class IpadAllyOpportunityAudit {
 static string DirectoryPath=>Path.GetFullPath(Path.Combine(Application.dataPath,"../../Results/ally-opportunity"));
 [MenuItem("Maze Biters/iPad/Validate practical ally opportunities")]
 public static void Run(){
  Directory.CreateDirectory(DirectoryPath);var report=NativeAllyOpportunityValidation.Run();string path=Path.Combine(DirectoryPath,"opportunity-report.json");File.WriteAllText(path,JsonUtility.ToJson(report,true));
  UnityEngine.Debug.Log("IPAD_ALLY_OPPORTUNITY_CHECKS "+report.assertions+" decisions="+report.decisions+" failures="+report.failures+" elapsedMs="+report.elapsedMs.ToString("F1"));
  foreach(var check in report.checks.Where(c=>!c.passed))UnityEngine.Debug.LogError("IPAD_ALLY_OPPORTUNITY_FAILURE "+check.name+": "+check.detail);
  if(!report.passed)throw new InvalidOperationException("Ally opportunity validation failed "+report.failures+" checks. See "+path);
 }
 [Serializable] public sealed class Count {public string name;public int count;}
 [Serializable] public sealed class Phase {
  public double seconds,stationaryMaxSeconds;public int movementDecisions,movementSteps,reversals,waitingSamples,foodContacts;
 }
 [Serializable] public sealed class CandidateTrace {
  public int snakeId,bodyLength,bodyIndex;public string kind,forecastReason;
  public Vector2Int direction,cell,head,snakeDirection;public double forecastRisk,nextSnakeMoveInMs;
  public bool earlierBodyContact,localMealTarget,committedTarget;
 }
 [Serializable] public sealed class SkipTrace {
  public double seconds;public int level,playerId,lockedSnakeId,localMealSnakeId,localMealBites,directiveTargetId;
  public string thought,directive,forecastReason;public Vector2Int playerCell,incomingDirection,chosenDirection,chosenCell,thoughtTarget;
  public bool selectedAnotherEligibleContact,unselectedEarlierMealHead,mealActive,committedBite,localMealGap;
  public CandidateTrace[] candidates;
 }
 [Serializable] public sealed class Row {
  public string difficulty,mode;public int difficultyIndex,seed,startLevel,endLevel,score,lives,deaths,respawns,steps,reversals,decisions,actorReplacements;
  public int eligibleLocalOpportunitySteps,takenLocalOpportunities,skippedLocalOpportunities,skipsWithFleeDirective,unselectedSafeAdjacentFinalHeads;
  public int tailContacts,splitContacts,headContacts,headsAfterEarlierBodyContact,comboActivations,peakHunters,peakSnakes;
  public double seconds,elapsedMs,rawPoints,maxLevelAgeSeconds,maxIntensity,firstFoodSeconds=-1,firstHeadSeconds=-1,firstComboSeconds=-1;public bool gameOver;
  public Phase initialShield=new Phase(),firstTenSecondsAfterShield=new Phase();
  public Count[] thoughts,reversalThoughts;public string error;
  public List<SkipTrace> opportunitySkips=new List<SkipTrace>();
 }
 [Serializable] public sealed class Report {
  public string label,kind,policy,limitations;public int sessionCount;public double simulationSeconds,elapsedMs;public Row[] sessions;
 }
 sealed class Tracking {
  public readonly Row row;public readonly Dictionary<string,int> thoughts=new Dictionary<string,int>(),reversals=new Dictionary<string,int>();
  readonly HashSet<int> eatenBodies=new HashSet<int>();Vector2Int prior,position;bool seen;double still,firstShieldEnd=-1;bool wasCombo;int trackedLevel=-1;NativePlayer trackedPlayer;
  void TrackLevel(int level){if(trackedLevel==level)return;trackedLevel=level;eatenBodies.Clear();seen=false;still=0;wasCombo=false;}
  void TrackActor(NativePlayer p){if(ReferenceEquals(trackedPlayer,p))return;if(trackedPlayer!=null)row.actorReplacements++;trackedPlayer=p;seen=false;still=0;wasCombo=false;}
  public Tracking(Row row){this.row=row;}
  static void Count(Dictionary<string,int> d,string key){key=string.IsNullOrEmpty(key)?"none":key;d.TryGetValue(key,out int count);d[key]=count+1;}
  Phase CurrentPhase(NativeGameplayWorld w,NativePlayer p,double start){
   if(w.Level!=row.startLevel||w.Time-start>25000)return null;
   if(p.ShieldUntil>w.Time&&firstShieldEnd<0)return row.initialShield;
   if(firstShieldEnd<0)firstShieldEnd=w.Time;
   return w.Time-firstShieldEnd<=10000?row.firstTenSecondsAfterShield:null;
  }
  public void Observe(NativeGameplayWorld w,NativePlayer p,double dt,double start){
   TrackLevel(w.Level);TrackActor(p);
   if(p.Dead||p.Lives<=0||w.Transition){seen=false;still=0;return;}
   var phase=CurrentPhase(w,p,start);if(phase!=null){phase.seconds+=dt/1000;if(p.Waiting)phase.waitingSamples++;}
   if(!seen){prior=position=p.Cell;seen=true;}
   if(position==p.Cell){still+=dt;if(phase!=null)phase.stationaryMaxSeconds=Math.Max(phase.stationaryMaxSeconds,still/1000);}
   else{row.steps++;if(phase!=null)phase.movementSteps++;if(prior==p.Cell){row.reversals++;if(phase!=null)phase.reversals++;Count(reversals,p.Ai?.thought);}prior=position;position=p.Cell;still=0;}
   if(p.Combo.Active&&!wasCombo){row.comboActivations++;if(row.firstComboSeconds<0)row.firstComboSeconds=(w.Time-start)/1000;}wasCombo=p.Combo.Active;
  }
  public void Event(NativeGameplayWorld w,NativePlayer p,NativeWorldEvent e,double start){
   TrackLevel(w.Level);TrackActor(p);
   if(e.Player!=p)return;
   var phase=CurrentPhase(w,p,start);
   if(e.Kind=="death"){row.deaths++;seen=false;}
   if(e.Kind=="respawn"){row.respawns++;seen=false;}
   if(e.Kind=="tail"||e.Kind=="split"||e.Kind=="head"){
    if(row.firstFoodSeconds<0)row.firstFoodSeconds=(w.Time-start)/1000;
    if(phase!=null)phase.foodContacts++;
    if(e.Kind=="tail"){row.tailContacts++;if(e.Snake!=null)eatenBodies.Add(e.Snake.Id);}
    if(e.Kind=="split"){row.splitContacts++;if(e.Created!=null)foreach(var s in e.Created)eatenBodies.Add(s.Id);}
    if(e.Kind=="head"){row.headContacts++;if(row.firstHeadSeconds<0)row.firstHeadSeconds=(w.Time-start)/1000;if(e.Snake!=null&&eatenBodies.Remove(e.Snake.Id))row.headsAfterEarlierBodyContact++;}
   }
   if(e.Kind!="playerTurn"||w.Transition)return;
   row.decisions++;Count(thoughts,p.Ai?.thought);if(phase!=null)phase.movementDecisions++;
   // Inspection runs after the real planner has chosen, before actual contact.
   // It does not consume randomness or alter gameplay actors. A deliberately
   // conservative threshold excludes forecast ambiguity from "eligible".
   var options=SafeLocalOpportunities(w,p,e.OldDirection);
   if(options.Count==0)return;
   row.eligibleLocalOpportunitySteps++;bool selected=options.Any(x=>x.direction==p.Dir);
   if(selected)row.takenLocalOpportunities++;else{row.skippedLocalOpportunities++;if(p.Ai?.directive?.type=="flee")row.skipsWithFleeDirective++;}
   bool skippedHead=options.Any(x=>x.snake.Body.Count==1&&eatenBodies.Contains(x.snake.Id)&&x.direction!=p.Dir);
   if(skippedHead)row.unselectedSafeAdjacentFinalHeads++;
   if(!selected||skippedHead){var state=p.Ai;row.opportunitySkips.Add(new SkipTrace{
    seconds=(w.Time-start)/1000,level=w.Level,playerId=p.Id,playerCell=p.Cell,incomingDirection=e.OldDirection,chosenDirection=p.Dir,chosenCell=p.Cell+p.Dir,
    thought=state?.thought,directive=state?.directive?.type,directiveTargetId=state?.directive?.target?.Id??0,thoughtTarget=state?.thoughtTarget??p.Cell,forecastReason=state?.foresightReason,
    selectedAnotherEligibleContact=selected,unselectedEarlierMealHead=skippedHead,mealActive=state?.mealActive??false,committedBite=state?.bitten??false,
    lockedSnakeId=state?.locked?.Id??0,localMealSnakeId=state?.casualSnake?.Id??0,localMealBites=state?.casualBites??0,localMealGap=state?.casualGap??false,
    candidates=options.Select(x=>new CandidateTrace{snakeId=x.snake.Id,bodyLength=x.snake.Body.Count,bodyIndex=x.snake.Body.IndexOf(p.Cell+x.direction),kind=x.snake.Head==p.Cell+x.direction?"head":x.snake.Tail==p.Cell+x.direction?"tail":"split",
     direction=x.direction,cell=p.Cell+x.direction,head=x.snake.Head,snakeDirection=x.snake.Dir,forecastRisk=x.risk,forecastReason=x.reason,nextSnakeMoveInMs=Math.Max(0,x.snake.LastMove+(x.snake.Reversing?436:218)-w.Time),earlierBodyContact=eatenBodies.Contains(x.snake.Id),localMealTarget=state?.casualSnake==x.snake,committedTarget=state?.locked==x.snake}).ToArray()
   });}
  }
  public void Finish(){row.thoughts=Counts(thoughts);row.reversalThoughts=Counts(reversals);}
 }
 struct Opportunity {public Vector2Int direction;public NativeGameplaySnake snake;public double risk;public string reason;}
 static List<Opportunity> SafeLocalOpportunities(NativeGameplayWorld w,NativePlayer p,Vector2Int incoming){
  var result=new List<Opportunity>();if(!w.CreatureBitesAllowed(p,w.Time))return result;
  foreach(var d in NativeGameplayWorld.Dirs){
   if(d==-incoming)continue;var c=p.Cell+d;if(!w.PlayerCellOpen(p,c)||!w.PlayerRouteSafe(p,c)||w.HunterAt(c)||w.ScorpionAt(c)||w.PlayerAt(c)!=null)continue;
   var contacts=w.Snakes.Where(s=>s.Body.Contains(c)).ToArray();if(contacts.Length!=1)continue;var snake=contacts[0];int at=snake.Body.IndexOf(c);
   if(at==0&&(snake.Body.Count==1?d==-snake.Dir:d!=snake.Dir)&&!w.CreatureAttackPower(p,w.Time))continue;
   var risk=w.Ally.InspectForesight(p,w.Time,d,c);if(risk.lethal||risk.risk>.05)continue;
   result.Add(new Opportunity{direction=d,snake=snake,risk=risk.risk,reason=risk.reason});
  }
  return result;
 }
 static Count[] Counts(Dictionary<string,int> d)=>d.OrderByDescending(p=>p.Value).Select(p=>new Count{name=p.Key,count=p.Value}).ToArray();

 // A consistent synthetic human uses public keyboard input, no invulnerability
 // or privileged mutation. It explores safely and takes nearby body contacts.
 sealed class Explorer {
  readonly Dictionary<int,int> visits=new Dictionary<int,int>();int level=-1;Vector2Int last;bool seen;
  public void Plan(NativeGameplayWorld w){var p=w.GetPlayer(0);if(p.IsAI||p.Dead||p.Lives<=0||w.Transition)return;
   if(level!=w.Level){visits.Clear();level=w.Level;seen=false;}if(!seen||last!=p.Cell){int key=w.Index(p.Cell);visits.TryGetValue(key,out int n);visits[key]=n+1;last=p.Cell;seen=true;}
   Vector2Int? direction=null;double best=double.PositiveInfinity;
   foreach(var d in NativeGameplayWorld.Dirs){var c=p.Cell+d;if(!w.PlayerCellOpen(p,c)||!w.PlayerRouteSafe(p,c))continue;bool safe=true;
    if(!w.PlayerProtected(p,w.Time)){
     foreach(var s in w.Snakes)if(c==s.Head?(s.Body.Count==1?d==-s.Dir:d!=s.Dir):!s.Reversing&&c==s.Head+s.Dir)safe=false;
     foreach(var h in w.Hunters)if(c==h.Cell||c==h.Cell+h.Dir)safe=false;
    }
    if(!safe)continue;visits.TryGetValue(w.Index(c),out int count);double rank=count*2+(d==p.Dir?-.2:0)+(d==-p.Dir?.35:0);if(w.Snakes.Any(s=>s.Body.Contains(c)))rank-=2;if(rank<best){best=rank;direction=d;}
   }
   using(w.ForPlayer(p)){w.ClearKeys();p.Pointer=null;p.PointerMomentum=false;if(direction.HasValue)w.Press("opportunity-explorer",direction.Value);else p.Waiting=true;}
  }
 }
 static Row Session(int tier,int mode,int seed,int startLevel,double duration){
  var watch=Stopwatch.StartNew();var row=new Row{difficulty=NativeMazeGenerator.DifficultyNames[tier],difficultyIndex=tier,mode=mode==0?"AI ONLY":"SOLO VS AI",seed=seed,startLevel=startLevel};
  try{
   var generator=new NativeMazeGenerator((uint)seed,NativeMazeGenerator.Difficulties[tier]);var levels=new Dictionary<int,SessionLevel>();
   SessionLevel Load(int number){if(!levels.TryGetValue(number,out var level)){level=generator.Generate(number);levels[number]=level;}return level;}
   var w=new NativeGameplayWorld(Load(1).geometry,NativeMazeGenerator.Rng((uint)(seed+8123))){Difficulty=NativeMazeGenerator.Difficulties[tier],AiDifficulty=tier,Time=1000,RealTime=1000,ScoreSpeed=1,Assist=true};w.SetMode(mode);w.StartSession(Load);
   for(int n=1;n<startLevel;n++)w.AdvanceLevel();
   for(int i=0;i<w.PlayerCount;i++){var player=w.GetPlayer(i);player.Score=0;player.ExactScore=0;player.Lives=3;player.NextLifeScore=5000;player.ExtraLives=0;}
   int aiSlot=w.PlayerCount-1;var tracking=new Tracking(row);var explorer=new Explorer();double start=w.Time;
   // Respawn and level installation replace NativePlayer. Observe the current
   // actor in its stable slot rather than retaining the original object.
   w.Event=e=>tracking.Event(w,w.GetPlayer(aiSlot),e,start);
   while(w.Time-start<duration*1000&&!w.GameOver&&!w.CatalogueFinished){double now=w.Time+10;if(mode==3){using(w.ForPlayer(w.GetPlayer(0)))if(now-w.Player.LastMove>w.PlayerDelay)explorer.Plan(w);}w.RealTime=now;w.Tick(now);tracking.Observe(w,w.GetPlayer(aiSlot),10,start);
    row.maxLevelAgeSeconds=Math.Max(row.maxLevelAgeSeconds,(w.Time-w.LevelStarted)/1000);row.maxIntensity=Math.Max(row.maxIntensity,w.DifficultyProfile.Intensity);row.peakHunters=Math.Max(row.peakHunters,w.Hunters.Count);row.peakSnakes=Math.Max(row.peakSnakes,w.Snakes.Count);
   }
   var p=w.GetPlayer(aiSlot);row.seconds=(w.Time-start)/1000;row.endLevel=w.Level;row.score=p.Score;row.rawPoints=p.ExactScore/w.Difficulty;row.lives=p.Lives;row.gameOver=w.GameOver;tracking.Finish();
  }catch(Exception e){row.error=e.ToString();UnityEngine.Debug.LogError("IPAD_ALLY_SESSION_FAILURE "+row.difficulty+" "+row.mode+" seed="+seed+" "+e);}
  row.elapsedMs=watch.Elapsed.TotalMilliseconds;return row;
 }
 static void WriteSessions(string name,IEnumerable<(int tier,int mode,int seed,int level)> cases,double duration){
  Directory.CreateDirectory(DirectoryPath);var watch=Stopwatch.StartNew();var rows=new List<Row>();
  foreach(var item in cases){var row=Session(item.tier,item.mode,item.seed,item.level,duration);rows.Add(row);UnityEngine.Debug.Log("IPAD_ALLY_OPPORTUNITY_SESSION "+row.difficulty+" "+row.mode+" seed="+row.seed+" level="+row.startLevel+" seconds="+row.seconds+" heads="+row.headContacts+" combo="+row.comboActivations+" opportunities="+row.takenLocalOpportunities+"/"+row.eligibleLocalOpportunitySteps+" reversals="+row.reversals);}
  string label=Environment.GetEnvironmentVariable("IPAD_ALLY_SESSION_LABEL")??"current";label=new string(label.Where(c=>char.IsLetterOrDigit(c)||c=='-'||c=='_').ToArray());if(label.Length==0)label="current";
  var report=new Report{label=label,kind="Deterministic native gameplay simulation with genuine AI, movement, enemies, contacts, respawn and level lifecycle",policy="Medium game speed. AI ONLY uses the real ally. SOLO VS AI uses the same ally and a fixed cautious explorer driven by public keyboard input. Three normal lives; no invulnerability. Each generated level and random stream uses a recorded seed. Opportunity observations are made after the planner chooses and require a unique legal non-reverse snake contact with forecast risk at most 0.05. Spawn-shield and first ten post-shield seconds are reported separately.",limitations="These are simulated gameplay observations, not human playtesting or rendered/device performance. Sessions end early at genuine Game Over. Opportunity skips may be legitimate (fleeing, route strategy, target continuity); they are diagnostic counts, not an asserted error rate. Reversals include necessary escapes and dead ends. A session's elapsed time does not imply a single level reached that age; maximum level age and intensity are included. Raw points include ordinary level-clear bonuses. Final-head completion count tracks prior body contacts, including fragments, rather than claiming every meal was continuous.",sessionCount=rows.Count,simulationSeconds=rows.Sum(r=>r.seconds),elapsedMs=watch.Elapsed.TotalMilliseconds,sessions=rows.ToArray()};
  string path=Path.Combine(DirectoryPath,name+"-"+label+".json");File.WriteAllText(path,JsonUtility.ToJson(report,true));UnityEngine.Debug.Log("IPAD_ALLY_OPPORTUNITY_SESSIONS_COMPLETE "+path+" count="+rows.Count+" simulationSeconds="+report.simulationSeconds);
  if(rows.Any(r=>!string.IsNullOrEmpty(r.error)))throw new InvalidOperationException("One or more ally opportunity sessions failed. See "+path);
 }
 [MenuItem("Maze Biters/iPad/Simulate practical ally opportunities")]
 public static void Sessions(){var cases=new List<(int,int,int,int)>();for(int tier=0;tier<5;tier++)foreach(int mode in new[]{0,3})foreach(int level in new[]{1,5})foreach(int seed in new[]{34,107})cases.Add((tier,mode,seed,level));WriteSessions("sessions",cases,180);}
 [MenuItem("Maze Biters/iPad/Inspect ally startup on every difficulty")]
 public static void Startup(){var cases=new List<(int,int,int,int)>();for(int tier=0;tier<5;tier++)foreach(int mode in new[]{0,3})foreach(int level in new[]{1,5})foreach(int seed in new[]{34,107})cases.Add((tier,mode,seed,level));WriteSessions("startup",cases,30);}
}

using System;
using System.IO;
using System.Linq;
using UnityEditor;
using UnityEngine;
using MazeBiters.NativeStudy;

public static class IpadPopulationAudit {
 sealed class Rng {
  public uint state=27;public int draws;
  public double Next(){draws++;unchecked{state+=0x6D2B79F5;uint n=(state^(state>>15))*(1|state);n^=n+(n^(n>>7))*(61|n);return (n^(n>>14))/4294967296.0;}}
  public Rng Copy()=>new Rng{state=state,draws=draws};
 }
 [Serializable] sealed class Result {public bool passed;public int checks;public string scope="Population progression, independent safe-start audit, keyboard parsing, cached level jumps and no test-jump score bonuses.";}
 [MenuItem("Maze Biters/iPad/Validate population and temporary level selection")]
 public static void Run(){
  int checks=0;void Check(bool ok,string text){checks++;if(!ok)throw new Exception("Population / selection: "+text);}
  foreach(var pair in new[]{(1,4),(2,4),(3,5),(11,9),(12,9),(13,10),(17,12),(33,20),(51,29),(100,53),(130,68)})Check(NativeGameplayWorld.DesiredStartingSnakes(pair.Item1)==pair.Item2,"progression at "+pair.Item1);
  Check(NativeGameplayWorld.DesiredStartingSnakes(int.MaxValue)>1000000000,"bounded arithmetic for extreme level");
  var digits=new IpadLevelDigits();
  Check(digits.Digit(0,0)==0&&digits.Digit(0,.2)==100,"00 means 100");
  Check(digits.Digit(9,1)==0&&digits.Digit(9,1.4)==99,"99");
  Check(digits.Digit(0,2)==0&&digits.Digit(1,2.3)==1,"01");
  Check(digits.Digit(7,3)==0&&digits.Confirm()==7,"one digit and Enter");
  Check(digits.Digit(8,4)==0&&digits.Poll(5)==0&&digits.Poll(5.3)==8,"one digit timeout");
  digits.Digit(4,6);digits.Clear();Check(digits.Confirm()==0,"cancel input");
  digits.Digit(0,7);Check(digits.Confirm()==0,"single zero ignored");
  foreach(int mode in Enumerable.Range(0,6))foreach(int target in new[]{13,33,100}){
   var generator=new NativeMazeGenerator(913,1);var first=generator.Generate(1);var next=generator.Generate(target);var random=new Rng();
   var w=new NativeGameplayWorld(first.geometry,random.Next){Difficulty=1,AiDifficulty=2};w.SetMode(mode);w.StartSession(n=>n==1?first:generator.Generate(n));
   w.Player.Score=1230;w.Player.ExactScore=1230;
   Check(!w.RequestTestLevel(0)&&!w.RequestTestLevel(101),"invalid selection rejected");
   Check(w.RequestTestLevel(target)&&w.NextLevelNumber==target&&w.Transition&&w.TestLevelSelectionUsed,"selected target "+mode+"/"+target);
   Check(!w.RequestTestLevel(2),"loading does not accept a second jump");
   var copied=random.Copy();var at=w.TransitionAt+NativeGameplayWorld.ClearDuration;
   var preview=w.PreviewNextLevel(next,copied.Next,at);w.Time=at;w.AdvanceLevel();
   Check(w.Level==target&&w.NextLevelNumber==target+1&&!w.Transition,"actual level and normal continuation");
   Check(w.Player.Score==1230&&preview.Player.Score==1230,"test jump awards no clearance bonus");
   string Shape(NativeGameplayWorld a)=>string.Join(";",a.Snakes.Select(s=>s.Id+":"+s.Palette+":"+string.Join("/",s.Body.Select(c=>c.x+","+c.y))));
   Check(Shape(w)==Shape(preview),"prepared and installed high-level populations identical");
   copied.Next();Check(copied.state==random.state&&copied.draws==random.draws,"identical random sequence after installation");
   Check(w.Snakes.Count<=w.StartingSnakeCapacity&&w.Snakes.Count<=w.RequestedStartingSnakes&&w.Snakes.Count>=9,"capacity limits");
   Check(w.ExtraSpawnSearchNodes<41000,"bounded search work");
  }
  checks+=IpadLightCapacityAudit.Run();
  IpadSafeStartAudit.Run();
  string directory=Path.GetFullPath(Path.Combine(Application.dataPath,"../../Results/snake-population"));Directory.CreateDirectory(directory);
  File.WriteAllText(Path.Combine(directory,"validation.json"),JsonUtility.ToJson(new Result{passed=true,checks=checks},true));
  Debug.Log("IPAD_POPULATION checks="+checks+" passed=true");
 }
}

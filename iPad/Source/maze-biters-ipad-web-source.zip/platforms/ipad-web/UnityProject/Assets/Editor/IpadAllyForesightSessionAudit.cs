using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using UnityEngine;
using MazeBiters.NativeStudy;

// Paired logic sessions, deliberately independent of rendering and device timing.
public static class IpadAllyForesightSessionAudit {
 [Serializable] public sealed class Count {public string name;public int count;}
 [Serializable] public sealed class Actor {public int id,score,lives,deaths,respawns,extraLives,steps,reversals,uniqueCells,tailBites,headBites,splits,hunters,fruits;public double rawActionPoints,aliveSeconds,longestStationarySeconds,firstDeathSeconds=-1;public Count[] thoughts,events;}
 [Serializable] public sealed class Death {public int player,level,x,y;public double seconds;public string reason;}
 [Serializable] public sealed class Row {public string variant,difficulty,mode,stateHash;public bool legacy,gameOver;public int seed,startLevel,endLevel,initialSnakeMass,finalSnakeMass,peakHunters,randomCalls,decisions,anticipationDecisions,maxForecastExpansions;public double durationSeconds,elapsedMs,planningCpuMs,planningMeanMs,planningP50Ms,planningP95Ms,planningP99Ms,planningMaxMs,meanForecastExpansions,maxLevelAgeSeconds,maxIntensity;public Actor ai,human;public Death[] deaths;}
 [Serializable] public sealed class Pair {public string key;public bool control,equivalent;public Row before,after;}
 [Serializable] public sealed class Report {public string kind,policy,limitations,cpu;public bool controlsPassed;public int sessionCount;public double simulationSeconds,elapsedMs;public Pair[] pairs;}
 static string DirectoryPath=>Path.GetFullPath(Path.Combine(Application.dataPath,"../../Results/foresight"));
 static void Add(Dictionary<string,int> d,string key){if(string.IsNullOrEmpty(key))key="none";d.TryGetValue(key,out int n);d[key]=n+1;}
 static Count[] Counts(Dictionary<string,int> d)=>d.OrderByDescending(k=>k.Value).ThenBy(k=>k.Key).Select(k=>new Count{name=k.Key,count=k.Value}).ToArray();
 sealed class Tracking {
  public readonly Actor result;public readonly Dictionary<string,int> events=new Dictionary<string,int>(),thoughts=new Dictionary<string,int>();readonly HashSet<string> cells=new HashSet<string>();Vector2Int position,previous;double stationary;bool observed;
  public Tracking(int id){result=new Actor{id=id};}
  public void Observe(NativeGameplayWorld w,NativePlayer p){
   if(p.Dead||p.Lives<=0||w.Transition){stationary=0;observed=false;return;}result.aliveSeconds+=.01;cells.Add(w.Level+":"+p.Cell.x+":"+p.Cell.y);
   if(!observed){position=previous=p.Cell;observed=true;}if(position==p.Cell){stationary+=.01;result.longestStationarySeconds=Math.Max(result.longestStationarySeconds,stationary);}else{result.steps++;if(previous==p.Cell)result.reversals++;previous=position;position=p.Cell;stationary=0;}
  }
  public Actor Finish(NativeGameplayWorld w,NativePlayer p,int startLevel){result.score=p.Score;result.rawActionPoints=p.ExactScore/w.Difficulty-500*(w.Level-startLevel);result.lives=p.Lives;result.extraLives=p.ExtraLives;result.uniqueCells=cells.Count;result.events=Counts(events);result.thoughts=Counts(thoughts);return result;}
 }
 sealed class Collector {
  readonly Dictionary<int,int> visits=new Dictionary<int,int>();int level=-1;Vector2Int last;bool seen;
  static bool Safe(NativeGameplayWorld w,NativePlayer p,Vector2Int from,Vector2Int to){
   if(!w.PlayerCellOpen(p,to)||!w.PlayerRouteSafe(p,to))return false;if(p.PowerUntil>w.Time||p.ShieldUntil>w.Time)return true;var move=to-from;
   foreach(var s in w.Snakes){if(to==s.Head){if(!(s.Body.Count==1?move!=-s.Dir:move==s.Dir))return false;}else if(!s.Reversing&&to==s.Head+s.Dir)return false;}
   foreach(var h in w.Hunters)if(to==h.Cell||to==h.Cell+h.Dir)return false;return w.Scorpion==null||to!=w.Scorpion.Cell;
  }
  public void Plan(NativeGameplayWorld w){
   var p=w.GetPlayer(0);if(p.IsAI||p.Dead||p.Lives<=0||w.Transition)return;if(level!=w.Level){visits.Clear();level=w.Level;seen=false;}
   if(!seen||last!=p.Cell){int key=w.Index(p.Cell);visits.TryGetValue(key,out int n);visits[key]=n+1;last=p.Cell;seen=true;}
   int count=w.Width*w.Height;var distance=Enumerable.Repeat(-1,count).ToArray();var first=new Vector2Int[count];var queue=new List<Vector2Int>{p.Cell};distance[w.Index(p.Cell)]=0;
   for(int r=0;r<queue.Count;r++){var at=queue[r];foreach(var d in NativeGameplayWorld.Dirs){var next=at+d;if(!w.Floor(next)||distance[w.Index(next)]>=0||!Safe(w,p,at,next))continue;int key=w.Index(next);distance[key]=distance[w.Index(at)]+1;first[key]=at==p.Cell?d:first[w.Index(at)];queue.Add(next);}}
   Vector2Int? best=null;double rank=double.PositiveInfinity;
   void Goal(Vector2Int cell,double bias){if(!w.Floor(cell))return;int key=w.Index(cell),d=distance[key];if(d<=0)return;double value=d+bias+(first[key]==p.Dir?-.1:0);if(value<rank){rank=value;best=first[key];}}
   foreach(var fruit in w.Fruits)Goal(fruit.Cell,-4);foreach(var snake in w.Snakes)Goal(snake.Tail,snake.Body.Count==1?1:0);
   if(!best.HasValue)foreach(var cell in queue){int key=w.Index(cell),d=distance[key];if(d==0)continue;visits.TryGetValue(key,out int n);double score=n*4+d*.15+(first[key]==p.Dir?-.1:0);if(score<rank){rank=score;best=first[key];}}
   using(w.ForPlayer(p)){w.ClearKeys();p.Pointer=null;p.PointerMomentum=false;if(best.HasValue)w.Press("foresight-collector",best.Value);else p.Waiting=true;}
  }
 }
 static void Mix(ref ulong hash,long value){unchecked{hash^=(ulong)value;hash*=1099511628211UL;}}
 static void MixCell(ref ulong hash,Vector2Int c){Mix(ref hash,c.x);Mix(ref hash,c.y);}
 static void SampleState(ref ulong hash,NativeGameplayWorld w,int calls){
  Mix(ref hash,w.Level);Mix(ref hash,calls);for(int i=0;i<w.PlayerCount;i++){var p=w.GetPlayer(i);MixCell(ref hash,p.Cell);MixCell(ref hash,p.Dir);Mix(ref hash,p.Score);Mix(ref hash,p.Lives);Mix(ref hash,p.Dead?1:0);}
  Mix(ref hash,w.Snakes.Count);foreach(var s in w.Snakes){Mix(ref hash,s.Id);MixCell(ref hash,s.Dir);Mix(ref hash,s.Reversing?1:0);foreach(var c in s.Body)MixCell(ref hash,c);}
  Mix(ref hash,w.Hunters.Count);foreach(var h in w.Hunters){Mix(ref hash,h.Id);MixCell(ref hash,h.Cell);MixCell(ref hash,h.Dir);}Mix(ref hash,w.Eggs.Count);foreach(var e in w.Eggs)MixCell(ref hash,e.Cell);Mix(ref hash,w.Fruits.Count);foreach(var f in w.Fruits)MixCell(ref hash,f.Cell);
 }
 static double Percentile(List<double> sorted,double fraction)=>sorted.Count==0?0:sorted[Math.Min(sorted.Count-1,(int)Math.Ceiling(sorted.Count*fraction)-1)];
 static Row Session(int difficulty,int mode,int seed,int startLevel,bool enabled,bool legacy,double seconds){
  var watch=Stopwatch.StartNew();var gen=new NativeMazeGenerator((uint)seed,NativeMazeGenerator.Difficulties[difficulty]);var levels=new Dictionary<int,SessionLevel>();SessionLevel Load(int n){if(!levels.TryGetValue(n,out var l)){l=gen.Generate(n);levels.Add(n,l);}return l;}
  int randomCalls=0;var rng=NativeMazeGenerator.Rng((uint)(seed+8123));double Next(){randomCalls++;return rng();}
  var w=new NativeGameplayWorld(Load(1).geometry,Next){Difficulty=NativeMazeGenerator.Difficulties[difficulty],AiDifficulty=difficulty,Time=1000,RealTime=1000,ScoreSpeed=1,Assist=true,UseLegacyAi=legacy};w.SetMode(mode);w.Ally.DisablePredictivePlanning=!enabled;w.StartSession(Load);
  for(int level=1;level<startLevel;level++)w.AdvanceLevel();for(int i=0;i<w.PlayerCount;i++){var p=w.GetPlayer(i);p.Score=0;p.ExactScore=0;p.Lives=3;p.NextLifeScore=5000;p.ExtraLives=0;}
  var row=new Row{variant=enabled?"foresight":"before",difficulty=NativeMazeGenerator.DifficultyNames[difficulty],mode=mode==0?"AI ONLY":"SOLO VS AI",legacy=legacy,seed=seed,startLevel=startLevel,initialSnakeMass=w.Snakes.Sum(s=>s.Body.Count)};
  int aiSlot=mode==0?0:1;var tracks=Enumerable.Range(0,w.PlayerCount).Select(i=>new Tracking(i+1)).ToArray();var deaths=new List<Death>();var eatenBy=new Dictionary<int,double>();var timing=new List<double>();var collector=new Collector();double start=w.Time;long totalExpanded=0;ulong hash=14695981039346656037UL;int ticks=0;w.MeasureAlly=true;
  w.Event=e=>{if(e.Kind=="playerBite"&&e.Victim!=null)eatenBy[e.Victim.Id]=w.Time;if(e.Player==null)return;var track=tracks[e.Player.Id-1];if(e.Kind!="sound"&&e.Kind!="snakeMove"&&e.Kind!="playerTurn"&&e.Kind!="hunterTurn")Add(track.events,e.Kind);
   if(e.Kind=="tail")track.result.tailBites++;if(e.Kind=="head"||e.Kind=="split"&&e.Index==0)track.result.headBites++;if(e.Kind=="split"&&e.Index>0)track.result.splits++;if(e.Kind=="hunterBite")track.result.hunters++;if(e.Kind=="fruit")track.result.fruits++;if(e.Kind=="respawn")track.result.respawns++;
   if(e.Kind=="death"){track.result.deaths++;double at=(w.Time-start)/1000;if(track.result.firstDeathSeconds<0)track.result.firstDeathSeconds=at;string reason=eatenBy.TryGetValue(e.Player.Id,out double bite)&&bite==w.Time?"competing-player":w.Snakes.Any(s=>s.Head==e.Player.Cell)?"snake-head":w.Hunters.Any(h=>h.Cell==e.Player.Cell)?"hunter":"unclassified-contact";deaths.Add(new Death{player=e.Player.Id,level=w.Level,seconds=at,reason=reason,x=e.Player.Cell.x,y=e.Player.Cell.y});}
  };
  while(w.Time-start<seconds*1000&&!w.GameOver){
   double now=w.Time+10;var human=w.GetPlayer(0);if(!human.IsAI){double delay;using(w.ForPlayer(human))delay=w.PlayerDelay;if(now-human.LastMove>delay)collector.Plan(w);}
   int priorDecisions=w.AllyDecisions;w.RealTime=now;w.Tick(now);for(int i=0;i<w.PlayerCount;i++)tracks[i].Observe(w,w.GetPlayer(i));
   if(w.AllyDecisions>priorDecisions){timing.Add(w.LastAllyMs);var a=w.GetPlayer(aiSlot).Ai;if(a!=null){Add(tracks[aiSlot].thoughts,a.thought);if(a.decisionAt==now&&a.thought!=null&&a.thought.StartsWith("anticipate-",StringComparison.Ordinal))row.anticipationDecisions++;totalExpanded+=a.foresightExpanded;row.maxForecastExpansions=Math.Max(row.maxForecastExpansions,a.foresightExpanded);}}
   row.maxLevelAgeSeconds=Math.Max(row.maxLevelAgeSeconds,(w.Time-w.LevelStarted)/1000);row.maxIntensity=Math.Max(row.maxIntensity,w.DifficultyProfile.Intensity);row.peakHunters=Math.Max(row.peakHunters,w.Hunters.Count);if(++ticks%10==0)SampleState(ref hash,w,randomCalls);
  }
  SampleState(ref hash,w,randomCalls);timing.Sort();row.durationSeconds=(w.Time-start)/1000;row.endLevel=w.Level;row.gameOver=w.GameOver;row.finalSnakeMass=w.Snakes.Sum(s=>s.Body.Count);row.ai=tracks[aiSlot].Finish(w,w.GetPlayer(aiSlot),startLevel);if(mode!=0)row.human=tracks[0].Finish(w,w.GetPlayer(0),startLevel);row.deaths=deaths.ToArray();row.randomCalls=randomCalls;row.stateHash=hash.ToString("X16");row.decisions=w.AllyDecisions;row.planningCpuMs=w.AllyCpuMs;row.planningMeanMs=w.AllyCpuMs/Math.Max(1,w.AllyDecisions);row.planningP50Ms=Percentile(timing,.50);row.planningP95Ms=Percentile(timing,.95);row.planningP99Ms=Percentile(timing,.99);row.planningMaxMs=Percentile(timing,1);row.meanForecastExpansions=(double)totalExpanded/Math.Max(1,w.AllyDecisions);row.elapsedMs=watch.Elapsed.TotalMilliseconds;return row;
 }
 static void RunSeries(bool quick){
  Directory.CreateDirectory(DirectoryPath);var watch=Stopwatch.StartNew();var pairs=new List<Pair>();
  // Exclude first JIT invocation from paired timing while leaving each real session's
  // first cache allocation in the reported cost. Execution order alternates by pair.
  Session(4,0,34,1,false,false,3);Session(4,0,34,1,true,false,3);
  void Save(){var report=new Report{kind="Paired deterministic native iPad gameplay simulation",policy="Only DisablePredictivePlanning differs within each pair; identical seed, generated maze sequence, medium speed, three lives, normal protection/death/respawn/contact rules. SOLO VS AI uses the same independent keyboard collector; AI ONLY is unassisted. Order alternates before/after, after a discarded three-second JIT warmup for each variant.",limitations="Editor logic audit, not an iPad hardware, HD/4K renderer, GPU, RAM or frame-pacing benchmark. Planning times are Stopwatch elapsed time around the actual AI decision on this Windows host and may include GC or scheduling interruptions. Different choices naturally diverge the shared RNG thereafter, so campaign outcomes indicate tendencies, not statistically proven human win rates. Level 5 starts are intentionally staged with three lives and zero score; other gameplay rules remain genuine. Controls compare trajectory and RNG-call hashes, not CPU time.",cpu=SystemInfo.processorType,controlsPassed=pairs.Where(p=>p.control).All(p=>p.equivalent),sessionCount=pairs.Count*2,simulationSeconds=pairs.Sum(p=>p.before.durationSeconds+p.after.durationSeconds),elapsedMs=watch.Elapsed.TotalMilliseconds,pairs=pairs.ToArray()};File.WriteAllText(Path.Combine(DirectoryPath,quick?"paired-sessions-quick.json":"paired-sessions.json"),JsonUtility.ToJson(report,true));}
  void PairRun(int difficulty,int mode,int seed,int startLevel,bool legacy,bool control,double seconds){bool firstEnabled=(pairs.Count&1)!=0;var first=Session(difficulty,mode,seed,startLevel,firstEnabled,legacy,seconds);var second=Session(difficulty,mode,seed,startLevel,!firstEnabled,legacy,seconds);var before=firstEnabled?second:first;var after=firstEnabled?first:second;var pair=new Pair{key=NativeMazeGenerator.DifficultyNames[difficulty]+"/mode"+mode+"/seed"+seed+"/level"+startLevel+(legacy?"/legacy":""),control=control,before=before,after=after,equivalent=before.stateHash==after.stateHash&&before.randomCalls==after.randomCalls};pairs.Add(pair);Save();UnityEngine.Debug.Log("FORESIGHT_SESSION "+pair.key+" before deaths="+before.ai.deaths+" points="+before.ai.rawActionPoints+" meanMs="+before.planningMeanMs+" after deaths="+after.ai.deaths+" points="+after.ai.rawActionPoints+" meanMs="+after.planningMeanMs+" overrides="+after.anticipationDecisions+" control="+control+" equal="+pair.equivalent);if(control&&!pair.equivalent)throw new InvalidOperationException("Foresight changed control "+pair.key);}
  if(quick){PairRun(4,0,34,5,false,false,120);PairRun(4,3,34,1,false,false,120);}
  else {foreach(int mode in new[]{0,3})foreach(int level in new[]{1,5})foreach(int seed in new[]{34,107,1009})PairRun(4,mode,seed,level,false,false,120);for(int difficulty=0;difficulty<4;difficulty++)PairRun(difficulty,3,34,1,false,true,60);PairRun(4,0,34,1,true,true,60);}
  UnityEngine.Debug.Log("FORESIGHT_SESSION_COMPLETE pairs="+pairs.Count+" elapsedMs="+watch.Elapsed.TotalMilliseconds);
 }
 public static void Run()=>RunSeries(false);
 public static void RunQuick()=>RunSeries(true);
}

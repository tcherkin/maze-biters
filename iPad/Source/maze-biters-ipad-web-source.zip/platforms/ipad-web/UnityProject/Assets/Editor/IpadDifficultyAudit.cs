using System;
using System.IO;
using System.Linq;
using UnityEditor;
using UnityEngine;
using MazeBiters.NativeStudy;

public static class IpadDifficultyAudit {
 [MenuItem("Maze Biters/iPad/Validate difficulty behaviour")]
 public static void Validate(){
  IpadTimeDifficultyAudit.Run();
  IpadCasualBiteAudit.Run();
  IpadCasualFinishAudit.Run();
  IpadCasualHeadAudit.Run();
  IpadAllyForesightAudit.Run();
  IpadAllyGradedForesightAudit.Run();
  string directory=Path.GetFullPath(Path.Combine(Application.dataPath,"../../Results/difficulty-rebalance"));
  Directory.CreateDirectory(directory);
  NativeDifficultyReport report=NativeDifficultyValidation.Run();
  File.WriteAllText(Path.Combine(directory,"brain-report.json"),JsonUtility.ToJson(report,true));
  File.WriteAllText(Path.Combine(directory,"audit-notes.txt"),
   "Scope: native iPad Unity gameplay only.\n"+
   "The former enemy model used difficulty as a multiplier for aggression and a timer that eventually raised intelligence to 1 at every setting. Low aggression predominantly produced random movement rather than intelligent evasion.\n"+
   "This report measures real seeded choices at clear junctions, severe injury, ten minutes of level age, and levels 1, 10 and 100. Dedicated fixtures exercise committed pursuit, maze-route distance, all living opponents, short dead ends, dynamic egg obstructions and no living threats.\n"+
   "Broad statistical thresholds intentionally permit gentle and occasional aggression at the easiest setting. The hardest committed pursuit check permits no deliberately inferior route when the shortest choice is unambiguous.\n"+
   "The old native oracle suites compare frozen browser directions and random draws. Those belong to explicit legacy mode; this report checks the revised behaviour without rewriting the browser or its frozen oracle data.\n"+
   "Performance observations: the current board is 36 by 25. Central flow fields should be reused by target/topology, escape search must remain bounded, and AI objective searches should avoid repeated allocation in the simulation loop. The elapsed time here is an editor aggregate, not an iPad frame-time measurement.\n");
  Debug.Log("IPAD_DIFFICULTY_CHECKS "+report.assertions+" decisions="+report.decisions+" failures="+report.failures+" elapsedMs="+report.elapsedMs.ToString("F1"));
  foreach(var failed in report.checks.Where(c=>!c.passed))Debug.LogError("IPAD_DIFFICULTY_FAILURE "+failed.name+": "+failed.detail);
  if(!report.passed)throw new InvalidOperationException("Native difficulty audit failed "+report.failures+" checks. See "+Path.Combine(directory,"brain-report.json"));
 }
 public static void Run(){Validate();Debug.Log("IPAD_ALLY_DIFFICULTY_CHECKS "+NativeAllyDifficultyValidation.Run());}
}

Shader "MazeBiters/SessionImage" {
 Properties {_MainTex("Image",2D)="white"{} _Opacity("Opacity",Float)=1 _Color("Tint",Color)=(1,1,1,1)}
 SubShader {Tags {"Queue"="Transparent"} Cull Off ZWrite Off ZTest Always Blend One OneMinusSrcAlpha
 Pass {CGPROGRAM
 #pragma vertex vert
 #pragma fragment frag
 #include "UnityCG.cginc"
 sampler2D _MainTex;float _Opacity;float4 _Color;
 struct V{float4 p:POSITION;float2 uv:TEXCOORD0;};struct F{float4 p:SV_POSITION;float2 uv:TEXCOORD0;};
 F vert(V v){F f;f.p=UnityObjectToClipPos(v.p);f.uv=v.uv;return f;}
 float4 frag(F f):SV_Target{float4 c=tex2D(_MainTex,f.uv)*_Color;c.a*=_Opacity;c.rgb*=c.a;return c;}
 ENDCG}
 }
}

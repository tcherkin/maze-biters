Shader "MazeBiters/IntakeCardinal" {SubShader {Pass {Cull Off ZWrite Off ZTest Always Blend Off
HLSLPROGRAM
#pragma vertex vert
#pragma fragment frag
#pragma target 3.5
#include "UnityCG.cginc"
UNITY_DECLARE_TEX2DARRAY(_Mask);
float _Frame;
struct V {float4 p:SV_POSITION;float2 uv:TEXCOORD0;};
V vert(appdata_base a){V o;o.p=UnityObjectToClipPos(a.vertex);o.uv=a.texcoord;return o;}
float4 frag(V i):SV_Target {float a=UNITY_SAMPLE_TEX2DARRAY(_Mask,float3(i.uv.x,1-i.uv.y,_Frame)).r;return float4(a,a,a,a);}
ENDHLSL
}}}

Shader "MazeBiters/HunterEye" {Properties {_MainTex("Authored iris",2D)="black"{} _Soft("Soft fringe",2D)="black"{} _Amount("Aggression pulse",Float)=1}
SubShader {Pass {Cull Off ZWrite Off ZTest Always Blend One OneMinusSrcColor
CGPROGRAM
#pragma vertex vert_img
#pragma fragment frag
#include "UnityCG.cginc"
sampler2D _MainTex,_Soft;float _Amount;
float4 frag(v2f_img i):SV_Target {
 float a=tex2D(_MainTex,i.uv).a*_Amount,b=tex2D(_Soft,i.uv).a*_Amount;
 float3 core=float3(1,246.0/255,203.0/255)*a,fringe=float3(220.0/255,234.0/255,1)*b;
 return float4(core+fringe*(1-a),a+b*(1-a));
}
ENDCG
}}}

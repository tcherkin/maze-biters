Shader "MazeBiters/PackedCharacter" {
 Properties { _MainTex("Original open pose",2D)="white"{} _MouthTex("Mouth",2D)="white"{} _Eye0Tex("Eye 0",2D)="white"{} _Eye1Tex("Eye 1",2D)="white"{} }
 SubShader { Tags { "Queue"="Transparent" "RenderType"="Transparent" } Cull Off ZWrite Off ZTest Always
 Blend One OneMinusSrcAlpha
 Pass { CGPROGRAM
 #pragma vertex vert
 #pragma fragment frag
 #pragma target 3.0
 #include "UnityCG.cginc"
 sampler2D _MainTex,_MouthTex,_Eye0Tex,_Eye1Tex;
 float4 _MainTex_TexelSize,_MouthTex_TexelSize,_Eye0Tex_TexelSize,_Eye1Tex_TexelSize;
 float4 _MouthRect,_Eye0Rect,_Eye1Rect;
 float4 _MouthPack,_Eye0Pack,_Eye1Pack; // columns, cellWidth, stride, guard
 float4 _Frames; // mouth, blink, number of eyes, native size
 float4 _Mirrors;
 struct appdata {float4 vertex:POSITION;float2 uv:TEXCOORD0;};
 struct v2f {float4 vertex:SV_POSITION;float2 uv:TEXCOORD0;};
 v2f vert(appdata v){v2f o;o.vertex=UnityObjectToClipPos(v.vertex);o.uv=v.uv;return o;}
 float4 pixel(sampler2D tex,float4 ts,float2 p){return tex2Dlod(tex,float4((p.x+.5)*ts.x,1-(p.y+.5)*ts.y,0,0));}
 bool inside(float2 p,float4 r){return p.x>=r.x&&p.y>=r.y&&p.x<r.x+r.z&&p.y<r.y+r.w;}
 float4 patch(sampler2D tex,float4 ts,float2 p,float4 r,float4 pack,float frame,float mirror){
  float2 local=p-r.xy;if(mirror>.5)local.x=r.z-1-local.x;
  float2 offset=float2(fmod(frame,pack.x)*pack.y,floor(frame/pack.x)*pack.z)+pack.w;
  return pixel(tex,ts,local+offset);
 }
 float4 compose(float2 p){
  // Work in native integer pixels before final bilinear interpolation. This
  // avoids the three horizontal seams caused by independently filtering patches.
  p=clamp(p,0,_Frames.w-1);
  float4 c=pixel(_MainTex,_MainTex_TexelSize,p);
  if(inside(p,_MouthRect))c=patch(_MouthTex,_MouthTex_TexelSize,p,_MouthRect,_MouthPack,_Frames.x,_Mirrors.x);
  if(_Frames.y>0&&_Frames.z>0&&inside(p,_Eye0Rect))c=patch(_Eye0Tex,_Eye0Tex_TexelSize,p,_Eye0Rect,_Eye0Pack,_Frames.y,_Mirrors.y);
  if(_Frames.y>0&&_Frames.z>1&&inside(p,_Eye1Rect))c=patch(_Eye1Tex,_Eye1Tex_TexelSize,p,_Eye1Rect,_Eye1Pack,_Frames.y,_Mirrors.z);
  // Canvas uploads quantize premultiplication BEFORE filtering. Preserve
  // those bytes: tiny source-alpha differences can amplify in turn UV fills.
  c.rgb=floor(c.rgb*c.a*255.0+.5)/255.0;return c;
 }
 float4 frag(v2f i):SV_Target{
  float2 p=float2(i.uv.x,1-i.uv.y)*_Frames.w-.5;
  float2 b=floor(p),f=frac(p);
  return lerp(lerp(compose(b),compose(b+float2(1,0)),f.x),lerp(compose(b+float2(0,1)),compose(b+1),f.x),f.y);
 }
 ENDCG }
 }
}

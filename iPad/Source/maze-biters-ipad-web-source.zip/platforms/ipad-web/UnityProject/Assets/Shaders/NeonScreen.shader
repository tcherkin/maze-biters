Shader "MazeBiters/NeonScreen" {Properties{_MainTex("Light",2D)="black"{} _Amount("Amount",Float)=1}
SubShader {Tags {"Queue"="Transparent"} Cull Off ZWrite Off ZTest Always Blend OneMinusDstColor One Pass {CGPROGRAM
#pragma vertex vert
#pragma fragment frag
#include "UnityCG.cginc"
sampler2D _MainTex;float _Amount;struct I{float4 p:POSITION;float2 uv:TEXCOORD0;};struct O{float4 p:SV_POSITION;float2 uv:TEXCOORD0;};O vert(I i){O o;o.p=UnityObjectToClipPos(i.p);o.uv=i.uv;return o;}float4 frag(O i):SV_Target{return tex2D(_MainTex,i.uv)*_Amount;}
ENDCG }}}

#ifndef MB_POWER_AURA_TINT_INCLUDED
#define MB_POWER_AURA_TINT_INCLUDED
sampler2D _PowerAuraTex;float _PowerAuraEnabled;
float3 powerAuraMaterial(float3 material,float2 uv,float scatter){
 if(_PowerAuraEnabled<.5)return material;
 float4 aura=tex2D(_PowerAuraTex,uv);if(aura.a<=0)return material;
 float weight=saturate(aura.a*3);float3 hue=saturate(aura.rgb/max(aura.a,.001));
 float peak=max(material.r,max(material.g,material.b));
 // Preserve relief and value while white illumination takes the skin's hues.
 return lerp(material,peak*(.10+.90*hue),weight*.78)+aura.rgb*(3*scatter);
}
#endif

Shader "MazeBiters/ExactImage" {
 Properties {_MainTex("Image",2D)="white"{}}
 SubShader {Tags {"Queue"="Geometry"} Cull Off ZWrite Off ZTest Always
 Pass {CGPROGRAM
 #pragma vertex vert
 #pragma fragment frag
 #include "UnityCG.cginc"
 sampler2D _MainTex;
 struct V {float4 p:POSITION;float2 uv:TEXCOORD0;};struct F {float4 p:SV_POSITION;float2 uv:TEXCOORD0;};
 F vert(V v){F f;f.p=UnityObjectToClipPos(v.p);f.uv=v.uv;return f;}
 float4 frag(F f):SV_Target{return tex2D(_MainTex,f.uv);}
 ENDCG}
 }
}

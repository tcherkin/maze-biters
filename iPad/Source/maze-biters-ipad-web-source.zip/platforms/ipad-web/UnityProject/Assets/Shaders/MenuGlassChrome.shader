Shader "MazeBiters/MenuGlassChrome" {
 Properties {
  _MainTex("Original chrome",2D)="white"{}
  _LayerSize("Logical size and position",Vector)=(1024,768,0,0)
  _LogoRect("Original logo only",Vector)=(176,60,664,98)
  _StudyTime("Presentation seconds",Float)=0
  _Glow("Glazing",Float)=.6
  _Champagne("Champagne logo",Float)=0
  _BAccent("Subtle original B jewel accent",Float)=0
  _BContrast("Richer rose and amethyst B",Float)=0
  _BFlow("Moving jewel shades within B",Float)=0
  _Opacity("Original opacity",Float)=1
 }
 SubShader {
  Tags {"Queue"="Transparent" "RenderType"="Transparent"}
  Cull Off ZWrite Off ZTest Always Blend One OneMinusSrcAlpha
  Pass {
   CGPROGRAM
   #pragma vertex vert
   #pragma fragment frag
   #include "UnityCG.cginc"
   sampler2D _MainTex;float4 _LayerSize,_LogoRect;float _StudyTime,_Glow,_Champagne,_Opacity,_BAccent,_BContrast,_BFlow;
   struct V {float4 p:POSITION;float2 uv:TEXCOORD0;};
   struct F {float4 p:SV_POSITION;float2 uv:TEXCOORD0;};
   F vert(V v){F o;o.p=UnityObjectToClipPos(v.p);o.uv=v.uv;return o;}
   float sq(float x){return x*x;}
   float4 frag(F f):SV_Target {
    float4 c=tex2D(_MainTex,f.uv);
    float3 sourceColor=c.rgb;
    float2 logical=float2(f.uv.x,1-f.uv.y)*_LayerSize.xy+_LayerSize.zw;
    float2 p=logical-_LogoRect.xy;
    if(p.x>=0&&p.y>=0&&p.x<_LogoRect.z&&p.y<_LogoRect.w){
     float2 uv=p/_LogoRect.zw;
     float strength=lerp(.45,1,_Glow);
     // Read the carved detail from the source's strongest channel, rather than
     // retaining the old green/gold hue or flattening the letters to one tint.
     // All letters share one sapphire-to-ice material, including the former B.
     float value=max(c.r,max(c.g,c.b));
     float neutral=min(c.r,min(c.g,c.b));
     float body=smoothstep(.09,.48,value);
     float3 azure=lerp(float3(.060,.31,.61),float3(.10,.66,.94),smoothstep(.12,.60,value));
     azure=lerp(azure,float3(.76,.95,1),smoothstep(.63,.99,value));
     float3 glass=pow(max(value,0),.97)*azure;
     // Existing neutral highlights retain their luminosity as pale glass.
     glass=lerp(glass,float3(.84,.96,1)*value,smoothstep(.45,.90,neutral)*.42);
     float yGloss=exp2(-sq((uv.y-.24)/.15));
     float inset=exp2(-sq((uv.y-.71)/.27));
     glass*=1-body*inset*.10*strength;
     glass+=float3(.035,.095,.13)*body*yGloss*strength;
     // A trace of reflected violet on the underside connects the ice-blue
     // lettering with the purple crystal world without recoloring its core.
     glass+=float3(.018,.008,.035)*body*inset*strength;
     float cycle=frac((_StudyTime+2)/14);
     float sweepCentre=lerp(-140,_LogoRect.z+220,saturate(cycle/.57));
     float sweep=exp2(-sq((p.x+p.y*.65-sweepCentre)/24));
     sweep*=1-smoothstep(.54,.60,cycle);
     float narrow=exp2(-sq((p.x+p.y*.65-sweepCentre+7)/4));
     narrow*=1-smoothstep(.54,.60,cycle);
     c.rgb=lerp(glass,float3(.87,.97,1),body*(sweep*.14+narrow*.08)*strength);
     if(_Champagne>.5){
      // Use the same carved values and moving reflection for pale champagne
      // glass: warm recessed channels, cream-gold facets and pearl highlights.
      float3 champagne=lerp(float3(.40,.29,.13),float3(.91,.74,.43),smoothstep(.12,.60,value));
      champagne=lerp(champagne,float3(1,.96,.83),smoothstep(.63,.99,value));
      float3 warmGlass=pow(max(value,0),.97)*champagne;
      warmGlass=lerp(warmGlass,float3(1,.97,.88)*value,smoothstep(.45,.90,neutral)*.42);
      warmGlass*=1-body*inset*.10*strength;
      warmGlass+=float3(.12,.095,.050)*body*yGloss*strength;
      warmGlass+=float3(.022,.009,.028)*body*inset*strength;
      c.rgb=lerp(warmGlass,float3(1,.985,.925),body*(sweep*.14+narrow*.08)*strength);
     }
     if(_BAccent>.5&&logical.x>=449&&logical.x<521){
      // The original B has warm facets and a magenta rim. Isolate that source
      // pigment, not a rectangular tint: neighbouring I glow stays untouched.
      float warm=smoothstep(.015,.10,sourceColor.r-sourceColor.g);
      float rim=smoothstep(.06,.28,min(sourceColor.r,sourceColor.b)-sourceColor.g);
      float blush=smoothstep(.16,.92,uv.y);
      float3 jewel=lerp(float3(.97,.84,.64),float3(.72,.37,.53),blush);
      jewel=lerp(jewel,float3(1,.95,.88),smoothstep(.72,.99,value)*(.30+.34*yGloss));
      float3 accented=pow(max(value,0),.97)*jewel;
      accented=lerp(accented,float3(1,.97,.90)*value,smoothstep(.45,.90,neutral)*.42);
      accented*=1-body*inset*.10*strength;
      accented+=float3(.11,.07,.07)*body*yGloss*strength;
      accented=lerp(accented,float3(1,.97,.93),body*(sweep*.14+narrow*.08)*strength);
      if(_BContrast>.5){
       // The richer option keeps the same engraved values and silhouette.
       // Rose-gold crown, raspberry middle and amethyst lower facets form a
       // distinct jewel; narrow pearl reflections keep the material luminous.
       float3 hue=lerp(float3(1,.66,.64),float3(.83,.27,.56),smoothstep(.12,.55,uv.y));
       hue=lerp(hue,float3(.49,.29,.76),smoothstep(.52,.96,uv.y));
       if(_BFlow>.5){
        // Continuous colour currents stay inside the original carved pigment.
        // Both clocks divide the existing 840-second presentation wrap exactly.
        float bx=saturate((logical.x-449)/72);
        float phase=6.28318530718*_StudyTime/7;
        float drift=sin(6.28318530718*_StudyTime/10+bx*1.7)*.32;
        float current=.5+.5*sin(phase-uv.y*4.2+bx*1.6+drift);
        float3 flowing=lerp(float3(1,.35,.57),float3(.51,.31,.86),current);
        float pearl=pow(.5+.5*sin(phase-uv.y*5.0-bx*.8+1.4),4);
        flowing=lerp(flowing,float3(1,.79,.67),pearl*.44);
        hue=lerp(hue,flowing,.83);
       }
       hue=lerp(hue,float3(1,.90,.88),smoothstep(.78,.99,value)*(.10+.28*yGloss));
       accented=pow(max(value,0),.97)*hue;
       accented=lerp(accented,float3(1,.96,.93)*value,smoothstep(.45,.90,neutral)*.40);
       accented*=1-body*inset*.10*strength;
       accented+=float3(.12,.065,.10)*body*yGloss*strength;
       accented=lerp(accented,float3(1,.95,1),body*(sweep*.14+narrow*.08)*strength);
       if(_BFlow>.5){
        // A quiet 3.5-second breath changes light, never geometry or opacity.
        float breath=.94+.06*(.5-.5*cos(6.28318530718*_StudyTime/3.5));
        accented*=breath;
       }
       c.rgb=lerp(c.rgb,accented,warm*(.76+.16*rim));
      }else c.rgb=lerp(c.rgb,accented,warm*(.42+.22*rim));
     }
    }
    c.a*=_Opacity;c.rgb*=c.a;return c;
   }
   ENDCG
  }
 }
}

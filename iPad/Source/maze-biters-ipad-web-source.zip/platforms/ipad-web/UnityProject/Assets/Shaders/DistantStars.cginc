#ifndef MAZE_BITERS_DISTANT_STARS
#define MAZE_BITERS_DISTANT_STARS
// Shared by the surround and tunnel floor: same field, scale and parallax.
float distantStarHash(float2 p){return frac(sin(dot(p,float2(127.1,311.7)))*43758.5453);}
float3 distantStars(float2 p){
 float2 cell=floor(p/9),local=frac(p/9)*9;float n=distantStarHash(cell);
 float2 centre=2+float2(distantStarHash(cell+31),distantStarHash(cell+73))*5;
 float size=lerp(.32,.66,distantStarHash(cell+19));float d=length(local-centre);
 float edge=max(fwidth(d),.08);float star=(1-smoothstep(size-edge,size+edge,d))*step(.86,n);
 float3 tint=lerp(float3(.13,.34,.30),float3(.26,.20,.42),distantStarHash(cell+53));
 return star*tint;
}
#endif

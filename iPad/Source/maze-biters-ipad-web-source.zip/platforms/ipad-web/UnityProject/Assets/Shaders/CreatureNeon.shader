Shader "MazeBiters/CreatureNeon" {Properties {_MainTex("Native pose",2D)="white"{} _Emission("Emission",Float)=0 _SourceOpacity("Source opacity",Float)=1}
SubShader {Pass {Cull Off ZWrite Off ZTest Always Blend Off
CGPROGRAM
#pragma vertex vert_img
#pragma fragment frag
#include "UnityCG.cginc"
sampler2D _MainTex;float _Emission,_SourceOpacity;
float byteEven(float x){x=clamp(x,0,255);float w=floor(x),f=x-w;return w+(f>.5?1:f<.5?0:fmod(w,2));}
float3 bytesEven(float3 x){return float3(byteEven(x.r),byteEven(x.g),byteEven(x.b))/255;}
float4 writeStraight(float3 rgb,float a){return float4(floor(rgb*a*255+.5)/255,a);}
float4 frag(v2f_img i):SV_Target {
 float4 premul=tex2D(_MainTex,i.uv)*_SourceOpacity;float4 s=floor(float4(premul.rgb/max(premul.a,.00001),premul.a)*255+.5);float high=max(s.r,max(s.g,s.b)),low=min(s.r,min(s.g,s.b));bool coloured=s.a>0&&high>48&&high-low>12;
 if(_Emission>.5){if(!coloured)return 0;float value=high/255,saturation=(high-low)/high,colour=smoothstep(.18,.52,saturation),interior=smoothstep(.22,.55,value),band=smoothstep(.42,.94,value),a=floor(s.a*saturate(.7*colour*interior*(.08+.76*band))+.5);if(a==0)return 0;return writeStraight(bytesEven(255*(.80+.20*value)*s.rgb/high),a/255);}
 if(!coloured)return writeStraight(s.rgb/255,s.a/255);float value=high/255,saturation=(high-low)/high,skin=smoothstep(.13,.45,saturation)*smoothstep(.20,.48,value),newValue=value+(1-value)*.28*.7*skin,core=.16*.7*skin*smoothstep(.48,.93,value);float3 hue=s.rgb/high;return writeStraight(bytesEven(255*newValue*(hue+(1-hue)*core)),s.a/255);
}
ENDCG
}}}

#ifndef MAZE_BITERS_MENU_TRAVEL_STARS
#define MAZE_BITERS_MENU_TRAVEL_STARS

// Four sparse planes in perspective. Their fixed star positions project away
// from the vanishing point as the camera approaches, rather than sliding the
// same flat sky sideways. No textures, particle objects or neighbour loops.
float3 menuStarHash(float2 cell) {
 float3 p=frac(float3(cell.x,cell.y,cell.x)*float3(.1031,.1030,.0973));
 p+=dot(p,p.yxz+33.33);
 return frac((p.xxy+p.yzz)*p.zyx);
}

float3 menuTravelPlane(float2 position,float seconds,float phaseOffset,float seed) {
 float phase=frac(seconds/60.0+phaseOffset);
 float depth=lerp(1.20,.24,phase);
 // The near/far overlap keeps the whole sky present. A plane has zero light
// at both ends of its lifetime, so its recycling never flashes or pops.
 float lifetime=smoothstep(0,.13,phase)*(1-smoothstep(.84,1,phase));
 float2 vanishing=float2(512,384);
 float2 p=(position-vanishing)*(depth/64.0)+float2(seed*13.17,seed*7.91);
 float2 cell=floor(p),local=frac(p);
 float3 h=menuStarHash(cell+seed*31.73);
 float2 centre=.24+.52*h.xy;
 float2 delta=(local-centre)*(64.0/depth);
 float d=length(delta);
 float present=step(.58,h.z);
 float rare=step(.965,h.z);
 float radius=(.36+.31*h.x+.22*rare)/(depth+.28);
 // Derivatives of continuous screen coordinates, never the resetting cell,
// keep HD and 4K edges clean at cell boundaries.
 float aa=max(max(fwidth(position.x),fwidth(position.y))*.72,.16);
 float core=1-smoothstep(max(0,radius-aa),radius+aa,d);
 float halo=exp2(-dot(delta,delta)/(radius*radius*5.5));
 // The kernel reaches exactly zero well before every cell boundary. Even the
// smallest margin is 12.8 screen pixels, while this support is at most 7.2.
 float support=1-smoothstep(radius*2.8+aa,radius*3.7+aa,d);
 float twinkle=.91+.09*sin(seconds*.5235987756+h.y*6.283185307);
 float sparkle=pow(saturate(sin(seconds*.7853981634+h.x*6.283185307)),12)*rare;
 float cross=max(exp2(-abs(delta.x)*5.0-abs(delta.y)*1.05),
                 exp2(-abs(delta.y)*5.0-abs(delta.x)*1.05));
 float intensity=(core*(.23+.46*h.y)+halo*.085+cross*sparkle*.18)*support;
 float3 tint=lerp(float3(.68,.62,1.0),float3(.90,.94,1.0),h.x);
 return tint*intensity*present*lifetime*twinkle;
}

float3 menuTravelStars(float2 logicalPosition,float seconds) {
 // All clocks divide 3,600 seconds, matching the backdrop's seamless rebase.
 float3 sky=menuTravelPlane(logicalPosition,seconds,.071,1);
 sky+=menuTravelPlane(logicalPosition,seconds,.293,3);
 sky+=menuTravelPlane(logicalPosition,seconds,.557,7);
 sky+=menuTravelPlane(logicalPosition,seconds,.823,11);
 return saturate(sky);
}
#endif

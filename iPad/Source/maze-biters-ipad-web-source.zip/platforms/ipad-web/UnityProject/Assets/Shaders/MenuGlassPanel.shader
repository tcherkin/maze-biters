Shader "MazeBiters/MenuGlassPanel" {
 Properties {
  _Dimensions("Face size, padding, radius",Vector)=(422,58,14,14)
  _Focus("Focus glaze",Float)=0
  _Opacity("Opacity",Float)=1
  _Brightness("Ambient brightness",Float)=.55
  _Glow("Rim light",Float)=.6
  _Champagne("Champagne frame",Float)=0
 }
 SubShader {
  Tags {"Queue"="Transparent" "RenderType"="Transparent"}
  Cull Off ZWrite Off ZTest Always Blend One OneMinusSrcAlpha
  Pass {
   CGPROGRAM
   #pragma vertex vert
   #pragma fragment frag
   #pragma target 3.0
   #include "UnityCG.cginc"
   float4 _Dimensions;float _Focus,_Opacity,_Brightness,_Glow,_Champagne;
   struct V {float4 p:POSITION;float2 uv:TEXCOORD0;};
   struct F {float4 p:SV_POSITION;float2 uv:TEXCOORD0;};
   F vert(V v){F o;o.p=UnityObjectToClipPos(v.p);o.uv=v.uv;return o;}
   float sq(float x){return x*x;}
   float roundBox(float2 p,float2 halfSize,float r){float2 q=abs(p)-halfSize+r;return min(max(q.x,q.y),0)+length(max(q,0))-r;}
   float4 frag(F f):SV_Target {
    float2 size=_Dimensions.xy;
    float2 p=float2(f.uv.x,1-f.uv.y)*(size+2*_Dimensions.z)-_Dimensions.z;
    float d=roundBox(p-size*.5,size*.5,_Dimensions.w);
    float aa=max(.32,fwidth(d)*.7);
    float face=1-smoothstep(-aa,aa,d);
    float2 uv=saturate(p/size);
    float top=pow(1-uv.y,3),bottom=pow(uv.y,8);
    float edge=exp2(-abs(d+.65)*2.3)*face;
    float inner=exp2(-abs(d+2.7)*2.1)*face;
    float horizontal=pow(saturate(sin(uv.x*3.14159265)),.6);
    float upperReflection=exp2(-sq((p.y-3.2)/1.05))*horizontal*face;
    float lowerReflection=exp2(-sq((p.y-size.y+3.6)/1.4))*horizontal*face;
    float halo=exp2(-max(d,0)*max(d,0)/30)*smoothstep(-.2,1.1,d);
    float brightness=lerp(.72,1.15,_Brightness);
    float3 baseTint=lerp(float3(.004,.008,.020),float3(.014,.037,.067),top)*brightness;
    baseTint+=float3(.007,.008,.019)*bottom;
    // A broad subdued reflection gives thickness without adding a second frame.
    float veil=exp2(-sq((uv.y-.18-uv.x*.13)/.25));
    baseTint+=float3(.006,.013,.024)*veil;
    float3 edgeTint=lerp(float3(.040,.16,.28),float3(.22,.47,.65),top);
    float3 rgb;float alpha;
    if(_Focus<.5){
     alpha=face*.79+halo*.055*_Glow;
     rgb=baseTint*face*.79+edgeTint*edge*.51;
     rgb+=float3(.055,.18,.31)*inner*.19;
     rgb+=float3(.35,.59,.74)*upperReflection*.27;
     rgb+=float3(.045,.075,.17)*lowerReflection*.35;
     rgb+=float3(.018,.075,.15)*halo*.11*_Glow;
     if(_Champagne>.5){
      // The same rounded glass face, in warm champagne with pearly reflections.
      float3 warmBase=lerp(float3(.012,.009,.005),float3(.050,.036,.016),top)*brightness;
      warmBase+=float3(.017,.011,.012)*bottom;
      warmBase+=float3(.023,.017,.009)*veil;
      float3 warmEdge=lerp(float3(.25,.18,.08),float3(.65,.54,.33),top);
      rgb=warmBase*face*.79+warmEdge*edge*.51;
      rgb+=float3(.29,.22,.12)*inner*.19;
      rgb+=float3(.78,.70,.51)*upperReflection*.27;
      rgb+=float3(.15,.105,.065)*lowerReflection*.35;
      rgb+=float3(.14,.096,.042)*halo*.11*_Glow;
     }
    } else {
     // Only the additional focused light is composited over the existing face.
     float accent=lerp(.68,1,_Glow);
     float focusEdge=exp2(-abs(d+.8)*1.25)*face;
     float focusSheen=exp2(-sq((uv.y-.32)/.36))*horizontal*face;
     float focusHalo=exp2(-max(d,0)*max(d,0)/14)*smoothstep(-.2,1.1,d);
     alpha=face*.28+focusEdge*.29+focusHalo*.09*_Glow;
     rgb=float3(.008,.024,.050)*face;
     rgb+=float3(.040,.135,.24)*focusSheen*.48;
     rgb+=lerp(float3(.12,.49,.79),float3(.70,.93,1),top)*focusEdge*.98*accent;
     rgb+=float3(.11,.38,.62)*inner*.25;
     rgb+=float3(.69,.94,1)*upperReflection*.60*accent;
     rgb+=float3(.08,.32,.52)*lowerReflection*.45;
     rgb+=float3(.026,.15,.27)*focusHalo*.30*_Glow;
     float rail=exp2(-sq(sq((p.x-size.x*.5)/17)))*exp2(-sq((p.y-size.y+4)/.75))*face;
     rgb+=float3(.39,.81,1)*rail*.4*accent;
     if(_Champagne>.5){
      rgb=float3(.032,.023,.011)*face;
      rgb+=float3(.19,.13,.06)*focusSheen*.48;
      rgb+=lerp(float3(.70,.52,.23),float3(1,.95,.79),top)*focusEdge*.98*accent;
      rgb+=float3(.58,.44,.23)*inner*.25;
      rgb+=float3(1,.97,.86)*upperReflection*.60*accent;
      rgb+=float3(.46,.32,.14)*lowerReflection*.45;
      rgb+=float3(.20,.135,.058)*focusHalo*.30*_Glow;
      rgb+=float3(1,.86,.55)*rail*.4*accent;
     }
    }
    return float4(rgb,saturate(alpha))*_Opacity;
   }
   ENDCG
  }
 }
}

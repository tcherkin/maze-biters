Shader "MazeBiters/GlideLanternLight" {
 Properties { _Opacity("Opacity",Float)=1 _Directional("Directional bias",Float)=1 _Direction("Grid-space direction and strength",Vector)=(1,0,0,0) }
 SubShader { Tags { "Queue"="Transparent" "RenderType"="Transparent" } Cull Off ZWrite Off ZTest Always Blend Zero OneMinusSrcAlpha
  Pass {
   CGPROGRAM
   #pragma vertex vert
   #pragma fragment frag
   #include "UnityCG.cginc"
   struct appdata {float4 vertex:POSITION;float2 uv:TEXCOORD0;};
   struct v2f {float4 vertex:SV_POSITION;float2 uv:TEXCOORD0;};
   float _Opacity,_Directional;float4 _Direction;
   v2f vert(appdata v){v2f o;o.vertex=UnityObjectToClipPos(v.vertex);o.uv=v.uv;return o;}
   float4 frag(v2f f):SV_Target {
    // Fixed world-aligned quad. Grid Y points down, unlike its UV Y.
    float2 p=float2((f.uv.x-.5)*448,(.5-f.uv.y)*448);
    float radius=length(p);float2 radial=p/max(radius,.0001);
    float2 direction=_Direction.xy*saturate(_Directional);
    float strength=saturate(length(direction));float along=dot(radial,direction);
    float forward=.5*(strength+along);
    // At zero the directional extension disappears continuously, leaving one
    // softly lit symmetric aura. There is no angle, normalization or side flip.
    float bias=strength>.00001?forward*forward/strength:0;
    float scale=lerp(24,68,bias);
    float transverse=sqrt(1+(1/(.9*.9)-1)*max(0,strength*strength-along*along));
    float u=max(0,radius-12.16)*transverse/scale;
    float light=exp(-u*u)*(1-smoothstep(2.35,3,u));
    return float4(0,0,0,saturate(light*_Opacity));
   }
   ENDCG
  }
 }
}

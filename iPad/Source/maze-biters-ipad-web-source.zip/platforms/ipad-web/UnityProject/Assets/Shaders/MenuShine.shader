Shader "MazeBiters/MenuShine" {
 Properties {_MainTex("Logical glyph mask / effect",2D)="white"{} _Beam("Authored beam",2D)="black"{} }
 CGINCLUDE
 #include "UnityCG.cginc"
 sampler2D _MainTex,_Beam;float4 _MainTex_TexelSize;float _MaskWidth,_Opacity,_ShadowAlpha;int _Count;float _Lefts[32];float4 _Mapping;float2 _Pixel;
 struct V {float4 p:POSITION;float2 uv:TEXCOORD0;};struct F {float4 p:SV_POSITION;float2 uv:TEXCOORD0;};
 F vert(V v){F f;f.p=UnityObjectToClipPos(v.p);f.uv=v.uv;return f;}
 float4 build(v2f_img f):SV_Target{
  float4 beam=0;for(int i=0;i<_Count;i++){float u=(f.uv.x*_MaskWidth-_Lefts[i])/176;if(u>=0&&u<1){float4 b=tex2D(_Beam,float2(u,.5));beam=float4(b.rgb*b.a,b.a)+beam*(1-b.a);}}
  float a=tex2D(_MainTex,f.uv).a;return floor(beam*a*255+.5)/255;
 }
 float4 sampleEffect(float2 uv){if(any(uv<0)||any(uv>1))return 0;return tex2D(_MainTex,uv);}
 float4 display(F f):SV_Target{
  float2 uv=f.uv*_Mapping.xy+_Mapping.zw;
  float4 c=sampleEffect(uv);float a=0;
  // Native-pixel Gaussian shadow, independent of HD/4K layout scaling.
  const float weights[5]={.06136,.24477,.38774,.24477,.06136};
  for(int y=0;y<5;y++)for(int x=0;x<5;x++)a+=sampleEffect(uv+float2(x-2,y-2)*_Pixel*1.5).a*weights[x]*weights[y];
  float3 shadow=float3(115,218,255)/255*a*_ShadowAlpha*_Opacity;
  return float4(1-(1-shadow)*(1-c.rgb*_Opacity),0);
 }
 ENDCG
 SubShader {Cull Off ZWrite Off ZTest Always
 Pass {CGPROGRAM
 #pragma vertex vert_img
 #pragma fragment build
 ENDCG}
 Pass {Blend OneMinusDstColor One, Zero One
 CGPROGRAM
 #pragma vertex vert
 #pragma fragment display
 ENDCG}
 }
}

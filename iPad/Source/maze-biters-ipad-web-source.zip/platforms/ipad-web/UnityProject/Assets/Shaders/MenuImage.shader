Shader "MazeBiters/MenuImage" {
 Properties {_MainTex("Original menu layer",2D)="white"{} _Opacity("Opacity",Float)=1 _UVRect("UV rectangle",Vector)=(0,0,1,1)}
 CGINCLUDE
 #include "UnityCG.cginc"
 sampler2D _MainTex;float _Opacity;float4 _UVRect;
 struct V {float4 p:POSITION;float2 uv:TEXCOORD0;};struct F {float4 p:SV_POSITION;float2 uv:TEXCOORD0;};
 F vert(V v){F f;f.p=UnityObjectToClipPos(v.p);f.uv=_UVRect.xy+v.uv*_UVRect.zw;return f;}
 float4 frag(F f):SV_Target{float4 c=tex2D(_MainTex,f.uv);c.a*=_Opacity;c.rgb*=c.a;return c;}
 ENDCG
 SubShader {Cull Off ZWrite Off ZTest Always
 Pass {Blend One OneMinusSrcAlpha
 CGPROGRAM
 #pragma vertex vert
 #pragma fragment frag
 ENDCG}
 Pass {Blend OneMinusDstColor One, Zero One
 CGPROGRAM
 #pragma vertex vert
 #pragma fragment frag
 ENDCG}
 }
}

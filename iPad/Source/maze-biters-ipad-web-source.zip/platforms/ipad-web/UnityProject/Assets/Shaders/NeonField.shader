// Direct port of the retained WebGL light-batch shader. Original 1x world
// lattice, four clip coverage samples, authored kernels, ordered blending.
Shader "MazeBiters/NeonField" {SubShader {Cull Off ZWrite Off ZTest Always Blend One OneMinusSrcAlpha Pass {CGPROGRAM
#pragma target 3.5
#pragma vertex vert
#pragma fragment frag
#include "UnityCG.cginc"
Texture2D<float4> _Data;sampler2D _Atlas;
struct I{float4 p:POSITION;float2 id:TEXCOORD0;};struct O{float4 p:SV_POSITION;float2 worldPoint:TEXCOORD0;nointerpolation int id:TEXCOORD1;};
O vert(I v){O o;o.p=UnityObjectToClipPos(v.p);o.worldPoint=float2(v.p.x,-v.p.y);o.id=(int)(v.id.x+.5);return o;}
float4 record(int id,int n){
 // WebGL2 texelFetch equivalent: the same full-precision float4 records,
 // without an SSBO/compute requirement. No filtering or color conversion.
 return _Data.Load(int3(n,id,0));
}
float visible(float2 p,float4 h,float4 clip,int count,int id){
 if(p.x<clip.x||p.y<clip.y||p.x>clip.z||p.y>clip.w)return 0;
 float2 delta=p-h.xy;float2 inv=1/float2(abs(delta.x)<1e-20?1e-20:delta.x,abs(delta.y)<1e-20?1e-20:delta.y);
 for(int i=0;i<36;i++){if(i>=count)break;float4 r=record(id,4+i);if(h.x>r.x&&h.x<r.z&&h.y>r.y&&h.y<r.w)return 0;
 float2 a=(r.xy-h.xy)*inv,b=(r.zw-h.xy)*inv;float near=max(min(a.x,b.x),min(a.y,b.y)),far=min(max(a.x,b.x),max(a.y,b.y));if(near<=far&&far>0&&near>=0&&near<1)return 0;}return 1;
}
float4 frag(O i):SV_Target {float4 h=record(i.id,0),atlas=record(i.id,1),clip=record(i.id,2);int count=(int)(record(i.id,3).x+.5);
 float2 uv=atlas.xy+((i.worldPoint-h.xy)/(h.z*2)+.5)*atlas.zw;uv.y=1-uv.y;float4 c=tex2D(_Atlas,uv);
 float a=(visible(i.worldPoint+float2(-.25,-.25),h,clip,count,i.id)+visible(i.worldPoint+float2(.25,-.25),h,clip,count,i.id)+visible(i.worldPoint+float2(-.25,.25),h,clip,count,i.id)+visible(i.worldPoint+float2(.25,.25),h,clip,count,i.id))*.25;return c*(h.w*a);}
ENDCG }}}

Shader "MazeBiters/SnakeSurface" {
 Properties {_MainTex("Original material",2D)="white"{} _Kind("Pass",Float)=0 _Reference("Stencil",Float)=1}
 SubShader {Tags {"Queue"="Transparent"} Cull Off ZWrite Off ZTest Always
 Pass {Stencil {Ref [_Reference] Comp Always Pass Replace} ColorMask 0
 CGPROGRAM
 #pragma vertex vert
 #pragma fragment frag
 #include "UnityCG.cginc"
 struct I {float4 vertex:POSITION;};struct O {float4 vertex:SV_POSITION;};O vert(I i){O o;o.vertex=UnityObjectToClipPos(i.vertex);return o;}float4 frag(O i):SV_Target{return 0;}
 ENDCG }
 Pass {Stencil {Ref [_Reference] Comp Equal Pass Keep} Blend One OneMinusSrcAlpha
 CGPROGRAM
 #pragma vertex vert
 #pragma fragment frag
 #include "UnityCG.cginc"
 sampler2D _MainTex;float _Kind;
 struct I {float4 vertex:POSITION;float2 uv:TEXCOORD0;};struct O {float4 vertex:SV_POSITION;float2 uv:TEXCOORD0;};O vert(I i){O o;o.vertex=UnityObjectToClipPos(i.vertex);o.uv=i.uv;return o;}
 float4 frag(O i):SV_Target{if(_Kind<.5)return float4(16.0/255,19.0/255,16.0/255,1);float4 c=tex2D(_MainTex,i.uv);c.rgb*=c.a;return c;}
 ENDCG }
 Pass {Blend One OneMinusSrcAlpha
 CGPROGRAM
 #pragma vertex vert
 #pragma fragment frag
 #include "UnityCG.cginc"
 sampler2D _MainTex;struct I {float4 p:POSITION;float2 uv:TEXCOORD0;};struct O {float4 p:SV_POSITION;float2 uv:TEXCOORD0;};O vert(I i){O o;o.p=UnityObjectToClipPos(i.p);o.uv=i.uv;return o;}float4 frag(O i):SV_Target{return tex2D(_MainTex,i.uv);}
 ENDCG }
 Pass {Blend One OneMinusSrcAlpha
 CGPROGRAM
 #pragma vertex vert
 #pragma fragment frag
 #include "UnityCG.cginc"
 struct I {float4 p:POSITION;float4 c:COLOR;};struct O {float4 p:SV_POSITION;float a:COLOR;};O vert(I i){O o;o.p=UnityObjectToClipPos(i.p);o.a=i.c.a;return o;}float4 frag(O i):SV_Target{return i.a;}
 ENDCG }
 }
}

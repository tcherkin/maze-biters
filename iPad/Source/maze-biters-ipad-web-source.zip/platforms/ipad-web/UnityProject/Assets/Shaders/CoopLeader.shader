Shader "MazeBiters/CoopLeader" {
 Properties{_MainTex("Source",2D)="black"{} _Outline("Outline",2D)="black"{} _Soft("Soft",2D)="black"{}}
 SubShader {Cull Off ZWrite Off ZTest Always Pass {CGPROGRAM
 #pragma vertex vert_img
 #pragma fragment frag
 #pragma target 3.0
 #include "UnityCG.cginc"
 sampler2D _MainTex,_Outline,_Soft;float _Size,_Padding,_Mode,_Legacy;float4 _Tint,_Rect;
 float4 _Wisp0,_Wisp1,_Source0,_Source1,_StampRect0,_StampRect1;
 float4 wisp(float2 uv,float4 geometry,float4 source,float4 rect){
  float2 local=(uv-geometry.xy)/geometry.z;
  if(any(abs(local)>.5))return 0;
  // Extract only this authored pearl, never another cell or the other wisp.
  float2 stamp=source.xy+local*source.z;
  return tex2D(_MainTex,rect.xy+stamp*rect.zw)*geometry.w;
 }
 float4 art(float2 uv){float2 p=(uv*(_Size+2*_Padding)-_Padding)/_Size;if(any(p<0)||any(p>1))return 0;return tex2D(_MainTex,p);}
 float4 frag(v2f_img i):SV_Target{
  if(_Mode==4||_Mode==5){
   float4 spark;
   if(_Mode==5){float4 a=wisp(i.uv,_Wisp0,_Source0,_StampRect0),b=wisp(i.uv,_Wisp1,_Source1,_StampRect1);spark=b+a*(1-b.a);}
   else spark=tex2D(_MainTex,_Rect.xy+i.uv*_Rect.zw);
   // Keep the authored paths, timing and pearl cores. Lift only the soft glow
   // to retain readability after correcting the old alpha mismatch.
   // 1-(1-a)^3 stays bounded, keeps the white core and fades to zero cleanly.
   if(_Legacy<.5)spark*=3-3*spark.a+spark.a*spark.a;
   return spark;
  }
  float4 c=art(i.uv);
  if(_Mode==0)return c.a;
  if(_Mode==1){float a=c.a,ring=0;int radius=max(1,(int)floor(_Size/80+.5));float product=1;float outer=_Size+2*_Padding;
   for(int y=-2;y<=2;y++)for(int x=-2;x<=2;x++)if(abs(x)<=radius&&abs(y)<=radius&&(x||y))product*=1-art(i.uv+float2(x,y)/outer).a;
   ring=.72*(1-product)*(1-a);float soft=tex2D(_Soft,i.uv).a*.54;float glow=(a*.54+soft*(1-a*.54))*(1-a);float alpha=ring+glow*(1-ring);return float4(_Tint.rgb*alpha,alpha);
  }
  float4 g=tex2D(_Outline,i.uv);
  if(_Legacy<.5){
   // One continuous, quiet mint/ice highlight, not a flat marker outline.
   // Shade only the aura; the opaque character and its screen lift stay exact.
   float rim=smoothstep(.03,.55,g.a);
   float highlight=saturate(.2+.65*i.uv.y-.25*i.uv.x);
   g.rgb=lerp(g.rgb*(.86+.14*i.uv.y),g.aaa,.25*rim*highlight);
   g*=1.4-.4*g.a;
  }
  float4 base=c+g*(1-c.a);float4 src=c*.42;
  // Premultiplied Canvas screen over the original painted pose + outline.
  return float4(src.rgb+base.rgb-src.rgb*base.rgb,src.a+base.a-src.a*base.a);
 }
 ENDCG}}
}

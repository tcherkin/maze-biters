Shader "MazeBiters/NeonWallScreen" {
 Properties {_MainTex("World light field",2D)="black"{} _Receiver("Native wall relief (R8)",2D)="black"{} _Dusk("Dusk",2D)="white"{} _Actors("Actors",2D)="black"{} _Amount("Amount",Float)=1}
 SubShader {Tags {"Queue"="Transparent"} Cull Off ZWrite Off ZTest Always Blend OneMinusDstColor One
  Pass {CGPROGRAM
   #pragma vertex vert
   #pragma fragment frag
   #include "UnityCG.cginc"
   sampler2D _MainTex,_Receiver,_Dusk,_Actors;float _Amount;
   struct Input {float4 position:POSITION;float2 uv:TEXCOORD0;};
   struct Output {float4 position:SV_POSITION;float2 uv:TEXCOORD0;};
   Output vert(Input i){Output o;o.position=UnityObjectToClipPos(i.position);o.uv=i.uv;return o;}
   float4 q(float4 value){return floor(value*255+.5)/255;}
   float4 frag(Output i):SV_Target {
    // Do not bake this thin relief into the 16px/cell light field: doing so
    // aliases rounded caps into bright dots which grow when displayed in 4K.
    float4 c=q(tex2D(_MainTex,i.uv));
    c=q(c*tex2D(_Receiver,i.uv).r);
    c=q(c*tex2D(_Dusk,i.uv).a);
    return q(c*(1-tex2D(_Actors,i.uv).a))*_Amount;
   }
   ENDCG
  }
 }
}

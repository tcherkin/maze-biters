Shader "MazeBiters/FocusedCrystal" {
 Properties {_MysticReceiver("Wall relief for travelling highlights",2D)="black"{} _MainTex("Unchanged native crystal light",2D)="black"{} _Actors("Original actor coverage",2D)="black"{} _Dusk("Original halo and beam mask",2D)="black"{} _Amount("Intrinsic light strength",Float)=1 _DistantEmission("Distant crystal emission",Float)=.22 _NearEmission("Revealed crystal emission",Float)=.97 _RevealStart("Reveal ease start",Float)=.04 _RevealEnd("Reveal ease end",Float)=.65}
 SubShader {Tags {"Queue"="Transparent"} Cull Off ZWrite Off ZTest Always Blend OneMinusDstColor One
  Pass {CGPROGRAM
   #pragma vertex vert
   #pragma fragment frag
 #pragma multi_compile __ MB_ATMOSPHERE_REFERENCE
   #include "UnityCG.cginc"
   #include "MysticLighting.cginc"
   sampler2D _MainTex,_Actors,_Dusk,_MysticReceiver;float _Amount,_DistantEmission,_NearEmission,_RevealStart,_RevealEnd;
   struct V{float4 p:POSITION;float2 uv:TEXCOORD0;};struct F{float4 p:SV_POSITION;float2 uv:TEXCOORD0;};
   F vert(V v){F f;f.p=UnityObjectToClipPos(v.p);f.uv=v.uv;return f;}
   float4 frag(F f):SV_Target {
    float4 light=tex2D(_MainTex,f.uv);
    float coverage=tex2D(_Actors,f.uv).a;
    coverage=lerp(coverage,1,smoothstep(.85,.98,coverage));
    float exposed=1-coverage;
    // Reuse the unchanged original head-tracked beam/halo. A fixed55% ambient
    // leaves a0.45DUSK alpha at distance; erasure reveals the glass smoothly.
    // No extra light texture, blur, geometry or temporal interpolation is used.
    float reveal=saturate(1-tex2D(_Dusk,f.uv).a/.45);
    float distant=_DistantEmission*lerp(1,.60+.15*tex2D(_MysticDepthTex,f.uv).r,_MysticMix*_MysticDepth);
    float illumination=lerp(distant,_NearEmission,smoothstep(_RevealStart,_RevealEnd,reveal));
    float3 result=light.rgb*light.a*exposed*_Amount*illumination;
    if(_MysticTravel>0.001){
     float receiver=tex2D(_MysticReceiver,f.uv).r;
     if(receiver>.002){
      float travel=mysticTravel(float2(f.uv.x,1-f.uv.y)*float2(576,400));
      float peak=max(light.r,max(light.g,light.b));
      float3 pearl=lerp(float3(.84,.92,1),light.rgb/max(.001,peak),.64);
      result+=travel*receiver*exposed*(pearl*.45+light.rgb*.23);
     }
    }
    return float4(saturate(result),0);
   }
   ENDCG
  }
 }
}

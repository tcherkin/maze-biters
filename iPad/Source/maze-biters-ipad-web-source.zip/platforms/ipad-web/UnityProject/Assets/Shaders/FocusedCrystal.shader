Shader "MazeBiters/FocusedCrystal" {
 Properties {_MainTex("Unchanged native crystal light",2D)="black"{} _Actors("Original actor coverage",2D)="black"{} _Dusk("Original halo and beam mask",2D)="black"{} _Amount("Intrinsic light strength",Float)=1 _DistantEmission("Distant crystal emission",Float)=.22 _NearEmission("Revealed crystal emission",Float)=.97 _RevealStart("Reveal ease start",Float)=.04 _RevealEnd("Reveal ease end",Float)=.65}
 SubShader {Tags {"Queue"="Transparent"} Cull Off ZWrite Off ZTest Always Blend OneMinusDstColor One
  Pass {CGPROGRAM
   #pragma vertex vert
   #pragma fragment frag
   #include "UnityCG.cginc"
   sampler2D _MainTex,_Actors,_Dusk;float _Amount,_DistantEmission,_NearEmission,_RevealStart,_RevealEnd;
   struct V{float4 p:POSITION;float2 uv:TEXCOORD0;};struct F{float4 p:SV_POSITION;float2 uv:TEXCOORD0;};
   F vert(V v){F f;f.p=UnityObjectToClipPos(v.p);f.uv=v.uv;return f;}
   float4 frag(F f):SV_Target {
    float4 light=tex2D(_MainTex,f.uv);
    float coverage=tex2D(_Actors,f.uv).a;
    coverage=lerp(coverage,1,smoothstep(.85,.98,coverage));
    float exposed=1-coverage;
    // Reuse the unchanged original head-tracked beam/halo. A fixed55% ambient
    // leaves a0.45DUSK alpha at distance; erasure reveals the glass smoothly.
    // No extra light texture, blur, geometry or temporal interpolation is used.
    float reveal=saturate(1-tex2D(_Dusk,f.uv).a/.45);
    float illumination=lerp(_DistantEmission,_NearEmission,smoothstep(_RevealStart,_RevealEnd,reveal));
    return float4(saturate(light.rgb*light.a*exposed*_Amount*illumination),0);
   }
   ENDCG
  }
 }
}

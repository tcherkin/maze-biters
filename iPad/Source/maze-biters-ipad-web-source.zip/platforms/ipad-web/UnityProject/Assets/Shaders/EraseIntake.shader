Shader "MazeBiters/EraseIntake" {Properties {_MainTex("Paint",2D)="white"{} _MaskTex("Aperture",2D)="white"{}}
SubShader {Pass {Cull Off ZWrite Off ZTest Always Blend Zero OneMinusSrcAlpha
CGPROGRAM
#pragma vertex vert_img
#pragma fragment frag
#include "UnityCG.cginc"
sampler2D _MainTex,_MaskTex;
float4 frag(v2f_img i):SV_Target {return tex2D(_MainTex,i.uv)*tex2D(_MaskTex,i.uv).a;}
ENDCG
}}}

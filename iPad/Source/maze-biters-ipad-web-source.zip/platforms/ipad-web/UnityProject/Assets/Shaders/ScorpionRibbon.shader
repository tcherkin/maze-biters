Shader "MazeBiters/ScorpionRibbon" {Properties {_MainTex("Original body",2D)="white"{}}
SubShader {Pass {Cull Off ZWrite Off ZTest Always Blend One OneMinusSrcAlpha Stencil {Ref 1 Comp Equal Pass Keep}
CGPROGRAM
#pragma vertex vert_img
#pragma fragment frag
#include "UnityCG.cginc"
sampler2D _MainTex;
float4 frag(v2f_img i):SV_Target {return tex2D(_MainTex,i.uv);}
ENDCG
}}}

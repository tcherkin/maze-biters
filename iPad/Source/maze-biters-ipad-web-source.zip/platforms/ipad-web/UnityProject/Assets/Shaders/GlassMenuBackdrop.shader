Shader "MazeBiters/GlassMenuBackdrop" {
 Properties {
  _MainTex("Approved glass walls",2D)="black"{}
  _EmissionTex("Approved crystal emission",2D)="black"{}
  _OpticalField("Prepared floor light",2D)="black"{}
  _Champagne("Champagne maze palette",Float)=0
  _LightBlue("Light blue maze palette",Float)=0
  _TravelEnabled("Travelling light inside wall material",Float)=0
  _BoundedMaze("Keep maze inside the rounded picture",Float)=0
  _ArchitecturalLayout("Thick paths around the menu",Float)=0
 }
 CGINCLUDE
 #include "UnityCG.cginc"
 #include "MenuTravelStars.cginc"
 sampler2D _MainTex,_EmissionTex,_OpticalField;
 float4 _Viewport,_FieldRect,_Pan,_AuraA,_AuraB,_Style;
 float _Champagne,_LightBlue,_TravelEnabled,_AlignedLayout,_BoundedMaze,_ArchitecturalLayout;
 float4 _TravelOffset;
 float4 _TravelA,_TravelB,_TravelC,_TravelD;
 struct V {float4 vertex:POSITION;float2 uv:TEXCOORD0;float2 pathWorld:TEXCOORD1;};
 struct F {float4 vertex:SV_POSITION;float2 uv:TEXCOORD0;float2 screen:TEXCOORD1;float2 pathWorld:TEXCOORD2;};
 F vertBackground(V v){F f;f.pathWorld=0;f.vertex=UnityObjectToClipPos(v.vertex);f.uv=v.uv;f.screen=_Viewport.xy+float2(v.uv.x,1-v.uv.y)*_Viewport.zw;return f;}
 F vertGlass(V v){F f;f.pathWorld=v.pathWorld;f.vertex=UnityObjectToClipPos(v.vertex);f.uv=v.uv;f.screen=(float2(v.vertex.x,-v.vertex.y)-float2(512,384))*_Pan.z+float2(512,384)-_Pan.xy;return f;}
 float2 glassWorld(float2 p){return (p+_Pan.xy-float2(512,384))/_Pan.z+float2(512,384);}
 float3 violetRose(float3 c){
  // Preserve the source atlas's neutral specular details and range. The deep
  // shell becomes amethyst; its cyan optical core becomes a soft rose light.
  float hi=max(c.r,max(c.g,c.b)),lo=min(c.r,min(c.g,c.b));
  float core=smoothstep(.35,.88,c.g/max(.001,c.b));
  float3 tint=lerp(float3(.55,.15,1),float3(1,.24,.72),core);
  return lo+(hi-lo)*tint;
 }
 float3 iceGlass(float3 c){
  // Recolour only the chromatic material; neutral carved glints remain neutral.
  // Recover most of the source's pearly peak: strict violet-luminance matching
  // made cyan look like dark steel. Lighting strength and alpha stay unchanged.
  float hi=max(c.r,max(c.g,c.b)),lo=min(c.r,min(c.g,c.b));
  float core=smoothstep(.35,.88,c.g/max(.001,c.b));
  float3 tint=lerp(float3(.18,.50,1),float3(.38,.87,1),core);
  float3 ice=lo+(hi-lo)*tint;
  float3 weights=float3(.2126,.7152,.0722);
  float balanced=dot(violetRose(c),weights)/max(.00001,dot(ice,weights));
  return ice*lerp(balanced,1,.78);
 }
 float roundedDistance(float2 p,float2 centre,float2 halfSize,float radius){float2 q=abs(p-centre)-halfSize+radius;return min(max(q.x,q.y),0)+length(max(q,0))-radius;}
 float mazeBoundary(float2 p){
  // A 1.5-logical-pixel inward feather keeps the complete wall and its floor
  // reflections inside (10,10,1004,748), with 22-pixel rounded corners.
  return 1-smoothstep(-1.5,0,roundedDistance(p,float2(512,384),float2(502,374),22));
 }
 float quietArea(float2 p,float2 centre,float2 halfSize,float radius){return 1-smoothstep(-8,38,roundedDistance(p,centre,halfSize,radius));}
 float quiet(float2 p){
  // These are soft art-direction masks, not UI surfaces. They do not alter any
  // original text, hit target, button geometry, alpha clock or navigation.
  float options=max(quietArea(p,float2(276,323),float2(222,112),30),quietArea(p,float2(748,323),float2(222,112),30));
  float title=quietArea(p,float2(512,121),float2(342,57),38);
  float settings=quietArea(p,float2(512,650),float2(476,49),26);
  float secondary=quietArea(p,float2(512,539),float2(250,25),20);
  return 1-.68*max(max(options,settings),max(title*.65,secondary*.75));
 }
 float titleVeil(float2 p){
  // The moving architecture must not read as strokes of the logo. A wide,
  // feathered veil leaves only a trace of the glass behind its entire wordmark.
  float distance=roundedDistance(p,float2(512,116),float2(363,69),42);
  return 1-smoothstep(-8,64,distance);
 }
 float aura(float2 world,float4 source){float2 p=(world-source.xy)/source.z;p.y*=1.08;float d=dot(p,p);return exp(-d*1.65)*(1-smoothstep(2.7,4,d))*source.w;}
 float localLight(float2 world){return saturate(aura(world,_AuraA)+aura(world,_AuraB));}
 float travelCell(float2 world){float2 cell=floor((world-float2(-302,-242))/44);return cell.x+cell.y*38;}
 float travelSample(float2 world,float cell,float4 source){
  float before=fmod(source.w,2048)-1,after=floor(source.w/2048)-1,own=travelCell(source.xy);
  float connected=max(1-step(.5,abs(cell-own)),max(1-step(.5,abs(cell-before)),1-step(.5,abs(cell-after))));
  float distance=length(world-source.xy);
  return exp(-distance*distance/(2*9*9))*(1-smoothstep(15,21,distance))*source.z*connected;
 }
 float travellingLight(float2 world){
  float cell=travelCell(world);
  return saturate(travelSample(world,cell,_TravelA)+travelSample(world,cell,_TravelB)+travelSample(world,cell,_TravelC)+travelSample(world,cell,_TravelD));
 }
 float travelSampleAligned(float2 world,float cell,float4 source){
  float before=fmod(source.w,2048)-1,after=floor(source.w/2048)-1,own=travelCell(source.xy-_TravelOffset.xy);
  float connected=max(1-step(.5,abs(cell-own)),max(1-step(.5,abs(cell-before)),1-step(.5,abs(cell-after))));
  float distance=length(world-source.xy);
  return exp(-distance*distance/(2*9*9))*(1-smoothstep(15,21,distance))*source.z*connected;
 }
 float travellingLightAligned(float2 world,float2 originalWorld){
  float cell=travelCell(originalWorld);
  return saturate(travelSampleAligned(world,cell,_TravelA)+travelSampleAligned(world,cell,_TravelB)+travelSampleAligned(world,cell,_TravelC)+travelSampleAligned(world,cell,_TravelD));
 }
 float architecturalSample(float2 world,float4 source){
  float distance=length(world-source.xy);
  return exp(-distance*distance/(2*11.88*11.88))*(1-smoothstep(20,27.72,distance))*source.z;
 }
 float architecturalLight(float2 world){
  return saturate(architecturalSample(world,_TravelA)+architecturalSample(world,_TravelB)+architecturalSample(world,_TravelC)+architecturalSample(world,_TravelD));
 }
 float4 fragBackground(F f):SV_Target {
  float2 world=glassWorld(f.screen),fieldUV=(world-_FieldRect.xy)/_FieldRect.zw;
  float3 optical=tex2D(_OpticalField,saturate(fieldUV)).rgb;
  optical*=step(0,fieldUV.x)*step(0,fieldUV.y)*step(fieldUV.x,1)*step(fieldUV.y,1);
  float calm=quiet(f.screen),light=localLight(world),bright=_Style.x,glow=_Style.y;
  // The independent distant sky approaches the viewer in perspective.
  float3 stars=menuTravelStars(f.screen,_Style.z)*1.25;
  float3 violet=float3(.24,.055,.40),rose=float3(.40,.08,.23);
  if(_Champagne>.5){violet=float3(.30,.22,.115);rose=float3(.38,.30,.19);}
  if(_LightBlue>.5){violet=float3(.065,.12,.27);rose=float3(.095,.165,.29);}
  // A restrained continuous tint connects the paths as a single glass surface;
  // the prepared broad field adds reflected color around the actual bends.
  // No fullscreen blur, moving noise or opaque bright fog is involved.
  float3 floorLight=violet*(.03+optical.r*1.55+optical.g*.085)+rose*optical.b*.38;
  floorLight*=bright*(.70+light*1.55*glow)*(.58+.42*calm);
  if(_BoundedMaze>.5)floorLight*=mazeBoundary(f.screen);
  float vignette=1-.23*smoothstep(.2,1.05,length((f.screen-float2(512,384))/float2(730,590)));
  float2 basin=(world-float2(512,432))/float2(760,610);
  float depth=exp(-dot(basin,basin)*1.35);
  float3 baseColor=float3(.008,.003,.013)+float3(.008,.0025,.012)*depth*bright;
  baseColor+=float3(.014,.003,.016)*light*glow*(.60+.40*calm);
  if(_Champagne>.5){
   // Muted honey in the depth, pale champagne in the reflected field. Keep
   // the sky itself cool so the glass reads warm without becoming orange fog.
   baseColor=float3(.010,.0075,.0045)+float3(.010,.007,.0035)*depth*bright;
   baseColor+=float3(.016,.012,.0065)*light*glow*(.60+.40*calm);
  }
  if(_LightBlue>.5){
   baseColor=float3(.0025,.0045,.008)+float3(.002,.004,.008)*depth*bright;
   baseColor+=float3(.003,.0065,.013)*light*glow*(.60+.40*calm);
  }
  return float4((baseColor+stars*(.42+.58*calm)+floorLight)*vignette,1);
 }
 float4 fragGlass(F f):SV_Target {
  float4 surface=tex2D(_MainTex,f.uv);float3 crystal=tex2D(_EmissionTex,f.uv).rgb;
  if(_Champagne<.5){
   if(_LightBlue>.5){surface.rgb=iceGlass(surface.rgb);crystal=iceGlass(crystal);}
   else{surface.rgb=violetRose(surface.rgb);crystal=violetRose(crystal);}
  }
  float calm=quiet(f.screen),light=localLight(glassWorld(f.screen));
  float illumination=(.25+.33*_Style.x)+light*.43*_Style.y;
  float3 color=surface.rgb*illumination+crystal*(.075+light*.22)*_Style.y;
  if(_TravelEnabled>.5){
   // Light is visible only through this existing wall-material pass. Neither
   // the sky nor the floor gains a halo, and source alpha is never expanded.
   float travel;
   if(_ArchitecturalLayout>.5)travel=architecturalLight(glassWorld(f.screen));
   else if(_AlignedLayout>.5)travel=travellingLightAligned(glassWorld(f.screen),f.pathWorld);
   else travel=travellingLight(glassWorld(f.screen));
   float core=smoothstep(.06,.62,max(crystal.r,max(crystal.g,crystal.b)));
   float3 pearl=_Champagne>.5?float3(1,.93,.72):float3(.64,.91,1);
   color+=travel*(pearl*.32+surface.rgb*.18)*(.18+.82*core);
  }
  float opacity=surface.a*(.35+.65*calm)*(1-.94*titleVeil(f.screen));
  if(_BoundedMaze>.5)opacity*=mazeBoundary(f.screen);
  color*=.48+.52*calm;
  return float4(color*opacity,opacity);
 }
 ENDCG
 SubShader {
  Cull Off ZWrite Off ZTest Always
  Pass {
   Blend Off
   CGPROGRAM
   #pragma target 3.0
   #pragma vertex vertBackground
   #pragma fragment fragBackground
   ENDCG
  }
  Pass {
   Blend One OneMinusSrcAlpha
   CGPROGRAM
   #pragma target 3.0
   #pragma vertex vertGlass
   #pragma fragment fragGlass
   ENDCG
  }
 }
 Fallback Off
}

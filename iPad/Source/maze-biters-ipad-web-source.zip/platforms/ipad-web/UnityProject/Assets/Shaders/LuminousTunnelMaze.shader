Shader "MazeBiters/LuminousTunnelMaze" {
 Properties {_MainTex("Unchanged smoked maze",2D)="white"{} _Dusk("Local labyrinth lighting",2D)="black"{} _SkyRect("Projected maze plus sky offset",Vector)=(0,0,576,400) _SkyVisibility("Distant star visibility",Float)=.9 _OuterSkyBlend("Contour exterior sky",Range(0,1))=1}
 SubShader {Tags {"Queue"="Geometry"} Cull Off ZWrite Off ZTest Always
 Pass {CGPROGRAM
 #pragma vertex vert
 #pragma fragment frag
 #pragma multi_compile __ MB_ATMOSPHERE_REFERENCE
 #include "UnityCG.cginc"
 #include "LuminousStars.cginc"
 #include "MysticLighting.cginc"
 sampler2D _MainTex,_Dusk;float4 _SkyRect;float _SkyVisibility,_OuterSkyBlend;
 struct V{float4 p:POSITION;float2 uv:TEXCOORD0;};struct F{float4 p:SV_POSITION;float2 uv:TEXCOORD0;};
 F vert(V v){F f;f.p=UnityObjectToClipPos(v.p);f.uv=v.uv;return f;}
 float4 frag(F f):SV_Target{
  float4 floor=tex2D(_MainTex,f.uv);
  float2 p=_SkyRect.xy+float2(f.uv.x,1-f.uv.y)*_SkyRect.zw;
  float duskAlpha=mysticDusk(tex2D(_Dusk,f.uv).a,f.uv);
  float coverage=smoothstep(0,153.0/255.0,floor.a);
  float localTransmission=max(1-duskAlpha*coverage,.2);
  float visibility=lerp(1,_SkyVisibility,coverage);
  float3 baseLight,rareCore;luminousStarLayers(p,baseLight,rareCore);
  // The glass transmits only 40% of the sky; a few existing cores can be twice
  // as luminous below it without brightening every star into a uniform dot.
  float3 sky=lerp(saturate(baseLight+rareCore),baseLight+2*rareCore,coverage);
  float3 material=floor.rgb*floor.a;
  float3 starSignal=sky*(1-floor.a)*visibility;
  // Cap against the FIXED 55% ambient minimum, never the current flashlight.
  // This prevents RGBA8 clipping before DUSK while keeping sky emission fixed
  // as the flashlight crosses a star. Empty exterior uses its 100% minimum.
  float minimumTransmission=1-mysticDusk(.45,f.uv)*coverage;
  starSignal=min(starSignal,(1-material)*minimumTransmission*(1-.03*coverage));
  // Identical physical sky below the floor and around it. Compensate only the
  // later darkness so the flashlight cannot animate distant star brightness.
  return float4(material+starSignal/localTransmission,1);
 }
 ENDCG}
 }
}

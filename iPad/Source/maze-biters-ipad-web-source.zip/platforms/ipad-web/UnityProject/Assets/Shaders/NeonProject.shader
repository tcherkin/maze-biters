Shader "MazeBiters/NeonProject" {Properties{_MainTex("Source",2D)="black"{} _Dusk("Dusk",2D)="white"{} _Actors("Actors",2D)="black"{} _Receiver("Receiver",2D)="white"{} _Foreground("Foreground",2D)="black"{} _Mode("Mode",Float)=0} SubShader {Cull Off ZWrite Off ZTest Always Pass {CGPROGRAM
#pragma vertex vert_img
#pragma fragment frag
#include "UnityCG.cginc"
#include "MysticLighting.cginc"
sampler2D _MainTex,_Dusk,_Actors,_Receiver,_Foreground;float _Mode;
float4 q(float4 v){return floor(v*255+.5)/255;}
float4 frag(v2f_img i):SV_Target {float4 c=q(tex2D(_MainTex,i.uv));
 if(_Mode==4)return q(c*(1-tex2D(_Foreground,i.uv).a));
 if(_Mode==1||_Mode==3)c=q(c*tex2D(_Receiver,i.uv).a);if(_Mode==3)return c;
 if(_Mode==2)c=q(c*(1-tex2D(_Foreground,i.uv).a));
 c=q(c*tex2D(_Dusk,i.uv).a);if(_Mode==2)c*=lerp(1,.84,_MysticMix*_MysticDepth*saturate(tex2D(_Dusk,i.uv).a/.45));if(_Mode!=2)c=q(c*(1-tex2D(_Actors,i.uv).a));return c;}
ENDCG }}}

Shader "MazeBiters/FrameStars" {
 Properties {_Rect("Logical rectangle",Vector)=(0,0,576,432) _Offset("Distant parallax",Vector)=(0,0,0,0)}
 SubShader {Tags {"Queue"="Transparent"} Cull Off ZWrite Off ZTest Always
 Pass {CGPROGRAM
 #pragma vertex vert
 #pragma fragment frag
 #include "UnityCG.cginc"
 #include "DistantStars.cginc"
 float4 _Rect,_Offset;
 struct V{float4 p:POSITION;float2 uv:TEXCOORD0;};struct F{float4 p:SV_POSITION;float2 uv:TEXCOORD0;};
 F vert(V v){F f;f.p=UnityObjectToClipPos(v.p);f.uv=v.uv;return f;}
 float4 frag(F f):SV_Target{
  float2 p=_Rect.xy+_Offset.xy+float2(f.uv.x,1-f.uv.y)*_Rect.zw;
  return float4(distantStars(p),1);
 }
 ENDCG}
 }
}


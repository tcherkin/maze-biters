Shader "MazeBiters/IntakeComposite" {Properties {_MainTex("Paint",2D)="white"{} _MaskTex("Aperture",2D)="white"{}}
SubShader {Tags {"Queue"="Transparent"} Pass {Cull Off ZWrite Off ZTest Always Blend One OneMinusSrcAlpha
CGPROGRAM
#pragma vertex vert
#pragma fragment frag
#include "UnityCG.cginc"
sampler2D _MainTex,_MaskTex;
struct V {float4 p:SV_POSITION;float2 uv:TEXCOORD0;};
V vert(appdata_base a){V o;o.p=UnityObjectToClipPos(a.vertex);o.uv=a.texcoord;return o;}
float4 frag(V i):SV_Target {return floor(tex2D(_MainTex,i.uv)*tex2D(_MaskTex,i.uv).a*255+.5)/255;}
ENDCG
}}}

#ifndef MAZE_MYSTIC_STUDY
#define MAZE_MYSTIC_STUDY
// A tiny, immutable world-space field; no extra full-screen render pass.
sampler2D _MysticDepthTex;
float _MysticMix,_MysticDepth,_MysticTravel,_MysticLightMix;
#if defined(SHADER_API_GLES3)
// The isolated WebGL2 build uses one tiny, linear point-sampled float texture.
// Records preserve all32 streams, exact float32 coordinates/cells and bounds;
// this avoids exceeding a device's guaranteed fragment-uniform capacity.
Texture2D<float4> _MysticRouteRecords;
float4 mysticSource(int n){return _MysticRouteRecords.Load(int3(n,0,0));}
float4 mysticCells(int n){return _MysticRouteRecords.Load(int3(96+n,0,0));}
float4 mysticBounds(int n){return _MysticRouteRecords.Load(int3(192+n,0,0));}
#else
float4 _MysticSources[96];
float4 _MysticSourceCells[96],_MysticStreamBounds[32];
float4 mysticSource(int n){return _MysticSources[n];}
float4 mysticCells(int n){return _MysticSourceCells[n];}
float4 mysticBounds(int n){return _MysticStreamBounds[n];}
#endif
#if defined(MB_THIRTYTWO_WALL_LIGHTS)
 #define MYSTIC_STREAMS 32
#elif defined(MB_SIXTEEN_WALL_LIGHTS)
 #define MYSTIC_STREAMS 16
#elif defined(MB_EIGHT_WALL_LIGHTS)
 #define MYSTIC_STREAMS 8
#else
 #define MYSTIC_STREAMS 4
#endif
float mysticDusk(float original,float2 uv){
 float ambient=.38+.10*tex2D(_MysticDepthTex,uv).r;
 return original*lerp(1,(1-ambient)/.45,saturate(_MysticMix*_MysticDepth));
}
float mysticTravel(float2 world){
 float cell=floor(world.x/16)+floor(world.y/16)*36;
 float result=0;
#if defined(MB_ATMOSPHERE_REFERENCE)
 [unroll]for(int n=0;n<MYSTIC_STREAMS*3;n++){
  float4 s=mysticSource(n);
  float own=floor(s.x/16)+floor(s.y/16)*36;
  float prior=fmod(s.w,1024)-1,next=floor(s.w/1024)-1;
  float connected=max(1-step(.5,abs(cell-own)),max(1-step(.5,abs(cell-prior)),1-step(.5,abs(cell-next))));
  float2 p=(world-s.xy)/11.2;
  float a=saturate(1-dot(p,p));
  result+=a*a*a*s.z*connected;
 }
#else
 // Small influence regions skip all distant wall-light kernels.
 // Exact topology and kernel arithmetic inside each region remain unchanged.
 [unroll]for(int stream=0;stream<MYSTIC_STREAMS;stream++){
  float4 b=mysticBounds(stream);
  [branch]if(world.x>=b.x&&world.y>=b.y&&world.x<=b.z&&world.y<=b.w){
   [unroll]for(int trail=0;trail<3;trail++){
    int n=stream*3+trail;float4 s=mysticSource(n),c=mysticCells(n);
    float connected=max(1-step(.5,abs(cell-c.x)),max(1-step(.5,abs(cell-c.y)),1-step(.5,abs(cell-c.z))));
    float2 p=(world-s.xy)/11.2;float a=saturate(1-dot(p,p));
    result+=a*a*a*s.z*connected;
   }
  }
 }
#endif
 // Travelling pearls stay alive at the bright endpoint of the breathing cycle.
 return min(result,1.25)*_MysticLightMix*_MysticTravel;
}
#endif

#ifndef MAZE_MYSTIC_STUDY
#define MAZE_MYSTIC_STUDY
// A tiny, immutable world-space field; no extra full-screen render pass.
sampler2D _MysticDepthTex;
float _MysticMix,_MysticDepth,_MysticTravel,_MysticLightMix;
float4 _MysticSources[12];
float mysticDusk(float original,float2 uv){
 float ambient=.38+.10*tex2D(_MysticDepthTex,uv).r;
 return original*lerp(1,(1-ambient)/.45,saturate(_MysticMix*_MysticDepth));
}
float mysticTravel(float2 world){
 float cell=floor(world.x/16)+floor(world.y/16)*36;
 float result=0;
 [unroll]for(int n=0;n<12;n++){
  float4 s=_MysticSources[n];
  float own=floor(s.x/16)+floor(s.y/16)*36;
  float prior=fmod(s.w,1024)-1,next=floor(s.w/1024)-1;
  float connected=max(1-step(.5,abs(cell-own)),max(1-step(.5,abs(cell-prior)),1-step(.5,abs(cell-next))));
  float2 p=(world-s.xy)/11.2;
  float a=saturate(1-dot(p,p));
  result+=a*a*a*s.z*connected;
 }
 // Travelling pearls stay alive at the bright endpoint of the breathing cycle.
 return min(result,1.25)*_MysticLightMix*_MysticTravel;
}
#endif

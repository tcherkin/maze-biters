Shader "MazeBiters/SnakeComposite" {Properties {_MainTex("Material",2D)="white"{} _MaskTex("Coverage",2D)="white"{}}
SubShader {Cull Off ZWrite Off ZTest Always Blend One OneMinusSrcAlpha Pass {CGPROGRAM
#pragma vertex vert
#pragma fragment frag
#include "UnityCG.cginc"
sampler2D _MainTex,_MaskTex;
struct I {float4 p:POSITION;float2 uv:TEXCOORD0;};
struct O {float4 p:SV_POSITION;float2 uv:TEXCOORD0;};
O vert(I i){
 O o;o.p=UnityObjectToClipPos(i.p);o.uv=i.uv;
 // NativeSnake explicitly uses GetGPUProjectionMatrix(..., true) when it
 // writes these cropped surfaces. D3D/Metal invert that projection for a
 // top-origin render target; WebGL retains its bottom-origin projection.
 // Flipping WebGL here samples the unused padding (and mirrors the glow).
#if UNITY_UV_STARTS_AT_TOP
 o.uv.y=1-o.uv.y;
#endif
 return o;
}
float4 frag(O i):SV_Target{return floor(tex2D(_MainTex,i.uv)*tex2D(_MaskTex,i.uv).a*255+.5)/255;}
ENDCG }}}

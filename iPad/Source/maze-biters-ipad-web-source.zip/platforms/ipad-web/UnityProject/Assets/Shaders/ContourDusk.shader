Shader "MazeBiters/ContourDusk" {
 Properties {_MainTex("Premultiplied DUSK mask",2D)="white"{} _Opacity("Opacity",Float)=1 _MazeCoverage("Contour maze coverage",2D)="white"{}}
 SubShader {Tags {"Queue"="Transparent"} Cull Off ZWrite Off ZTest Always Blend One OneMinusSrcAlpha
 Pass {CGPROGRAM
 #pragma vertex vert
 #pragma fragment frag
 #include "UnityCG.cginc"
 sampler2D _MainTex,_MazeCoverage;float _Opacity;
 struct V {float4 p:POSITION;float2 uv:TEXCOORD0;};struct F {float4 p:SV_POSITION;float2 uv:TEXCOORD0;};
 F vert(V v){F f;f.p=UnityObjectToClipPos(v.p);f.uv=v.uv;return f;}
 float4 frag(F f):SV_Target{
  // This shader is selected only by the isolated contour AFTER preview.
  // Tunnel alpha starts at 153/255; only the exterior rounded cutout is lower.
  // Preserve premultiplication by scaling the complete original DUSK sample.
  float coverage=smoothstep(0,153.0/255.0,tex2D(_MazeCoverage,f.uv).a);
  return tex2D(_MainTex,f.uv)*_Opacity*coverage;
 }
 ENDCG}
 }
}

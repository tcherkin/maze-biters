#ifndef MAZE_BITERS_LUMINOUS_STARS
#define MAZE_BITERS_LUMINOUS_STARS
#include "DistantStars.cginc"
// Preserve original hash, cells and centres. Only rare existing stars get a
// luminous cyan-white core and soft halo; nothing is attached to maze geometry.
void luminousStarLayers(float2 p,out float3 baseLight,out float3 rareCore){
 float2 cell=floor(p/9),local=frac(p/9)*9;float n=distantStarHash(cell);
 float2 centre=2+float2(distantStarHash(cell+31),distantStarHash(cell+73))*5;
 float2 delta=local-centre;float d=length(delta);
 float size=lerp(.32,.66,distantStarHash(cell+19));
 // p is continuous across cells; derivatives of the reset local distance are
 // not. Using its pixel footprint avoids cell-boundary horizontal hairlines.
 float edge=max(max(fwidth(p).x,fwidth(p).y),.08);
 float rare=step(.965,n);
 float core=(1-smoothstep(size*.72-edge,size*.72+edge,d))*rare;
 // Every centre is >=2 logical pixels from its cell edge. Reach exact zero
 // before that boundary, including the soft halo, so there is no clipped seam.
 float halo=exp(-d*d/1.3)*(1-smoothstep(1.5,1.95,d))*rare;
 float3 tint=lerp(float3(.40,.78,1),float3(.80,.92,1),distantStarHash(cell+97));
 float ordinary=(1-smoothstep(size-edge,size+edge,d))*step(.86,n);
 float3 originalTint=lerp(float3(.13,.34,.30),float3(.26,.20,.42),distantStarHash(cell+53));
 baseLight=ordinary*originalTint*1.45+tint*halo*.12;
 rareCore=tint*core*.70;
}
float3 luminousStars(float2 p){float3 baseLight,rareCore;luminousStarLayers(p,baseLight,rareCore);return saturate(baseLight+rareCore);}
#endif

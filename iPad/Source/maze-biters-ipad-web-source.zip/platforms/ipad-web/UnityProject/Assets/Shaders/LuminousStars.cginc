#ifndef MAZE_BITERS_LUMINOUS_STARS
#define MAZE_BITERS_LUMINOUS_STARS
#include "DistantStars.cginc"
// The same sky coordinates and clock drive the exterior and transmitted sky.
// No camera, player light or maze-breathing phase enters this modulation.
float _MysticStarTime,_MysticStarStrength;
// Preserve original hash, cells and centres. Only rare existing stars get a
// luminous cyan-white core and soft halo; nothing is attached to maze geometry.
void luminousStarLayers(float2 p,out float3 baseLight,out float3 rareCore){
 float2 cell=floor(p/9),local=frac(p/9)*9;float n=distantStarHash(cell);
 float2 centre=2+float2(distantStarHash(cell+31),distantStarHash(cell+73))*5;
 float2 delta=local-centre;float d=length(delta);
 float size=lerp(.32,.66,distantStarHash(cell+19));
 // p is continuous across cells; derivatives of the reset local distance are
 // not. Using its pixel footprint avoids cell-boundary horizontal hairlines.
 float edge=max(max(fwidth(p).x,fwidth(p).y),.08);
 float rare=step(.965,n);
 float core=(1-smoothstep(size*.72-edge,size*.72+edge,d))*rare;
 // Every centre is >=2 logical pixels from its cell edge. Reach exact zero
 // before that boundary, including the soft halo, so there is no clipped seam.
 float halo=exp(-d*d/1.3)*(1-smoothstep(1.5,1.95,d))*rare;
 float3 tint=lerp(float3(.40,.78,1),float3(.80,.92,1),distantStarHash(cell+97));
 float ordinary=(1-smoothstep(size-edge,size+edge,d))*step(.86,n);
 float3 originalTint=lerp(float3(.13,.34,.30),float3(.26,.20,.42),distantStarHash(cell+53));
 baseLight=ordinary*originalTint*1.45+tint*halo*.12;
 rareCore=tint*core*.70;
 if(_MysticStarStrength>.0001 && n>=.86 && d<max(1.95,size+edge)){
  float seed=distantStarHash(cell+127);
  float phase=frac(seed*17.17+n*31.7)*6.2831853;
  float rate=lerp(.82,1.43,frac(seed*7.79));
  float wave=sin(_MysticStarTime*rate+phase);
  float drift=sin(_MysticStarTime*rate*.53+seed*51.13);
  // A readable 1–2 second glint every 3.8–7.4 seconds, independently phased.
  // Keep a quiet population between the luminous points: no whole-sky pulse.
  float gleam=.5+.5*sin(_MysticStarTime*(6.2831853/lerp(3.8,7.4,seed))+seed*37.31);
  gleam*=gleam;gleam*=gleam;gleam*=gleam;
  baseLight*=1+_MysticStarStrength*(.24*wave+.06*drift-.05);
  rareCore*=1+_MysticStarStrength*(.26*wave+.08*drift-.14);
  // Larger pearly cores, a soft bloom, and tiny four-point highlights make the
  // motion visible at overview scale. All are anchored to existing stars and
  // taper to exact zero before the cell edge; no new star positions or seams.
  float flash=_MysticStarStrength*step(.94,n)*gleam;
  float envelope=1-smoothstep(1.45,1.95,d);
  float pearl=1-smoothstep(size*.92-edge,size*.92+edge,d);
  float bloom=exp(-d*d/1.8)*envelope;
  float armWidth=max(.10,edge*.40);
  float2 a=abs(delta);
  float rays=(exp(-a.x*a.x/(armWidth*armWidth))*exp(-a.y*a.y/1.15)
             +exp(-a.y*a.y/(armWidth*armWidth))*exp(-a.x*a.x/1.15))*.5*envelope;
  float3 pearlTint=lerp(tint,float3(.90,.97,1),.55);
  rareCore+=pearlTint*flash*(pearl*1.10+bloom*.45+rays*.35);
 }
}
float3 luminousStars(float2 p){float3 baseLight,rareCore;luminousStarLayers(p,baseLight,rareCore);return saturate(baseLight+rareCore);}
#endif

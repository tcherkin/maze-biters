Shader "MazeBiters/NeonBlur" {Properties{_MainTex("Source",2D)="black"{}} SubShader {Cull Off ZWrite Off ZTest Always Pass {CGPROGRAM
#pragma vertex vert_img
#pragma fragment frag
#include "UnityCG.cginc"
sampler2D _MainTex;float2 _Step;
float4 frag(v2f_img i):SV_Target {const float weights[8]={.197448,.174697,.120999,.065602,.027840,.009246,.002403,.000489};float4 c=tex2D(_MainTex,i.uv)*weights[0];for(int k=1;k<8;k++)c+=(tex2D(_MainTex,i.uv+_Step*k)+tex2D(_MainTex,i.uv-_Step*k))*weights[k];return c;}
ENDCG }}}

Shader "MazeBiters/MessagePanel" {
 Properties {
  _Color("Tint",Color)=(0.006,0.014,0.022,0.82)
  _Size("Logical size",Vector)=(320,64,0,0)
  _Radius("Corner radius",Float)=18
  _Feather("Soft edge",Float)=12
  _Opacity("Opacity",Float)=1
 }
 SubShader {
  Tags {"Queue"="Transparent" "RenderType"="Transparent"}
  Cull Off ZWrite Off ZTest Always Blend One OneMinusSrcAlpha
  Pass {CGPROGRAM
   #pragma vertex vert
   #pragma fragment frag
   #include "UnityCG.cginc"
   float4 _Color,_Size;float _Radius,_Feather,_Opacity;
   struct V {float4 p:POSITION;float2 uv:TEXCOORD0;};
   struct F {float4 p:SV_POSITION;float2 uv:TEXCOORD0;};
   F vert(V v){F f;f.p=UnityObjectToClipPos(v.p);f.uv=v.uv;return f;}
   float4 frag(F f):SV_Target {
    float2 halfSize=max(_Size.xy*.5,1);
    float radius=min(_Radius,min(halfSize.x,halfSize.y));
    float2 q=abs((f.uv-.5)*_Size.xy)-halfSize+radius;
    float distance=length(max(q,0))+min(max(q.x,q.y),0)-radius;
    // Fade entirely inside the geometry: no hard rectangle or clipped halo.
    float coverage=1-smoothstep(-max(_Feather,.5),0,distance);
    float alpha=_Color.a*saturate(_Opacity)*coverage;
    float3 tint=_Color.rgb*(.86+.14*f.uv.y);
    return float4(tint*alpha,alpha);
   }
  ENDCG}
 }
}

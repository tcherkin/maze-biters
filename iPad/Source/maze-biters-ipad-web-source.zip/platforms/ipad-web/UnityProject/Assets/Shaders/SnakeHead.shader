Shader "MazeBiters/SnakeHead" {Properties {_MainTex("Original mouth atlas",2D)="white"{} _Nape("Rounded retiring neck",Float)=0 _Opacity("Opacity",Float)=1}
 SubShader {Tags {"Queue"="Transparent"} Cull Off ZWrite Off ZTest Always Blend One OneMinusSrcAlpha
 Pass {CGPROGRAM
 #pragma vertex vert
 #pragma fragment frag
 #include "UnityCG.cginc"
 sampler2D _MainTex;float _Nape,_Opacity;struct I{float4 p:POSITION;float2 uv:TEXCOORD0;};struct O{float4 p:SV_POSITION;float2 uv:TEXCOORD0;};O vert(I i){O o;o.p=UnityObjectToClipPos(i.p);o.uv=i.uv;return o;}
 float cubic(float4 v,float t){float u=1-t;return u*u*u*v.x+3*u*u*t*v.y+3*u*t*t*v.z+t*t*t*v.w;}
 float4 frag(O i):SV_Target{float4 color=tex2D(_MainTex,i.uv);if(_Nape>0){float2 p=frac(float2(i.uv.x*9,(1-i.uv.y)*11))*float2(224,176);float edge;
 if(p.y>136)edge=lerp(42*_Nape,42,(p.y-136)/40);else{float4 ys=p.y<70?float4(0,15,36,70):float4(70,105,126,136);float4 xs=p.y<70?float4(42,18,2,2):float4(2,2,19,42);float lo=0,hi=1;[unroll]for(int n=0;n<12;n++){float mid=(lo+hi)*.5;if(cubic(ys,mid)<p.y)lo=mid;else hi=mid;}edge=cubic(xs,(lo+hi)*.5)*_Nape;}
 float d=p.x-edge;color*=saturate(d/max(fwidth(d),.0001)+.5);}return color*_Opacity;}
 ENDCG}
 }}

Shader "MazeBiters/TunnelMaze" {
 Properties {_MainTex("Original maze with floor coverage",2D)="white"{} _Dusk("Local labyrinth lighting",2D)="black"{} _SkyRect("Projected maze plus sky offset",Vector)=(0,0,576,400) _SkyVisibility("Distant star visibility",Float)=.5}
 SubShader {Tags {"Queue"="Geometry"} Cull Off ZWrite Off ZTest Always
 Pass {CGPROGRAM
 #pragma vertex vert
 #pragma fragment frag
 #include "UnityCG.cginc"
 #include "DistantStars.cginc"
 sampler2D _MainTex,_Dusk;float4 _SkyRect;float _SkyVisibility;
 struct V {float4 p:POSITION;float2 uv:TEXCOORD0;};struct F {float4 p:SV_POSITION;float2 uv:TEXCOORD0;};
 F vert(V v){F f;f.p=UnityObjectToClipPos(v.p);f.uv=v.uv;return f;}
 float4 frag(F f):SV_Target{
  float4 floor=tex2D(_MainTex,f.uv);
  // Compose the same distant field before actors are drawn. Only its emitted
  // light bypasses the later DUSK attenuation; the floor, walls and actors keep
  // the original lighting. No late star overlay can leak over silhouettes.
  float2 p=_SkyRect.xy+float2(f.uv.x,1-f.uv.y)*_SkyRect.zw;
  float3 sky=distantStars(p);
  float localTransmission=max(1-tex2D(_Dusk,f.uv).a,.2);
  return float4(floor.rgb*floor.a+sky*(1-floor.a)*_SkyVisibility/localTransmission,1);
 }
 ENDCG}
 }
}

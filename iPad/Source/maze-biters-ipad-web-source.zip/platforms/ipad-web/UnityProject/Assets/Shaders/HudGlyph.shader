Shader "MazeBiters/HudGlyph" {
 Properties {_MainTex("Original glyphs",2D)="white"{} _Beam("Original spotlight",2D)="black"{} _Opacity("Opacity",Float)=1 _BeamX("Logical beam left",Float)=0 _BeamOn("Spotlight active",Float)=0
 _OcclusionOpacity("Object contact opacity",Float)=1}
 SubShader {Tags {"Queue"="Transparent"} Cull Off ZWrite Off ZTest Always Blend One OneMinusSrcAlpha
 Pass {CGPROGRAM
 #pragma vertex vert
 #pragma fragment frag
 #include "UnityCG.cginc"
 sampler2D _MainTex,_Beam;float _Opacity,_BeamX,_BeamOn,_OcclusionOpacity;
 struct V{float4 p:POSITION;float2 uv:TEXCOORD0;};
 struct F{float4 p:SV_POSITION;float2 uv:TEXCOORD0;float2 logical:TEXCOORD1;};
 F vert(V v){F f;f.p=UnityObjectToClipPos(v.p);f.uv=v.uv;f.logical=float2(v.p.x,32-v.p.y);return f;}
 float4 frag(F f):SV_Target{
  float4 glyph=tex2D(_MainTex,f.uv);
  float alpha=glyph.a*_Opacity;
  float4 result=float4(glyph.rgb*alpha,alpha);
  float u=(f.logical.x-_BeamX)/72;
  if(_BeamOn>0.5&&u>=0&&u<1){
   float4 beam=tex2D(_Beam,float2(u,0.5));
   // Canvas destination-in quantizes the authored glyph mask to RGBA8.
   float a=floor(beam.a*glyph.a*255+0.5)/255;
   result=float4(beam.rgb*a,a)+result*(1-a);
  }
  // Attenuate both the glyph and its original sweep, preserving premultiplication.
  // The whole row fades; original spotlight and pulse remain independent.
  return result*_OcclusionOpacity;
 }
 ENDCG}
 }
}


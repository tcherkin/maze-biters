Shader "MazeBiters/CreatureEye" {Properties {_MainTex("Authored eye mask",2D)="black"{} _Amount("Amount",Float)=1}
SubShader {Pass {Cull Off ZWrite Off ZTest Always Blend One OneMinusSrcAlpha
CGPROGRAM
#pragma vertex vert_img
#pragma fragment frag
#include "UnityCG.cginc"
sampler2D _MainTex;float _Amount;
float4 frag(v2f_img i):SV_Target {float a=tex2D(_MainTex,i.uv).a*_Amount;return float4(float3(1,246.0/255,203.0/255)*a,a);}
ENDCG
}}}

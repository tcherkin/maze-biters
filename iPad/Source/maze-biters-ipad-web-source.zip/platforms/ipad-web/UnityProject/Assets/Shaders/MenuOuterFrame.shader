Shader "MazeBiters/MenuOuterFrame" {
 Properties {
  _Dimensions("Viewport size, inset, corner radius",Vector)=(1024,768,8,22)
  _Glow("Restrained frame halo",Float)=.6
  _SoftFrame("Feathered champagne reflections",Float)=0
 }
 SubShader {
  Tags {"Queue"="Transparent" "RenderType"="Transparent"}
  Cull Off ZWrite Off ZTest Always Blend One OneMinusSrcAlpha
  Pass {
   CGPROGRAM
   #pragma vertex vert
   #pragma fragment frag
   #pragma target 3.0
   #include "UnityCG.cginc"
   float4 _Dimensions;float _Glow,_SoftFrame;
   struct V {float4 p:POSITION;float2 uv:TEXCOORD0;};
   struct F {float4 p:SV_POSITION;float2 uv:TEXCOORD0;};
   F vert(V v){F o;o.p=UnityObjectToClipPos(v.p);o.uv=v.uv;return o;}
   float roundedDistance(float2 p,float2 halfSize,float radius){
    float2 q=abs(p)-halfSize+radius;
    return min(max(q.x,q.y),0)+length(max(q,0))-radius;
   }
   float frameStroke(float d,float centre,float halfWidth,float aa){
    return 1-smoothstep(halfWidth-aa,halfWidth+aa,abs(d-centre));
   }
   float4 frag(F f):SV_Target {
    float2 uv=float2(f.uv.x,1-f.uv.y),size=_Dimensions.xy;
    float2 p=uv*size-size*.5;
    float d=roundedDistance(p,size*.5-_Dimensions.z,_Dimensions.w);
    float aa=max(.16,fwidth(d)*.55);
    // A narrow champagne bevel, a darker inward chamfer and a fine inner
    // reflection evoke the original double outline without a solid panel.
    float rim=frameStroke(d,0,.66,aa);
    float chamfer=frameStroke(d,-1.45,.46,aa);
    float hairline=frameStroke(d,-4.7,.26,aa);
    float support=1-smoothstep(7,11,abs(d));
    float halo=exp2(-d*d/12)*support;
    float top=pow(saturate(1-uv.y),1.4);
    float highlightA=(uv.x-.19)/.30,highlightB=(uv.x-.92)/.18;
    float polished=exp2(-highlightA*highlightA)*top;
    polished+=exp2(-highlightB*highlightB)*uv.y*uv.y*.40;
    float3 champagne=lerp(float3(.36,.27,.14),float3(.74,.63,.42),top);
    float3 pearl=float3(1,.94,.78);
    float3 rgb=champagne*rim*.73;
    rgb+=float3(.23,.16,.075)*chamfer*.35;
    rgb+=lerp(float3(.29,.21,.105),float3(.61,.50,.30),top)*hairline*.27;
    rgb+=pearl*rim*polished*.19;
    rgb+=float3(.22,.15,.065)*halo*.11*_Glow;
    // Only outside the rounded border: lightly seat the rim against the sky.
    // The entire interior more than eleven logical pixels from it is exactly
    // transparent, preserving the maze, text and animation pixels underneath.
    float outside=smoothstep(-.2,5,d)*.40;
    float alpha=saturate(rim*.78+chamfer*.35+hairline*.27+halo*.07*_Glow+outside);
    if(_SoftFrame>.5){
     // Let polished rounded corners catch light; long runs dissolve smoothly
     // toward their centres. This is static surface shading, not a blinking rim.
     float2 edgeDistance=abs(p)-(size*.5-_Dimensions.z);
     float vertical=smoothstep(-18,18,edgeDistance.x-edgeDistance.y);
     float along=lerp(abs(uv.x-.5)*2,abs(uv.y-.5)*2,vertical);
     float envelope=.16+.84*pow(saturate(along),1.8);
     float broad=exp2(-d*d/30)*(1-smoothstep(10,17,abs(d)));
     float softInner=exp2(-(d+3.1)*(d+3.1)/3.6)*support;
     float pearlCatch=pow(saturate(along),5)*(.35+.65*top);
     rgb=champagne*rim*.68*envelope;
     rgb+=float3(.34,.25,.125)*softInner*.16*envelope;
     rgb+=pearl*rim*pearlCatch*.23;
     rgb+=float3(.30,.21,.10)*broad*.14*_Glow*envelope;
     rgb+=float3(.55,.44,.25)*hairline*.12*envelope;
     alpha=saturate(rim*.70*envelope+softInner*.17*envelope+hairline*.12*envelope+broad*.07*_Glow*envelope+outside);
    }
    return float4(rgb,alpha);
   }
   ENDCG
  }
 }
 Fallback Off
}

"""Stage an already-tested web build under iPad/; never commit or push it."""
from pathlib import Path
import hashlib
import json
import re
import shutil
import subprocess
import zipfile

HERE = Path(__file__).resolve().parent
CHECKOUT = HERE / "Publish"
BUILD = HERE / "Builds/iPad"
MAX_FILE = 100 * 1024 * 1024
PAYLOAD_ROOT = "StreamingAssets/WebPayload/"


def digest(path):
    with path.open("rb") as stream:
        return hashlib.file_digest(stream, "sha256").hexdigest()


def safe(root, relative):
    path = (root / relative).resolve()
    if not path.is_relative_to(root.resolve()):
        raise ValueError("Path escapes intended directory")
    return path


def git(*args):
    return subprocess.check_output(["git", "-C", str(CHECKOUT), *args], text=True).rstrip("\r\n")


def sibling_site_bytes():
    total = 0
    for line in git("ls-tree", "-rl", "HEAD").splitlines():
        metadata, name = line.split("\t", 1)
        if name.startswith("iPad/"):
            continue
        if name.startswith("iPhone/.runtime/"):
            # iPhone serves these immutable files from pinned raw Git URLs;
            # default Jekyll excludes them from the Pages site itself.
            if (CHECKOUT / ".nojekyll").exists() or (CHECKOUT / "_config.yml").exists():
                raise ValueError("Hidden runtime budget requires the unchanged default Jekyll exclusion policy")
            continue
        total += int(metadata.split()[-1])
    return total


def committed_release():
    result = subprocess.run(["git", "-C", str(CHECKOUT), "show", "HEAD:iPad/release.json"], capture_output=True)
    if result.returncode:
        return {}
    return json.loads(result.stdout)


def compatibility_records(baseline, current, build_guid=None):
    """Retain the previous release's own runtime, never its inherited runtime."""
    guid = baseline.get("buildGuid")
    previous_manifest = PAYLOAD_ROOT + ("manifest-" + guid + ".json" if guid else "manifest.json")
    latest = {entry["path"]: entry for entry in current}
    retained = []
    same_build = bool(build_guid and guid == build_guid)
    entries = baseline.get("compatibilityFiles", []) if same_build else baseline.get("currentFiles", baseline.get("files", []))
    for entry in entries:
        name = entry["path"]
        runtime = same_build or name.startswith("Build/") or name == previous_manifest or name.startswith(PAYLOAD_ROOT) and name.endswith(".mbpack.gz")
        if not runtime:
            continue
        if name in latest:
            if latest[name]["sha256"] != entry["sha256"] or latest[name]["bytes"] != entry["bytes"]:
                raise ValueError("Current build would overwrite an immutable previous runtime resource: " + name)
        else:
            retained.append(entry)
    return retained


def source_archive(destination):
    files = []
    project = HERE / "UnityProject"
    for directory in ("Assets", "Packages", "ProjectSettings"):
        for file in (project / directory).rglob("*"):
            if not file.is_file():
                continue
            relative = file.relative_to(project).as_posix()
            # Content is already published in the hash packs, not duplicated in
            # this archive. Keep StreamingAssets.meta for its stable folder GUID.
            if relative.startswith("Assets/StreamingAssets/"):
                continue
            files.append((file, "UnityProject/" + relative))
    helpers = ("restore-source-assets.py", "pack-web-assets.py", "prepare-publication.py", "export-web-sfx.py", "adapt-web-crystals.py", "DEPLOYMENT.md", "README-WEB.md", "Results/audit/web-shell-contract.cjs", "Results/audit/WebPayloadChecks.cs")
    helpers += tuple(path.name for path in HERE.glob("test-web-*.cjs"))
    for name in helpers:
        file = HERE / name
        if not file.is_file():
            raise FileNotFoundError(name)
        files.append((file, name))
    archive_root = "platforms/ipad-web/"
    source_manifest = []
    private_path = re.compile(r"(?:[A-Za-z]:[\\/](?:Users|Program Files)|\x2fUsers\x2f|\x2fhome\x2f[^ /]+\x2f)", re.IGNORECASE)
    text_extensions = {".cs", ".shader", ".json", ".asset", ".unity", ".py", ".md", ".js", ".jslib", ".cjs", ".html", ".meta", ".txt"}
    with zipfile.ZipFile(destination, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
        for file, relative in sorted(files, key=lambda item: item[1]):
            safe(project if relative.startswith("UnityProject/") else HERE, file.relative_to(project if relative.startswith("UnityProject/") else HERE))
            data = file.read_bytes()
            if file.suffix.lower() in text_extensions:
                text = data.decode("utf-8-sig")
                if private_path.search(text):
                    raise ValueError("Local machine path in public source: " + relative)
            info = zipfile.ZipInfo(archive_root + relative, date_time=(1980, 1, 1, 0, 0, 0))
            info.compress_type = zipfile.ZIP_DEFLATED
            info.external_attr = 0o100644 << 16
            archive.writestr(info, data)
            source_manifest.append({"path": relative, "bytes": len(data), "sha256": hashlib.sha256(data).hexdigest()})
        info = zipfile.ZipInfo(archive_root + "source-manifest.json", date_time=(1980, 1, 1, 0, 0, 0))
        info.compress_type = zipfile.ZIP_DEFLATED
        archive.writestr(info, json.dumps({"version": 1, "files": source_manifest}, indent=2) + "\n")
    with zipfile.ZipFile(destination) as archive:
        if archive.testzip() is not None:
            raise ValueError("Source ZIP verification failed")
    return len(source_manifest)


def main():
    if HERE.name != "ipad-web" or HERE.parent.name != "platforms":
        raise ValueError("Unexpected working project")
    if git("remote", "get-url", "origin") != "https://github.com/tcherkin/maze-biters.git":
        raise ValueError("Deployment checkout has an unexpected origin")
    if git("rev-parse", "HEAD") != git("rev-parse", "origin/main"):
        raise ValueError("Deployment HEAD must equal the fetched origin/main before staging")
    for line in git("status", "--porcelain", "--untracked-files=all").splitlines():
        if line and not line[3:].replace("\\", "/").startswith("iPad/"):
            raise ValueError("Deployment contains changes outside iPad/: " + line)
    root_bytes = sibling_site_bytes()
    if not (BUILD / "index.html").is_file():
        raise ValueError("Build output is incomplete: index.html missing")
    info = json.loads((BUILD / "build-info.json").read_text(encoding="utf-8-sig"))
    guid = info["buildGuid"]
    if not re.fullmatch(r"[0-9a-fA-F]{32}", guid) or info["assetManifest"] != "manifest-" + guid + ".json":
        raise ValueError("Invalid build/asset manifest identity")
    index = (BUILD / "index.html").read_text(encoding="utf-8-sig")
    build_paths = set(re.findall(r"Build/[^\s'\"<>?]+", index))
    if len(build_paths) != 4 or not any(".wasm" in name for name in build_paths):
        raise ValueError("Current HTML must reference the four Unity build resources")
    if any(not safe(BUILD, name).is_file() for name in build_paths):
        raise ValueError("An HTML-referenced Unity resource is missing")
    destination = safe(CHECKOUT, "iPad")
    destination.mkdir(parents=True, exist_ok=True)
    previous = destination / "release.json"
    managed = []
    if previous.is_file():
        managed = json.loads(previous.read_text(encoding="utf-8"))["files"]
    baseline = committed_release()
    expected = set()
    # Preserve byte-for-byte checksums even when the parent repository enables
    # text normalization. This policy applies only inside the published iPad/.
    (destination / ".gitattributes").write_bytes(b"# Release checksums require the exact generated bytes.\n* -text !eol\n")
    expected.add(".gitattributes")
    payload = json.loads((BUILD / PAYLOAD_ROOT / "manifest.json").read_text(encoding="utf-8"))
    canonical = BUILD / PAYLOAD_ROOT / "manifest.json"
    versioned = BUILD / PAYLOAD_ROOT / info["assetManifest"]
    if versioned.read_bytes() != canonical.read_bytes():
        raise ValueError("Versioned manifest differs from canonical restore manifest")
    allowed_payload = {PAYLOAD_ROOT + "manifest.json", PAYLOAD_ROOT + info["assetManifest"]} | {PAYLOAD_ROOT + pack["file"] for pack in payload["packs"]}
    for file in sorted(BUILD.rglob("*")):
        if not file.is_file() or file.suffix == ".meta":
            continue
        relative = file.relative_to(BUILD).as_posix()
        if relative.startswith("Build/") and relative not in build_paths:
            continue
        if relative.startswith("StreamingAssets/") and relative not in allowed_payload:
            continue
        if file.stat().st_size >= MAX_FILE:
            raise ValueError("Build file exceeds safe Git limit: " + relative)
        target = safe(destination, relative)
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(file, target)
        expected.add(relative)
    for item in payload["packs"]:
        file = safe(destination / PAYLOAD_ROOT, item["file"])
        if file.stat().st_size != item["bytes"] or digest(file) != item["sha256"]:
            raise ValueError("Published pack verification failed: " + item["file"])
    shutil.copy2(HERE / "README-WEB.md", destination / "README.md")
    expected.add("README.md")
    archive = safe(destination, "Source/maze-biters-ipad-web-source.zip")
    archive.parent.mkdir(parents=True, exist_ok=True)
    count = source_archive(archive)
    if archive.stat().st_size >= MAX_FILE:
        raise ValueError("Source archive exceeds safe Git limit")
    expected.add("Source/maze-biters-ipad-web-source.zip")
    current = [{"path": name, "bytes": (destination / name).stat().st_size, "sha256": digest(destination / name)} for name in sorted(expected) if name != ".gitattributes"]
    compatibility = compatibility_records(baseline, current, guid)
    for entry in compatibility:
        file = safe(destination, entry["path"])
        if not file.is_file() or file.stat().st_size != entry["bytes"] or digest(file) != entry["sha256"]:
            raise ValueError("Previous runtime resource is missing or was modified: " + entry["path"])
        expected.add(entry["path"])
    # Remove only files owned by our previous release manifest, and only when
    # still byte-identical to that manifest. Never recursively delete a folder.
    for old in managed:
        if old["path"] in expected:
            continue
        file = safe(destination, old["path"])
        if file.is_file():
            if digest(file) != old["sha256"]:
                raise ValueError("Refusing to remove modified previous artifact: " + old["path"])
            file.unlink()
    evidence = sorted(current + compatibility, key=lambda entry: entry["path"])
    total_bytes = sum(entry["bytes"] for entry in evidence)
    if root_bytes + total_bytes >= 990000000:
        raise ValueError("Published site would exceed the safe GitHub Pages size budget")
    if any(entry["bytes"] >= MAX_FILE for entry in evidence):
        raise ValueError("A retained artifact exceeds the safe Git file limit")
    # GitHub Pages deliberately omits dotfiles. Keep repository metadata out of
    # the served-artifact manifest rather than advertising an expected HTTP 404.
    report = {"version": 2, "product": "Maze Biters iPad Web", "engine": "Unity 6000.6.3f1", "baseCommit": git("rev-parse", "HEAD"), "buildGuid": guid, "assetManifest": PAYLOAD_ROOT + info["assetManifest"], "sourceFiles": count, "runtimeFiles": payload["verifiedFiles"], "repositoryOnlyFiles": [".gitattributes"], "currentFiles": current, "compatibilityFiles": compatibility, "files": evidence, "totalBytes": total_bytes, "siteBytes": root_bytes + total_bytes}
    (destination / "release.json").write_text(json.dumps(report, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({"prepared": True, "directory": "Publish/iPad", "files": len(evidence) + 2, "sourceFiles": count, "totalMiB": round(report["totalBytes"] / 1048576, 3), "sourceZipMiB": round(archive.stat().st_size / 1048576, 3), "baseCommit": report["baseCommit"], "committed": False, "pushed": False}, indent=2))


if __name__ == "__main__":
    main()

"""Lossless, repeatable Web Audio SFX bank from the approved source WAV files."""
import hashlib
import json
from pathlib import Path
import struct
import wave

ROOT = Path(__file__).resolve().parent
PROJECT = ROOT / "UnityProject"
STREAMING = ROOT / "SourceAssets" if (ROOT / "SourceAssets").is_dir() else PROJECT / "Assets/StreamingAssets"

def text_bytes(value):
    encoded = value.encode("utf-8")
    size = len(encoded)
    prefix = bytearray()
    while size >= 128:
        prefix.append((size & 127) | 128)
        size >>= 7
    prefix.append(size)
    return bytes(prefix) + encoded

def main():
    manifest = json.loads((STREAMING / "Reference/session-audio.json").read_text(encoding="utf-8"))
    data = bytearray(struct.pack("<ii", 0x4D425741, len(manifest["sounds"])))
    sources = []
    for entry in manifest["sounds"]:
        source = PROJECT / "Assets/Resources/SessionAudio" / (entry["id"] + ".wav")
        with wave.open(str(source), "rb") as clip:
            assert clip.getcomptype() == "NONE", source
            channels, rate, width, frames = clip.getnchannels(), clip.getframerate(), clip.getsampwidth(), clip.getnframes()
            assert channels in (1, 2) and width in (1, 2, 3, 4), source
            raw = clip.readframes(frames)
        data.extend(text_bytes(entry["name"]))
        data.extend(struct.pack("<iii", channels, rate, frames * channels))
        for offset in range(0, len(raw), width):
            sample = raw[offset:offset + width]
            value = (sample[0] - 128) / 128 if width == 1 else int.from_bytes(sample, "little", signed=True) / (2 ** (8 * width - 1))
            data.extend(struct.pack("<f", value))
        sources.append({"id": entry["id"], "name": entry["name"], "sha256": hashlib.sha256(source.read_bytes()).hexdigest(), "channels": channels, "rate": rate, "frames": frames})
    target = STREAMING / "WebAudio/sfx.bytes"
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_bytes(data)
    report = {"sounds": sources, "bytes": len(data), "sha256": hashlib.sha256(data).hexdigest(), "note": "Original PCM amplitudes and sample rates, interleaved float32; no AAC/OGG conversion. Web Audio uses the original bus gain/panning/compressor settings. Browser resampling may differ from native playback."}
    (ROOT / "web-sfx-export.json").write_text(json.dumps(report, indent=2), encoding="utf-8")
    print(json.dumps({"sounds": len(sources), "bytes": len(data), "sha256": report["sha256"]}))

if __name__ == "__main__":
    main()

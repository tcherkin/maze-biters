"""Restore exact runtime SourceAssets and build payload from a published iPad build."""
from pathlib import Path
import argparse
import gzip
import hashlib
import io
import json
import shutil
import struct


def safe(root, relative):
    if not relative or "\\" in relative or Path(relative).is_absolute() or ".." in Path(relative).parts:
        raise ValueError("Unsafe relative path")
    path = (root / relative).resolve()
    if not path.is_relative_to(root.resolve()):
        raise ValueError("Path escapes destination")
    return path


def main():
    here = Path(__file__).resolve().parent
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("payload", type=Path, help="Published iPad/StreamingAssets/WebPayload folder containing manifest.json and gzip packs")
    args = parser.parse_args()
    payload = args.payload.resolve()
    manifest = json.loads((payload / "manifest.json").read_text(encoding="utf-8"))
    expected = {x["path"]: x for x in manifest["requiredSources"]}
    sources = here / "SourceAssets"
    copies = (here / "WebPayload", here / "UnityProject/Assets/StreamingAssets/WebPayload")
    seen = set()
    for item in manifest["packs"]:
        path = safe(payload, item["file"])
        blob = path.read_bytes()
        if len(blob) != item["bytes"] or hashlib.sha256(blob).hexdigest() != item["sha256"]:
            raise ValueError("Pack integrity failure: " + item["file"])
        raw = gzip.decompress(blob)
        if len(raw) != item["rawBytes"]:
            raise ValueError("Pack length mismatch")
        reader = io.BytesIO(raw)
        while True:
            header = reader.read(4)
            if len(header) != 4:
                raise ValueError("Missing pack terminator")
            size, = struct.unpack("<i", header)
            if size == 0:
                if reader.read():
                    raise ValueError("Trailing bytes")
                break
            if not 0 < size <= 4096:
                raise ValueError("Invalid path size")
            key = reader.read(size).decode("utf-8")
            length, = struct.unpack("<i", reader.read(4))
            if length < 0 or length > 134217728:
                raise ValueError("Invalid file size")
            data = reader.read(length)
            evidence = expected.get(key)
            if key in seen or evidence is None or evidence["pack"] != item["file"] or len(data) != evidence["bytes"] or hashlib.sha256(data).hexdigest() != evidence["sha256"]:
                raise ValueError("Source integrity failure: " + key)
            target = safe(sources, key)
            target.parent.mkdir(parents=True, exist_ok=True)
            if target.exists() and target.read_bytes() != data:
                raise ValueError("Refusing to replace a changed source file: " + key)
            target.write_bytes(data)
            seen.add(key)
        for folder in copies:
            folder.mkdir(parents=True, exist_ok=True)
            target = safe(folder, item["file"])
            if target != path:
                shutil.copy2(path, target)
    if seen != expected.keys():
        raise ValueError("Incomplete source set")
    for folder in copies:
        target = folder / "manifest.json"
        if target.resolve() != (payload / "manifest.json").resolve():
            shutil.copy2(payload / "manifest.json", target)
    print(json.dumps({"passed": True, "restoredFiles": len(seen), "packs": len(manifest["packs"])}))


if __name__ == "__main__":
    main()

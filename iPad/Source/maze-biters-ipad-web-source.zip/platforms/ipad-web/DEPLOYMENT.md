# Rebuilding and publishing the isolated iPad Web edition

This directory is the web-specific Unity fork. Keep it at `platforms/ipad-web`.
The native iPad, PC Unity and original browser projects are independent.

## Reconstruct a published source archive

1. Extract `Source/maze-biters-ipad-web-source.zip` at a workspace root.
2. Obtain the published `iPad/StreamingAssets/WebPayload` directory, including `manifest.json`
   and every hash-named pack listed in it. A clone of the release repository includes them.
3. From the workspace root, run:

   ```text
   python platforms/ipad-web/restore-source-assets.py iPad/StreamingAssets/WebPayload
   ```

   This verifies every pack and restored source file. It restores `SourceAssets`
   for Editor use, plus `WebPayload` and the small compressed payload inside the
   Unity project's `Assets/StreamingAssets/WebPayload` directory. It does not restore excluded
   visual-test screenshots or captured legacy levels; these are not needed by the
   interactive web build. Full legacy validation commands require the separate
   original development fixtures.

## Build

Use Unity **6000.6.3f1** with **Web Build Support** installed. The project stores its
package versions in `Packages/manifest.json` and `packages-lock.json`.

For a source-art or sound change, regenerate the payload first:

```text
python platforms/ipad-web/export-web-sfx.py
python platforms/ipad-web/pack-web-assets.py
```

Copy only the packs named by `WebPayload/manifest.json` and that manifest into
`UnityProject/Assets/StreamingAssets/WebPayload`. The raw `SourceAssets` must remain outside
Unity `Assets`; otherwise Unity also packages the large uncompressed source set.

From the Unity command line, use these arguments with your installed Unity executable:

```text
-batchmode -quit -projectPath platforms/ipad-web/UnityProject -buildTarget WebGL -executeMethod WebBuild.Build -logFile web-build.log
```

The output is `platforms/ipad-web/Builds/iPad`. `WebBuild` selects WebGL2, disables
C# threads, keeps the approved shaders, and uses Gzip with decompression fallback
so the build works on GitHub Pages without custom response headers.

Serve the output through HTTP, not `file://`. Check startup, mode selection while
loading, touch/menu input, quality switching, audio after a gesture, GAME OVER and
restart, plus HD/high-resolution play. Inspect browser errors and test Mobile
Safari on a real device before claiming device performance.

## Prepare an additive repository change

The deployment checkout belongs at `platforms/ipad-web/Publish`, with origin
`https://github.com/tcherkin/maze-biters.git`. It must track the current `main`.
Use an independent clone; do not replace the original game's checkout.

After testing the final build:

```text
python platforms/ipad-web/prepare-publication.py
git -C platforms/ipad-web/Publish diff --stat
git -C platforms/ipad-web/Publish status --short
```

The preparation tool writes only `Publish/iPad`, checks the 100 MiB Git file limit,
creates a reproducible source ZIP without caches/logs/local paths, and writes a
release manifest. It does **not** commit, push, or change GitHub settings.
The generated `iPad/.gitattributes` preserves exact artifact bytes, including
JSON line endings, so Git's text conversion cannot invalidate the release hashes.

Review that every change is under `iPad/`. Stage and commit that directory only.
Fetch `origin/main` again immediately before pushing; if it changed, reconcile the
additive directory on the newer main without overwriting unrelated changes.

The repository already publishes GitHub Pages from `main` at `/`. No new Pages
workflow or settings change is required. Pushing the additive `iPad/` directory
publishes `https://tcherkin.github.io/maze-biters/iPad/` while retaining the original
game at `https://tcherkin.github.io/maze-biters/`.

After deployment, verify the iPad page, build files and packs return successful
responses, check the in-browser game again, and confirm the original root page is
unchanged. GitHub Pages limits the complete published site to 1 GB; ordinary Git
files must remain below 100 MiB. Keep old build artifacts out of `iPad/` on updates.

using System;using System.IO;using System.IO.Compression;using System.Collections.Generic;using System.Security.Cryptography;using System.Text;using System.Web.Script.Serialization;
namespace MazeBiters.NativeStudy {
 // Only Unity's outer data types are stubbed. The tested validator, hashing,
 // and unpacker are compiled directly from the runtime WebPayload.cs file.
 public class WebBootstrap {
  public class Pack {public string file,stage,sha256;public long bytes,rawBytes;public int fileCount;}
  public class Manifest {public int version;public Pack[] packs;}
 }
 class WebPayloadChecks {
  static int checks;static readonly List<string> names=new List<string>();
  static void Check(string name,bool ok){checks++;if(!ok)throw new Exception("FAIL: "+name);names.Add(name);}
  static void Reject(string name,Action work){bool rejected=false;try{work();}catch(InvalidDataException){rejected=true;}catch(EndOfStreamException){rejected=true;}Check(name,rejected);}
  static int Drain(IEnumerable<object> steps){int count=0;foreach(var item in steps)count++;return count;}
  static byte[] Package(string name,byte[] content,bool trailing,out long rawLength){using(var raw=new MemoryStream()){using(var w=new BinaryWriter(raw,Encoding.UTF8,true)){byte[] n=Encoding.UTF8.GetBytes(name);w.Write(n.Length);w.Write(n);w.Write(content.Length);w.Write(content);w.Write(0);if(trailing)w.Write(1234);}rawLength=raw.Length;using(var compressed=new MemoryStream()){using(var gzip=new GZipStream(compressed,CompressionMode.Compress,true))gzip.Write(raw.GetBuffer(),0,(int)raw.Length);return compressed.ToArray();}}}
  static WebBootstrap.Pack Pack(byte[] data,long raw){using(var digest=SHA256.Create())return new WebBootstrap.Pack{file="runtime-test.mbpack.gz",stage="runtime",bytes=data.Length,rawBytes=raw,fileCount=1,sha256=BitConverter.ToString(digest.ComputeHash(data)).Replace("-","").ToLowerInvariant()};}
  public static int Main(string[] args){try{
   string root=Path.GetFullPath(args[0]);Directory.CreateDirectory(root);
   byte[] content=new byte[2000000];new Random(34).NextBytes(content);long raw;var data=Package("Art/example.bin",content,false,out raw);var pack=Pack(data,raw);
   Check("hashing yields within 2ms or 512 KiB work slices",Drain(WebPayload.Verify(pack,data))>=3);
   Check("unpacking yields across 128 KiB slices",Drain(WebPayload.Unpack(pack,data,Path.Combine(root,"valid")))>=3);
   Check("unpacked content is byte identical",Convert.ToBase64String(File.ReadAllBytes(Path.Combine(root,"valid/Art/example.bin")))==Convert.ToBase64String(content));
   var broken=(byte[])data.Clone();broken[broken.Length/2]^=0x40;Reject("corrupted compressed response rejected before extraction",()=>Drain(WebPayload.Verify(pack,broken)));
   Reject("truncated HTTP success response rejected",()=>Drain(WebPayload.Verify(pack,new byte[data.Length-1])));
   var wrong=Pack(data,raw+1);Reject("wrong uncompressed dimensions rejected",()=>Drain(WebPayload.Unpack(wrong,data,Path.Combine(root,"wrong-size"))));
   wrong=Pack(data,raw);wrong.fileCount=2;Reject("wrong file count rejected",()=>Drain(WebPayload.Unpack(wrong,data,Path.Combine(root,"wrong-count"))));
   foreach(string name in new[]{"../outside","/absolute","Art/../../outside","Art\\outside","Art/./file","Art//file","C:/outside"}){long n;var bytes=Package(name,new byte[]{1},false,out n);var p=Pack(bytes,n);Reject("reject path "+name,()=>Drain(WebPayload.Unpack(p,bytes,Path.Combine(root,"invalid-path"))));}
   long tailLength;var tail=Package("valid.bin",new byte[]{1},true,out tailLength);var tailPack=Pack(tail,tailLength);Reject("trailing decoded payload rejected",()=>Drain(WebPayload.Unpack(tailPack,tail,Path.Combine(root,"trailing"))));
   var menu=Pack(data,raw);menu.file="menu-test.mbpack.gz";menu.stage="menu";var valid=new WebBootstrap.Manifest{version=1,packs=new[]{menu,pack}};WebPayload.Validate(valid);Check("valid staged manifest accepted",true);
   Reject("missing pack list rejected before caching",()=>WebPayload.Validate(new WebBootstrap.Manifest{version=1}));
   Reject("empty pack list rejected before caching",()=>WebPayload.Validate(new WebBootstrap.Manifest{version=1,packs=new WebBootstrap.Pack[0]}));
   Reject("unsupported manifest version rejected",()=>WebPayload.Validate(new WebBootstrap.Manifest{version=2,packs=valid.packs}));
   Reject("late menu stage rejected",()=>WebPayload.Validate(new WebBootstrap.Manifest{version=1,packs=new[]{pack,menu}}));
   Reject("duplicate package rejected",()=>WebPayload.Validate(new WebBootstrap.Manifest{version=1,packs=new[]{menu,pack,pack}}));
   WebBootstrap.Manifest cached=null;try{var candidate=new WebBootstrap.Manifest{version=1};WebPayload.Validate(candidate);cached=candidate;}catch(InvalidDataException){}Check("invalid manifest never retained across retry",cached==null);WebPayload.Validate(valid);cached=valid;Check("subsequent corrected manifest can be accepted",cached==valid);
   var json=new JavaScriptSerializer{MaxJsonLength=int.MaxValue};var actual=json.Deserialize<WebBootstrap.Manifest>(File.ReadAllText(args[1]));WebPayload.Validate(actual);int slices=0;foreach(var p in actual.packs)slices+=Drain(WebPayload.Verify(p,File.ReadAllBytes(Path.Combine(Path.GetDirectoryName(args[1]),p.file))));Check("all actual release package digests verified",actual.packs.Length>0&&slices>=actual.packs.Length);
   var report=new{passed=true,checks=checks,actualPackages=actual.packs.Length,hashSlices=slices,names=names,note="Actual runtime WebPayload implementation compiled on Mono; not a browser performance measurement."};var output=json.Serialize(report);File.WriteAllText(Path.Combine(root,"report.json"),output);Console.WriteLine(output);return 0;
  }catch(Exception e){Console.Error.WriteLine(e);return 1;}}
 }
}

"""Package the isolated iPad Web runtime's immutable files without changing sources.

Each gzip stream expands to repeated little-endian int32 path length, UTF-8
relative path, int32 data length, bytes; a zero path length terminates the pack.
Files are never split across packs. The ~8 MiB target is exceeded only by a
single source larger than the target (currently PreparedLight.bytes).
"""
from __future__ import annotations

import argparse
import gzip
import hashlib
import io
import json
import re
import struct
from pathlib import Path

HERE = Path(__file__).resolve().parent
SOURCE = HERE / "SourceAssets" if (HERE / "SourceAssets").is_dir() else HERE / "UnityProject" / "Assets" / "StreamingAssets"
DESTINATION = HERE / "WebPayload"
SCRIPTS = HERE / "UnityProject" / "Assets" / "Scripts"
MAX_RAW = 8 * 1024 * 1024
THEMES = ("green", "orange", "blue-violet", "ruby-red", "turquoise", "gold")


def beneath(path: Path, root: Path) -> Path:
    resolved = path.resolve()
    if not resolved.is_relative_to(root.resolve()):
        raise ValueError(f"Path escaped its allowed root: {path}")
    return resolved


def select_sources():
    selected: dict[str, dict] = {}
    exclusions: list[dict] = []

    def add(relative, stage, evidence):
        key = Path(relative).as_posix()
        if key.startswith("/") or ".." in Path(key).parts or "\\" in key:
            raise ValueError(f"Unsafe virtual filesystem path: {key}")
        path = beneath(SOURCE / key, SOURCE)
        if not path.is_file():
            raise FileNotFoundError(f"Required runtime source is missing: {key}")
        if key in selected and selected[key]["stage"] != stage:
            raise ValueError(f"Conflicting loading stages for {key}")
        selected.setdefault(key, {"path": key, "stage": stage, "requiredBy": evidence})

    # Follow renderer manifests, not directory-wide screenshots. Their `cases`
    # are reference-only and are never used by the interactive renderer.
    for family, consumer in (("menu", "NativeMenuRenderer.cs"), ("records", "NativeRecordRenderer.cs")):
        for quality in ("hd", "4k"):
            manifest = f"Reference/{family}/{quality}.json"
            add(manifest, "menu", f"{consumer}: manifest + entries")
            spec = json.loads((SOURCE / manifest).read_text(encoding="utf-8"))
            for item in spec["entries"]:
                add(f"Reference/{family}/{item['file']}", "menu", f"{manifest}: entries[{item['id']}]")
    add("Reference/session-audio.json", "menu", "NativeSessionAudio.cs: sound names and playback rules")
    add("WebAudio/sfx.bytes", "menu", "NativeWebAudio.cs: original interleaved PCM sound bank")

    for path in sorted((SOURCE / "Art").rglob("*")):
        if path.is_file() and path.suffix != ".meta":
            add(path.relative_to(SOURCE), "runtime", "PackedArt.cs: all authored palettes, mouth and blink layers")
    for family in ("fantasy", "fantasyMask", "dragon", "dragonEye"):
        add(f"Animation/{family}-cages.json", "runtime", "NativeTurns.cs: authored turning geometry")
    add("PreparedLight.bytes", "runtime", "NativePreparedLight.cs: complete prepared lighting archive")

    # Keep all production paint resources in both densities and all palettes.
    # Legacy brushes are retained because the renderer keeps its approved safe
    # fallback; captured complete level screenshots are not such source brushes.
    for folder in ("maze-brushes", "glass-brushes"):
        for path in sorted((SOURCE / "Reference" / folder).rglob("*")):
            if path.is_file() and path.suffix != ".meta" and path.name != "validation-level.json":
                # The approved menu reuses the blue-violet wall/emission atlas.
                # Make these available before WebBootstrap exposes the menu;
                # they remain the same shared files when runtime loads later.
                relative = path.relative_to(SOURCE)
                menu_atlas = (folder == "glass-brushes" and relative.parts[2] == "blue-violet"
                              and relative.parts[3] in ("hd", "4k")
                              and relative.name in ("wall.rgba.gz", "emission.f32.gz"))
                add(relative, "menu" if menu_atlas else "runtime",
                    "GlassMenuBackdrop + NativeGlassMazeArtwork: shared menu-first atlases"
                    if menu_atlas else "NativeMazeArtwork.cs / NativeGlassMazeArtwork.cs: palette brushes")

    fixture_patterns = (
        r"benchmark-trace\.json", r".*-oracle\.json", r".*-camera\.json",
        r"generator-visual-cases\.json", r".*reference.*", r"pose-.*",
        r".*-turns\.(json|png)", r"anim-(hd|4k)-snakes\.(json|png)",
        r"scorpion-(hd|4k)-ref-\d+\.png", r"scorpion-(hd|4k)-images\.json",
        r"neon-field-\d+\.png", r"neon-points\.json", r"neon-eye-clocks\.json",
        r"light-masks\.(json|png)", r"power-light\.(json|png)", r"session-light\.(json|png)",
    )
    for path in sorted((SOURCE / "Reference").iterdir()):
        if not path.is_file() or path.suffix == ".meta" or path.name == "session-audio.json":
            continue
        if any(re.fullmatch(pattern, path.name) for pattern in fixture_patterns):
            continue
        add(path.relative_to(SOURCE), "runtime", "Runtime Reference bank: masks, neon, pickups, scorpion, deaths, level catalogue, AI warm-up")
    for quality in ("hd", "4k"):
        for kind in ("font", "ai-font", "background", "beam"):
            add(f"Reference/hud/{quality}-{kind}.png", "runtime", "NativeHud.cs: all player-count layouts")

    # Explicitly certify dynamically constructed paths rather than relying on
    # a successful first level to establish completeness.
    required = {"Reference/level.json", "Reference/session-levels.json", "Reference/scorpion-art.json"}
    for theme in THEMES:
        for quality in ("hd", "4k"):
            required.update(f"Reference/glass-brushes/{theme}/{quality}/{name}" for name in (
                "wall.rgba.gz", "emission.f32.gz", "receiver.r8.gz", "receiver-low.r8.gz", "floor-coefficients.f64"))
    for quality in ("hd", "4k"):
        required.add(f"Reference/glass-brushes/common/{quality}/glint-seed.f32.gz")
        for direction in ("left", "right", "up", "down"):
            required.add(f"Reference/intake-{quality}-{direction}.bin")
            for family, palettes in (("fantasy", ("p1", "p2", "ai")), ("dragon", ("h1", "h3", "h4"))):
                for palette in palettes:
                    required.add(f"Reference/anim-{quality}-{family}-{palette}-{direction}-shape.bin")
    for color in ("Green", "Yellow", "Blue", "Pink", "Orange"):
        for part in ("mouth", "solo", "material"):
            for treatment in ("lit", "emission"):
                required.add(f"Reference/neon-{color}-{part}-{treatment}.native.gz")
    missing = sorted(required - selected.keys())
    if missing:
        raise ValueError("Dynamic runtime files missing from selection: " + ", ".join(missing))

    for path in sorted(SOURCE.rglob("*")):
        if not path.is_file() or path.suffix == ".meta":
            continue
        key = path.relative_to(SOURCE).as_posix()
        if key in selected:
            continue
        if key.startswith("Reference/levels/"):
            reason = "Captured legacy level images; interactive Web release generates glass geometry and receivers at runtime"
        elif key.startswith(("Reference/menu/", "Reference/records/")):
            reason = "Not an entries[] dependency; reference screenshot or validation case only"
        elif key.startswith("WebAudio/"):
            reason = "Music is streamed separately through browser Web Audio; not a virtual filesystem PCM bank"
        else:
            reason = "Validation oracle/image; not an interactive runtime resource"
        exclusions.append({"path": key, "bytes": path.stat().st_size, "reason": reason})
    return selected, exclusions


def encode_pack(entries):
    buffer = io.BytesIO()
    for entry in entries:
        key = entry["path"].encode("utf-8")
        data = beneath(SOURCE / entry["path"], SOURCE).read_bytes()
        if len(data) > 0x7FFFFFFF:
            raise ValueError("A file exceeds the binary pack format")
        entry["bytes"] = len(data)
        entry["sha256"] = hashlib.sha256(data).hexdigest()
        buffer.write(struct.pack("<i", len(key)))
        buffer.write(key)
        buffer.write(struct.pack("<i", len(data)))
        buffer.write(data)
    buffer.write(struct.pack("<i", 0))
    return buffer.getvalue()


def verify_pack(blob, entries):
    stream = io.BytesIO(gzip.decompress(blob))
    for expected in entries:
        n, = struct.unpack("<i", stream.read(4))
        key = stream.read(n).decode("utf-8")
        length, = struct.unpack("<i", stream.read(4))
        data = stream.read(length)
        if key != expected["path"] or length != expected["bytes"] or hashlib.sha256(data).hexdigest() != expected["sha256"]:
            raise ValueError(f"Pack round-trip mismatch: {expected['path']}")
    if stream.read() != struct.pack("<i", 0):
        raise ValueError("Missing pack terminator or unexpected trailing bytes")


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--audit-only", action="store_true", help="Validate dependencies and sizes without writing packs")
    args = parser.parse_args()
    if HERE.name != "ipad-web" or HERE.parent.name != "platforms":
        raise ValueError("Run this script only from its isolated platforms/ipad-web location")
    beneath(SOURCE, HERE)
    beneath(DESTINATION, HERE)
    if DESTINATION.resolve().is_relative_to((HERE / "UnityProject" / "Assets").resolve()):
        raise ValueError("Payload output must remain outside Unity Assets")
    selected, excluded = select_sources()
    entries = sorted(selected.values(), key=lambda x: (x["stage"] != "menu", x["path"]))
    summary = {stage: {"files": sum(x["stage"] == stage for x in entries), "sourceBytes": sum((SOURCE / x["path"]).stat().st_size for x in entries if x["stage"] == stage)} for stage in ("menu", "runtime")}
    if args.audit_only:
        print(json.dumps({"passed": True, "stages": summary, "excludedFiles": len(excluded), "excludedBytes": sum(x["bytes"] for x in excluded)}, indent=2))
        return
    DESTINATION.mkdir(parents=True, exist_ok=True)
    packs = []
    for stage in ("menu", "runtime"):
        group, size = [], 4

        def flush():
            if not group:
                return
            raw = encode_pack(group)
            # Explicit filename and mtime make gzip bytes stable across machines.
            compressed = io.BytesIO()
            with gzip.GzipFile(filename="", mode="wb", fileobj=compressed, mtime=0, compresslevel=9) as zipped:
                zipped.write(raw)
            blob = compressed.getvalue()
            verify_pack(blob, group)
            digest = hashlib.sha256(blob).hexdigest()
            name = f"{stage}-{digest[:20]}.mbpack.gz"
            path = beneath(DESTINATION / name, DESTINATION)
            if path.exists() and path.read_bytes() != blob:
                raise ValueError("Hash-named pack unexpectedly conflicts with existing data")
            path.write_bytes(blob)
            packs.append({"file": name, "stage": stage, "bytes": len(blob), "sha256": digest, "rawBytes": len(raw), "fileCount": len(group), "oversizedSingleSource": len(raw) > MAX_RAW})
            for entry in group:
                entry["pack"] = name

        for entry in (x for x in entries if x["stage"] == stage):
            entry_size = 8 + len(entry["path"].encode("utf-8")) + (SOURCE / entry["path"]).stat().st_size
            if group and size + entry_size > MAX_RAW:
                flush()
                group, size = [], 4
            group.append(entry)
            size += entry_size
        flush()
    # Evidence records source consumers and exact immutable file hashes. The
    # runtime needs only packs[]. Nothing is deleted, including old hash packs.
    consumers = sorted({"NativeMenuRenderer.cs", "NativeRecordRenderer.cs", "NativeWebAudio.cs", "NativeSessionAudio.cs", "PackedArt.cs", "NativeTurns.cs", "NativePreparedLight.cs", "NativeMazeArtwork.cs", "NativeGlassMazeArtwork.cs", "NativeHud.cs", "NativeSessionWorld.cs", "NativeNeon.cs", "NativeSnakeTexturePreparation.cs", "NativePickups.cs", "NativeScorpionImages.cs"})
    manifest = {"version": 1, "format": "int32-le pathLength, UTF8 path, int32-le byteLength, bytes; int32 zero terminator; gzip", "targetRawBytes": MAX_RAW, "packs": packs, "requiredSources": entries, "sourceConsumers": [{"file": name, "sha256": hashlib.sha256((SCRIPTS / name).read_bytes()).hexdigest()} for name in consumers], "excludedSources": excluded, "stages": summary}
    manifest["totalBytes"] = sum(p["bytes"] for p in packs)
    manifest["totalRawBytes"] = sum(p["rawBytes"] for p in packs)
    manifest["verifiedFiles"] = len(entries)
    (DESTINATION / "manifest.json").write_text(json.dumps(manifest, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({"passed": True, "output": str(DESTINATION), "files": len(entries), "packs": len(packs), "compressedMiB": round(manifest["totalBytes"] / 1048576, 3), "rawMiB": round(manifest["totalRawBytes"] / 1048576, 3), "stages": summary, "oversizedSingleSource": [p["file"] for p in packs if p["oversizedSingleSource"]]}, indent=2))


if __name__ == "__main__":
    main()

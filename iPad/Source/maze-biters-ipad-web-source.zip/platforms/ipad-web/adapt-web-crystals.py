"""Port the approved native crystal painter into the isolated WebGL copy.

This is deliberately separate from the historical, one-time Web adaptation.
Only renderer hooks are merged into Web-owned files. Cooperative setup methods
are derived from the current native formulas, with yields between bounded work
units; the native project and its source assets are never written.
"""
from pathlib import Path
import hashlib
import uuid

base = Path(__file__).resolve().parent
native = base.parent / "ipad/UnityProject/Assets/Scripts"
web = base / "UnityProject/Assets/Scripts"
source = native if (native / "NativeCrystalCores.cs").is_file() else web


def read(path):
    return path.read_text(encoding="utf-8-sig")


def write(path, text):
    path.write_text(text, encoding="utf-8", newline="\n")
    meta = path.with_name(path.name + ".meta")
    if not meta.exists():
        write_meta = "fileFormatVersion: 2\nguid: " + uuid.uuid4().hex + "\n"
        meta.write_text(write_meta, encoding="utf-8")


def once(text, before, after):
    if before == after:
        return text
    count = text.count(before)
    if count != 1:
        raise RuntimeError(f"Expected one renderer anchor ({count}): {before[:90]}")
    return text.replace(before, after, 1)


def method(text, signature):
    start = text.index(signature)
    brace = text.index("{", start)
    depth = 1
    at = brace + 1
    while depth:
        depth += (text[at] == "{") - (text[at] == "}")
        at += 1
    return text[start:at]


for name in ("NativeCrystalCores.cs", "NativeCrystalStructure.cs",
             "NativeGemCoreMaterial.cs", "CrystalCoreStressAudit.cs"):
    write(web / name, read(source / name))

p = web / "NativeMazeArtwork.cs"
s = read(p)
old = "bool packGlassCache=true){StarSky="
new = "bool packGlassCache=true,bool? crystalCores=null){this.crystalCores=crystalCores??CrystalCoresEnabled;StarSky="
if old in s:
    s = once(s, old, new)
elif new not in s:
    raise RuntimeError("Unrecognized Web maze constructor")
write(p, s)

p = web / "NativeGlassMazeArtwork.cs"
s = read(p)
if "PrepareCrystalMaterial(wall,wallEmission);" not in s:
    s = once(s, "profile.topologyMs=timer.Elapsed.TotalMilliseconds;timer.Restart();",
             "profile.topologyMs=timer.Elapsed.TotalMilliseconds;timer.Restart();PrepareCrystalMaterial(wall,wallEmission);")
if "FinishCrystalTileProbe();" not in s:
    s = once(s, "finally {if(broad.IsCreated)broad.Dispose();",
             "finally {FinishCrystalTileProbe();crystalMaterial=crystalLight=null;coreStructure=null;ReleaseGemCoreMaterialStaging();if(broad.IsCreated)broad.Dispose();")
source_composer = read(source / p.name)
if "Action<int,float[]> GlassComposer(" in source_composer:
    native_composer = method(source_composer, "Action<int,float[]> GlassComposer(")
else:
    native_composer = method(source_composer, "void ComposeGlass(")
    native_composer = once(native_composer,
                       "void ComposeGlass(NativeArray<float> broad,NativeArray<float> edge,NativeArray<float> glints,byte[] wall,float[] emission,byte[] detail,double[] c,float[] streamedSeed=null)",
                       "Action<int,float[]> GlassComposer(NativeArray<float> broad,NativeArray<float> edge,NativeArray<float> glints,byte[] wall,float[] emission,byte[] detail,double[] c)")
    native_composer = once(native_composer,
                       "if(streamedSeed!=null)GlassStreamGlints(streamedSeed,composeRow);else GlassRows(glassHeight,y=>composeRow(y,null));",
                       "return composeRow;")
web_composer = method(s, "Action<int,float[]> GlassComposer(")
s = once(s, web_composer, native_composer)
range_composer = once(native_composer,
                       "Action<int,float[]> GlassComposer(",
                       "Action<int,int,int,float[]> GlassComposerRange(")
range_composer = once(range_composer,
                       "Action<int,float[]> composeRow=(y,streamedGlints)=>{for(int x=0;x<glassWidth;x++)",
                       "Action<int,int,int,float[]> composeRow=(y,xFrom,xTo,streamedGlints)=>{for(int x=xFrom;x<xTo;x++)")
if "Action<int,int,int,float[]> GlassComposerRange(" in s:
    s = once(s, method(s, "Action<int,int,int,float[]> GlassComposerRange("), range_composer)
else:
    s = once(s, native_composer, native_composer + "\n  " + range_composer)
for guard in ("public static readonly int GlassPainterWorkers=1;",
              "if(WebWorkQueue.Capturing)", "WebWorkQueue.Defer(BuildGlassWeb"):
    if guard not in s:
        raise RuntimeError("Lost WebGL painter safeguard: " + guard)
write(p, s)

# Preserve the exact arithmetic and iteration order from the approved source.
# Only control flow between complete units is different on the player loop.
structure = read(source / "NativeCrystalStructure.cs")
curves = method(structure, "void PrepareCoreCurves(byte[] wall)")
curves = once(curves, "void PrepareCoreCurves(", "IEnumerable<object> WebPrepareCoreCurves(")
curves = once(curves, "support[i]=last+.0625;", "support[i]=last+.0625;yield return null;")
curves = once(curves, "if(Error(left)<Error(right))hi=right;else lo=left;",
              "if(Error(left)<Error(right))hi=right;else lo=left;yield return null;")

topology = method(structure, "void PrepareCrystalStructure(byte[] wall)")
topology = once(topology, "void PrepareCrystalStructure(", "IEnumerable<object> WebPrepareCrystalStructure(")
topology = once(topology, "PrepareCoreCurves(wall);",
                "foreach(var step in WebPrepareCoreCurves(wall))yield return step;")
topology = once(topology, "audit.boundarySegments=coreStructure.boundaries.Count;",
                "audit.boundarySegments=coreStructure.boundaries.Count;yield return null;")
topology = once(topology, "coreStructure.bins[at].Add(i);}\n   }",
                "coreStructure.bins[at].Add(i);}\n    yield return null;\n   }")
topology = once(topology, "audit.horizontalDividers++;\n   }",
                "audit.horizontalDividers++;\n    yield return null;\n   }")

material = method(read(source / "NativeGemCoreMaterial.cs"),
                  "void PrepareGemCoreMaterial(byte[] wall,float[] emission)")
material = once(material, "void PrepareGemCoreMaterial(", "IEnumerable<object> WebPrepareGemCoreMaterial(")
material = once(material, "if(!crystalCores)return;", "if(!crystalCores)yield break;")
material = once(material, "lower=GemAdd(lower,p);nl++;}\n   }",
                "lower=GemAdd(lower,p);nl++;}\n    yield return null;\n   }")
material = once(material, "samples.Sort((a,b)=>GemPeak(a).CompareTo(GemPeak(b)));",
                "samples.Sort((a,b)=>GemPeak(a).CompareTo(GemPeak(b)));yield return null;")
material = once(material, "for(int y=0;y<GemBevelDepth;y++)for(int x=0;x<GemBevelAlong;x++){",
                "for(int y=0;y<GemBevelDepth;y++){for(int x=0;x<GemBevelAlong;x++){")
end = material.rfind("\n   }")
if end < 0:
    raise RuntimeError("Missing material lookup-row boundary")
material = material[:end] + "\n   }yield return null;}" + material[end + len("\n   }"):]

header = """// Generated by adapt-web-crystals.py from the approved native formulas.
// Do not hand-edit: only bounded cooperative yields differ from native setup.
using System;
using System.Collections.Generic;
using UnityEngine;
namespace MazeBiters.NativeStudy {
 public sealed partial class NativeMazeArtwork {
  IEnumerable<object> WebPrepareCrystalMaterial(byte[] wall,float[] emission){
   if(!crystalCores)yield break;
   foreach(var step in WebPrepareCrystalStructure(wall))yield return step;
   foreach(var step in WebPrepareGemCoreMaterial(wall,emission))yield return step;
  }
"""
write(web / "WebCrystalPreparation.cs", header + "  " + curves + "\n  " + topology + "\n  " + material + "\n }\n}\n")

p = web / "WebMazeArtwork.cs"
s = read(p)
if "crystalCores=CrystalCoresEnabled;StarSky=true;" not in s:
    s = once(s, "NativeMazeArtwork(SessionLevel level,string sourceRoot){StarSky=true;",
             "NativeMazeArtwork(SessionLevel level,string sourceRoot){crystalCores=CrystalCoresEnabled;StarSky=true;")
if "foreach(var step in WebPrepareCrystalMaterial" not in s:
    s = once(s, "timer.Restart();yield return null;\n    broad=new NativeArray<float>",
             "timer.Restart();yield return null;\n    foreach(var step in WebPrepareCrystalMaterial(wall,wallEmission))yield return step;\n    broad=new NativeArray<float>")
if "FinishCrystalTileProbe();" not in s:
    s = once(s, "finally{if(broad.IsCreated)broad.Dispose();",
             "finally{FinishCrystalTileProbe();crystalMaterial=crystalLight=null;coreStructure=null;ReleaseGemCoreMaterialStaging();if(broad.IsCreated)broad.Dispose();")
if "var compose=GlassComposer(" in s:
    s = once(s, "var compose=GlassComposer(", "var compose=GlassComposerRange(")
if "IEnumerable<object> WebComposeGlass(float[] seed,Action<int,float[]> compose)" in s:
    s = once(s, "IEnumerable<object> WebComposeGlass(float[] seed,Action<int,float[]> compose)",
             "IEnumerable<object> WebComposeGlass(float[] seed,Action<int,int,int,float[]> compose)")
if "compose(y,glint);yield return null;" in s:
    s = once(s, "compose(y,glint);yield return null;",
             "// Reuse this row's exact glints; bound only independent optical pixels.\n     for(int start=0;start<glassWidth;start+=128){compose(y,start,Math.Min(glassWidth,start+128),glint);yield return null;}")
write(p, s)

print("WEB_CRYSTAL_ADAPTATION native formulas copied; Web worker guards and cooperative painter retained")
for name in ("NativeCrystalCores.cs", "NativeCrystalStructure.cs", "NativeGemCoreMaterial.cs", "CrystalCoreStressAudit.cs"):
    if (web / name).read_bytes() != (source / name).read_bytes():
        # Newline normalization is harmless, but code must remain exactly equal.
        if read(web / name) != read(source / name):
            raise RuntimeError("Unexpected crystal source change: " + name)
    print(name, hashlib.sha256((web / name).read_bytes()).hexdigest())

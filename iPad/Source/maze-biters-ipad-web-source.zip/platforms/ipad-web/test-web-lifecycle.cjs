const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');
const assert = require('node:assert/strict');
const scripts = path.join(__dirname, 'UnityProject/Assets/Scripts');
const plugins = path.join(__dirname, 'UnityProject/Assets/Plugins/WebGL');
let checks = 0;
function check(value, message) { checks++; assert(value, message); }
function fixture() {
  const listeners = {window:new Map(), document:new Map()};
  function listen(group, name, callback) {
    if (!listeners[group].has(name)) listeners[group].set(name, []);
    listeners[group].get(name).push(callback);
  }
  const library = {}, clock = {now:10000}, doc = {hidden:false, focused:true};
  doc.hasFocus = () => doc.focused;
  doc.addEventListener = (name, f) => listen('document', name, f);
  doc.removeEventListener = () => {};
  const environment = {
    console, LibraryManager:{library}, mergeInto:(a,b)=>Object.assign(a,b),
    performance:{now:()=>clock.now}, document:doc,
    window:{addEventListener:(name,f)=>listen('window',name,f)}
  };
  vm.createContext(environment);
  for (const name of ['MazeWebAudio.jslib','MazeWebLifecycle.jslib']) {
    vm.runInContext(fs.readFileSync(path.join(plugins,name),'utf8'), environment, {filename:name});
  }
  environment.MBWAudio=library.$MBWAudio; environment.MBWLifecycle=library.$MBWLifecycle;
  return {
    library, clock, doc, audio:environment.MBWAudio,
    state:()=>library.MBWLifecycleState(), seconds:()=>library.MBWLifecycleSeconds(),
    event:(group,name,target)=>{for(const f of listeners[group].get(name)||[])f({target:target||(group==='window'?environment.window:doc)});},
    audioContext(state='running') {
      const context={state,resumes:0,suspends:0,
        resume(){this.resumes++;this.state='running';return Promise.resolve();},
        suspend(){this.suspends++;this.state='suspended';return Promise.resolve();}};
      environment.MBWAudio.context=context;return context;
    }
  };
}
{
  const f=fixture(), sound=f.audioContext();
  check(f.state()===0&&f.seconds()===0,'Visible startup is active.');
  f.clock.now+=750;check(f.seconds()===.75,'Active clock advances during play.');
  const generation=f.state()>>1;
  f.doc.hidden=true;f.event('document','visibilitychange');
  check((f.state()&1)===1&&(f.state()>>1)===generation+1,'Visibility immediately suspends and invalidates the next Unity frame.');
  check(sound.state==='suspended'&&sound.suspends===1,'SFX stop immediately, even without another Unity Update.');
  f.clock.now+=180000;
  check(f.seconds()===.75,'Three hidden minutes consume no menu/music/GPU timeout budget.');
  f.doc.focused=false;f.event('window','blur');
  check((f.state()>>1)===generation+1,'Nested blur does not double-count the same suspension.');
  f.doc.hidden=false;f.event('document','visibilitychange');
  check((f.state()&1)===1&&sound.resumes===0,'A visible but unfocused browser remains suspended.');
  f.doc.focused=true;f.event('window','focus');
  check((f.state()&1)===0&&f.seconds()===.75,'Refocus does not catch up hidden time.');
  check(sound.resumes===1&&sound.state==='running','Previously running SFX resume.');
  f.clock.now+=250;check(f.seconds()===1,'Only new foreground time advances.');
  f.doc.activeElement={id:'menu'};
  check((f.state()&1)===0,'Moving focus to the page toolbar is not browser suspension.');
  const beforeElementBlur=f.state();
  f.event('window','blur',{id:'retry'});f.doc.activeElement={tagName:'BODY'};f.clock.now+=300;
  check(f.state()===beforeElementBlur&&f.seconds()===1.3,'Hiding a focused Retry button must not suspend a ready menu.');
  f.event('window','focus',{id:'canvas'});f.event('window','blur',{id:'pause'});f.clock.now+=300;
  check(f.state()===beforeElementBlur&&f.seconds()===1.6,'Canvas/toolbar element focus changes never consume the confirmation clock.');
  f.event('window','pagehide');f.clock.now+=60000;
  check(f.seconds()===1.6,'Page-cache suspension freezes the clock.');
  f.event('window','pageshow');check(f.seconds()===1.6&&(f.state()&1)===0,'Page-cache restoration resumes without catch-up.');
  check((f.state()>>1)===generation+2,'A hidden/restored cycle between Unity Updates remains detectable.');
}
{
  const f=fixture(), sound=f.audioContext('suspended');f.state();
  f.doc.hidden=true;f.event('document','visibilitychange');f.clock.now+=60000;
  f.doc.hidden=false;f.event('document','visibilitychange');
  check(sound.resumes===0,'Lifecycle restoration does not unlock autoplay-gated audio.');
}
{
  const f=fixture();f.doc.hidden=true;f.doc.focused=false;f.state();f.clock.now+=90000;
  check(f.seconds()===0,'A background-started page has no elapsed preparation time.');
  f.doc.hidden=false;f.doc.focused=true;f.event('window','focus');f.clock.now+=1000;
  check(f.seconds()===1,'Background-started page starts its active clock on return.');
}
// Integration contracts prevent accidentally reintroducing raw wall time or
// overwriting the user's pause choice while changing the browser bridge.
const lifecycle=fs.readFileSync(path.join(scripts,'WebLifecycle.cs'),'utf8');
const gameplay=fs.readFileSync(path.join(scripts,'NativeGameplayStudy.cs'),'utf8');
check(gameplay.indexOf('if(HoldWebLifecycle())return;')<gameplay.indexOf('bool padPause=false,padExit=false;'),'Lifecycle gate runs before game hotkeys and clocks.');
check(lifecycle.includes('discardPreparationDelta=true;')&&lifecycle.includes('generation!=webLifecycleGeneration'),'Resume drops the stale Unity delta even if no hidden frame ran.');
check(!/\bpaused\s*=/.test(lifecycle),'Lifecycle never overwrites the player pause switch.');
check(lifecycle.includes('world?.ClearAllKeys();ReleaseIpadTouch();'),'Captured touch and held keys cannot leak across suspension.');
for(const name of ['NativeMenu.cs','NativeMenuArtworkLoading.cs','NativeMenuPreparation.cs','NativeGpuCompletion.cs','NativeResponsiveLevelGate.cs','NativeSessionAudio.cs']) {
  const source=fs.readFileSync(path.join(scripts,name),'utf8');
  check(source.includes('WebLifecycle.Realtime')&&!source.includes('Time.realtimeSinceStartupAsDouble'),name+' uses foreground time for deadlines.');
}
const result={passed:true,checks,note:'Executes the actual browser lifecycle and audio bridge with deterministic visibility/focus/page-cache events. Integration contracts verify the game gate, pause ownership, and foreground-time deadlines. Does not certify Safari audio policy or physical iPad performance.'};
fs.mkdirSync(path.join(__dirname,'Results'),{recursive:true});
fs.writeFileSync(path.join(__dirname,'Results/web-lifecycle-checks.json'),JSON.stringify(result,null,2)+'\n');
console.log(result);

const fs = require('node:fs');
const vm = require('node:vm');
const assert = require('node:assert/strict');
const path = require('node:path');
let checks = 0;
function check(value) { checks++; assert(value); }
const sources = [], nodes = [], listeners = new Map();
class Node { constructor(kind) { this.kind = kind; this.gain = {value:1}; this.connections=[]; nodes.push(this); } connect(n) {this.connections.push(n);} disconnect() {this.disconnected=true;} }
class Context {
  constructor(){this.currentTime=0;this.state='suspended';this.destination={};}
  createGain(){return new Node('gain');}
  createDynamicsCompressor(){let n=new Node('compressor');for(let p of ['threshold','knee','ratio','attack','release'])n[p]={value:0};return n;}
  createStereoPanner(){let n=new Node('panner');n.pan={value:0};return n;}
  createBuffer(channels,frames,rate){let data=Array.from({length:channels},()=>new Float32Array(frames));return {duration:frames/rate,data,getChannelData:c=>data[c]};}
  createBufferSource(){let n=new Node('source');n.start=()=>n.started=true;n.stop=()=>n.stopped=true;sources.push(n);return n;}
  resume(){this.state='running';return Promise.resolve();}
  close(){this.state='closed';return Promise.resolve();}
}
const library = {};
const storageValues=new Map([['maze-biters-existing-score','do not touch']]);let blockStorage=false,blockCommit=false,copiedText=null;
const storage={getItem:k=>{if(blockStorage)throw new Error('Storage blocked');return storageValues.has(k)?storageValues.get(k):null;},setItem:(k,v)=>{if(blockStorage||blockCommit&&k==='MazeBiters:iPad:v1:scores')throw new Error('Quota exceeded');storageValues.set(k,String(v));}};
const environment = { console, window:{AudioContext:Context,localStorage:storage}, document:{addEventListener:(n,f)=>listeners.set(n,f),removeEventListener:n=>listeners.delete(n)}, LibraryManager:{library}, mergeInto:(a,b)=>Object.assign(a,b), UTF8ToString:s=>s, lengthBytesUTF8:s=>Buffer.byteLength(s), stringToUTF8:(s,p,c)=>{copiedText={s,p,c};}, HEAPF32:new Float32Array([0,.25,-.25,.5,-.5]), GL:{currentContext:null} };
vm.createContext(environment);
const root=path.join(__dirname,'UnityProject/Assets/Plugins/WebGL');
for(const file of ['MazeWebAudio.jslib','MazeWebGpu.jslib','MazeWebScores.jslib'])vm.runInContext(fs.readFileSync(path.join(root,file),'utf8'),environment,{filename:file});
environment.MBWAudio=library.$MBWAudio;environment.MBWGpu=library.$MBWGpu;environment.MBWScores=library.$MBWScores;
const busId=library.MBWAudioCreate(), bus=environment.MBWAudio.buses[busId];
check(busId>0);check(bus.gain.gain.value===.72);check(bus.compressor.threshold.value===-10&&bus.compressor.knee.value===12&&bus.compressor.ratio.value===3);check(bus.compressor.attack.value===.003&&bus.compressor.release.value===.16);check(listeners.size===3);
check(library.MBWAudioRegister(busId,'sample',4,4,2,2)===1);
check(bus.sounds.sample.data[0][0]===.25&&bus.sounds.sample.data[1][0]===-.25&&bus.sounds.sample.data[0][1]===.5&&bus.sounds.sample.data[1][1]===-.5);
const centered=library.MBWAudioPlay(busId,'sample',0);check(centered>0);check(bus.voices[centered].pan.kind==='gain');check(library.MBWAudioPlaying(busId,centered)===1);
const side=library.MBWAudioPlay(busId,'sample',.58);check(bus.voices[side].pan.kind==='panner'&&bus.voices[side].pan.pan.value===.58);
listeners.get('pointerdown')();check(environment.MBWAudio.context.state==='running');
library.MBWAudioMute(busId,1);check(bus.output.gain.value===0);library.MBWAudioMute(busId,0);check(bus.output.gain.value===1);
library.MBWAudioStop(busId,side);check(library.MBWAudioPlaying(busId,side)===0&&sources[1].stopped&&sources[1].disconnected);
environment.MBWAudio.context.currentTime=1;check(library.MBWAudioPlaying(busId,centered)===0);check(sources[0].stopped);
library.MBWAudioPlay(busId,'sample',-.58);library.MBWAudioDestroy(busId);check(!environment.MBWAudio.buses[busId]&&environment.MBWAudio.context===null&&listeners.size===0);check(sources[2].stopped);
check(library.MBWGpuSubmit()===0);
let flushed=0,deleted=0,waits=0,lost=false,response=2;
const gl={SYNC_GPU_COMMANDS_COMPLETE:10,ALREADY_SIGNALED:1,TIMEOUT_EXPIRED:2,CONDITION_SATISFIED:3,WAIT_FAILED:4,isContextLost:()=>lost,
  fenceSync:(condition,flags)=>{check(condition===10&&flags===0);return {};},flush:()=>flushed++,deleteSync:()=>deleted++,
  clientWaitSync:(fence,flags,timeout)=>{check(flags===0&&timeout===0);waits++;return response;}};
environment.GL.currentContext={GLctx:gl};
const fence=library.MBWGpuSubmit();check(fence>0&&flushed===1);check(library.MBWGpuPoll(fence)===0);
response=3;check(library.MBWGpuPoll(fence)===1);library.MBWGpuRelease(fence);check(deleted===1&&library.MBWGpuPoll(fence)===-1);
library.MBWGpuRelease(fence);check(deleted===1);
const failed=library.MBWGpuSubmit();response=4;check(library.MBWGpuPoll(failed)===-1);lost=true;library.MBWGpuRelease(failed);check(deleted===1);check(library.MBWGpuSubmit()===0);check(waits===3);
check(library.MBWScoreRead(0,0,0)===0);
const jsonA=JSON.stringify({version:1,entries:[{name:'ONE',score:100}]}),jsonB=JSON.stringify({version:1,entries:[{name:'TWO',score:200}]});
check(library.MBWScoreCommit(jsonA,0)===1);check(storageValues.get(environment.MBWScores.key)===jsonA);check(library.MBWScoreRead(0,0,0)===Buffer.byteLength(jsonA)+1);
check(library.MBWScoreRead(0,8,1)===Buffer.byteLength(jsonA)+1&&copiedText===null);
check(library.MBWScoreRead(0,8,1000)>0&&copiedText.s===jsonA&&copiedText.p===8);
check(library.MBWScoreCommit(jsonB,0)===1);check(storageValues.get(environment.MBWScores.key+':backup')===jsonA);
check(library.MBWScoreRead(1,0,0)===Buffer.byteLength(jsonA)+1);
storageValues.set(environment.MBWScores.key,'broken');check(library.MBWScoreCommit(jsonB,1)===1);check(storageValues.get(environment.MBWScores.key+':unreadable')==='broken'&&storageValues.get(environment.MBWScores.key+':backup')===jsonA);
check(library.MBWScoreCommit('invalid',0)===-3);check(library.MBWScoreCommit('{"version":9,"entries":[]}',0)===-3);check(storageValues.get(environment.MBWScores.key)===jsonB);
blockCommit=true;check(library.MBWScoreCommit(jsonA,0)===-1);check(storageValues.get(environment.MBWScores.key)===jsonB);blockCommit=false;
blockStorage=true;check(library.MBWScoreRead(0,0,0)===-1&&library.MBWScoreCommit(jsonA,0)===-1);blockStorage=false;
check(storageValues.get('maze-biters-existing-score')==='do not touch');check(Array.from(storageValues.keys()).filter(k=>k.startsWith('MazeBiters:iPad:v1:scores')).length===3);
const result={passed:true,checks,note:'Mock Web Audio, WebGL2, and isolated synchronous score storage API contracts, including quota/security failures. Not an actual browser audio/GPU compatibility or device performance claim.'};
fs.writeFileSync(path.join(__dirname,'web-bridges-checks.json'),JSON.stringify(result,null,2));console.log(result);

const fs = require('node:fs');
const vm = require('node:vm');
const path = require('node:path');
const source = process.argv[2] ? path.resolve(process.argv[2]) : path.resolve(__dirname, '../../UnityProject/Assets/WebGLTemplates/MazeBiters/index.html');
const html = fs.readFileSync(source, 'utf8');
const script = [...html.matchAll(/<script>([\s\S]*?)<\/script>/g)].map(m=>m[1]).join('\n');
function host() {
  const elements = new Map(), calls = [], listeners = new Map();
  const element = id => {
    if (!elements.has(id)) elements.set(id,{style:{},textContent:'',value:0,width:0,height:0,focus(){calls.push(['focus',id]);},addEventListener(){}});
    return elements.get(id);
  };
  const context = {console,URLSearchParams,innerWidth:1920,innerHeight:1080,addEventListener(name,fn,capture){if(!listeners.has(name))listeners.set(name,[]);listeners.get(name).push({fn,capture});},
    location:{search:'',reload(){calls.push(['reload']);}},
    document:{querySelector:element,addEventListener(){},documentElement:{},fullscreenElement:null},
    fakeUnity:{SendMessage(...args){calls.push(['send',...args]);}},
  };
  context.window=context;vm.createContext(context);vm.runInContext(script,context);
  return {context,elements,calls,listeners,run:s=>vm.runInContext(s,context)};
}
const checks=[];
function test(name,body){try{const result=body(host());checks.push({name,...result});}catch(e){checks.push({name,pass:false,error:e.message});}}
test('Initial boot failure reloads whole runtime',h=>{h.run("failed('initial boot failure')");h.elements.get('#retry').onclick();return {pass:h.calls.some(c=>c[0]==='reload'),calls:h.calls};});
test('Recoverable asset download failure retries bootstrap',h=>{h.run("unity=fakeUnity; mazeWebStatus('asset interrupted',0,-1)");h.elements.get('#retry').onclick();return {pass:h.calls.some(c=>c[0]==='send'&&c[2]==='Retry'),calls:h.calls};});
test('Fatal error after runtime creation must reload runtime',h=>{h.run("unity=fakeUnity; failed('WASM runtime aborted')");h.elements.get('#retry').onclick();return {pass:h.calls.some(c=>c[0]==='reload'),calls:h.calls};});
test('Fatal error must remain visible despite a pending asset callback',h=>{h.run("unity=fakeUnity; failed('WASM runtime aborted'); mazeWebStatus('background assets',0.6,1)");return {pass:h.elements.get('#loading').style.display!=='none',display:h.elements.get('#loading').style.display};});
test('HD/4K canvas remains native size',h=>{h.run("mazeWebState('{\"quality\":\"4k\"}')");const c=h.elements.get('#canvas');return {pass:c.width===3840&&c.height===2160,width:c.width,height:c.height};});
test('HD canvas remains native size',h=>{h.run("mazeWebState('{\"quality\":\"hd\"}')");const c=h.elements.get('#canvas');return {pass:c.width===1920&&c.height===1080,width:c.width,height:c.height};});

test('Resize affects CSS fit only, preserving the 4K drawing buffer',h=>{h.run("mazeWebState('{\"quality\":\"4k\"}')");h.context.innerWidth=1280;h.context.innerHeight=720;h.run('fit()');const c=h.elements.get('#canvas');return {pass:c.width===3840&&c.height===2160&&parseFloat(c.style.width)/parseFloat(c.style.height)===16/9,width:c.width,height:c.height,style:c.style};});

test('Portrait viewport does not stretch canvas',h=>{h.context.innerWidth=768;h.context.innerHeight=1024;h.run('fit()');const s=h.elements.get('#canvas').style;return {pass:parseFloat(s.width)/parseFloat(s.height)===16/9,style:s};});
test('DOM toolbar key activation and matching release never reach Unity',h=>{let stopped=0,prevented=0;const event={code:'Enter',key:'Enter',target:{closest:()=>true},stopImmediatePropagation(){stopped++;},preventDefault(){prevented++;}};for(const x of h.listeners.get('keydown')||[])if(x.capture)x.fn(event);event.target={closest:()=>false};for(const x of h.listeners.get('keyup')||[])if(x.capture)x.fn(event);return {pass:stopped===2&&prevented===0,stopped,prevented};});
test('Normal gameplay arrow input remains available to Unity',h=>{let stopped=0;const event={code:'ArrowUp',key:'ArrowUp',target:{closest:()=>false},stopImmediatePropagation(){stopped++;}};for(const x of h.listeners.get('keydown')||[])if(x.capture)x.fn(event);return {pass:stopped===0,stopped};});
test('Recoverable retry button hides until a new error arrives',h=>{h.run("unity=fakeUnity; mazeWebStatus('asset interrupted',0,-1)");h.elements.get('#retry').onclick();const afterClick=h.elements.get('#retry').style.display;h.run("mazeWebStatus('retrying',0.3,1)");return {pass:afterClick==='none'&&h.elements.get('#retry').style.display==='none',afterClick};});
function key(h,type,overrides={}) {
  const event={code:'Enter',key:'Enter',altKey:true,repeat:false,target:{closest:()=>false},stopped:false,prevented:false,
    stopImmediatePropagation(){this.stopped=true;},preventDefault(){this.prevented=true;},...overrides};
  for(const x of h.listeners.get(type)||[]){x.fn(event);if(event.stopped)break;}
  return event;
}
test('Alt+Enter toggles fullscreen once per press without activating the menu',h=>{
  let entered=0,exited=0;const doc=h.context.document;
  doc.documentElement.requestFullscreen=()=>{entered++;doc.fullscreenElement=doc.documentElement;return {catch(){}};};
  doc.exitFullscreen=()=>{exited++;doc.fullscreenElement=null;return {catch(){}};};
  const down=key(h,'keydown');key(h,'keydown',{repeat:true});key(h,'keydown');
  const up=key(h,'keyup',{altKey:false});key(h,'keydown');key(h,'keyup');
  const plain=key(h,'keydown',{altKey:false});
  return {pass:entered===1&&exited===1&&down.stopped&&down.prevented&&up.stopped&&up.prevented&&!plain.stopped,entered,exited};
});
test('Window blur clears an interrupted Alt+Enter press',h=>{
  let calls=0;h.context.document.documentElement.requestFullscreen=()=>{calls++;return {catch(){}};};
  key(h,'keydown');for(const x of h.listeners.get('blur')||[])x.fn({});key(h,'keydown');
  return {pass:calls===2,calls};
});
test('Fullscreen button tolerates browsers without a fullscreen API',h=>{
  h.elements.get('#full').onclick();return {pass:h.calls.some(c=>c[0]==='focus'&&c[1]==='#canvas')};
});
const report={source,kind:'Actual shell script with mocked DOM and Unity bridge; no simulated game execution',passed:checks.filter(c=>c.pass).length,total:checks.length,checks};
fs.writeFileSync(path.join(__dirname,'web-shell-contract.json'),JSON.stringify(report,null,2));
console.log(JSON.stringify(report,null,2));

if(report.passed!==report.total)process.exitCode=1;

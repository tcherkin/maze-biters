# Rebuilding and publishing the isolated PC Web edition

This directory is the web-specific Unity fork. Keep it at `platforms/pc-web`.
The native PC, native iPad, iPad Web and original browser projects are independent.

## Reconstruct a published source archive

1. Extract `Source/maze-biters-pc-web-source.zip` at a workspace root.
2. Obtain the published `PC/StreamingAssets/WebPayload` directory, including `manifest.json`
   and every hash-named pack listed in it. A clone of the release repository includes them.
3. From the workspace root, run:

   ```text
   python platforms/pc-web/restore-source-assets.py PC/StreamingAssets/WebPayload
   ```

   This verifies every pack and restored source file. It restores `SourceAssets`
   for Editor use, plus `WebPayload` and the small compressed payload inside the
   Unity project's `Assets/StreamingAssets/WebPayload` directory. It does not restore excluded
   visual-test screenshots or captured legacy levels; these are not needed by the
   interactive web build. Full legacy validation commands require the separate
   original development fixtures.

## Build

Use Unity **6000.6.3f1** with **Web Build Support** installed. The project stores its
package versions in `Packages/manifest.json` and `packages-lock.json`.

For a source-art or sound change, regenerate the payload first:

```text
python platforms/pc-web/export-web-sfx.py
python platforms/pc-web/pack-web-assets.py
```

Copy only the packs named by `WebPayload/manifest.json` and that manifest into
`UnityProject/Assets/StreamingAssets/WebPayload`. The raw `SourceAssets` must remain outside
Unity `Assets`; otherwise Unity also packages the large uncompressed source set.

From the Unity command line, use these arguments with your installed Unity executable:

```text
-batchmode -quit -projectPath platforms/pc-web/UnityProject -buildTarget WebGL -executeMethod WebBuild.Build -logFile web-build.log
```

The output is `platforms/pc-web/Builds/PC`. `WebBuild` selects WebGL2, disables
C# threads, keeps the approved shaders, and uses Gzip with decompression fallback
so the build works on GitHub Pages without custom response headers.
Unity build resources use hashed filenames. After a successful build, the editor
also writes `build-info.json` and a copy named `manifest-<build GUID>.json` inside
`StreamingAssets/WebPayload`. The runtime requests that exact manifest; the
canonical `manifest.json` remains available for source reconstruction.

Serve the output through HTTP, not `file://`. Check startup, mode selection while
loading, keyboard/menu/controller input, quality switching, audio after a gesture,
GAME OVER and restart, plus HD (1920 × 1080) and 4K (3840 × 2160) play. Inspect
browser errors and test supported browsers before claiming compatibility.

## Prepare an additive repository change

The deployment checkout belongs at `platforms/pc-web/Publish`, with origin
`https://github.com/tcherkin/maze-biters.git`. It must track the current `main`.
Use an independent clone; do not replace the original game's checkout.

After testing the final build:

```text
python platforms/pc-web/prepare-publication.py
git -C platforms/pc-web/Publish diff --stat
git -C platforms/pc-web/Publish status --short
```

The preparation tool writes only `Publish/PC`, checks the 100 MiB Git file limit,
creates a reproducible source ZIP without caches/logs/local paths, and writes a
release manifest. It does **not** commit, push, or change GitHub settings.
The generated `PC/.gitattributes` preserves exact artifact bytes, including
JSON line endings, so Git's text conversion cannot invalidate the release hashes.
The release manifest separates `currentFiles` from `compatibilityFiles`. The tool
retains only the preceding PC release's own runtime files for already-cached HTML;
it does not inherit older compatibility generations or any iPad release files.
The build directory may contain old artifacts, but only files referenced by the
current HTML, its identified manifest and its hash packs enter the current set.

Review that every change is under `PC/`. Compare the complete non-PC Git tree
with the pre-publication baseline, including all iPad files. Stage and commit
that directory only. Check generated-file hashes against staged Git blobs too.
Fetch `origin/main` again immediately before pushing; if it changed, reconcile the
additive directory on the newer main without overwriting unrelated changes.

The repository already publishes GitHub Pages from `main` at `/`. No new Pages
workflow or settings change is required. Pushing the additive `PC/` directory
publishes `https://tcherkin.github.io/maze-biters/PC/` while retaining the original
game at `https://tcherkin.github.io/maze-biters/` and the existing iPad edition at
`https://tcherkin.github.io/maze-biters/iPad/`. Do not change either existing tree.

After deployment, verify the PC page, build files and packs return successful
responses, check the in-browser game again, and confirm the original root page
and entire iPad tree are unchanged. GitHub Pages limits the complete published
site to 1 GB; ordinary Git files must remain below 100 MiB. Keep unreferenced
build artifacts out of `PC/` on updates while retaining the preceding generation.


## Storage, size and preservation checks

Use separate `MazeBiters:PC:` score keys and `MazeBiters:PCWeb:` preference keys:
all three web editions share a browser origin even though their URLs differ.
Do not make PC load mutable files from the iPad folder. Its runtime, manifests
and payload packs must resolve relative to the PC build.

The published repository is already sizeable. The helper counts every tracked
file outside `PC/`, including iPad compatibility resources, and refuses a total
of 990,000,000 bytes or more. The first PC release has no previous PC runtime to
retain. Subsequent releases retain one PC generation only. Do not reduce the
existing iPad resources to make room; if the site no longer fits, use a separate
hosting destination rather than silently removing another edition.

Keep runtime files in ordinary Git below 100 MiB each. Pack payloads into small
hash-named gzip files and do not add raw SourceAssets, Unity Library, build logs,
or test captures. Gzip decompression fallback avoids needing custom GitHub Pages
Content-Encoding headers. Hash-named Unity resources and build-GUID manifests
prevent cached HTML from mixing different build generations.

Run `python platforms/pc-web/Results/audit/test-publication-retention.py` for the
isolated publication contract checks. This creates tiny test fixtures only; it
never stages, commits, pushes, or touches the real deployment directory.

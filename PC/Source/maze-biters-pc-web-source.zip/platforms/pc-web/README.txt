MAZE BITERS — PC WEB

Independent WebGL 2 / WebAssembly edition of the widescreen PC Unity project.
Native PC, native iPad, iPad Web and the original browser game stay independent.

Public address: https://tcherkin.github.io/maze-biters/PC/
The game uses 16:9: HD is 1920 x 1080; 4K is 3840 x 2160.
The view fits the browser window without stretching characters.

SOLO controls: arrows or WASD. Two local players: WASD for player 1 and arrows
for player 2. Compatible gamepads are supported. Enter confirms menu choices,
P pauses, Escape returns from gameplay to the menu. The page has Pause, Menu
and Full Screen controls. A browser may consume Escape to leave full screen.
Audio needs a user gesture. Local records and settings use PC-specific storage
and do not overwrite iPad Web or original browser saves.

Build with Unity 6000.6.3f1 plus Web Build Support; see DEPLOYMENT.md.
SourceAssets contains runtime source files; pack-web-assets.py selects runtime
resources, compresses them losslessly and verifies each source hash.
Unity Assets/StreamingAssets contains distributable packs, not desktop fixtures.
Menu resources load first; gameplay preparation continues while menus operate.

Browser-specific adaptations:
- Cooperative preparation instead of managed worker threads.
- RGBAFloat light-record textures instead of desktop structured buffers.
- Nonblocking WebGL 2 completion fences.
- Web Audio for original PCM effects; Unity AudioSource for music.
- Browser-local score storage with write/read-back validation.

Actual browser performance depends on hardware and resolution. Native desktop
performance and physical-device compatibility are not implied by a web build.

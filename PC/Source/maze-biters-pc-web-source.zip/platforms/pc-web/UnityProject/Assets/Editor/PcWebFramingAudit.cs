using System;
using System.IO;
using UnityEngine;
using MazeBiters.NativeStudy;

// Checks the actual PC camera and its frozen reference traces. This does not
// measure browser/GPU performance or claim pixel parity across graphics APIs.
public static class PcWebFramingAudit {
 [Serializable] sealed class Result {
  public bool passed;
  public int framingChecks,sourceChecks,soloChecks,duoChecks,trioChecks,overviewChecks,total;
  public string note;
 }
 public static void Validate(){
  var result=new Result{note="Original PC camera/overview source, keyboard/controller mapping, frozen solo/duo/trio camera traces and 16:9 presentation. Rendering and browser input are checked separately."};
  void Check(bool ok,string name){result.framingChecks++;if(!ok)throw new Exception("PC Web framing: "+name);}
  void Near(double a,double b,string name)=>Check(Math.Abs(a-b)<.001,name+": "+a+" / "+b);
  Check(!IpadPresentation.Enabled,"iPad camera, safe-area, touch-drag and 160-pixel zoom adaptation are disabled");
  var hd=PcWebPresentation.Pixels("hd");var uhd=PcWebPresentation.Pixels("4k");
  Check(hd==new Vector2Int(1920,1080),"HD render target is native PC 1920 x 1080");
  Check(uhd==new Vector2Int(3840,2160),"4K render target is native PC 3840 x 2160");
  var f=new NativeFrame(PcWebPresentation.Aspect,true);
  Near(f.Width,768,"PC logical width");Near(f.Height,432,"PC logical height");
  Check(f.OverlayHud&&f.TopInset==0&&f.ViewOffsetY==0,"HUD overlays the full game viewport");
  double overview=NativeOverviewFraming.Zoom(f,1);var board=f.ProjectBoard(288,200,overview);
  Near(overview,1.08,"native PC overview enlargement");Near(board.y,0,"overview reaches top");Near(board.yMax,f.Height,"overview reaches bottom");
  Check(board.x>0,"overview keeps side stars");Near(board.x,f.Width-board.xMax,"side stars balanced");
  Near(NativeOverviewFraming.Zoom(f,2),2,"native PC maximum close zoom");
  Near(16*2*uhd.y/f.Height,160,"4K cell occupies original 160 pixels at maximum close zoom");
  Near(16*2*hd.y/f.Height,80,"HD cell occupies original 80 pixels at maximum close zoom");
  var middle=f.ProjectBoard(288,200,2);Check(middle.x<0&&middle.xMax>f.Width&&middle.y<0&&middle.yMax>f.Height,"close centre fills the wide viewport");
  var top=f.ProjectBoard(288,NativeOverviewFraming.Y(f,100,2,2),2);
  var bottom=f.ProjectBoard(288,NativeOverviewFraming.Y(f,300,2,2),2);
  Near(top.y,52,"approved top sky margin");Near(f.Height-bottom.yMax,52,"approved bottom sky margin");
  var left=f.ProjectBoard(144,200,2);var right=f.ProjectBoard(432,200,2);
  Near(left.x,96,"native PC left edge sky");Near(f.Width-right.xMax,96,"native PC right edge sky");
  foreach(var pixels in new[]{hd,uhd})foreach(double zoom in new[]{overview,1.5,2.0})foreach(double cx in new[]{144.0,288,432}){
   var projected=f.ProjectBoard(cx,200,zoom);
   for(int row=0;row<25;row++)for(int col=0;col<36;col++){
    var p=new Vector2((float)(projected.x+(col+.5)*16*zoom),(float)(projected.y+(row+.5)*16*zoom));
    var physical=new Vector2(p.x/f.Width*pixels.x,pixels.y-p.y/f.Height*pixels.y);
    var logical=f.Logical(physical,new Rect(0,0,pixels.x,pixels.y),pixels.y);
    bool visible=p.x>=0&&p.x<f.Width&&p.y>=0&&p.y<f.Height;
    bool hit=f.PointerCell(logical,cx,200,zoom,out var cell);
    Check(hit==visible&&(!hit||cell==new Vector2Int(col,row)),"HD/4K mouse projection matches camera");
   }
  }
  string source=Path.Combine(Application.dataPath,"Scripts");
  string original=Path.GetFullPath(Path.Combine(Application.dataPath,"../../../../experiments/unity-native-study/UnityProject/Assets/Scripts"));
  if(Directory.Exists(original)){
   string Read(string root,string name)=>File.ReadAllText(Path.Combine(root,name)).Replace("\r\n","\n");
   void Same(string a,string b,string name){result.sourceChecks++;if(a!=b)throw new Exception("PC source parity: "+name);}
   foreach(string file in new[]{"NativeGameplayCamera.cs","NativeOverviewFraming.cs","NativeGamepadInput.cs"})Same(Read(original,file),Read(source,file),file);
   string Slice(string text,string from,string until){int begin=text.IndexOf(from,StringComparison.Ordinal);if(begin<0)throw new Exception("Missing PC source section "+from);int end=text.IndexOf(until,begin,StringComparison.Ordinal);if(end<0)throw new Exception("Missing PC source boundary "+until);return text.Substring(begin,end-begin);}
   Same(Slice(Read(original,"NativeGameplayStudy.cs"),"static readonly KeyCode[] keys=","void InputStep()"),Slice(Read(source,"NativeGameplayStudy.cs"),"static readonly KeyCode[] keys=","void InputStep()"),"keyboard bindings and player ownership");
   Same(Slice(Read(original,"NativeGameplayCameraIntegration.cs"),"if(NativeDisplay.Enabled){double originalY=y;","cameraViewX=x;"),Slice(Read(source,"NativeGameplayCameraIntegration.cs"),"if(NativeDisplay.Enabled){double originalY=y;","cameraViewX=x;"),"original PC camera/framing branch");
  }
  result.soloChecks=NativeCameraValidation.Run();result.duoChecks=NativeCoopValidation.Camera();result.trioChecks=NativeCoopValidation.Camera(true);
  result.overviewChecks=NativeOverviewFramingValidation.Run();
  result.total=result.framingChecks+result.sourceChecks+result.soloChecks+result.duoChecks+result.trioChecks+result.overviewChecks;result.passed=true;
  string dir=Path.GetFullPath(Path.Combine(Application.dataPath,"../../Results/pc-framing"));Directory.CreateDirectory(dir);File.WriteAllText(Path.Combine(dir,"checks.json"),JsonUtility.ToJson(result,true));
  Debug.Log("PC_WEB_FRAMING_CHECKS "+result.total+" source="+result.sourceChecks);
 }
}
